- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Staten Island Community District 2 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1t5XvRbCSnAh52LcRUXo-dx-ffAQFrKct/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1t5XvRbCSnAh52LcRUXo-dx-ffAQFrKct/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Staten Island Community District
2
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Staten Island Community Board 2
image
Address: 900 South Avenue, Suite 28
Phone: (718) 68-3581
Email: dderrico@cb.nyc.gov
Website: www.cb2si.com
Chair: Dana T. Magee District Manager: Debra Derrico
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 2 has many prevailing needs that impact the quality of life of our community residents and our businesses. Our district is approximately 24 square miles in area encompassing the entire mid-island section of Staten Island. Our geographic district comprises Willowbrook, Todt Hill, Dongan Hills, Midland Beach, New Dorp, Arrochar, Old Town, Grasmere, Manor Heights, Bloomfield, Chelsea, Travis, Heartland Village, New Springville, Bulls Head, and Lighthouse Hill. Staten Island is primarily made up of one and two-family houses and many thriving businesses. Each town is proud of its unique qualities and individual characteristics which residents strive to maintain. The stability of our district depends greatly on the viability of its commercial sectors and housing stock.
Our growing aging population requires more funding and more services for our seniors. Advocates project that 1 in 5 New Yorkers will be over the age of 65 in 2030. Staten Island is also projected to have the largest aging population in New York City by 2030. As the population ages, we need to be able to provide services to ensure the safety and well-being of our senior population.
The developmental trends within District 2 will help address these issues. The former Farm Colony will provide much needed senior-targeted housing and create a new district that compliments and enhances the surrounding community. This residential community, located on Brielle Avenue will contain approximately 350 residential units, 17,000 square feet of commercial space, as well as a central green space and accessory parking. The Sea View Senior Living Center will create much-needed senior-housing and provide quality care for many of the area residents. This center will be used for both assisted living and non-assisted services and as a community center for our senior population.
The increase in substance abuse on Staten Island is a major issue and is considered an epidemic. Staten Island has a high rate of illegal drug use in the borough. There is a great need for more treatment services to help combat this issue. It is imperative that we have increased education about the harmful effects of drug use and this education must begin at the elementary school level.
Community Board 2 is fortunate to have concerned, energetic and devoted citizens who work actively to maintain the stability of our area. Our board has supported, assisted and participated in these activities and will continue to do so for the betterment of our district. We will continue to petition for improvements and services that our district is entitled to receive.
4. TOP THREE PRESSING ISSUES OVERALL
Staten Island Community Board 2
image
The three most pressing issues facing this Community Board are:
Infrastructure resiliency
A top priority for our district is the commercial revitalization and development of the East Shore of Staten Island. It is well-known that the East Shore of Staten Island sustained severe damage from Hurricane Sandy. Residential revitalization, as well as storm damage mitigation programs, have been well underway but there is still a lot of work that needs to be done in regards to commercial development. In order to attract business owners to the area, it is essential that sidewalk improvement, street improvement, and signage projects are implemented. Sidewalk improvement needs for the East Shore are increased street furniture and lighting (i.e city benches, ornamental solar lights on street trees, holiday lighting on the main commercial corridors) and enhancement of greenery of streets (i.e. street trees, tree guards, rain gardens, bioswales). Street improvement needs include enhanced traffic calming measures (i.e. mid-block painted crosswalks on Midland Avenue and Sand Lane, medians and pedestrian refuge island on Hylan Blvd.) and expanding bike infrastructure (i.e. shared bike lane on Sand Lane). Other improvements that will beautify the area are creating a gateway between the beach and commercial corridors (i.e. gateway public art sculpture on Father Capodanno Bouelvard), creating a pedestrian pathway connecting boardwalk to Father Capodanno at Midland Avenue and creating shared space around Fountain of the Dolphins.
Schools
Due to the widespread of substance abuse among our youth, more programs and interventions are needed to reduce the prevalence of substance abuse behaviors. The request again this year is to have every public elementary, intermediate, and high school on Staten Island assigned a Substance Abuse Prevention and Intervention Specialist (SAPIS). The SAPIS program provides a range of prevention and intervention services in Kindergarten through 12th grade. Staten Island has 81 public schools. Of the 81 public schools here on Staten Island, only 48 have an evidence- based program for drug abuse, and 33 do not have a program in place to prevent drug abuse amongst our youth.
There are no programs in twenty-two of the 50 elementary schools. We need to do more and do better to help reduce drug abuse and school failure. .
Traffic
Traffic congestion and mobility continues to be another one of the district's top problem. As the population continues to grow, our ability to move on and off throughout the Island has become difficult at best, and at times nearly impossible. The majority of our roadways consist of two-lane country roads (one lane in each direction) with an antiquated traffic signal system that needs to be upgraded. Staten Island is under served by public transportation. By increasing public transportation options, particularly by expanding city-wide Ferry service, the commute time would likely improve. A large percentage of Staten Island residents require 60 minutes or more to commute to work. In 2015 Mayor de Blasio proposed five new fast-ferry lines to connect outer-boroughs to Manhattan. The plan was called the "5-Borough Ferry Plan," but Staten Island, the fifth borough was left out.
Community Board 2 requested last year and is requesting again this year Ferry Service from St. George to Bay Ridge Brooklyn, and DUMBO. The connection between the boroughs, which are currently separated by a $19 toll, could provide incalculable benefits to the residents and economies of these boroughs. This connection will improve connectivity, provide access to workforce opportunities, reduce wear and tear on roads and boost local businesses. DUMBO is home to emerging job hubs, strong academic institutions, and cultural institutions. The commute time between St. George, Staten Island and DUMBO takes approximately one hour and requires multiple transfers between the ferry and trains. A direct line could reduce travel time and alleviate overcrowding on subways.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Staten Island Community Board 2
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
Senior advocates estimate that by 2040, New York’s 60+plus population will increase to 1.86 million. By 2040, boomers will be part of the oldest population group. Staten Island is also projected to have the greatest senior population in New York City by 2030. As the population ages, we need to be able to provide services to ensure that resources are available to give our seniors the quality of life they deserve. Elder abuse protection, housing, healthcare, senior centers, and many other support systems must be enhanced and continued to meet the needs of our growing senior population. And, as the senior population grows, additional and appropriate placement of services is needed. Therefore, we not only need an increase in senior services, but also to advocate for managed long-term care companies to better evaluate client’s needs so they can be placed in the appropriate care setting.
Guidelines should look for criteria that evaluate medical, psychological, and social needs. However, some social adult-day care centers remain unregulated by the city or state, which does not address the medical and social needs of our elderly and disabled. Proper regulations must protect the vulnerability of our seniors. There are 288 registered social adult day care centers in New York City, 15 registered on Staten Island. These programs are funded by Medicaid through Managed Long-term Care companies (MLTC). MLTC is a system that streamlines the delivery of long-term services to people who are chronically ill or disabled and who wish to stay in their homes and communities. The New York City Department for the Aging (DFTA) enforces the standards from a 1994 State Office of the Aging guideline. DFTA can impose fines for the agencies that are breaking rules. However, there is no enforcement of these fines. Social adult day care centers remain unregulated by the city or state, which does not address the medical and social needs of our elderly and disabled. Proper regulations are needed to protect the vulnerability of our seniors. A regulatory program with DFTA must have direct authority oversight of adult day care. Seniors should be placed in facilities that serve their required needs, not just placed in "pop-up" daycare centers which in truth are real "babysitting" services for our seniors. Guidelines should look for criteria that evaluate medical, psychological, and social needs. The need of seniors services is critical as the population increases.
Community Board 2's Aging committee is grateful of DFTA’s support on SI programs that are run at the Jewish Community Center of SI. Their funding has provided needed community programming and innovations in senior centers directed to residents with dementia and early cognitive impairments. These programs are popular with older persons and their caregivers with events often being conducted to packed houses.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
11/16
HHC
Provide a new or
Fund the development of a Staten Island Health
460 Brielle
expanded health
and Wellness Campus on the grounds of Sea
Avenue
care facility
View Hospital Rehabilitation Center and Home,
which would also include housing and services
for seniors and the disabled.
12/16
DFTA
Create a new senior
Provide additional funding in the budget to
460 Brielle
center or other
rehabilitate the vacant buildings on the campus
Avenue
facility for seniors
of Sea View Hospital Rehabilitation Center and
Home. There are approximately 40 buildings
and less than half are currently being used.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
20/20
DOHMH
Reduce rat
Increase DOHMH funds to cut down on the rat
populations
population. There has been thousands of rat
sightings on Staten Island in recent years.
However Staten Island is was not part of Mayor
Bill de Blasio's $32 million plan to cut down on
the rodent infestation problem in 2017. As we
all know, Rats have the potential to spread a
wide variety of diseases. They tend to live in
environments such as drains, sewers, and
rubbish where germs can be found. These germs
can then be spread wherever rats go by way of
their fur, feet, urine or droppings. The main
diseases of concern are Weils disease. Rats can
also damage property by gnawing at wood,
lead and soft metals, electrical wiring, water
pipes, and drainage systems.
YOUTH, EDUCATION AND CHILD WELFARE
Staten Island Community Board 2
image
M ost Important Issue Related to Youth, Education and Child Welfare
Support services for special needs youth (disabled, immigrant, non-English proficient, etc.)
Approximately 48,000 students on Staten Island are eligible for an Individualized Education Program (IEP) yet due to the shortage of special education services in Staten Island schools, and the lack of on-site providers, parents are given Related Service Authorization (RSA) vouchers, which places the burden on parents to find a provider, coordinate services, and transport their child or children to the provider. A large percentage of the eligible students did not utilize their RSA vouchers and received the services they need and are entitled to because of the burden placed on the parent to find providers who have availability. According to former Public Advocate Leticia James, the voucher program does not work for students, parents or schools and is leading to the neglect of students with disabilities. It is essential for NYC Department of Education to re-evaluate its reliance on RSA vouchers and find a way to provide for all students. In addition to re-evaluating the RSA voucher programs, Community Board 2 would like to request an increase in IEP specialized in our district schools.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Staten Island has a high rate of opioid overdoses in New York City, according to city Health Department data, and the second-highest rate of heroin overdose deaths per 100,000 residents in 2017. Due to the widespread substance abuse among our youth, more programs and interventions are needed to reduce the prevalence of substance abuse and prevent the escalation of substance abuse behaviors.
The request again this year is to have every public elementary, intermediate, and high school on Staten Island assigned a Substance Abuse Prevention and Intervention Specialist (SAPIS). The SAPIS program provides a range of prevention and intervention services in Kindergarten through 12th grade. According to data collected by Tackling Youth Substance Abuse (TYSA), which is part of Staten Island Partnership for Community Wellness (SIPCW), 32 of the borough's 81 public schools didn't have an evidence-based program in place to prevent substance abuse among youth.
Staten Island received twenty-four SAPIS counselors in 2017, however, it is simply not enough to help combat the ever-growing drug epidemic here on Staten Island. Staten Island has 81 public schools. Of the 81 public schools here on Staten Island, only 48 have an evidence-based program for drug abuse, and 33 do not have a program in place to prevent drug abuse amongst our youth. There are no programs in 22 of the 50 elementary schools. We need to do more and do better to help reduce drug abuse and school failure.
In addition, air-conditioning units should be installed in all public schools on Staten Island for health and safety reasons. Most high schools and elementary schools have air-conditioners, but few intermediate schools are air- conditioned. As early as late spring into early summer, classroom temperatures rise as high as the upper 90's. With extreme heat comes poor air quality. Children and adults with respiratory conditions, such as asthma or heart conditions, may be especially sensitive to the the heat and air quality. This creates unacceptable working conditions for our teachers and students.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
7/16
SCA
Provide technology
Provide funding for security cameras at Staten
485 Clawson
upgrade
Island Technical High. It is the only public high
Street
school on the island that doesn't have them.
This is a priority that needs to be addressed
especially in these unsafe times.
13/16
SCA
Renovate or
Install central air-conditioning units in PS 54. As
1060
upgrade an
early as late spring into early summer,
Willowbrook
elementary school
classroom temperatures rise as high as in the
Road, Staten
upper 90's. This is unacceptable working
Island
conditions for students,as well as teachers.
15/16
SCA
Renovate interior
The New Dorp High School east gymnasium
465 New
building component
requires an upgrade. The upgrade would
Dorp Lane
include painting, refinishing the floor, repairing
light fixtures, and installing a digital scoreboard
and collapsible bleachers.
CS
SCA
Renovate or
Install air-conditioning units in all public schools
upgrade a middle or
on Staten Island. Most high schools and
intermediate school
elementary schools have air-conditioners, but
few intermediate schools are air-conditioned. As
early as late spring into early summer,
classroom temperatures rise as high as in the
upper 90's. This is unacceptable working
conditions for our teachers, as well as students.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
3/20
DOE
Assign more
Assign a Substance Abuse Prevention and
teaching staff
Intervention Specialist (SAPIS) to every Staten
Island Elementary, Intermediate and High
School to reduce the prevalence of substance
abuse and prevent the escalation of substance
abuse behaviors among our Staten Island youth.
PUBLIC SAFETY AND EMERGENCY SERVICES
Staten Island Community Board 2
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
There have been multiple attacks committed by minors at the Staten Island Mall. On June 21, 2019 four separate attacks were reported on teen girls in the shopping mall. The assailants in those incidents were ages 12 and 13. One of the attacks left a 14-year-old girl bloodied and bruised, and another suffered a concussion. On June 26, two 14- year-old girls were set upon by a larger group of female teens aged 13 and 14. In July there were five separate assaults on teen girls over a 10 day period. The beating left a 14-year-old bloodied and bruised, and another suffered a concussion. In early November two adult women had a scary encounter with a group of 10 teenagers who threw bottles and trash at them, shouted profanities at them and spit at them. We request an increased police presence at the Staten Island Mall and additional mall security and their K-9 Unit, especially during the holiday season.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The opioid epidemic continues to escalate in Staten Island. There has been an increase in the number of drugged driving incidents. It is imperative to increase the number of Drug Recognition Agents for Staten Island. These agents are specially trained and certified to recognize and identify drugged drivers. This will make our roads safer and enhanced prosecution in drug cases.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/16
FDNY
Provide new
The purchase of a MARR-1 Vehicle will allow
facilities such as a
mutual aid response in the event of a mutual
firehouse or EMS
aid activation.FDNY hold mutual aid
station
agreements in the event of an emergency,
catastrophic event or disaster. FDNY EMS
Operations serves as the primary coordinator
for all mutual aid activation provided under
agreements by Volunteer, Voluntary Hospitals,
NYS Mobilization Plan, Nassau County, New
Jersey, Suffolk County and the REMSCO Regional
Plan. The purchase of a MARR-1 supports
several goals and objectives in the FDNY related
to enhancing regional capabilities, EMS service
tiered response, coordination, mutual aid,
public health readiness and enhancing incident
management and response capabilities.
2/16
FDNY
Provide new
Bariatric ambulances are in service in the
emergency vehicles,
boroughs of Brooklyn and Queens. Significant
such as fire trucks or
population of medical calls in addition to
ambulances
Brooklyn and Queens requiring bariatric
response transport are in Manhattan and the
Bronx. In order to provide timely bariatric
response the FDNY needs additional bariatric
ambulances apparatus to the boroughs of
Manhattan and the Bronx. Additional bariatric
ambulances will support FDNY goals and
objectives related to challenges bariatric
patients pose for pre-hospital care and
transport directly affecting patient outcomes.
3/16
FDNY
Provide new
Purchase new brush fire unit vehicles. Four of
emergency vehicles,
the vehicles are out of date and unreliable.
such as fire trucks or
ambulances
4/16
FDNY
Rehabilitate or
Fire houses 155, 167, 158 and 161 need new
renovate existing
doors.
fire houses or EMS
stations
5/16
FDNY
Provide new
We request that NYC proved a designated space
57 Cleveland
emergency vehicles,
for a FDNY satelite training facility to support
Place, Staten
such as fire trucks or
ongoing training for EMT's and paramedics.
Island, New
ambulances
NYC recently acquired a 7-acre property (former
York, NY
St. John Villa Academy) in Staten Island
earmarked for the Department of Education. In
addition to being used as a training facility, it
would serve the Staten Island Community as
classroom space for community residents to
take the free FDNY CPR training courses.
6/16
FDNY
Provide new
Provide funding for the purchase of a new NYC
460 Brielle
emergency vehicles,
Fire Department Major Emergency Response
Avenue
such as fire trucks or
Vehicle (MERV 5). The MERV (Major Emergency
ambulances
Response Vehicle) is assigned to all major
medical emergencies within its borough, it is
capable of permitting several patients to be
treated in one place. This unit seats 14 and has
a stretcher. ALS and BLS functions may be
performed on this unit, anything from minor
injuries to a cardiac arrest.it can treat 3 patients
on stretchers at once. Essentially, it's an
emergency room on wheels. It saves lives.
9/16
FDNY
Provide new
Provide funding to equip all new ambulances
emergency vehicles,
with power-lift capability.
such as fire trucks or
ambulances
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
1/20
FDNY
Other FDNY facilities
and equipment requests (Expense)
Squad Companies in the FDNY use Engine style
apparatus but also carry specialized equipment. These companies serve dual purposes. In their normal 1st alarm area, they respond as an engine company, either first, second or third due. Their duties are the same as any other engine assigned to an alarm. In other than their first alarm area, the Squads are assigned as a special unit, and the incident commander assigns them tasks on the fire ground. These tasks can be either engine or truck company related. If the IC decides that the engine companies need help stretching lines or an additional handline is needed, the Squad can be assigned this task. If the IC decides that vertical ventilation is needed, the Squad can be assigned to perform or augment the roof top ventilation.
4/20
NYPD
Assign additional uniformed officers
Assign additional Drug Recognition Experts to decrease the number of drugged driving incidents.
19/20
NYPD
Assign additional crossing guards
Assign additional Crossing Guard for PS 60, Alice Austen R60
55 Merrill Avenue
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Staten Island Community Board 2
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Sewer capacity
Many sites within the West Shore are encumbered by tidal and fresh water wetland issues, as well as poor drainage systems and a lock of sewers. Advocating and securing the City of New York’s commitment to install proper drainage systems and sewers is imperative to the successful operation of all businesses in the area. Lack of adequate drainage and standing water remain pervasive and recurrent problems. To date, property owners have not been able to even get septic tanks due to the proximity of the protected wetlands to some property. While one industrial business in the area does own its own sewage treatment plant, the others do not, and this may therefore be another option to explore. Property owners and community stakeholders agree that installing sewers in the West Shore will enhance curb appeal, increase property value, attract new tenants to vacant land, and assist the industrial businesses to better serve their customers. The West Shore may also be a candidate for the City of New York’s upcoming street storm water pilot projects that enhance storm water catchment and reduce impact on combined sewage overflows (CSOs). The streets within the West Shore are ideal candidates for these pilot projects because: many streets are routinely flooded during storm events due to the large number of wetlands and tributaries surrounding a very low-lying system; many of the streets do not have sidewalks, trees, or other infrastructures that would need to be installed for a pilot program; therefore no retrofitting is required. Any minor retrofitting that would be necessary would not have a significant impact given that the roads are not currently over- utilized; and many of the roads and sites lack current street drainage infrastructure, and are therefore solid candidates for storm water run-off reduction strategies that could reduce capital costs for future road infrastructure development.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
There is a critical need for infrastructure improvements which includes a new sanitary sewer pump station, new sanitary sewers feeding the pump station as well as storm sewers and storm-water management- possibly including a Bluebelt-like storm water management system to work with the existing wetlands in the area. There is a great need for catch basins to be cleaned out regularly to prevent blockage and pollutants from entering our stormwater drainage system.
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
17/20
DEP
Investigate air
CB2 would like the DEP to monitor excessive
2800 Victory
quality complaints
engine idling. An hour of automobile idling
Boulevard
at specific location
burns approximately one-fifth of a gallon of gas
and releases nearly 4 pounds of CO2 into the air.
Excessive amounts of CO2 in the atmosphere
can contribute to asthma, difficulty in breathing,
decreased lung function, exacerbate
cardiovascular problems and lead to chronic
bronchitis.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Staten Island Community Board 2
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Small Business services/support
Community Board 2 was happy about the City Council’s passage of the New Dorp Business Improvement District in April 2017. We are grateful to Council Member Matteo for his vision and proposal to form a Business Improvement District in the New Dorp section of Staten Island, and to the Staten Island Economic Development Corporation and local merchants for their partnership in this endeavor. New Dorp Lane is one of the busiest commercial centers on Staten Island. New Dorp is a shopping district that features coffee shops, restaurants, jewelry stores, clothing boutiques, spas and several other retail establishments. It is served by the New Dorp train station and several MTA bus routes. The Business Improvement District contains 146 properties and 180 businesses. Hundreds of families enjoy activities such as the New Dorp Weekend Walk, New Dorp Lane Concert Series, the Annual Car Show, Restaurant Crawl, Holiday Tree Lighting and more. The lack of street parking in the area is an issue. Community Board 2 requests a comprehensive parking plan study within the boundaries of the New Dorp Business Improvement District to determine the current and future demand of parking, and recommendations and actions that can be taken to meet the projected demand during busy seasons to ensure the continued success of the BID and economic well being of the community.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
No comments
Needs for Economic Development
The NYC Economic Development Corporation has developed an Industrial Business Improvement District within the proposed “Green Zone” on the West Shore of Staten Island. The West Shore was designated as an Opportunity Zone and further designated within the same boundaries of the proposed, larger Green Zone on the West Shore of Staten Island. Over time, the WS-IBID plans to grow into one of the most successful and sustainable industrial corridors in the tri-state area. Public infrastructure, including sewers, drainage, and roads, need fixing. Without these upgrades, the West Shore Industrial Business Improvement District will not be able to sustain a current business, nor will the district be able to grow and attract new business over time. Many streets in the Green Zone are in dire need of improvement. It was specifically requested that New York City Department of Environmental Protection provide a scope for a ten-year plan that phases in the necessary sewage pump station(s) sanitary sewers and storm sewer necessary to carry out the development goals of the NYCEDC based on current approved drainage plans of DEP. Should it be determined that there is a further benefit to implement drainage plan modifications to include
Bluebelt-type stormwater management to carry out the mayor’s green infrastructure goals, we could suggest streets that should be included in the plans. Listed below are streets located within the boundaries of the Green Zone that are in dire need of improvement.
Streets located within the boundaries of the Green Zone that are in dire need of improvement. Gulf Avenue between 5th Street and Edward Curry Avenue;
Bloomfield Avenue between Gulf Avenue and Chelsea Road; Edward Curry Avenue between Gulf Avenue and Chelsea Road; Chelsea Road between Bloomfield Avenue and South Avenue;
South Avenue between Chelsea Road and Meredith Avenue; The entirety of Industry Road;
The entirety of Spencer Street Meredith Avenue from the northern limit to the West Shore Expressway overpass.
Without infrastructure improvements to streets within the district, the West Shore will not be able to grow to its potential.
Many sites on the West Shore are encumbered by tidal and freshwater wetland issues, as well as poor drainage systems and a lack of sewers. Advocating and securing the City of New York’s commitment to install proper drainage systems and sewers is imperative to the successful operation of all businesses in the area. Lack of adequate drainage and standing water remain pervasive and recurrent problems. Sewers and Drainage: Listed below are properties that need sewer installation and drainage improvements: Block 2810; Lots: 14, 47,59, 80, 96, 98, 102
Block 1750; Lot: 215 Block 1760; Lots: 46, 110, 115, 116, 200, 250, 255, Block 1780; Lots: 22, 57, 80, 85, 92, 151,
160, 164, 186, 200, 240, 250, 270, 298, Block 1801; Lots: 1, 6, 10, 20, 25, 27, 30, 31, 35, 75, 100, 150, 155, 160, 181,
Block 1815; Lots: 175, 181, 191, 192, 199, Block 1850; Lots: 160, 180, 190, 260, Block 2810 Lot: 98.
To date, property owners have not been able to even get septic tanks due to the proximity of the protected wetlands to some property. While one industrial business in the area does own its own sewage treatment plant, the others do not, and this may be another option to explore. Property owners and community stakeholders agree that installing sewers in the West Shore will enhance curb appeal, increase property value, attract new tenants to vacant land, and assist the industrial businesses to better serve their customers. Many streets on the West Shore are routinely flooded during storm events due to a large number of wetlands and tributaries surrounding a very low- lying system. Many of the streets do not have sidewalks, trees, or other infrastructures and lack street drainage. As the west shore looks to the future, it is imperative that the current business owners cease to be encumbered by the tidal, freshwater wetland, and sewage/drainage issues. The uncertainty of the impact by and on the wetlands represents a significant development/redevelopment risk. CB2 and the West Shore community believe that there is an opportunity to work with the city, state and regulatory agencies.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
10/16 EDC Invest in capital
projects to improve access to the waterfront
Provide funding for additional ferry service from St. George to Bay Ridge Brooklyn & DUMBO. The connections between the boroughs which are separated by a $19 toll and an hour or more commute would provide incalculable benefits to the residents and economies of these two boroughs.
Expense Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
TRANSPORTATION
Staten Island Community Board 2
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
It is imperative that commuters ease the already overburdened Staten Island roads and travel more expediently by water. OMB approved a cost limitation of $6million for the purchase of ferries for the expansion of the East River Ferry Service citywide. The service will consist of 5 new ferry routes and Staten Island, the borough which heavily depends on ferry transportation, has not received additional service. Community Board 2 is requesting Ferry Service from St. George to Bay Ridge Brooklyn & DUMBO. The connection between these boroughs, which are currently separated by a $19 toll could provide incalculable benefits to the residents and economies of these boroughs. This connection will improve connectivity, provide access to workforce opportunities, reduce wear and tear on roads and boost local businesses. DUMBO is home to emerging job hubs, strong academic institutions, and cultural institutions. The commute time between St. George, Staten Island and DUMBO takes approximately one hour and requires multiple transfers between the ferry and trains. A direct line could reduce travel time and alleviate overcrowding on subways.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Traffic congestion and mobility continue to be the district's top problem and as the population grows, our ability to move on and off throughout the Island has become difficult at best, and at times nearly impossible. Our roadways consist of two-lane country roads (one lane in each direction) with an antiquated traffic signal system that needs to be upgraded. We need to address present and future traffic congestion and reliability problems, which are expected to worsen in the future.
The HOV lane extension project which was completed allows cars with three or more passengers to travel in the lane between Victory Boulevard and the Verrazzano Bridge. Community Board 2 expressed our support to NYSDOT for extending the lane all the way west to the Goethals Bridge. We are certain that extending the HOV lane all the way to the Goethals Bridge would reduce congestion and improve mobility. Changes must be made to make travel on the already over-burdened Staten Island Expressway less crowded and easier to traverse for drivers. Community Board 2 is requesting ferry service from St. George to Bay Ridge, Brooklyn and DUMBO. The connection between these great boroughs, which are currently separated by a $19 toll and an hour or more commute would provide incalculable benefits to the residents and economies of these two boroughs.
Needs for Transit Services
MTA is more than $14 billion short in its $32 billion capital program for 2015-2019. This impacts the quality of transit services for Staten Islanders. A major issue regarding transit service is the complete lack of connectivity to surrounding airports. In Queens, there are four buses available for residents to access LaGuardia Airport. An overwhelming majority of Staten Island residents who fly go through Newark Airport. Residents taking public transportation to Newark airport are required to go through Penn Station or Port Authority Bus Terminal; a commute that is likely over two hours long. Community Board 2 continues to support the development of a West Shore Light Rail system. The West Shore of Staten Island is on its way to becoming Island's Business Hub. Soon, it will be home to an 855,000 square-foot Amazon Fulfillment Center, that will employ 2,250 people as well as 975,000 square-foot IKEA warehouse distribution center that will create another 300 jobs. Furthermore, the Nicotra Group is constructing a 330,000 square foot Century Office Building on Staten Island's Teleport Campus. These huge construction projects will create more vehicles and trucks traversing the West Shore Expressway. A West Shore Light Rail system could provide a reliable and attractive travel choice for Staten Island residents located in South Shore and Mid-Island communities. The light rail is an electric system able to operate single or multiple car train sets along the shore or exclusive rights-of-way. The WSLR would extend New Jersey Transit's Hudson-Bergen Light Rail system (HBLRT) over the Bayonne Bridge and into western and southern portions of Staten Island and connect to SIRTOA
service at the Richmond Valley Station. The benefits of Light Rail are: Trips are diverted from congested roadways, saves travel time, improves reliability, and increases property values near stations. SIEDC estimates that the area will be home to 65,000 new residents by 2030.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
16/16
DOT
Reconstruct streets
Request funding to extend Father Capodanno
Father
Boulevard from Midland Beach to at least Ebbits
Capodanno
Street. This would allow motorists to continue
Blvd Midland
on Father Capodanno Boulevard to alleviate
Beach Ebbits
congestion on Hylan Boulevard from Midland
St
Avenue to Ebbitts Street. An alternate route is
needed to help alleviate congestion for our
residents.
CS
DOT
Other
Improve Richmond Road from Todt Hill Road to
Richmond
transportation
Amboy Road (HWRER99)
Road Todt Hill
infrastructure
Road Amboy
requests
Road
CS
DOT
Reconstruct streets
Implement roadway reconstruction on Manor
Manor Road
Road between Brielle Avenue and Rockland
Brielle
Avenue to eliminate hazardous curves.
Avenue
Rockland
Avenue
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
6/20
DOT
Provide new traffic
Provide funding to purchase new models of
or pedestrian
accessible pedestrian signals that come with a
signals
button that has an adjustable locator tone to
help people find it, a tactile arrow that helps
people feel the button and guide them to the
crosswalk, an audible message that indicates
when the "Walk" signal is on and what street
the person is crossing. The crossing tone sounds
until the flashing "Don't Walk" signal comes
on.for additional Audible Signals to help the
blind navigate streets. Refer to DOT for best
locations.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Staten Island Community Board 2
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Library facilities and access
Currently, the NYPL's operational funding enables them to be a stable and consistent resource for all New Yorkers; opening their doors at minimum six days per week and offering high quality and diverse programming. The NYPL seeks to maitain their expense funding and request appropriate funding for the expansion of libraries, services, and collections. This is particularly more important now that more people rely on their services from early literacy programming to ESOL classes for immigrants and story times for homeless families. The libraries need additional funding to ensure that their branches can continue to meet the growing needs of our communities.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
We would like an increase in funding for seasonal staffing at the NYC Department of Parks and Recreation. Seasonal staff assist in general maintenance work, including lawn mowing, edging, seeding, snow removal, cultivating, fertilizing, sod laying and hedge trimming, sweeping and raking of litter and emptying of receptacles. As we have mentioned previously, litter is an ongoing issue and seasonal staff can reduce the amount of litter. Seasonal staff is also responsible for cleaning and maintaining facilities including comfort stations and is responsible for performing safety checks on facilities and equipment.
Needs for Cultural Services
The Jacques Marchais Museum of Tibetan Art was established in 1945 to promote a greater understanding and appreciation of Tibetan art and culture. The Museum presents a permanent historic display as well as temporary changing exhibitions. The Museum also presents an on-going calendar of public events including lectures, films, tai chi classes, and school visits. They welcome approximately 5,000 visitors per year, half of which are foreign tourists. The buildings that house the Tibetan Museum are the oldest examples of Himalayan style architecture in the United States and they were designed so that visitors could appreciate the art in a contextual setting.The Jewish Community Center of Staten Island is one of the largest social service agencies in the borough. For nearly 90 years, the JCC has been assisting individuals reach their fullest potential regardless of limited resources or abilities, age, gender, ethnicity or religion. They operate four sites and their programs and services support over 40,000 people, including over 8,000 youth. The JCC’s major initiatives include education/literacy, advocacy, healthcare/wellness, social and support services, emergency response and preparedness, community organizing and family engagement. The JCC would like funding to continue such programs as Rosemary’s Place for those with Alzheimer’s and dementia related illnesses, Sunrise Day Camp- a very unique program for children with cancer and their siblings, their Adult Education Department to help prepare the Immigrant Community for the TASC exam and help them earn their HSE diplomas, an afterschool program which also implements STEAM activities so that Staten Island children are able to achieve success not only in the classroom but in their adulthood, as well as their Senior Adult programs, which gives social, recreational, cultural and educational activities to senior adults over the age of sixty as well as a hot, nutritious meal in a safe environment that allows them to actively engage with others.
The GRACE Foundation is committed to supporting, educating, and enhancing the quality of life for children/adults and their families impacted by Autism Spectrum Disorder (ASD), which is a neurological disorder that impacts the development of language and communication skills, as well as social interaction and relatedness. Each person with ASD is unique and requires individualized guidance and support, and there are no racial, ethnic or social boundaries in the diagnosis of ASD. The GRACE Foundation realized that, while awareness has increased over the past few decades as to what exactly is Autism, it does not make up for the absence of acknowledgement, inclusion and action on the part of those who have the power to improve, provide and create opportunity. Those diagnosed with
ASD need not only their family’s help, but also the community’s to build safe, productive and supportive spaces where they can learn in the way that best suits their individual capabilities, in a warm environment surrounded by those that understand them.
The GRACE Foundation would like to receive funding so that they can expand their building and with it their commitment to supporting individuals with ASD and their families by adding a functional art lab, recording studio, photography studio, quiet sensory room, dance and yoga room, and private space for the growing Day Habilitation program.
The Jewish Community Center of Staten Island is one of the largest social service agencies in the borough. For nearly 90 years, the JCC has been assisting individuals reach their fullest potential regardless of limited resources or abilities, age, gender, ethnicity or religion. They operate four sites and their programs and services support over 40,000 people, including over 8,000 youth. The JCC’s major initiatives include education/literacy, advocacy, healthcare/wellness, social and support services, emergency response and preparedness, community organizing and family engagement. The JCC would like funding to continue such programs as Rosemary’s Place for those with Alzheimer’s and dementia related illnesses, Sunrise Day Camp- a very unique program for children with cancer and their siblings, their Adult Education Department to help prepare the Immigrant Community for the TASC exam and help them earn their HSE diplomas, an afterschool program which also implements STEAM activities so that Staten Island children are able to achieve success not only in the classroom but in their adulthood, as well as their Senior Adult programs, which gives social, recreational, cultural and educational activities to senior adults over the age of sixty as well as a hot, nutritious meal in a safe environment that allows them to actively engage with others.
Meals on Wheels is a vital service for over 130 recipients who receive two meals daily. They emphasize the importance of the daily contact between the deliverer and meal recipient to monitor, on a daily basis, the well- being of their clients and includes partnering with twenty-one programs to service the special needs community whose consumers assist in delivering meals, assembling mailings or with packaging meals in the kitchen. We would like the funding for this organization to be continued so that they will be able to continue to serve the residents of Staten Island who are and will be in need of their services.
Needs for Library Services
City funding for libraries has been cut by nearly 20% over the past decade and library staff has been reduced by more than 1,000 workers. The NYPL libraries within CB2 (Staten Island) are used extensively. The community relies on them to provide essential library services, as well as educational programs and community space. Many of the library locations are in need of critical upgrades, including mechanical systems, bathrooms, roofs, facades, and ADA upgrades. The three library systems are seeking a restoration of $65 million in expense funding and the inclusion
$1.4 billion in the City’s 10-Year Capital Strategy. This capital funding is needed for renovations, critical maintenance, elevator replacement when necessary, heating and cooling systems, ADA compliance and technology upgrades. The funding is essential, as the libraries are especially important to low and moderate income residents who depend on the libraries for access to books, internet access, job search, and film, while also acting as a quiet place to read, do homework, or other work. Currently, the operational funding enables our libraries to be a stable and consistent resource for all New Yorkers, opening their doors at minimum six days per week and offering high-quality and diverse programming. We seek to increase operating funding for our libraries to expand to 7-day services. Currently, only 15 of the city's libraries are open 7 days a week. Increased funding will ensure that at least one branch in every Council District is open 7 days. This is particularly important at this time, when more people than ever rely on library services, from early literacy to ESOL classes for immigrants and story times for homeless families.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
8/16
NYPL
Provide more or
Provide capital funding to equip Staten Island
better equipment to
libraries with security cameras inside and out to
a library
ensure these "safe havens" remain secure.
14/16
DPR
Reconstruct or
Renovate Willowbrook Park with new apparatus
1 Eton Place
upgrade a park or
such as ramped play equipment, universally
amenity (i.e.
acceptable swings, and charcoal barbecue grills.
playground, outdoor
Willowbrook Park's Carousel, picnic grounds,
athletic field)
and ballfield attract many families and an
upgrade would enhance one of Staten Island's
most popular Greenbelt parks.
CS
DPR
Improve access to a
Community Board 2 continues to support the
park or amenity (i.e.
request to open up the road system in Fresh Kills
playground, outdoor
Park, which would connect Richmond Avenue to
athletic field)
the West Shore Expressway through Nascent
Park. The plan includes a four-lane road that
would stem from the Yukon Avenue intersection
at Richmond Avenue and traverse the East Park.
This would help ease traffic in the surrounding
community.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
5/20 DPR Enhance park safety
through more security staff (police or parks enforcement)
Provide additional funding for security staffing (PEP) officers. This would ensure the safety of visitors to our parks.
image
7/20 DPR Other street trees
and forestry services requests
Community Board 2 is requesting additional funding to hire additional personnel to remove the backlogged thousands of open tree stumps. Tree stumps are dangerous, especially for children and our senior population. They also attract pests and critters.
image
8/20 DPR Forestry services,
including street tree maintenance
Community Board 2 is requesting additional funding to hire additional personnel for street tree maintenance. It is important to maintain trees to keep the people around it safe. A dead branch can fall from a tree at any time, endangering nearby people, buildings, and power lines.
image
9/20 DCLA Support nonprofit
cultural organizations
Continue to fund our cultural establishments so every Staten Island resident has access to arts and culture.
image
16/20 NYPL Extend library hours
or expand and enhance library programs
Increase funding to hire additional library staff to accommodate the increase in attendance.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
2/20
Other
Other expense
Fund supplies for requested EMS Academy.
budget request
10/20
Other
Other expense
DFTA - Increase funding for services to older
budget request
adults including personal and home care,
transportation services, meals-on-wheels, senior
congregate care meal programs and case
managers
11/20
Other
Other expense
Meals on Wheels is a vital service for over 130
budget request
recipients who receive two meals daily. They
emphasize the importance of the daily contact
between the deliverer and meal recipient to
monitor, on a daily basis, the well-being of their
clients and includes partnering with twenty-one
programs to service the special needs
community whose consumers assist in
delivering meals, assembling mailings or with
packaging meals in the kitchen. We would like
the funding for this organization to be
continued so that they will be able to continue
to serve the residents of Staten Island who are
and will be in need of their services.
12/20
Other
Other expense
Community Agency for Senior Citizens (CASC), is
budget request
an invaluable resource for seniors at risk and
their caregiving families. CACS provides support
in Case Management, Crime Victims Assistance,
Elder Abuse, transportation and more. CASC is a
comprehensive local resource to help navigate
the senior services, agencies, resources and
options on Staten Island.
13/20
Other
Other expense
There are 77,000 older persons who currently
budget request
reside in Staten Island. There are only 25 funded
DFTA Senior Services groups or organizations for
over 77,000 older persons. Please consider
additional funding to meet the needs of the
older population.
14/20
Other
Other expense budget request
DFTA - Expand the NYC Department for the Aging Geriatric Mental Health (DGMH), a clinical mental health program lodged in a number of senior centers, and friendly visiting ThriveNYC initiatives.
15/20
Other
Other expense budget request
The Jewish Community Center of Staten Island. has specialized programs for persons struggling with dementia and early cognitive impairments. These programs provide an affordable alternative to institutional placement and in- home care.
1466 Manor Road, Staten Island, New York, NY
18/20
Other
Other expense budget request
DOT - Create painted mid-block crosswalks on Midland Avenue and Sand Lane to make it safe and convenient for pedestrians to cross.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/16
FDNY
Provide new
The purchase of a MARR-1 Vehicle will allow
facilities such as a
mutual aid response in the event of a mutual
firehouse or EMS
aid activation.FDNY hold mutual aid
station
agreements in the event of an emergency,
catastrophic event or disaster. FDNY EMS
Operations serves as the primary coordinator
for all mutual aid activation provided under
agreements by Volunteer, Voluntary Hospitals,
NYS Mobilization Plan, Nassau County, New
Jersey, Suffolk County and the REMSCO Regional
Plan. The purchase of a MARR-1 supports
several goals and objectives in the FDNY related
to enhancing regional capabilities, EMS service
tiered response, coordination, mutual aid,
public health readiness and enhancing incident
management and response capabilities.
2/16
FDNY
Provide new
Bariatric ambulances are in service in the
emergency vehicles,
boroughs of Brooklyn and Queens. Significant
such as fire trucks or
population of medical calls in addition to
ambulances
Brooklyn and Queens requiring bariatric
response transport are in Manhattan and the
Bronx. In order to provide timely bariatric
response the FDNY needs additional bariatric
ambulances apparatus to the boroughs of
Manhattan and the Bronx. Additional bariatric
ambulances will support FDNY goals and
objectives related to challenges bariatric
patients pose for pre-hospital care and
transport directly affecting patient outcomes.
3/16
FDNY
Provide new
Purchase new brush fire unit vehicles. Four of
emergency vehicles,
the vehicles are out of date and unreliable.
such as fire trucks or
ambulances
4/16
FDNY
Rehabilitate or
Fire houses 155, 167, 158 and 161 need new
renovate existing
doors.
fire houses or EMS
stations
5/16
FDNY
Provide new
We request that NYC proved a designated space
57 Cleveland
emergency vehicles,
for a FDNY satelite training facility to support
Place, Staten
such as fire trucks or
ongoing training for EMT's and paramedics.
Island, New
ambulances
NYC recently acquired a 7-acre property (former
York, NY
St. John Villa Academy) in Staten Island
earmarked for the Department of Education. In
addition to being used as a training facility, it
would serve the Staten Island Community as
classroom space for community residents to
take the free FDNY CPR training courses.
6/16
FDNY
Provide new
Provide funding for the purchase of a new NYC
460 Brielle
emergency vehicles,
Fire Department Major Emergency Response
Avenue
such as fire trucks or
Vehicle (MERV 5). The MERV (Major Emergency
ambulances
Response Vehicle) is assigned to all major
medical emergencies within its borough, it is
capable of permitting several patients to be
treated in one place. This unit seats 14 and has
a stretcher. ALS and BLS functions may be
performed on this unit, anything from minor
injuries to a cardiac arrest.it can treat 3 patients
on stretchers at once. Essentially, it's an
emergency room on wheels. It saves lives.
7/16
SCA
Provide technology
Provide funding for security cameras at Staten
485 Clawson
upgrade
Island Technical High. It is the only public high
Street
school on the island that doesn't have them.
This is a priority that needs to be addressed
especially in these unsafe times.
8/16
NYPL
Provide more or
Provide capital funding to equip Staten Island
better equipment to
libraries with security cameras inside and out to
a library
ensure these "safe havens" remain secure.
9/16
FDNY
Provide new
Provide funding to equip all new ambulances
emergency vehicles,
with power-lift capability.
such as fire trucks or
ambulances
10/16
EDC
Invest in capital
Provide funding for additional ferry service from
projects to improve
St. George to Bay Ridge Brooklyn & DUMBO.
access to the
The connections between the boroughs which
waterfront
are separated by a $19 toll and an hour or more
commute would provide incalculable benefits to
the residents and economies of these two
boroughs.
11/16
HHC
Provide a new or
Fund the development of a Staten Island Health
460 Brielle
expanded health
and Wellness Campus on the grounds of Sea
Avenue
care facility
View Hospital Rehabilitation Center and Home,
which would also include housing and services
for seniors and the disabled.
12/16
DFTA
Create a new senior
Provide additional funding in the budget to
460 Brielle
center or other
rehabilitate the vacant buildings on the campus
Avenue
facility for seniors
of Sea View Hospital Rehabilitation Center and
Home. There are approximately 40 buildings
and less than half are currently being used.
13/16
SCA
Renovate or
Install central air-conditioning units in PS 54. As
1060
upgrade an
early as late spring into early summer,
Willowbrook
elementary school
classroom temperatures rise as high as in the
Road, Staten
upper 90's. This is unacceptable working
Island
conditions for students,as well as teachers.
14/16
DPR
Reconstruct or
Renovate Willowbrook Park with new apparatus
1 Eton Place
upgrade a park or
such as ramped play equipment, universally
amenity (i.e.
acceptable swings, and charcoal barbecue grills.
playground, outdoor
Willowbrook Park's Carousel, picnic grounds,
athletic field)
and ballfield attract many families and an
upgrade would enhance one of Staten Island's
most popular Greenbelt parks.
15/16
SCA
Renovate interior
The New Dorp High School east gymnasium
465 New
building component
requires an upgrade. The upgrade would
Dorp Lane
include painting, refinishing the floor, repairing
light fixtures, and installing a digital scoreboard
and collapsible bleachers.
16/16
DOT
Reconstruct streets
Request funding to extend Father Capodanno
Father
Boulevard from Midland Beach to at least Ebbits
Capodanno
Street. This would allow motorists to continue
Blvd Midland
on Father Capodanno Boulevard to alleviate
Beach Ebbits
congestion on Hylan Boulevard from Midland
St
Avenue to Ebbitts Street. An alternate route is
needed to help alleviate congestion for our
residents.
CS
DPR
Improve access to a
Community Board 2 continues to support the
park or amenity (i.e.
request to open up the road system in Fresh Kills
playground, outdoor
Park, which would connect Richmond Avenue to
athletic field)
the West Shore Expressway through Nascent
Park. The plan includes a four-lane road that
would stem from the Yukon Avenue intersection
at Richmond Avenue and traverse the East Park.
This would help ease traffic in the surrounding
community.
CS SCA Renovate or upgrade a middle or intermediate school
Install air-conditioning units in all public schools on Staten Island. Most high schools and elementary schools have air-conditioners, but few intermediate schools are air-conditioned. As early as late spring into early summer, classroom temperatures rise as high as in the upper 90's. This is unacceptable working conditions for our teachers, as well as students.
image
CS DOT Other transportation infrastructure requests
Improve Richmond Road from Todt Hill Road to Amboy Road (HWRER99)
Richmond Road Todt Hill Road Amboy Road
image
CS DOT Reconstruct streets Implement roadway reconstruction on Manor
Road between Brielle Avenue and Rockland Avenue to eliminate hazardous curves.
Manor Road Brielle Avenue Rockland Avenue
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/20
FDNY
Other FDNY facilities
Squad Companies in the FDNY use Engine style
and equipment
apparatus but also carry specialized equipment.
requests (Expense)
These companies serve dual purposes. In their
normal 1st alarm area, they respond as an
engine company, either first, second or third
due. Their duties are the same as any other
engine assigned to an alarm. In other than their
first alarm area, the Squads are assigned as a
special unit, and the incident commander
assigns them tasks on the fire ground. These
options on Staten Island.
13/20
Other
Other expense
There are 77,000 older persons who currently
budget request
reside in Staten Island. There are only 25 funded
DFTA Senior Services groups or organizations for
over 77,000 older persons. Please consider
additional funding to meet the needs of the
older population.
14/20
Other
Other expense
DFTA - Expand the NYC Department for the
budget request
Aging Geriatric Mental Health (DGMH), a
clinical mental health program lodged in a
number of senior centers, and friendly visiting
ThriveNYC initiatives.
15/20
Other
Other expense
The Jewish Community Center of Staten Island.
1466 Manor
budget request
has specialized programs for persons struggling
Road, Staten
with dementia and early cognitive impairments.
Island, New
These programs provide an affordable
York, NY
alternative to institutional placement and in-
home care.
16/20
NYPL
Extend library hours
Increase funding to hire additional library staff
or expand and
to accommodate the increase in attendance.
enhance library
programs
17/20
DEP
Investigate air
CB2 would like the DEP to monitor excessive
2800 Victory
quality complaints
engine idling. An hour of automobile idling
Boulevard
at specific location
burns approximately one-fifth of a gallon of gas
and releases nearly 4 pounds of CO2 into the air.
Excessive amounts of CO2 in the atmosphere
can contribute to asthma, difficulty in breathing,
decreased lung function, exacerbate
cardiovascular problems and lead to chronic
bronchitis.
18/20
Other
Other expense
DOT - Create painted mid-block crosswalks on
budget request
Midland Avenue and Sand Lane to make it safe
and convenient for pedestrians to cross.
19/20
NYPD
Assign additional
Assign additional Crossing Guard for PS 60, Alice
55 Merrill
crossing guards
Austen R60
Avenue
20/20 DOHMH Reduce rat
populations
Increase DOHMH funds to cut down on the rat population. There has been thousands of rat sightings on Staten Island in recent years.
However Staten Island is was not part of Mayor Bill de Blasio's $32 million plan to cut down on the rodent infestation problem in 2017. As we all know, Rats have the potential to spread a wide variety of diseases. They tend to live in environments such as drains, sewers, and rubbish where germs can be found. These germs can then be spread wherever rats go by way of their fur, feet, urine or droppings. The main diseases of concern are Weils disease. Rats can also damage property by gnawing at wood, lead and soft metals, electrical wiring, water pipes, and drainage systems.
image

