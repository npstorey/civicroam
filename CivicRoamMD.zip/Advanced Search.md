- Page Type:: [[__About__]]
- There are two levels of advanced search.
    1. Use the search bar in [civic.roam.garden](https://civic.roam.garden/) domain to search the full text of all documents in Civic Roam.
    2. Use the [[#tags]] page directly from the [Civic Roam Research Graph](https://roamresearch.com/#/app/Civic/page/TKghSZzQ6) to perform advanced filtering of searches of the full text of all documents in Civic Roam.
        - To add a tag [submit a request here.]([[Suggest]])
