- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 1 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1tkh4US9F1hVQnFZf7jh86-vJf0D8XjyB/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1tkh4US9F1hVQnFZf7jh86-vJf0D8XjyB/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
1
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 1
image
Address: 435 Graham Avenue, First Floor Phone: (718) 389-0009
Email: bk01@cb.nyc.gov
Website: www.nyc.gov/brooklyncb1
Chair: Dealice Fuller District Manager: Gerald Esposito
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
BROOKLYN COMMUNITY BOARD NO. 1 STATEMENT OF COMMUNITY DISTRICT NEEDS FISCAL YEAR 2021 Pursuant to
the requirements of the New York City Charter, Brooklyn Community Board No. 1 (Greenpoint/Williamsburg) submits its Statement of Community District Needs for the upcoming year. It is our hope that the items identified in this document will be given priority consideration by the City of New York in order to further enhance the development of a cooperative planning process and insure an improvement in the quality of life for all of our residents. OVERVIEW The wave of 2009 (a Tsunami) continues to impact our community. Not just a wave of destruction, but multiple waves of construction. The flood waters have not receded. Some construction worksites are still stalled or abandoned. The undertow of these thunderous waves continues to negatively impact the lives of the residents of Greenpoint-Williamburg and will effect generations to come. This tide of grief has already created a climate of highly inflated rents, denied lease renewals to both residential and commercial tenants, and a forced exodus of longtime commercial tenants into less desirable areas and even out of state. Now, complicating the equation even more, we are faced with distressed and abandoned work sites and condo prices which are out of touch with today’s market. And the erosion of the existing community has not stopped there! Like the construction of the Brooklyn Queens Expressway in the 1940’s which split communities and demolished the Mt. Carmel Cathedral (for the so called betterment of the transportation network) this continuing pounding of the wave destroys dreams for the homesteaders, the poor and middle/working class of this community – the people who chose to stay, when it was not trendy or chic. Without a guarantee of affordability they have been forgotten. And as the flood waters persist to move inland, the distillates of the 2005 Rezoning (notably opposed by CB 1) continue to swoop down upon our small stable communities and create havoc by demolishing our quaint existing structures, building upward (with units not affordable for our community) and straining our limited services and already overburdened antiquated infrastructure. The 2005 rezoning continues to be a “gift that keeps on giving” --- we are now facing pending construction of tower type “as of right” developments in Greenpoint (City Landing/Commercial Street) and in Williamsburg (the former Domino site). We ask that a councilmatic blue ribbon commission be formed to examine and evaluate the results of the 2005 rezoning. (CONTINUED SEE OUR STATEMENT OF DISTRICT NEEDS THAT HAS BEEN UPLOADED) (or see our website for the full 2021 Statement of District Needs: http://www.nyc.gov/html/bkncb1/html/home/home.shtml)
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 1
image
The three most pressing issues facing this Community Board are:
Affordable housing
Affordable housing in Community Board No. 1 is a top priority that must be addressed as a critical need. If our neighborhoods are to remain viable and attract/retain jobs and a stable work force, an adequate supply of decent and affordable housing must be available at various income levels. Community Board No. 1 generally supports the policies articulated by the City, that provides an unprecedented portion of City Capital Budget funding for housing in a manner that gives increased priority to the development of low and moderate income housing.
Land use trends (zoning, development, neighborhood preservation, etc.)
(The Following Is An Excerpt from our Statement of District Needs - please see the full statement for additional information) HOUSING Affordable housing in Community Board No. 1 is a top priority that must be addressed as a critical need. If our neighborhoods are to remain viable and attract/retain jobs and a stable work force, an adequate supply of decent and affordable housing must be available at various income levels. Community Board No. 1 generally supports the policies articulated by the City, that provides an unprecedented portion of City Capital Budget funding for housing in a manner that gives increased priority to the development of low and moderate income housing. As we have stated in previous years, three general principles must be incorporated into any equitable comprehensive housing plan: FIRST, those currently funded housing programs that have proven successful must be held harmless from the reduction in past federal assistance, even if an increased City Tax Levy contribution is required to achieve this end. SECOND, in allocating additional housing funds between the poor and middle class economic segments of our society, it is essential that the first priority be assigned to the poorest segment of our population, those who must bear the brunt of the housing crisis. However, we strongly support the need for affordable housing (both rental and home ownership) for all economic groups. THIRD, any additional housing funds must be allocated in a fair and equitable manner that responds to the most critical housing needs of each Community District, with a clear and largely advertised marketing throughout the district.
Senior services
SENIOR CITIZEN HOUSING We note that there is a great need for housing of the elderly and an increasing senior citizen population in Community Board No. 1 (over 20,000) remains of paramount concern. In the past, we have been successful in obtaining Section 202 (federal) funding for various senior housing developments in the district: Jennings Hall, Monsignor Vetro Houses, Metropolitan Houses, Monsignor Jarka Hall, Los Sures Senior Citizens Development, Dupont Street Mary D’Angelis Senior Housing) and Huron Street Senior Housing. We urge that similar efforts continue in Greenpoint/Williamsburg, with additional Section 202 sites submitted by private and City sources and evaluated by Community Board No. 1 prior to being recommended to the City. Where there is a shortage of senior citizen, assisted living housing, and nursing homes (a nursing home was targeted for construction at the former Greenpoint Hospital campus) in the district, we hope that the City will develop this targeted housing as promised by a previous administration. However, HPD has failed miserably in communicating with this Board. (CONTINUED IN FULL STATEMENT)
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 1
image
M ost Important Issue Related to Health Care and Human Services
Environmental health issues (noise, lead, respiratory illness, etc.)
RECENT HEALTH TRENDS Community Board No. 1 had ranked third out of the 59 districts citywide with a high number of asthma cases. Despite a city-wide drop in cases, our district still has a high rate. We remain concerned in any rise in cases of asthma in the district. Funds must be earmarked for additional testing, education and specialized treatment. Several years ago there was a CDC cancer and asthma study conducted in this District and we strongly support a new, updated study be carried out. In addition, the DEP ought to conduct a study of air and traffic pollution (which is particularly bad in our District) and their environmental and health impacts. We continue to support efforts by the Department of Health & Mental Hygiene, DEP and HPD to thwart lead poisoning as it is a very serious condition, especially for children. Children with lead poisoning may develop health, learning and behavior problems. Education about lead poisoning is important so that people can make their homes safe and healthy as well as learn about treatment and access to testing. Reports about AIDS in New York City have yielded the following figures for Community Board No. 1: the rates of new HIV diagnosis in Greenpoint and Williamsburg-Bushwick health districts range 0.50 & 1.30 per 1,000 persons/population. The combined rates for our district are above the rates for Brooklyn (0.68), New York City (0.84) and the US (1.14). Rates of people living with HIV & AIDS show Greenpoint at
5.5 and Williamsburg-Bushwick at 12.1 per 1,000 persons/population which again, is above the rates of Brooklyn (6.4), NYC (9.2) and US (3.2). We urge that the medical community continue addressing this grave disease and that additional programs be developed toward prevention, education and treatment. As the only New York City hospital within blocks of Community Board No. 1 Woodhull Hospital must be aggressive in addressing the needs of all of our constituents.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
(This is an excerpt from our 2021 Statement of District Needs - see the statement for full content) Health Services – Our district has serious health issues that must be addressed. CB 1 remains concerned about the delivery of health care services in the district and supports efforts for improvement. The top causes of death for residents of Greenpoint and Williamsburg, as for most New Yorkers, are heart disease and cancer. Death rates due to heart disease, flu and pneumonia, diabetes, stroke and liver disease are higher in Greenpoint and Williamsburg when compared to the City rates. Quality Health Care - A lack of quality health care can lead to negative health outcomes and more intensive treatment, such as avoidable hospitalizations. Access to health care is therefore a needed focus. About one in six adults in Greenpoint and Williamsburg has no health insurance, and one in eight goes without needed medical care. We urge continued funding for asthma patient care, research and education. We were pleased when a dental clinic (Williamsburg) was reopened to provide much needed services for youngsters in the district whose families do not have adequate financial means or insurance coverage, and were left dismayed that the clinic was again closed as a budget savings measure by HHC in 2010. We support any necessary funding to reopen and maintain the clinic within our district. The only dental clinic that offers free and affordable dental care is located in Woodhull Hospital, a facility not located in our district's confines. In addition, we urge that emerging health care need trends (such as access to health care, treatment and prevention of heart disease, psychological & mental illness treatment) be addressed. The Brooklyn Hospital/Mt. Sinai in its 2015 report relates that the burden of both asthma and hypertension have increased to 18% and 33% respectively in our district. (SEE FULL CONTENT IN THE STATEMENT OF DISTRICT NEEDS)
Needs for Older NYs
(The following is an excerpt from our full Statement of District Needs) SENIOR CITIZEN HOUSING We note that there is a great need for housing of the elderly and an increasing senior citizen population in Community Board No. 1 (over 20,000) remains of paramount concern. In the past, we have been successful in obtaining Section 202 (federal) funding for various senior housing developments in the district: Jennings Hall, Monsignor Vetro Houses, Metropolitan Houses, Monsignor Jarka Hall, Los Sures Senior Citizens Development, Dupont Street Mary D’Angelis Senior Housing) and Huron Street Senior Housing. We urge that similar efforts continue in Greenpoint/Williamsburg, with additional Section 202 sites submitted by private and City sources and evaluated by Community Board No. 1 prior to being recommended to the City. Where there is a shortage of senior citizen, assisted living housing, and nursing homes (a nursing home was targeted for construction at the former Greenpoint Hospital campus) in the district, we hope that the City will develop this targeted housing as promised by a previous administration. However, HPD has failed miserably in communicating with this Board. (SEE FULL STATEMENT OF DISTRICT NEEDS FOR CONTENT)
Needs for Homeless
(The following is an excerpt ) HOUSING FOR THE HOMELESS We continue to support and urge a continuation of the reduction in the census at the remaining temporary shelter at the former Greenpoint Hospital. The positive positions taken by the Community Board are well known to the City. We applaud the revised policy changes by the City and look forward to the eventual results, a reduction/elimination of the “warehousing” of the homeless in our Community District and throughout the City. Expensive temporary housing must be replaced with permanent low- rent housing, including housing for single individuals, in each Community District. We also urge the expansion of support services to identify and address individual medical/social needs of homeless individuals residing in city and private facilities HOMELESS SERVICES Community Board No. 1 approves the downsizing plan that decreased the census a the former Greenpoint Hospital Site, as the City has agreed to do at all other “armory” type shelters. We agree with the City’s decision to limit the overall census at any one site to 200 persons or less, and we hope that this number can be further reduced. In the past, Community Board No. 1 supported the development of compassionate and effective programs for the homeless. We share the City’s basic policy to provide shelter to those who request it and, in 1983 were the only Board in Brooklyn to positively respond to the Mayor’s appeal to suggest potential shelter sites. Our recommended location, the former Most Holy Trinity Convent, was initially identified as a shelter for homeless women, and subsequently opened as a model S.R.O. facility. We have supported this excellent private shelter administered by Most Holy Trinity Parish, and stand ready to assist the efforts of other local community groups to establish similar programs. The City should review regulatory policies toward private facilities, in which, homeless individuals reside such as, the Clay Family Residence (at the former Greenpoint Hotel building). Also, the City must insure that adequate support services are provided to maintain the safety of surrounding residents and to minimize quality of life problems. We have received complaints regarding the newly opened Clay Family Residence about the facility's clients loitering and fighting outside. Community Board No. 1 had vehemently opposed the Department of Homeless Services’ (DHS’s) and the Doe Fund’s advancement of a shelter at 89-111 Porter Avenue.
We were truly saddened that the Appellate division failed to find merit for appeal when the City found a loophole in the ULURP process and sited this “homeless” shelter in the heart of a city designated “in place industrial park”. We remain concerned about the establishment of a homeless facility at 400 McGuinness Blvd, (a former factory building that a previous owner eyed for residential development) and 66 Clay Street (aka the Greenpoint Hotel/SRO). We remain concerned about these facilities and any associated rise in crime statistics demonstrated for the area. (CONTINUED - SEE FULL STATEMENT OF DISTRICT NEEDS)
Needs for Low Income NYs
(THIS IS AN EXCERPT FROM OUR STATEMENT OF DISTRICT NEEDS) HOUSING Affordable housing in Community Board No. 1 is a top priority that must be addressed as a critical need. If our neighborhoods are to remain viable and attract/retain jobs and a stable work force, an adequate supply of decent and affordable housing must be available at various income levels. Community Board No. 1 generally supports the policies articulated by the City, that provides an unprecedented portion of City Capital Budget funding for housing in a manner that gives increased priority to the development of low and moderate income housing. As we have stated in previous years, three general principles must be incorporated into any equitable comprehensive housing plan: FIRST, those currently funded housing programs that have proven successful must be held harmless from the reduction in past federal assistance, even if an increased City Tax Levy contribution is required to achieve this end. SECOND, in allocating
additional housing funds between the poor and middle class economic segments of our society, it is essential that the first priority be assigned to the poorest segment of our population, those who must bear the brunt of the housing crisis. However, we strongly support the need for affordable housing (both rental and home ownership) for all economic groups. THIRD, any additional housing funds must be allocated in a fair and equitable manner that responds to the most critical housing needs of each Community District, with a clear and largely advertised marketing throughout the district. (SEE FULL STATEMENT OF DISTRICT NEEDS FOR CONTENT)
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
7/25
DFTA
Increase home
Request: Increase Funding of Homecare Services
delivered meals
and the Homebound Meals Program.
capacity
Explanation: Increase funding of homecare
services and the homebound meals program.
Responsible Agency: Department for the Aging
15/25
DOHMH
Other programs to
Request: Fund Comprehensive Study of
address public
Environmental Health Hazards, Including Air
health issues
Quality and Asthma, to Learn Cumulative Effects
requests
on CB 1; Study Should Include the DEP Waste
Water Treatment Plant. Explanation:
Community Board No. 1 has been impacted by
many adverse environmental factors (i.e.,
Mobile Oil spill, toxic waste, transfer stations,
air pollution, etc.). A comprehensive study is
needed to assess these impacts and develop
resolutions, such as anti-asthma initiatives, to
be implemented. The Study should include the
DEP Waste Water Treatment Plant. Responsible
Agency: Department of Health and Mental
Hygiene
17/25
DFTA
Create a new senior
Request: Establish Senior Center to Serve South
Clymer Street
center or other
West Area of Williamsburg, Central to Division
Division
facility for seniors
Avenue and Clymer Street/Continued Funding.
Avenue
Explanation: At the present time, accessible
Bedford
senior center services do not exist for the
Avenue
expanding senior citizen population of the west
area of Williamsburg. Although we are aware of
the current funding constraints regarding senior
center services, the existing needs compel us to
support the establishment of such a facility in
the area central to Division Avenue and Clymer
Street. Responsible Agency: Department for the
Aging
20/25
DOHMH
Provide more
Request: Increase AIDS Outreach. Explanation:
HIV/AIDS
Increase the staffing of outreach programs that
information and
handle education, testing and counseling for
services
infectious diseases (TB/AIDS/ZIKA) and drug
abuse. Responsible Agency: Department of
Health and Mental Hygiene
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 1
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
(This is an excerpt from the 2021 Statement of District Needs) EDUCATION We support an overall master planning effort for the Department of Education’s District 14. With the acknowledged change in student population, schools in our district must be retooled to address the ever changing needs. We continue to support our area schools and their needs that were previously related to our Board: outfitting each school with a science laboratory and to provide wireless computers and stations for the schools within the Community School District. We continue to support (1) After School, Saturday, Summer Instructional and Recreational Programs; and (2) Repair, Refinishment of our area’s School Buildings. In the past, budget cuts to several capital projects caused them to be eliminated in a number of schools and many educational programs were either ceased or reduced as well as staff connected with those programs. We are concerned about the need for student protection and support all recognized security programs approved by the Department of Education to protect our children.DAY CARE AND SENIOR CENTER SERVICES Community Board No. 1 was served by 30 Day Care/2,956 slots 9 Head Start/799 slots, 18 Group Day Care/2,100 slots, 2 Day Care-Voucher Sites/8 slots and 1 LPOS/49 slots and 9 Senior Centers serving an average of 1,338 daily meals. We strongly urge continued support of the City’s extensive tax levy commitment to maintain day care and senior center services at least a their current levels despite devastating budget cuts, and urge that it be maintained as long as the need exists. In particular, the need for new day care centers, head start program and an increase in meals-on-wheels program is rising in the District, especially in the South Williamsburg area. We are totally dismayed to learn that the City has chosen to close the two agencies at the 211 Ainslie Street facility: The Small World Day Care Center and the Swinging 60’s Senior Citizen Center. These two programs have co-existed in the same building for several decades to serve two populations in the neighborhood that are at high risk: the very young and the elderly. (SEE FULL STATEMENT OF DISTRICT NEEDS FOR CONTENT)
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
(THIS IS AN EXCERPT FROM OUR 2021 DISTRICT NEEDS STATEMENT) EDUCATION We support an overall master
planning effort for the Department of Education’s District 14. With the acknowledged change in student population, schools in our district must be retooled to address the ever changing needs. We continue to support our area schools and their needs that were previously related to our Board: outfitting each school with a science laboratory and to provide wireless computers and stations for the schools within the Community School District. We continue to support (1) After School, Saturday, Summer Instructional and Recreational Programs; and (2) Repair, Refinishment of our area’s School Buildings. In the past, budget cuts to several capital projects caused them to be eliminated in a number of schools and many educational programs were either ceased or reduced as well as staff connected with those programs. We are concerned about the need for student protection and support all recognized security programs approved by the Department of Education to protect our children. A major push by parents, community residents and teachers to reorganize the academically declining Comprehensive Eastern District High School proved to be quite successful as the 850 Grand Street Campus facility was instituted. In 1996 the Board of Education started three smaller schools, also called academies, that focused on particular themes of study (Progress HS for Professional Careers; Enterprise Business HS; and the School for Legal Studies), and eventually phased out Eastern District High School. Since that time, several other smaller schools are established in our district: the Academy for Young Writers; Williamsburg Preparatory School; Williamsburg HS for Architecture and Design; El Puente Academy for Peace and Justice; Harry Van Arsdale HS GED; Green School: An Academy for Environmental Careers; and charter schools: Williamsburg Collegiate Charter School; Williamsburg Charter HS (“Beginning with Children” was a pioneer charter school in our community for elementary school age youngsters. It grew out of a private partnership with Pfizer and opened its doors in September 1992). We look forward to our educational facilities having future success in serving the educational needs of our children. We have received the expressed needs (list shown below of
schools within the confines of CB 1) from School District 14's superintendent. Schools Needs MS 126 424 Leonard Street - Air conditioning in the auditorium and cafeteria PS 132 320 Manhattan Ave. - 13 classroom air conditioners are not functioning, as well as the air conditioners in the Performing Arts Space and in the cafeteria. PS 147 325 Bushwick Ave. - Comprehensive Auditorium Upgrade including Electrical Wiring to accommodate air conditioning systems, new seating and floors, state-of-the-art stage equipment to include a defined stage area with backstage, lighting, sound. - Comprehensive Bathroom Upgrades for students and adults building-wide to include new plumbing, flushing systems, toilets, sinks, wall tiles, floors. - Window Upgrade (entire building). PS 250 108 Montrose Ave. - Bathroom upgrades. - Brighter lighting in the Gym. - School yard upgrades. - New closet Doors in Classrooms. PS 319 360 Keap Street - New PA System. - New Windows. - Courtyard Resurface. - New toilets and sinks for student restrooms. Additional comments for the needs of PS 250 are: Multi Media Center at PS 250 - Comprehensive Multi Media Center for students and community members to have the opportunity to learn photography, film-making, animation, graphics, podcasting, and other forms of communication. This proposal calls for state of the art technology and support for media. A Modern Gym at PS 250 - The idea is to resurface the gym floor with hardwood and to install new wall padding. We also need the basketball hoops fixed. The gym lighting needs to be upgraded, and the gym needs bleachers installed. Restroom Upgrade - The student restrooms have not been upgraded in over two decades. School Yard Upgrade - Repair broken asphalt and overall redesign Auditorium Upgrade - Add air conditioning system, new seating, state of the art stage equipment to encompasses backstage upgrade, new sound system, projector upgrades, and lighting enhancements It has been reported by the Department of City Planning that according to the Census, out of the total district’s population, in the group 5 years and over: 89,085 persons are proficient and 57,775 are not proficient in English. Those persons not proficient in English had another language spoken at home. Roughly 46.5% spoke Spanish/Spanish Creole; 20.8% spoke Polish; 20.5% spoke Yiddish (with the remainder percentage scattered in other categories). We encourage programs that will assist persons with attaining better English proficiency skills.
Needs for Youth and Child Welfare
(THIS IS AN EXCERPT FROM OUR FULL FY 2020 STATEMENT OF DISTRICT NEEDS) YOUTH SERVICES More than 51,600
residents of Community Board No. 1 are 19 years of age or less, and a very high percentage of this population resides in the poorest portions of the district. Unless an effective network of youth service programs is established, many of these youths will never have a fair opportunity to succeed in life, and will instead be attracted to the alternate lifestyles of crime and drugs. In light of this, the appallingly small allocation for delinquency prevention and after school programs funded by the Department of Youth and Community Development remains a perpetual source of frustration to the Board’s Youth & Education Committee. We are also concerned with the closing of youth centers at our public housing developments. The youth center at the Cooper Park Housing development is closed in the evenings. The closings should be stopped and these centers reopened and financially supported. Not only do they provide vital recreation but are safe havens for the youths. The Beacon program located at 850 Grand Street Campus has offered a valuable resource, but is not enough to service the approximately 51,625 youths of our district. Unless the City and State agree to substantially bolster this modest allocation, and a 100% increase is not- out-of order, its impact upon the youth of Community Board No. 1 will remain slight. We were pleased that the City expanded Beacon Programs citywide and, as a result, additional Beacon programs for our area have been made available at MS 126 and MS 50. The Beacon program at MS 126 has served as an anchor for a newly formed “Greenpoint-Williamsburg Youth Soccer League” that has over 500 youths. There is extremely limited open space to accommodate these youngsters to play concurrent games and we urge that additional space be made available for this use. We are concerned about the sudden increase in the number of Charter Schools being sited in the district (Community School District 14 serves the CB 1 area). Often they are being collocated in existing school buildings. We raise the question of their having a negative impact upon funding allocations for our existing public schools.
YOUTH EMPLOYMENT The Department of Youth and Community Development must increase the number of slots and continue to develop and expand local sponsorship within Community District No. 1 for the City’s “Summer Youth Employment Program”. It must take a more aggressive role in addressing program sponsorship in each Community Board area. We urge the City to increase its outreach within the community to obtain non-profit agency sponsors who will adequately service our youths. TEEN PREGNANCY One of the most serious problems involving youth is adolescent pregnancy, which had reached epidemic proportions throughout North Brooklyn. We are pleased to learn that statistics in this area are starting to show a decline. It is essential that a systematic approach to this problem is continued aimed at preventing unwanted pregnancies form occurring in the first place and providing educational and social services to the teen mothers in order to prevent long term welfare dependency.
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
8/26
SCA
Renovate or
Request: Department of Education Projects
upgrade a middle or
Scheduled to Upgrade Schools in SD-14 to Start
intermediate school
or Complete this Year (for Example: Renovations
to Include Automotive Trades HS; 850 Grand
Street Campus; Van Arsdale HS). Explanation:
Many of the schools in the district are very old
and require modernization, upgrading of their
physical structures and/or replacements of
heating/cooling systems. Responsible Agency:
Department of Education
10/26
SCA
Renovate other site
Request: Construct a New Schoolyard at PS 18
101 Maujer
component
(Located at 101 Maujer Street). Explanation:
Street
This elementary school accommodates many
Pre-K through 5th Grade students. Its
schoolyard is quite outdated with broken
concrete/asphalt areas. Renovations are needed
to modernize it (work should include the
installation of new play equipment and safety
surfaces). Responsible Agency: Department of
Education
11/26
SCA
Provide a new or
Request: Construction Proposed for a New
219 West
expand an existing
School (P.S./I.S. A New School (Elementary
Street
elementary school
School/Intermediate School - PS/IS) at the
Dupont Street Development Site. Explanation: A
new school is proposed at the development site
on Dupont Street. We urge that District 14 and
the District's CEC are consulted and play a lead
role with any planning for the school.
Responsible Agency: Department of Education
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
5/25
DYCD
Provide, expand, or
Request: Increase Significantly the Department
enhance after
of Youth and Community Development Agency's
school programs for
Community Board Fair Share, After School, and
elementary school
Summer Recreation Funding Allocation for CD
students (grades K-
1. Explanation: Over 32% of CD1's population
5)
is 18 years of age or younger, and many of these
individuals require education, recreation and
counseling programs to enable them to escape
from an environment of crime and poverty. The
inadequate levels of Youth Bureau funding
available to CD1 severely undermines the ability
of these programs to effectively serve this
population. The significant expansion of all
Youth Bureau allocations should be
implemented as promptly as possible.
Responsible Agency: Department of Youth &
Community Development
11/25
DOE
Provide more funds
Request: Fund New Science Labs for Schools
for teaching
(including middle schools)(District 14/Region 8)
resources such as
Located Within the Confines of Community
classroom material
Board No. 1 District. Explanation: New science
labs are needed in the various schools in our
District. The labs would provide new facilities or
replace outdated ones and utilize modern
equipment for instruction. Responsible Agency:
Department of Education
12/25
DOE
Provide, expand, or
Establish additional daycare or head start
enhance funding for
programs to serve Greenpoint/Williamsburg
Child Care and Head
that are now under-served.
Start programs
14/25
DOE
Provide more funds
Request: Fund a New School Library for PS 250.
108 Montrose
for teaching
Explanation: A new library is needed at this
Avenue
resources such as
elementary school to provide an expanded
classroom material
reading facility and teaching resources.
Responsible Agency: Department of Education
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 1
image
M ost Important Issue Related to Public Safety and Emergency Services
Emergency service delivery (including rapid response)
(Excerpt Statement of District Needs)We note the valuable contribution of the anti-drug housed at the 90th Precinct. We urge continued efforts by the NYPD to deter illegal drug dealing in our community and reduce crime. We are concerned about the lack of planning on both New York State and New York City levels in regards to medical marijuana operations. ince the "legalization" of marijuana in other US states, problems of abuse have skyrocketed in communities, especially in places like Colorado and California. We are concerned that our community will suffer from similar woes and fear that New York State does not have a firm grasp on the matter. The foot patrolman is a valuable public safety resource and more personnel must be put on patrol to increase efficiency and address quality of life type complaints. We are pleased that they have started“NCO”. For each sector team there are two officers designated as the neighborhood coordination officers (NCOs). We supported the installation of these cameras on McGuinness B, especially at the intersection of Norman Avenue where Public School 34 is located. Community Board No. 1 unfortunately, had the distinction of being in the top three of the community districts with the highest suspicious fire rates. The devastating 10+ alarm fire in 2006 the Greenpoint Terminal Market (remarked as rivaling the 9/11 terrorist attacks on the World Trade Center) shows too dramatically the need for fire protection and the full complement needed to investigate and solve suspicious fires. We must not forget that a large percentage of housing stock was lost in our communities during the arson ravages of the 1970’s. It was only through prevention, education, investigation and the bringing to justice those persons criminally responsible, that the spread of fire damage was stemmed. We continue to rank within the top five community boards in terms of total incidents. We oppose any plan by the Administration to close any more units! With the closing of St. Catherine’s Hospital in 1964 and the Greenpoint Hospital shutdown in 1982, the Greenpoint/Williamsburg community remains void of any hospital facility within its confines. Although vibrant and expanding, the communities of Greenpoint/Williamsburg continue to have an older population ( a rising young one) and thus rely on the Fire services, EMS, Engine Companies with defibrillators to be the “1st Responders” when needed. As a community in renaissance, we have seen a steady rise in population (noted in the 2010 census). We believe that this figure is far short of the actual increase (the notable growing population includes many new families with young children, and there is a boom in the restaurant/bar type businesses with many patrons attracted from both inside and outside the community). We continue to support affordable housing and open space for the Broadway Triangle area.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
(Excerpt from the FY2020 Statement of District Needs) POLICE DEPARTMENT STAFFING Adequate police protection is a basic public right, and we urge the Community Board No. 1’s two local precincts – the 90th and 94th – receive their fair share of any additional police staffing. Community Board 1 is experiencing a renaissance. Current population statistics topple over census figures as new faces fill our streets as we become the trendy place to live; even more to visit. New residences are constructed or lofts are converted, new entertainment venues are being developed. While we are enjoying this popularity, it comes with a cost. Our two police precincts, the 90th and 94th, continue to be severely overburdened with addressing the many quality of life issues that arise with the many different lifestyles of our new and existing populations. For example, Bedford Avenue (between Metropolitan Avenue and North 12th Street; North 6th Street between Bedford and Kent Avenue) has become a Mecca for bars, eateries – and on the whole – a new venue for nightlife in Williamsburg. Policing is a necessary ingredient for this venue to be successful, not only for the City as a tax revenue base, but being able to weave this trend into an existing community. Likewise, the introduction of clubs, bars and galleries in Greenpoint has also created a greater enforcement need – constituents are walking the streets at later hours whereas past trends of earlier bedtimes drew less police action. We are highly concerned about the sudden rise of huge venues for entertainment that are opening in the district, especially within our industrial/manufacturing enclaves. These large venues are geared to
attract thousands of patrons to their doors per event. Such numbers require tight security plans and safety management. In lieu of this ever- changing scenario Community Board No. 1 seeks immediate action in the assignment of additional police officers to the 90th and 94th Police Precincts. In addition, the growth in the residential and commercial population has brought a great deal more vehicular, pedestrian, and bicycle traffic to the district. We would greatly benefit from more traffic enforcement agents, particularly along our busiest and increasingly dangerous corridors: Graham Avenue, Flushing Avenue, Metropolitan Avenue, Bedford Avenue, and Manhattan Avenue. Since the implementation of a cycling network in our district, we are compelled to respond to increased complaints by residents that cyclists are not adhering to rules of safety. We call upon the Administration to begin a program of identification license plates for bicycles. Revenues attained by the plating of bicycles can be used to implement additional safety measures to protect cyclist, pedestrians and motorists. We believe that the implementation of the BikeShare program warrants the need for police personnel to be dedicated for bicycles safety enforcement. We continue to support the installation of surveillance cameras within the City’s subway stations. The cameras have aided the police in deterring crime and apprehending criminals. We support requests made by our local precinct(s) commanders to install these cameras, monitored by NYPD personnel, in our district’s stations (G, L, M/J lines). This should result in the assignment of adequate police officers to each facility to maintain the recently reduced crime rate and maintain around the clock coverage of all police sectors in each precinct. In addition, it is essential that the number of police officers assigned to the eight NYC Housing Authority developments located in Community Board No. 1 be significantly increased, whereas Cooper Park was turned over to the 94th Precinct. This should be duplicated throughout Community District 1 area. Turning NYCHA sites over to their respective precincts for a more local policing strategy is the right thing to do!
Needs for Emergency Services
(Excerpt from FY 2019 Statement of District Needs) FDNY/EMERGENCY MEDICAL SERVICES We continue to be in “shock and awe” with the Mayor’s decision to close Engine Company 212 that we are compelled to once again reiterate our extreme and vehement opposition to any Fire Station closings. The future of our community depends on this essential service. We oppose any plan by the Administration to close any more units! With the closing of St. Catherine’s Hospital in 1964 and the Greenpoint Hospital shutdown in 1982, the Greenpoint/Williamsburg community remains void of any hospital facility within its confines. Although vibrant and expanding, the communities of Greenpoint/Williamsburg continue to have an older population (and a rising young one) and thus rely on the Fire services, EMS, Engine Companies with defibrillators to be the “1st Responders” when needed. For the period of January – May 2016, our fire companies responded to 4,933 emergencies (total emergency & medical responses) as “Certified First Responders-Defibrillators” in Community Board No. 1. The ranking for our district is the third highest in Brooklyn with Emergency Medical total responses. The total number for Nonfire and Nonmedical Emergencies for this year to date (May) is 2,783 noting our district as the highest in Brooklyn with these responses. There were 238 responses to structural fires and 223 nonstructural fire responses, with a total of 461 year to date, ranking our district as first with the highest number. In 2015, from January to December, CB 1 ranked third in the borough with 13,539 total incidents handled by the FDNY. As a community in renaissance, we have seen a steady rise in population (noted in the 2010 census). We believe that this figure is far short of the actual increase (the notable growing population includes many new families with young children, and there is a boom in the restaurant/bar type businesses with many patrons attracted from both inside and outside the community). An increased risk of fire is connected with restaurant operations, as well as possible food/choking hazard emergencies. We remain concerned about the lack of fire and emergency medical service coverage in this section of our district. The exodus of the commercial use to that of residential is extremely problematic mainly as well because most – if not all – of the properties are wood beam construction with an extreme potential for fire. We applaud the Fire Department’s efforts to bring better service via the concept of housing EMT bases strategically located in the community. A location was identified and secured within Community Board No. 1 (332 Metropolitan Avenue). After several delays this facility’s construction was completed and operating. The FDNY has made little attempt if any, to site a location to serve the northern portion of Greenpoint. We hereby call upon the Administration to address the community’s need for ready ambulance services. (CONTINUED - SEE FULL STATEMENT OF DISTRICT NEEDS)
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
1/26 FDNY Provide new
facilities such as a firehouse or EMS station
Request: Creation of a New Firehouse in the North side Area. Explanation: The Greenpoint and Williamsburg communities are growing greatly in population and new businesses. With the pending rezoning and waterfront development there is a tremendous increased need for enhanced public safety. There is no firehouse to serve the North side community and the waterfront area. A new state of the art facility that can house proper modern equipment (such as ladders for high rise buildings) should be created to better service the community. Responsible Agency: Fire Department
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
2/25
FDNY
Provide more
Request: Fund the Operations of a Newly
firefighters or EMS
Created Firehouse (FDNY) in the North side.
workers
Explanation: The closure of the firehouse at 136
Wythe Avenue serving the mixed-use north
community leaves this expanding residential
neighborhood without adequate fire protection.
Loft conversion and future development
planned for the waterfront will greatly increase
the population and businesses in the area
requiring fire protection. Responsible Agency:
Fire Department
9/25
NYPD
Assign additional
Request: Provide Safe Street Crossing (NYPD
crossing guards
Crossing Guard Post) at Jackson Street &
Kingsland Avenue for Children Attending Various
Local Schools and Programs. Explanation:
Provide safe street crossing (NYPD crossing
guard post ) at Jackson Street & Kingsland
Avenue for children attending various local
schools/after school programs (St. Francis
Developmental School, PS 132, St.
Nicholas/Rosary Academy, IS 49 Campus, Grand
Street Campus/Beacon Program, IS 126/Beacon
Program, School Settlement House Association).
Responsible Agency: Police Department
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 1
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Environmental concerns affecting citizens
(Excerpt from the Statement of District Needs)Our board opposes the Organics Recycling/Waste to Energy Program at the Newtown Creek Water Pollution Control Plant and unanimously passed the following resolution: RESOLUTION TO OPPOSE PROCESSING OF ORGANIC Community Board No. 1 opposes the WASTE/WASTE TO ENERGY AT THE NEWTOWN CREEK WATER POLLUTION CONTROL PLANT - WHEREAS the City of New York, with the Department of Sanitation and the Department of Environmental Protection has co-ventured with Waste Management Inc. and NationalGrid to conduct a recycling program to process organic waste/waste to energy at the Newtown Creek Water Pollution Control Plant. It excerbates the adverse environmental conditions that come from traffic, industrial uses and waste processing.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
(Excerpt from the 2019 Statement of District Needs) SEWER CONSTRUCTION As one of Brooklyn’ oldest communities, Community District No. 1 naturally suffers from a terribly outdated and inadequate sewer system. The continued upgrading and replacement of our sewers remains an on-going necessity. The stretch of Graham Avenue, from Meeker Avenue to Metropolitan Avenue, continues to be plagued by foul sewer odors that emanate from the catch basins. To date, DEP has not been able to resolve the condition. An additional unresolved sewer related matter is DEP’s failure to step up to the plate and aggressively correct numerous cave-in conditions from previous sewer pipe work that now requires trench restoration. These are sites where there was inadequate shoring, or wood shoring that was never removed and decayed causing underground subsurface voids which have subsequently collapsed. The Department of Environmental Protection continues to drag its feet in this matter while every day these conditions worsen and present public safety hazards. Community Board No. 1 has forwarded the following locations since 1999 to receive priority attention: • Clymer Street between Wythe and Bedford Avenues • Division Avenue between Berry Street and Wythe Avenue • Eckford Street between Norman and Nassau Avenues • Grand Street between Humboldt Street and Morgan Avenue • Maujer Street between Lorimer Street and Union Avenue • Meserole Street between Lorimer Street and Union Avenue • Montrose Avenue between Union Avenue and Buschwick Place • Moore Street between Humboldt Street and Manhattan Avenue • North 6th Street between Driggs Avenue and Roebling Street • Rutledge Street between Bedford/Marcy/Lee Avenues • Scholes Street between Morgan and Union Avenues • Skillman Avenue between Humboldt Street and Graham Avenue • Ten Eyck Street at Lorimer Street These locations were to be addressed in FY 2009, however, the Department of Design and Construction relates that the work is delayed because DEP says they have no funding! In another portion of the District, the area directly under and north of the Kosciuszko Bridge continues to be forgotten and floods constantly with the free-fall drainage from the BQE. Sewer construction here has been delayed, too. This item also needs to be promptly addressed by the responsible environmental agencies of both the City and State. (CONTINUED -SEE STATEMENT OF DISTRICT NEEDS)
Needs for Sanitation Services
(Excerpt from the 2020 Statement of District Needs) SANITATION GARAGES The construction of a new garage to serve Community District 1 and 4 was completed. The Department of Sanitation has not acted responsibly to relocate the K-3 Sanitation Garage. It still needs to be placed in Community District 3 and no longer be situated in our district. The Department of Sanitation must take immediate corrective action to relocate this to its respective district as per co-terminality guidelines and not juggle it within the confines of Community Board No. 1. The DOS relocation of BK3 to the old BK4 site remains completely unacceptable. STREET CLEANING REGULATIONS We urge the Department of Sanitation to change the parking regulations to reduce the number of street cleaning days from four to two. We should be treated like any other Community Board and be granted a reduction.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
19/25 DSNY Provide more
frequent garbage or recycling pick-up
Request: Expand Refuse Collection Program for NYCHA and Other Large Housing Developments to Schools & Senior Centers. Explanation: Implementation of this request will provide relief to the residents of Community Board No. 1's eight public housing developments (6,506 units); Lindsay Park Mitchell-Lama housing (2,800 units), who suffer from chronically inadequate refuse collection services.
Responsible Agency: Department of Sanitation
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 1
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
(Excerpt) OVERVIEW The wave of 2009 (a Tsunami) continues to impact our community. Not just a wave of destruction, but multiple waves of construction. The flood waters have not receded. Some construction worksites are still stalled or abandoned. The undertow of these thunderous waves continues to negatively impact the lives of the residents of Greenpoint-Williamburg and will effect generations to come. This tide of grief has already created a climate of highly inflated rents, denied lease renewals to both residential and commercial tenants, and a forced exodus of longtime commercial tenants into less desirable areas and even out of state. Now, complicating the equation even more, we are faced with distressed and abandoned work sites and condo prices which are out of touch with today’s market. And the erosion of the existing community has not stopped there! Like the construction of the BQE in the 1940’s which split communities and demolished the Mt. Carmel Cathedral (for the so called betterment of the transportation network) this continuing pounding of the wave destroys dreams for the homesteaders, the poor and middle/working class of this community – the people who chose to stay, when it was not trendy or chic. Without a guarantee of affordability they have been forgotten. And as the flood waters persist to move inland, the distillates of the 2005 Rezoning (notably opposed by CB 1) continue to swoop down upon our small stable communities and create havoc by demolishing our quaint existing structures, building upward (with units not affordable for our community) and straining our limited services and already overburdened antiquated infrastructure. The 2005 rezoning continues to be a “gift that keeps on giving” --- we are now facing pending construction of tower type “as of right” developments in Greenpoint and in Williamsburg We ask that a councilmatic blue ribbon commission be formed to examine and evaluate the results of the 2005 rezoning. HOTEL DEVELOPMENT CB 1 seeks the City to address an issue that is of increasing importance to our community: hotel development. As the landscape of the city changes, more and more hotels are being built in neighborhoods that are historically residential. (SEE FULL STATEMENT)
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
(Excerpt from the 2020 Statement of District Needs) HOTEL DEVELOPMENT CB 1 seeks the City to address an issue that is of increasing importance to our community: hotel development. As the landscape of the city changes, more and more hotels are being built in neighborhoods that are historically residential, such as ours. Hotels have an outsized, often disruptive, impact on our communities and we urgently need a process that provides real community input on hotel development. Recent hotel growth in Brooklyn has been in residential and industrial areas, crowding out local communities, manufacturing spaces, and affordable housing. This hotel growth has led to the gentrification and homogenization of our communities, and it has inflated rents and property taxes. To maintain our vibrant city, every effort should be made to preserve socioeconomic diversity and keep our neighborhoods affordable for the mix of uses (residential, community spaces, artistic) that currently exist. We need a real voice in the development process and an opportunity to engage developers before they start building. The simplest, most comprehensive approach is to amend the Zoning Resolution so that new hotels may only be developed by special permit. We strongly support a city-wide special permit requirement for hotels. This will empower communities and put residents and our representatives in City Council and in the Borough President’s office on more equal footing with hotel developers, who have too often disregarded substantive issues. (SEE FULL STATEMENT FOR CONTENT)
Needs for Housing
(Excerpt from FY 2020 Statement of District Needs) HOUSING Affordable housing in Community Board No. 1 is a top priority that must be addressed as a critical need. If our neighborhoods are to remain viable and attract/retain jobs and a stable work force, an adequate supply of decent and affordable housing must be available at various income levels. As we have stated in previous years, three general principles must be incorporated into any equitable comprehensive housing plan: FIRST, those currently funded housing programs that have proven successful must be
held harmless from the reduction in past federal assistance, even if an increased City Tax Levy contribution is required to achieve this end. SECOND, in allocating additional housing funds between the poor and middle class economic segments of our society, it is essential that the first priority be assigned to the poorest segment of our population, those who must bear the brunt of the housing crisis. However, we strongly support the need for affordable housing (both rental and home ownership) for all economic groups. THIRD, any additional housing funds must be allocated in a fair and equitable manner that responds to the most critical housing needs of each Community District, with a clear and largely advertised marketing throughout the district. We will now apply these principals to the major housing concerns of Greenpoint and Williambsurg: While we were extremely encouraged by the Administration’s “Points of Agreement” with the NYC Council and its consideration of the Greenpoint- Williamsburg zoning and related ULURP actions, several points were noted in this document, including affordable housing, which the Administration agreed to significantly increase through a variety of mechanisms including inclusionary zoning, financial and tax incentives. In addition to increasing the number of affordable units in the district, the Administration agreed to anti-harassment provisions to be provided separately, as part of a follow-up corrective action. The lack of progress on the many areas outlined in the Agreement shows a violation of the spirit of this document. The ill-fated plans to create a Greenpoint-Williamsburg Affordable Housing and Infrastructure Fund of up to $10 million, to be managed by HPD, using proceeds received from the sale of air rights from the MTA site on Commercial Street in Greenpoint never happened. Harassment and displacement continues unmitigated. All efforts must be made to implement those previously proposed projects that have yet to be funded. It is essential that the City realizes the need for low income rental housing/ownership and provide the much needed funds that will help compensate for the past tragic loss of Federal housing subsidies. The inclusion of such programs by the Mayor, an overall comprehensive housing program, is an absolute necessity for our district. Homeownership in low- income communities is seriously weak. In other areas of the country, the Section 8 subsidy is utilized for home purchasing. We urge that a similar pilot program be brought to NYC, and that Greenpoint and Williamsburg is considered for inclusion. (SEE FULL STATEMENT FOR CONTENT)
Needs for Economic Development
(Excerpt from the 2020 Statement of District Needs) ECONOMIC DEVELOPMENT COMMERCIAL REVITALIZATION AND INDUSTRIAL DEVELOPMENT (CONTINUED - SEE FULL DISTRICT NEEDS STATEMENT STATEMENT)
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
2/26
HPD
Provide more
Request: Fund Construction and Rehabilitation
housing for medium
of Subsidized/Affordable Housing, Including
income households
Waterfront and Upland Areas, in the
Community District 1 Area. Explanation: The
neighborhoods of Greenpoint and Williamsburg
possess critical housing needs and the allocation
of funds to provide affordable housing in the
district remains a vital concern of CB 1. It is
essential that adequate subsidies be allocated
to ensure balanced development of our
community. Responsible Agency: Department of
Housing Preservation & Develop
9/26
NYCHA
Renovate or
Redevelop NYCHA Playground on Roebling
Roebling &
upgrade NYCHA
Street and South 9th Street. This park is well
South 9th
community facilities
used by the community. The playground is aged,
or open space
in need of upgraded equipment and
unfrastructure.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
3/25
HPD
Other affordable
Reinstate funding for the Greenpoint –
housing programs
Williamsburg Tenant Legal Fund ($2 million),
requests (expense)
including anti-harassment provisions per the
Administration’s Points of Agreement regarding
the Greenpoint-Williamsburg waterfront
rezoning.
6/25
HPD
Provide or enhance
Request: Increase Funding to Support Subsidies
rental subsidies
to Lower Rents for Senior Citizens to Reduce the
programs
Increase in Homelessness. Explanation: Increase
funding to support subsidies to lower rents for
senior citizens to reduce the increase in
homelessness. Responsible Agency: Department
of Housing Preservation & Development
8/25
HPD
Other affordable housing programs requests (expense)
Request: Create a New Fund for the Affordable Housing and Infrastructure Fund ($10 Million) Created Under the Administration's Points of Agreement Regarding the Greenpoint- Williamsburg Waterfront Rezoning. Explanation: A new fund is requested. The Affordable Housing and Infrastructure Fund ($10 Million) was created under the Administration's Points of Agreement regarding the Greenpoint- Williamsburg waterfront rezoning. Proceeds from this fund will only be available to development parcels that make use of the waterfront inclusionary housing program referenced in the agreement, and that participate in the esplanade transfer program (as noted in the agreement's Open Space section). Funds will be used to partially offset site-specific infrastructure costs.
22/25
HPD
Other affordable housing programs requests (expense)
Increase allocation for rehabilitation loan programs.
23/25
DOB
Assign additional building inspectors (including expanding training programs)
Continue/expand the building inspector training program; increase the number of inspectors (DOB) for CB  1.
TRANSPORTATION
Brooklyn Community Board 1
image
M ost Important Issue Related to Transportation and Mobility
Other
TRANSPORTATION AND INFRASTRUCTURE TRANSPORTATION BLUEPRINT STUDY We urge the Department of
Transportation to realize Community Board No. 1’s goals for adequate mass transit, safer streets, more accessible and safer walking and biking environment, and better driving and parking conditions for delivery trucks and motorists. We continue to urge the City and State to budget money to adequately forecast transit and traffic growth projections. Newly constructed buildings have brought – and will continue to bring – thousands of new residents to Greenpoint and Williamsburg. It must be stressed that the time for sitting back is over. We no longer need a proactive approach, but a reactive one! The L train is so overcrowded that commuters are turning toward alternate sources that are already beyond capacity (i.e. G train line; cross town buses). In addition, many of our bus routes are so convoluted that they fail to provide direct and expedient access to key commuter hub points. The failure of the Administration to respond to our mass transit crisis remains a shameful blot on its legacy. Rethinking is needed for our bus routes and alternate forms of access to Manhattan must be implemented (i.e. water taxis have limited capacities and short service hours. A larger accommodating ferry type service, with affordable fares, is needed). We are pleased that the City has planned to improve ferry access to our waterfront with comparable fares as subways and buses (MetroCard fare). The fruits of this new plan under the NYC Department of Economic Development have yet to be seen. DOT has undertaken traffic two studies: South Williamsburg and Williamsburg. We have seen only the preliminary results of these two studies and we are concerned that the public’s participation in the process is severely lacking.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
TRANSPORTATION AND INFRASTRUCTURE TRANSPORTATION AND INFRASTRUCTURE TRANSPORTATION BLUEPRINT
STUDY We urge the Department of Transportation to realize Community Board No. 1’s goals for adequate mass transit, safer streets, more accessible and safer walking and biking environment, and better driving and parking conditions for delivery trucks and motorists. We continue to urge the City and State to budget money to adequately forecast transit and traffic growth projections. Newly constructed buildings have brought – and will continue to bring – thousands of new residents to Greenpoint and Williamsburg. It must be stressed that the time for sitting back is over. We no longer need a proactive approach, but a reactive one! The L train is so overcrowded that commuters are turning toward alternate sources that are already beyond capacity (i.e. G train line; cross town buses). In addition, many of our bus routes are so convoluted that they fail to provide direct and expedient access to key commuter hub points. The failure of the Administration to respond to our mass transit crisis remains a shameful blot on its legacy. Rethinking is needed for our bus routes and alternate forms of access to Manhattan must be implemented (i.e. water taxis have limited capacities and short service hours. A larger accommodating ferry type service, with affordable fares, is needed). We are pleased that the City has planned to improve ferry access to our waterfront with comparable fares as subways and buses (MetroCard fare). The fruits of this new plan under the NYC Department of Economic Development have yet to be seen. DOT has undertaken traffic two studies: South Williamsburg and Williamsburg. We have seen only the preliminary results of these two studies and we are concerned that the public’s participation in the process is severely lacking. BRIDGE IMPROVEMENT Since Community Board No. 1 is nearly surrounded by the East River and the Newtown Creek, it is not surprising that the quality of our local bridges remain continuing concerns. Emphasis must be placed on adequate continued coordination (access/egress) to our community during any upcoming construction work. We must express deep concern about traffic impacts on the community during any bridge reconstruction. We urge that such construction proceed with on-going monthly maximum community input. Repeated delays on the reconstruction of the Grand Street (Penny Bridge) continue to spell disaster. The Grand Street Bridge is particularly dangerous as the narrow width of the bridge does not allow for two lanes of vehicles, especially trucks, to pass at the same time. Community Board No. 1 supports the alternative which is a Steel “Basket Handle” Tied Arch design. This project was to precede
the Kosciuszko Bridge reconstruction agenda. However, it has not. Every effort must be made to ensure that there are adequate safety measures and detours in place. The City-Wide need to upgrade its East River bridges is of great concern to the Board as it relates to the Williamsburg Bridge. Its closing in 1988 caused both traffic and economic hardship to the surrounding community. This century old landmark literally opened North Brooklyn to Manhattan and, through the implementation of the extensive repairs contained in BR-253, will continue to serve the people of the City for at least a century to come. There must be safe traveling by pedestrians and bicyclists. An issue of particular concern is the upgrading of the pedestrian walkway that serves as a vital link with the Lower East Side. All efforts must be made to ensure the implementation of improvements, which should, as much as possible, aim to enhance security on these paths. This includes installation of emergency call boxes and cameras on these stretches. While so called improvements to this bridge are being made, it is distressing to see this landmark bridge being slowly dissected beam by beam to make way for a “highway type overpass”. The integrity and glamour of Roebling’s structure is being lost. Community Board No. 1 request the City to directly involve it with all discussions on repair, design and plans for all bridges in the district as they are being developed, not after the fact. We continue to support the safer methods and construction protocols that have come forward to remove lead paint, including testing and clean- up of any contaminants needed with this type of construction work. We urge continued adherence to these strict and comprehensive protocols in order to provide the best protection for our community’s residents as well as those who work here. (CONTINUED IN STATEMENT OF DISTRICT NEEDS)
Needs for Transit Services
(Excerpt from 2019 Statement of District Needs) MASS TRANSIT Before discussing the proposed reconstruction work that the MTA/New York City Transit is planning for the "L" train line's Canarsie Tubes, we will address the transit system as it currently stands. Mass transit is woefully inadequate to meet the needs of our district. Local bus service is frequently delayed because of overall traffic congestion. Overcrowding on the L train is so severe that riders often must allow 2, 3, or more trains go by before they can board; while on the G train, growing ridership is straining the limits of the current 4-car trains and the service schedule, which is that of a non-rush-hour service schedule. MTA- NYC Transit’s E/F/G/V service change in 2001, which terminated the northbound G line at Court Square on weekdays, interfered with many commutes; service has deteriorated further: the MTA indicated that the G would run its full route on weekends, but on any given weekend, that is not the case. G rides suffer from short, overcrowded trains and a halved line most of the time. For those North Brooklyn commuters who solely depend on the G, improved service must be a priority. The Board has read with interest – not to mention a sense of irony – that the V line has the lowest ridership in the entire system – lower, even, than the G line, which makes far fewer stops. In 2001, the G line was shortened from its then-6 subway car trains to its present 4-car trains in order to supply the newly created V line. The V line was so clearly underutilized since its inception and the crowding on the G has increased dramatically with no downward trend in sight. The V line was eliminated and the M train was rerouted to cover the service. The Board recommends that MTA-NYC Transit reallocate subway cars from the M line and return them to the G line to offer relief for G line riders. There needs to be better connection to trains that travel to and from Manhattan. The connection at Court Square for the G line remains inadequate and difficult to navigate. We continue to advocate that there be a free transfer between the G line and the elevated (J/M) line (Broadway/Hewes Street). During the work planned on the G line's Greenpoint Avenue Tube (it was badly damaged during Hurricane Sandy) the MTA announced that they would temporarily provide a free transfer between the G line and the elevated trains. We were pleased that the temporary extension of the G line that brought it further into Brooklyn was made permanent. The Greenpoint Avenue station on the G line needs to be upgraded to include a public announcement system as one is sorely lacking. Delays in service on the line leave riders at this station in the dark because there is no communication. Ferry service has resumed at the CB 1’s waterfront, with an expanded service. We ask that the ferry service be “hooked into” the NYC Transit’s fare system to allow payment by use of a MetroCard. In down times on the G, the ferry could serve as alternate mode of transportation to and from Manhattan, Long Island City or further into Brooklyn where they may stop. We are pleased that EDC have expanded the ferry service in our district making commuting to other boroughs more conducive. (SEE FULL DNS STATEMENT)
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/26
DOT
Other
Request: Install Surveillance Cameras for the
transportation
Williamsburg Bridge (Roadways, Walkway and
infrastructure
Bikeway). Explanation: The Williamsburg Bridge
requests
is heavily used by both vehicular traffic on its
roadways, and by pedestrians/bike riders on the
walkways. Enhanced security by the use of
surveillance cameras would increase the public's
safety.
7/26
NYCTA
Repair or upgrade
Request: Fund MTA/NYCTA Continuation of the
subway stations or
Station Upgrading Program (G, L, J, and M
other transit
Lines) to Also Include Surveillance Cameras for
infrastructure
"L" (Bedford Avenue Station) and "G" Lines
(Metropolitan Avenue/Grand Street/Lorimer
Street Station) and a Public Address System on
the "G" - Greenpoint Avenue Station.
Explanation: Fund continuation of the station
upgrading program, include camera
surveillance for added public safety and a public
address system at on the "G" Greenpoint
Avenue Station. Responsible Agency: Transit
Authority
12/26
DOT
Reconstruct streets
Request: Trench Restoration/Reconstruction for
Withers
Withers Street, between Humboldt Street and
Street
Woodpoint Road. Explanation: The roadway on
Humboldt
Withers Street, between Humboldt Street,
Street
between Humboldt Street and Woodpoint Road
Woodpoint
is severely deteriorated and sunken in, making it
Road
unsafe for both pedestrian and vehicular traffic.
13/26
DOT
Reconstruct streets
Request: Reconstruct Grand Street, from Grand
Grand Street
Street Bridge to River Street. Explanation: This
Metropolitan
piece of roadway receives much traffic and is a
Bridge River
truck route. The street needs reconstruction to
Street
correct several poor conditions that exist.
Responsible Agency: Department of
Transportation
14/26
DOT
Reconstruct streets
Request: Reconstruct Metropolitan Avenue,
Metropolitan
from Varick Ave. to River Street. Explanation:
Avenue Varick
This piece of roadway receives much traffic and
Avenue River
is a truck route. The street needs reconstruction
Street
to correct several poor conditions that exist.
Responsible Agency: Department of
Transportation
15/26
DOT
Reconstruct streets
Request: Reconstruct Meserole Street between
Meserole
Bushwick Avenue and Union Avenue.
Street
Explanation: Reconstruction of this street is
Bushwick
needed to prevent a future disaster. Currently,
Avenue Union
this street is in deplorable condition and in
Avenue
constant danger of a cave-in. Rampant truck
traffic throughout the district has severely
deteriorated the base of this street. Responsible
Agency: Department of Transportation
16/26
DOT
Reconstruct streets
Request: Reconstruct Driggs Avenue from
Driggs
Lorimer Street to Division Avenue. Explanation:
Avenue
Driggs Avenue is a very heavily traveled street in
Lorimer
the District. This stretch was not worked on in
Street
several years and is in poor condition. This road
Division
carries traffic that goes to the Williamsburg
Avenue
Bridge and is often used as a detour route.
Responsible Agency: Department of
Transportation
17/26
DOT
Reconstruct streets
Request: Reconstruct Montrose Avenue from
Monstrose
Union Avenue to Bushwick Avenue. Explanation:
Avenue Union
This street is a major connection from the
Avenue
western part of the district to East
Bushwick
Williamsburg. This heavily traveled street is in
Avenue
poor condition and requires reconstruction to
correct the many road defects and cave-ins
along the stretch of Montrose running from
Union Avenue to Bushwick Avenue. Responsible
Agency: Department of Transportation
18/26
DOT
Rehabilitate bridges
Request: Reconstruct and Widen the Grand
Street Bridge (aka Penny Bridge). Explanation:
This heavily utilized bridge is severely outdated
and presents hazardous conditions for vehicles
and pedestrians who use it. It is too narrow for
the passing of trucks at the same time (East and
West bound). Responsible Agency: Department
of Transportation
19/26
DOT
Reconstruct streets
Request: Reconstruct Scholes Street from
Scholes Street
Morgan Avenue to Union Avenue. Explanation:
Morgan
Scholes Street suffers from severe sinking of the
Avenue Union
roadbed along the stretch from Morgan Avenue
Avenue
to Union Avenue. It is in need of trench
restoration.
20/26
DOT
Reconstruct streets
Request: Reconstruct Lorimer Street from
Lorimer
Broadway to Nassau Avenue (Revised Limit).
Street
Explanation: This heavily utilized street, which
Broadway
serves as a bus route, has experienced extensive
Nassau
deterioration and now requires comprehensive
Avenue
reconstruction. Responsible Agency:
Department of Transportation
21/26
DOT
Reconstruct streets
Request: Reconstruct Frost Street and the
Frost Street
sidewalks from Debevoise Avenue to Morgan
Debevoise
Avenue Explanation: This roadway is in a state
Avenue
of disrepair and requires reconstruction.
Morgan
Avenue
22/26
DOT
Repair or construct
Replace sidewalks around Williams Plaza (aka
325 Roebling
new curbs or
Jonathan Williams Development/NCHA) from
St
pedestrian ramps
Division Avenue, South 9th Street, Broadway,
Marcy Avenue, Roebling Street, Havemeyer
Street. These sidewalks are in disrepair around
the development.
23/26
DOT
Reconstruct streets
Request: Reconstruct Maspeth Avenue, from
Maspeth
Vandervoort Avenue to Newtown Creek.
Avenue
Explanation: This section of Maspeth Avenue is
Vandervoort
in the industrial area and carries both truck and
Avenue
vehicular traffic. The roadway is in deplorable
Newtown
condition and requires reconstruction.
Creek
CS
DOT
Upgrade or create
Support of the Plaza Project at Moore Street
new plazas
Market.
CS
NYCTA
Improve
Request: Provide Funding for an Elevator for L
accessibility of
line at Bedford Avenue - ADA Access.
transit
Explanation: Community Board No. 1 is in
infrastructure, by
support of making the Bedford Avenue station
providing elevators,
of the L line more accessible to persons who
escalators, etc.
require ADA access in order to enter the transit
line. Responsible Agency: Transit Authority
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
16/25
DOT
Conduct traffic or
Request: Fund a Comprehensive Traffic Blue
parking studies
Print Study for Greenpoint-Williamsburg.
Explanation: A comprehensive study of traffic in
the district is needed. This Blue Print Study" is to
thoroughly assess the district and address
current and future transportation needs of
Greenpoint and Williamsburg. Responsible
Agency: Department of Transportation
18/25
DOT
Conduct traffic or
Fund a Greenpoint/Williamsburg Water
parking studies
Transportation Study, including ground/land
based connections.
24/25
DOT
Address traffic
Request: Increase Funds for Street Signage of
congestion
Truck Routes. Explanation: Community Board
No. 1 has a number of truck routes. However,
trucks often use other streets in the district to
travel. Signage is needed to keep trucks on their
designated routes. Additional signs are needed
to keep trucks off the residential streets.
Responsible Agency: Department of
Transportation
25/25
NYCTA
Other transit service
Acquisition of a replacement site for relocation
requests
of the MTA facility (Emergency Response Unit &
Depot of cross town buses) at 65 Commercial
Street.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 1
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park access and park facility access
(Excerpt from the FY 2020 Statement of District Needs) PARKS & RECREATION INCREASE STAFFING The over 110 acres of parkland situated in Community Board No. 1 represent an extremely valuable resource, the potential of which, however, remains to be realized due to the continued erosion of Park Department staff. Clearly, 29 “real” (1 manager, 3 supervisors, 1 full time gardener, 1 part time gardener, 23 other regular staff) maintenance workers cannot begin to supply even minimal coverage of our heavily utilized parks, and underscore the need to provide for the proper maintenance of these facilities. We currently have only 1 slot for workers (playground associates) who provide recreational services for youths and administer programs in the district. This playground associate is located in only one of our many playgrounds – totally insufficient to fully serve Community Board No. 1’s district. According to the 2010 census, our District contains over 51,600 residents who are 19 years of age or less, and hosts a heavily used regional park (McCarren Park). We have found that the number of children in the district is steadily increasing as can be seen with the corresponding increases of public and private school enrolled pupils (kindergarten – 8th grade). A minimum of 5 more supervisory staff positions and 30 employee staff positions are badly needed.
Specifically, additional maintenance staff must be assigned to the following facilities: McCarren Park, Cooper Park, Sternberg Park (Lindsay Park), Sgt. Dougherty (to be reconstructed with the Kosciuszko Bridge Project), P.S. 84 Playground, Martinez Playground, La Guardia Playground, Bushwick Houses Pool. Beyond this, it is essential that adequate recreation staffing is assigned to Metropolitan Pool and such major facilities as McCarren, McGolrick and Sternberg Parks. Finally, firm commitments to secure adequate, year round, recreation, security and medical first aid staffing at McCarren Pool is essential and must be made a very high department priority. (CONTINUED-SEE FULL STATEMENT)
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
PARKS & RECREATION RETENTION AND EXPANSION OF PARKLAND As the pertinent City Planning Department studies indicate, Community District No. 1 is one of the most under-served area with regard to park and recreation services. Thus, we would strongly oppose the elimination of any currently mapped parkland in our district or usage/renting of same for other than parkland/recreation unless as per current City policy, equivalent space is developed as parkland in the immediate vicinity. We also strongly support the establishment of additional parks and playgrounds within our borders. Community Board No. 1 continues its support for the development of appropriate small parks on triangles. The Southside and South Williamsburg have few local parks, and the triangles, such as where Heyward. Wallabout and Wythe Avenue come together, should be implemented. We have requested for many years that the concrete triangle at Meeker Avenue, Morgan Avenue and Driggs Avenue to be greened. We were pleased that the site finally received this treatment, but it has now been destroyed with construction signage from the Kosciuszko Bridge project. We are delighted to see that the Administration proposes the expansion of the Waterfront Park to the Bushwick Inlet and its initial phase has moved forward. This expansion proposal provides much needed recreational space for our residents and insures some greening of the waterfront (the former Sanitation Garage at 50 Kent Avenue was demolished and annexed as parkland/open space). The proposal also suggests the inclusion of a Waterfront Access Plan (WAP). While we support this concept, we most certainly want to be directly involved in the design process. The Administration should commence the condemnation procedures to demonstrate a good faith gesture to our community while carefully retaining jobs and relocating existing businesses. (SEE ATTACHED STATEMENT)
Needs for Cultural Services
No comments
Needs for Library Services
PUBLIC LIBRARIES - Community Board No. 1 contains four public libraries (Greenpoint, Bushwick, Leonard and Marcy Avenue branches) which provide a variety of services for the community. We support their needs for enhanced equipment, computer linkages, increased book budgets and physical improvements. The Leonard Branch has its elevator installed and is still seeking to construct a ramp as well as other sorely needed improvements for this aging Carnegie branch. We support their efforts to have the facility wheelchair accessible. Greenpoint Branch is an existing facility that can no longer accommodate the growing needs of the community in terms of function and programming and the construction of a new facility, on its current footprint, is being sought. We have learned that the work will commence on this project at the end of June. We urge that all efforts be made to accommodate the community with auxiliary service while the branch is closed. It is most encouraging to see that these facilities are being highly used by both young and older residents alike. CB 1 strongly opposes cuts to the budgets for our libraries.
Needs for Community Boards
COMMUNITY BOARDS Community Board No. 1 still lacks adequate funding. The meager budget provided for our board does not keep pace with inflation and any increased operating costs. The cost for acquiring much needed newer technology, computer software, upgraded hardware as well as internet/web access capabilities is expensive. Community Board No. 1 is always facing yet another round of budget cuts in the budget process. While restorations were made this fiscal year, we remain guarded about projected cuts for upcoming fiscal years. Community Boards have not really seen an increase in our budget in over 20 years. The increase this fiscal year was a temporary increase only. Our internal budget is not sufficient enough to meet the ever escalating costs of necessary office operations and staffing. The rapid changes in communications, media and computers, plus the costly upgrading of various programs and equipment would inhibit a Board’s daily operations whose insufficient budget covers a small staffing of only three persons (2 full-time and 1 part-time) and miniscule operating (OTPS) cost of $ 10,476. Our office carries out a myriad of services. CB 1 is the mini City Hall for our constituents. We handle complaints, provide comments on projects, land use and develop capital/expense budget lines for the district as well as conduct public hearings. We have 13 established committees that comprehensively tackle matters of concern and service delivery. Our staff also supports the board members in preparing reports, minutes, and scheduling of meetings.
Matters from the public are handled as well, these often range from simple point of information inquiries, "freedom of information (FOIL)", to major investigations requiring constant follow up! In addition, we have other operating tasks that are for specifically needed to administer the CB 1's internal operations. These include recordkeeping, timekeeping, budget preparation, monitoring & payment of expenditures, voucher preparation, inventory and auditing. SUSTAINABILITY OF COMMUNITY BOARDS Community boards provide a vital function for the districts they are designated to serve and consequently stand as valuable assets to the City as well. There is urgent need for increased funding as moneys were lost in previous budget crunches and were projected to be further reduced in the upcoming fiscal years. Community Board budgets should not be at the sole whim of the Administration. The NYC Charter’s language regarding community boards must be strongly re-written to ensure that community boards are fiscally protected and legislatively promulgated – the budgets must be held harmless from political climates. (CONTINUED IN THE DISTRICT NEEDS STATEMENT)
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/26
DPR
Other requests for
Request: Fund the Development of Parkland per
park, building, or
Greenpoint-Williamsburg Waterfront Rezoning
access
and the Administration's Points of Agreement.
improvements
Explanation: With the rezoning of the
Greenpoint-Williamsburg waterfront, the
Administration agreed to development of
parkland and stated commitment towards
building open space, waterfront esplanade and
continuous waterfront access (Water Front
Access Plan: WAP") as well as improvements to
McCarren Park and Pool. Responsible Agency:
Department of Parks and Recreation
4/26
DPR
Provide a new, or
Funding for the further development of
86 Kent
new expansion to, a
Bushwick Inlet Park (including
Avenue
building in a park
construction/expansion of the park itself; and
the remediation of the Bayside Fuel Oil site and
the CitiStorage site). This park was promised to
the community when the rezoning occurred on
the waterfront. The acquisition of the parcels
have moved forward and remediation of the site
is the next needed step in making the park a
true reality.
6/26
DPR
Reconstruct or
WNYC Transmitter Park is a very well used open
B385
upgrade a building
space on our waterfront. It does not have a
Greenpoint
in a park
comfort station that could accommodate the
Avenue
many users, including children and their
families. A comfort station is greatly needed on
the site,
24/26
DPR
Reconstruct or
Renovation of McCarren Park Handball Courts.
upgrade a park or
playground
25/26
DPR
Provide a new or
Restore and fund redevelopment of Sand Park,
expanded park or
under the Williamsburg Bridge. This park was
playground
basically abandoned over the years and subject
to storage by work contracted on the
Williamsburg Bridge.
26/26
DPR
Enhance park safety
Improved lighting at the Mt. Carmel Triangle
through design
Park and Monument (BQE Park).
interventions, e.g.
better lighting
(Capital)
CS
BPL
Create a new, or
Request: Replacement on Site of the Greenpoint
107 Norman
renovate or upgrade
Branch of the Brooklyn Public Library (at
Avenue
an existing public
Existing Footprint, 107 Norman Avenue, Corner
library
of Leonard Street). Explanation: The branch of
the Brooklyn Public Library that services
Greenpoint (107 Norman Avenue) is too small to
meet the needs of the growing population of
the neighborhood. This branch should be
expanded on site to provide enhanced services
at the building. Responsible Agency: Brooklyn
Public Library
CS
DPR
Reconstruct or
Request: Fund Needed Projects to Improve
110 Russell
upgrade a park or
McGolrick Park's Grounds, Infrastructure and
Street
amenity (i.e.
Play Areas. Explanation: McGolrick Park is in
playground, outdoor
need of major improvements. Funding must be
athletic field)
secured for the necessary capital projects for
the park's infrastructure and building. This park
hosts a landmark structure (its central Pavilion
Shelter) and two important historic sculptures.
Attention and funding is needed to preserve its
fine and unique character and ugrade its
infrastructure. Responsible Agency: Department
of Parks and Recreation
CS
DPR
Reconstruct or
Request: Expand Neighborhood Park and
upgrade a park or
Playground Restoration Program. Explanation:
amenity (i.e.
The Board strongly supports this positive
playground, outdoor
program which will provide both renovation
athletic field)
funding and staffing assignments for parks and
playgrounds targeted to be upgraded. We urge
that this project continues and expands in
FY2020 and hope that the specific facilities
recommended by the Board in our priorities will
be favorably acted upon. Responsible Agency:
Department of Parks and Recreation
CS
DPR
Provide a new, or
Request: Complete All Phases of Development
new expansion to, a
for the Waterfront Area/Parkland at: (a.) The
building in a park
Foot of Greenpoint Avenue - WNYC Transmitter
Park (Old WNYC Tower Area), (b.) Division
Avenue Ferry Park. Explanation: Complete the
upgrading/development of these parcels as
parkland for access to CB 1's waterfront.
Responsible Agency: Department of Parks and
Recreation
CS DPR Reconstruct or upgrade a building in a park
Request: Support Needed Improvements for Cooper Park. Explanation: The Parks Department has created a conceptual design for Cooper Park to enhance it and provided needed improvements. The plan is not fully funded and will proceed in phases. Phase I has received funding support from the council member and has started construction. Responsible Agency: Department of Parks and Recreation
image
CS DPR Enhance park safety through design interventions, e.g. better lighting (Capital)
Request: Provide Lighting for Tennis Courts at McCarren Park. Explanation: The tennis courts in McCarren Park are well used. Players have requested lighting to be installed at the courts so to allow playing to continue after dusk, especially during summer months when the weather cools in the evenings. Responsible Agency: Department of Parks and Recreation
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/25
OMB
Other community
Request: Increase Funds for Community Boards.
435 Graham
board facilities and
We Strongly Recommend that Boards' Budgets
Avenue
staff requests
be Increased. The 59 CBs Citywide Still Woefully
Lack Adequate Funding. They Need to be Able to
Hire Planners and Other Skilled Professionals to
Evaluate Development Projects Explanation:
Charter mandated Community Boards are vital
cogs in the City's operating process. Community
Boards play a formal role in decisions on land
use, have input on capital & expense budgets, &
monitoring of service deliver-essentially servings
as little "City Halls" for their communities. They
are responsible sounding boards for the local
elected officials and act in consultation with
them. They provide constituents an opportunity
to have their voices heard on numerous issues.
4/25
DPR
Provide better park
Increase significantly park maintenance funds
maintenance
and increase operations/recreation staffing at
specific CB 1 parks and playgrounds (including
support equipment). Include additional hours
for women’s swim time at Metropolitan Pool.
image
10/25
BPL
Extend library hours
Request: Expand Funding for Library Operations
or expand and
Brooklyn Public Library (Including Branches
enhance library
with CD1; Fund Extended Days/Hours; Fund
programs
Computer Catalogue and Increase Book
Budget). Explanation: We are aware that the
Brooklyn Public Library has, in the past, been
underfunded relative to the other NYC library
systems. We urge that this inequality be
completely eliminated and that a fair proportion
of the system's funds be allocated to CD1's four
local branches. Responsible Agency: Brooklyn
Public Library
13/25
DPR
Enhance park safety
Request: Expand Park Enforcement Patrol
through more
Project to Include McCarren Park (Including Park
security staff (police
Rangers). Explanation: In our view, McCarren
or parks
Park is a heavily utilized regional facility that
enforcement)
should receive an allotment of this patrol force
to provide increased security and supplement
the efforts of the overworked departmental
staff. Responsible Agency: Department of Parks
and Recreation
21/25
DPR
Other park
Request: Increase Funding for the Green Streets
programming
Program for Projects in CB1, Including the
requests
Much Needed Improvements and Fencing of
Park Triangles. Explanation: These
improvements made under the green streets
programs have benefited the community and
provided additional greening for the area that
has been lost due to the beetle (Asian Long Horn
Beetle) infestation. This program should include
areas that need improvements and fencing such
as the park triangles: Badame Sessa, Father
Giorgio, and the Memorial Gore at Maspeth
Avenue, Bushwick Ave./Metropolitan Avenue.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/26
FDNY
Provide new
Request: Creation of a New Firehouse in the
facilities such as a
North side Area. Explanation: The Greenpoint
firehouse or EMS
and Williamsburg communities are growing
station
greatly in population and new businesses. With
the pending rezoning and waterfront
development there is a tremendous increased
need for enhanced public safety. There is no
firehouse to serve the North side community
and the waterfront area. A new state of the art
facility that can house proper modern
equipment (such as ladders for high rise
buildings) should be created to better service
the community. Responsible Agency: Fire
Department
2/26
HPD
Provide more
Request: Fund Construction and Rehabilitation
housing for medium
of Subsidized/Affordable Housing, Including
income households
Waterfront and Upland Areas, in the
Community District 1 Area. Explanation: The
neighborhoods of Greenpoint and Williamsburg
possess critical housing needs and the allocation
of funds to provide affordable housing in the
district remains a vital concern of CB 1. It is
essential that adequate subsidies be allocated
to ensure balanced development of our
community. Responsible Agency: Department of
Housing Preservation & Develop
3/26
DPR
Other requests for
Request: Fund the Development of Parkland per
park, building, or
Greenpoint-Williamsburg Waterfront Rezoning
access
and the Administration's Points of Agreement.
improvements
Explanation: With the rezoning of the
Greenpoint-Williamsburg waterfront, the
Administration agreed to development of
parkland and stated commitment towards
building open space, waterfront esplanade and
continuous waterfront access (Water Front
Access Plan: WAP") as well as improvements to
McCarren Park and Pool. Responsible Agency:
Department of Parks and Recreation
4/26
DPR
Provide a new, or
Funding for the further development of
86 Kent
new expansion to, a
Bushwick Inlet Park (including
Avenue
building in a park
construction/expansion of the park itself; and
the remediation of the Bayside Fuel Oil site and
the CitiStorage site). This park was promised to
the community when the rezoning occurred on
the waterfront. The acquisition of the parcels
have moved forward and remediation of the site
is the next needed step in making the park a
true reality.
5/26
DOT
Other
Request: Install Surveillance Cameras for the
transportation
Williamsburg Bridge (Roadways, Walkway and
infrastructure
Bikeway). Explanation: The Williamsburg Bridge
requests
is heavily used by both vehicular traffic on its
roadways, and by pedestrians/bike riders on the
walkways. Enhanced security by the use of
surveillance cameras would increase the public's
safety.
6/26
DPR
Reconstruct or
WNYC Transmitter Park is a very well used open
B385
upgrade a building
space on our waterfront. It does not have a
Greenpoint
in a park
comfort station that could accommodate the
Avenue
many users, including children and their
families. A comfort station is greatly needed on
the site,
7/26
NYCTA
Repair or upgrade
Request: Fund MTA/NYCTA Continuation of the
subway stations or
Station Upgrading Program (G, L, J, and M
other transit
Lines) to Also Include Surveillance Cameras for
infrastructure
"L" (Bedford Avenue Station) and "G" Lines
(Metropolitan Avenue/Grand Street/Lorimer
Street Station) and a Public Address System on
the "G" - Greenpoint Avenue Station.
Explanation: Fund continuation of the station
upgrading program, include camera
surveillance for added public safety and a public
address system at on the "G" Greenpoint
Avenue Station. Responsible Agency: Transit
Authority
8/26
SCA
Renovate or
Request: Department of Education Projects
upgrade a middle or
Scheduled to Upgrade Schools in SD-14 to Start
intermediate school
or Complete this Year (for Example: Renovations
to Include Automotive Trades HS; 850 Grand
Street Campus; Van Arsdale HS). Explanation:
Many of the schools in the district are very old
and require modernization, upgrading of their
physical structures and/or replacements of
heating/cooling systems. Responsible Agency:
Department of Education
9/26
NYCHA
Renovate or
Redevelop NYCHA Playground on Roebling
Roebling &
upgrade NYCHA
Street and South 9th Street. This park is well
South 9th
community facilities
used by the community. The playground is aged,
or open space
in need of upgraded equipment and
unfrastructure.
10/26
SCA
Renovate other site
Request: Construct a New Schoolyard at PS 18
101 Maujer
component
(Located at 101 Maujer Street). Explanation:
Street
This elementary school accommodates many
Pre-K through 5th Grade students. Its
schoolyard is quite outdated with broken
concrete/asphalt areas. Renovations are needed
to modernize it (work should include the
installation of new play equipment and safety
surfaces). Responsible Agency: Department of
Education
11/26
SCA
Provide a new or
Request: Construction Proposed for a New
219 West
expand an existing
School (P.S./I.S. A New School (Elementary
Street
elementary school
School/Intermediate School - PS/IS) at the
Dupont Street Development Site. Explanation: A
new school is proposed at the development site
on Dupont Street. We urge that District 14 and
the District's CEC are consulted and play a lead
role with any planning for the school.
Responsible Agency: Department of Education
12/26
DOT
Reconstruct streets
Request: Trench Restoration/Reconstruction for
Withers
Withers Street, between Humboldt Street and
Street
Woodpoint Road. Explanation: The roadway on
Humboldt
Withers Street, between Humboldt Street,
Street
between Humboldt Street and Woodpoint Road
Woodpoint
is severely deteriorated and sunken in, making it
Road
unsafe for both pedestrian and vehicular traffic.
13/26
DOT
Reconstruct streets
Request: Reconstruct Grand Street, from Grand
Grand Street
Street Bridge to River Street. Explanation: This
Metropolitan
piece of roadway receives much traffic and is a
Bridge River
truck route. The street needs reconstruction to
Street
correct several poor conditions that exist.
Responsible Agency: Department of
Transportation
14/26
DOT
Reconstruct streets
Request: Reconstruct Metropolitan Avenue,
Metropolitan
from Varick Ave. to River Street. Explanation:
Avenue Varick
This piece of roadway receives much traffic and
Avenue River
is a truck route. The street needs reconstruction
Street
to correct several poor conditions that exist.
Responsible Agency: Department of
Transportation
15/26
DOT
Reconstruct streets
Request: Reconstruct Meserole Street between
Meserole
Bushwick Avenue and Union Avenue.
Street
Explanation: Reconstruction of this street is
Bushwick
needed to prevent a future disaster. Currently,
Avenue Union
this street is in deplorable condition and in
Avenue
constant danger of a cave-in. Rampant truck
traffic throughout the district has severely
deteriorated the base of this street. Responsible
Agency: Department of Transportation
16/26
DOT
Reconstruct streets
Request: Reconstruct Driggs Avenue from
Driggs
Lorimer Street to Division Avenue. Explanation:
Avenue
Driggs Avenue is a very heavily traveled street in
Lorimer
the District. This stretch was not worked on in
Street
several years and is in poor condition. This road
Division
carries traffic that goes to the Williamsburg
Avenue
Bridge and is often used as a detour route.
Responsible Agency: Department of
Transportation
17/26
DOT
Reconstruct streets
Request: Reconstruct Montrose Avenue from
Monstrose
Union Avenue to Bushwick Avenue. Explanation:
Avenue Union
This street is a major connection from the
Avenue
western part of the district to East
Bushwick
Williamsburg. This heavily traveled street is in
Avenue
poor condition and requires reconstruction to
correct the many road defects and cave-ins
along the stretch of Montrose running from
Union Avenue to Bushwick Avenue. Responsible
Agency: Department of Transportation
18/26
DOT
Rehabilitate bridges
Request: Reconstruct and Widen the Grand
Street Bridge (aka Penny Bridge). Explanation:
This heavily utilized bridge is severely outdated
and presents hazardous conditions for vehicles
and pedestrians who use it. It is too narrow for
the passing of trucks at the same time (East and
West bound). Responsible Agency: Department
of Transportation
19/26
DOT
Reconstruct streets
Request: Reconstruct Scholes Street from
Scholes Street
Morgan Avenue to Union Avenue. Explanation:
Morgan
Scholes Street suffers from severe sinking of the
Avenue Union
roadbed along the stretch from Morgan Avenue
Avenue
to Union Avenue. It is in need of trench
restoration.
20/26
DOT
Reconstruct streets
Request: Reconstruct Lorimer Street from
Lorimer
Broadway to Nassau Avenue (Revised Limit).
Street
Explanation: This heavily utilized street, which
Broadway
serves as a bus route, has experienced extensive
Nassau
deterioration and now requires comprehensive
Avenue
reconstruction. Responsible Agency:
Department of Transportation
21/26
DOT
Reconstruct streets
Request: Reconstruct Frost Street and the
Frost Street
sidewalks from Debevoise Avenue to Morgan
Debevoise
Avenue Explanation: This roadway is in a state
Avenue
of disrepair and requires reconstruction.
Morgan
Avenue
22/26
DOT
Repair or construct
Replace sidewalks around Williams Plaza (aka
325 Roebling
new curbs or
Jonathan Williams Development/NCHA) from
St
pedestrian ramps
Division Avenue, South 9th Street, Broadway,
Marcy Avenue, Roebling Street, Havemeyer
Street. These sidewalks are in disrepair around
the development.
23/26
DOT
Reconstruct streets
Request: Reconstruct Maspeth Avenue, from
Maspeth
Vandervoort Avenue to Newtown Creek.
Avenue
Explanation: This section of Maspeth Avenue is
Vandervoort
in the industrial area and carries both truck and
Avenue
vehicular traffic. The roadway is in deplorable
Newtown
condition and requires reconstruction.
Creek
24/26
DPR
Reconstruct or
Renovation of McCarren Park Handball Courts.
upgrade a park or
playground
25/26
DPR
Provide a new or
Restore and fund redevelopment of Sand Park,
expanded park or
under the Williamsburg Bridge. This park was
playground
basically abandoned over the years and subject
to storage by work contracted on the
Williamsburg Bridge.
26/26
DPR
Enhance park safety
Improved lighting at the Mt. Carmel Triangle
through design
Park and Monument (BQE Park).
interventions, e.g.
better lighting
(Capital)
CS
DOT
Upgrade or create
Support of the Plaza Project at Moore Street
new plazas
Market.
CS
NYCTA
Improve
Request: Provide Funding for an Elevator for L
accessibility of
line at Bedford Avenue - ADA Access.
transit
Explanation: Community Board No. 1 is in
infrastructure, by
support of making the Bedford Avenue station
providing elevators,
of the L line more accessible to persons who
escalators, etc.
require ADA access in order to enter the transit
line. Responsible Agency: Transit Authority
CS
BPL
Create a new, or
Request: Replacement on Site of the Greenpoint
107 Norman
renovate or upgrade
Branch of the Brooklyn Public Library (at
Avenue
an existing public
Existing Footprint, 107 Norman Avenue, Corner
library
of Leonard Street). Explanation: The branch of
the Brooklyn Public Library that services
Greenpoint (107 Norman Avenue) is too small to
meet the needs of the growing population of
the neighborhood. This branch should be
expanded on site to provide enhanced services
at the building. Responsible Agency: Brooklyn
Public Library
CS
DPR
Reconstruct or
Request: Fund Needed Projects to Improve
110 Russell
upgrade a park or
McGolrick Park's Grounds, Infrastructure and
Street
amenity (i.e.
Play Areas. Explanation: McGolrick Park is in
playground, outdoor
need of major improvements. Funding must be
athletic field)
secured for the necessary capital projects for
the park's infrastructure and building. This park
hosts a landmark structure (its central Pavilion
Shelter) and two important historic sculptures.
Attention and funding is needed to preserve its
fine and unique character and ugrade its
infrastructure. Responsible Agency: Department
of Parks and Recreation
CS
DPR
Reconstruct or
Request: Expand Neighborhood Park and
upgrade a park or
Playground Restoration Program. Explanation:
amenity (i.e.
The Board strongly supports this positive
playground, outdoor
program which will provide both renovation
athletic field)
funding and staffing assignments for parks and
playgrounds targeted to be upgraded. We urge
that this project continues and expands in
FY2020 and hope that the specific facilities
recommended by the Board in our priorities will
be favorably acted upon. Responsible Agency:
Department of Parks and Recreation
CS DPR Provide a new, or new expansion to, a building in a park
Request: Complete All Phases of Development for the Waterfront Area/Parkland at: (a.) The Foot of Greenpoint Avenue - WNYC Transmitter Park (Old WNYC Tower Area), (b.) Division Avenue Ferry Park. Explanation: Complete the upgrading/development of these parcels as parkland for access to CB 1's waterfront.
Responsible Agency: Department of Parks and Recreation
image
CS DPR Reconstruct or upgrade a building in a park
Request: Support Needed Improvements for Cooper Park. Explanation: The Parks Department has created a conceptual design for Cooper Park to enhance it and provided needed improvements. The plan is not fully funded and will proceed in phases. Phase I has received funding support from the council member and has started construction. Responsible Agency: Department of Parks and Recreation
image
CS DPR Enhance park safety through design interventions, e.g. better lighting (Capital)
Request: Provide Lighting for Tennis Courts at McCarren Park. Explanation: The tennis courts in McCarren Park are well used. Players have requested lighting to be installed at the courts so to allow playing to continue after dusk, especially during summer months when the weather cools in the evenings. Responsible Agency: Department of Parks and Recreation
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
OMB
Other community
Request: Increase Funds for Community Boards.
435 Graham
board facilities and
We Strongly Recommend that Boards' Budgets
Avenue
staff requests
be Increased. The 59 CBs Citywide Still Woefully
Lack Adequate Funding. They Need to be Able to
Hire Planners and Other Skilled Professionals to
Evaluate Development Projects Explanation:
Charter mandated Community Boards are vital
cogs in the City's operating process. Community
Boards play a formal role in decisions on land
use, have input on capital & expense budgets, &
monitoring of service deliver-essentially servings
as little "City Halls" for their communities. They
are responsible sounding boards for the local
elected officials and act in consultation with
them. They provide constituents an opportunity
to have their voices heard on numerous issues.
2/25
FDNY
Provide more
Request: Fund the Operations of a Newly
firefighters or EMS
Created Firehouse (FDNY) in the North side.
workers
Explanation: The closure of the firehouse at 136
Wythe Avenue serving the mixed-use north
community leaves this expanding residential
neighborhood without adequate fire protection.
Loft conversion and future development
planned for the waterfront will greatly increase
the population and businesses in the area
requiring fire protection. Responsible Agency:
Fire Department
3/25
HPD
Other affordable
Reinstate funding for the Greenpoint –
housing programs
Williamsburg Tenant Legal Fund ($2 million),
requests (expense)
including anti-harassment provisions per the
Administration’s Points of Agreement regarding
the Greenpoint-Williamsburg waterfront
rezoning.
4/25
DPR
Provide better park
Increase significantly park maintenance funds
maintenance
and increase operations/recreation staffing at
specific CB 1 parks and playgrounds (including
support equipment). Include additional hours
for women’s swim time at Metropolitan Pool.
5/25
DYCD
Provide, expand, or
Request: Increase Significantly the Department
enhance after
of Youth and Community Development Agency's
school programs for
Community Board Fair Share, After School, and
elementary school
Summer Recreation Funding Allocation for CD
students (grades K-
1. Explanation: Over 32% of CD1's population
5)
is 18 years of age or younger, and many of these
individuals require education, recreation and
counseling programs to enable them to escape
from an environment of crime and poverty. The
inadequate levels of Youth Bureau funding
available to CD1 severely undermines the ability
of these programs to effectively serve this
population. The significant expansion of all
Youth Bureau allocations should be
implemented as promptly as possible.
Responsible Agency: Department of Youth &
Community Development
6/25
HPD
Provide or enhance
Request: Increase Funding to Support Subsidies
rental subsidies
to Lower Rents for Senior Citizens to Reduce the
programs
Increase in Homelessness. Explanation: Increase
funding to support subsidies to lower rents for
senior citizens to reduce the increase in
homelessness. Responsible Agency: Department
of Housing Preservation & Development
7/25
DFTA
Increase home
Request: Increase Funding of Homecare Services
delivered meals
and the Homebound Meals Program.
capacity
Explanation: Increase funding of homecare
services and the homebound meals program.
Responsible Agency: Department for the Aging
8/25
HPD
Other affordable
Request: Create a New Fund for the Affordable
housing programs
Housing and Infrastructure Fund ($10 Million)
requests (expense)
Created Under the Administration's Points of
Agreement Regarding the Greenpoint-
Williamsburg Waterfront Rezoning. Explanation:
A new fund is requested. The Affordable
Housing and Infrastructure Fund ($10 Million)
was created under the Administration's Points
of Agreement regarding the Greenpoint-
Williamsburg waterfront rezoning. Proceeds
from this fund will only be available to
development parcels that make use of the
waterfront inclusionary housing program
referenced in the agreement, and that
participate in the esplanade transfer program
(as noted in the agreement's Open Space
section). Funds will be used to partially offset
site-specific infrastructure costs.
9/25
NYPD
Assign additional
Request: Provide Safe Street Crossing (NYPD
crossing guards
Crossing Guard Post) at Jackson Street &
Kingsland Avenue for Children Attending Various
Local Schools and Programs. Explanation:
Provide safe street crossing (NYPD crossing
guard post ) at Jackson Street & Kingsland
Avenue for children attending various local
schools/after school programs (St. Francis
Developmental School, PS 132, St.
Nicholas/Rosary Academy, IS 49 Campus, Grand
Street Campus/Beacon Program, IS 126/Beacon
Program, School Settlement House Association).
Responsible Agency: Police Department
10/25
BPL
Extend library hours
Request: Expand Funding for Library Operations
or expand and
Brooklyn Public Library (Including Branches
enhance library
with CD1; Fund Extended Days/Hours; Fund
programs
Computer Catalogue and Increase Book
Budget). Explanation: We are aware that the
Brooklyn Public Library has, in the past, been
underfunded relative to the other NYC library
systems. We urge that this inequality be
completely eliminated and that a fair proportion
of the system's funds be allocated to CD1's four
local branches. Responsible Agency: Brooklyn
Public Library
11/25
DOE
Provide more funds
Request: Fund New Science Labs for Schools
for teaching
(including middle schools)(District 14/Region 8)
resources such as
Located Within the Confines of Community
classroom material
Board No. 1 District. Explanation: New science
labs are needed in the various schools in our
District. The labs would provide new facilities or
replace outdated ones and utilize modern
equipment for instruction. Responsible Agency:
Department of Education
12/25
DOE
Provide, expand, or
Establish additional daycare or head start
enhance funding for
programs to serve Greenpoint/Williamsburg
Child Care and Head
that are now under-served.
Start programs
13/25
DPR
Enhance park safety
Request: Expand Park Enforcement Patrol
through more
Project to Include McCarren Park (Including Park
security staff (police
Rangers). Explanation: In our view, McCarren
or parks
Park is a heavily utilized regional facility that
enforcement)
should receive an allotment of this patrol force
to provide increased security and supplement
the efforts of the overworked departmental
staff. Responsible Agency: Department of Parks
and Recreation
14/25
DOE
Provide more funds
Request: Fund a New School Library for PS 250.
108 Montrose
for teaching
Explanation: A new library is needed at this
Avenue
resources such as
elementary school to provide an expanded
classroom material
reading facility and teaching resources.
Responsible Agency: Department of Education
15/25
DOHMH
Other programs to
Request: Fund Comprehensive Study of
address public
Environmental Health Hazards, Including Air
health issues
Quality and Asthma, to Learn Cumulative Effects
requests
on CB 1; Study Should Include the DEP Waste
Water Treatment Plant. Explanation:
Community Board No. 1 has been impacted by
many adverse environmental factors (i.e.,
Mobile Oil spill, toxic waste, transfer stations,
air pollution, etc.). A comprehensive study is
needed to assess these impacts and develop
resolutions, such as anti-asthma initiatives, to
be implemented. The Study should include the
DEP Waste Water Treatment Plant. Responsible
Agency: Department of Health and Mental
Hygiene
16/25
DOT
Conduct traffic or
Request: Fund a Comprehensive Traffic Blue
parking studies
Print Study for Greenpoint-Williamsburg.
Explanation: A comprehensive study of traffic in
the district is needed. This Blue Print Study" is to
thoroughly assess the district and address
current and future transportation needs of
Greenpoint and Williamsburg. Responsible
Agency: Department of Transportation
17/25
DFTA
Create a new senior
Request: Establish Senior Center to Serve South
Clymer Street
center or other
West Area of Williamsburg, Central to Division
Division
facility for seniors
Avenue and Clymer Street/Continued Funding.
Avenue
Explanation: At the present time, accessible
Bedford
senior center services do not exist for the
Avenue
expanding senior citizen population of the west
area of Williamsburg. Although we are aware of
the current funding constraints regarding senior
center services, the existing needs compel us to
support the establishment of such a facility in
the area central to Division Avenue and Clymer
Street. Responsible Agency: Department for the
Aging
18/25
DOT
Conduct traffic or
Fund a Greenpoint/Williamsburg Water
parking studies
Transportation Study, including ground/land
based connections.
19/25
DSNY
Provide more
Request: Expand Refuse Collection Program for
frequent garbage or
NYCHA and Other Large Housing Developments
recycling pick-up
to Schools & Senior Centers. Explanation:
Implementation of this request will provide
relief to the residents of Community Board No.
1's eight public housing developments (6,506
units); Lindsay Park Mitchell-Lama housing
(2,800 units), who suffer from chronically
inadequate refuse collection services.
Responsible Agency: Department of Sanitation
20/25
DOHMH
Provide more
Request: Increase AIDS Outreach. Explanation:
HIV/AIDS
Increase the staffing of outreach programs that
information and
handle education, testing and counseling for
services
infectious diseases (TB/AIDS/ZIKA) and drug
abuse. Responsible Agency: Department of
Health and Mental Hygiene
21/25
DPR
Other park
Request: Increase Funding for the Green Streets
programming
Program for Projects in CB1, Including the
requests
Much Needed Improvements and Fencing of
Park Triangles. Explanation: These
improvements made under the green streets
programs have benefited the community and
provided additional greening for the area that
has been lost due to the beetle (Asian Long Horn
Beetle) infestation. This program should include
areas that need improvements and fencing such
as the park triangles: Badame Sessa, Father
Giorgio, and the Memorial Gore at Maspeth
Avenue, Bushwick Ave./Metropolitan Avenue.
22/25
HPD
Other affordable
Increase allocation for rehabilitation loan
housing programs
programs.
requests (expense)
23/25
DOB
Assign additional
Continue/expand the building inspector training
building inspectors
program; increase the number of inspectors
(including
(DOB) for CB  1.
expanding training
programs)
24/25
DOT
Address traffic
Request: Increase Funds for Street Signage of
congestion
Truck Routes. Explanation: Community Board
No. 1 has a number of truck routes. However,
trucks often use other streets in the district to
travel. Signage is needed to keep trucks on their
designated routes. Additional signs are needed
to keep trucks off the residential streets.
Responsible Agency: Department of
Transportation
25/25 NYCTA Other transit service
requests
Acquisition of a replacement site for relocation of the MTA facility (Emergency Response Unit & Depot of cross town buses) at 65 Commercial Street.
image

