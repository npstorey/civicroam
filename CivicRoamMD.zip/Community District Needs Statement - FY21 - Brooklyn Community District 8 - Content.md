- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 8 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1gC9B60mYNLXezixL1ETc3s9oy299JHgF/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1gC9B60mYNLXezixL1ETc3s9oy299JHgF/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'',
Brooklyn Community District
8
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 8
image
Address: 1291 St. Marks Avenue Phone: (718) 467-5574
Email: brooklyncb8@gmail.com
Website: www.brooklyncb8.org
Chair: Ethel Tyus District Manager: Michelle George
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board No. 8 encompasses the neighborhoods of North Crown Heights, Prospect Heights, and Weeksville, and is bounded by Atlantic Avenue on the north, Ralph Avenue on the east, Eastern Parkway on the south, and Flatbush Avenue on the west. The District is rapidly evolving, and oftentimes unfortunately, not in a positive way. The battle of wills between long-time residents and “newcomers” to the rapidly gentrifying community are at an all-time high and are only increasing as new initiatives are implemented. The community once renowned for its cultural diversity and acceptance of differences now finds itself pitted against each other, with debates based on black/white, old/new, less affluent/very wealthy residents often at the forefront of the debates and resulting tensions. Swift and constant displacement of residents resulting from the conversion of rent-stabilized housing to luxury housing, development of luxury housing, the paucity of affordable housing, and property owners intent on maximizing profits serves to exacerbate tensions.
There has been an increase in mounting tensions between residents of different races, and it is very evident during conversations where "progressive" elements/changes/projects (i.e., Citi Bike, protected bike lanes, congestion pricing, residential parking permits) are discussed. Many of these changes are wrought by expansive gentrification and the addition of hundreds of units of luxury housing, that further serves to push out less economically advantaged individuals, thus leading the way for even more disparities between residents. Conditions causing gentrification like the increase in construction of luxury condominiums, construction of housing developments outside of the price range for long term residents despite their so-called "affordable" billing, conversion of two- family homes to multiple dwellings, rising rents due to increased property taxes in the historic districts, and oft- times the accelerated desire of property owners to maximize profits at the expense of comfort and decency, is causing noticeable shifts in the economic status, ethnic, and cultural make-up in the community. This in turn leads to increasingly taut tensions between longtime community residents and new residents, with the end result being a feeling of a "tale of two cities," where long-time residents indicate a belief that "progressive" tactics are being completed and implemented only to satisfy the desires and whims of new residents, or a belief that key infrastructural changes that Community Board 8 has clamored for repeatedly over time tend to only be addressed when new, often Caucasian residents bring the issues to the City's attention. Additionally, many life-long residents feel as though their needs are being flouted for the sake of the newer and often wealthier and affluent neighbors. Furthermore, more and more new residents are illustrating an insensitivity to the culture of their neighbors and apply pressure on city agencies to suppress the expression of these cultural staples. There has been a marked increase in complaints against black-owned establishments that have existed in relative harmony in the community for decades, and some of these business owners believe that the complaints are being made only because they are black. Complicating matters are new infrastructure installments such as bike lanes and CitiBike docks that are further alienating residents from each other and contributing to the divide. It is the goal of the District office of Community Board 8 to bring residents together on common issues and forge a bridge of understanding while attempting to stifle sentiments of entitlement that tend to infuriate those that believe they are less privileged and oft systemically oppressed.
Due to hyper development of underutilized lands based on zoning regulations, extensions on buildings in the historic districts, conversions of two-family homes to multiple dwellings, and of course, the Atlantic Yards/Pacific Park Project, the population of District 8 is rapidly growing. Rising rents are causing the merger of many families in smaller units and the need for apartment shares by those incapable of affording monthly rent rates without the assistance of their extended families and friends. With an increased number of people in a smaller space, it is imperative that recreational activities outside of the home be present within the community to provide mental health respites. Additionally, more and more families and younger adults looking to start families are moving into the district. The needs of children have been long ignored in our district with few resources allocated for their growth, development, and creativity. Thus, a need for greater child-based activities across a multitude of demographics has arisen and must be addresses quickly in a manner that allows everyone access regardless of their socio-economic status. Additionally, a trend has emerged where dogs have become a necessary accessory for life in Brooklyn, contributing to the need for activities for both humans and their pet companions. Occasionally, the tenuous balance between the needs of humans and the needs of humans with animal companions teeter on the brink of unstable, consequently creating additional friction, and accelerating animosity between residents across all backgrounds.
Commercial gentrification continues to plague our commercial corridors. Commercial gentrification is a term coined by District 8 staff several years ago to denote the shocking increase in rent in commercial spaces from one lease to the next that drive out businesses and keep stagnant the necessary assortment of businesses offering a consortium of services for the community with the ability to remain viable due to increased overhead costs. This trend toward higher monthly fees has led to an increase in the number of eating and drinking establishments and shrinkage in other boutiques/service-related businesses in the District. Competition for affordable commercial space is causing additional chasms to form between upper and lower tier businesses and creating an influx of businesses that require alternative money-making strategies such as possession of a liquor license or even illegal means to meet the high overhead operating costs. Unfortunately, this causes unsustainable competition between businesses and contributes to the rapid commercial turnover, and intensifies hostilities between residents, business owners, and patrons of eating and drinking establishments.
We understand that change is necessary, is not always linear, and is not always accepted by everyone. However, there are ways that an equitable as possible approach can be made to benefit as many as possible without disproportionately harming the most vulnerable. An alarmingly high decrease in truly affordable housing units available in the district, especially for seniors and low and middle-income residents; lack of quality medical services and hospital coverage; uncertain public school options due to constant school closures and co-locations; unaddressed mental and economic stresses amongst a multitude of the district’s population; and property owners willing to flout the city’s reach in terms of either recouping losses, maintaining habitable conditions, or even basic maintenance for public safety are issues all requiring ample priority and attention from government officials.
Consequently, we advocate for increased discussion amongst the various stakeholders in the community as well as District office staff, with input from our volunteer membership, when agencies seek to implement new changes as this will limit the ideation that the community has no input and will also allow us greater opportunity to mitigate any foreseeable issues that will arise. Hearing the concerns of everyone in a public, open forum would allow everyone to feel seen and heard, and dispel the notion that things are being done on a whim or at the behest of only a select few. Oversight city agencies such as HPD, DOB, and DOHMH must be allowed to institute substantial fines to encourage property owners to remediate areas of concern that warrant fines (such as active rodent complaints, unsafe construction practices, immoral tactics to force rent regulated tenants from their homes, etc.). Community Board No. 8 is committed to participating in the formulation of plans to address service delivery, housing, infrastructure and overall quality of life needs and concerns of the residents within the district. The furnishing of requests detailed within will facilitate achievement of Community Board No. 8's goals for Fiscal Year 2021 and beyond.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 8
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
Preserving the character of our community is one of our greatest priorities. Historic designation of multiple areas was designed to assist with this goal, and efforts continue to push toward expanded historic districts, including a recently proposed Prospect Heights Historic Apartments District featuring the apartment buildings on land initially set aside for the construction of Prospect Park. Unfortunately, a Landmarks Preservation Commission performing in a manner antithetical to historic preservation does little to protect the historic areas, and we are seeing more and more conversions of single-family homes into multiple condominiums with vertical and horizontal extensions which distract from the charm of other houses on the historic blocks. Also, historic designation for certain blocks does not protect the entire community from large scale luxury development designed for segments of the nation's population that is not native to New York City, nor is designed for the majority of those who have made Brooklyn Community Board 8 their home. Many of these developments serve to push out certain populations from the community, thus clearing the way for a new population of economically advantaged individuals and a much less heterogeneous populace despite assurances that the Mandatory Inclusionary Housing (MIH) will assist less wealthy residents. Already in certain communities, we are seeing a rise in homogeneity with few people of color in new developments. We maintain that development must be done in such a way that the neighborhoods are preserved and that truly affordable housing is maximized across all income bands and not just those earning at least 90% AMI that comes with an unsustainable rent burden. Construction focused solely on luxury branding have served to elevate rents not only across District 8 but New York City as a whole, and MIH is inarguably not working as intended to protect and create affordable housing. The affordable housing stock is being decommissioned at an elevated pace, but we hope that recently enacted rent laws at the state level will help with preservation since many incentives for pushing out long-term tenants have been rescinded. However, with that hope also comes the need for city agencies to provide protections for tenants that may fall victim to unscrupulous landlords that seek to engage in “demolition by neglect” tactics. Moreover, as pertains to Land Use trends, we have noticed an increase in conversions of single-family homes to multiple family homes (usually condominiums) in our District as vacant land is scarce but more property owners are selling and relocating to less expensive cities. These enlargement projects are deleteriously impacting adjacent neighbors with myriad forms of pollution (noise, dust/debris, air quality, light), damage to their foundations, and the result is usually a jarringly altered landscape to their surroundings with buildings antithetical to the charming aesthetic of Community Board 8. Increases in concerns of blocked light and air have flooded the District office in the years since the housing boom as more applictions for enlargements have been approved by the Landmarks Preservation Commission and the Dept. of Buildings for as-of-right projects. The majority of residents believe (usually not incorrectly) that these landscape changes are designed to alienate them from their sense of community and also destroy what little is left of the community. BK CB 8 has fought for the Crown Heights West Re-zoning proposal which was approved by the Dept. of City Planning in an effort to maintain the aesthetic of the district. However, and unfortunately, unforeseen consequences of the up-zoning have brought to light that more work needs to be completed and greater efforts need to be made to preserve the existing housing stock. Furthermore, the M-CROWN proposal that has been submitted to DCP continues to languish as the agency makes no movement on approving it, and private up-zoning applications are decimating the vision for the area bounded by Grand Avenue and Franklin Avenue from Atlantic Avenue to Bergen Street, with the two northerly blocks of Atlantic Avenue from Vanderbilt Avenue to Washington Avenue. Needless to say, our residents and members are concerned that our district is being abused by private development with the assistance of elected officials and the Dept. of City Planning as no movement has been taken on dispelling private interest, usually fueled by alternative interests to preserving jobs and the character of the community. Finally, existing large-scale development projects such as Pacific Park/Atlantic Yards Development, pose an ongoing nuisance condition in our community. Unfortunately, as these large-scale projects are usually not overseen by agencies of New York City and are instead, state overseen projects, city agencies are oft times unable to assist with resident complaints and
amelioration of issues. We urge the Mayor’s office to allow for additional oversight into these projects, specifically Pacific Park/Atlantic Yards, as there is scant community benefit while ongoing issues increase damaging effects on the quality of life for residents.
Parks
The state of New York sets a goal of 2.5 acres of open space for every 1,000 people, and the New York City average is 1.5 acres per 1,000. Unfortunately, due to enhanced development in the District, our residents are falling short with government mandates for open space. For instance, with its proposed 8 acres of open space, a fully built-out Pacific Park would have .36 acres per 1,000. However, the additional population of the District resulting from increased development and the Atlantic Yard Development Project/Pacific Park will actually decrease the ratio of public space available to residents in District 8. The ratio of active to passive open space would be substantially below the desirable range cited in the City Environmental Quality Review guidelines. As such, the need greatly exceeds the desire of residents for open space. We have noticed a trend with new developments creating “open space” on rooftops for with small, individual terraces. Unfortunately, these private spaces are nowhere near adequate to provide the recreational need required to maintain proper mental health. For decades, sanctioned studies have found that open space and recreational activities provides substantial mental respite to aid in creating a happier and healthier population. With myriad mental health issues on the rise, we advocate for the use of vacant lots for community gardens and open space areas to provide greenspace for resident enjoyment. Nature is healing, and the concrete jungle that is New York City requires as much open space as possible. As such, we also advocate for the City to provide incentives to property owners to create green roofs and participate in small scale urban gardening in their yards and roof space. This will have multiple beneficial effects across numerous areas of need, not relegated to only open space, but also dietary benefits, street release, etc. Gardening is an activity studies have shown decreases stress, aids relationship building, and also assists with certain other disorders; additionally, locally grown food allows for healthier meals and less exhaust from food delivery; plantings absorb rainwater runoff, and the rooftop gardens absorb sunlight and heat, lowering cooling costs. What the city loses in tax revenue to finance and subsidize the incentive program will be regained in other areas. Furthermore, those benefiting from the program will be healthier and likely happier, creating a more positive atmosphere in the city overall. Children will also be imbued with a healthy relationship with nature, the city’s wildlife population will have space to cohabitate with humans that have invaded and removed all of their space, and the like. Furthermore, a survey sent to residents in the summer of 2019 indicates that many residents are dissatisfied with the Parks Department’s handling of trees. Most residents are dissatisfied with the pruning schedule of trees, the inability of multiple agencies to work together to solve simple issues that merely require inter-agency cooperation (for instance, the Dept. of Transportation raising or lowering a street sign to prevent Parks from having to lope off half the canopy of a perfectly healthy tree for the sign to be visible; DOT adding a second arm to a street light should the adult healthy tree’s foliage block light, etc.). In addition to pruning, residents oft complain about the cleanliness (or lack thereof) of parks and playgrounds, the lack of lights, lack of parks enforcement, illegal activity, in parks and playgrounds, outdated play equipment and features, and the fact that parks are overrun with dogs off leash. Needless to say, we urge conversations between Parks officials, the Community Board staff, and residents to address many of the issues presented.
Infrastructure resiliency
Infrastructure and resiliency is not merely about reducing carbon emissions, heat absorption, reliance on fossil fuels, and standard combating of climate change. Focuses on infrastructure and resilience enters every facet of city life, even residual reach. For instance, the streets, sidewalks, bike lanes and bus stops in and around many sections of District 8 and especially the northern portion of Prospect Heights, are overburdened resulting in dangerous conditions to pedestrians, bikers, bus riders and drivers due to construction. Community Board 8 is fortunate to have an extensive bike network, with bike lanes on segments of all but 3 of our east-west lanes and an increasing number of bike lanes on north-south travel lanes. Unfortunately, residents have brought to the attention of the District office that they do not feel safe traveling in certain bike lanes due to vehicular traffic and bike lane blockages. Vehicle owners have expressed their frustration at what they believe are one-way programs designed only to limit vehicular traffic in an effort to reduce vehicle/pedestrian-bike collisions and fatalities, thus causing an undue burden as bikers are not held accountable for not following the rules of the road, and pedestrians are not held accountable for not being cognizant of their surroundings. We advocate for equitable traffic and transit studies so that no one population feels stressed, thus causing driver angst and leading to aggressive driving out of
frustration. While bike lanes are a wonderful addition to the streetscape, the reduction of travel lanes and the resultant squeeze of vehicles in less space has created an inorganic traffic condition that feeds the belief that vehicles are the sole source of the problem when the problem results from everyone on the road: bikers that disregard traffic laws and do not use lights/reflectors; pedestrians that do not pay attention to rules of the road and jaywalk, walk between cars, walk while distracted, etc. We all have a part to play in keeping our streets safe for all, and an equitable traffic calming project that does more than further box (and in the minds of drivers, penalizes) in drivers. Proper compromise should not result in sacrifice, but the general feeling of many in District 8 is that vehicles are sacrificing—and this sacrifice leads to resentment and aggressive driving, thus causing the potential for increased traffic incidents. Equity is key. Further increasing the need for equity are the many development projects ongoing in the District, which causes traffic nightmares for pedestrians, bikers, and vehicle owners. Especially at corner development sites and sites that block the sidewalk, numerous issues arise. Specific examples are the now completed project at 1525 Bedford Avenue, the ongoing project at 850 Washington Avenue, and the decades long nuisance Pacific Park Project. To provide perspective, specifically at the intersections of Bergen Street and Sixth Avenue and Dean Street and Sixth Avenue have poor or no sight lines, traffic lights are poorly coordinated, and double parking abounds on both streets due to construction at Pacific Park. At Washington Avenue and Lincoln Place, an entire lane and sidewalk has been removed; at the project site of the former St. Mary’s Hospital, for almost 9 months, the sidewalk on both the southern portions of St. Marks Avenue and Prospect Place, and also the entirely of Buffalo Avenue between the two blocks was closed and a narrow lane for pedestrian passage was erected in the street, limiting sight lines for the turning B15, and narrowing the travel lanes. There are bike lanes on the blocks of each of these projects, and bikers, pedestrians, and drivers were (and are) severely impacted. The expectation that people should not walk on the side of the street where construction is, is laudable but not realistic. Traffic remediation for these issues must be done immediately, and we encourage DOT and developers to review the conditions before agreeing upon a fencing plan. Understandably, safety is key; however, development sites must be amended accordingly with other agencies (such as the Dept. of Buildings that approves building plans) to limit the deleterious impacts on the streetscape during construction, especially those projects that will be underway for extended periods of time. Moving toward other aspects of resiliency, we applaud the bioswale/rain garden initiative implemented by the Dept. of Environmental Protection. However, we recognize that the program does not go far enough or extend well enough to assist with storm water runoff. Notwithstanding the decrepit look of many bioswales, the number of trees within them that have died in less than one season, the overgrown plantings, and the garbage and dirt that accumulates in them, we urge not only additional attention to be paid toe the rain gardens, but also an expansion of other programs to assist with storm water runoff. Int eh last twelve months, our District office has seen an increase in the number of complaints of flooded basements and sewer backups during heavy rainfall. Previous requests for incentives for homeowners to create greenspace on their properties and roofs have fallen on deaf ears. The desire of homeowners to concretize their property in a feeble effort to minimize rodent populations have only aided in the increase of storm water flooding and over burdening the city’s aging storm drain systems. We encourage the use of permeable concrete and walkways whenever the city does such work on pathways, and also any increase in plantings and shrubbery that can assist with water capture. Property owners with gardens, greenspaces, and greenroofs should be encouraged to use rain barrels to capture rainwater to water their plantings. Again, this will have many positive benefits that will immediately pay for themselves in other areas and eventually even financially. Housing remains a solid top two issue in BK CB 8—primarily affordable housing for those living below the 90% AMI percentile, which is roughly about half of the population of our residents. When people are forced to worry about their sustainable housing needs, they worry about other things as well. When people are forced to spend the majority of their income on housing needs, other aspects of their lives are impacted as well, and certain things, such as medical care and healthy eating, suffer as a result. Some psychologists focus on the Maslow Hierarchy of Needs to espouse the need for as few stresses as possible in the external environment to increase the mental fortitude of individuals. Maslow’s hierarchy states that the baseline needs, or the Physiological needs (which include shelter, air, water—or the basic needs for survival), that when met, allow for the recognition of the Safety/Personal needs (which include a feeling of security, improved employment, better health), which then leads to a greater sense of Love and Belonging, which improves relationships with friends and family, which then creates better Self Esteem (more respect for the self and environment/others, freedom, fortitude of judgment), and leads to the final tier of the pyramid, Self-Actualization, or the desire to be the best that one can be. If the baseline physiological needs are not met, individuals remain in a state of pain and mental crisis, and the results are catastrophic. Unfortunately, in District 8, and for a growing number of New York City residents, housing remains a source of great discomfort, thus leading to issues of concern across numerous areas of city life. If baseline needs are
not met, the result is usually an increase in mental health issues such as depression or anger related lashing out, increased crime, decreased productivity, increased substance abuse, increased cases of preventable diseases, increased discord between neighbors, and so much more. Continuing with resiliency and infrastructure, we believe that the core component to building a successful resilient community, is inter-agency cooperation and for the agencies to work together to ameliorate issues. For instance, rodent complaints have led the complaints fielded by the District office for the last three years. Second is overflowing litter baskets or the lack of litter baskets on street corners. WE believe these two issues are related. As garbage cans overflow, they provide a feast for rodents, which, if alternative food sources are available, will forego consuming bait and instead eat something else. The Dept. of Sanitation working in conjunction with the Dept. of Health on abatement measures would go a long way in dispelling the rodent epidemic. For instance, in areas with a high prevalence of rodent activity, additional litter basket collection can be added, additional litter baskets added, more monitoring for illegal dumping, greater enforcement for commercial streets with residential units that do not have proper garbage receptacles, and also the Dept. of health altering policy to have greater fines and/or reducing the amount of time for property owners to respond to summonses when rodent activity is found on their property to remediate the issues. The bottom line is that all agencies must work together to address issues of concern rather than single handedly attempting to only solve that which falls under their purview and thus ignoring issues that are cross-agency. Interagency cooperation is essential for resiliency and improved infrastructure.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 8
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
Community Board No. 8 has a high resident displacement rate due to rising rents, rising property taxes due to historic designation, and a gentrifying neighborhood. More and more of our residents are struggling to pay their rent and meet other monthly expenses. Increases in owner costs, or perceived increases due to not as high profit margins, are being transferred to tenants. We also have a large number of individuals living in homeless shelters and transitory housing that need permanent abodes. If services and legislation are in place to reduce the rates at which rents are increased and tenants forcibly displaced, we can help stem the tide of the path to homelessness, as well as reduce other burdens that residents face. Such programs are rental assistance programs, legislation that requires property owners that receive tax breaks on their property to maintain affordable units based on the community’s AMI, maintenance of rent-stabilized units, and assistance for tenants in rent-controlled and ren-stabilized units to combat landlord harassment and abuse. Residents that live in private houses not governed by rent stabilization laws are especially vulnerable, especially in a neighborhood that is ripe for speculators and developers seeking to take advantage of underbuilt homes and properties.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
We encourage additional one stop-shop clinics and health care centers that provide many if not all health care services of a hospital. Facilities such as these that offer health screenings, dialysis, astham treatment, walk-in services, etc., are a great addition to the community, especially since our District does not have a hospital. While we are not advocating for such small care medical centers to replace hospital care, they are convenient, easily accessible, and provide necessary services to many residents that otherwise would not seek medical care. In addition to these centers, we hope they will offer more comprehnesive mental health and substance abuse care/preventative services.
Needs for Older NYs
A growing and oft neglected population, our senior population requires special services and care that should come automatically to a class of well-deserving citizens. We need to recognize and reward the efforts and hard work of our senior population by providing them the fundamental means of existing above the Federal poverty line, which unfortunately for many seniors living in New York City, is not a reality with rising medical and health insurance bills and increases rent and property tax burdens. As proponents of elderly care and in recognition of the special needs of the elderly in District 8, we appeal to a course of action that will make this goal possible. More services focused on improving the quality of life, residential opportunities, home-care and health-care need to be provided by City- operated and neighborhood based agencies. Services should focus on the forgotten population that earns too much to be eligible for Medicaid, and consequently do not qualify for Medicaid paid services as well as those that earn too much to qualify for low income senior housing opportunities. We acknowledge the City's efforts to increase eligibility for certain services such as SCRIE and DRIE and property tax breaks by raising the maximum yearly income. However, more needs to be done as to be eligible for the programs, seniors must still bear a large cost burden. SCRIE and DRIE should be available to every senior, not just those that are paying more than 30% of their income in rent. Factors such as taxes on income, healthcare insurance costs, medical and prescription copays, basic necessities, and the like need to be factored in as well. Finally, an emphasis on home-care will help reduce costly institutional care and the burdens placed upon kin that serve as caregivers, and will also provide additional freedom to relatively self-sufficient individuals. Services for non-institutionalized seniors should include innovative senior
centers that instruct the seniors how to navigate the technological world, easily accessible and reliable transportation, truly affordable housing and housing security, prescription drug coverage and assistance, and other social and recreational activities.
Needs for Homeless
Affordable housing and limiting landlord greed will assist with dispelling homelessness.
Needs for Low Income NYs
As more and more people become economically unstable, it is imperative that adequate services be available for them to make their financial statuses more secure. Education and training programs, housing assistance programs, and cash and food assistance programs are all needed to help the economically vulnerable get back on their feet. Additionally, since cash strapped homes can lead to rising tensions between partners, domestic violence prevention programs are needed to dispel anger and angst that might otherwise be taken out on domestic partners. Feelings of inadequacy can arise from people that feel as though they are failing in their attempts to be good parents, partners/spouses, caregivers, etc., and thus can contribute to substance abuse related issues as a means of escapism. Support in areas of social services must include addiction treatment options and counseling to help people understand that their perceived failures are not worth the risk of their health, well-being, and relationships. Programs designed to assist with coping with issues often outside of an individuals control must be provided and easily accessible. HRA/DSS must work with DOHMH to create these programs. Finally, our elderly must be looked after. They must be cared for and their safety from abuse and predatory behavior ensured. Services to help educate them on signs and symptoms of elder abuse and scams are needed.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
1/43 DOHMH Reduce rat populations
With the large number of development projects scattered throughout the District, and renovation projects ongoing in our historic districts, the number of rodent complaints has skyrocketed with rodents more visible today than at any other time in the last two decades. A greater number of inspectors and exterminators are needed to quickly address baiting concerns and identify rodent havens and burrows for treatment.Residents overwhelmingly also support DOHMH implementing a policy change mandating that developers bait more than just the perimeter of their projects and instead bait a wider berth, as well as the city enforcing harsh penalties (such as liens) on properties that do not perform abatement.
image
4/43 DHS, HRA
Provide, expand, or enhance rental assistance programs
As rent rates in District 8 continue to increase, more and more families and individuals are on the verge of homelessness. Programs should be expanded to help them avoid entering the shelter system and becoming statistics. Rental assistance programs are in dire need to help cover the gap between affordability and unaffordable. The financial value of housing vouchers should be increased to match the rental rates that are being charged for units.
image
5/43 DOHMH Create or promote
programs to de- stigmatize mental health problems and encourage treatment
The stigma of admitting to having a mental illness is great, especially in immigrant and communities of color where sentiments such as "mental illness is not a disease you can afford to have," continue to be a plague. This stigma prevents those suffering from symptoms from seeking help. Programs such as THRIVE NYC are a great start, but the fear of being identified in the community as having an illness prevents many from seeking their services. More education on what mental illness versus what it is not is direly needed to help eliminate the negative stigma that is pervasive in many communities. An understanding of the different ways people can suffer from mental illness can go a long way in helping de-stigmatize the condition and also allow sufferers to seek help.
image
11/43 DOHMH Provide more
HIV/AIDS
information and services
While HIV transmission rates are down citywide, transmission of other non-HIV related diseases is on the rise, and in District 8, we rank in the top 10 in all categories of increased STD infection according to the latest Dept. of Health data. The fear of HIV and other STIs has been lessened over time because of new drugs created to help prevent infection and drugs designed to help a person live longer. Adequate education should be provided regarding the use of prophylactics and engaging in safe sexual practices to prevent the unnecessary spread of the disease.
image
14/43 DOHMH Promote
vaccinations and immunizations
Unfortunately, erroneous reports not backed by factual data have frightened some parents into declining immunization for their children. This practice puts other children at risk and also has the potential to bring back diseases that could actually be avoided via immunization and education. Factual data regarding the link between immunizations and autism is very necessary to prevent parents from making an uninformed decision that could have major deleterious ramifications on not only their children, but the broader community, especially as their non-immunized children become school age. Education and immunization promotion services are needed to deflate and eliminate these "alternative facts" and erroneous reports not upheld by factual science.
image
18/43 HRA Other domestic
violence services requests
Funding should be provided for preventative services to educate women and men of all ages on the telltale signs of all forms of abusephysical, emotional, sexual, and psychologicaland how to exit a situation that could be potentially life threatening, not only for her- or him-self, but for any children in the home as well. This will provide pre-emptive services and prevent further destruction of familial ties and bonds. Additionally, the necessary psychological counseling is urgently needed to ensure that past victims can prevent falling victim again in future relationships.
image
23/43 HRA Provide, expand, or
enhance adult protective services
We must keep in mind that our elderly population is at risk for abuse from family members and home health aides seeking to take advantage of their frail emotional and physical states. Our elderly population is the most vulnerable and often forgotten. They require considerable attention to maintain their safety and well-being, thus preventing them from being subjected to unnecessary hardship, pain, and mental aggravation in the form of fear.
image
24/43 DOHMH Create or promote
programs for education and awareness on nutrition, physical activity, etc.
District 8 is severely plagued by other health ailments including diabetes, heart disease, asthma, stroke, obesity, and many other conditions that require substantial medical care for those afflicted. The inability to afford healthy food options combined with the lack of healthy food options for residents on the eastern end of the district only compounds these problems.
Lower income residents without excess expendable cash should have access to quality fresh food and be trained in healthy living without exceeding their budget. Programs stressing proper nutrition should be provided for families as a preventive measure to stem the development of diseases caused by poor dietary habits and lack of exercise.
image
25/43
HRA
Provide, expand, or
Financial education and planning is direly
enhance
needed in less economically advantaged
educational
households. Due to the inevitability of having to
programs for adults
stretch their finances even further than they are
capable, it is imperative that residents have
access to financial planning and budgeting
information to learn how to properly plan their
monthly spending. They must be educated on
what is and is not a priority in order to avoid the
inevitable if they are not careful: homelessness.
People applying for one-shot deals to cover back
rent should automatically be enrolled in such
financial planning courses to obtain the tools to
prevent them from needing these emergency
services again.
30/43
HRA
Provide, expand, or
Not every person lacking job skills and basic
enhance job training
training for resume creation and interview
success tips lives within a NYCHA development
or is eligible to receive cash assistance. Job
training opportunities need to be expanded
beyond those living in NYCHA housing and
receiving cash assistance. These programs are
needed to help the underachieving gain self-
sufficiency and move away from a life living off
of other people and potentially public assistance
when they no longer have a support system.
33/43
DFTA
Enhance programs
Too often, our elders are too ashamed or afraid
for elder abuse
to speak up for themselves, leading them to
victims
suffer continued abuse at the hands of
caregivers or even strangers. We encourage
DFTA to increase outreach efforts and initiate
public service announcements to inform seniors
of their options and services should they ever
come face to face with elder abuse. We also
advocate for increased public awareness
programs to help people identify the signs and
signals of elder abuse.
34/43
DFTA
Increase
The elderly have a difficult enough time
transportation
traveling. Unreliable public transportation
services capacity
options are at times their only choice. An
increase in senior transportation, whether via
para transit or taxi vouchers, should be
provided--especially for those that live alone
and have minimal contact with the outside
world.
38/43 DFTA Enhance home care
services
Homebound seniors should not have to live a life of unintentional isolation because they are self-sufficient enough to be able to live on their own still. Medicaid ineligible seniors should not be forced to pay exorbitant out of pocket costs for assistance in day to day needs. We encourage increasing home care services for homebound seniors to include not only basic care and assistance, but also for interactive conversation and companionship to prevent the ails of isolation.
image
42/43 HRA Expand access to
public health insurance such as Medicaid
With the federal government extracting every ounce of worth from the Affordable Care Act, now more than ever, individuals in need of health care must have a viable option for health care than the skeleton plans designed to undermine what the ACA was attempting to accomplish. Decreasing eligibility requirements to receive Medicaid, or even having a payment system to make more people Medicaid eligible would help bridge the gap between those with quality health insurance and those without.
Costs of private markets are increasing
drastically due to cuts in federal subsidies and fewer people are able to afford private insurance. Having Medicaid as an option would allow access to the preventative care many people need to prevent grave illnesses.
image
43/43 DOHMH Promote Quit
Smoking Programs
Residents of multiple dwelling units face an oft times forgotten issue: any resident living next to or upstairs from a smoker, is subject to secondhand smoke, which studies have shown is more toxic than the primary smoke inhaled by the smoker. Residents should not be forced to endure health issues brought about by inconsiderate neighbors. As such, we urge the City to eliminate smoking in multiple dwellings and also increase awareness of the dangers of smoking, not only for the smoker, but also those subject to secondhand smoke.
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 8
image
M ost Important Issue Related to Youth, Education and Child Welfare
Other
Inclusionary programs designed to create an inclusive and positive environment for youth—anti bullying, suicide awareness and prevention, bereavement, conflict resolution—are essential in today's environment. While children have always been cruel, the proliferation of social media and entertainment platforms have accelerated bullying to levels not experienced by older generations. Additionally, with greater platforms for entertainment, youth are exposed to much more information with fewer parental restrictions as many parents simply are unable to keep up with current technological trends. As such, it is crucial that all children be given an inclusive environment where differences are celebrated and normalized rather than “othered.” The othering must cease, and it begins with youth. To aid in inclusion, it is imperative that sensitivity training via exposure to different things be integrated in educational and social programs at an early age. “Drag Queen Reading Rooms” are a step in the right direction, as are more intersectional reading materials in schools for students. The more exposure to things and type of people not necessarily in a child’s like only aids in and enhances their ability to be receptive to things unlike themselves, and consequently, foster acceptance. When more things are accepted and normalized, less bullying will be an immediate side effect. Suicide prevention and grief assistance are an essential facet of youth’s lives. Due to social media, negative news stories that many youth might relate to, are more prevalent than years past. As more gender and identity definitions are being brought to the public’s attention and more people feel comfortable being their true selves, it is only a matter of time before individuals incapable of understanding difference or things they do not agree with, begin to assail those that refuse to live in a prescripted box. Such youth need necessary outlets to provide safe spaces for them to be themselves and receive the encouragement and support they need to help assuage mental assails. Furthermore, as the media coverage around mass shootings increases due to the lack of gun control in the United States, grief and bereavement counseling is necessary to assist youth with dealing with stresses brought about my issues they should not have to think about—but cannot hide from.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
We urge the Dept. of Education to provide funds to upgrade the interior and exterior of our schools so that students will not be preoccupied or disheartened by dilapidated conditions, and also to create a curriculum that is conducive to structured learning and less frustration that focuses on inclusion and understanding of humanity. We encourage smaller class sizes for all grades as they are necessary to give each student an equal and ample amount of individual attention and one-on-one interaction with their teacher. Our children deserve and require a well-rounded education that includes not only the fundamentals of math, language arts, and reading comprehension, but also science, social studies, and the arts.
We support academic enrichment through creative expression, including but not limited to literature, crafts, dance, music and fine arts. Incorporating all of these disciplines helps to stimulate and enhance brain and logical thinking development, which fosters a more profound learning process in all areas. Furthermore, a broadened curriculum for foreign languages should be implemented in public schools to enhance an appreciation of the various cultural mores and customs that students will encounter throughout life, including the workforce. If the DOE notices that a particular charter school's curriculum is creating more successful students, we encourage implementing elements of that curriculum into that of the DOE's. Also, a set disciplinary standard should be implemented city-wide so that teachers know precisely what mechanisms are in place for handling unruly children. Teachers are not "glorified babysitters" and should be given the requisite tools to be successful in their duties.
Needs for Youth and Child Welfare
As the number of children in the foster care system rises, allowances must be made for resources for kinship care and foster parent training and recruitment services. Too many children are being forced into a system that cannot
protect them or look after them properly. Oftentimes, the conditions in group homes where children are placed until they find foster homes, or rather, IF they find foster homes, are more dangerous than the situation they were removed from. To make matters worse, ACS officials often remove children from homes when there is no actual cause for removal. Parents in situations like this should have some sort of recourse. While we acknowledge that there exist heinous cases where there is no other means to protecting the child, it must be noted that not every perceived case of abuse is an actual case of abuse. More focus should be placed on educating parents how best to care for and discipline their children in a rapidly changing climate where corporal punishment is viewed as abuse and cause for a child to be taken out of the home. Efforts should be focused more on keeping children in the home except in those dire cases where there is strong evidence that abuse and neglect is rampant and little to no regard is given to the child's or children's well being. We must remember that poverty does not mean that a child is improperly cared for or not loved. A spanking does not equal abuse. Case workers with ACS need to be better trained on recognizing actual cases of abuse and removing those children at great risk rather than removing all children because of protocol. As it stands now, parents are given no authority in their homes and are not given an opportunity to rear their children properly as they are fearful of penalties and fearful of children and youth recognizing that they are granted more power and authority than the parent. This leads to negative behaviors and acting out in many cases for our youth and with severe residual ramifications for the youth. As the number of children presently in the foster care system greatly exceeds the number of homes available, increased efforts must be made to provide the proper mental health care to prevent children from further losing a sense of self-image, self- worth, and their identity. Efforts must be made to assure children that their lives have meaning despite a lack of parental and familial influences. Identity crises and issues of esteem can easily form when children are institutionalized and begin to question the necessity of their existence. Unnecessarily removing children from a home when there is no evidence of actual abuse or endangering a child and sending said children to live in an institutional setting has the potential to affect their self worth and view of themselves and set their life on a tangential course that is dangerous and life threatening. It is critical that both group and one-on-one therapy sessions be provided immediately after removing the child to prevent these crises of identity from arising. In addition, programs for youth who are aging out of the foster care system are needed. These programs assist in the critical adjustment and transition period for youth who are forced to live and survive on their own with minimal to no supervision just because they have reached a "legal" age. It must be remembered that age of maturity does not always correlate with age in years. In order to assure that these individuals are able to live successfully without resorting to crime, programs must be instituted to assist them with job training and placement, money management, higher learning, and the like.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
5/14
SCA
Renovate or
Provide a new PA system, new classroom doors,
1580 Dean
upgrade an
a new cafeteria floor, new curtains for the
Street
elementary school
auditorium, and a new gymnasium floor. The
current PA system does not reach the entire
building, the doors do not close all the way so
they cannot be locked, the tiles are buckling in
the cafeteria, and the gym floor cannot be
sanded again. These are the specific requests
from the school. SCA last year stated that it
unable to prioritize funding for these requests.
However, in the wake of multiple school
shootings and unnecessary student deaths, it is
imperative that the PA system and properly
functioning doors be provided. How will SCA
explain student deaths because the doors were
unable to close and lock and an announcement
of an emergency situation unable to be made?
6/14
SCA
Renovate or
Provide new electrical system throughout the
130
upgrade a middle or
building, modernize/update the auditorium,
Rochester
intermediate school
provide new tables for the lunchroom, install
Avenue
new doors with locks, upgrade pipes/water
system in the building. These requests were
made by the school directly. Last year, SCA
stated that funding for part is recommended.
What part, and when will it be completed? In
the wake of the massive amount of school
shootings in recent months, it is imperative that
every school be equipped with doors that are
able to close and lock in a hurry as this can save
lives. How will SCA explain the loss of life if a
shooting occurs in a school and tens of children
murdered simply because the door to their
classroom could not lock?
CS
SCA
Provide a new or
We thank the DOE and SCA to agree to create a
37 Sixth
expand an existing
designated District 13 middle school in the B15
Avenue
middle/intermediate
building of the Atlantic Yards/Pacific Park
school
Development. We look forward to the school's
design and completion, and the great impact it
will have on the parents of middle school
students in Prospect Heights.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
17/43
ACS
Provide, expand, or
With the passage of Raise the Age legislation,
enhance preventive
many of our youth are now presented with an
services and
opportunity to receive services necessary for
community based
their continued community presence within
alternatives for
their home communities. With ATS options,
youth
youth can receive the mental health services
they need, training, mentoring, and counseling
services to begin the process of properly
integrating into the community to build social
capital. Intervention programs are key to
helping reduce the number of youth straying
toward incarceration, and programs geared
toward this end are necessary.
26/43
DYCD
Provide, expand, or
Early intervention is the key to saving the future
enhance skills
of our youth. It is well documented that inner-
training and
city children have a higher risk for crime,
employment
dropping out of school and other educational
services for high
deficits, gang involvement, drug use, and
school students at
incarceration. We urge funding for activities
risk of dropping out
that target at-risk youth. Funding for youth
development and delinquency and prevention
programs is necessary to serve our youth and
quell the growing trend toward life-ruining
activities.
27/43
DOE
Expand or improve
It is regrettably laughable that the DOE would
nutritional
state that it is committed to providing healthy
programs, e.g.,
food choices and maintaining high nutritional
school meals
standards by offering delicious and attractive
menu options, and that their nutritional
standards always meet, and many times exceed,
USDA Nutrition Standards for school meals. If
that were the case, would students be served
unappetizing and fattening meals that are
moldy, unidentifiable meats, spoiled milk,
expired and moldy juice, and foods that are so
hyper processed, they cannot even pass as the
substance they claim to be? Numerous news
exposes based on the 2017 investigation of the
DOE food program speak a different tune to
what the DOE claims, and this lack of honesty
within the agency is disheartening.
31/43
DYCD
Provide, expand, or
Primary school is an important time in our
enhance after
children's lives. It is in primary school that the
school programs for
foundation for education is laid. After school
elementary school
programs are effective tools in enhancing and
students (grades K-
enriching education as well as providing social
5)
skill building opportunities.
32/43 DYCD Provide, expand, or
enhance street outreach services
A large portion of homeless youth belong to the lesbian, gay, bisexual, transgender, non binary, non conforming, and queer (LGBTQ) population. They are often ostracized and shunned by their families and are forced to choose to either be comfortable with who they are or change/hide/pretend to be someone they are not simply to continue receiving familial support. In order to be true to themselves, they leave abusive situations and are forced to the streets. Efforts should be made to reach out to these youth to remove them from abusive situations and prevent them from becoming part of the growing homeless population.
image
39/43 ACS Provide, expand, or
enhance primary prevention services to strengthen families
Families need certain tools to learn to get along. Intergenerational assistance is needed to help bridge the gaps between younger and older generations that, to be blunt, do not understand each other. Children these days have the mindset that a parent is supposed to be a friend, and because parents are afraid of legal repercussions for reprimanding their children the way they were, attitudes are often left unchecked, which can cause friction in the home. Children, parents, and extended family need to be educated on the modern family structure and what the new social "norm" is for family ties.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 8
image
M ost Important Issue Related to Public Safety and Emergency Services
Police-community relations
While crime is down overall in District 8, we have experienced a major increase in violent crime and homicides in the first 10 months of 2019. Murders and gun violence has increased by 600% on the year. Residents have noticed that minor crime that not many care about is down, but believe the two precincts covering our district, the 77th and 78th Precincts, are doing insufficient work to ameliorate the rising tide of fear inducing crime. Unfortunately, many residents, usually minority residents, believe the opposite, that the NYPD is unfairly targeting them and their businesses because they are minority. Coupled with the fact that a substantial amount of resources have been allocated to keep a police sentry outside of the entrance to Stroud Playground on Park Place between Grand and Classon Avenues as a result of “shots fired” and multiple shootings have occurred at the less affluent St. John’s Park where individuals were actually hit with bullets and that park received only stadium lights, it is concerning that the optics lead one to put faith in these beliefs of minority residents. Stroud Playground received an ARGUS camera that was installed over the summer and still maintains a police sentry more than seven months after shots fired, yet portions of the District where crime and shootings are rampant (usually centered along the eastern end of the district) have not received additional resources. Furthermore, the feelings of harassment by our minority proprietors at the hands of the NYPD is cause for concern as MARCH operations (Multi-Agency Response to Community Hotspots) appear to not have a stable and consistent basis for determining which establishments should be “raided.” Multiple establishments state they are unfairly targeted because their clientele is minority, yet non- minority owned establishments with greater traffic and noise concerns are not targeted. We urge more transparency when it comes to MARCH operations and how establishments are chosen for the visits. Furthermore, we encourage more community outreach outside of the Neighborhood Coordinating Officer (NCO) Program with our residents. The extensive pressure placed on NCO officers can lead to burnout, a lack of desire to adequately interface, possible misuse of resources, avoidance, or a lack of regard for the issues that NCO officers should receive assistance with but are not. Additional foot patrol is necessary as is a greater visible presence of the Community Affairs unit at local precincts. That being said, we applaud the NYPD and the success of the NCO program; however, we acknowledge that just like with ever new program, there are growing pains and adjustments that must be made. The same is true with the NCO program, and we hope the NYPD enhances the program by adding additional officers to each section in each precinct and enhance foot patrol as well so that the burden of policing an entire segment of a command does not fall solely on the shoulders of two officers.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
While our police Comp Stat numbers reflect an overall decline in crime, residents will tell a different story: that crime is increasing or at the very least, remaining the same, especially in the eastern portion of the District. The eastern side of Community Board 8 is more heavily populated than the western and central portions because of NYCHA developments and large apartment buildings in addition to the private single to four family houses. There is still a need for additional patrol in the area bounded by Troy Avenue and Ralph Avenue from Atlantic Avenue to Eastern Parkway. The blocks of Sterling and Park Places in this area are especially problematic. Consequently, additional police officers are needed for the 77th and 78th Precincts and PSA 2 to effectively monitor the community and NYCHA developments in our District and to put additional officers in these problem areas. It is troubling to hear that multiple sex trafficking rings were discovered in District 8. We need to monitor the situation closely to ensure that women, especially underage women, are protected from sexual predators. Our local precincts need to monitor constant traffic at locations and listen closely to resident complaints that houses are being used for nefarious purposes. We encourage the NYPD to work closely with the Kings County District Attorney's office to educate the public on the signs of sex trafficking so that the public can assist in identifying problem locations.
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
14/14 NYPD Add NYPD parking
facilities
With the construction of Pacific Park around the 78th Precinct, there is a dearth of parking spaces available for officers of the precinct. The 77th Precinct also lacks adequate parking spaces and the result is officers angle parking on the sidewalk in front of private homes, double parking on residential streets, or disobeying alternate side parking rules. We urge the officers of the 78th Precinct to utilize the parking spaces that have been set aside for their use in the Pacific Park project at 535 Carlton Avenue.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
10/43
NYPD
Increase resources
We advocate for the NYPD to do an analysis of
for youth crime
youth crimes by precinct and fund programs in
prevention
those areas with high rates of youth crime to
programs
help stem the increasing numbers of young
people in youth detention centers.
28/43
NYPD
Assign additional
While we are aware that staffing levels are
staff to address
allocated based on graduating classes and
specific crimes (e.g.
Administrative processes, there is an inherent
drug, gang-related,
need for undercover officers to assist with the
vice, etc.)
growing gang population on the eastern end of
the District, and vice offices to address the
increasing sex trafficking operations in CB8.
Additionally, an increase in street drugs to
compete with not as easily available
prescription drugs, has led to more drug houses
in our community. Undercovers are needed to
infiltrate these rings and close these houses
down, thus making the community safer for all.
A great benefit of the closure of these drug
houses is also the reduction of opioid drugs
readily available to the seeking public. Finally,
additional detectives are needed to investigate
crime.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 8
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Other
It is difficult for District office staff to isolate one core area on which to focus in terms of resiliency, core infrastructure, and city services. Due to rampant development, multiple nuisances resulting from construction have arisen as have other health concerns. Construction causes a disruption in rodent burrows, sending them scurrying to other areas to escape the vibrations. While New York City has always had a large rodent population, construction and renovation projects have run them from their underground homes and onto the surface—into sight. We can no longer say “out of sight, out of mind,” as rodents are visible even during the day time hours for what are usually nocturnal beasts. Furthermore, construction has created additional nuisances such as noise and dust and the increased number of after hours variances yields less rest from construction that residents can obtain. We have also received an increase in different types of pollution complaints that we had not received in the past, with this year alone receiving three “light pollution” complaints from residents whose abode is across the street from or next door to a new construction building that employs daylight running lights embedded in the building that are excessively bright. No agency—Dept. of Buildings, Dept. of Transportation, or the Dept. of Environmental Protection—has been able to assist us with resolving the light pollution complaints and residents have suffered as a result. Unfortunately, it appears these types of bright lights may well be a trend toward removing residents from rent stabilized buildings that have not been converted for market rate rentals yet by nuisance complaints that are slow to be resolved.
Furthermore, as more residents move into the community as single-family homes are converted to multiple dwelling abodes, trash generation is heightened. Unfortunately, for much of 2019, the Dept. of Sanitation suffered from an equipment shortage that resulted in garbage being left on the street for longer than residents are accustomed. This did not go well in District 8 and the level of dissatisfaction with municipal service delivery was not hidden. We recognize the hard work of our fellow service members in other agencies, but we urge department commissioners and the Mayor’s office to be honest and upfront about agency-wide issues to help generate and maintain patience amongst residents when they believe their needs are not being met. Lastly, a burgeoning nightlife scene in District 8 as more and more commercial spaces are being rented for eating and drinking establishments, it is essential that the delicate balance of residential needs and commercial needs is maintained. We do not expect bars and restaurants to be entirely quiet and not produce noise; however, we appeal to agencies to do a better job of responding to noise complaints so that proprietors do not feel empowered to disregard their neighbor’s needs.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Complaints of flooding in the basements of homes in the District are increasing as are ponding complaints around certain intersections and uneven roadways. The Right of Way Bioswale installation projects occurring throughout the city are designed to assist with runoff and flooding for sewers not equipped to handle the quantity of water running through the system. Unfortunately, these bioswales are neither well maintained nor adequate to handle the growing strain on our sewer. We hope that the city allocates funds to implement other methods to employ to assist with runoff and sewer capacity such as providing incentive for homeowners and developers to create green roofs or green areas in their yard spaces. Many residents prefer to concrete over their front and back yards in an effort to reduce the possibility of any vegetation attracting rodents. What is not understood is that all of this concrete is impermeable and increases the runoff to the sewer. We need to incentivize residents to have as much green space and vegetation on their property as possible to help absorb rain water, while providing a valuable environmental benefit. Unfortunately, this form does not allow us to specifically request funding for the maintenance of bioswales or funding for homeowners to create green roofs or gardens. However, to reiterate: we advocate for incentives for homeowners to create green roofs and as much vegetation on their property as possible to absorb rain water. We also advocate for increasing the size of tree pits to not only allow for root growth, but also to increase the amount of permeable surfaces in the city's concrete jungle.
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
16/43
DSNY
Increase
Illegal dumping creates blight and makes it
enforcement of
appear as though the community does not care
illegal dumping laws
about itself. As it stands, existing resources are
not sufficient to stem this tide of community
blight. Illegal dumping must be stopped and
penalties strengthened for those that illegally
dump waste. Because current laws target those
that dump from vehicles, black market dumpers
that use shopping carts and dump near corner
baskets are often overlooked. These dumpers
need to be penalized for their actions. It should
not be acceptable for them or anyone else to
dump on our streets and feel as though they can
get away with it.
20/43
DSNY
Other cleaning
Provide enforcement for proper commercial
requests
trash receptacles for mixed-use buildings along
primary and secondary corridors. Mixed-use
buildings without trash storage receptacles for
residential use cause an alarming rate of corner
basket misuse. Residential tenants that have no
location within their premises to place their
garbage, are led to place their household trash
in corner baskets, or, in instances when a corner
basket is not present, simply leave their trash
bags on the sidewalk in an area it does not
belong. Proper enforcement of
container/receptacle laws will help eliminate
this cycle, and also potentially lead to a
decrease in vermin along commercial corridors.
21/43
DSNY
Provide more
While we have been assured that our
frequent litter
commercial strips receive 6 day a week basket
basket collection
collection, we constantly receive complaints of
overflowing baskets that have not been
collected and dumped in days. These complaints
are usually from residents in and around the
vicinity of Vanderbilt and Washington Avenues.
We urge additional litter basket collection, the
addition of extra baskets where necessary, and
the monitoring of existing baskets to ensure
that they are not being improperly used.
29/43 DSNY Provide or expand
NYC organics collection program
Separate organic collection is useful in diminishing the amount of trash sent to landfills daily. We are highly disappointed that the City discontinued organics collection because it did not properly plan an effective strategy for collection. Organics collection can not only save the city millions of dollars a year, but can actually allow the city to profit from the collection. Organic waste can be broken down by biodigesters and the compost sold to other municipalities for their fertilizer needs. We urge the city to re-institute organics collection.
image
35/43 DSNY Increase
enforcement of canine waste laws
It is imperative that Pooper Scooper laws be enforced and that signs alerting dog owners that it is their responsibility to clean up after their dogs are installed. AS A RESULT, WE ARE ASKING THAT FUNDING TO RE-INSTATE THE SIGNAGE UNIT BE PROVIDED. Furthermore,
additional Sanitation Police Officers are also needed to issue summonses to dog owners who do not clean up after their dogs as canine waste has the potential to create health hazards for humans and other dogs. Dog owners must be held responsible for properly caring for their pets.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 8
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Housing support (including tenant protection)
We question the effectiveness of Mandatory Inclusionary Housing and the affordable housing it claims to provide. The myriad options given to developers often means that the poorest residents are further alienated from housing as most developers participate in Options 2 or 4, which allows them the greatest amount of rent and return on investment (ROI) while not providing housing that is affordable to the residents of the community they are developing. Furthermore, we believe it contributes to gentrification and further landlord harassment as property owners near development sites realize that they are being denied additional income from their rental properties. We urge the Mayor and HPD to take look at the options available in MIH to encourage greater units set aside for Options 1 or 3, to accommodate the need for ELLA (extremely low and low affordability) housing—which is the greatest need in District 8. Secondly, NYCHA residents should not suffer the indignities they suffer. Many conditions are appalling and quite frankly, border on the criminal. Just because people lack financial wealth does not mean they should be forced to live in subpar living conditions. Demolition by neglect of NYCHA units at the hands of government officials (City, State, and Federal) is disgusting and we urge officials to investigate why repairs take so long and are completed so shoddily. If basic maintenance is completed, then the need for large capital projects will be less prevalent over time. Unfortunately, as many NYCHA residents state, “we are poor, so no one cares about us,” it begs the question whether or not our elected officials actually honor that thought since little to no movement has been made in terms of basic repairs to restore habitability to units. When people feel good about their environment, they feel better about themselves and have more respect. The conditions of many NYCHA units are conditioning residents to believe that respect is not a necessity of life, and as such, oft-times, the most vulnerable are roped into enhancing “broken windows theory” as the theory relates to the image of the self, resulting from the home environment. Finally, while we understand that development is a form of progress and that progress sis not always linear, we urge officials to work with residents and the Community Board to determine the best land use trends for the neighborhood. Bringing the Community Board in after a project has been certified disallows for adequate input by the boards, whose members and residents are in the best position to alert developers of the actual needs of the community. We encourage broader ULURP participation at an earlier interval, and also request that that Dept. of the City Planning listen to concerns and alter plans and designs rather than forcing on the Board their own vision based on a limited scope of understanding/limited scope of interest and insulting to the residents that are disproportionately affected by their policies.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
We urge the City to consider using derelict, fallow housing for affordable housing opportunities rather than attacking community gardens and taking away green space for small scale development projects. Property owners should be held accountable for their property and should know that if they refuse to take care of it, there is the possibility that they can lose it to address a grave need at truly affordable rates, not inflated rates that are grossly unaffordable. We believe that a proper accounting of vacant NYCHA units should be done, especially considering the dire need for affordable units. The units that are deemed uninhabitable because of various repair needs need to be fixed and made available for occupation as soon as possible. It is saddening that we have thousands of families living in temporary shelters when there are over 4,000 vacant NYCHA units that could be used for permanent housing if only they were habitable. Demolition by neglect is inhumane and immoral, and should be deterred by any means necessary. We need our local lawmakers to seriously consider the issue of arbitrary market rate rents that developers force on a community. The city needs to take a hard line stance on the amount of rent that can be charged to prevent displacement of residents. Following the federal guidelines for the Area Median Income is not
feasible in a city with a high standard of living such as New York City. Competition is great for the few so-called affordable units that are available, and the families most in need are ineligible usually because of poor credit. With HUD proposing to increase the burden of responsibility to 35% of income, the strain on already struggling families is merely going to increase. Our elected officials need to step in and institute policy changes that address the glaring and blatant greed of developers that are decimating the housing market in New York City. We believe that the Mayor and City Council have the ability to enact legislation that can help reduce this financial burden by capping rent rates that developers can charge, especially when they enter certain underdeveloped or underprivileged communities. No one should be at risk of displacement, and consequently, our local government needs to do a better job of ensuring that no one faces this danger.
Needs for Economic Development
The revitalization of our commercial strips is one of our top priorities. We request that Small Business Services and the Brooklyn Chamber of Commerce continue to work with District 8 for the revitalization of Utica, Kingston, and Nostrand Avenues, each between Atlantic Avenue and Eastern Parkway. These under-developed strips have the same potential to be as vibrant as Flatbush, Vanderbilt, Washington, and Franklin Avenues. Also, we seek the assistance of SBS and the Chamber in helping reduce the number of vacant storefronts on otherwise vibrant strips because of rising commercial rent and landlord greed.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/14
HPD
Provide more
Too many city dwellers are living well below the
housing for
poverty line. As such, many families are forced
extremely low and
to combine households in units that are way too
low income
small for the capacity they are designed for.
households
Having additional low-income housing
opportunities will help rectify this problem of
apartment sharing and overcrowding.
2/14
HPD
Provide more
Seniors, the disabled, and the homeless are
housing for special
often left out of housing conversations. As
needs households,
vulnerable populations, they need to be
such as the formerly
watched carefully and catered to just as much
homeless
as families. Many seniors and disabled
individuals live on fixed incomes of minimal
amounts, and are thus unable to afford the
current housing market. This leads them to
homelessness and homeless shelters. Housing
needs to be created specifically for these
populations to prevent the vicious cycle of
people entering homeless shelters.
3/14
HPD
Expand loan
Many small scale landlords desire to maintain
programs to
their apartments but are unable to afford to
rehabilitate multiple
afford the rising costs of doing so without
dwelling buildings
raising rents to unaffordable levels. Loan
programs to help them with rehabilitation
projects are necessary to ensure that these
landlords and property owners do not have liens
levied against their properties because of code
enforcement violations.
7/14
NYCHA
Increase energy
The Brownsville power grid is insufficient to
efficiency and
support its service base. Con Ed has identified
environmental
that NYCHA developments place most of the
performance of
strain on the grid. An audit of energy efficiency
NYCHA
and environmental performance should be
developments
conducted to ensure that NYCHA developments
are running efficiently and using as little energy
as possible to function effectively. The use of
energy efficient bulbs in all units and common
areas and the installation of solar panels on
NYCHA buildings will aid tremendously in this
effort and also reduce the electricity bill owed to
Con Edison.
8/14 EDC Build or expand
incubator or affordable work or research lab spaces
A Food & Drink Small-scale Manufacturing, Package and Bottling Incubator space is needed in CB8. A number of locations in our manufacturing district (M1) can potentially serve as the venue for small-scale manufacturing in local food and drink besides Sunset Park and the Brooklyn Navy Yard.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
2/43
HPD
Provide or enhance
As the affordable housing market continues to
rental subsidies
be stressed by man-made conditions, more
programs
financial rental assistance services are needed
to assist tenants with maintaining their housing
independence.
3/43
NYCHA
Expand programs
As more and more landlords are allowing
for housing
currently occupied rent controlled and rent
inspections to
stabilized apartments to drift into the ranks of
correct code
uninhabitability to push out long term tenants,
violations
this allows them to then renovate recently
vacated apartments to collect higher rents. We
need to ensure that enforcement agents use
their full power to encourage landlords to make
repairs for long term tenants rather than just
focusing on improving the habitability for higher
rent paying tenants. If landlords are unwilling to
make necessary repairs, we urge the City to do
so for them and bill them for the repairs, with
the threat of vacating their ownership of the
property should they not reimburse and pay
hefty fines. This in turn will deter illegal tactics
to get rid of low rent paying tenants.
6/43
NYCHA
Expand tenant
More and more landlords are resorting to illegal
protection programs
tactics to evict tenants from their homes or
make conditions so bad that residents elect to
leave their homes, thus allowing them to raise
rents. Tenant education services and legal
services to inform tenants of their rights are in
high demand.
12/43 EDC Expand programs to
support local businesses and entrepreneurs
CB8 has an abundance of restaurants and bars which would benefit from trained staff that live in the community. Comptroller Stringer has released information stating that the number of bars and restaurants has increased more than 500% in CB 8 between 2000 and 2015.
Necessary training services for the hospitality industry is necessary to allow the movement of employees from low-paying introductory jobs to the higher paying "front of the house" and managerial positions.
image
13/43 EDC Expand programs
for certain industries, e.g. fashion, film, advanced and food manufacturing, life sciences and healthcare
CB 8 is a growing community and an attractive spot for filming, culinary arts, and even fashion designers. Many of our residents have interests in, or untapped potential, to fill openings in many of these areas and thrive. Training programs geared toward helping our residents of all ages engage their interests and skills is essential. The creation of a Culinary Arts Program and Culinary Education and Training Facility Space situated in Community District 8 boundaries would address the need and interest for these skills by these businesses and our hospitality industry. Additionally, training programs geared toward different positions in film and theater production is crucial for increasing diversity in the industry.
image
15/43 SBS Provide commercial
lease support for business owners
With the current climate of capitalism focused on profit maximization, many of our commercial tenants are suffering from what is now being referred to as "commercial gentrification." Property owners with commercial spaces are often raising rents on commercial properties at lease renewal by astronomical amounts, usually tripling or quadrupling the previous rent rate.
The majority of our businesses cannot survive these increases and are forced to close, thus leading to high turnover and vacancy rates. Lease negotiation support for commercial tenants is necessary to assist them in overcoming the greed barrier to remain in their spaces and continue the trend of economic growth in CB 8.
image
22/43 DCP Other zoning and
land use requests
Study the rezoning of the manufacturing district bounded by Grand and Franklin Avenues between Atlantic Avenue and Bergen Street (blocks 1125, 1126, 1133, 1134, 1141, and
1142), as well as the south side of Atlantic Avenue between Grand and Vanderbilt Avenues (blocks 1122 and 1124) for mixed residential and manufacturing use according to Community Board 8s M-CROWN proposal as amended and submitted to the Department of City Planning.
image
40/43 EDC Improve public
housing maintenance and cleanliness
All NYCHA developments should be equipped with containers for garbage storage since maintenance staff currently places garbage curbside multiple times per day. This leads to curbs of NYCHA developments always having garbage outside, which is unsightly and unsanitary. Containerized collection will provide a place to house garbage until pickup day.
TRANSPORTATION
Brooklyn Community Board 8
image
M ost Important Issue Related to Transportation and Mobility
Traffic safety
Over the last few years, District 8 has had several traffic calming studies performed that have proven to be an effective tool in slowing vehicular traffic, thus making our district safer for its residents. However, these calming measures have led to traffic back-ups on key strips and at many high-traffic intersections. These blockages cause irritation in drivers, and sometimes makes them drive erratically or recklessly, thus reducing the safety effects of the calming measures. Also, the addition of bike lanes in a community that has its fair share already, is beginning to cause friction between residents. Recently, double parking courtesies issued during Alternate Side Parking were rescinded on blocks with newly installed bike lanes, creating cantankerous attitudes often levied toward District office staff. It is imperative that when DOT looks to install bike lanes and brings their proposal to a Community Board, that the agency takes into consideration the long term effects the bike lanes will have on residents. These effects are not just limited to revocation of double parking courtesies, but also the slowing down of traffic, new threats posed to pedestrians, and the like. Additionally, residents have requested a courtesy of being allowed to double park in the bike lane during ASP hours without fears of getting a ticket to reduce the possibility of traffic being blocked if a vehicle does not move from the curb and double parked cars are parked in the travel lane to keep the bike lane free.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Equitable treatment toward pedestrians, bikers, and vehicle owners is needed. Currently, DOT's and the Mayoral administration's focus in primarily on bikers and pedestrians, thus restricting driver movement ever further. Parking is being reduced, streets closed to create pedestrian plazas (PP) (which in turn cause residual traffic backups that were not adequately vetted prior to the implementation of the PP), shared bike lanes installed on extremely narrow streets (which cannot possibly be safe for bikers), and travel lanes being removed from already crowded roadways. The composite effect of this is driver angst, which serves to derail all that Vision Zero is attempting to do. Whereas we do believe out streets need additional calming measures to make them safer, we advocate for equitable measures. Out of the box thinking is necessary if the city truly intends to curb accidents. For instance, all way crossings at intersections should be implemented in some of the more heavily used areas to allow pedestrians time and space to cross the street without fear of moving vehicles. Also, bikers need to be held accountable for reckless biking. While the city and Transportation Alternatives is quick to throw out doctored numbers supporting their claims of vehicles causing pedestrian and biker injuries, these same statistics should be produced for bikers causing pedestrian injuries and also for bikers that are responsible for collisions with vehicles because of illegal tactics they were employing while riding. Equality is not a four letter word.
Needs for Transit Services
Many seniors and people with disabilities rely on bus service to travel. It becomes disheartening knowing that some people prefer to remain home rather than attempt to rely upon unreliable bus service in District 8. We request better service along our bus lines, especially during non peak hours and weekends.
image
Capital Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
9/14 NYCTA Repair or upgrade
subway stations or other transit infrastructure
The Franklin Avenue Shuttle line is in dire need of repainting. Efforts should be made to ensure that the shuttle line is held to the same quality standards as other major transit stations.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
19/43
NYCTA
Provide a new bus
Re-instate the B 71 bus line. This line was an
service or Select Bus
integral part of accessing the cultural icons of
Service
the Brooklyn Museum of Art, Brooklyn Botanic
Gardens, Grand Army Plaza Library, and
Prospect Park.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 8
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
Our parks, cultural institutions, and libraries provide invaluable resources, education and entertainment to our residents. They should be maintained in a manner that will allow them to continue providing pleasure and enjoyment to their users and visitors. That being said, it is unfortunate that many of our parks and playgrounds are neglected in terms of trash pickup, maintenance, and even security. The District office receives at least one complaint a week about illegal activity in a park or playground, in addition to multiple complaints of garbage strewn parks and overflowing trash cans on Parks property. We understand that the Parks Department has limited resources and are unable to clean parks daily and also to provide PEP officers at every park and playground, but more needs to be done to keep our parks and playgrounds cleaner and safer. We encourage a rotation of PEP officers to patrol our parks and playgrounds just to inform people that their activity is monitored. While this will not entirely stop illegal activity, we believe it will help dispel some of it as people will think twice before engaging in activity that can lead to potential fines. It is time that the city restores Parks' budget so that the department can provide adequate services to the community and we at CB 8 can stop making excuses for the lack of services.
Additionally, many of the street trees in District 8 are in terrible shape. Many are dying and/or have dead limbs, a good number are in need of pruning and care, and newly planted trees are not properly maintained and consequently die young. In addition to newly planted trees not being properly cared for by contractors, in some circumstances, trees not suitable for the soil or climate are planted, and do not thrive, raising residents' ire and dissatisfaction with service delivery.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The need for safe and well-maintained parks and playgrounds are essential for the children in District 8. A regular maintenance program with adequate manpower is crucial. Currently, maintenance staff needs to be increased for all of our Parks and Playgrounds, malls along Eastern Parkway, and the St. John’s Recreation Center. Additional Playground Associates, Park Enforcement Officers, and other personnel are required to keep children at play free from harassment and dangerous elements that lurk in unguarded areas. It has been proven that with personnel in our parks, they are cleaner and safer for those that utilize them. Also, while we are aware that the response to each of our Capital requests will be, "The Department supports this request but does not have funds to accommodate the request. Please contact your local elected officials," we will maintain our Capital requests in the hopes that the City Council and Mayor will notice the trend in Community Board requests and increase the budget for the Parks Department.
Needs for Cultural Services
We urge the City to continue its financial support for the renovation of our cultural institutions. The Brooklyn Children’s Museum (BCM) is one of New York City’s unique educational and cultural treasures. Since its inception in 1899, it has been recognized for educational excellence and innovation and has had strong local and national impact while attendance continues to grow. Funding is required to complete necessary repairs and upgrades, and is also needed to maintain operating hours for the museum and staff levels at a livable wage. Weeksville Heritage Center (WHC) is another cultural jewel in District 8. The newly completed educational center and office space should further enhance the eastern end of the District. WHC is a multi-dimensional museum dedicated to preserving the history of the 19th century African American community of Weeksville, Brooklyn. Using a contemporary lens, the center activates this unique history through the presentation of innovative, vanguard and experimental programs.
Unfortunately, there is not enough funding dedicated to WHC to keep it open for enough hours to provide potential visitors with its services and cultural enrichment.
Needs for Library Services
In recent years, the three public library systems serving NYC have been threatened annually with drastic cuts. Libraries provide job seekers assistance, adult literacy, English as a Second Language, computer training, tax preparation, US Passport processing, fine arts exhibits, access to the internet, and serve as a repository for historic material. Taken as a whole, the Brooklyn Public Library system requires its full funding due to its multi-service delivery to youth and adults alike.
Needs for Community Boards
Community Boards are the first advocates for community residents facing issues with other city agencies. It is our charter mandated duty to interface with community residents and city municipalities to ensure service delivery in a timely manner. 311 is not an adequate substitution for the interaction of community boards and community residents. Residents increasingly complain about the difficulty of obtaining useful and accurate information from the 311 system concerning resolution of complaints submitted via the central hotline and other general questions. The net result of the 311 hotline has been stagnation in service delivery and complaint resolution. Community Boards in general lack adequate operational funding. The meager budget provided for each of the fifty-nine boards citywide has not kept up with inflation and any increased operating costs. Community Boards possess the only budget that has not seen an increase in the past two decades despite increases in operation costs. We operate on a meager budget yet perform a valuable service to the community and city. Staff at community boards are more likely to be underpaid compared to their counterparts at larger agencies with bigger budgets despite similar job responsibilities. Employees are not paid living wages to sustain living in a city that is becoming more and more unaffordable. We urge the Mayor and the City Council to consider a much needed increase for operating costs and staff maintenance for all Community Boards. We hope the City Council and Borough President’s office will continue to battle with us to keep the voice of local government alive in every community.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
4/14
DCAS
Renovate, upgrade
Acquire land, or re-appropriate a city-owned
or provide new
building for use by Community Board 8. Rescue
community board
2 of the FDNY will be relocating from its base at
facilities and
1472 Bergen Street shortly. The building and
equipment
land is city-owned, and can be remodeled to
support not only the CB 8 district office, but also
house meeting space for the Board. This will in
turn save the City millions of dollars in rent
payments.
10/14
DPR
Other requests for
As the number of people with dogs increases in
park, building, or
the community, it is imperative that we have a
access
park with a dog run that allows pet owners a
improvements
safe and friendly environment to give their pets
exercise. Specifically for Brower Park and Lincoln
Terrace Park.
11/14
DPR
Enhance park safety
Install lamp posts around Dean Street
through design
Playground. Currently, there is a lighting issue in
interventions, e.g.
Dean Street playground. The playground does
better lighting
not have an operating system and in the past
(Capital)
relied upon stadium lights to illuminate the
area. Light posts placed strategically around the
park will illuminate the playground without
creating a nuisance situation for the park's
residential neighbors.
12/14
DPR
Reconstruct or
Upgrade the fitness equipment at Lincoln
upgrade a park or
Terrace Park. The equipment in the adult fitness
amenity (i.e.
area is highly utilized and in dire need of
playground, outdoor
replacement.
athletic field)
13/14
DPR
Enhance park safety
Install lights around playground area in Brower
through design
Park. There are currently no lights in the
interventions, e.g.
playground, and the area is completely dark and
better lighting
encourages dangerous activities.
(Capital)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
7/43
DPR
Enhance park safety
Existing resources are currently not sufficient to
through more
accommodate this request. We urge the Parks
security staff (police
Department to hire additional Park Enforcement
or parks
Personnel (PEP officers) to enforce the rules of
enforcement)
the park such as no littering, no fire (BBQ), and
no off leash dogs during specified hours and
many others. Funding must be provided in order
to rectify these problems and make our parks
and playgrounds safe and enjoyable for all.
8/43
OMB
Other community
In FY 2016, the Boards' budgets were slightly
board facilities and
increased to accommodate the collective
staff requests
bargaining agreement. However, the operating
budget for Community Boards are still woefully
inadequate, not keeping pace of inflation and
any increased operating costs. The costs for
acquiring much needed newer technology,
computer software, upgraded hardware, as well
as internet/web access capabilities is expensive.
In addition, according to Chapter 70, Section
2800 (21f) of the City Charter, we are required
to have experts such as planners to assist us in
our Charter mandated duties. We do not
currently have the funds available to hire such
experts and/or consultants. It is consequently
imperative that all the Community Boards'
budgets be increased.
9/43
DPR
Improve trash
Existing resources to accommodate this request
removal and
are currently not sufficient. Too often, we get
cleanliness
complaints about trash in neighborhood parks
and playgrounds. We urge the Parks
Department to increase efforts to keep our
parks and playgrounds litter free. Of course, this
request does not absolve those that utilize our
parks and playgrounds from doing their part to
keep the parks clean as well.
36/43
BPL
Extend library hours
Financial/economic literacy programs for teens
725 St Marks
or expand and
are direly needed. Learning to save and invest is
Avenue
enhance library
essential for economically disadvantaged
programs
residents. This information needs to be learned
during adolescence so that as adults, residents
will be financially stable. The Brooklyn Public
Library should engage residents with financial
literacy programs and make such programs
accessible to all.
37/43 DPR Forestry services,
including street tree maintenance
We are pleased with the number of new trees that have been planted in the district over the last few years. The Parks Department must hold contractors accountable for not following the mandates of their contract as many of the recently planted trees are either dead or dying. Better street tree maintenance is needed to prevent these issues from plaguing a valuable resource. Additionally, older trees need better care such as pruning and larger tree pits to remain healthy and vibrant.
image
41/43 DCLA Support nonprofit
cultural organizations
Cultural Affairs needs to assist our cultural institutions with advertisement opportunities across the city. A greater emphasis needs to be placed on the importance of the arts, culture, and diaspora history.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/14
HPD
Provide more
Too many city dwellers are living well below the
housing for
poverty line. As such, many families are forced
extremely low and
to combine households in units that are way too
low income
small for the capacity they are designed for.
households
Having additional low-income housing
opportunities will help rectify this problem of
apartment sharing and overcrowding.
2/14
HPD
Provide more
Seniors, the disabled, and the homeless are
housing for special
often left out of housing conversations. As
needs households,
vulnerable populations, they need to be
such as the formerly
watched carefully and catered to just as much
homeless
as families. Many seniors and disabled
individuals live on fixed incomes of minimal
amounts, and are thus unable to afford the
current housing market. This leads them to
homelessness and homeless shelters. Housing
needs to be created specifically for these
populations to prevent the vicious cycle of
people entering homeless shelters.
3/14
HPD
Expand loan
Many small scale landlords desire to maintain
programs to
their apartments but are unable to afford to
rehabilitate multiple
afford the rising costs of doing so without
dwelling buildings
raising rents to unaffordable levels. Loan
programs to help them with rehabilitation
projects are necessary to ensure that these
landlords and property owners do not have liens
levied against their properties because of code
enforcement violations.
4/14
DCAS
Renovate, upgrade
Acquire land, or re-appropriate a city-owned
or provide new
building for use by Community Board 8. Rescue
community board
2 of the FDNY will be relocating from its base at
facilities and
1472 Bergen Street shortly. The building and
equipment
land is city-owned, and can be remodeled to
support not only the CB 8 district office, but also
house meeting space for the Board. This will in
turn save the City millions of dollars in rent
payments.
5/14
SCA
Renovate or
Provide a new PA system, new classroom doors,
1580 Dean
upgrade an
a new cafeteria floor, new curtains for the
Street
elementary school
auditorium, and a new gymnasium floor. The
current PA system does not reach the entire
building, the doors do not close all the way so
they cannot be locked, the tiles are buckling in
the cafeteria, and the gym floor cannot be
sanded again. These are the specific requests
from the school. SCA last year stated that it
unable to prioritize funding for these requests.
However, in the wake of multiple school
shootings and unnecessary student deaths, it is
imperative that the PA system and properly
functioning doors be provided. How will SCA
explain student deaths because the doors were
unable to close and lock and an announcement
of an emergency situation unable to be made?
6/14
SCA
Renovate or
Provide new electrical system throughout the
130
upgrade a middle or
building, modernize/update the auditorium,
Rochester
intermediate school
provide new tables for the lunchroom, install
Avenue
new doors with locks, upgrade pipes/water
system in the building. These requests were
made by the school directly. Last year, SCA
stated that funding for part is recommended.
What part, and when will it be completed? In
the wake of the massive amount of school
shootings in recent months, it is imperative that
every school be equipped with doors that are
able to close and lock in a hurry as this can save
lives. How will SCA explain the loss of life if a
shooting occurs in a school and tens of children
murdered simply because the door to their
classroom could not lock?
7/14
NYCHA
Increase energy
The Brownsville power grid is insufficient to
efficiency and
support its service base. Con Ed has identified
environmental
that NYCHA developments place most of the
performance of
strain on the grid. An audit of energy efficiency
NYCHA
and environmental performance should be
developments
conducted to ensure that NYCHA developments
are running efficiently and using as little energy
as possible to function effectively. The use of
energy efficient bulbs in all units and common
areas and the installation of solar panels on
NYCHA buildings will aid tremendously in this
effort and also reduce the electricity bill owed to
Con Edison.
8/14
EDC
Build or expand
A Food & Drink Small-scale Manufacturing,
incubator or
Package and Bottling Incubator space is needed
affordable work or
in CB8. A number of locations in our
research lab spaces
manufacturing district (M1) can potentially
serve as the venue for small-scale
manufacturing in local food and drink besides
Sunset Park and the Brooklyn Navy Yard.
9/14
NYCTA
Repair or upgrade
The Franklin Avenue Shuttle line is in dire need
subway stations or
of repainting. Efforts should be made to ensure
other transit
that the shuttle line is held to the same quality
infrastructure
standards as other major transit stations.
10/14
DPR
Other requests for
As the number of people with dogs increases in
park, building, or
the community, it is imperative that we have a
access
park with a dog run that allows pet owners a
improvements
safe and friendly environment to give their pets
exercise. Specifically for Brower Park and Lincoln
Terrace Park.
11/14
DPR
Enhance park safety
Install lamp posts around Dean Street
through design
Playground. Currently, there is a lighting issue in
interventions, e.g.
Dean Street playground. The playground does
better lighting
not have an operating system and in the past
(Capital)
relied upon stadium lights to illuminate the
area. Light posts placed strategically around the
park will illuminate the playground without
creating a nuisance situation for the park's
residential neighbors.
12/14
DPR
Reconstruct or
Upgrade the fitness equipment at Lincoln
upgrade a park or
Terrace Park. The equipment in the adult fitness
amenity (i.e.
area is highly utilized and in dire need of
playground, outdoor
replacement.
athletic field)
13/14
DPR
Enhance park safety
Install lights around playground area in Brower
through design
Park. There are currently no lights in the
interventions, e.g.
playground, and the area is completely dark and
better lighting
encourages dangerous activities.
(Capital)
14/14
NYPD
Add NYPD parking
facilities
With the construction of Pacific Park around the
78th Precinct, there is a dearth of parking spaces available for officers of the precinct. The 77th Precinct also lacks adequate parking spaces and the result is officers angle parking on the sidewalk in front of private homes, double parking on residential streets, or disobeying alternate side parking rules. We urge the officers of the 78th Precinct to utilize the parking spaces that have been set aside for their use in the Pacific Park project at 535 Carlton Avenue.
CS
SCA
Provide a new or expand an existing middle/intermediate school
We thank the DOE and SCA to agree to create a designated District 13 middle school in the B15 building of the Atlantic Yards/Pacific Park Development. We look forward to the school's design and completion, and the great impact it will have on the parents of middle school students in Prospect Heights.
37 Sixth Avenue
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/43
DOHMH
Reduce rat
With the large number of development projects
populations
scattered throughout the District, and
renovation projects ongoing in our historic
districts, the number of rodent complaints has
skyrocketed with rodents more visible today
than at any other time in the last two decades.
A greater number of inspectors and
exterminators are needed to quickly address
baiting concerns and identify rodent havens and
burrows for treatment.Residents
overwhelmingly also support DOHMH
implementing a policy change mandating that
developers bait more than just the perimeter of
their projects and instead bait a wider berth, as
well as the city enforcing harsh penalties (such
as liens) on properties that do not perform
abatement.
2/43
HPD
Provide or enhance
As the affordable housing market continues to
rental subsidies
be stressed by man-made conditions, more
programs
financial rental assistance services are needed
to assist tenants with maintaining their housing
independence.
3/43
NYCHA
Expand programs
As more and more landlords are allowing
for housing
currently occupied rent controlled and rent
inspections to
stabilized apartments to drift into the ranks of
correct code
uninhabitability to push out long term tenants,
violations
this allows them to then renovate recently
vacated apartments to collect higher rents. We
need to ensure that enforcement agents use
their full power to encourage landlords to make
repairs for long term tenants rather than just
focusing on improving the habitability for higher
rent paying tenants. If landlords are unwilling to
make necessary repairs, we urge the City to do
so for them and bill them for the repairs, with
the threat of vacating their ownership of the
property should they not reimburse and pay
hefty fines. This in turn will deter illegal tactics
to get rid of low rent paying tenants.
4/43
DHS,
Provide, expand, or
As rent rates in District 8 continue to increase,
HRA
enhance rental
more and more families and individuals are on
assistance programs
the verge of homelessness. Programs should be
expanded to help them avoid entering the
shelter system and becoming statistics. Rental
assistance programs are in dire need to help
cover the gap between affordability and
unaffordable. The financial value of housing
vouchers should be increased to match the
rental rates that are being charged for units.
5/43
DOHMH
Create or promote
The stigma of admitting to having a mental
programs to de-
illness is great, especially in immigrant and
stigmatize mental
communities of color where sentiments such as
health problems
"mental illness is not a disease you can afford to
and encourage
have," continue to be a plague. This stigma
treatment
prevents those suffering from symptoms from
seeking help. Programs such as THRIVE NYC are
a great start, but the fear of being identified in
the community as having an illness prevents
many from seeking their services. More
education on what mental illness versus what it
is not is direly needed to help eliminate the
negative stigma that is pervasive in many
communities. An understanding of the different
ways people can suffer from mental illness can
go a long way in helping de-stigmatize the
condition and also allow sufferers to seek help.
6/43
NYCHA
Expand tenant
More and more landlords are resorting to illegal
protection programs
tactics to evict tenants from their homes or
make conditions so bad that residents elect to
leave their homes, thus allowing them to raise
rents. Tenant education services and legal
services to inform tenants of their rights are in
high demand.
7/43
DPR
Enhance park safety
Existing resources are currently not sufficient to
through more
accommodate this request. We urge the Parks
security staff (police
Department to hire additional Park Enforcement
or parks
Personnel (PEP officers) to enforce the rules of
enforcement)
the park such as no littering, no fire (BBQ), and
no off leash dogs during specified hours and
many others. Funding must be provided in order
to rectify these problems and make our parks
and playgrounds safe and enjoyable for all.
8/43
OMB
Other community
In FY 2016, the Boards' budgets were slightly
board facilities and
increased to accommodate the collective
staff requests
bargaining agreement. However, the operating
budget for Community Boards are still woefully
inadequate, not keeping pace of inflation and
any increased operating costs. The costs for
acquiring much needed newer technology,
computer software, upgraded hardware, as well
as internet/web access capabilities is expensive.
In addition, according to Chapter 70, Section
2800 (21f) of the City Charter, we are required
to have experts such as planners to assist us in
our Charter mandated duties. We do not
currently have the funds available to hire such
experts and/or consultants. It is consequently
imperative that all the Community Boards'
budgets be increased.
9/43
DPR
Improve trash
Existing resources to accommodate this request
removal and
are currently not sufficient. Too often, we get
cleanliness
complaints about trash in neighborhood parks
and playgrounds. We urge the Parks
Department to increase efforts to keep our
parks and playgrounds litter free. Of course, this
request does not absolve those that utilize our
parks and playgrounds from doing their part to
keep the parks clean as well.
10/43
NYPD
Increase resources
We advocate for the NYPD to do an analysis of
for youth crime
youth crimes by precinct and fund programs in
prevention
those areas with high rates of youth crime to
programs
help stem the increasing numbers of young
people in youth detention centers.
11/43
DOHMH
Provide more
While HIV transmission rates are down citywide,
HIV/AIDS
transmission of other non-HIV related diseases
information and
is on the rise, and in District 8, we rank in the
services
top 10 in all categories of increased STD
infection according to the latest Dept. of Health
data. The fear of HIV and other STIs has been
lessened over time because of new drugs
created to help prevent infection and drugs
designed to help a person live longer. Adequate
education should be provided regarding the use
of prophylactics and engaging in safe sexual
practices to prevent the unnecessary spread of
the disease.
12/43 EDC Expand programs to
support local businesses and entrepreneurs
CB8 has an abundance of restaurants and bars which would benefit from trained staff that live in the community. Comptroller Stringer has released information stating that the number of bars and restaurants has increased more than 500% in CB 8 between 2000 and 2015.
Necessary training services for the hospitality industry is necessary to allow the movement of employees from low-paying introductory jobs to the higher paying "front of the house" and managerial positions.
image
13/43 EDC Expand programs
for certain industries, e.g. fashion, film, advanced and food manufacturing, life sciences and healthcare
CB 8 is a growing community and an attractive spot for filming, culinary arts, and even fashion designers. Many of our residents have interests in, or untapped potential, to fill openings in many of these areas and thrive. Training programs geared toward helping our residents of all ages engage their interests and skills is essential. The creation of a Culinary Arts Program and Culinary Education and Training Facility Space situated in Community District 8 boundaries would address the need and interest for these skills by these businesses and our hospitality industry. Additionally, training programs geared toward different positions in film and theater production is crucial for increasing diversity in the industry.
image
14/43 DOHMH Promote
vaccinations and immunizations
Unfortunately, erroneous reports not backed by factual data have frightened some parents into declining immunization for their children. This practice puts other children at risk and also has the potential to bring back diseases that could actually be avoided via immunization and education. Factual data regarding the link between immunizations and autism is very necessary to prevent parents from making an uninformed decision that could have major deleterious ramifications on not only their children, but the broader community, especially as their non-immunized children become school age. Education and immunization promotion services are needed to deflate and eliminate these "alternative facts" and erroneous reports not upheld by factual science.
image
15/43 SBS Provide commercial
lease support for business owners
With the current climate of capitalism focused on profit maximization, many of our commercial tenants are suffering from what is now being referred to as "commercial gentrification." Property owners with commercial spaces are often raising rents on commercial properties at lease renewal by astronomical amounts, usually tripling or quadrupling the previous rent rate.
The majority of our businesses cannot survive these increases and are forced to close, thus leading to high turnover and vacancy rates. Lease negotiation support for commercial tenants is necessary to assist them in overcoming the greed barrier to remain in their spaces and continue the trend of economic growth in CB 8.
image
16/43 DSNY Increase
enforcement of illegal dumping laws
Illegal dumping creates blight and makes it appear as though the community does not care about itself. As it stands, existing resources are not sufficient to stem this tide of community blight. Illegal dumping must be stopped and penalties strengthened for those that illegally dump waste. Because current laws target those that dump from vehicles, black market dumpers that use shopping carts and dump near corner baskets are often overlooked. These dumpers need to be penalized for their actions. It should not be acceptable for them or anyone else to dump on our streets and feel as though they can get away with it.
image
17/43 ACS Provide, expand, or
enhance preventive services and community based alternatives for youth
With the passage of Raise the Age legislation, many of our youth are now presented with an opportunity to receive services necessary for their continued community presence within their home communities. With ATS options, youth can receive the mental health services they need, training, mentoring, and counseling services to begin the process of properly integrating into the community to build social capital. Intervention programs are key to helping reduce the number of youth straying toward incarceration, and programs geared toward this end are necessary.
image
18/43
HRA
Other domestic
Funding should be provided for preventative
violence services
services to educate women and men of all ages
requests
on the telltale signs of all forms of
abusephysical, emotional, sexual, and
psychologicaland how to exit a situation that
could be potentially life threatening, not only for
her- or him-self, but for any children in the home
as well. This will provide pre-emptive services
and prevent further destruction of familial ties
and bonds. Additionally, the necessary
psychological counseling is urgently needed to
ensure that past victims can prevent falling
victim again in future relationships.
19/43
NYCTA
Provide a new bus
Re-instate the B 71 bus line. This line was an
service or Select Bus
integral part of accessing the cultural icons of
Service
the Brooklyn Museum of Art, Brooklyn Botanic
Gardens, Grand Army Plaza Library, and
Prospect Park.
20/43
DSNY
Other cleaning
Provide enforcement for proper commercial
requests
trash receptacles for mixed-use buildings along
primary and secondary corridors. Mixed-use
buildings without trash storage receptacles for
residential use cause an alarming rate of corner
basket misuse. Residential tenants that have no
location within their premises to place their
garbage, are led to place their household trash
in corner baskets, or, in instances when a corner
basket is not present, simply leave their trash
bags on the sidewalk in an area it does not
belong. Proper enforcement of
container/receptacle laws will help eliminate
this cycle, and also potentially lead to a
decrease in vermin along commercial corridors.
21/43
DSNY
Provide more
While we have been assured that our
frequent litter
commercial strips receive 6 day a week basket
basket collection
collection, we constantly receive complaints of
overflowing baskets that have not been
collected and dumped in days. These complaints
are usually from residents in and around the
vicinity of Vanderbilt and Washington Avenues.
We urge additional litter basket collection, the
addition of extra baskets where necessary, and
the monitoring of existing baskets to ensure
that they are not being improperly used.
22/43 DCP Other zoning and
land use requests
Study the rezoning of the manufacturing district bounded by Grand and Franklin Avenues between Atlantic Avenue and Bergen Street (blocks 1125, 1126, 1133, 1134, 1141, and
1142), as well as the south side of Atlantic Avenue between Grand and Vanderbilt Avenues (blocks 1122 and 1124) for mixed residential and manufacturing use according to Community Board 8s M-CROWN proposal as amended and submitted to the Department of City Planning.
image
23/43 HRA Provide, expand, or
enhance adult protective services
We must keep in mind that our elderly population is at risk for abuse from family members and home health aides seeking to take advantage of their frail emotional and physical states. Our elderly population is the most vulnerable and often forgotten. They require considerable attention to maintain their safety and well-being, thus preventing them from being subjected to unnecessary hardship, pain, and mental aggravation in the form of fear.
image
24/43 DOHMH Create or promote
programs for education and awareness on nutrition, physical activity, etc.
District 8 is severely plagued by other health ailments including diabetes, heart disease, asthma, stroke, obesity, and many other conditions that require substantial medical care for those afflicted. The inability to afford healthy food options combined with the lack of healthy food options for residents on the eastern end of the district only compounds these problems.
Lower income residents without excess expendable cash should have access to quality fresh food and be trained in healthy living without exceeding their budget. Programs stressing proper nutrition should be provided for families as a preventive measure to stem the development of diseases caused by poor dietary habits and lack of exercise.
image
25/43 HRA Provide, expand, or
enhance educational programs for adults
Financial education and planning is direly needed in less economically advantaged households. Due to the inevitability of having to stretch their finances even further than they are capable, it is imperative that residents have access to financial planning and budgeting information to learn how to properly plan their monthly spending. They must be educated on what is and is not a priority in order to avoid the inevitable if they are not careful: homelessness. People applying for one-shot deals to cover back rent should automatically be enrolled in such financial planning courses to obtain the tools to prevent them from needing these emergency services again.
image
26/43 DYCD Provide, expand, or
enhance skills training and employment services for high school students at risk of dropping out
Early intervention is the key to saving the future of our youth. It is well documented that inner- city children have a higher risk for crime, dropping out of school and other educational deficits, gang involvement, drug use, and incarceration. We urge funding for activities that target at-risk youth. Funding for youth development and delinquency and prevention programs is necessary to serve our youth and quell the growing trend toward life-ruining activities.
image
27/43 DOE Expand or improve
nutritional programs, e.g., school meals
It is regrettably laughable that the DOE would state that it is committed to providing healthy food choices and maintaining high nutritional standards by offering delicious and attractive menu options, and that their nutritional standards always meet, and many times exceed, USDA Nutrition Standards for school meals. If that were the case, would students be served unappetizing and fattening meals that are moldy, unidentifiable meats, spoiled milk, expired and moldy juice, and foods that are so hyper processed, they cannot even pass as the substance they claim to be? Numerous news exposes based on the 2017 investigation of the DOE food program speak a different tune to what the DOE claims, and this lack of honesty within the agency is disheartening.
image
28/43
NYPD
Assign additional
While we are aware that staffing levels are
staff to address
allocated based on graduating classes and
specific crimes (e.g.
Administrative processes, there is an inherent
drug, gang-related,
need for undercover officers to assist with the
vice, etc.)
growing gang population on the eastern end of
the District, and vice offices to address the
increasing sex trafficking operations in CB8.
Additionally, an increase in street drugs to
compete with not as easily available
prescription drugs, has led to more drug houses
in our community. Undercovers are needed to
infiltrate these rings and close these houses
down, thus making the community safer for all.
A great benefit of the closure of these drug
houses is also the reduction of opioid drugs
readily available to the seeking public. Finally,
additional detectives are needed to investigate
crime.
29/43
DSNY
Provide or expand
Separate organic collection is useful in
NYC organics
diminishing the amount of trash sent to landfills
collection program
daily. We are highly disappointed that the City
discontinued organics collection because it did
not properly plan an effective strategy for
collection. Organics collection can not only save
the city millions of dollars a year, but can
actually allow the city to profit from the
collection. Organic waste can be broken down
by biodigesters and the compost sold to other
municipalities for their fertilizer needs. We urge
the city to re-institute organics collection.
30/43
HRA
Provide, expand, or
Not every person lacking job skills and basic
enhance job training
training for resume creation and interview
success tips lives within a NYCHA development
or is eligible to receive cash assistance. Job
training opportunities need to be expanded
beyond those living in NYCHA housing and
receiving cash assistance. These programs are
needed to help the underachieving gain self-
sufficiency and move away from a life living off
of other people and potentially public assistance
when they no longer have a support system.
31/43
DYCD
Provide, expand, or
Primary school is an important time in our
enhance after
children's lives. It is in primary school that the
school programs for
foundation for education is laid. After school
elementary school
programs are effective tools in enhancing and
students (grades K-
enriching education as well as providing social
5)
skill building opportunities.
32/43
DYCD
Provide, expand, or
A large portion of homeless youth belong to the
enhance street
lesbian, gay, bisexual, transgender, non binary,
outreach services
non conforming, and queer (LGBTQ) population.
They are often ostracized and shunned by their
families and are forced to choose to either be
comfortable with who they are or
change/hide/pretend to be someone they are
not simply to continue receiving familial
support. In order to be true to themselves, they
leave abusive situations and are forced to the
streets. Efforts should be made to reach out to
these youth to remove them from abusive
situations and prevent them from becoming
part of the growing homeless population.
33/43
DFTA
Enhance programs
Too often, our elders are too ashamed or afraid
for elder abuse
to speak up for themselves, leading them to
victims
suffer continued abuse at the hands of
caregivers or even strangers. We encourage
DFTA to increase outreach efforts and initiate
public service announcements to inform seniors
of their options and services should they ever
come face to face with elder abuse. We also
advocate for increased public awareness
programs to help people identify the signs and
signals of elder abuse.
34/43
DFTA
Increase
The elderly have a difficult enough time
transportation
traveling. Unreliable public transportation
services capacity
options are at times their only choice. An
increase in senior transportation, whether via
para transit or taxi vouchers, should be
provided--especially for those that live alone
and have minimal contact with the outside
world.
35/43
DSNY
Increase
It is imperative that Pooper Scooper laws be
enforcement of
enforced and that signs alerting dog owners
canine waste laws
that it is their responsibility to clean up after
their dogs are installed. AS A RESULT, WE ARE
ASKING THAT FUNDING TO RE-INSTATE THE
SIGNAGE UNIT BE PROVIDED. Furthermore,
additional Sanitation Police Officers are also
needed to issue summonses to dog owners who
do not clean up after their dogs as canine waste
has the potential to create health hazards for
humans and other dogs. Dog owners must be
held responsible for properly caring for their
pets.
36/43
BPL
Extend library hours
Financial/economic literacy programs for teens
725 St Marks
or expand and
are direly needed. Learning to save and invest is
Avenue
enhance library
essential for economically disadvantaged
programs
residents. This information needs to be learned
during adolescence so that as adults, residents
will be financially stable. The Brooklyn Public
Library should engage residents with financial
literacy programs and make such programs
accessible to all.
37/43
DPR
Forestry services,
We are pleased with the number of new trees
including street tree
that have been planted in the district over the
maintenance
last few years. The Parks Department must hold
contractors accountable for not following the
mandates of their contract as many of the
recently planted trees are either dead or dying.
Better street tree maintenance is needed to
prevent these issues from plaguing a valuable
resource. Additionally, older trees need better
care such as pruning and larger tree pits to
remain healthy and vibrant.
38/43
DFTA
Enhance home care
Homebound seniors should not have to live a
services
life of unintentional isolation because they are
self-sufficient enough to be able to live on their
own still. Medicaid ineligible seniors should not
be forced to pay exorbitant out of pocket costs
for assistance in day to day needs. We
encourage increasing home care services for
homebound seniors to include not only basic
care and assistance, but also for interactive
conversation and companionship to prevent the
ails of isolation.
39/43
ACS
Provide, expand, or
Families need certain tools to learn to get along.
enhance primary
Intergenerational assistance is needed to help
prevention services
bridge the gaps between younger and older
to strengthen
generations that, to be blunt, do not understand
families
each other. Children these days have the
mindset that a parent is supposed to be a
friend, and because parents are afraid of legal
repercussions for reprimanding their children
the way they were, attitudes are often left
unchecked, which can cause friction in the
home. Children, parents, and extended family
need to be educated on the modern family
structure and what the new social "norm" is for
family ties.
40/43
EDC
Improve public
All NYCHA developments should be equipped
housing
with containers for garbage storage since
maintenance and
maintenance staff currently places garbage
cleanliness
curbside multiple times per day. This leads to
curbs of NYCHA developments always having
garbage outside, which is unsightly and
unsanitary. Containerized collection will provide
a place to house garbage until pickup day.
41/43
DCLA
Support nonprofit
Cultural Affairs needs to assist our cultural
cultural
institutions with advertisement opportunities
organizations
across the city. A greater emphasis needs to be
placed on the importance of the arts, culture,
and diaspora history.
42/43
HRA
Expand access to
With the federal government extracting every
public health
ounce of worth from the Affordable Care Act,
insurance such as
now more than ever, individuals in need of
Medicaid
health care must have a viable option for health
care than the skeleton plans designed to
undermine what the ACA was attempting to
accomplish. Decreasing eligibility requirements
to receive Medicaid, or even having a payment
system to make more people Medicaid eligible
would help bridge the gap between those with
quality health insurance and those without.
Costs of private markets are increasing
drastically due to cuts in federal subsidies and
fewer people are able to afford private
insurance. Having Medicaid as an option would
allow access to the preventative care many
people need to prevent grave illnesses.
43/43
DOHMH
Promote Quit
Residents of multiple dwelling units face an oft
Smoking Programs
times forgotten issue: any resident living next to
or upstairs from a smoker, is subject to
secondhand smoke, which studies have shown is
more toxic than the primary smoke inhaled by
the smoker. Residents should not be forced to
endure health issues brought about by
inconsiderate neighbors. As such, we urge the
City to eliminate smoking in multiple dwellings
and also increase awareness of the dangers of
smoking, not only for the smoker, but also those
subject to secondhand smoke.

