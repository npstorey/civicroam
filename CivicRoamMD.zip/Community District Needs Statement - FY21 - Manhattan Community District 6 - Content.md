- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 6 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1gPowfKorPNfs89j2ukEsoqhXAZQARSRf/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1gPowfKorPNfs89j2ukEsoqhXAZQARSRf/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
6
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 6
image
Address: 211 East 43rd Street, 1404
Phone: (212) 319-3750
Email: office@cbsix.org
Website: cbsix.org
Chair: Molly Hollister District Manager: Jesus Perez
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community District Six (CD6) encompasses the East Side of Manhattan from 14th to 59th Streets, from the East River to Lexington Avenue and farther west in some areas to include Gramercy Park, Murray Hill, Turtle Bay and parts of East Midtown. Additional well-known neighborhoods lie within our boundaries: Sutton Place, Beekman Place, Tudor City, Kips Bay, Rosehill, East Midtown Plaza, Waterside Plaza, Stuyvesant Town and Peter Cooper Village. The district is a mixture of residential, commercial, medical, educational and institutional uses with major office buildings, including 731 Lexington (“Bloomberg Tower”), 601 Lexington Avenue (former Citigroup Center), and the Chrysler building, and retail shops lining the avenues. There are several medical facilities used by all New Yorkers including VA Medical Center, Bellevue Hospital, NYU Langone Medical Center, NYU Hospital for Joint Diseases, and Mt. Sinai Beth Israel Hospital, which is undergoing major restructuring that will affect our community in important ways noted throughout this document. Numerous substance abuse, mental health, and ambulatory care clinics as well as some facilities of the New York Eye and Ear Hospital are located in the district. CD6 hosts the 30th St Shelter, the city's largest at 850 beds, Samaritan Village on 53rd, New Providence Women's Shelter and other homeless facilities, including a Safe Haven site on East 17th Street. The district includes the Baruch College campus, the School of Visual Arts, the NYU School of Medicine, the NYU College of Dentistry, and the Beren Campus of Yeshiva University, Stern College and other institutions. We host numerous bioscience laboratories out of the Alexandria Center for Life Science and expect more facilities as NYU continues expansion. CD6 is also home to the United Nations as well as hundreds of missions and diplomatic residences. While recognizing the diversity of residential and commercial use, the district is primarily a middle-income community that has significant numbers of low- income residents and a large elderly population, many living on fixed incomes. We are always mindful that data about the neighborhoods of affluence in CD6 must not mask the very real need for access to affordable housing, homeless and general social services, and adequate measures for personal safety and overall well-being for all our neighbors. There are five Business Improvement Districts (BIDs) within CD6 or at its borders: The Grand Central Partnership, 34th Street Partnership, East Midtown Association, Union Square Partnership and the Flatiron/23rd Street Partnership. These continue to improve the quality of life within the district and we encourage the city to continue endorsing new BIDs where viable. We also must draw attention to the two 197-a plans prepared by CB6 and adopted, with modifications, by the CPC and the City Council. In January 2008, the City Planning Commission approved with modifications the 197-a plan submitted by Manhattan Community Board 6. In March 2008 the City Council adopted the plan as modified by the City Planning Commission. Click here to view the adopted plan. In May of 1995, CB6 submitted a 197-a plan regarding Stuyvesant Cove. This plan was modified and adopted by the City Planning commission and City Council in 1997. Click here to view that plan. These long-term planning documents should guide future action of all city agencies and are integral to the understanding of the needs of our district. This is particularly true in planning related to the waterfront and for the medical corridor that is anchored by First Avenue from 14th Street to 38th Street. CB6 is committed to seeing the planning guidelines and specific proposals of the 197-a plans fully implemented. CD6 is undergoing several major shifts in its urban-planning landscape. Along the waterfront, the East Side Coastal Resiliency Project promises to transform access to additional open space and recreational opportunities, while increasing our district’s ability to withstand flood damage like that experienced during Superstorm Sandy. Recent rezoning efforts in East Midtown promise to transform several blocks in our district into more densely populated areas that could bring additional challenges to our docket. The continuation of Mount Sinai’s Beth Israel Campus’s transformation continues to pose questions, as effects of service closures remain in doubt as the community awaits the hospital’s impact assessment and as working groups continue to meet on the issue – what impact redevelopment of real estate at the site may have is also a concern. Finally, affordability remains a difficult issue to solve and one which affects our middle- and working-class communities in direct, immediate ways. We will always look at any shifts in zoning (in-district or city-wide) and governmental- or institutionally-owned property as potential means to provide residents with housing units at reasonable cost based on their income levels.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 6
image
The three most pressing issues facing this Community Board are:
Affordable housing
Thanks to the passing of Housing Stability and Tenant Protection Act of 2019, rent-stabilized housing remains the most effective measure of preserving existing affordable housing City-wide. CD 6 like many other community districts across the city is in dire need of affordable housing, particularly NEW low-income and moderate-income housing. We are grateful to the State legislature for passing comprehensive rent regulation reform which will preserve our district's stock of affordable rent stabilized housing. However, preserving our existing stock of affordable housing is not enough to ameliorate the housing crisis we face. Over the past 15-20 years, a loss of Mitchell-Lama, and loss of Section 8 housing, and loss of rent-controlled and loss of rent-regulated housing, have led to 13.7% of rental units being rented at 80% AMI, 20.6% of district renters are rent burdened, and 64.8% of low- income renters in the district are severely rent burdened. To support and retain population and economic diversity, the board seeks new or reclaimed low- and moderate-income housing within the district.
Parks
CD6 has the least amount of open space of any community district in Manhattan. Census data shows our child-age population growing quickly, more playground and recreation space is needed. The overall population would benefit from a quality of life standpoint from additional green spaces. Moreover, much of the open space we do have has fallen into disrepair. Additionally, lack of open space is tied to air quality. Manhattan CD6 remains towards the top of several pollutant levels lists in recent municipal studies. As these levels are aggravated by lack of tree cover and extent of “impermeable surface,” additional green spaces can be considered a health matter.
Homelessness
Despite major residential development in Manhattan (Community District 6 (CD6), affordable housing in our district is disappearing. The housing crisis is felt most acutely by district residents who require special needs housing (seniors, formerly homeless individuals). We seek to remedy the situation through the creation of additional supportive and senior housing to house the homeless and our growing population of seniors. The creation of more supportive type housing units would counter the recent uptick in homelessness in the city and our area in particular.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 6
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
During his 2019 State of the State address Governor Cuomo announced a new commitment to build or rehabilitate 20,000 supportive housing units statewide over the next fifteen years. As CD 6 has only one supportive housing facility, Kenmore Hall, CB6 asks that additional supportive housing units be built in CD 6—especially given CD 6’s proximity to many public health facilities that support this population. Supportive housing will help our most vulnerable residents by creating a more robust social safety net to prevent a rise in street homelessness and to reduce crowding at our homeless shelters. CD 6 has the largest men's homeless shelter in the country, the 30th Street Men’s Shelter (located on 30th Street between 1st Avenue and the FDR Drive). This shelter maintains 850 beds and is the entry point for many citywide into the shelter system. Homelessness is a citywide issue; however, the lack of supportive housing units in CD 6 has led to an increase in street-homeless.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
There are several major hospitals in CD6, used by all New Yorkers, including Mt. Sinai Beth Israel Medical Center, VA Medical Center, Bellevue Hospital, NYU Langone Medical Center, and the NYU Hospital for Joint Diseases. Numerous substance abuse, mental health, and other ambulatory care clinics as well as some facilities of the New York Eye and Ear Hospital are located in CD6. These together essentially comply an “medical corridor” within New York City, as alluded to in our 197-a Plan. We look forward to continued cooperation with these medical facilities as they expand and modernize their operations, as well as cooperation with city agencies in ensuring that these institutions have the adequate, surrounding infrastructure and supportive programming needed to properly serve both district residents and New Yorkers at large. Of utmost concern in the coming months and years is the status of Mt. Sinai Beth Israel Medical Center. After Mt. Sinai Health System’s (MSHS) merger with Continuum Health Partner, their Downtown Transformation Plan (DTP) was developed. This plan involves the distribution of services throughout the MSHS citywide systems, creating specialized satellite treatment centers at each of their network facilities. This would mean reduction or elimination of certain specialty services within the current Beth Israel campus, including Gynecological and Obstetric care, and potentially, longer distances for our most vulnerable citizens seeking care they currently receive locally. Further, Beth Israel Hospital itself will be relocated to a new site on 13th Street, with a significantly-reduced bed count. This, in addition to the elimination of 25 acute-care beds for AIDS treatment through closure of its Mapplethorpe Center and a further reduction of 29 acute-care beds through closure of the campus’s inpatient physical rehab facility. Understandably, the residents of CD6 and nearby areas served by this medical center have serious questions as to whether their healthcare needs will be adequately met and if the reduced scope of service is sufficient for the population of our district and much of Downtown Manhattan, especially in the wake of St. Vincent Hospital’s closure and considering New York-Presbyterian Lower Manhattan Hospital’s limited capacity. We worry about not just non-emergency care and everyday emergencies, but also large- scale calamities like Superstorm Sandy or the attacks of 9/11. The appropriate agencies and elected officials, along with MSHS, must monitor the plan in conjunction with CB6 to mitigate downside risks to our community. As of this document’s submission, the hospital corporation has not released its community assessment report. However, CB6 hopes that in anticipation of further healthcare facility changes or closures, the City and State initiate a systemwide study of both the public and private healthcare networks so that communities can better understand current coverage, connectivity, and shorfalls across the five boroughs. For decades, CB6 has been advocating for a strategic plan to determine Bellevue Hospital’s immediate and future health care and land use needs, especially prior to any potential disposition of property. No such study has ever been conveyed to the board. We will continue to advocate for updated facilities, state-of-the-art equipment, and improved services there. CB6 has taken note of the lack of
high quality skilled nursing facilities in Manhattan and especially within CD6. Also, the number of hospice beds is woefully inadequate. The NYC Department of City Planning projects that Manhattan’s elderly population, aged 65 and over, will grow by 57.9% between 2000 and 2030, adding 108,000 elderly persons. CD6 has seen an increase in the number of persons age 65 and over of 9.8% just since the 2000 census – and more than 45% of these individuals are 75 and older. We therefore must plan for the additional health and other support services needed by this population. Consistent with the 197-a Plan, we are looking at development of health-related facilities within this “medical corridor.” Among other options, we would welcome a sub-acute facility or multiple use facility that would allow for a continuum of care for seniors and others. Biotech incubators, such as the Alexandria Center for Life Sciences, are also well-received additions to the corridor’s development. Non-medical and non-research related uses within this corridor, such as the proposed Sanitation Garage, will be subject to the greatest scrutiny or opposition.
Needs for Older NYs
In CD6, over 18% of our population is 65 and older, one of the highest proportions of seniors relative to other community districts. Therefore, senior services are of paramount importance to our district, especially since seniors are likelier to have income restraints. To encourage innovative programming, we urge the city to provide funding that looks beyond just the number of meals served and focuses instead on the services seniors seek for social and mental stimulation. We recognize older adults prioritize the ability to maintain and create new relationships. Social isolation is a major concern when considering aging segments, whether due to living alone or to disabilities.
Research suggests that isolation may be as harmful as smoking, obesity and lack of physical activity. Social isolation also contributes to elder abuse and preventable deaths. The board also notes that fall rates among seniors in CD6. Therefore, programming to foster social and physical activity would help prevent avoidable injury and illness in many of our seniors. We are pleased by DFTA’s efforts to introduce “innovative senior centers” which help fulfill these goals; however, none of the centers are in CD6. We ask that DFTA look at expanding programs for our seniors beyond the confines of the traditional senior center, making them available throughout our district. We note that we only have two senior centers at the northern- and southern-most ends of the map, and they are at capacity. We propose shared space with existing educational facilities such as libraries, identification of underutilized city-owned spaces, or partnerships with area community-based organizations. Facilities and organizations should have the funds to provide services not just for the frail, but also for active seniors. Computer labs with Internet access provide a wide range of opportunities so all seniors may research issues related to their health, keep informed of programs for their age group, and expand their skill set. Education on how to manage benefits online should lead to improved quality of life as well as greater use of federal programs and less reliance on city funds. CB6 consistently advocates for lifelong learning in budget requests to provide on-going education for seniors. In addition to meals and programming, aging-in-place services are vital, like homecare (a cheaper option than nursing homes) and escort assistance. Respite assistance for caregivers also is needed and ultimately, is a cost-cutting measure. Further, affordable housing options should keep this segment in mind - seniors should be able to remain in their neighborhoods of choice. Specialized legal needs and support for the physically and financially abused elderly have recently arisen as pressing concerns. We understand federal funding has been cut over the years, but various studies suggest an aging population and services supporting it remain vital – these requests are shared by CD’s across New York (see attachment). The city must take steps to make up the funding gap since we can no longer rely on other government sources.
Needs for Homeless
CB6 faces certain unique homeless and housing related challenges based in large part to the close proximity of five facilities/features within a several block radius of one another – NYCHA’s Nathan Straus Houses (located at 2nd Avenue between 27th and 28th Street), the 30th Street Men’s Shelter (located on 1st Avenue and 30th Street), ACS’s Nicholas Scoppetta Children’s Center (located on 1st Avenue between 26th and 27th Streets), Bellevue South Park (located between 1st and 2nd Avenues and 26th and 28th Streets), and the single largest concentration of hospitals in the city, including NYCHH’s Bellevue Hospital and the VA Medical Center (all located along 1st Avenue between 23rd Street and 34th Streets) creating the largest Public Health District in the city.
The result has been a concentration of three separate constituencies (homeless, local residents and ACS teens), all within a few blocks of one another, each competing for extremely limited places to go, particularly during the day, and thereby creating a variety of challenges and pressures on this area of the district. It is no surprise then, that CB6 experiences homeless conditions and housing challenges that are complicated and high in volume and require sophisticated and thoughful solutions.
P ublic Health District
Positive network effects, along with historical land use patterns and zoning decisions have resulted in a de facto clinical care and public health district, running north-south along the 1 Ave/East River axis of Community District 6. We are home to the largest cluster of clinical inpatient and outpatient facilities in the New York metropolitan area, comprising more than 50 primary facilities in total.
These include the flagship campuses of the NYC Health & Hospitals system (which includes America’s oldest public hospital, Bellevue Hospital Center), the NYU Langone health system, the Manhattan VA Medical Center and Mount Sinai Beth Israel Hospital. Taken together, Bellevue and NYU Langone serve a million people a year, mostly New Yorkers but including visitors from all over the world. Of particular note is that Bellevue, the VA and the other facilities in this core clinical care and public health institutional zone draw tens of thousands a people each day into Community District 6, including a significant homeless population, particularly from Bellevue and the VA.
N icholas Scoppetta Children’s Center (ACS)
The ACS Children’s Center, located on 1st Avenue between 28th and 29th Street, houses approximately 75 teenagers per day who are being housed temporarily while awaiting foster homes. Although ACS has recently hired additional staff, among other positive changes, and these initiatives are already seeing certain positive results, a July 25, 2019 article in the New York Post reported that the teen population at the Center has spiked 200 percent in recent years. The result has been an influx of a large population of young people in a small concentrated area who also need a place to be during the day when they are not in school or in the Center. Additionally, at least anecdotally from local business owners and NYPD officers, there appears to have been a correlating spike of incidents of local vandalism and petty crimes (e.g. shoplifting) in the surrounding area.
3 0th Street Men’s Shelter
The 30th Street Men’s Shelter, located on 30th Street between 1st Avenue and the FDR Drive, maintains 850 beds and is the entry point for more than 11,000 single men housed there or at other locations throughout the city. It is the largest shelter in the City. During the day, the men generally remain in the local area, including in and around Straus Houses and Bellevue South Park.
C ompeting Needs of the Day Populations
Residents of the 30th Street Shelter, the ACS Center, and those released from Bellevue, the VA and other local facilities who are also often homeless, become de facto temporary residents of the neighborhood’s parks and streets. Many more, while they might go home or to a shelter at night, have extended periods of time to fill during the day, and they spend it in our neighborhoods; certain parks and plazas - in particular Bellevue Park South - become de facto hospital and shelter waiting rooms during some parts of the week, making it more difficult for local residents (particularly residents of Straus Houses) and other New Yorkers to share the space.
Needs for Low Income NYs
CD6 welcomes programming that seeks to help individuals find employment opportunities, particularly when a job can allow them to exit public assistance. It is estimated that over 5% of our district receives some form of government-funded income support; many of these residents do not have the skills to gain employment in a competitive, changing marketplace. Free or affordable job training programs and employment-readying services are essential to this mission. We acknowledge the city’s progress in integrating social services to make it easier for individuals and families to reach the proper agencies and programs when they need help. AccessNYC, the city’s benefits portal, allows them to more easily attain those benefits, including food assistance, rent support and supplemental health insurance, which stabilize their current hardships. Further outreach is needed to make sure
CD6 residents are aware of this website. Despite recent federal cuts, we must make sure citizens know they might have food, housing and medical security in these still-difficult economic times. As CD6 continues to see luxury residential development replace low- and middle-income housing, HRA’s oversight of legal services becomes an indispensable part of the affordable housing arsenal, as fixed-income constituents, including seniors, face landlord harassment and complicated visits to Housing Court. We welcome the city’s major investment in legal aid for these and other purposes that assist people in staying in their current home, thereby solidifying our neighborhoods.
Increased funding for these programs should be maintained in FY 2020 and beyond to avoid displacing neighbors and prevent homelessness.
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
6/33
HHC
Provide a new or
The Children's Comprehensive Psychiatric
462 First
expanded health
Emergency Program at Bellevue Hospital is the
Avenue
care facility
only psychiatric emergency care environment in
New York State, and one of three in the world,
dedicated solely to the care of children and
adolescents. With significant growth in usage, it
is essential that Bellevue expand the physical
space dedicated to these services. This project is
fully funded through a New York State grant in
the amount of $1,352,520, and the project is
now in design. CB6 requests that the project
proceed with no significant delays.
33/33
DFTA
Create a new senior
The Board understands the lack of fed & state
center or other
funds for a new senior center, but asks DFTA to
facility for seniors
aggressively advocate for such funds & seek city
funds, in conjunction with other agencies, to
ensure adequate services to our aging
population. CD6 only has Stein Ctr & the Center
at St. Peter's, a satellite location of Lenox Hill
Houses. CB6 also notes DFTA's objective to
provide innovative senior ctrs and the life-long
learning concept clearly fits in the innovative
approach. If an addt'l physical location is not
feasible now, we ask that centers in CD6 have
these enhanced programs and that DFTA use
future support programs for seniors in other
spaces such as colleges & schools.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
2/20
DHS
Expand street
CB6 requests that DHS fund a dedicated
outreach
homeless outreach team for the area near
Bellevue South Park, as this area is a hot spot
for street homelessness given its proximity to
the local hospital, outpatient clinics, and 30th
Street Men’s shelter.
6/20
DFTA
Enhance
A new senior facility providing meals and
educational and
services has been requested by CB6 for over a
recreational
decade. While we continue to advocate for an
programs
additional center in our district, our aging
population would benefit from an expansion of
programming that can be housed in existing
City facilities or in sites run by community
organizations, and funded by DFTA and other
agencies. Libraries or CBOs, for example, can
host or provide exercise programs, fall
prevention programming (i.e., Tai Chi), life long
learning, and technology programming.
10/20
DFTA
Enhance home care
Allocate Additional Funding for Home
services
Assistance Programs for the Elderly in CD6.
18.3% of the population of the district is over
age 65. CB6 requests a higher level of attention
to its elderly population. Increased availability
of home assistance may become particularly
important after the cutbacks in services at
senior centers throughout the area. This method
of care is far less expensive than subsidized
nursing home care, which is typically the
alternative.
13/20
HRA
Provide, expand, or
CB6 would like to see enhanced funding for job
enhance job training
training programs in existence or under
development by HRA and its partners. These
programs seek to increase clients' skills,
readying them for employment and facilitating
their exit from public assistance. These
programs and associated training materials
should be free or low-cost so as not to deter
clients from participating.
15/20
DFTA
Enhance programs
With an aging population comes a greater need
for elder abuse
for attention to crimes perpetrated that are
victims
particular to seniors. Combating elder abuse,
whether physical (domestic) abuse or the
financial kind is critical in a district that has
18.2% of its population over the age of 65 (and
growing). CB6 asks for additional funds to be
devoted to specialized programs developed by
the Department for the Aging to identify and
prevent these situations. Additionally, more
data on the extent of elder abuse in our city
would be helpful in identifying needs in the
district and citywide.
20/20 DOHMH Promote
vaccinations and immunizations
The recent measles outbreak in New York City occurred largely because of misunderstandings and misinformation about the measles vaccine. We believe that redoubling efforts on the promotion of vaccinations and immunizations would be an important step in making sure that outbreaks like this don’t happen in the future.
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 6
image
M ost Important Issue Related to Youth, Education and Child Welfare
Schools and educational facilities (Maintenance)
Schools in CD6 need continued investment in their aging infrastructure. HVAC issues, electrical and plumbing lines, and fiber optic cabling are just some of the areas in need of attention. We should also point out that while the welfare of students is the primary focus of any school maintenance, adult staff facilities should be kept in mind when renovations are identified and planned.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Universal Pre-K seats and insufficient afterschool and support services for children continue to be a problem in CD6. The board’s ability to address the state of our schools is hampered by the lack of adequate communication about proposed educational plans, facility enhancements, and resource allocation. Although PS 281 opened in 2013, issues have already arisen, including child safety concerns due to changing traffic patterns and construction on adjacent sites, as well as the concerns about the anticipated lack of sunlight in the schoolyard and potential degradation of St. Vartan Park across the street. CB6 restates its belief that communication between boards and the DOE and School Construction Authority would improve outcomes. To keep our schools up to date, they need appropriate technology upgrades and wiring to support the bandwidth of tomorrow. Some schools in CD6 have upgraded infrastructure, but many facilities remain unaddressed, including facilities used by adult staff and parents, which are often overlooked. Refurbished facilities would also be available for community events providing year- round, multi-purpose utilization of school buildings. Our schools should also be constantly monitored for air quality to protect our children from exposure to toxic substances. Overall, CD6, located in School District 2, should see a greater rate of spending per child, since IBO reports we have among the lowest per-pupil allocations in the city (see "Per Pupil Allocations" below). CB6 continues to urge that the old Police Academy location on East 20th St should be considered a possible location for a school once the NYPD vacates. It is our current understanding that the agency does not have immediate plans to leave, but we urge the administration to include the board and surrounding community in any future planning for this site as required by the New York City Charter. CB6 has a stated position that any future private charter schools not be placed in current public-school facilities as this undermines their efficacy. In addition, CB6 supports the establishment and continuation of stand-alone capital fund accounts formed when we experience large-scale residential or commercial development. Financial contributions by private developers and institutions in these instances would help address increased collateral needs resulting from such projects that add permanent or commuter populations to our district. These needs can include new schools, transit services and below-surface infrastructure.
Needs for Youth and Child Welfare
CB6 appreciates the difficulty and quantity of the caseload covering children’s issues in New York. We support efforts that establish an effective and appropriate caseworker-per-child ratio. A recent spate of fatalities of children that were being monitored by ACS demonstrates that more well-qualified caseworkers are needed to ensure the safety of our kids. Proper management of these cases can help prevent other tragedies, but in some cases, can help prevent the alternative - foster care - by providing households with counseling and services that allow the family to stay intact. Kinship programs, where relatives care for the child in lieu of strangers, should be promoted where possible, and support for those caregivers must be adequately distributed. Our board also encourages lead agencies to promote foster parenting to citizens within our borders in cooperation with the CD6 office. ACS’s facility on First Ave in CD6, known as The Children’s Center, is an item the board would like to collaborate further on with the agency. We welcome constructive dialogue to help identify, understand and support ACS's priorities and objectives. We are happy that a Community Advisory Board (CAB) has been established and meets regularly. ACS' location within what we have referred to in previous sections as a "public health district" has led to needs specific to this area. For more on those needs, see the sections on homelessness and public security, Additionally, CD6 recognizes
the important role ACS plays in early childhood education and welcomes new hires to manage programs and providers of such services. It is essential that, coupled with Universal Pre-K, EarlyLearn and other initiatives seek funding to achieve maximum enrollment in CD6 and beyond.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
12/33
SCA
Provide technology
PS 116 currently has no security system, making
210 East 33
upgrade
it difficult for the school to keep track of what is
Street,
going on throughout its building. It is especially
Manhattan,
problematic this year, as early voting and
New York, NY
classes are going on at the same time, without
a security system to ensure that both kids and
voters alike remain safe. Installing a security
system at PS 116 will be a major step towards
ensuring the safety of kids at the school.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
1/20
DYCD
Other runaway and
According to the latest research by NYU’s
homeless youth
Steinhardt School of Culture, Education and
requests
Human Development, one out of every eight
children in New York City experiences
homelessness before the Fifth Grade. The
trauma of homelessness leaves many children
unable to reach their full potential and in need
of expanded support. In addition, Elementary
schools across the entire city are seeing rises in
homeless students, including in Chinatown,
Midtown West and Midtown East, with some
schools experiencing rates of STH students as
high as 27%. These schools include institutions
in our neighboring Community Board Zones and
significantly impact children in PS 116 in the
CB6 Zone.
9/20 ACS Provide, expand, or
enhance preventive services and community based alternatives for youth
CB6 requests that funding be enhanced for preventative services that allow families to remain together which maintaining the welfare of the children in the home. We understand these programs are effective in preventing children from entering foster care and can include services such as family or individual counseling, parenting classes, substance abuse treatment, domestic violence intervention, home care, and support for pregnant and parenting teens, among others. However, this funding must be coupled with additional staff and better training for caseworkers to ensure children's safety.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 6
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
As previously mentioned, CD 6's "public health district," the several block radius that encompasses NYCHA’s Nathan Straus Houses (located at 2nd Avenue between 27th and 28th Street), the 30th Street Men’s Shelter (located on 1st Avenue and 30th Street), ACS’s Nicholas Scoppetta Children’s Center (located on 1st Avenue between 26th and 27th Streets), Bellevue South Park (located between 1st and 2nd Avenues and 26th and 28th Streets), and the single largest concentration of hospitals in the city, including NYCHH’s Bellevue Hospital and the VA Medical Center (all located along 1st Avenue between 23rd Street and 34th Streets, has resulted in a concentration of three separate constituencies (homeless, local residents and ACS teens), all within a few blocks of one another, each competing for extremely limited places to go, particularly during the day, and thereby creating a variety of challenges and pressures on this area of the district. To remedy some of the issues that this subsection of CD 6 faces, CB6 recommends that the security at Straus houses be improved through the implementation of layered access at the lobby and rear door. Additionally, we believe that NYCHA should provide funding for a security guard at Straus Houses. Finally, we believe that DHS should fund a dedicated homeless outreach team for this area to: 1) continually canvass the catchment area to establish constructive relationships with homeless individuals and provide outreach, direct services and referrals; 2) provide a rapid response to alerts from CB6 stakeholders of homeless persons in the area; and 3) in every applicable instance, to manage de-escalation of any crises by a homeless individual.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The increased staffing of the 13th and 17th Precincts had been our top expense budget request for several years. CB6 was pleased that elected officials increased overall staff of the NYPD in recent years, and we look forward to receiving our fair share of new personnel as cadets continue to graduate from the academy. While our crime rates remain stable (or lower in some categories), issues associated with some of our homeless shelters and several clinics, particularly headlines regarding the 30th Street Shelter, have particularly concerned CD6 residents. Other issues include increasing calls about issues including public drinking and drug use, loitering in playgrounds, aggressive littering, and panhandling. Through Community Advisory Boards (CABs), we continue to communicate with NYPD, lead agencies and the service sites to find solutions to these problems, including more frequent patrols of surrounding streets. As traffic worsens in CD6, so do infractions. Blocking of intersections, parking in bus and bike lanes, and illegal stopping are frequently not cited. This adds to potential dangers to our pedestrian-heavy district. Moreover, continued increases in bicycle ridership adds a new element to policing of traffic safety. Our precincts should have dedicated personnel specifically monitoring bike activity. To be clear, CB6 does not intend to put the onus on cyclists, but rather suggests the comprehensive monitoring of how they, cars and pedestrians interact safely and follow traffic rules. We would welcome officers or auxiliary personnel on bike patrol to add units that mimic the new transportation landscape. We further suggest that, as an ongoing City Hall priority, Vision Zero help place emphasis on integrating the many new and old facets of transportation to ensure everyone commutes safely. Noise remains the top complaint as registered by 311. There have been many concerns voiced by the community about the concentration of bars along 2nd and 3rd Avenues, particularly in the East 20s, 30s and 50s. These areas are heavily congested and noisy when patrons congregate outside or leave the venue. Some owners blast music out of open storefronts. Advertised pub crawls exacerbate the issue. Residents have found calls to 311 frustrating as law enforcement has many hours to respond to non-emergency; therefore, there is limited response to these issues when they are actually happening. NYPD should coordinate activities with DEP to provide better response times to address these ongoing violations. DEP should also explore outreach efforts to the community where they could educate the public on how to best monitor and document noise problems to assist the agency in investigations. Of course, our police precincts cannot carry out their duties effectively with aging infrastructure hampering their efforts. We have asked for full modernization of precincts in CD6 that reflect the force’s 21st Century needs. Some
upgrades at the 13th Precinct have been budgeted, but the station needs major renovation. Additionally, when reviewing existing facilities in our district, CB6 wishes to be involved in any re-purposing or disposition of the old Police Academy on East 20th St. Should the NYPD no longer need the facility, we support a new school for the site.
Needs for Emergency Services
CD6 hosts first-class emergency rooms and hospital facilities within its borders. Our first responders should have state-of-the-art bases and training, ready for more of the potential crises we have experienced in the recent past. The community is better served, while our firefighters, EMS workers and other emergency support workers feel more capable when fulfilling their missions if they are equipped with the right tools. With regards to EMS Battalion 8, a concern is construction and renovation of sites adjacent to their facility. With a major development project on the horizon at the former Brookdale Campus on East 25th St and the upcoming resiliency-related upgrades at Bellevue Hospital Center, CB6 is concerned Battalion 8 will be hampered or may have to be temporarily relocated. We will watch the progress at these sites so that they do not adversely affect this essential deliverer of emergency services. Responding to emergencies does not just begin with city emergency personnel - studies show that bystander CPR training initiatives improve health outcomes significantly (see attached report). CB6 would like to see additional city funds for CPR and life safety programs via NYC Service to make up for shorfalls in funding provided by the FDNY Foundation. In addition, we stress the continued need for funding for all manners of education regarding fire safety. The FDNY reported 2016 as the lowest for fire fatalities in its recorded history and cites its outreach efforts as instrumental.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
15/33
NYPD
Renovate or
CB6 requests that the 13th Precinct receive
230 E 21st
upgrade existing
funds for a full renovation or replacement of the
Street
precinct houses
precinct house. Though NYPD has replied that
this has been funded, requests for scope so far
only cite upgrades to wiring and aesthetics, not
the full structural work we have been told is
needed. With crime-fighting shifting more and
more to technology-heavy approaches,
precincts should be fully equipped with state of
the art hardware that would increase the
efficiency of uniformed and civilian staff. NYPD
management acknowledged the need and
requested our support for this request in 2016.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
8/20
NYPD
Assign additional
The Mayor has several policies and programs
traffic enforcement
meant to improve traffic flow and traffic safety
officers
in New York City, such as more protected bicycle
lanes, dedicated bus lanes, and Vision Zero.
However, because of a lack of traffic
enforcement in our district, those policies and
programs are left compromised. Protected
bicycle lanes are compromised because of
drivers interfering with those lanes. Bus lanes
are compromised because other vehicles park in
those dedicated bus lanes. Vision Zero is
compromised because of vehicles that travel in
a dangerous manner, therefore compromising
the safety and lives of pedestrians. Additional
traffic enforcement officers will be helpful in the
carrying out of these initiatives.
16/20
NYPD
Assign additional
CB6 requests and increase in funding for the
uniformed officers
Neighborhood Coordination Officers Program at
the 13th and 17th precincts.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 6
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Noise pollution
With major arteries and approaches, such as to the Queens Midtown Tunnel and the 59th St Bridge, and due to increased bike/bus lanes and private and public street closures, traffic has become a major problem and results in increased noise. Additionally, high-rise building construction is rampant and causes its own noise pollution. With several bar and nightlife stretches, we also experience noise complaints due to evening activities. Noise is the number one CD6 resident complaint to 311.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
CB6 continues to advocate for measures that better the overall environmental quality of the district, including resolutions on greater efficiency for city vehicles and boats, monitoring of construction projects and "macro" items, such as advocacy for greater recycling efforts. However, we look for support in day-to-day monitoring of air and noise pollution. With increased traffic congestion due to several factors, street noise and concerns about air quality have increased. As the attached Air Survey maps show, NO2 levels, heavily weighted towards traffic levels, remains at their highest in Manhattan CD6. Other contributing factors to air and noise pollution: The 34th Street Heliport's noise, odors and air blast impacts have drawn criticism from nearby residents and necessitated replacement of costly air filtration equipment at NYU Langone Medical Center. Residential and commercial real estate development in the district raises many of the same noise and air concerns. Additionally, our prominent nightlife districts result in frequent calls from residents to 311, complaining about loud patrons and blaring music from open storefronts into the early morning hours. A greater number of inspectors to monitor noise is needed. We also ask that more air monitoring devices be placed in areas of recently increased construction and traffic activity (i.e. Queens Midtown Tunnel) so that their short- and medium-term impact can be analyzed. CB6 also believes better coordination on hot- button issues between DEP and these other agencies could prove fruiful (NYPD in the case of traffic and nightlife; DOT with regards to conducting traffic studies and observing emission levels; DOB when it comes to onsite construction inspections and asbestos abatement). As we have suggested elsewhere, DEP should also educate the public in how to best monitor and document on-going noise issues to assist the agency’s enforcement measures.
Needs for Sanitation Services
Trash complaints to the CD6 office, both residential and on our streets, have increased. We continue to note that additional enforcement of alternate side of the street regulations is needed to facilitate regular maintenance. Some sidewalks also fare poorly, as they are continuously littered. CB6 supports hiring of additional crews to remedy the situation, and encourage further review of pick-up routes and frequency. Commercial and residential garbage frequently sits on the street for many hours in advance of mandated curbside placement times, which creates odors and unsightly messes that also attract rodents. This issue pertains to both privately- and government-owned buildings. Enforcement of sanitation rules must be increased. Additional pickups seem warranted to handle the increase in mandated recycling efforts. Small- and medium-sized buildings do not have space to store the added volume between once-weekly pickup times. Anecdotal evidence suggests many buildings are commingling their recycling with regular garbage on sanitation pick-up days to free up space in receptacles and refuse rooms. It's time to treat recycling collection and enforcement the same as that for regular trash. Finally, DSNY with EDC has proposed that a garage be located at the former Hunter College Brookdale Campus, 425 East 25th St, between First Ave and FDR Dr. While CB6 recognizes the principle of locating such facilities in or near the district being served, we have objected to the placement of this project in the middle of the medical corridor (between Bellevue Center and the VA Hospital) and near major residential developments and schools. The location is in clear opposition to our 197-a plan. A planning study commissioned by CB6 proposed two alternatives that have gone ignored (see "25th Street Sanitation Garage" study below). We still have no specifics as to plans for the remainder of the site on either
end of the planned garage, even after several scoping hearings with community groups, but the ULURP process remains. CB6 has serious concerns in regards to a sanitation garage being established at this site. In the meantime, DSNY has recently contacted the board to announce a temporary base of operations on East 26th Street along with a nearby on-street site for the storage of sanitation vehicles on Mount Carmel Place, next to residences and a park. The board was given no other options on this siting. We oppose this siting and encourage the city to take any possible measures to relocate the temporary base & vehicle parking to a non-residential area where it would be more appropriate.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
12/20 DEP Investigate noise
complaints at specific location
Increase staffing of Noise Pollution Control Inspectors. In recent years, 311 and other reports show noise as 1 complain in the district. Aside from noise from late-night revelers and bars/restaurants, CD6 has also experienced increased complaints due to traffic congestion. Our roads are narrower due to bike/bus lanes and we have major approaches in our borders, such as the Queensboro Bridge and Queens Midtown Tunnel. We also host the 34th St Heliport and large construction projects that deserve monitoring. Finally, because of After-Hours Variances that are granted, there are complaints about late night construction noise. More inspectors would stay ahead of complaints with 24/7 monitoring, rather than the current after-the-fact on-site visits.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 6
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
Thanks to the passing of Housing Stability and Tenant Protection Act of 2019, rent-stabilized housing remains the most effective measure of preserving existing affordable housing City-wide. CB6 requests the development of NEW low-income and moderate-income housing in CD 6. Over the past 15-20 years, a loss of Mitchell-Lama, and loss of Section 8 housing, and loss of rent-controlled and loss of rent-regulated housing, have led to 13.7% of rental units being rented at 80% AMI, 20.6% of district renters are rent burdened, and 64.8% of low-income renters in the district are severely rent burdened. In order to support and retain our existing population and promote economic diversity, we call upon the City to provide new or reclaimed low-and moderate-income housing within our district in the forthcoming year.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Before the 2008 recession, CD6 saw rapid building growth, with over 2000 additional residential units constructed since the 2000 Census, plus over 2 million square feet of new office and retail space. By 2016, a boom in residential permitting had returned, with building applications at record highs. DOB and related agencies need enough tools and personnel to process paperwork and inspect sites correctly. Expanded online capabilities for submission of zoning and construction documents and their subsequent public review is also welcomed. Rapid growth also means additional infrastructure requirements, such as transit options, subsurface service delivery, sanitation services, and open space – City Planning staff should be sufficient to meet these challenges. The rezoning of about 70 blocks of East Midtown remains on our radar. Greater East Midtown rezoning was approved in August 2017, after extensive community comment and input. Responding to community requests for additional open space, the text amendment requires each site developed under the rezoning to provide public open space. Additionally, there will be a governing group to prioritize public realm improvements in the area. CB6 wants to encourage the creation of open space in the district, and will work with the city and private developers to facilitate open space development, as well as street level public realm improvements. CB6 remains an advocate for expanded transportation and subsurface infrastructure and specific public realm upgrades. We hope to work with DCP and partners to preserve East Midtown’s global competitiveness in the 21st Century, while retaining some human scale and meeting demands of local residents. This applies not just to multi-block rezoning, but also to the rising number of individual sites slated for “superscrapers,” which CB6 opposes when they threaten the scale and character of a neighborhood. As to remapping streets, 30th St east of First Ave does not appear on the official city map, thus is technically not a street. In our 2008 City Council-approved 197-a plan, CB6 stated its desire to re-map this street. Since NYU Langone has completed its new laboratory building, we cannot see why the hospital would object. Another re-mapping request is 26th St east of First, at the site of the proposed DSNY Garage. The Sanitation Garage Working Group requested that DSNY re-map the street as it enhances oversight of adjoining parcels. Any further changes on the horizon to street mapping proposed by government or institutional actors, due to issues such as waterfront resiliency or otherwise, will continue to receive our board’s highest scrutiny. Regarding the DSNY garage, the proposed rezoning would change the property from an R to M zone, which would constitute spot zoning. The property is located between Bellevue and the VA, an area designated as a medical corridor in CD6's 197-a plan. The community at-large asks that the ULURP process take objections into account. Due to strong local opposition and since it contradicts our 197-a, CB6 requests DSNY re-evaluate alternatives sites. As pertains to forthcoming, large-scale development issues, the upcoming restructuring of Mount Sinai Beth Israel Medical Center is being met with skepticism from CD6 residents. As Mount Sinai plans to relocate services from the current site and dispose of real estate, questions remain as to potential development in its place. ULURP procedures, as alternative uses become apparent, especially those not in keeping with current zoning or use provisions, should be sensitive to community input. CB6 will make sure new construction will be of minimal impact while studying possible services and infrastructure improvements
the district may need as the area suffers the loss of this vital institution. A related concern is the proximity of Beth Israel to Stuyvesant Town, which contains additional development rights whose transfer parameters have yet to be defined. Any disposition of Stuyvesant Town air rights here or to other district sites should be subject to extensive public review. Finally, CB6 is currently in the process of updating our database of privately-owned public spaces (POPS) in CD 6. This database will include the site’s physical condition, amenities required, and general notes. As soon as this database is completed it will be posted publicly on our website, cbsix.org. We ask for additional oversight of our POPS and a for City Planning to partner with community boards on developing a better POPS framework, especially since CD6 ranks lowest in amount of open space in Manhattan.
Needs for Housing
CD6 is confronting a housing crisis along with the rest of the city. We also show that CD6 did not benefit greatly from the New Market Place program under the prior administration, nor have we seen significant upticks in preservation or new affordable development under the current Housing New York plan. In order to support and retain our existing residents and promote economic diversity, CB6 calls on the city to commit funds to provide new or reclaimed low- and moderate-income housing within the district, with particular attention to senior citizens and other fixed-income households. Our community has demonstrated great compassion for the homeless and is aware of the enormous demands for service needed by this population. CD6 welcomed new developments within the district built or converted under the successful city-and-state joint program NY/NY III, which created 9000 supportive housing units for the mentally-ill homeless and other target segments. We believe it is essential that successor programs learn from the positive lessons in interagency communication and community involvement in site selection (led in the city by DOHMH and HPD). We are encouraged by recent (but separate) city and state commitments to the construction of new supportive units. In 2015, the Mayor announced a 15,000-unit goal, while the Governor’s proposal includes another 20,000 units statewide. We ask that funding be disbursed immediately so they can begin to sensibly address our persistent homelessness crisis. The case for this type of housing can be made financially, as shown in the attached report, which shows it saves taxpayers when compared to sheltering or institutionalization – $40 per person per day in supportive housing vs. a staggering $802 per day in the latter options. Homelessness is not just a function of disability but also of affordability. CD6 seeks additional permanent placement for homeless families, which require larger units than those offered via other programs. HPD and DHS should consider allocating an increased portion of the city’s affordable housing resources to this population. Finally, we would like to draw attention to our district’s NYCHA developments. CB6 is aware that capital needs are an agency-wide problem, but Straus Houses requires upgrades that deal with immediate security concerns. Residents and management have alerted us to items such as new lobby doors that would prevent non-residents from entering the premises without permission. On an operations level, these developments need new refuse disposal facilities and policies, where curbside placement frequently occurs on the wrong days and times, leading to accumulation of garbage and attracting vermin and persons looking to rummage through. Recycling efforts should also be redoubled, and pest control should be further explored. We want to make sure CD6 NYCHA residents’ needs are communicated through our office, which is why we also encourage the agency to expand and share informational resources so we can achieve this effectively.
Needs for Economic Development
We are pleased that sources of highly skilled medical and research jobs and the economic stimulus they provide are in and near CD6. NYU Langone recently completed a 14-story laboratory building on East 30th St and First Ave and a new Children’s Hospital at East 34th Street and First Ave. The Alexandria Center of Life Science, part of East River Science Park, has two operational buildings with a third on the way. It is devoted primarily to biotech facilities and contains 300,000 sq. ft. of lab and other R&D space. Funding for this project was a public/private arrangement including money from city and state entities, the city’s business community, some federal funding, and the developer. We welcome the addition of the Cornell NYC Tech Campus on Roosevelt Island which, while located outside CD6, will have great impact. CB6 has advocated for a strategic plan to determine Bellevue’s health care and land use needs prior to disposition of property. No such study has been conveyed to us. We continue to advocate for the renovation and re-purposing of the former Bellevue Psychiatric Building. In 2008, EDC issued an RFP for it, and several proposals were received; however, no selection was made. Our 197-a Plan explicitly calls for scientific, medical, and institutional uses for this building. CB6 stands by the plan and continues to ask for renovation of the building. It has been considered for landmarking by the state and contains WPA-era murals in need of restoration.
CB6 remains diligent about our waterfront. We work towards a continuous esplanade and bikeway along the East River. The former ConEd site pier has been restored and is in need of beautification and amenities. Earlier this year the Mayor pledged funding for an esplanade between East 53rd and East 61st Streets which will have a dramatic impact on our waterfront access and use. Our continuing participation in the Eastside Coastal Resiliency plan remains essential as the plan is about to complete the ULURP process. Continued incorporation of Blueway Plan items into these resiliency projects are positive steps that we will keep lobbying for. We also are happy that theNYC Ferry stop at East 20th Street is active and serving the residents of CD 6. Much of the funding for our waterfront (and near-waterfront) priorities, however, remains contingent on the Memorandum of Understanding (MOU) involving the disposition of assets to the United Nations. The UN, to date, has not formally approved the MOU. We still look forward to this key step. Notwithstanding, CB6 seeks a proactive approach by EDC in ensuring alternative funding sources for some of these important projects so that they are not put off indefinitely nor solely dependent on agreements with non-city institutions. The Mayor’s commitment to funding a partial stretch of East River waterfront from is a step in the right direction, but more will be needed to make our waterfront accessible and useful. Finally, DSNY with EDC proposed that a garage be built at the former Hunter College Brookdale Campus on East 25th St. While CB6 recognizes the principle of locating such facilities in or near the district being served, we have objected to this site as it contradicts our 197-a plan. Strong community opposition to the project persists. We continue to support alternative plans as presented in a 2014 planning study independently commissioned by CB6 and strenuously encourage a re-evaluation of alternatives sites that would be more suitable for this purpose.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/33
HPD
Provide more
CB6 requests the preservation of existing and
housing for
the development of NEW low- and moderate-
extremely low and
income housing in CD6. Over the past 15-20
low income
years, a loss of Mitchell-Lama, and loss of
households
Section 8 housing, and loss of rent-controlled
and loss of rent-regulated housing, have caused
areas in CD6 to become increasingly more
income segregated. In order to support and
retain our existing population and promote
economic diversity, we call upon the City to
commit at least $20 Million to provide new or
reclaimed low-and moderate-income housing
within our district in the forthcoming year.
2/33
HPD
Provide more
CB6 requests city dollars be committed to the
housing for special
development of additional permanent housing
needs households,
for homeless families. There is an insufficient
such as the formerly
supply of housing for homeless families. HPD
homeless
needs to allocate to homeless families just five
percent (5%) more of the vacant units that
become available annually from the city's
existing affordable housing resources. These
resources include public housing, Section 8 rent
subsidies and units developed by HPD, and
inclusionary zoning on rezoned manufacturing
and Brownfield sites.
4/33
HPD
Provide more
During his 2019 State of the State address
housing for special
Governor Cuomo announced a new
needs households,
commitment to build or rehabilitate 20,000
such as the formerly
supportive housing units statewide over the
homeless
next fifteen years. As CD 6 has only one
supportive housing facility, Kenmore Hall, CB6
asks that additional supportive housing units be
built in CD 6—especially given CD 6’s proximity
to many public health facilities that support this
population. In addition to this commitment to
the building of new supportive housing units, CB
6 asks that the City and State ensure that
supportive housing providers be fully funded so
that they can continue to operate their current
facilities. Additionally, CB6 requests more
affordable assisted living and senior housing in
CD 6 to accommodate the aging population of
this district.
5/33
EDC
Invest in capital
According to the Department of City Planning,
East River
projects to improve
New York City boasts 520 miles of waterfront
Esplanade E
access to the
and as such our waterfront is a significant
14th Street E
waterfront
resource for our city. Our waterfront has for
59th Street
many years been a particular priority for
Manhattan Community Board Six. Currently our
community cannot access large segments of our
waterfront because our waterfront esplanade
has significant gaps in it. In a city where we all
live in such close quarters, our outdoor spaces,
especially our waterfronts, are all the more
valuable. And for districts like ours, which the
Department of City Planning has confirmed has
“the lowest amount of open space per capita of
Manhattan community districts” , we feel this
need most acutely. CB6 requests updated
timelines for the esplanade and bikeway plans
when possible.
7/33
NYCHA
Install security
For many years, residents of Straus Houses have
cameras or make
urged NYCHA to improve security. Most pressing
other safety
is the need for new front and rear lobby doors
upgrades (Capital)
incorporating layered access control. The lack of
layered access and the general malfunctioning
of the doors constitutes a significant safety and
security concern for residents and management
—for example, there have been multiple fires
set in the stairwells by non-residents in 2019.
Given that neighboring 344 East 28th Street is
undergoing a PACT conversion and thus will
have its security needs paid for by the new
management company, NYCHA should redirect
security funding to Straus houses once the 344
PACT conversion occurs.
30/33
EDC
Build or expand
CD6 hosts a premier medical corridor along First
First Avenue E
incubator or
Ave that includes several major hospitals and
23rd Street E
affordable work or
the successful Alexandria Center for Life Science.
34th Street
research lab spaces
This cluster of institutions, in addition to
university and training facilities, make our
district ideal for construction of additional,
affordable research lab space and tech-related
incubators. The rising cost in the traditional
office corridors discourages greater expansion
of these industries in New York. We welcome
the added employment opportunities they
bring, as well as the partnerships they can forge
with our educational centers. We encourage
exploration of city-owned sites for this purpose.
CS EDC Invest in capital projects to improve access to the waterfront
Solar One conducts numerous educational programs in the park using indigenous and exogenous varieties of plants as part of its instruction for responsible environmental practices. An irrigation system is essential for survival of the plants used throughout Stuyvesant Cove Park. We look forward to its completion now that funds are committed as part of resiliency efforts on the waterfront.
24-20 FDR
Drive East Service Road
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
3/20
NYCHA
Install security
CB6 requests that in addition to the requested
cameras or make
improvements to the physical security
other safety
infrastructure at Straus Houses, that a
upgrades (Expense)
permanent security guard be hired for this
complex. All of the nearby housing complexes of
a similar size (Kips Bay Court, Phipps Houses)
have hired their own private security teams. A
dedicated security detail would improve the
quality of life for the residents at Straus houses
and would create neighborhood equity, where
the public housing is on par with private
housing.
TRANSPORTATION
Manhattan Community Board 6
image
M ost Important Issue Related to Transportation and Mobility
Accessibility (ADA related compliance and infrastructure enhancements)
Of the five subway stations that have subway entrances in Community District 6 (1st Avenue, 3rd Avenue, Grand Central-42nd Street, 51st Street/Lexington Avenue-53rd Street, and 59th Street/Lexington Avenue-59th Street), only one of the stations is currently fully accessible. There are heavily-used stations in and near our district, such as Lexington Avenue-59th Street and 33rd Street, that are not ADA-compliant and are currently not slated for accessibility improvements in the Proposed 2020-2024 Capital Plan. The City should provide funding to the MTA to make subway stations in and near our district accessible by constructing elevators and accessible entrances to subway plaforms.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Traffic in CD6 is a major concern. We need a traffic study and action plan to understand how vehicular flow can improve. With major vehicular transit points like the 59th St Bridge, Midtown Tunnel and FDR on/off ramps, plus sometimes all-day avenue and side street jams, solutions need to be identified to allow better movement for private cars, buses, bikes and pedestrians alike. Major construction at the Queens Midtown Tunnel has exacerbated the problem on major streets, side streets, and avenues that feed this vital artery. Work on the MTA’s Park Avenue infrastructure may make matters on those same side streets worse. Congestion increases due to partial and full street closures by real estate development and construction, plus DOT or utility company street work. The need for studying traffic patterns and better coordination of work/permitting that might affect them is evident. As the board does not have resources to process a study alone, a DOT-directed action plan based on available and requested research would be most beneficial. CB6 has high hopes for Vision Zero. We are pleased with the initial efforts being made to install accessible crossing signals and continue to request them at problem-corners via DOT’s portal. Traffic incidents occur throughout the district but some locations are of greatest concern. Re-engineering has improved the conditions of the intersection at 24th St and Lexington Ave; however, other intersections remain problematic.
The area around 34th St and FDR Dr Service Rd consistently ranks high in collision rates. Engineering to address traffic flow here is key. CB6 has also heard from residents about 23rd St and 2nd Ave, 23rd St and 3rd Ave, and the ever-problematic 57th to 58th Street section of 2nd Ave. To help address pedestrian-vehicle collisions, several measures can be studied. Dedicated left turn signals are necessary at several major intersections along our avenues. Additionally, CB6 asks that DOT consider traffic calming measures, such as leading pedestrian intervals, speed bumps, all-red stop phases or other methods to improve safety for pedestrians along some avenue segments.
Pedestrian-bicycle incidents are on the rise. There has been a noticeable increase in bike ridership. CB6 supports bike lanes, though we must recognize that pedestrians can be injured by illegal and unsafe cyclists, such as sidewalk riding, ignoring stop lights, and traveling against traffic. Enforcement is the easiest solution. Cyclists, though, should also benefit. They deal with lanes shared by buses, vehicles, and double parking. Major gaps in the East River Greenway force cyclists into dangerous traffic conditions. Completion of protected bike lanes along the east side of CD6 is a critical component of DOT strategy. As for waterways, CB6 is happy that there is a now an East River Ferry stop at East 20th Street. We look forward to the continued use of this maritime complement to our current, congested land-based transportation network. We note, however, that as ferry-related pedestrian and bicycle traffic increases along the FDR Service Road, so should monitoring of possible safety issues related to vehicular traffic flow. Recent discussion of expansion of Staten Island Ferry service to the 34th Street pier is additional cause for consideration of waterfront traffic patterns.
Needs for Transit Services
CB6 notes its continuing support for a full-length Second Avenue Subway which would relieve the burden on the Lexington Line and provide much-needed relief to the congested bus system along First, Second and Third Avenues. Many on the East Side currently walk over one-half mile to a subway station. Phases 3 and 4 of the project are expected to benefit Manhattan CD6. We eagerly await the completion of this work and ask the city to block any efforts to further delay it. Consideration of simultaneous work on Phases 2-4 should be considered as funding and machinery is available. In light of capital demands on the Metropolitan Transit Authority, we hope the city and the state will cooperate in funding shorfalls in the MTA's capital budget, with particular attention to the Second Avenue Subway line's completion. The economic benefits are apparent: it would secure New York its place as a competitive, world-class business environment, while its construction provides good-paying jobs for New Yorkers. The proposed Emergency Ventilation Plant (EVP) for the Lexington Avenue Subway Line, currently under further review, was slated for the area under Park Avenue in the East 30s. Although the core infrastructure will be housed below street level, construction for its placement will certainly affect the surrounding neighborhood in various ways, including noise, potential street closures, pedestrian detours, and general traffic flow disruptions. The MTA estimates a project duration of over 4.5 years. As many of these streets feed the Queens Midtown Tunnel, CB6 and the surrounding community are especially concerned since we already experience elevated traffic congestion. As the MTA has further delayed this action item pending review of possible alternatives to the original plan, we await a resolution that is considerate of the community in this project-intensive neighborhood. The L Train shutdown is one of the community’s top concerns, with a projected interruption in service of 18 months from commencement. At the time of this document’s composition, the city has released initial plans for the shutdown that include significantly increased transit service along the L corridor & traffic restrictions designed to assist buses, but the board expects that the agencies in charge of the mitigation plans will be prepared to further bolster transit if the existing measures prove to be initially insufficient. The board is pleased that requests to make the 1Av L Train subway station ADA compliant has resulted in the funding/construction of plaform elevators at that station, and hopes that, along with vital upgrades to the line, the MTA will consider making L train stops further compliant with ADA regulations – the opportunity to close these stations fully presents a unique opportunity to promote accessibility. Additionally, CB6 has identified other transit issues that it looks to solve with its transit agency partners: 1) Reinstatement of local bus stops on crosstown bus lines, particularly on the M34, M34A and M23 lines; 2) Providing connectivity of bus services with existing bus routes and with proposed ferry services; 3) completion of an additional entrance for the First Ave station of the L subway line; and 4) increasing efficiencies of bus lanes along First and Second Avenues to decrease clustering and improve travel times. Real-time Passenger Information would also be helpful, especially along our Select Bus Service lines. Finally, we want to ensure the MTA and NYCTA remain vigilant in its oversight of maintenance at stations managed and constructed by private developers. The long-term upkeep of these stations requires continued supervision and their completion should be monitored for unreasonable delays.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/33
NYCTA
Improve
Of the five subway stations that have subway
accessibility of
entrances in Community District 6 (1st Avenue,
transit
3rd Avenue, Grand Central-42nd Street, 51st
infrastructure, by
Street/Lexington Avenue-53rd Street, and 59th
providing elevators,
Street/Lexington Avenue-59th Street), only one
escalators, etc.
of the stations is currently fully accessible. There
are heavily-used stations in and near our
district, such as Lexington Avenue-59th Street
and 33rd Street, that are not ADA-compliant
and are currently not slated for accessibility
improvements in the Proposed 2020-2024
Capital Plan. The City should provide funding to
the MTA to make subway stations in and near
our district accessible by constructing elevators
and accessible entrances to subway platforms.
11/33
DOT
Rehabilitate bridges
Waterside Plaza has an existing pedestrian
bridge at East 25th Street which should be
modified to allow handicap access at its western
end. The agency should also work with
Waterside to make sure that resident concerns
are addressed including the installation of safer
surfaces that reduce problems in snow and rain,
improved lighting and other safety issues. It is
our understanding that the project is in the Ten-
Year Plan but we want to ensure that the funds
remain and that the project is completed.
13/33
DOT
Other
Post office trucks have no suitable parking
transportation
options and therefore park on our district's
infrastructure
streets, taking away parking spaces from
requests
residents. Residents frequently complain about
post office trucks parking on our streets. A post
office truck depot or other solution would
increase parking availability.
16/33
NYCTA
Other transit
Numerous express buses that originate in the
infrastructure
outer boroughs end their routes in or near
requests
Community District 6. However, these buses
have no suitable parking options and therefore
park in our district's streets, taking away
parking spaces from residents and blocking bus
lanes. Residents frequently complain about
express buses parking along 34th and 57th
Streets, and in the 2nd Avenue bus lane. CB6
has passed resolutions in support of finding
layover locations for these buses. A bus depot or
other solution will removed obstructions from
our bus lanes and increase parking availability.
22/33
NYCTA
Repair or upgrade
The East Side of Manhattan is under-served by
subway stations or
the transit system. The Lexington Avenue lines
other transit
are grossly over-crowded; many Eastside
infrastructure
residents and commuters walk over a half mile
to already overly-congested trains. Phases 3 and
4 of the Second Avenue Subway are expected to
benefit Community District 6. We eagerly await
the completion of this work and ask the City to
not delay this work.
24/33
DOT
Install streetscape
CB6 requests that DOT Install and remediate
improvements
drainage for curb cuts at intersections
throughout the district.
29/33
DOT
Improve traffic and
We request automatic walkway counters at
pedestrian safety,
strategic locations throughout CD6 that would
including traffic
collect counts for pedestrians and cyclists. This
calming (Capital)
data would be valuable for multi-modal
planning in CB6 for pedestrians and cyclists,
specifically for projects relating to the new
Green Wave initiative and other system
improvements in CD6. Ideal counters would be
able to differentiate between cyclists and
pedestrians and distinguish the direction of
users. Data would then be made available to
CB6 through monthly reports or an online
dashboard made accessible by the CB6 Office. A
permanent walkway counter would allow for
the collection of data year-round, making it
easier to understand total use and identify
trends over time. This data can help CB6 make a
case for future investments and service
requests.
CS DOT Upgrade or create new greenways
From 13th to 15th Street, the waterfront esplanade heads north of East River Park past the Con Edison pier. While this section has been reconstructed to allow a wider path for bikers and pedestrians, there is a section of the path that remains narrow and promotes collisions - known as the "pinch point." Using some existing FDR Dr infrastructure, the Blueway Plan outlines an elevated, safer pedestrian and biker bridge that also separates the public from the Con Ed facility. CB6 requests that this plan be further studied and funded.
East River Esplanade East 13th Street East 15th Street
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
11/20
DOT
Conduct traffic or
The entrance area for the Queens Midtown
parking studies
Tunnel is plagued by numerous problems:
constant traffic backups, slow buses, pedestrian
safety issues, and a lack of a bicycle lane for the
part of Second Avenue that includes the Queens
Midtown Tunnel area. All these issues need
addressing, but first, CB6 believes that the NYC
Department of Transportation needs to perform
a comprehensive traffic study that can figure
out how to best address these issues. CB6
requests a traffic study for the Queens Midtown
Tunnel entrance area, with the study area being
between 38th and 33rd Streets (north to south)
and between the FDR Drive and 3rd Avenue
(east to west).
14/20
DOT
Other expense
For each of the past several years, well over
traffic
1,000 calls about street conditions have been
improvements
made to 311 in the Community District 6 area.
requests
Given this fact, robust paving personnel is
necessary to repair roads in poor condition as
well as keep roads in good condition. Having
more paving crews would also prevent lane
closures, improve traffic in spots, and avoid
damage to cars, trucks and city vehicles due to
potholes and sinkholes.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 6
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
CB6 selects parks as a capital priority because of limited open space in our district. In a borough-wide comparison, CD6 has the least amount of open space and outdoor recreation. CD 6 is also one of the densest districts in New York City, with 146.8k residents and 18 acres of park space. Compared to other districts, the ratio of parks to people is disproportionate, ranking open space as one of CB6’s top capital and expense objectives. CB6 advocates for additional open space and improved park facilities that provide a visual relief in densely developed areas like CD 6.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
I ncrease in CD 6’s Youth Population
In CD 6, 8.7 percent of the residents are under the age of eighteen and this number is only growing. Between the years of 2020 and 2030, the Department of City Planning (DCP) projects an 8.9 percent increase in children between the ages of 5 and 17. To support an increase in CD 6’s youth population, CB6 requests additional active open space and playgrounds.
image
C D 6’s Privately Owned Public Spaces
With 16 parks, concentrated from 2nd Avenue to the East River, the district lacks adequate access to open space and recreation. In this subsection of Midtown, from Lexington to 2nd Avenue, there is a concentration of privately owned public spaces (POPS). Thus, preservation of our 77 POPS are vital due to our low park count in densely populated neighborhoods. We ask for the city’s support in ensuring that they are compliant and accessible.
In 2008, CB6 began surveying the district's POPS. Currently, CB6 is updating the survey with new observations. This report will provide a guide to and a survey of the varying physical condition of many of these often-overlooked sites. CB6 recommends that POPS are not quantified as parkland, to ensure that that there is an accurate count of acreage attributed to CD 6 for open space and active recreation. CB6 discerns POPS’s importance but advocates for additional recreation and open space, outside of flood prone areas (between Lexington and 2nd Avenues).
C D 6’s Flood Zone
Thirteen of CD 6’s parks are in the 2050 floodplain: Sutton Place Park South, Peter Detmold, Robert Moses Playground, St. Vartan Park, Glick Park, Asser Levy Park, Peter’s Field, Augustus St. Gaudens Playground, Stuyvesant Square Park, Con Edison Field, Captain Patrick J. Brown Walk, Stuy Cove (EDC), and Waterside Pier (EDC). During the East Side Coastal Resiliency (ESCR) Project, Murphy Brothers Playground, Stuyvesant Cove Park, Asser Levy Playground and Captain Patrick J. Brown Walk will be remodeled and upgraded to include improved programming, landscapes, recreational fields, playgrounds, and/or amenities. It is estimated that these parks will be closed for 3.5 to 5 years. As part of the ESCR project, a flood barrier will be deployed to prevent flood inundation, still, CB 6 advocates for supplemental action. The interior of the Asser Levy Recreation Center requires infrastructural upgrades for functional improvement and to deter storm damage. In the event of a flood, additional capital upgrades that flood proof the recreation center could have monetary benefits. CB6 recommends that the Department of Parks & Recreation (DPR) conduct a cost benefit analysis on floodproofing parks that are in the flood plain. CB6 advocates for resilient materials in parks, floodproofing, and waterfront zoning for buildings on our waterfront.
N ew Park for CD 6
During the ESCR project, CB6 advocates for additional mitigation in CD 6, particularly on our waterfront. In many stretches of CD 6, residents cannot access their waterfront. This is because the FDR obstructs the greenway. Many segments ‘Under the Elevated’ FDR highway are dark, unsafe, and unfit for community activity. These segments on the waterfront can be repurposed to act as mitigation for the ESCR project. One such space that comes to mind is the 34th Street parking lot, which obstructs pedestrian views, impacts safety, and connectivity. Waterfront open space has a proven track record of turning desolate spaces into networks of community exchange that foster economic growth; thus, a waterfront park has the potential to be a resource for CD 6 residents.
T ree Planting & Bioswales for CD 6
CB6 thanks DPR for their mitigation efforts through targeted tree planting and urban forest enhancements, which proposes 1,000 tree plantings in parks and streets, and 40 bioswales starting in fall of 2019. CB6 welcomes collaboration between the DPR and City Council Members to create these capital improvements. CB6 recommends that Partnerships For Parks expand its programming and gardening services throughout CD 6.
I rrigation Systems for CD 6’s Parks
Irrigation in parks is used for water fountains, sprinkler systems, and tree watering. DPR says that watering your street tree or greenstreet is very important and is an extreme challenge for parks workers and residents. If more parks had irrigation systems, it would free up time for parks workers, residents, and would produce healthy trees. By irrigating parkland, you can improve quality of life, intercept stormwater, conserve energy, remove air pollutants, and reduce carbon dioxide. Out of CD 6’s sixteen parks, A ugustus St. Gaudens Playground, Bellevue South Park, and
S t. Vartan Park are the only three with sprinkler systems. Parks with sprinklers can be used as cooling stations on hot days in New York City. Out of CD 6’s sixteen parks, Asser Levy and Stuyvesant Square Park are the only two with fountains. Community Board 6 advocates for water in all of our parks, especially in the parks with dog runs like Robert Moses and Peter Detmold, to keep our animals hydrated.
A dditional Parks Staff for CD 6
CB6 continues to stress the need for increased staffing at parks and recreation centers. Upkeep would improve with specialty staff such as a dedicated district gardener, city parks workers, and additional welders. As we address these maintenance issues, we seek better security from additional PEP officers and cameras for the southern command.
Needs for Cultural Services
In CD 6 we host two important museums with distinguished collections, eleven theaters, and eight music venues or schools. CB6 is always supportive of existing and enhanced supportive programs that allow these smaller theaters and lower-key museums to thrive, through direct grants or via funding to community organizations that utilize them. CB6 also acknowledges that schools and universities in our district, as well as long-standing art institutes, contribute to cultural creation. Additionally, public works of art are considered of benefit in CD 6, and we welcome the continued use of corporate or public plazas to host artistic installations that enhance the cultural program of the area. We also encourage a conversation to identify additional locations for public art in our district. CB 6 also encourages partnership with local Business Improvement Districts to support the implementation of cultural events, connecting residents to these experiences.
Needs for Library Services
In 2020, the City Council’s Fiscal Executive Plan granted library systems a $387.1 million subsidy, while in fiscal year 2019, library systems were granted $387.7 million, which is a $589,000 decrease in funding. CB6 supports capital and expense funding increases for libraries city-wide. In CD 6 we host three libraries: the Epiphany Library, Grand Central Library, and Kips Bay Library. In FY19, the Epiphany Library had 198,399 visits and 16,645 participating in programing; the Grand Central Library had 220,323 visits and 15,329 participating in programing; the Kips Bay Library had 136,350 visits and 10,469 participating in programing. This data shows that Epiphany Library and Grand Central Library both have a large audience for programming, and therefore, an increased budgetary need. Libraries have become a resource nation-wide; in 2015, more than one-third of all libraries provide literacy training, GED preparation, STEAM, and afterschool programs. Programs like these can uplift New York City’s youth, building a
support net for a brighter future. Virtually all libraries, 98 percent, offer free public Wi-Fi access, which is a great resource for afterschool study and for remote employees. CB6 advocates for additional programing, educational resources, and electronic resources in all of CD 6’s branches. Additionally, programs for subgroups like seniors are increasingly provided by libraries, and as requested of DFTA, we believe the library system should increase its services to older New Yorkers seeking social and educational stimulation.
Needs for Community Boards
CB6 took a big step forward in 2018 with the acquisition and occupation of a new board office, satisfying a long- standing desperate need. Although the board itself is now sufficiently sited within this office for years to come, many of our community-based service institutions face problems in arranging usable facilities for their functions. Additionally, common office/meeting spaces can serve functions as general community centers open to the public, centers for specialized programming, and polling places for BOE operations. We urge our officials to consider possible existing or new, permanent sites that can satisfy these outstanding needs, so that our district has a sufficient supply of welcoming community facilities for local groups and residents-at-large. As we prepare this document, data-driven analysis of community conditions helps us make the case for our stated needs.
Unfortunately, we run into some roadblocks as we collect this information. Communications between some city agencies and the board need to be improved. Consultation on district capital projects is required by the NYC Charter but too often the board is often informed about decisions without appropriate notice. As a result, CB6 is unable to provide timely information to community-based organizations and loses resident feedback on some of our most important projects. While Open Data portals have improved, creating datasets remains difficult for the layperson – therefore, we miss out on potentially useful mapping and summaries of information on a host of issues. Thankfully, DCP has recently released a district portal with a good deal of information about the community’s population, zoning issues and other information useful in analyzing the state of our neighborhoods. A more user-friendly experience to build our as-needed research capabilities on Open Data would still be helpful. Moreover, the continued breakdown of census and agency information by community district, spearheaded by DOITT and DCP, is essential. Finally, appropriate funding for the CB6 office is essential to provide the level of analysis and service our community should expect. Despite recent increases in funding, the increases are not baselined and are a bare minimum to keep the board office functioning on a basic level. Additional funds would allow us to hire more staff or fund studies and surveys that would help us better target hyperlocal services. We would also support any legislation mandating additional, specialized staff to assist board offices, such as community and/or urban planners.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
8/33
DPR
Provide a new or
CD 6 has the least amount of parkland in the
34th Street &
expanded park or
borough. While densely developed, our district
the FDR
playground
has parcels of underutilized land that should be
repurposed as park space. Apart from the
276,000 sq ft of privately-owned land that has
sat vacant for many years in the middle of our
district, at 34th Street, there are two prime
waterfront spaces: one is an 11,000 sq ft City-
owned property that is current used as a
parking lot and the other is a 40,000 sq ft City-
owned heliport that adversely impacts the
quality of life of nearby residents and was the
origin of the helicopter that crashed into a
midtown office building on June 10, 2019, killing
the pilot. There is an approximately 25,000 sq ft
City-owned waterfront space at 30th Street that
is only used intermittently as a party venue.
9/33
DPR
Reconstruct or
On behalf of the Office Manager at Asser Levy
392 Asser
upgrade a building
Recreation Center, CB6 requests that the
Levy Place
in a park
Department of Parks & Recreation (DPR)
replaces, upgrades, and flood proofs Asser Levy
Recreation Center’s windows. CB6 requests that
the DPR replaces all ceiling tiles at the
recreation center. CB6 request that indoor pool
dehumidifier/HVAC system is repaired and LED
lights are added in the pool. CB6 requests that
air conditioning is installed throughout the
building. CB6 request that the men’s locker
room, woman’s locker room, and handicapped
restrooms are remodeled to include new toilets,
hand dryers, showers and sinks.
10/33
DCAS
Renovate, upgrade
or provide new community board facilities and equipment
For a City agency like CB6, leasing office space
from a private landlord can be unreliable, evidenced by CB6’s 4 different offices in the past 3 ½ years. The City procurement process to rent office space requires a minimum of 18 months, which is impractical in CD6’s real estate market. Additionally, the space limit the City imposes on community board office space is too small to meet our Charter-mandated public meeting needs. CB6 therefore requests a City-owned office space with facilities to accommodate public meetings and events of varying sizes.
Such a facility could be used by CB6, City
agencies, elected officials, and nonprofit organizations and also serve as a polling place
—something CD6 lacks—and could be part of NYCEM’s Share Your Space initiative in a citywide emergency.
14/33
DPR
Provide a new or expanded parks facility, e.g. recreation center
CB6 requests a new comfort station at Murphy's Brother's Playground. There are only five comfort stations in CD6 parks.
Avenue C, Manhattan, New York, NY
17/33
NYPL
Create a new, or renovate or upgrade an existing public library
CB6 has been speaking with the office manager at The Epiphany Branch who has informed us that the library needs their exterior brick facade renovated/upgraded.
228 East 23rd Street
18/33
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
CB6 requests that there is irrigation and water access at Peter Detmold Park.
19/33
DPR
Reconstruct or upgrade a building in a park
CB6 board members request that the bluestone sidewalk at Ralph J. Bunche Park is reconstructed. The bluestone pavers have been deteriorating for years and are dangerous to pedestrians.
20/33
DPR
Reconstruct or upgrade a building in a park
CB6 requests the elevators are renovated and that the roof is reconstructed.
21/33
DPR
Provide a new or expanded parks facility, e.g. recreation center
Murphy's Brother's Playground has 52,930 square feet of active and passive open space. CB6 requests that a dog run is added at this location because there are few in the area.
Avenue C, Manhattan, New York, NY
23/33
DPR
Provide a new or
expanded parks facility, e.g. recreation center
St. Vartan Park has 90,585 square feet of active
and passive open space. As one of CD 6's largest parks, CB6 requests that a dog run is added at this location.
1 Avenue,
Manhattan, New York, NY
25/33
DPR
Enhance park safety
A video security system at Bellevue South Park
315 East 26th
through design
would increase security for people using the
Street
interventions, e.g.
park and help identify and deter criminal
better lighting
activity. Manhattan CB6 board office continues
(Capital)
to receive notices from residents about
problems at this site. Members of the board
who reside at this location report that regularly
they see inappropriate and vulgar behavior.
26/33
DPR
Enhance park safety
Friends of Dag Hammarskjold Park and local
831 1st
through design
residents request the installation of video
Avenue
interventions, e.g.
camera(s) in the Garden Area of Dag
better lighting
Hammarskjold Park. District residents have
(Capital)
reported criminal or offensive public behavior in
the Park but PEP Officers and law enforcement
are hindered by the need to actually observe the
behavior when it occurs. Surveillance by video
camera(s) would be a cost-effective means to
identify incidents and deter future illegal
activity.
27/33
NYPL
Provide more or
CB6 requests additional electronic resources for
better equipment to
library branches in CD 6 (Kips Bay, Epiphany,
a library
and Grand Central branches). With library
usage at record highs, primarily by those
seeking to use computers for job searches,
college applications, grant and benefits
research, and other essential reasons, branches
should be equipped with additional and
upgraded computer stations and fiber optic
cabling. Alternative electronic equipment such
as newer servers, research platforms and
tablets would also help connect all New Yorkers
to better data and opportunities.
28/33
DPR
Improve access to a
CB6 requests that the lights at Tudor City's
328 East 42
park or amenity (i.e.
entrance ramps at 42nd and 1st Avenue are
Street,
playground, outdoor
repaired. For the past years, there has been a
Manhattan,
athletic field)
conversation about jurisdiction between the
New York, NY
Department of Parks & Recreation and
Department of Transportation. CB6 asks that
this discrepancy is resolved because at night the
staircases are dangerous.
31/33
DPR
Improve access to a
CB6 requests a pedestrian overpass be built
park or amenity (i.e.
between Murphy's Brother's Playground &
playground, outdoor
Stuyvesant Cove Park. Due to heavy and fast
athletic field)
traffic coming off FDR Dr, access to Stuyvesant
Cove Park is dangerous to pedestrians. An
overpass connecting the two parks is a solution
to a safety problem. It is also consistent with our
197-a Plan.
32/33
DPR
Reconstruct or
MacArthur Park is seeing significantly increased
upgrade a park or
usage by families and requires up-to-date
amenity (i.e.
equipment in the playground.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Restore Lighting in East River Esplanade (Glick
FDR Drive and
upgrade a building
Park). The lighting in the park was damaged in
East 36 Street
in a park
Superstorm Sandy and has not been repaired.
The lighting is essential to full enjoyment of the
park and more importantly, as a security
measure. This item has been listed as a
"possible project" on the Parks Department
profile page, and we look forward to completion
of the work once federal funds are fully
available.
CS
DPR
Reconstruct or
Restoration of function to the East River
FDR Drive and
upgrade a building
Esplanade Park (Glick Park) fountains by
E 36th Street
in a park
replacing the pumps for water circulation and
the electrical systems would add considerably to
the attractiveness and use of the park. We look
forward to seeing design proposals and a fully
funded commitment.
CS
DPR
Reconstruct or
Repair Fountains in Dag Hammarskjold Plaza.
upgrade a building
Most of the fountain equipment has been under
in a park
water for more than a decade and is hopelessly
corroded. This includes both plumbing and
electrical wiring. The Friends of Dag
Hammarskjold Plaza takes a custodial interest
and will do what it can, but the Plaza should be
a world-class park and outstanding
neighborhood amenity worthy of funding by the
city. We look forward to this work's completion.
CS
DPR
Reconstruct or
Community Board 6 supports the Department of
348 East 54th
upgrade a building
Parks and Recreation proposal to convert the
Street
in a park
roof of the 54th Street Recreation Center into a
passive recreation space. We encourage the City
to fully fund this project to a timely completion.
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Bellevue South Park requires a re-designed layout to make the space more workable for both adults and children to enjoy in defined areas. Playground spaces need consolidation to ensure they are secure for children and their guardians. This would allow separate access for adults not accompanying children to use spaces separately. The park would also benefit from a new dog run to foster greater usage from the surrounding neighborhood. Currently, the $1.1 Million has been allocated for a renovation of the basketball courts and installation of a dog run. We await further scoping on what additional work can be done to make this a fully ADA compliant project.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
4/20 DPR Enhance park safety
through more security staff (police or parks enforcement)
Park Enforcement Patrol (PEP) officer presence reduces illegal or inappropriate behavior and increases the opportunity for peaceful and safe enjoyment of the parks by both children and adults. CB6 would like more frequent patrols in our district. Current levels of roving enforcement are not sufficient to address quality of life issues in our parks; more fixed patrols are needed. In this vein, we support funding of 1 additional sergeant and 8 additional PEP officers for Manhattan South.
image
5/20 DPR Provide better park
maintenance
CB6 continues to stress the need for increased staffing at parks and recreation centers. Upkeep would improve with specialty staff such as a dedicated district gardener, city parks workers, and additional welders DPR. Current levels of maintenance and operations staff are not adequate to maintain our parks, and our landscaping suffers from lack of gardening and accessibility. It should be noted that non- governmental funding (i.e. conservancies) is not available for any parks in CD6. As a district suffering from lack of park space, maintaining what little we have is crucial.
image
7/20
OMB
Provide more
community board staff
In Fiscal Years 2019 and 2020 all 59 Community
Boards received a non-baselined $42,500 increase to their OTPS budget. For at least the past four fiscal years, there has been no increase in Community Boards’ base budgets. CB6 has advocated for additional base budget funding for Community Boards in our last several District Needs Statements. Additional base budget funding would allow Community Boards to hire new staff and retain current staff, allowing for ambitious community planning projects and constituent services. Retention of staff will be vital with term-limited board members, as district offices will become the repository for the institutional memory of districts. CB6 requests that each community board has their base budget increased to at least $276,411 starting in Fiscal Year 2021.
211 East 43rd
Street
17/20
DPR
Provide more programs in parks or recreational centers
To mitigate the loss of park space and active recreation space in CD6 as a result of the ESCR project construction, CB 6 requests that DPR do more outreach and alternative programming at locations with available space for active recreation activities.
19/20
NYPL
Extend library hours or expand and enhance library programs
CB6 requests funding full Service Hours at Kips Bay, Epiphany and Grand Central Libraries. CB6 also requests that service is added seven days a week in FY 2021. CB6 asks that recently increased funding levels be baselined.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority Agency Request Explanation Location
image
18/20 LPC Expand staffing and
program related services
There are currently 6 designated Historic Districts within Manhattan Community District 6 that need to be monitored and additional areas should be considered for designation. Current Landmarks Preservation Commission staffing levels are not sufficient to physically inspect properties nor to process new (or outstanding) landmark applications. We ask that staffing at the agency increase.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/33
HPD
Provide more
CB6 requests the preservation of existing and
housing for
the development of NEW low- and moderate-
extremely low and
income housing in CD6. Over the past 15-20
low income
years, a loss of Mitchell-Lama, and loss of
households
Section 8 housing, and loss of rent-controlled
and loss of rent-regulated housing, have caused
areas in CD6 to become increasingly more
income segregated. In order to support and
retain our existing population and promote
economic diversity, we call upon the City to
commit at least $20 Million to provide new or
reclaimed low-and moderate-income housing
within our district in the forthcoming year.
2/33
HPD
Provide more
CB6 requests city dollars be committed to the
housing for special
development of additional permanent housing
needs households,
for homeless families. There is an insufficient
such as the formerly
supply of housing for homeless families. HPD
homeless
needs to allocate to homeless families just five
percent (5%) more of the vacant units that
become available annually from the city's
existing affordable housing resources. These
resources include public housing, Section 8 rent
subsidies and units developed by HPD, and
inclusionary zoning on rezoned manufacturing
and Brownfield sites.
3/33
NYCTA
Improve
Of the five subway stations that have subway
accessibility of
entrances in Community District 6 (1st Avenue,
transit
3rd Avenue, Grand Central-42nd Street, 51st
infrastructure, by
Street/Lexington Avenue-53rd Street, and 59th
providing elevators,
Street/Lexington Avenue-59th Street), only one
escalators, etc.
of the stations is currently fully accessible. There
are heavily-used stations in and near our
district, such as Lexington Avenue-59th Street
and 33rd Street, that are not ADA-compliant
and are currently not slated for accessibility
improvements in the Proposed 2020-2024
Capital Plan. The City should provide funding to
the MTA to make subway stations in and near
our district accessible by constructing elevators
and accessible entrances to subway platforms.
4/33
HPD
Provide more
During his 2019 State of the State address
housing for special
Governor Cuomo announced a new
needs households,
commitment to build or rehabilitate 20,000
such as the formerly
supportive housing units statewide over the
homeless
next fifteen years. As CD 6 has only one
supportive housing facility, Kenmore Hall, CB6
asks that additional supportive housing units be
built in CD 6—especially given CD 6’s proximity
to many public health facilities that support this
population. In addition to this commitment to
the building of new supportive housing units, CB
6 asks that the City and State ensure that
supportive housing providers be fully funded so
that they can continue to operate their current
facilities. Additionally, CB6 requests more
affordable assisted living and senior housing in
CD 6 to accommodate the aging population of
this district.
5/33
EDC
Invest in capital
According to the Department of City Planning,
East River
projects to improve
New York City boasts 520 miles of waterfront
Esplanade E
access to the
and as such our waterfront is a significant
14th Street E
waterfront
resource for our city. Our waterfront has for
59th Street
many years been a particular priority for
Manhattan Community Board Six. Currently our
community cannot access large segments of our
waterfront because our waterfront esplanade
has significant gaps in it. In a city where we all
live in such close quarters, our outdoor spaces,
especially our waterfronts, are all the more
valuable. And for districts like ours, which the
Department of City Planning has confirmed has
“the lowest amount of open space per capita of
Manhattan community districts” , we feel this
need most acutely. CB6 requests updated
timelines for the esplanade and bikeway plans
when possible.
6/33
HHC
Provide a new or
The Children's Comprehensive Psychiatric
462 First
expanded health
Emergency Program at Bellevue Hospital is the
Avenue
care facility
only psychiatric emergency care environment in
New York State, and one of three in the world,
dedicated solely to the care of children and
adolescents. With significant growth in usage, it
is essential that Bellevue expand the physical
space dedicated to these services. This project is
fully funded through a New York State grant in
the amount of $1,352,520, and the project is
now in design. CB6 requests that the project
proceed with no significant delays.
7/33
NYCHA
Install security
For many years, residents of Straus Houses have
cameras or make
urged NYCHA to improve security. Most pressing
other safety
is the need for new front and rear lobby doors
upgrades (Capital)
incorporating layered access control. The lack of
layered access and the general malfunctioning
of the doors constitutes a significant safety and
security concern for residents and management
—for example, there have been multiple fires
set in the stairwells by non-residents in 2019.
Given that neighboring 344 East 28th Street is
undergoing a PACT conversion and thus will
have its security needs paid for by the new
management company, NYCHA should redirect
security funding to Straus houses once the 344
PACT conversion occurs.
8/33
DPR
Provide a new or
CD 6 has the least amount of parkland in the
34th Street &
expanded park or
borough. While densely developed, our district
the FDR
playground
has parcels of underutilized land that should be
repurposed as park space. Apart from the
276,000 sq ft of privately-owned land that has
sat vacant for many years in the middle of our
district, at 34th Street, there are two prime
waterfront spaces: one is an 11,000 sq ft City-
owned property that is current used as a
parking lot and the other is a 40,000 sq ft City-
owned heliport that adversely impacts the
quality of life of nearby residents and was the
origin of the helicopter that crashed into a
midtown office building on June 10, 2019, killing
the pilot. There is an approximately 25,000 sq ft
City-owned waterfront space at 30th Street that
is only used intermittently as a party venue.
9/33
DPR
Reconstruct or
On behalf of the Office Manager at Asser Levy
392 Asser
upgrade a building
Recreation Center, CB6 requests that the
Levy Place
in a park
Department of Parks & Recreation (DPR)
replaces, upgrades, and flood proofs Asser Levy
Recreation Center’s windows. CB6 requests that
the DPR replaces all ceiling tiles at the
recreation center. CB6 request that indoor pool
dehumidifier/HVAC system is repaired and LED
lights are added in the pool. CB6 requests that
air conditioning is installed throughout the
building. CB6 request that the men’s locker
room, woman’s locker room, and handicapped
restrooms are remodeled to include new toilets,
hand dryers, showers and sinks.
10/33
DCAS
Renovate, upgrade
For a City agency like CB6, leasing office space
or provide new
from a private landlord can be unreliable,
community board
evidenced by CB6’s 4 different offices in the past
facilities and
3 ½ years. The City procurement process to rent
equipment
office space requires a minimum of 18 months,
which is impractical in CD6’s real estate market.
Additionally, the space limit the City imposes on
community board office space is too small to
meet our Charter-mandated public meeting
needs. CB6 therefore requests a City-owned
office space with facilities to accommodate
public meetings and events of varying sizes.
Such a facility could be used by CB6, City
agencies, elected officials, and nonprofit
organizations and also serve as a polling place
—something CD6 lacks—and could be part of
NYCEM’s Share Your Space initiative in a
citywide emergency.
11/33
DOT
Rehabilitate bridges
Waterside Plaza has an existing pedestrian
bridge at East 25th Street which should be
modified to allow handicap access at its western
end. The agency should also work with
Waterside to make sure that resident concerns
are addressed including the installation of safer
surfaces that reduce problems in snow and rain,
improved lighting and other safety issues. It is
our understanding that the project is in the Ten-
Year Plan but we want to ensure that the funds
remain and that the project is completed.
12/33
SCA
Provide technology
PS 116 currently has no security system, making
210 East 33
upgrade
it difficult for the school to keep track of what is
Street,
going on throughout its building. It is especially
Manhattan,
problematic this year, as early voting and
New York, NY
classes are going on at the same time, without
a security system to ensure that both kids and
voters alike remain safe. Installing a security
system at PS 116 will be a major step towards
ensuring the safety of kids at the school.
13/33
DOT
Other
Post office trucks have no suitable parking
transportation
options and therefore park on our district's
infrastructure
streets, taking away parking spaces from
requests
residents. Residents frequently complain about
post office trucks parking on our streets. A post
office truck depot or other solution would
increase parking availability.
14/33
DPR
Provide a new or
expanded parks facility, e.g. recreation center
CB6 requests a new comfort station at Murphy's
Brother's Playground. There are only five comfort stations in CD6 parks.
Avenue C,
Manhattan, New York, NY
15/33
NYPD
Renovate or
CB6 requests that the 13th Precinct receive
230 E 21st
upgrade existing
funds for a full renovation or replacement of the
Street
precinct houses
precinct house. Though NYPD has replied that
this has been funded, requests for scope so far
only cite upgrades to wiring and aesthetics, not
the full structural work we have been told is
needed. With crime-fighting shifting more and
more to technology-heavy approaches,
precincts should be fully equipped with state of
the art hardware that would increase the
efficiency of uniformed and civilian staff. NYPD
management acknowledged the need and
requested our support for this request in 2016.
16/33
NYCTA
Other transit
Numerous express buses that originate in the
infrastructure
outer boroughs end their routes in or near
requests
Community District 6. However, these buses
have no suitable parking options and therefore
park in our district's streets, taking away
parking spaces from residents and blocking bus
lanes. Residents frequently complain about
express buses parking along 34th and 57th
Streets, and in the 2nd Avenue bus lane. CB6
has passed resolutions in support of finding
layover locations for these buses. A bus depot or
other solution will removed obstructions from
our bus lanes and increase parking availability.
17/33
NYPL
Create a new, or
CB6 has been speaking with the office manager
228 East 23rd
renovate or upgrade
at The Epiphany Branch who has informed us
Street
an existing public
that the library needs their exterior brick facade
library
renovated/upgraded.
18/33
DPR
Reconstruct or
CB6 requests that there is irrigation and water
upgrade a park or
access at Peter Detmold Park.
amenity (i.e.
playground, outdoor
athletic field)
19/33
DPR
Reconstruct or
CB6 board members request that the bluestone
upgrade a building
sidewalk at Ralph J. Bunche Park is
in a park
reconstructed. The bluestone pavers have been
deteriorating for years and are dangerous to
pedestrians.
20/33
DPR
Reconstruct or
upgrade a building in a park
CB6 requests the elevators are renovated and
that the roof is reconstructed.
21/33
DPR
Provide a new or
Murphy's Brother's Playground has 52,930
Avenue C,
expanded parks
square feet of active and passive open space.
Manhattan,
facility, e.g.
CB6 requests that a dog run is added at this
New York, NY
recreation center
location because there are few in the area.
22/33
NYCTA
Repair or upgrade
The East Side of Manhattan is under-served by
subway stations or
the transit system. The Lexington Avenue lines
other transit
are grossly over-crowded; many Eastside
infrastructure
residents and commuters walk over a half mile
to already overly-congested trains. Phases 3 and
4 of the Second Avenue Subway are expected to
benefit Community District 6. We eagerly await
the completion of this work and ask the City to
not delay this work.
23/33
DPR
Provide a new or
St. Vartan Park has 90,585 square feet of active
1 Avenue,
expanded parks
and passive open space. As one of CD 6's largest
Manhattan,
facility, e.g.
parks, CB6 requests that a dog run is added at
New York, NY
recreation center
this location.
24/33
DOT
Install streetscape
CB6 requests that DOT Install and remediate
improvements
drainage for curb cuts at intersections
throughout the district.
25/33
DPR
Enhance park safety
A video security system at Bellevue South Park
315 East 26th
through design
would increase security for people using the
Street
interventions, e.g.
park and help identify and deter criminal
better lighting
activity. Manhattan CB6 board office continues
(Capital)
to receive notices from residents about
problems at this site. Members of the board
who reside at this location report that regularly
they see inappropriate and vulgar behavior.
26/33
DPR
Enhance park safety
Friends of Dag Hammarskjold Park and local
831 1st
through design
residents request the installation of video
Avenue
interventions, e.g.
camera(s) in the Garden Area of Dag
better lighting
Hammarskjold Park. District residents have
(Capital)
reported criminal or offensive public behavior in
the Park but PEP Officers and law enforcement
are hindered by the need to actually observe the
behavior when it occurs. Surveillance by video
camera(s) would be a cost-effective means to
identify incidents and deter future illegal
activity.
27/33
NYPL
Provide more or
CB6 requests additional electronic resources for
better equipment to
library branches in CD 6 (Kips Bay, Epiphany,
a library
and Grand Central branches). With library
usage at record highs, primarily by those
seeking to use computers for job searches,
college applications, grant and benefits
research, and other essential reasons, branches
should be equipped with additional and
upgraded computer stations and fiber optic
cabling. Alternative electronic equipment such
as newer servers, research platforms and
tablets would also help connect all New Yorkers
to better data and opportunities.
28/33
DPR
Improve access to a
CB6 requests that the lights at Tudor City's
328 East 42
park or amenity (i.e.
entrance ramps at 42nd and 1st Avenue are
Street,
playground, outdoor
repaired. For the past years, there has been a
Manhattan,
athletic field)
conversation about jurisdiction between the
New York, NY
Department of Parks & Recreation and
Department of Transportation. CB6 asks that
this discrepancy is resolved because at night the
staircases are dangerous.
29/33
DOT
Improve traffic and
We request automatic walkway counters at
pedestrian safety,
strategic locations throughout CD6 that would
including traffic
collect counts for pedestrians and cyclists. This
calming (Capital)
data would be valuable for multi-modal
planning in CB6 for pedestrians and cyclists,
specifically for projects relating to the new
Green Wave initiative and other system
improvements in CD6. Ideal counters would be
able to differentiate between cyclists and
pedestrians and distinguish the direction of
users. Data would then be made available to
CB6 through monthly reports or an online
dashboard made accessible by the CB6 Office. A
permanent walkway counter would allow for
the collection of data year-round, making it
easier to understand total use and identify
trends over time. This data can help CB6 make a
case for future investments and service
requests.
30/33
EDC
Build or expand
CD6 hosts a premier medical corridor along First
First Avenue E
incubator or
Ave that includes several major hospitals and
23rd Street E
affordable work or
the successful Alexandria Center for Life Science.
34th Street
research lab spaces
This cluster of institutions, in addition to
university and training facilities, make our
district ideal for construction of additional,
affordable research lab space and tech-related
incubators. The rising cost in the traditional
office corridors discourages greater expansion
of these industries in New York. We welcome
the added employment opportunities they
bring, as well as the partnerships they can forge
with our educational centers. We encourage
exploration of city-owned sites for this purpose.
31/33
DPR
Improve access to a
CB6 requests a pedestrian overpass be built
park or amenity (i.e.
between Murphy's Brother's Playground &
playground, outdoor
Stuyvesant Cove Park. Due to heavy and fast
athletic field)
traffic coming off FDR Dr, access to Stuyvesant
Cove Park is dangerous to pedestrians. An
overpass connecting the two parks is a solution
to a safety problem. It is also consistent with our
197-a Plan.
32/33
DPR
Reconstruct or
MacArthur Park is seeing significantly increased
upgrade a park or
usage by families and requires up-to-date
amenity (i.e.
equipment in the playground.
playground, outdoor
athletic field)
33/33
DFTA
Create a new senior
The Board understands the lack of fed & state
center or other
funds for a new senior center, but asks DFTA to
facility for seniors
aggressively advocate for such funds & seek city
funds, in conjunction with other agencies, to
ensure adequate services to our aging
population. CD6 only has Stein Ctr & the Center
at St. Peter's, a satellite location of Lenox Hill
Houses. CB6 also notes DFTA's objective to
provide innovative senior ctrs and the life-long
learning concept clearly fits in the innovative
approach. If an addt'l physical location is not
feasible now, we ask that centers in CD6 have
these enhanced programs and that DFTA use
future support programs for seniors in other
spaces such as colleges & schools.
CS
DOT
Upgrade or create
From 13th to 15th Street, the waterfront
East River
new greenways
esplanade heads north of East River Park past
Esplanade
the Con Edison pier. While this section has been
East 13th
reconstructed to allow a wider path for bikers
Street East
and pedestrians, there is a section of the path
15th Street
that remains narrow and promotes collisions -
known as the "pinch point." Using some existing
FDR Dr infrastructure, the Blueway Plan outlines
an elevated, safer pedestrian and biker bridge
that also separates the public from the Con Ed
facility. CB6 requests that this plan be further
studied and funded.
CS
EDC
Invest in capital
Solar One conducts numerous educational
24-20 FDR
projects to improve
programs in the park using indigenous and
Drive East
access to the
exogenous varieties of plants as part of its
Service Road
waterfront
instruction for responsible environmental
practices. An irrigation system is essential for
survival of the plants used throughout
Stuyvesant Cove Park. We look forward to its
completion now that funds are committed as
part of resiliency efforts on the waterfront.
CS
DPR
Reconstruct or
Restore Lighting in East River Esplanade (Glick
FDR Drive and
upgrade a building
Park). The lighting in the park was damaged in
East 36 Street
in a park
Superstorm Sandy and has not been repaired.
The lighting is essential to full enjoyment of the
park and more importantly, as a security
measure. This item has been listed as a
"possible project" on the Parks Department
profile page, and we look forward to completion
of the work once federal funds are fully
available.
CS
DPR
Reconstruct or
Restoration of function to the East River
FDR Drive and
upgrade a building
Esplanade Park (Glick Park) fountains by
E 36th Street
in a park
replacing the pumps for water circulation and
the electrical systems would add considerably to
the attractiveness and use of the park. We look
forward to seeing design proposals and a fully
funded commitment.
CS
DPR
Reconstruct or
Repair Fountains in Dag Hammarskjold Plaza.
upgrade a building
Most of the fountain equipment has been under
in a park
water for more than a decade and is hopelessly
corroded. This includes both plumbing and
electrical wiring. The Friends of Dag
Hammarskjold Plaza takes a custodial interest
and will do what it can, but the Plaza should be
a world-class park and outstanding
neighborhood amenity worthy of funding by the
city. We look forward to this work's completion.
CS
DPR
Reconstruct or
Community Board 6 supports the Department of
348 East 54th
upgrade a building
Parks and Recreation proposal to convert the
Street
in a park
roof of the 54th Street Recreation Center into a
passive recreation space. We encourage the City
to fully fund this project to a timely completion.
CS
DPR
Reconstruct or
Bellevue South Park requires a re-designed
upgrade a park or
layout to make the space more workable for
amenity (i.e.
both adults and children to enjoy in defined
playground, outdoor
areas. Playground spaces need consolidation to
athletic field)
ensure they are secure for children and their
guardians. This would allow separate access for
adults not accompanying children to use spaces
separately. The park would also benefit from a
new dog run to foster greater usage from the
surrounding neighborhood. Currently, the $1.1
Million has been allocated for a renovation of
the basketball courts and installation of a dog
run. We await further scoping on what
additional work can be done to make this a fully
ADA compliant project.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/20
DYCD
Other runaway and
According to the latest research by NYU’s
homeless youth
Steinhardt School of Culture, Education and
requests
Human Development, one out of every eight
children in New York City experiences
homelessness before the Fifth Grade. The
trauma of homelessness leaves many children
unable to reach their full potential and in need
of expanded support. In addition, Elementary
schools across the entire city are seeing rises in
homeless students, including in Chinatown,
Midtown West and Midtown East, with some
schools experiencing rates of STH students as
high as 27%. These schools include institutions
in our neighboring Community Board Zones and
significantly impact children in PS 116 in the
CB6 Zone.
2/20
DHS
Expand street
CB6 requests that DHS fund a dedicated
outreach
homeless outreach team for the area near
Bellevue South Park, as this area is a hot spot
for street homelessness given its proximity to
the local hospital, outpatient clinics, and 30th
Street Men’s shelter.
3/20
NYCHA
Install security
CB6 requests that in addition to the requested
cameras or make
improvements to the physical security
other safety
infrastructure at Straus Houses, that a
upgrades (Expense)
permanent security guard be hired for this
complex. All of the nearby housing complexes of
a similar size (Kips Bay Court, Phipps Houses)
have hired their own private security teams. A
dedicated security detail would improve the
quality of life for the residents at Straus houses
and would create neighborhood equity, where
the public housing is on par with private
housing.
4/20 DPR Enhance park safety
through more security staff (police or parks enforcement)
Park Enforcement Patrol (PEP) officer presence reduces illegal or inappropriate behavior and increases the opportunity for peaceful and safe enjoyment of the parks by both children and adults. CB6 would like more frequent patrols in our district. Current levels of roving enforcement are not sufficient to address quality of life issues in our parks; more fixed patrols are needed. In this vein, we support funding of 1 additional sergeant and 8 additional PEP officers for Manhattan South.
image
5/20 DPR Provide better park
maintenance
CB6 continues to stress the need for increased staffing at parks and recreation centers. Upkeep would improve with specialty staff such as a dedicated district gardener, city parks workers, and additional welders DPR. Current levels of maintenance and operations staff are not adequate to maintain our parks, and our landscaping suffers from lack of gardening and accessibility. It should be noted that non- governmental funding (i.e. conservancies) is not available for any parks in CD6. As a district suffering from lack of park space, maintaining what little we have is crucial.
image
6/20 DFTA Enhance educational and recreational programs
A new senior facility providing meals and services has been requested by CB6 for over a decade. While we continue to advocate for an additional center in our district, our aging population would benefit from an expansion of programming that can be housed in existing City facilities or in sites run by community organizations, and funded by DFTA and other agencies. Libraries or CBOs, for example, can host or provide exercise programs, fall prevention programming (i.e., Tai Chi), life long learning, and technology programming.
image
7/20
OMB
Provide more
In Fiscal Years 2019 and 2020 all 59 Community
211 East 43rd
community board
Boards received a non-baselined $42,500
Street
staff
increase to their OTPS budget. For at least the
past four fiscal years, there has been no
increase in Community Boards’ base budgets.
CB6 has advocated for additional base budget
funding for Community Boards in our last
several District Needs Statements. Additional
base budget funding would allow Community
Boards to hire new staff and retain current staff,
allowing for ambitious community planning
projects and constituent services. Retention of
staff will be vital with term-limited board
members, as district offices will become the
repository for the institutional memory of
districts. CB6 requests that each community
board has their base budget increased to at
least $276,411 starting in Fiscal Year 2021.
8/20
NYPD
Assign additional
The Mayor has several policies and programs
traffic enforcement
meant to improve traffic flow and traffic safety
officers
in New York City, such as more protected bicycle
lanes, dedicated bus lanes, and Vision Zero.
However, because of a lack of traffic
enforcement in our district, those policies and
programs are left compromised. Protected
bicycle lanes are compromised because of
drivers interfering with those lanes. Bus lanes
are compromised because other vehicles park in
those dedicated bus lanes. Vision Zero is
compromised because of vehicles that travel in
a dangerous manner, therefore compromising
the safety and lives of pedestrians. Additional
traffic enforcement officers will be helpful in the
carrying out of these initiatives.
9/20
ACS
Provide, expand, or
CB6 requests that funding be enhanced for
enhance preventive
preventative services that allow families to
services and
remain together which maintaining the welfare
community based
of the children in the home. We understand
alternatives for
these programs are effective in preventing
youth
children from entering foster care and can
include services such as family or individual
counseling, parenting classes, substance abuse
treatment, domestic violence intervention,
home care, and support for pregnant and
parenting teens, among others. However, this
funding must be coupled with additional staff
and better training for caseworkers to ensure
children's safety.
10/20 DFTA Enhance home care
services
Allocate Additional Funding for Home Assistance Programs for the Elderly in CD6. 18.3% of the population of the district is over age 65. CB6 requests a higher level of attention to its elderly population. Increased availability of home assistance may become particularly important after the cutbacks in services at senior centers throughout the area. This method of care is far less expensive than subsidized nursing home care, which is typically the alternative.
image
11/20 DOT Conduct traffic or
parking studies
The entrance area for the Queens Midtown Tunnel is plagued by numerous problems: constant traffic backups, slow buses, pedestrian safety issues, and a lack of a bicycle lane for the part of Second Avenue that includes the Queens Midtown Tunnel area. All these issues need addressing, but first, CB6 believes that the NYC Department of Transportation needs to perform a comprehensive traffic study that can figure out how to best address these issues. CB6 requests a traffic study for the Queens Midtown Tunnel entrance area, with the study area being between 38th and 33rd Streets (north to south) and between the FDR Drive and 3rd Avenue (east to west).
image
12/20 DEP Investigate noise
complaints at specific location
Increase staffing of Noise Pollution Control Inspectors. In recent years, 311 and other reports show noise as 1 complain in the district. Aside from noise from late-night revelers and bars/restaurants, CD6 has also experienced increased complaints due to traffic congestion. Our roads are narrower due to bike/bus lanes and we have major approaches in our borders, such as the Queensboro Bridge and Queens Midtown Tunnel. We also host the 34th St Heliport and large construction projects that deserve monitoring. Finally, because of After-Hours Variances that are granted, there are complaints about late night construction noise. More inspectors would stay ahead of complaints with 24/7 monitoring, rather than the current after-the-fact on-site visits.
image
13/20
HRA
Provide, expand, or
CB6 would like to see enhanced funding for job
enhance job training
training programs in existence or under
development by HRA and its partners. These
programs seek to increase clients' skills,
readying them for employment and facilitating
their exit from public assistance. These
programs and associated training materials
should be free or low-cost so as not to deter
clients from participating.
14/20
DOT
Other expense
For each of the past several years, well over
traffic
1,000 calls about street conditions have been
improvements
made to 311 in the Community District 6 area.
requests
Given this fact, robust paving personnel is
necessary to repair roads in poor condition as
well as keep roads in good condition. Having
more paving crews would also prevent lane
closures, improve traffic in spots, and avoid
damage to cars, trucks and city vehicles due to
potholes and sinkholes.
15/20
DFTA
Enhance programs
With an aging population comes a greater need
for elder abuse
for attention to crimes perpetrated that are
victims
particular to seniors. Combating elder abuse,
whether physical (domestic) abuse or the
financial kind is critical in a district that has
18.2% of its population over the age of 65 (and
growing). CB6 asks for additional funds to be
devoted to specialized programs developed by
the Department for the Aging to identify and
prevent these situations. Additionally, more
data on the extent of elder abuse in our city
would be helpful in identifying needs in the
district and citywide.
16/20
NYPD
Assign additional
CB6 requests and increase in funding for the
uniformed officers
Neighborhood Coordination Officers Program at
the 13th and 17th precincts.
17/20
DPR
Provide more
To mitigate the loss of park space and active
programs in parks or
recreation space in CD6 as a result of the ESCR
recreational centers
project construction, CB 6 requests that DPR do
more outreach and alternative programming at
locations with available space for active
recreation activities.
program related services
Districts within Manhattan Community District 6 that need to be monitored and additional areas should be considered for designation. Current Landmarks Preservation Commission staffing levels are not sufficient to physically inspect properties nor to process new (or outstanding) landmark applications. We ask that staffing at the agency increase.
image
19/20 NYPL Extend library hours
or expand and enhance library programs
CB6 requests funding full Service Hours at Kips Bay, Epiphany and Grand Central Libraries. CB6 also requests that service is added seven days a week in FY 2021. CB6 asks that recently increased funding levels be baselined.
image
20/20 DOHMH Promote
vaccinations and immunizations
The recent measles outbreak in New York City occurred largely because of misunderstandings and misinformation about the measles vaccine. We believe that redoubling efforts on the promotion of vaccinations and immunizations would be an important step in making sure that outbreaks like this don’t happen in the future.

