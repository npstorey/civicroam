- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 12 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1md-M5oeLQoSCJnULC8bqIL9LpW6X4CWs/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1md-M5oeLQoSCJnULC8bqIL9LpW6X4CWs/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
12
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 12
image
Address: 530 West 166th Street, 6-A Phone: (212) 568-8500
Email: ebsmith@cb.nyc.gov
Website: www.nyc.gov/mcb12
Chair: Eleazar Bueno
District Manager: Ebenezer Smith
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Manhattan Community District 12 (CD12M) encompasses the most northern parts of Manhattan, including Washington Heights and Inwood. The district, which is geographically diverse, is bounded by the Harlem River Drive on the east side and by the Hudson River on the west side; and runs from West 155th Street to West 220th Street. We are a diverse community of 209,617 residents, an increase of 19,000 residents from the last survey (U.S. Census Bureau, 2010-2012 American Community Survey 3 Year Estimates - Population Division - New York City Department of City Planning (Jan 2014)), including a majority of residents 149,678 (71.4 percent) of Latino or of Hispanic heritage; 34,463 (16.4 percent) of White Non-Hispanic; 16,155 (7.7 percent) of Blacks/African American Non- Hispanic; 5,240 (2.5 percent) of Asian or Pacific Islander Non-Hispanic; 74 (less than 1 percent) of American Indian and Alaska Native Non-Hispanic. The largest group in the district is of Dominican descent. Community District 12 is also an immigrant community: the district has a foreign born population of almost 50% (102K residents), with 55.5% residents not being a citizen yet. The median age in the district is 36, and almost a quarter (20.6%) of our population is under 20 years old and 12.1% of our residents are over the age of 65. We also have a high poverty and unemployment rate: 21.2% of our residents live on incomes below the federal poverty threshold, with 33.5% of those people being under the age of 18. Our district median household income ($39,535) and the Manhattan median household income is ($66,739) . In addition, the American Community Survey 3-year estimates for 2010 through 2012 indicates that 10.3% of our residents ages 16 and over were unemployed and 33.6% were not in the labor force. In 2013 49.5% of our residents were one 1 or more forms of public assistance (an increase of 1.5% vs.
2005 when last measured, according to the Dept. of NYC Planning Community District 12 portal page. Notably, 31.5% of our adults over are over the age of 25 and do not have a high school diploma. Community District 12 urgently need employment services to increase the median household income, social/human services that support our working families, vocational training schools to raise resident skill levels to obtain competitive employment, provide more services for immigrant families, and more free ELS courses for non-English speaking residents.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 12
image
The three most pressing issues facing this Community Board are:
Affordable housing
We received many complaints from residents and small businesses indicating that their rents are too high and that their landlords are harassing them in multiple ways. For the foregoing reasons, CB 12, M recommend the City to increase funding for mandatory “right to counsel” for anyone who is rent-burdened (pays 50% of their income in rent) and also increase funding for legal representation in court. CB 12, M also request that Permanent Long Term Affordable Housing (Construction) - Build a high number of these apartments/housing units with immediate priority should be given to non-profit organizations and community land trusts that are partnered with non-profit developers. Emphasis should be given to 100% affordable housing based on the community's AMI.
Land use trends (zoning, development, neighborhood preservation, etc.)
Our district is facing a rezoning proposal made by the NYC and a rezoning application for the Inwood section of the district has been submitted to the Department of City Planning. CB 12, M request that the Department of City Planning should dedicate additional planning staff to work with CB12M and local residents to formulate and implement a contextual zoning plan for Washington Heights and Inwood and to provide technical assistance to CB12M and local residents to evaluate the Inwood Rezoning proposal including the draft and final Environmental Impact Statement.
Schools
The students attending the school in CB 12, M do not have the same advantage and opportunities than other students have Citywide. CB 12, M advocate for the following implementations in our district: 1. Class Size Reduction: The City shall increase funding to reduce class size in CSD6 as soon as possible. 2. Digital Library: CB 12, M would like to request that the City provide funding to build a Science, Technology, Engineering, and Math (STEM) “Digital Library” within School District Six. 3. The students in CB 12, M do not have enough afterschool options. CB 12, M needs an Afterschool System program and we request that the City increase funding for comprehensive afterschool programs including homework assistance and tutoring through CBOs in CSD6. 4. Biotech Laboratory: CB 12, M request that the City provide funding for a biotech laboratory and research facility for all students at the George Washington Educational Campus to insure there are opportunities for readiness, mentoring and hands an immersion on a genomic (DNA) level that is linked to a variety of career path in health /medical/science and non science fields. and a Computer Lab and upgrade Science Lab: Expand Computer Lab and upgrade Science Lab at M468- HS for Health Careers & Sciences.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 12
image
M ost Important Issue Related to Health Care and Human Services
Mental health and substance abuse treatment and prevention programs
In the Expense Budget Priorities for FY 2021 the most important issue for Health Care and Human Services is to expand mental health services in the community, including crisis intervention and acute care for persons with severe mental illness. It is also important for CB 12, M to increase services to prevent and treat chronic diseases, such as Alzheimer's, diabetes, cancer and heart disease. Provide funding to ensure that all local public schools have health clinics, is relevant for CB 12, M. Noise complaints have incremented considerable in our community, for this reason we request an increase staff that conduct regular noise enforcement, air quality monitoring and water quality testing in our community.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Our residents are less likely to have regular health care providers than those in NYC overall and foreign-born adults and men are least likely to have a regular doctor. Nearly one in ten residents use the emergency room, most likely at New York-Presbyterian Hospital, when they are sick or need medical advice. One in five local adults is obese, and almost one half do not exercise. The birth rate to teenage mothers is higher in this community than in all of Manhattan and NYC overall. On the plus side, the average annual death rates in our district is reported to be lower than in Manhattan and NYC overall. We would to request funds to undertake a comprehensive Needs Assessment of Community Board 12's LGBTQ community, identifying population, assets, unmet needs, strategies for assessing unmet needs, and additional collaborative and unique opportunities.
Needs for Older NYs
CB 12, M considered that the following issues are the most important for the Older New Yorker community within the district: Increase Expanded In Home Services For Elderly Persons (EISEP) funding to provide affordable home care, including sliding scale reimbursement. Increase funding for transportation for seniors by restoring prior City Council Funding and expand access to services. Increase access to appropriate, healthy food programs for seniors with medical needs. Increase funding for Naturally Occurring Retirement Communities to support currently unfunded mandate for nursing hours. Increase OTPS funding for replacement furnishings (non-capital) in senior centers as needed. System-wide upgrade of area senior centers to improve connectivity and WiFi
Needs for Homeless
We have a Homeless Shelter in our District in need of funding and more services. It is still a matter unresolved
Needs for Low Income NYs
We need the creation of a Workforce 1 in our district to provide training and help low income residents to find a good job.
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
7/48
DFTA
Renovate or upgrade a senior center
Renovate existing or build replacement senior centers as necessary to comply w/ ADA & DFTA regs
23/48
HHC
Other health care facilities requests
Funding for a new facility for the Washington Heights CORNER Project
27/48
DFTA
Renovate or upgrade a senior center
System-wide upgrade of area senior centers to improve connectivity for Wi-Fi and telecommunication services.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/44
DOHMH
Create or promote
Expand mental health services in the
programs to de-
community, including crisis intervention and
stigmatize mental
acute care for persons with severe mental illness
health problems
and encourage
treatment
2/44
DOHMH
Other programs to
Increase substance abuse services in our
address public
community, including opioid overdose
health issues
prevention education, and funding for syringe
requests
cleanups and collections
6/44
DHS,
Provide, expand, or
Increase Tenant support specialists specific to
HRA
enhance anti-
CD12,M and fund initiatives to inform and
eviction legal
educate tenants of their rights.
services
9/44
DFTA
Enhance home care
Increase the expansion in the program
services
"Expanded In Home Services For Elderly Persons
(EISEP)" funding to provide affordable home
care, including sliding scale reimbursement
(fees based on a customer's ability to pay).
11/44
DOHMH
Create or promote
Increase services to prevent and treat chronic
programs to de-
diseases, such as Alzheimer's, diabetes, cancer
stigmatize mental
and heart disease, in our community
health problems
and encourage
treatment
12/44
DFTA
Other senior center
Increase funding to expand services at senior
program requests
centers in CD 12, M to include hiring additional
social workers and program coordinators to
create culturally competent programs, adding
meals, extending hours, increasing per-meal
reimbursement rates, etc.
13/44
DOHMH
Provide more
Increase HIV/AIDS prevention and treatment
HIV/AIDS
services, and LGBTQ services, in our community
information and
services
14/44
DHS,
Other homelessness
Provide more funding for the Homebase
HRA
prevention program
Program in CD 12, M to prevent individuals and
request
families at imminent risk for entering the NYC
shelter system.
20/44
DOHMH
Other programs to
Provide funding to ensure that all local public
address public
schools have health clinics (DOHMH)
health issues
requests
23/44
DOHMH
Other animal and
Increase pest control efforts to eliminate rats,
pest control
cockroaches, etc. in our community (DOHMH).
requests
24/44
DHS,
Other homelessness
Increase funding for supportive housing for
HRA
prevention program
LGBTQ youth
request
26/44
DFTA
Increase
Increase funding for transportation for seniors
transportation
by restoring prior budget cuts and expand
services capacity
access and outreach to these services.
30/44
DOHMH
Increase health
Spanish-speaking health inspectors
inspections, e.g. for
restaurants
31/44
DOHMH
Other programs to
Create an educational campaign about the
address public
federal public charge rule to inform immigrants
health issues
of their rights to obtain health services and
requests
other benefits
33/44 DFTA Increase home
delivered meals capacity
Increase access and outreach to healthy food programs for seniors with medical and health related needs.
image
37/44 DFTA Enhance NORC
programs and health services
Increase funding for Naturally Occurring Retirement Communities (NORC) or multi-family housing that has inherited a significant numbers of older adults since there is no support or a funding mandate for nursing care, case management assistance and health with benefits and entitlement.
image
38/44 DFTA Other senior center
program requests
Increase OTPS funding for replacement furnishings (non-capital) in senior centers as needed.
image
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 12
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
There are 32 geographic Community School Districts (CSD) in New York. Each district is in charge of their elementary and secondary public schools within their community. Of these 32 CSD, District 6 consists of the Upper West Side, Harlem and Washington Heights/Inwood communities located in the northern part of Manhattan (from West 135th to 218th Street). District 6 enrollment has approximately 25,121 students (K-12) according to district 6 data of 2015-
16. There are 49 public schools in District 6, of which 31 public schools (K-8) and 8 high schools are situated within the Washington Heights and Inwood community and the remaining 10 schools are located in the Upper West Side and Harlem. There are 19 out-of- school time (OST) programs, 8 daycares and head start programs, and 3 public libraries in the community of Washington Heights. However, local concerns regarding the improvement and increase of resources in this community continue to be a challenge. Community District 12 is in urgent needs of significant after-school enrichment/extracurricular activities at local schools and parks within the district; the school day ends for most students around 2:30pm, and most families in the district find it difficult to provide adequate after-school supervision for this children – an increase of funding for after-school enrichment/extracurricular activities at local schools and parks within the district is highly desirable. Furthermore, in the Expense Budge Ranking for F Y 18, the number one issue for our Youth and Education Committee is Increase funding for Comprehensive Afterschool System program that include tutoring assistance with homework through community based organizations in school district 6. Class Size Reduction is needed in our district and we would like that City increase funding to reduce class size in CSD6. In addition CB 12, M needs biotech laboratory. We would that the City provide funding for a biotech laboratory and research facility for all students at the George Washington Educational Campus to insure there are opportunities for readiness, mentoring and hands an immersion on a genomic (DNA) level that is linked to a variety of career path in health /medical/science and non science fields.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Physical Education (PE) serves as a keystone to reinforce student’s academic achievement and prepare them to be physically and mentally active. School districts in New York City are mandated by the NYS Dept of Education to provide students with physical education and fitness paces, and to be instructed by Certified Teacher. However, evidence continues to suggest (report issued by the Comptroller Scott Stringer that the lack of physical education increases the health risk of students to become obese. Over 25 percent of students in New York City between the ages of 5 to 14 in Kindergarten through 8th grades are obese or severely obese. In several schools located in CB 12, Manhattan District including I.S 528, Bea Fuller Roger; I.S. 223, Mott Hall; and I.S 28 that serve students from PK-5th grades and 6th-8th grades do not have education fitness and /or their gymnasium. These schools have been waiting for the more than a decade to correct this problem. Therefore, it is imperative that DOE provides the capital funds for FY17 for the restoration and increase of physical education and fitness spaces needed in the aforementioned schools within CB12 district. See http://comptroller.nyc.gov/reports/droppingtheball Additionally, the majority the school facilities in the CB 12, M are very old in great disrepair and in need of renovation or reconstruction. For example the swimming pool of the George Washington High School has been out of use for more than 20 years. The students in this district does not have access to a swimming pool. Swimming as sport is not being offered to the student.
Needs for Youth and Child Welfare
There is a high demand for a variety of programs in the community and among them are child care to assist working parents and after school programs, job training and skill development, college readiness programs to help students succeed in higher education, healthy eating in schools to reduce obesity, and youth anti-violence programs that promote safer communities. Expanded access to the Universal Pre-K program successfully created by Mayor De Blasio – the demand for Pre-K slots in Community District 12 has outpaced the availability – including in the zoned
school districts of many community residents – the City and DOE should focus on creating more Pre-K resources in the district – our district has seen an increase of almost 2,000 children under the age of 5 from this report last year
– the need for Pre-K resources is on the rise.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
17/48
SCA
Provide technology
Build a Science, Technology, Engineering, &
upgrade
Math (STEM) "Digital Library" within School
District 6.
22/48
SCA
Renovate interior
Provide funding for a new elevator at George
549
building component
Washington Educational Campus.
AUDUBON
AVENUE
31/48
SCA
Renovate interior
Renovate the George Washington Educational
building component
Campus Gymnasium (built in 1969)
34/48
SCA
Renovate interior
Upgrade Science Lab(s) at M468/HS for Health
building component
Careers & Sciences
35/48
SCA
Renovate other site
Provide funding to expand Computer at
component
M468/HS for Health Careers and Sciences
43/48
SCA
Renovate interior
HVAC Upgrade to add air conditioning in the
549 Audubon
building component
George Washington Educational Campus
Avenue
auditorium.
CS
SCA
Renovate or
Provide funding to renovate and upgrade
upgrade a high
classroom at M468- H.S. for Health Careers and
school
Sciences
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
10/44
DOE
Other educational
Increase funding for Individualized Education
programs requests
Plans and 504 Plans for students with identified
learning difficulties/disabilities in School District
6.
18/44
DOE
Other educational
Increase funding for Class Size Reduction in
programs requests
School District 6.
25/44
DOE
Other educational
Provide funding to increase support for social-
programs requests
emotional learning skills programs for students
in School District 6 .
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 12
image
M ost Important Issue Related to Public Safety and Emergency Services
Crime prevention programs
Community District 12 requires more permanent officers (police officers, supervisors, and detectives) and police services to address issues facing an increased number of residents, visitors to the almost 1,000 acres of parkland, more events in the community and the city that require staffing which drain the resources in place, increased security at different locations, and a major increase of visitors due to a proliferation of restaurants and nightlife establishments. With an expected increase in the population due to new housing, the services are even more warranted for crime prevention in order to maintain or decrease the major index crime statistics and any other violent or non-violent crimes. Our two police precincts - the 33rd and 34th precincts - cover 155th to 218th Street from river to river and this landscape includes a major hospital and its affiliates; public housing developments; several large and popular parks that encompass baseball and soccer fields, a public swimming pool, three boating docks;a homeless shelter for men; transit rail yards; a NYC Department of Sanitation depot; senior centers; a university; museums; and more than 100,000 residents with an influx of tens of thousands of tourists and visitors to the community, particularly from May through October. Both precincts lack a sufficient number of permanent officers to address crime, particularly slashing and stabbings, violence on the street, rape and sexual assault, and gang activities as well as the increased volume of quality of life issues. There has been a vast increase of quality-of- life complaints documented by 311 calls, which include noise, loud music, loitering, car break-ins and vandalism, graffiti on private and public property; large crowds in our parks; illegal Fourth of July fireworks which last for several days before and after the holiday; the increase of the homeless throughout the city and uptown, where residents have reported homeless men congregating on sidewalks and intimidating neighborhood residents both on the street and in the subways; and illegal parking.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Community District 12 requires more permanent officers and police services to address the issues facing an increased number of residents, visitors to the almost 1,000 acres of parkland, more events in the community and the city that require staffing, increased security at different locations, and a major increase of visitors due to an increase in restaurants and nightlife establishments. The two police precincts - the 33rd and 34th precincts - cover 155th to 218th Street from river to river and this landscape includes a major hospital and its affiliates; public housing developments; several large and popular parks that encompass baseball and soccer fields, a public swimming pool, three boating docks;a homeless shelter for men; transit rail yards; a NYC Department of Sanitation depot; senior centers; a university; museums; and more than 100,000 residents with an influx of tens of thousands of tourists and visitors to the community, particularly from May through October. Both precincts lack a sufficient number of permanent officers to address crime, particularly slashing and stabbings, violence on the street, rape and sexual assault, and gang activities as well as quality of life issues. There has been a vast increase of quality-of-life complaints documented by 311 calls, which include noise, loud music, loitering, car break-ins and vandalism, graffiti on private and public property; large crowds in our parks; illegal Fourth of July fireworks which last for several days before and after the holiday; groups of homeless men intimidating neighborhood residents both on the street and in the subways; and illegal parking. Community District 12 urges the City of New York to provide a an additional 30 police officers for both the 34th and 33rd Precincts as well as provide them with additional transportation equipment, including patrol cars and ATVs so that they may adequately protect and serve the community. A command post set up near the Dyckman Street area will enable officers to respond to 911 and 311 calls at the end of the precinct in a more timely and efficient manner. In order for complete transparency, we are requesting that all uniformed patrol officers and supervisors be allocated body cams. With the increased technology, we request that Spotshotter be implemented in both precincts in order to ascertain where shots are fired, aiding the NYPD in reducing gun violence. Finally, being the geographic territory of Community Board 12 is particularly vast, we urge the City of New York to provide the 33rd and 34th Precincts with a significant closed circuit camera and lighting
budget, so that they can keep track of troubled areas as well as focus on preventative issues, all while using the latest technology available, without sacrificing human resources on the ground, which could instead be used for urgent responses by law enforcement.
Needs for Emergency Services
Our local firehouses participate in many community wide events. However, more educational initiatives are requested to best education the public and provide outreach in terms of fire safety, recruiting, illegal fireworks, smoke detectors, and other issues important to the safety of residents and businesses. Firehouses have been renovated and are in excellent shape, except for two which require the replacement of apparatus doors. A relatively new EMS base, circa 2013, has been existing in temporary modular buildings also known as trailers; a permanent building is much preferred and requested.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
25/48
NYPD
Other NYPD
Procurement of additional noise decibel readers
facilities and
for CD12M
equipment requests
(Capital)
29/48
FDNY
Provide new
Procurement of all terrain vehicle (ATV) or
emergency vehicles,
"Gator" vehicles for FDNY for efficient response
such as fire trucks or
in CD12M's vast parklands.
ambulances
33/48
NYPD
Other NYPD
Lighttower within the 33rd and 34th Precincts.
facilities and
equipment requests
(Capital)
36/48
NYPD
Provide surveillance
Procure 2 Argus Cameras for NYPD 33rd
cameras
Precinct placement in high crime and low traffic
areas alongside Edgecombe/Riverside Drive or
along 155th Street and Riverside Drive
38/48
FDNY
Other FDNY facilities
Procurement of a Bariatric Stretcher for FDNY
and equipment
requests (Capital)
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
5/44
NYPD
Provide resources to
Expand implicit bias, mental health, substance
train officers, e.g. in
use training programs and multi agency
community policing
response.
8/44
NYPD
Increase resources
Expand Domestic Violence and Anti-Sexual
for domestic
Harassment programs and improve multi-
violence prevention
agency response.
programs
29/44
FDNY
Expand funding for
Increase funding to support FDNY in addressing
fire prevention and
and correcting violations and enhance fire
life safety initiatives
prevention in housing and nightlife
establishments.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 12
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Air quality and pollution
The initial findings of the New York City Community Air Survey showed that Washington Heights is one of the most polluted areas in the City, apparently because of the huge amount of traffic coming through the community on the Trans Manhattan Expressway and the concentration of apartment buildings burning dirty fuel oil.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
The water and sewer pipes in our district are very old and are collapsing very often. This condition is shown on the increasing numbers of sink holes and cave in holes all over the district. We have reported in the past two years several dozen of sink holes and cave in on Post Ave., Cooper Street, West 181st Street among other. Our catch basins are clogged causing a lot of floods with heaving rains. There is a very bad flood location at Dyckman Street, Nagle Ave and Fort George Hill. There are also locations that do not have enough catch basin or do not have catch basin at all like the northeast corner of West 166th and Amsterdam Ave. Community Board 12 supports the following actions to improve the environment of our community: • Aggressive outreach efforts by the Bureau of Pest Control to reduce rat infestation in our community, which was cited as having the highest rate of rat infestation in Manhattan in 2011. • Restoration of funding for Manhattan’s only lead-safe house, operated by the Northern Manhattan Improvement Corp. at 2183 Amsterdam Ave. This facility is a vital resource for families with lead- poisoned children whose apartments are undergoing lead abatement. • Increased funding for public education and outreach on disposal of household garbage and recyclables. • Due to Northern Manhattan becoming a destination for dining and entertainment the number of pedestrian traffic has increased dramatically we need more litter baskets on our streets to mitigate the overflow of litter baskets on our streets. • The hiring of additional Sanitation workers, including street cleaners and Sanitation police officers, for Community District 12. • The construction of a Sanitation garage for Manhattan Community District 8 so that its collection trucks will no longer make thousands of unnecessary trips through our community every year in violation of the City Charter co-terminality mandate. • The use of cleaner, less polluting fuel oil in apartment buildings, local businesses and large institutions to reduce a major source of pollution in the community. • Stronger and consistent enforcement of the Noise Control Code throughout the community, especially late at night in connection with bars and restaurants. • Comprehensive regulations and policy for the placement of cell phone towers on residential buildings that protect public health and safety and u
Needs for Sanitation Services
Increased funding for public education and outreach on disposal of household garbage and recyclables. • Due to Northern Manhattan becoming a destination for dining and entertainment the number of pedestrian traffic has increased dramatically we need more litter baskets on our streets to mitigate the overflow of litter baskets on our streets. • The hiring of additional Sanitation workers, including street cleaners and Sanitation police officers, for Community District 12. • The construction of a Sanitation garage for Manhattan Community District 8 so that its collection trucks will no longer make thousands of unnecessary trips through our community every year in violation of the City Charter co-terminality mandate
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation Location
12/48
DEP
Inspect water main
Expedite the replacement of old water mains
on specific street
and sewer lines in our community.
segment and repair
or replace as
needed (Capital)
13/48
DSNY
Provide new or
Provide additional garbage collection trucks and
increase number of
street sweepers with snow plows
sanitation trucks
and other
equipment
CS
DSNY
Provide new or
Construct new District 8M garage and relocate
upgrade existing
its trucks from District 12M.
sanitation garages
or other sanitation
infrastructure
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
34/44
DSNY
Provide more
Increase trash basket collection on commercial
frequent litter
streets on weekends in District 12M (DSNY)
basket collection
36/44
DSNY
Other garbage
Increase funding for education and outreach on
collection and
recycling, reuse and composting as well as
recycling requests
proper disposal of household garbage in our
community
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 12
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing preservation
Housing that is affordable to households within the income-range most representative of the community district is the most important housing issue in Washington Heights and Inwood. The availability of affordable housing and the availability of sufficient affordable housing to meet local demand constitutes the core of both the physical and the social issues. CD12's low AMI, compared to city-wide AMI, and the rising cost of living result in high rent burden and over crowding for a significant percentage of households. The existing stock of affordable housing must be kept intact and affordable to the majority of local residents in order for the community to be sustained and enjoy greater access to and benefit from the broader economic and social fabric of the city and the nation. In addition to the preservation of the existing affordable housing, we are in need of the construction of new affordable housing and the for these new housing units must be calculated based on the median household income of the residents of Community District 12-Manhattan and not based on the median household income of the residents of Manhattan or the City as a whole. Furthermore, the number one issue for the Housing & Human Services committee for the Expense Budget Ranking for Fiscal Year 2018 is to Provide sufficient funding for mandatory “right to counsel” and CBO’s for HOUSING COURT and the new Office of Civil Justice to provide legal, social services and or administrative assistance, heavy attorney representation, advocacy or intervention beyond the pro bono or current non-attorney Guardian Ad Litem programs, and one stop HRA/LINC programs for all tenant litigants in CB12,M.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
We need additional planning staff to work with CB12M and local residents to formulate and implement a community-based contextual zoning plan for Washington Heights & Inwood. We need to implement a planning and development initiative for Washington Heights & Inwood whereby vacant city-owned lots and buildings are identified, packaged and released in one or more Requests for Proposals dedicated to scattered-site infill residential development that is affordable to local residents of CD12 with affordability defined by the Area Median Income (AMI) of CD12. (HPD), or purchased by the City for such development.
Needs for Housing
Community District 12 Manhattan is well known for its pre and post-world war buildings which are in need of much maintenance and repairs. Many of which are not accessible for individuals with disabilities. As well it holds the most rent regulated apartments in all of Manhattan at 56, 173 rent regulated units. Within Community District 12 Manhattan there is exist many housing issues where tenants who live in these apartments are faced with deplorable living conditions and serious housing code violations. This is such a problem that in 2010 and 2011 than The New York City Public Advocate Bill De Blasio now Mayor created the Worst Landlords Watch List, reporting s Manhattan's worst-run down buildings are mostly Harlem, Washington Heights, and Inwood. Forty five of the 56 Manhattan buildings on the list are in those areas The impact of high rent is felt nationwide, the call for affordability is imperative. A report created by Shaun Donovan / Secretary of the U.S Department of housing and Urban Development “Out of Reach 2012 “defined affordability as it is consistent with the federal standard that no more than 30% of a house holds gross income should be spent on gross housing cost and households paying over 30% of their income are considered cost burdened. The former Mayor of New York Michael Bloomberg’s acknowledged the need d for 165,000 more affordable housing units to be either built or preserved in New York City. However the Mayor’s affordable housing distribution has been grossly uneven, as seen in statistics provided by the Department of Housing Preservation and Development regarding the borough of Manhattan. From 2004 to 2010, 36,271 affordable housing units were built or preserved in Manhattan, but more than two-thirds of this construction was concentrated in just three of Manhattan’s twelve community districts. Residents in this district are faced with rising rents; overcrowding and physical conditions of existing rent-regulated housing units are often in deplorable, conditions with serious housing code violations. This clearly highlights the needs for more funding our existing
housing stock in regard to preservation and new construction of affordable housing. Another major concern for our community is the need for affordable and accessible housing, since the median house hold income of our residents is 38, 320 and 42.3% of our residents.
Needs for Economic Development
Top Priorities for Business Development/Economic Development for CB12M: 1. CB12 needs renovated libraries that can be utilized by residents throughout the district to help prepare for gainful employment, be it to utilize technology to search for jobs, as well as resume building – our libraries are a central resource for all that are being underutilized because of the outdated and run down conditions they are in. 2. Continuation of Annual CB12M Small Business Forum, so as to bring the business community, government and the residents of this district together so business owners can gain valuable information on how to thrive and expand. 3. Continuation of Annual CB12M Jobs Fair, and perhaps as a bi-annual event, so as bring job seekers and employers together and help reduce the systemically high unemployment of CB12M. 4. Establish the committee as a main resource to all current and new local businesses, in an effort to engage in a public/private sector dialogue that helps CB12M residents, business and institutions thrive and expand, as well as providing information to local business as it relates to city, state and federal business oriented initiatives. 5. Incorporating business and the local arts community – with a high storefront vacancy, the committee aims to reduce the blight of vacant store fronts by creating a partnership among landlords and the CB12M arts community, so as to provide expanded arts space while increasing the appeal of venues that may be vacant at the time. 6. Play a critical role with the NYC Economic Development Corporation in the current rezoning efforts within CB12M 7. Strengthening relations with government agencies that assist with small business such as DCA, DEP, and SBS. 8. Partner with restaurants and bars in an effort to ensure friendly balance between nightlife activity and the residential community 9. Host an event for local business and residents that provides commercial real estate and legal training as it relates to commercial leases and rights for all those involved in a commercial lease 10. Creating increased tourism and consumer demand for CB12M business and organizations, through expanded transportation options, including water taxi service to Northern Manhattan. With an aging mass transit system, it is cr
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/48
HPD
Other affordable
Provide sufficient funds to fully renovate 2110
housing programs
Amsterdam Avenue (city-own property) for
requests (capital)
Affordable Housing.
2/48
HPD
Other affordable
Permanent long-term affordable housing
housing programs
construction - build a high number of 100%
requests (capital)
affordable units (based on community AMI)
with immediate priority given to non-profit
organizations and COMMUNITY LAND
TRUSTS/LAND BANKS that are partnered with
non-profit developers.
5/48
HPD
Provide more
Provide funding to construct affordable,
housing for seniors
accessible housing for seniors
6/48
HPD
Expand loan
Additional funding for AEP and PPP programs
programs to
for preservation and rehabilitation of distressed
rehabilitate multiple
buildings in CD12,M - immediate priority.
dwelling buildings
10/48
HPD
Provide more
Provide more housing for at-risk and
housing for special
transitioning individuals and families
needs households,
such as the formerly
homeless
48/48
SBS
Other capital
Business training/capacitation hubs (additional
commercial district
to services offered by SBS)
revitalization
requests
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
3/44 HPD Other affordable
housing programs requests (expense)
Increase funding for legal representation in court in all zip codes not currently covered in CD 12,M particularly zip codes in the rezoning area and increase the AMI eligibility to 300% from 200% under the Right to Counsel Program.
image
4/44 DCP Other zoning and
land use requests
Dedicated additional planning staff to work with CB12M and local residents to formulate and implement a community-based neighborhood preservation (formerly stated “contextual zoning”) plan for Washington Heights and Inwood, exclusive of any work undertaken in connection with EDC’s recent Inwood Rezoning plan.
image
19/44 HPD Other affordable
housing programs requests (expense)
Funding for more HPD Housing Code Violation inspectors
image
42/44 SBS Provide or expand
business education to businesses and entrepreneurs
Funding for Business Committee Resource Guide for new & existing businesses
image
44/44 SBS Support local CBOs
efforts to provide or expand district marketing, branding, and promotion
Marketing support for businesses
image
TRANSPORTATION
Manhattan Community Board 12
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
The most important transportation issue in CB 12, M is the traffic flow. During the pick hours we face traffic jams on the main streets within the district and the streets approaching the different bridges in the district. CB12, Manhattan is perhaps the district with the most bridges in the borough connecting Manhattan with the Bronx on seven different locations over the Harlem River and connecting Manhattan with New Jersey over the Hudson River. Allocate funds to purchase light paving equiments (rollers 4-6 foot, milling machines, APM Paver Machines) sudable to be used on bridges and overpasses.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
We have the following bridges in our district: 1. The Macombs Dam Bridge spans the Harlem River in New York City, connecting the boroughs of Manhattan and the Bronx near Yankee Stadium on West 155th Street. 2. The High Bridge is the oldest bridge in New York City, having originally opened as an aqueduct in 1848 and reopened as a pedestrian walkway in 2015 is connecting Manhattan and the Bronx over the Harlem River on West 173rd Street through the Highbridge Park. It is expected that bicycle traffic increase on Amsterdam Ave in the near future. 3. The Alexander Hamilton Bridge connecting the Trans-Manhattan Expressway in the Washington Heights section of Manhattan and the Cross-Bronx Expressway over the Harlem River. This bridge brings traffic to the Washington Bridge and the West 181st Street and connects to the Henry Hudson Parkway. 4. The Washington Bridge crosses the Harlem River connecting 181st Street and Amsterdam Avenue in the Washington Heights neighborhood of Manhattan to University Avenue in the Morris Heights neighborhood of the Bronx. 5. The University Heights Bridge crosses the Harlem River, connecting West 207th Street in the Inwood neighborhood of Manhattan to West Fordham Road in the University Heights section of the Bronx. 6. The Broadway Bridge crosses the Harlem River Ship Canal between Inwood on Manhattan Island and Marble Hill in the Bronx. 7. The Henry Hudson Bridge crosses the Spuyten Duyvil Creek. It connects Spuyten Duyvil in the Bronx with Inwood in Manhattan. 8. George Washington Bridge crosses the Hudson River, connecting the Washington Heights neighborhood in the borough of Manhattan in New York City to Fort Lee, in New Jersey. The George Washington Bridge carries over 106 million vehicles per year, making it the world's busiest motor vehicle bridge according to the Port Authority of New York and New Jersey. The approaches to and from the George Washington Bridge in Washington Heights are very congested at all time of the day getting worse during the pick hours. 9. Amsterdam Ave., Audubon Ave., Wadsworth Ave., St. Nicholas Ave., Broadway and Ft. Washington Ave. between West 178th and West 179th Street are overpasses over the Trans Manhattan Expressway. These overpasses are in disrepair because in order for NYC DOT to pave them with their actual equipment they will be required to shut down completely the Trans Manhattan Express way. For these reasons our Traffic & Transportation Committee added a new request for Expense 2018 Fiscal Year Budget to Allocate funds to purchase light paving equipment (rollers 4-6 foot, milling machines, APM Paver Machines) suitable to be used on bridges and overpasses.
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation Location
14/48
NYCTA
Improve
Funding to make the following subway stations
accessibility of
fully ADA compliant. IRT (1) Line Stops: 157,
transit
168, 181,191, Dyckman, 207 (uptown), & 215;
infrastructure, by
IND (A/C) Line Stops: 155, 163, 168, 181, 191,
providing elevators,
Dyckman, & 207.
escalators, etc.
26/48
NYCTA
Repair or upgrade
Rehabilitate the W. 157 Street IRT Subway
subway stations or
Station.
other transit
infrastructure
30/48
NYCTA
Repair or upgrade
Rehabilitate the W. 155 Street IND Subway
subway stations or
Station.
other transit
infrastructure
32/48
NYCTA
Repair or upgrade
Rehabilitate West 207th Street IRT (1 Train)
subway stations or
Subway Stations.
other transit
infrastructure
CS
NYCTA
Repair or upgrade
Rehabilitate the Subway Stations at West 181st
subway stations or
and West 168 Streets IND.
other transit
infrastructure
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
22/44
DOT
Improve traffic and
Increase funding for repairs of pedestrian
pedestrian safety,
sidewalks, including curb ramps
including traffic
calming (Expense)
27/44
NYCTA
Other transit service
Increase funding for subway station personnel,
requests
maintenance, communication technology, and
security
39/44 DOT Other expense
traffic improvements requests
Increase funds for pothole repairs
image
43/44 DOT Other expense
traffic improvements requests
Funding for a study focused on how to improve traffic flow to and from all of the eight major bridges in CB12M
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 12
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
Community District 12 has a total of 1,790 acres and features more than 600 acres of parkland; more than 1/3 of the district is parkland. Our parks resources include miles of waterfront, a forest, and three historic houses.
Although accessibility continues to be an issue, care and maintenance issues have become an increasing source of conflict in many parks. Northern Manhattan has very few PEP officers; even with the additional of a dedicated team for the newly opened High Bridge, and the addition of a half-dozen PEP officers, CB12M still has significantly fewer enforcement resources per acre of parkland than anywhere else in the City, and no dedicated Forestry service.
Moreover, some of our access issues could mitigated by the additional of personnel resources, particularly along the waterfront, and in areas of high-conflict use (e.g., BBQing vs. cultural programming in the Inwood Hill Park peninsula, more Urban Park Ranger programming along the waterfront, etc.) 5. Summary of Community District Needs and Budget Requests Park care and maintenance Community District 12 has a total of 1,790 acres and features more than 600 acres of parkland; more than 1/3 of the district is parkland. Our parks resources include miles of waterfront, a forest, and three historic houses. Although accessibility continues to be an issue, care and maintenance issues have become an increasing source of conflict in many parks. Northern Manhattan has very few PEP officers; even with the addition in FY’17 of a dedicated team for the newly opened High Bridge and the addition of a half-dozen PEP officers, CB12M still has significantly fewer enforcement resources per acre of parkland than anywhere else in the City, and no dedicated Forestry service. Moreover, some of our access issues could mitigated by the addition of personnel resources, particularly along the waterfront and in areas of high-conflict use (e.g., BBQing vs. cultural programming in the Inwood Hill Park peninsula, more Urban Park Ranger programming along the waterfront, etc.) Main Issue Related to Parks, Cultural and other Community Facilities Community District Needs Related to Parks and Recreational Facilities and Programming With well over 600 acres of park land it is no surprise that 11 of CB12M's 39 capital budget priorities (plus 6 out of 8 Continuing Support items) are for projects in and around our parks. Many of the projects are for ADA retrofitting, or for repairs to update aging infrastructure. There are additional capital and expense needs relating to youth programming in parks, waterfront recreation development and other items which, while important, were beyond the OMB-imposed limit of 40 capital project and 25 expense programs. Ongoing maintenance of parks pathways, particularly in our largest parks -- Fort Tryon, Highbridge, and Inwood Hill -- is the single most important way to ensure safe access to all parts of our parks, both for recreation as well as for maintenance, safety, and access. The Msgr. Kett playground is in a part of Inwood not otherwise served by playgrounds nearby, despite being close to a public housing project. It hasn't been renovated since the '90's and is long overdue. Additionally, its basketball courts are heavily used by the community, and are in need of repair. The Raoul Wallenberg playground, which serves a broad range of ages from children to teens to seniors, hasn’t had a full renovation in more than a generation. Many areas within our parks, playgrounds and dog runs need plumbing and/or lighting, for the benefit of parks users, as well as for use by landscaping staff. Areas in need include Ft. Tryon Park's Alpine Garden along the eastern/Broadway slope, and the dog run; the northern loop overlooking Riverside Drive, which severely compromised by an underground spring and has been the site of several pedestrian injuries, the Riverside Park dog run at W. 165th Street, and the basketball/tennis courts in Inwood Hill Park. ADA compliance and retrofit projects include: the historic Morris-Jumel Mansion, the High Bridge Water Tower, restrooms throughout the District's Parks, and the Hispanic Society of America on the historic Audubon Terrace. Additional ongoing/recurring requests include the Phase II restoration of the High Bridge water tower (e.g., stairs, pointing, windows and carillon); expansion of free public WiFi in our parks, and the addition of a Lenape garden to augment the Native American programming in Inwood Hill Park. As a new request we would like to see the development of a memorial to honor the Native American and African Burial Grounds which lie beneath a public school and the MTA Rail Yards on Tenth Avenue from W. 207th to W. 220th Streets, including signage, curriculum, and facilities to support community events. On the expense side, CD12M parks are in desperate need of more maintenance and enforcement personnel. While there is much excellent programming of all kinds, our wealth of facilities could be leveraged to greater use with additional programming targeted to children, teens, and seniors. Given our income thresholds and levels of poverty, which are well below borough averages, CD12M is particularly in
need of free or low-cost recreation and educational offerings. We also need additional maintenance and sanitation staffing, boat storage at the Muscota Marsh to support public waterfront recreation, and a dedicated forestry crew. Community District Needs Related to Cultural and other Community Facilities and Programming CB12M has a wealth of cultural facilities and programs, but many are in need of accessibility improvements, major capital repairs, and additional program offerings for our community. In particular, afterschool programming and educational/cultural programming at museums & historic houses (e.g. Hispanic Society, Morris- Jumel Mansion, Dyckman Farmhouse, etc.) Northern Manhattan also is in desperate need of accessible performance and gallery space, rehearsal space, and infrastructure to support a growing arts community and audience for performance and displayed art. There is no prioritized capital item for this as there is no identified lead agency or specific funding project, but the absence of this resource is a recurring trope at community meetings and events; as such, it is appropriate to note it in our Statement of District Needs. Community District Needs Related to Library Facilities and Programming The existing library facilities are in disrepair and need to be renovated and make it accessible in some cases. CB 12, M need more libraries; therefore, the construction of more libraries facilities are required. The budget for the libraries were increased recently. We request that this increase be maintained and expanded. Capital Requests Related to Parks, Cultural and other Community Facilities Priority / Agency / Need / Request / Location • 10/39 DPR Park, buildings, and access improvements: Provide a new or expanded park or amenity: Native American
/ African Burial Grounds (Tenth Ave. & W. 212th St.): Develop a memorial, signage, curriculum, and facilities to support community events • 15/39 DPR Park maintenance and safety: Enhance park safety and access: Inwood Hill, Highbridge and Fort Tryon Parks: Reconstruct/maintain 60+ miles of park pathways and paving • 21/39 DPR Park maintenance and safety: Enhance park safety through design interventions: Highbridge water tower Phase II: public access, additional renovations (restore public access, incl. handrail repair, window guards, interior lighting, ADA entrance, and carillon) • 25/39 DPR Park, buildings, and access improvements: Reconstruct or upgrade a building in a park: Morris-Jumel Mansion ADA Accessibility • 26/39 DCLA Cultural facilities and resources: Renovate of upgrade an existing cultural facility: Hispanic Society renovations: roof, interior, terrace, & ADA compliance • 30/39 DPR Park maintenance and safety: Enhance park safety through design interventions: Shoreline preservation and bulkhead repairs in Ft. Washington Park • 35/39 DPR Park, buildings, and access improvements: Reconstruct or upgrade a park or amenity: Renovate/rehabilitate Msgr. Kett Playground (204 btw. 10th & Nagle) • 36/39 DPR Park, buildings, and access improvements: Reconstruct or upgrade a park or amenity: Raoul Wallenberg Playground & Basketball Court Reconstruction (Amsterdam btw. W 188/190) • 37/39 DPR Park, buildings, and access improvements: Reconstruct or upgrade a park or amenity: J. Hood Wright overlook and viewing platform: ADA accessibility • 38/39 DPR Park, buildings, and access improvements: Provide a new or expanded park or amenity: More family picnic / BBQ areas throughout CD12 Parks to meet increasing community demand • 39/39 DPR Park, buildings, and access improvements: Provide a new or expanded park or amenity: Add Lenape Garden to Inwood Hill Park • Continuing Support DPR Park maintenance and safety: Enhance park safety through design interventions: Highbridge water tower: roof repair, stabilize structure and replace windows; (does not enable public access) • Continuing Support DPR Park, buildings, and access improvements: Reconstruct or upgrade a park or amenity: Renovate & reconstruct Audubon Playground, including removal of existing temporary structure • Continuing Support DPR Park, buildings, and access improvements: Reconstruct or upgrade a building in a park: Renovate / repair the Nature Center in Inwood Hill Park • Continuing Support DPR Park, buildings, and access improvements: Reconstruct or upgrade a park or amenity: Renovate Javits Playground (Ft. Tryon Park) • Continuing Support DPR Park, buildings, and access improvements: Reconstruct or upgrade a building in a park: Dyckman Farmhouse: roof repairs • Continuing Support DPR Park, buildings, and access improvements: Reconstruct or upgrade a park or amenity: Sherman Creek: NYRP Phase II clean-up & waterfront access Summary of Community District Needs and Budget Requests Expense Requests Related to Parks, Cultural and other Community Facilities Priority / Agency / Need / Request / Location • 8/43 DPR Park programming: Increase funding for various programming throughout CD12 parks, playgrounds, courts, & historic houses: Additional Parks & Urban Park Ranger staff as well as contracted specialists for afterschool, recreational, waterfront, & cultural programming for kids, teens, adults, & seniors • 9/43 DPR Park maintenance and safety: Fund additional Park Enforcement Personnel (PEP) • 29/43 DPR Park maintenance and safety: Fund additional staff for Sanitation, Maintenance & Operations, Horticulture (2 APSWS, 6 CPWS to ensure more sites have fixed post staff) • 38/43 DPR Park programming: Muscota Marsh Boat Storage to support public waterfront programming (storage unit is small and not capitally eligible) • 41/43 DPR Park maintenance and safety: Dedicated Forestry Crew for CD12: Dedicated crew of 4 to help w/ sustained invasives removal & native plantings in Inwood & Highbridge forests
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
With well over 600 acres of park land it is no surprise that fully 15 of CB12M's capital budget priorities (plus 5 continuing support items) are for projects in and around our parks. Many of the projects are for ADA retrofitting, or for repairs to update aging infrastructure. There are additional capital and expense needs relating to youth programming in parks, waterfront recreation development and other items which, while important, were beyond the OMB-imposed limit of 40 capital project and 25 expense programs. The Audubon Playground is in a section of CD12M with relatively few parks/playgrounds, yet there is a school serving citywide DoE needs situated in the playground. We would like that "temporary" structure (built decades ago) removed and the area returned to community use as a recreational facility. Ongoing maintenance of parks pathways, particularly in our largest parks -- Fort Tryon, Highbridge, and Inwood Hill -- is the single most important way to ensure safe access to all parts of our parks, both for recreation as well as for maintenance, safety, and access. The Msgr. Kett playground is in a part of Inwood not otherwise served by playgrounds nearby, despite being close to a public housing project. It hasn't been renovated since the '90's and is long overdue. Additionally, the basketball courts are heavily used by the community, and are in need of repair. Many areas within our parks, playgrounds and dog runs need plumbing and/or lighting, for the benefit of parks users, as well as for use by landscaping staff. Areas in need include Ft. Tryon Park's Alpine Garden along the eastern/Broadway slope, and the dog run; the Riverside Park dog run at W. 165th Street, the "Sunken" Playground in Highbridge Park in lower the 160s, and the basketball/tennis courts in Inwood Hill Park. ADA compliance and retrofit projects include: the historic Morris-Jumel Mansion, the Dyckman Farmhouse, the High Bridge Water Tower, Highbridge Park's New Adventure Playground (W. 165th & Edgecombe), restrooms throughout the District's Parks, and the Hispanic Society of America. Additional ongoing/recurring requests include the Phase II restoration of the High Bridge water tower (e.g., stairs, pointing, windows and carillon); expansion of free public WiFi in our parks; and funding of Phase II of the New York Restoration Project's clean-up and waterfront access at Sherman Creek. As a new request we would like to see the addition of a science barge to meet the educational needs of CD12M's youth and adults alike, in a creative way that also utilizes our vast waterfront. On the expense side, CD12M parks are in desperate need of more maintenance and enforcement personnel. While there is much excellent programming of all kinds, our wealth of facilities could be leveraged to greater use with additional programming targeted to youth, seniors, teens. Given our income thresholds and levels of poverty, which are well below borough averages, CD12M is particularly in need of free or low-cost recreation and educational offerings.
Needs for Cultural Services
CB12M has a wealth of cultural facilities and programs, but many are in need of accessibility improvements, major capital repairs, and additional program offerings for our community. In particular, afterschool programming and educational/cultural programming at museums & historic houses (e.g. Hispanic Society, Morris- Jumel Mansion, Dyckman Farmhouse, etc.) Northern Manhattan also is in desperate need of accessible performance and gallery space, rehearsal space, and infrastructure to support a growing arts community and audience for performance and displayed art. There is no prioritized capital item for this as there is no identified lead agency or specific funding project, but the absence of this resource is a recurring trope at community meetings and events; as such, it is appropriate to note it in our Statement of District Needs.
Needs for Library Services
The existing library facilities are in disrepair and need to be renovated and make it accessible in some cases. CB 12, M need more libraries; therefore, the construction of more libraries facilities are required. The budget for the libraries were increased recently. We request that this increase is maintained and expanded.
Needs for Community Boards
Under the NYC Charter, Community Boards have a great deal of responsibilities. Community Board have a limited budget resulting in limited staff. CB 12, M has only three staff members including the District Manager. With three staff members CB 12, covers the office operation, all the community needs, Board members demands and night meeting coverage, processing of vendor’s payments and the Comptroller’s audits. With the sophistication of technology there are new demand that sometime is not possible to accomplish because of the lack of training on the staff or the lack of personnel to perform it. The members of Community Board 12, M demand the presence of a staff for the night’s meetings. We have at least ten night meetings per month. The night meetings start at 7 pm and finish around 10 pm. Some meetings, like the Licensing Committee finish close to might night. The Licensing
Committee meeting in the month of June went up to the next day, the meeting was adjourned at 1:30 am but the agenda was not completed. A Second meeting was re-convened the following week. CB 12, M needs an additional staff member to help with to keep up with the operation and the covering of the nights meeting.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
8/48
DPR
Improve access to a
Repair badly degraded staircases & retaining
park or playground
walls in Isham Park
9/48
DCLA
Renovate or
Hispanic Society renovations: roof, interior,
upgrade an existing
terrace, & ADA compliance.
cultural facility
11/48
DPR
Reconstruct or
Renovate / repair Inwood Hill Park Nature
upgrade a park or
Center following hurricane Sandy (requires
amenity (i.e.
additional $1.5+ million allocation)
playground, outdoor
athletic field)
15/48
DPR
Reconstruct or
Raoul Wallenberg Playground & Basketball
upgrade a park or
Court Reconstruction (Amsterdam btw. W
amenity (i.e.
188/190).
playground, outdoor
athletic field)
20/48
DCLA
Other cultural
Native American / African Burial Grounds (Tenth
Tenth Ave
facilities and
Ave. & W. 212th St.): Develop a memorial with
and W. 212th
resources requests
directional & interpretive signage, and a facility
St
(Capital)
to support community events.
21/48
DPR
Reconstruct or
Renovate eastern (Broadway) perimeter
upgrade a park or
playground in Ft. Tryon Park's Anne Loftus
playground
Playground and add sensory playground.
24/48
DPR
Reconstruct or
Inwood Hill, Highbridge and Fort Tryon Parks:
upgrade a park or
Reconstruct/maintain 60+ miles of park
amenity (i.e.
pathways and paving.
playground, outdoor
athletic field)
28/48
DPR
Reconstruct or
Repair & reconstruct Ft. Tryon Park's Linden
upgrade a park or
Terrace
playground
37/48
DPR
Reconstruct or
Renovate Payson Playground & make it and the
upgrade a park or
park house accessible
amenity (i.e.
playground, outdoor
athletic field)
40/48
DPR
Reconstruct or
More family picnic / BBQ areas throughout
upgrade a park or
CD12 Parks to meet increasing community
amenity (i.e.
demand
playground, outdoor
athletic field)
41/48
DPR
Reconstruct or
Shoreline preservation and bulkhead repairs in
upgrade a park or
Ft. Washington Park
amenity (i.e.
playground, outdoor
athletic field)
42/48
DPR
Reconstruct or
Highbridge Rec Center weatherization (fix
upgrade a park or
windows to retain heat/cooling)
amenity (i.e.
playground, outdoor
athletic field)
44/48
DPR
Improve access to a
Reconstruct Bushman Step Street West 157th
W 157th ST
park or amenity (i.e.
between Edgecombe and St. Nicholas Avenue
Edgecombe
playground, outdoor
St. Nicholas
athletic field)
Ave
46/48
DPR
Improve access to a
J. Hood Wright overlook and viewing platform:
park or amenity (i.e.
ADA accessibility
playground, outdoor
athletic field)
47/48
DPR
Reconstruct or
Asbestos abatement and restoration of
upgrade a parks
"Building D" in Ft. Tryon Park for security
facility
presence
CS
DPR
Reconstruct or
Dyckman Farmhouse: roof repairs.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Renovate/rehabilitate Msgr. Kett Playground
upgrade a park or
(204 btw. 10th & Nagle)
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Morris-Jumel Mansion ADA Accessibility and
upgrade a park or
exterior renovation including renovation
amenity (i.e.
following following water main break.
playground, outdoor
athletic field)
CS NYPL Create a new, or renovate or upgrade an existing public library
Full renovation of Fort Washington branch library.
535 WEST
179 STREET
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
7/44
DPR
Enhance park safety
Fund additional Park Enforcement Personnel
through more
(PEP).
security staff (police
or parks
enforcement)
15/44
DPR
Provide more
Increase funding by at least $500k for various
programs in parks or
programming throughout CD12 parks,
recreational centers
playgrounds, courts, & historic houses: fund
additional Playground Associates and Parks &
Urban Park Ranger staff as well as contracted
specialists for afterschool, recreational,
waterfront, and cultural programming for kids,
teens, adults, & seniors
21/44
DCLA
Support nonprofit
Increase DCLA funding by at least $500k to
cultural
increase support for arts programming and
organizations
individual artists within CD12M (DCLA)
28/44
DPR
Forestry services,
Dedicated Forestry Crew for CD12: Dedicated
including street tree
crew of 4 to help w/ sustained invasives removal
maintenance
& native plantings in Inwood & Highbridge
forests
32/44
NYPL
Extend library hours
Maintain funding to provide six days of service
or expand and
at all NYPL branches
enhance library
programs
35/44
DPR
Provide better park
Fund additional staff for Sanitation,
maintenance
Maintenance & Operations, Horticulture (2
APSWs, 6 CPWs to ensure more sites have fixed
post staff) (DPR)
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
3/48
Other
Other capital budget
Funding for supportive housing (construction)
request
for LGBTQ youth.
4/48
Other
Other capital budget
Allocate capital funds to support a planning and
request
development initiative for Washington Heights
and Inwood whereby vacant city-owned lots
and buildings, or lots and buildings purchased
or otherwise acquired by the City in Washington
Heights and Inwood, are identified and
packaged in one or more Requests for Proposals
dedicated to scattered-site infill affordable
residential development projects for which
affordability is defined by the area median
income (AMI) of current CD12 residents.
16/48
Other
Other capital budget
Build a biotech laboratory and research facility
request
for all students at the George Washington
Educational Campus to ensure opportunities for
readiness, mentoring and hands on immersion
on a genomic (DNA) level that is linked to a
variety of career paths in
health/medical/science and non-science fields.
18/48
Other
Other capital budget
DEP - Install green infrastructure such as
request
bioswales to divert stormwater from the sewer
system in our community
19/48
Other
Other capital budget
Additional upgrade of Emergency Response
request
System (311 & 911) to record times and
geolocations for better response, data, and
transparency
39/48
Other
Other capital budget
Community food garden
request
45/48
Other
Other capital budget
Business façade improvement funding
request
Other Expense Requests
Priority Agency Request Explanation Location
image
16/44
Other
Other expense budget request
DOE - Funding needed for comprehensive testing for lead in water and paint in all District 6 schools by a third-party agency.
17/44
Other
Other expense budget request
DEP - Increase staff to conduct regular noise enforcement, air quality monitoring and water quality testing in our community
40/44
Other
Other expense budget request
Add speed cameras in 34th precinct
41/44
Other
Other expense budget request
Education campaign on potential impact of the Inwood Rezoning on businesses
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/48
HPD
Other affordable
Provide sufficient funds to fully renovate 2110
housing programs
Amsterdam Avenue (city-own property) for
requests (capital)
Affordable Housing.
2/48
HPD
Other affordable
Permanent long-term affordable housing
housing programs
construction - build a high number of 100%
requests (capital)
affordable units (based on community AMI)
with immediate priority given to non-profit
organizations and COMMUNITY LAND
TRUSTS/LAND BANKS that are partnered with
non-profit developers.
3/48
Other
Other capital budget
Funding for supportive housing (construction)
request
for LGBTQ youth.
4/48
Other
Other capital budget
Allocate capital funds to support a planning and
request
development initiative for Washington Heights
and Inwood whereby vacant city-owned lots
and buildings, or lots and buildings purchased
or otherwise acquired by the City in Washington
Heights and Inwood, are identified and
packaged in one or more Requests for Proposals
dedicated to scattered-site infill affordable
residential development projects for which
affordability is defined by the area median
income (AMI) of current CD12 residents.
5/48
HPD
Provide more
Provide funding to construct affordable,
housing for seniors
accessible housing for seniors
6/48
HPD
Expand loan
Additional funding for AEP and PPP programs
programs to
for preservation and rehabilitation of distressed
rehabilitate multiple
buildings in CD12,M - immediate priority.
dwelling buildings
7/48
DFTA
Renovate or
Renovate existing or build replacement senior
upgrade a senior
centers as necessary to comply w/ ADA & DFTA
center
regs
8/48
DPR
Improve access to a
Repair badly degraded staircases & retaining
park or playground
walls in Isham Park
9/48
DCLA
Renovate or upgrade an existing cultural facility
Hispanic Society renovations: roof, interior, terrace, & ADA compliance.
10/48
HPD
Provide more
Provide more housing for at-risk and
housing for special
transitioning individuals and families
needs households,
such as the formerly
homeless
11/48
DPR
Reconstruct or
Renovate / repair Inwood Hill Park Nature
upgrade a park or
Center following hurricane Sandy (requires
amenity (i.e.
additional $1.5+ million allocation)
playground, outdoor
athletic field)
12/48
DEP
Inspect water main
Expedite the replacement of old water mains
on specific street
and sewer lines in our community.
segment and repair
or replace as
needed (Capital)
13/48
DSNY
Provide new or
Provide additional garbage collection trucks and
increase number of
street sweepers with snow plows
sanitation trucks
and other
equipment
14/48
NYCTA
Improve
Funding to make the following subway stations
accessibility of
fully ADA compliant. IRT (1) Line Stops: 157,
transit
168, 181,191, Dyckman, 207 (uptown), & 215;
infrastructure, by
IND (A/C) Line Stops: 155, 163, 168, 181, 191,
providing elevators,
Dyckman, & 207.
escalators, etc.
15/48
DPR
Reconstruct or
Raoul Wallenberg Playground & Basketball
upgrade a park or
Court Reconstruction (Amsterdam btw. W
amenity (i.e.
188/190).
playground, outdoor
athletic field)
16/48
Other
Other capital budget
Build a biotech laboratory and research facility
request
for all students at the George Washington
Educational Campus to ensure opportunities for
readiness, mentoring and hands on immersion
on a genomic (DNA) level that is linked to a
variety of career paths in
health/medical/science and non-science fields.
17/48
SCA
Provide technology upgrade
Build a Science, Technology, Engineering, & Math (STEM) "Digital Library" within School District 6.
18/48
Other
Other capital budget
DEP - Install green infrastructure such as
request
bioswales to divert stormwater from the sewer
system in our community
19/48
Other
Other capital budget
Additional upgrade of Emergency Response
request
System (311 & 911) to record times and
geolocations for better response, data, and
transparency
20/48
DCLA
Other cultural
Native American / African Burial Grounds (Tenth
Tenth Ave
facilities and
Ave. & W. 212th St.): Develop a memorial with
and W. 212th
resources requests
directional & interpretive signage, and a facility
St
(Capital)
to support community events.
21/48
DPR
Reconstruct or
Renovate eastern (Broadway) perimeter
upgrade a park or
playground in Ft. Tryon Park's Anne Loftus
playground
Playground and add sensory playground.
22/48
SCA
Renovate interior
Provide funding for a new elevator at George
549
building component
Washington Educational Campus.
AUDUBON
AVENUE
23/48
HHC
Other health care
Funding for a new facility for the Washington
facilities requests
Heights CORNER Project
24/48
DPR
Reconstruct or
Inwood Hill, Highbridge and Fort Tryon Parks:
upgrade a park or
Reconstruct/maintain 60+ miles of park
amenity (i.e.
pathways and paving.
playground, outdoor
athletic field)
25/48
NYPD
Other NYPD
Procurement of additional noise decibel readers
facilities and
for CD12M
equipment requests
(Capital)
26/48
NYCTA
Repair or upgrade
Rehabilitate the W. 157 Street IRT Subway
subway stations or
Station.
other transit
infrastructure
27/48
DFTA
Renovate or
System-wide upgrade of area senior centers to
upgrade a senior
improve connectivity for Wi-Fi and
center
telecommunication services.
28/48
DPR
Reconstruct or upgrade a park or playground
Repair & reconstruct Ft. Tryon Park's Linden Terrace
29/48
FDNY
Provide new
Procurement of all terrain vehicle (ATV) or
emergency vehicles,
"Gator" vehicles for FDNY for efficient response
such as fire trucks or
in CD12M's vast parklands.
ambulances
30/48
NYCTA
Repair or upgrade
Rehabilitate the W. 155 Street IND Subway
subway stations or
Station.
other transit
infrastructure
31/48
SCA
Renovate interior
Renovate the George Washington Educational
building component
Campus Gymnasium (built in 1969)
32/48
NYCTA
Repair or upgrade
Rehabilitate West 207th Street IRT (1 Train)
subway stations or
Subway Stations.
other transit
infrastructure
33/48
NYPD
Other NYPD
Lighttower within the 33rd and 34th Precincts.
facilities and
equipment requests
(Capital)
34/48
SCA
Renovate interior
Upgrade Science Lab(s) at M468/HS for Health
building component
Careers & Sciences
35/48
SCA
Renovate other site
Provide funding to expand Computer at
component
M468/HS for Health Careers and Sciences
36/48
NYPD
Provide surveillance
Procure 2 Argus Cameras for NYPD 33rd
cameras
Precinct placement in high crime and low traffic
areas alongside Edgecombe/Riverside Drive or
along 155th Street and Riverside Drive
37/48
DPR
Reconstruct or
Renovate Payson Playground & make it and the
upgrade a park or
park house accessible
amenity (i.e.
playground, outdoor
athletic field)
38/48
FDNY
Other FDNY facilities
Procurement of a Bariatric Stretcher for FDNY
and equipment
requests (Capital)
39/48
Other
Other capital budget
Community food garden
request
40/48
DPR
Reconstruct or
More family picnic / BBQ areas throughout
upgrade a park or
CD12 Parks to meet increasing community
amenity (i.e.
demand
playground, outdoor
athletic field)
41/48
DPR
Reconstruct or
Shoreline preservation and bulkhead repairs in
upgrade a park or
Ft. Washington Park
amenity (i.e.
playground, outdoor
athletic field)
42/48
DPR
Reconstruct or
Highbridge Rec Center weatherization (fix
upgrade a park or
windows to retain heat/cooling)
amenity (i.e.
playground, outdoor
athletic field)
43/48
SCA
Renovate interior
HVAC Upgrade to add air conditioning in the
549 Audubon
building component
George Washington Educational Campus
Avenue
auditorium.
44/48
DPR
Improve access to a
Reconstruct Bushman Step Street West 157th
W 157th ST
park or amenity (i.e.
between Edgecombe and St. Nicholas Avenue
Edgecombe
playground, outdoor
St. Nicholas
athletic field)
Ave
45/48
Other
Other capital budget
Business façade improvement funding
request
46/48
DPR
Improve access to a
J. Hood Wright overlook and viewing platform:
park or amenity (i.e.
ADA accessibility
playground, outdoor
athletic field)
47/48
DPR
Reconstruct or
Asbestos abatement and restoration of
upgrade a parks
"Building D" in Ft. Tryon Park for security
facility
presence
48/48
SBS
Other capital
Business training/capacitation hubs (additional
commercial district
to services offered by SBS)
revitalization
requests
CS
DSNY
Provide new or
Construct new District 8M garage and relocate
upgrade existing
its trucks from District 12M.
sanitation garages
or other sanitation
infrastructure
CS
NYCTA
Repair or upgrade subway stations or other transit infrastructure
Rehabilitate the Subway Stations at West 181st and West 168 Streets IND.
CS
SCA
Renovate or
Provide funding to renovate and upgrade
upgrade a high
classroom at M468- H.S. for Health Careers and
school
Sciences
CS
DPR
Reconstruct or
Dyckman Farmhouse: roof repairs.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Renovate/rehabilitate Msgr. Kett Playground
upgrade a park or
(204 btw. 10th & Nagle)
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Morris-Jumel Mansion ADA Accessibility and
upgrade a park or
exterior renovation including renovation
amenity (i.e.
following following water main break.
playground, outdoor
athletic field)
CS
NYPL
Create a new, or
Full renovation of Fort Washington branch
535 WEST
renovate or upgrade
library.
179 STREET
an existing public
library
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/44
DOHMH
Create or promote
Expand mental health services in the
programs to de-
community, including crisis intervention and
stigmatize mental
acute care for persons with severe mental illness
health problems
and encourage
treatment
2/44
DOHMH
Other programs to
Increase substance abuse services in our
address public
community, including opioid overdose
health issues
prevention education, and funding for syringe
requests
cleanups and collections
3/44
HPD
Other affordable
Increase funding for legal representation in
housing programs
court in all zip codes not currently covered in CD
requests (expense)
12,M particularly zip codes in the rezoning area
and increase the AMI eligibility to 300% from
200% under the Right to Counsel Program.
4/44
DCP
Other zoning and
Dedicated additional planning staff to work with
land use requests
CB12M and local residents to formulate and
implement a community-based neighborhood
preservation (formerly stated “contextual
zoning”) plan for Washington Heights and
Inwood, exclusive of any work undertaken in
connection with EDC’s recent Inwood Rezoning
plan.
5/44
NYPD
Provide resources to
Expand implicit bias, mental health, substance
train officers, e.g. in
use training programs and multi agency
community policing
response.
6/44
DHS,
Provide, expand, or
Increase Tenant support specialists specific to
HRA
enhance anti-
CD12,M and fund initiatives to inform and
eviction legal
educate tenants of their rights.
services
7/44
DPR
Enhance park safety
Fund additional Park Enforcement Personnel
through more
(PEP).
security staff (police
or parks
enforcement)
8/44
NYPD
Increase resources
Expand Domestic Violence and Anti-Sexual
for domestic
Harassment programs and improve multi-
violence prevention
agency response.
programs
9/44
DFTA
Enhance home care
Increase the expansion in the program
services
"Expanded In Home Services For Elderly Persons
(EISEP)" funding to provide affordable home
care, including sliding scale reimbursement
(fees based on a customer's ability to pay).
10/44
DOE
Other educational
Increase funding for Individualized Education
programs requests
Plans and 504 Plans for students with identified
learning difficulties/disabilities in School District
6.
11/44
DOHMH
Create or promote
Increase services to prevent and treat chronic
programs to de-
diseases, such as Alzheimer's, diabetes, cancer
stigmatize mental
and heart disease, in our community
health problems
and encourage
treatment
12/44
DFTA
Other senior center
Increase funding to expand services at senior
program requests
centers in CD 12, M to include hiring additional
social workers and program coordinators to
create culturally competent programs, adding
meals, extending hours, increasing per-meal
reimbursement rates, etc.
13/44
DOHMH
Provide more
Increase HIV/AIDS prevention and treatment
HIV/AIDS
services, and LGBTQ services, in our community
information and
services
14/44
DHS,
Other homelessness
Provide more funding for the Homebase
HRA
prevention program
Program in CD 12, M to prevent individuals and
request
families at imminent risk for entering the NYC
shelter system.
15/44
DPR
Provide more
Increase funding by at least $500k for various
programs in parks or
programming throughout CD12 parks,
recreational centers
playgrounds, courts, & historic houses: fund
additional Playground Associates and Parks &
Urban Park Ranger staff as well as contracted
specialists for afterschool, recreational,
waterfront, and cultural programming for kids,
teens, adults, & seniors
16/44
Other
Other expense
DOE - Funding needed for comprehensive
budget request
testing for lead in water and paint in all District
6 schools by a third-party agency.
17/44
Other
Other expense
DEP - Increase staff to conduct regular noise
budget request
enforcement, air quality monitoring and water
quality testing in our community
18/44
DOE
Other educational programs requests
Increase funding for Class Size Reduction in School District 6.
19/44
HPD
Other affordable
Funding for more HPD Housing Code Violation
housing programs
inspectors
requests (expense)
20/44
DOHMH
Other programs to
Provide funding to ensure that all local public
address public
schools have health clinics (DOHMH)
health issues
requests
21/44
DCLA
Support nonprofit
Increase DCLA funding by at least $500k to
cultural
increase support for arts programming and
organizations
individual artists within CD12M (DCLA)
22/44
DOT
Improve traffic and
Increase funding for repairs of pedestrian
pedestrian safety,
sidewalks, including curb ramps
including traffic
calming (Expense)
23/44
DOHMH
Other animal and
Increase pest control efforts to eliminate rats,
pest control
cockroaches, etc. in our community (DOHMH).
requests
24/44
DHS,
Other homelessness
Increase funding for supportive housing for
HRA
prevention program
LGBTQ youth
request
25/44
DOE
Other educational
Provide funding to increase support for social-
programs requests
emotional learning skills programs for students
in School District 6 .
26/44
DFTA
Increase
Increase funding for transportation for seniors
transportation
by restoring prior budget cuts and expand
services capacity
access and outreach to these services.
27/44
NYCTA
Other transit service
Increase funding for subway station personnel,
requests
maintenance, communication technology, and
security
28/44
DPR
Forestry services,
Dedicated Forestry Crew for CD12: Dedicated
including street tree
crew of 4 to help w/ sustained invasives removal
maintenance
& native plantings in Inwood & Highbridge
forests
29/44
FDNY
Expand funding for
Increase funding to support FDNY in addressing
fire prevention and
and correcting violations and enhance fire
life safety initiatives
prevention in housing and nightlife
establishments.
30/44
DOHMH
Increase health inspections, e.g. for restaurants
Spanish-speaking health inspectors
31/44
DOHMH
Other programs to
Create an educational campaign about the
address public
federal public charge rule to inform immigrants
health issues
of their rights to obtain health services and
requests
other benefits
32/44
NYPL
Extend library hours
Maintain funding to provide six days of service
or expand and
at all NYPL branches
enhance library
programs
33/44
DFTA
Increase home
Increase access and outreach to healthy food
delivered meals
programs for seniors with medical and health
capacity
related needs.
34/44
DSNY
Provide more
Increase trash basket collection on commercial
frequent litter
streets on weekends in District 12M (DSNY)
basket collection
35/44
DPR
Provide better park
Fund additional staff for Sanitation,
maintenance
Maintenance & Operations, Horticulture (2
APSWs, 6 CPWs to ensure more sites have fixed
post staff) (DPR)
36/44
DSNY
Other garbage
Increase funding for education and outreach on
collection and
recycling, reuse and composting as well as
recycling requests
proper disposal of household garbage in our
community
37/44
DFTA
Enhance NORC
Increase funding for Naturally Occurring
programs and
Retirement Communities (NORC) or multi-family
health services
housing that has inherited a significant numbers
of older adults since there is no support or a
funding mandate for nursing care, case
management assistance and health with
benefits and entitlement.
38/44
DFTA
Other senior center
Increase OTPS funding for replacement
program requests
furnishings (non-capital) in senior centers as
needed.
39/44
DOT
Other expense
Increase funds for pothole repairs
traffic
improvements
requests
40/44
Other
Other expense
Add speed cameras in 34th precinct
budget request
41/44
Other
Other expense budget request
Education campaign on potential impact of the Inwood Rezoning on businesses
42/44
SBS
Provide or expand
Funding for Business Committee Resource Guide
business education
for new & existing businesses
to businesses and
entrepreneurs
43/44
DOT
Other expense
Funding for a study focused on how to improve
traffic
traffic flow to and from all of the eight major
improvements
bridges in CB12M
requests
44/44
SBS
Support local CBOs
Marketing support for businesses
efforts to provide or
expand district
marketing,
branding, and
promotion

