- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 12 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1dEmZj0KMqwHeZX4bVlVaV_LTYe84SFOX/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1dEmZj0KMqwHeZX4bVlVaV_LTYe84SFOX/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
'
2021
image
11¥1:
Published by:
PLANNING
February 2020
•'''
Brooklyn Community District
12
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 12
image
Address: 5910 13th Avenue Phone: (718) 851-0800
Email: bkcb12@gmail.com
Website: www.brooklyncb12.org
Chair: Yidel Perlstein District Manager: Barry Spitzer
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Brooklyn Community Board 12 encompasses neighborhoods of Borough Park and parts of Kensington, Sunset Park and Midwood. Borough Park is known for its large enclave of Hasidic Jewish residents. Kensington is home to rapidly growing Pakistani and Bangladeshi Communi es. Sunset Park, specifically 8th Avenue which borders District 12 as well as District 7, is the loca on of Brooklyn’s Chinatown. Midwood’s Ocean Parkway is the site of 4.86 miles long boulevard that connects the Coney Island Beach to Prospect Park.
Community Board 12 represents a diverse popula on with dis nct and varied needs. The dis nc ons of the district
are what makes the needs unique. There are several differences of note in the 2017 American Community Survey as compiled by the United States Census Bureau.
The 2017 ACS birth rate in this district is 11.5%, which is more than double the average New York rate of 4.6% (calculated as the percentage of women ages 15-50 who gave birth the previous year). This leads to a
dispropor onate number of infants, children and youth who require childcare and other youth services. Indeed, the percentage of youth under the age of 18 is 36.3%- the largest of any district in NYC (per NYC Planning). These children, largely educated in non-public schools, are en tled to the proper delivery of city services, such as trash collec on. These children should not be accosted by decaying organic matter on the streets in front of their schools.
65.9% of residents in this district use English as a second language (ESL). 55% of the residents speak an Indo- European language (The NY rate of Indo-European language as the spoken language at home is 8%, The US rate is 3%). Notably, Yiddish, the language largely used by Hasidic residents, as well as the languages origina ng in the Indian subcon nent, are all Indo-European languages. This is noteworthy because of the lack of proper accommoda on for these ESL speakers. While NYC is well equipped to fully accommodate ESL speakers whose primary language is Spanish, the same is not true of ESL speakers whose primary language is Yiddish. The accommoda ons provided appear as though google translated, with awkward wording and syntax, which is difficult to understand. This district needs services provided in a way its residents can understand.
The district is comprised of a wealth of cultural and ethnic enclaves. The US Census data combined with OpenStreetMap data found that 22% of the popula on in Kensington, a neighborhood within CB12, iden fy as ethnically Asian; this reflects the vibrant Pakistani, Bangladeshi and Indian communi es that live in the area. The Kensington area itself has welcomed many new families with young children. However, the Kensington area is largely devoid of Parks or Green streets in close enough proximity to be of use to these children.
The Chinatown of Brooklyn is located on 8th Avenue, which is the boundary between Community Board 7 and Community Board 12. This area has seen a steady evolu on in its ethnic makeup to accommodate the growing cultural community within this desirous enclave: in some streets located between 8th and 9th ave, between 75%-90% of residents iden fy as ethnically Asian.
Because of religious and cultural necessi es unique to the diverse cultures this district encompasses, Community District 12 has become a much-desired area in which to live. All areas of our District are experiencing an influx of large families, which is contribu ng to the density of this District as a whole. The district suffers from traffic conges on, lack of parking, sanita on deficiencies, and infrastructure problems. The prime example is Borough Park, which con nues to be the most densely populated sec on of the District. Religious constraints and sizable
families anchor the community to this district because of the proximity to their houses of worship, kosher shopping areas and schools.
Traffic is brought about by the density of the district. For one, the amount of school buses needed to transport children to school is remarkable (rough es mates are about 300-350 buses a day). Understanding that traffic and parking are par for the course in dense ci es, we propose a few changes that we have observed can alleviate some conges on in a fiscally viable manner. The district, due to the con nued growth of the community, is constantly subjected to construc on and infrastructure upgrades which further exacerbates the problem. And while permits by DOT are required for such work, the s pula ons embedded to ensure traffic flow are ignored many mes. These
illegal street closures create chaos with the inevitable extra burden on traffic. An increase in DOT HIQA oversight will ensure that construc on is done as painlessly as possible.
We also request some innovative ideas should be seriously explored: some of our busiest stretches have traffic patterns that vary according to the time of day. Therefore, we request a middle lane of traffic to change directionally according to the patterns of am and pm rush hours. This remedy, which is already in use at other big cities, will accommodate the morning rush of traffic to work and school. We would also like serious consideration given to residential parking tags to ease the parking burden of the residents of the district.
Borough Park is in dire need of affordable housing to accommodate its growing population who come to this district for its cultural wealth- not monetary wealth. A large portion of the population lives in poverty and cannot afford the market prices on housing.
Our children, comprising a large percentage of the population, are largely educated in religious private schools. Ever since Everson v Board of Education (1947), the largely held legal opinion was that all school children are entitled to essential services:
“cutting off church schools from these services * so separate and so indisputably marked off from the religious function would make it far more difficult for the schools to operate. But such is obviously not the purpose of the First Amendment. That Amendment requires the state to be a neutral in its relations with groups of religious believers and nonbelievers; it does not require the state to be their adversary.”
this statement was made in reference to transportation needs.
And while New York City celebrates diversity of culture and religion, the New York City Department of Sanitation does not fully service private school children, who are fed 3 meals daily, the same way it does public school children. Private schools get serviced only twice a week, as all residences. But, because Borough Park is home to the largest amount of private schools in NYC, this creates a huge problem (some schools house between 2-4 thousand children- which is many times larger than local district schools). Garbage piles up and gets spread around all over the street. This creates a smell during the summer. Sanitation workers can't fit the piles of garbage into their trucks and leave some for the next scheduled twice-weekly pickup. This creates a major decline in our quality of life. Daily trash collection for our private schools, who also serve daily meals thereby generating rapidly decaying garbage, is an absolute necessity.
One of the primary complaints of residents of the district is the lack of oversight in Sanitation. Residents report masses of trash scattered in the streets left in the wake of what is supposed to be routine trash collection. The fact is, many sanitation employees are lax in how they do their jobs. On the other hand, residents complain that they are ticketed for minor infractions such as candy wrappers that are blown into their sidewalk frontage after they cleaned in front of their house. Despite the institution of additional supervisors, the problem remains prevalent. We propose cameras mounted on all trucks so that supervisors have the ability to monitor and review their crew. It is high time the sanitation department provides of photo evidence on every ticket. The accountability cameras will provide will lead to responsible trash collection and enforcement. This technology already exists and is used to ensure essential services are provided properly.
The Community Board 12 District is, and continues to be, a viable tax base. However, the demographic outliers present unique challenges. The board has the intimate knowledge of these details and how to work with them. We are ready, willing, and able to do whatever we can to assist NYC in its stated goal of promoting and celebrating diversity.
We add one caveat to our statement in order to further emphasize the needs of our district: CB12’s participation rate in the 2010 Census was 49%. All population related data is therefore grossly underrepresented leading to a further strain on resources allocated by population. This Community Board, in conjunction with many local government and community organizations, has engaged in a major effort to drive up the participation rate to 100% participation in the 2020 Census. Our needs are greater than reflected in this statement and we sincerely hope the City will respond to the genuine needs of our district.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 12
image
The three most pressing issues facing this Community Board are:
Affordable housing
Community Board 12 is a densely populated community with large families living in the district. Community Board 12 is home to one of the largest enclaves of Jewish religious community which many members naturally gravitate to. This vibrant neighborhood is very much in demand as a center that can meet all of the religious, social and community needs unique to this community. As a result, the housing supply is low and the demand very high driving property values up and making affordable housing almost non-existent. This high price is not driven by the ability of the market to pay the price, but rather by the extreme scarcity of property for sale or for rent. For most families in our district, buying a home is practically out of reach and renting for a reasonable rate is almost impossible. Solutions to affordable housing are crucial to this community.
Traffic
Community Board 12 serves a vibrant, ever expanding, diverse community. These properties contribute to extreme traffic congestion. The growing community tend to have motor vehicles which leads to an extreme parking shortage. The inordinate amount of school buses (both am and pm), along with all other traffic, taxes the roads and leads to frequent roadway breakdowns. Studies of both the traffic and parking flow in areas throughout the district should be done to best determine cost effective measures to modernize the traffic patterns in order to bring the "old" community into the 21st century.
Trash removal & cleanliness
Community Board 12 has long been plagued with sanitation related problems. These problems not only affect the quality of life, it also present a public health and safety issue that cannot be side swept. There is an illegal dumping problem where sometimes dangerous or even hazardous items are dumped without regard for the safety of passersby who are sometimes little children. This district has many more private schools than public schools and thus private school enrollment far outnumbers the student enrollment in public schools. However, whereas public schools get daily trash collections, the private schools do not. The lack of daily collection becomes a health and quality of life hazard because of the rotting organic matter that sits around for days. More oversight is needed over sanitation employees who don’t do their jobs. There has been an overload of cases in the past of spillage and incomplete garbage collection
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 12
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
While many social services programs available through HRA, not all are fully utilized. This is partially because many of our residents don’t know of these programs or don’t have access to the programs that are available. In consolidating HRA centers, a great disservice has been done to the neediest residents in our district; those that may not know how to navigate the web or the city subway system. Community Board 12 is dire need of an HRA center within this district. Many of our residents use services from HRA such as; SNAP (food stamps), Medicaid, welfare, HEAP, and childcare vouchers. The research shows that this district is one of the largest recipients of HRA services in the Borough. Many in our district, especially the Orthodox community, do not have access to the internet, thereby making it very difficult to make use of HRA services, like Access HRA, that are offered on the internet. Many HRA clients have to travel a long time to get to an HRA facility and then spend almost an entire day there. They sometimes need to bring their children and sometimes have to give up a day's work. Many of our residents feel that when visiting an HRA facility that there is some lack of cultural sensitivity, so we are asking HRA to send some service professionals to our office to serve our community, as they have done in the past.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
Adequate funding is needed for Community based organizations. Our district is in dire need of a HRA office. We have a lot of English as Second Language (ESL) residents who don't understand English and have to travel far to get to the right agencies. 65.9% of residents in this district use English as a second language (ESL). 55% of the residents speak an Indo- European language (The NY rate of Indo-European language as the spoken language at home is 8%, The US rate is 3%). Notably, Yiddish, the language largely used by Hasidic residents, as well as the languages originating in the Indian subcontinent, are all Indo-European languages. This is noteworthy because of the lack of proper accommodation for these ESL speakers. While NYC is well equipped to fully accommodate ESL speakers whose primary language is Spanish, the same is not true of ESL speakers whose primary language is Yiddish. The accommodations provided appear as though google translated, with awkward wording and syntax, which is difficult to understand. This district needs services provided in a way its residents can understand.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
2/8 HRA Other request for
services to support low-income New Yorkers
Community Board 12 is in dire need of an HRA Social Services agency office in this district; to aid residents with social services such as welfare, snap, cash assistance, Medicaid, heap and childcare vouchers. HRA has been consolidating its centers and has shut down the center most often used by CB12 residents. Some of the neediest are unable to access help online and are unable to figure out a way to downtown Brooklyn. The district represents many residents unfamiliar with the English Language and unfamiliar with basic technology; they require in-person assistance.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/25
HRA
Other request for
In our Capital requests we asked for an HRA
services to support
service center in our district. Knowing that
low-income New
getting a new HRA Service Center in our district
Yorkers
is a big ask, we are requesting that at least HRA
send service professionals a few times a month
to our office to service our residents, as they
have done in the past. In FY2020 HRA
responded to this same request (212202003E)
saying the 'request has already been funded'.
Further communication with HRA clarified that
funding is appropriated for training programs-
which is not what we are asking. We currently
have fully equipped office space that can be
used by an HRA staffer who can service
individually members of our district who may
not have the ability to avail themselves to
assistance now.
21/25 DOHMH Create or promote
programs to de- stigmatize mental health problems and encourage treatment
Under the leadership of the Mayor, NYC made it a priority to improve Mental Health. This effort hasn’t succeeded in reaching CB12 residents.
This is largely due to language barriers and the stigma associated with mental or emotional difference. Thus, many residents here are left undiagnosed & untreated. This often compounds the necessity of extreme and costly interventions. CBO’s within our district are uniquely qualified to understand the culture in this insular community and can work within the parameters of the unique differences inherent in the district. Funding is required for extensive awareness campaigns to eliminate the stigma preventing anyone from asking for such help.
This aims to prevent the most vulnerable from
falling prey to the opioid epidemic.
image
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 12
image
M ost Important Issue Related to Youth, Education and Child Welfare
Youth workforce development and summer youth employment
Adequate funding is needed for the Community based programs that are youth oriented. More funding should be applied to the Summer Youth Employment Program. Many youth, especially older teenagers, are denied employment due to lack of funding.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
17/25 DYCD Provide, expand, or
enhance the Summer Youth Employment Program
Adequate funding is needed for the Community based programs that are youth oriented. More funding should be allocated to the Summer Youth Employment Program. Many youth, especially older teenagers, are denied employment due to lack of funding. Summer employment serves a dual purpose in both occupying teenagers and teaching them responsibility and accountability.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 12
image
M ost Important Issue Related to Public Safety and Emergency Services
Public safety facilities (precinct, fire houses, etc.)
Generations of Police Officers have had to “live” in a decrepit, antiquated “House” with absolutely no amenities and with conditions that would be considered substandard and inferior for the criminals and derelicts, but are accepted and condoned at this Station House as suitable for our Police Officers.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Our Precinct is very old and falling apart. We need a new precinct house to provide better conditions and technology to accommodate our police officers.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/8
NYPD
Renovate or
66th Precinct - Demolish and reconstruct a new
5822 16th
upgrade existing
66th Precinct Station House on the footprints of
Ave
precinct houses
the present site. A new precinct house for the
66th Precinct is one of the oldest budget
requests initiated 35 years ago. Funding was
eliminated for a project proposal to construct a
new 66 Precinct Stationhouse in the FY 12
budget. The 66th precinct must be demolished
and a new 66th precinct must be built on the
footprints of the present site. Although, some
renovations were made, specifically the front
entrance to the precinct, the building is still old
and there is a need for a new one.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
2/25
NYPD
Assign additional
TCAs (Traffic Control Agents): Our district is in
traffic enforcement
dire need of Traffic Control Agents assigned to
officers
float to areas of concern throughout the critical
areas in our District, as well as other alternative
measures to decrease congestion. Currently, we
have none. The areas of specific concern are:
18th Avenue from 45th Street to Ocean
Parkway, 15th Avenue from 42nd Street to 45th
Street, 14th Avenue from 49th Street to 42nd
Street, 13th Avenue from 39th Street to 54th
Streets, Avenues I and J from McDonald Avenue
to Coney Island Avenue, Fort Hamilton Parkway
from 36th Street to 46th Street . These are a few
of the notoriously congested areas. The
locations are subject to change based on
seasonal and other variables. The traffic
congestion and horn honking are severe
especially during the AM and
5/25 NYPD Provide additional
patrol cars and other vehicles
The 66th Precinct Community Affairs Unit’s unmarked vehicle is currently in bad shape and keeps breaking down. We are requesting a new unmarked vehicle dedicated to the Community Affairs Unit. Last year, the agency initial response to tracking 212202003C was that this has been or will be completed in 2019. The adopted budget stated that due fiscal constraints, the availability of funds is uncertain. This is a necessary item for the safety of our community.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 12
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
Community Board 12 district is in dire need of more collection services and dumping enforcement. Our children, comprising a large percentage of the population, are largely educated in religious private schools. Ever since Everson v Board of Education (1947), the largely held legal opinion was that all school children are entitled to essential services: “cutting off church schools from these services ...so separate and so indisputably marked off from the religious function would make it far more difficult for the schools to operate. But such is obviously not the purpose of the First Amendment. That Amendment requires the state to be a neutral in its relations with groups of religious believers and nonbelievers; it does not require the state to be their adversary.” *this statement was made in reference to transportation needs. And while New York City celebrates diversity of culture and religion, the New York City Department of Sanitation does not fully service private school children, who are fed 3 meals daily, the same way it does public school children. Private schools get serviced only twice a week, as all residences. But, because Borough Park is home to the largest amount of private schools in NYC, this creates a huge problem (some schools house between 2-4 thousand children- which is many times larger than local district schools). Garbage piles up and gets spread around all over the street. This creates a smell during the summer. Sanitation workers can't fit the piles of garbage into their trucks and leave some for the next scheduled twice-weekly pickup. This creates a major decline in our quality of life. Daily trash collection for our private schools, who also serve daily meals thereby generating rapidly decaying garbage, is an absolute necessity. One of the primary complaints of residents of the district is the lack of oversight in Sanitation. Residents report masses of trash scattered in the streets left in the wake of what is supposed to be routine trash collection. The fact is, many sanitation employees are lax in how they do their jobs. On the other hand, residents complain that they are ticketed for minor infractions such as candy wrappers that are blown into their sidewalk frontage after they cleaned in front of their house. Despite the institution of additional supervisors, the problem remains prevalent. We propose cameras mounted on all trucks so that supervisors have the ability to monitor and review their crew. It is high time the sanitation department provides of photo evidence on every ticket. The accountability cameras will provide will lead to responsible trash collection and enforcement. This technology already exists and is used to ensure essential services are provided properly.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Many of the sewers in our district are antiquated and need to be replaced. Also, after a rain a lot of the catch basins on the corners get clogged up and huge puddles make it impossible for pedestrians to cross the street. Cleaning and enlarging these catch basins should be a priority and done regularly to prevent combined sewer overflow.
Needs for Sanitation Services
Due to the density of population in Community District 12, increasing sanitation services to the maximum amount possible is essential to our quality of life.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
1/25 DSNY Provide more
frequent garbage or recycling pick-up for schools and institutions
Provide daily garbage and recycling pick-up for Private Schools. CB 12 has about 80 private schools serving approximately 100,000 or more children. The District has 16 public schools which serves approximately a third of the total enrollment of the private schools. The student enrollment in some of the public schools has been dwindling rather than increasing. Most of these private schools have year round lunch programs with perishable foods. However, the private schools only receive two pickups per week while the public schools are picked up daily. The student enrollment in private schools far outnumber the enrollment in public schools in this district and because of the amount of garbage generated from these schools each day, daily pickups must be implemented.
image
6/25 DEP Clean catch basins All catch basins should be cleaned on a regularly
scheduled basis. Deteriorated catch basins should be repaired or replaced as part of a regular maintenance schedule. There has been an increase in flooding complaints. DEP is under a consent decree to alleviate combined sewer overflow. One of the obvious ways to work towards this is to make sure rainwater drains properly through the catch basins. This does not happen when the catch basins are clogged.
There were many areas of repeated environmental concern- such as: 53rd St. from 11th Ave. to 13th Ave., 55th Street & 12th Ave., 51st St. & 12th Ave. And while we are happy to work with constituents in reporting this to DEP- this is only after the symptoms of neglect (flooding!) appear.
image
7/25
DSNY
Provide more
We are also requesting the mechanical sweeper
frequent garbage or
on the 12am to 8am midnight shift six days a
recycling pick-up
week be returned (it has been taken away on
7/1/2017 in the FY18 budget) this sweeper
effectively cleans the district. Our district
constantly rates low on the scorecard and this
should help maintain cleanliness throughout the
district.
8/25
DSNY
Increase
There has been a major increase of illegal
enforcement of
dumping. Especially along the LIRR freight line.
illegal dumping laws
Specific areas along the line are: 61st St.
between 11th and 12 Ave., 56th St between
15th and 16th Ave., and 55th St. between 16th
and 17th Ave. 49th St. between 18th Ave. and
19th Ave. (the deadend street) is a location that
is plagued by illegal dumping. Parkway.
Sanitation Police Officers should be assigned to
our district to catch violators and enforce
Sanitation laws. We need enforcement to work
closely with the Superintendent. The Super
should have input of target areas and get
continuous reports from Enforcement on their
progress.
9/25
DSNY
Other cleaning
We are requesting an increase from 5 broom
requests
routes to six broom routes on Monday, Tuesday,
Thursday and Friday.
10/25
DSNY
Other garbage
We are requesting the return of a permanent
collection and
cleaning officer to the district. Currently BK12
recycling requests
does not have a dedicated cleaning officer. Such
an officer would go a long way to remedy the
chronic littering in high litter areas.
11/25
DSNY
Other garbage
We request cameras mounted on Sanitation
collection and
Truck to ensure essential services are provided
recycling
properly. We also request photos attached to
infrastructure
sanitation violations when issued to residents.
requests (Expense)
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 12
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
With the steady increase in population in the Community Board 12 area and the particular religious and cultural needs of our residents which prevents most from leaving this community, there is a critical need for affordable housing. Families in this district have many children and need housing to accommodate their larges families at an affordable rate. Currently, most families are spending upwards and above 80% of their monthly earnings on rent and buying for almost most of them is out of the question.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
We would like for some commercial areas in our district to be rezoned for residential development with an increased focus on affordable housing.
Needs for Housing
Continuation of funding for additional programs.
Needs for Economic Development
Workforce development is a prime concern in our area.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
19/25 SBS Other expense workforce development requests
Due to a large amount of residents in our district that are neither college educated, nor proficient in the English Language, investing in targeted vocational training in this district, with an emphasis on high paying and emerging skills, is a priority that would go a long way towards raising the current low incomes so many families here are experiencing. There are no Work Force 1 (WF1) centers close enough to service the district, therefore providing funding to fill the gap is appropriate. Nor are there any programs that are truly Yiddish compatible.
image
22/25 DCP Study land use and
zoning to better match current use or future neighborhood needs
One of the major issues plaguing the district is the lack of affordable housing. To that end, we request some long overdue studies of commercial areas in our district, specifically the commercial strip spanning 60th street, for the purposes of being rezoned for residential development with a major focus on affordable housing.
TRANSPORTATION
Brooklyn Community Board 12
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
Our community is in dire need of Traffic Control Officers assigned to critical areas in our District as well as alternative measures to decrease congestion. At this time, we have none. Locations where traffic congestion is out of control are 18th Avenue from 45th Street to Ocean Parkway; 15th Avenue from 42nd Street to 45th Street; 14th Avenue from 49th Street to 42nd Street (morning hours)’ 13th Avenue the entire day from 39th Street to 54th Streets’ and Avenues I and J from McDonald Avenue to Coney Island Avenue, especially during rush hours (these are just to name a few). The traffic congestion is extremely severe as well as the horn honking during both the AM and PM rush hours.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The infrasture within Community District 12 is outdated and crumbling. The area is in need of an overall engineering study to upgrade and update the area to be viable. We need the full use of all 21st century innovations to help keep the district moving in a safe manner. Vision Zero is an important goal, there have been too many traffic fatalities in the community. There are traffic calming measures and traffic flow studies we are asking for to make our district safer for vehicles, pedestrians, and cyclists.
Needs for Transit Services
With many of our residents using mass transit, some better accommodations and services are warranted.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/8
NYCTA
Improve
Due to large number of young children and
accessibility of
senior citizens in our district, mothers with their
transit
strollers and elderly, sometimes with walkers,
infrastructure, by
are having a hard time getting onto the train
providing elevators,
platforms. There is an urgent need to install
escalators, etc.
elevators at the D and F lines. Preferably at the
18th Avenue and McDonald station for the F
line, where transfers to several bus lines are
available, and the 50th Street and New Utrecht
Avenue station for the D line, the closest subway
station to Maimonides Medical Center, a level 1
Trauma Center as well as one of the most oft
used birth centers in New York State. NYCTA
should add these stations to their priority lists.
5/8
DOT
Reconstruct streets
37th Street between 14th & 15th Avenues is dire
37th street
need of reconstruction. DOT has requested
14th Ave 15th
funding for this project (FY2020 212202010C).
Ave
This would not qualify as a standard street
repaving because of the unique aspects of this
street, such as the absence of curb cuts. This
street is plagued with potholes, sink holes, and
cracked streets that are dangerous to motorist
as well as pedestrian crossings. The unattended
potholes and various depressions lead to
flooding with every rainstorm.
6/8
DOT
Improve traffic and
We request a pedestrian crossing for the Ave. K
Ocean
pedestrian safety,
& Ocean Parkway intersection. As of now there
Parkway
including traffic
is no pedestrian crossing for 2/5th of a mile,
Avenue K
calming (Capital)
from Ave. J to Ave. L. It is a matter of public
safety to install a traffic light that allows
pedestrians for cross safely. A traffic light will
slow traffic on this stretch where cars routinely
speed up because there are no traffic calming
measures in place.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/25
DOT
Other expense
NYC.gov states there are 150 HIQA inspectors.
traffic
Their mission statement includes “increas(ing)
improvements
the level of safety for both pedestrian and
requests
vehicle travel…” and “expedit(ing) the flow of
traffic, for both pedestrian and vehicular traffic
around the construction zones.” However, street
permit stipulations are ignored more often than
not, leading to chaos. It must therefore be
necessary to increase the number of HIQA
inspectors to ensure compliance. DOT often
doesn’t send an inspector quick enough to be an
effective remedy, more inspectors and thus
quicker action will be immensely helpful. Many
times HIQA will come hours later- after
construction is complete. Further, an inspector
should be permanently assigned to the CB12
area and coordinate with the board for effective
permit compliance.
12/25
DOT
Provide new traffic
Expand the Traffic Engineering Department to
or pedestrian
be able to conduct traffic studies more
signals
expeditiously.
13/25
DOT
Conduct traffic or
13th Ave. is the commercial shopping Mecca in
parking studies
CB12. People come from all over to shop here
due to its ethnic flavor. On any given day, more
than 10k people traverse this shopping strip.
Parking is at a premium. It can take an hour to
pass through the 23 blocks of this shopping
strip. 13 Ave. hasn’t been redesigned in over 21
years and is in dire need of a thorough
engineering study to determine the best
measures to ease the traffic and parking
congestion nightmare, especially during rush
hours. We request such a study to determine the
feasibility of certain ideas. For instance, the
possibility of adding an additional lane with
interchangeable direction depending on the
time of day or adding turning lanes and maybe
eliminating parking at certain times to increase
traffic flow.
14/25
DOT
Conduct traffic or
Traffic is very congested along 18th Ave.,
18th Avenue
parking studies
specifically from 45th Street to Ocean Parkway
45th Street
and especially during morning hours. 18th Ave.,
Ocean
an already major thoroughfare, intersects with
Parkway
McDonald Ave. where the F line subway station
is. This creates both vehicular and pedestrian
traffic. We are requesting a thorough
engineering study to determine the feasibility of
certain measures to alleviate the strain. For
instance, the possibility of adding an additional
lane with interchangeable direction depending
on the time of day (as is done at various
locations in other cities) or adding turning lanes.
15/25
DOT
Conduct traffic or
A complete traffic study on Avenue J from
Avenue J
parking studies
McDonald Avenue to Coney Island Avenue is
McDonald
needed as well, especially at the intersection of
Avenue
Avenue J and Bay Parkway where there is a
Coney Island
constant bottleneck. The streets aren't aligned
Avenue
so that sometimes drivers may find themselves
continuing into a non-existent lane. There is
severe congestion during both AM and PM rush
hours. It can take very long to travel this strip,
especially from the Bay Parkway intersection to
Ocean Parkway.
16/25
DOT
Conduct traffic or
A complete traffic study on Avenue I from
Avenue I
parking studies
McDonald Avenue to Coney Island Avenue is
McDonald
needed. There is severe congestion as well as
Avenue
horn honking during both AM and PM rush
Coney Island
Hours. It can take up to one hour during rush
Avenue
hours to travel this strip.
23/25
DOT
Other expense
Upgrade street signs and markings throughout
60th Street
traffic
the district as needed. Specifically, on 60th
and 13th Ave
improvements
Street and 13th Avenue showing northbound
requests
traffic must turn either left or right as traffic
flowing on 13th avenue southbound up to 60th
street is ONE-WAY. We have multiple vehicles a
day going the wrong way southbound from
60th street to 59th Street. Also, signage is
needed that cars travelling east and west on
60th Street cannot make turns onto 13th
Avenue going northbound. This was requested
for FY2020 (212202026E) but was denied by the
Borough Commissioner because of existing "Do
Not Enter" signs. But this problem persists and
can be easily remedied with a sign directed to
the drivers who mistakenly drive the wrong way.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 12
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
We need a full complement of Parks personnel for our District to insure that each facility will have an attendant on a full-time basis. Comfort Stations cannot be utilized without Parks personnel present. Therefore, many remain closed and not utilized. It is imperative that personnel be assigned to these locations. Parks should be cleaned on a daily basis, especially those with Children’s playgrounds. All Parks must be provided with signage – Park Closes at Dusk – or 9:00 PM. Increased lighting must be provided in every facility.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Our parks are over utilized because of the large families living in our district. As new families continue to move into this district our parks become a mainstream for our children to play. Elected officials have contributed huge sums of money to upgrade our parks into state-of-the-art facilities that are pleasant outdoor spaces for children. However, the lack of security attracts an element to the parks that deters youth from wholesome play. It's a shame to have the capital expenditures go to waste due to security concerns.
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/8
DPR
Enhance park safety
Due to a rise in criminal activity and people
through design
loitering in the park after permitted hours we
interventions, e.g.
are requesting that the park be outfitted with
better lighting
permanent lighting to deter these activities at
(Capital)
night. Temporary fixes provided for the summer
are not sufficient deterrent year-round.
7/8
DPR
Reconstruct or
COL. MARCUS PARK - A comfort station in the
upgrade a park or
playground area is needed. Numerous children
amenity (i.e.
and adults must cross East 5th Street to go to
playground, outdoor
the other side of the park in order to use the
athletic field)
restrooms. This is a highly trafficked street. A
restroom, especially for the children using this
park, is essential to this playground.
8/8
DPR
Provide a new or
Rappaport Playground (53rd Street & Fort
Fort Hamilton
expanded park or
Hamilton Parkway) is the only roller hockey rink
Parkway
amenity (i.e.
left in Brooklyn and it's in dire need of a new
playground, outdoor
one, due to the use of rink. Also, the panels
athletic field)
surrounding the rink need to be replaced.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
18/25
DPR
Enhance park safety
Funding is needed for Parks Personnel to lock all
through more
parks in our district after dusk. Elected officials
security staff (police
have contributed huge sums of money to
or parks
upgrade our parks into state-of-the-art facilities
enforcement)
that are pleasant outdoor spaces for children.
However, the lack of security attracts an
element to the parks that deters youth from
wholesome play. It's a shame to have the
capital expenditures go to waste due to security
concerns.
20/25 DPR Forestry services,
including street tree maintenance
PARKS advised that the funds to repair sidewalks damaged by trees was increased. However, this increased funding has not yet resulted in actual repairs. We request PARKS repair the sidewalks damaged by trees as they said they would. Some of these areas are extremely dangerous for pedestrians and have been waiting for repairs for a very long time. One such example is the damaged sidewalk on 12th Ave. off 55th street. It was damaged by a falling tree in July 2019and has not been repaired as of mid-October 2019, despite some reported slip and falls. The sidewalk is lifted several inches off the ground.
image
24/25 DPR Provide better park
maintenance
Ocean Parkway is a main thoroughfare and is highly trafficked. In addition, Ocean Parkway is a Special District. The beauty of Ocean Parkway must not be allowed to deteriorate. Some of our elected officials have designated monies for the upgrade and beautification of the Malls.
Maintenance must be ongoing to make sure the upgrades and beautification remains intact. In order to maintain this arena in a sanitary and groomed condition, a crew should be assigned to maintain the malls of this thoroughfare and prevent homeless people from sleeping on the benches. An additional crew cab truck is requested to transport them the length and breathe of this roadway. The Malls and trees must receive regular attention so that the Parkway can be properly maintained.
image
25/25 DPR Forestry services,
including street tree maintenance
Although PARKS maintain a 7-year pruning cycle, oftentimes trees fall into disrepair before the 7 years are out. The incidents with falling trees or branches has been rising in our district due to delay in treatment of sick and dying trees. We request additional resources to provide for a safe timeframe to check on the health of trees specifically to prevent them from falling during severe weather conditions.
Additionally, the timeline for the replacement of trees is very long. We request additional resources to speed up the process.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/8
NYPD
Renovate or
66th Precinct - Demolish and reconstruct a new
5822 16th
upgrade existing
66th Precinct Station House on the footprints of
Ave
precinct houses
the present site. A new precinct house for the
66th Precinct is one of the oldest budget
requests initiated 35 years ago. Funding was
eliminated for a project proposal to construct a
new 66 Precinct Stationhouse in the FY 12
budget. The 66th precinct must be demolished
and a new 66th precinct must be built on the
footprints of the present site. Although, some
renovations were made, specifically the front
entrance to the precinct, the building is still old
and there is a need for a new one.
2/8
HRA
Other request for
Community Board 12 is in dire need of an HRA
services to support
Social Services agency office in this district; to
low-income New
aid residents with social services such as
Yorkers
welfare, snap, cash assistance, Medicaid, heap
and childcare vouchers. HRA has been
consolidating its centers and has shut down the
center most often used by CB12 residents. Some
of the neediest are unable to access help online
and are unable to figure out a way to
downtown Brooklyn. The district represents
many residents unfamiliar with the English
Language and unfamiliar with basic technology;
they require in-person assistance.
3/8
DPR
Enhance park safety
Due to a rise in criminal activity and people
through design
loitering in the park after permitted hours we
interventions, e.g.
are requesting that the park be outfitted with
better lighting
permanent lighting to deter these activities at
(Capital)
night. Temporary fixes provided for the summer
are not sufficient deterrent year-round.
4/8
NYCTA
Improve
Due to large number of young children and
accessibility of
senior citizens in our district, mothers with their
transit
strollers and elderly, sometimes with walkers,
infrastructure, by
are having a hard time getting onto the train
providing elevators,
platforms. There is an urgent need to install
escalators, etc.
elevators at the D and F lines. Preferably at the
18th Avenue and McDonald station for the F
line, where transfers to several bus lines are
available, and the 50th Street and New Utrecht
Avenue station for the D line, the closest subway
station to Maimonides Medical Center, a level 1
Trauma Center as well as one of the most oft
used birth centers in New York State. NYCTA
should add these stations to their priority lists.
5/8
DOT
Reconstruct streets
37th Street between 14th & 15th Avenues is dire
37th street
need of reconstruction. DOT has requested
14th Ave 15th
funding for this project (FY2020 212202010C).
Ave
This would not qualify as a standard street
repaving because of the unique aspects of this
street, such as the absence of curb cuts. This
street is plagued with potholes, sink holes, and
cracked streets that are dangerous to motorist
as well as pedestrian crossings. The unattended
potholes and various depressions lead to
flooding with every rainstorm.
6/8
DOT
Improve traffic and
We request a pedestrian crossing for the Ave. K
Ocean
pedestrian safety,
& Ocean Parkway intersection. As of now there
Parkway
including traffic
is no pedestrian crossing for 2/5th of a mile,
Avenue K
calming (Capital)
from Ave. J to Ave. L. It is a matter of public
safety to install a traffic light that allows
pedestrians for cross safely. A traffic light will
slow traffic on this stretch where cars routinely
speed up because there are no traffic calming
measures in place.
7/8
DPR
Reconstruct or
COL. MARCUS PARK - A comfort station in the
upgrade a park or
playground area is needed. Numerous children
amenity (i.e.
and adults must cross East 5th Street to go to
playground, outdoor
the other side of the park in order to use the
athletic field)
restrooms. This is a highly trafficked street. A
restroom, especially for the children using this
park, is essential to this playground.
8/8
DPR
Provide a new or
Rappaport Playground (53rd Street & Fort
Fort Hamilton
expanded park or
Hamilton Parkway) is the only roller hockey rink
Parkway
amenity (i.e.
left in Brooklyn and it's in dire need of a new
playground, outdoor
one, due to the use of rink. Also, the panels
athletic field)
surrounding the rink need to be replaced.
Expense Budget Requests
Priority Agency Request Explanation Location
image
1/25 DSNY Provide more
frequent garbage or recycling pick-up for schools and institutions
Provide daily garbage and recycling pick-up for Private Schools. CB 12 has about 80 private schools serving approximately 100,000 or more children. The District has 16 public schools which serves approximately a third of the total enrollment of the private schools. The student enrollment in some of the public schools has been dwindling rather than increasing. Most of these private schools have year round lunch programs with perishable foods. However, the private schools only receive two pickups per week while the public schools are picked up daily. The student enrollment in private schools far outnumber the enrollment in public schools in this district and because of the amount of garbage generated from these schools each day, daily pickups must be implemented.
image
2/25 NYPD Assign additional
traffic enforcement officers
TCAs (Traffic Control Agents): Our district is in dire need of Traffic Control Agents assigned to float to areas of concern throughout the critical areas in our District, as well as other alternative measures to decrease congestion. Currently, we have none. The areas of specific concern are: 18th Avenue from 45th Street to Ocean Parkway, 15th Avenue from 42nd Street to 45th Street, 14th Avenue from 49th Street to 42nd Street, 13th Avenue from 39th Street to 54th Streets, Avenues I and J from McDonald Avenue to Coney Island Avenue, Fort Hamilton Parkway from 36th Street to 46th Street . These are a few of the notoriously congested areas. The locations are subject to change based on seasonal and other variables. The traffic congestion and horn honking are severe especially during the AM and
image
3/25 HRA Other request for
services to support low-income New Yorkers
In our Capital requests we asked for an HRA service center in our district. Knowing that getting a new HRA Service Center in our district is a big ask, we are requesting that at least HRA send service professionals a few times a month to our office to service our residents, as they have done in the past. In FY2020 HRA responded to this same request (212202003E) saying the 'request has already been funded'.
Further communication with HRA clarified that funding is appropriated for training programs- which is not what we are asking. We currently have fully equipped office space that can be used by an HRA staffer who can service individually members of our district who may not have the ability to avail themselves to assistance now.
image
4/25 DOT Other expense
traffic improvements requests
NYC.gov states there are 150 HIQA inspectors. Their mission statement includes “increas(ing) the level of safety for both pedestrian and vehicle travel…” and “expedit(ing) the flow of traffic, for both pedestrian and vehicular traffic around the construction zones.” However, street permit stipulations are ignored more often than not, leading to chaos. It must therefore be necessary to increase the number of HIQA inspectors to ensure compliance. DOT often doesn’t send an inspector quick enough to be an effective remedy, more inspectors and thus quicker action will be immensely helpful. Many times HIQA will come hours later- after construction is complete. Further, an inspector should be permanently assigned to the CB12 area and coordinate with the board for effective permit compliance.
image
5/25 NYPD Provide additional
patrol cars and other vehicles
The 66th Precinct Community Affairs Unit’s unmarked vehicle is currently in bad shape and keeps breaking down. We are requesting a new unmarked vehicle dedicated to the Community Affairs Unit. Last year, the agency initial response to tracking 212202003C was that this has been or will be completed in 2019. The adopted budget stated that due fiscal constraints, the availability of funds is uncertain. This is a necessary item for the safety of our community.
image
image
6/25
DEP
Clean catch basins
All catch basins should be cleaned on a regularly
scheduled basis. Deteriorated catch basins
should be repaired or replaced as part of a
regular maintenance schedule. There has been
an increase in flooding complaints. DEP is under
a consent decree to alleviate combined sewer
overflow. One of the obvious ways to work
towards this is to make sure rainwater drains
properly through the catch basins. This does not
happen when the catch basins are clogged.
There were many areas of repeated
environmental concern- such as: 53rd St. from
11th Ave. to 13th Ave., 55th Street & 12th Ave.,
51st St. & 12th Ave. And while we are happy to
work with constituents in reporting this to DEP-
this is only after the symptoms of neglect
(flooding!) appear.
7/25
DSNY
Provide more
We are also requesting the mechanical sweeper
frequent garbage or
on the 12am to 8am midnight shift six days a
recycling pick-up
week be returned (it has been taken away on
7/1/2017 in the FY18 budget) this sweeper
effectively cleans the district. Our district
constantly rates low on the scorecard and this
should help maintain cleanliness throughout the
district.
8/25
DSNY
Increase
There has been a major increase of illegal
enforcement of
dumping. Especially along the LIRR freight line.
illegal dumping laws
Specific areas along the line are: 61st St.
between 11th and 12 Ave., 56th St between
15th and 16th Ave., and 55th St. between 16th
and 17th Ave. 49th St. between 18th Ave. and
19th Ave. (the deadend street) is a location that
is plagued by illegal dumping. Parkway.
Sanitation Police Officers should be assigned to
our district to catch violators and enforce
Sanitation laws. We need enforcement to work
closely with the Superintendent. The Super
should have input of target areas and get
continuous reports from Enforcement on their
progress.
9/25
DSNY
Other cleaning
We are requesting an increase from 5 broom
requests
routes to six broom routes on Monday, Tuesday,
Thursday and Friday.
10/25
DSNY
Other garbage
We are requesting the return of a permanent
collection and
cleaning officer to the district. Currently BK12
recycling requests
does not have a dedicated cleaning officer. Such
an officer would go a long way to remedy the
chronic littering in high litter areas.
11/25
DSNY
Other garbage
We request cameras mounted on Sanitation
collection and
Truck to ensure essential services are provided
recycling
properly. We also request photos attached to
infrastructure
sanitation violations when issued to residents.
requests (Expense)
12/25
DOT
Provide new traffic
Expand the Traffic Engineering Department to
or pedestrian
be able to conduct traffic studies more
signals
expeditiously.
13/25
DOT
Conduct traffic or
13th Ave. is the commercial shopping Mecca in
parking studies
CB12. People come from all over to shop here
due to its ethnic flavor. On any given day, more
than 10k people traverse this shopping strip.
Parking is at a premium. It can take an hour to
pass through the 23 blocks of this shopping
strip. 13 Ave. hasn’t been redesigned in over 21
years and is in dire need of a thorough
engineering study to determine the best
measures to ease the traffic and parking
congestion nightmare, especially during rush
hours. We request such a study to determine the
feasibility of certain ideas. For instance, the
possibility of adding an additional lane with
interchangeable direction depending on the
time of day or adding turning lanes and maybe
eliminating parking at certain times to increase
traffic flow.
14/25
DOT
Conduct traffic or
Traffic is very congested along 18th Ave.,
18th Avenue
parking studies
specifically from 45th Street to Ocean Parkway
45th Street
and especially during morning hours. 18th Ave.,
Ocean
an already major thoroughfare, intersects with
Parkway
McDonald Ave. where the F line subway station
is. This creates both vehicular and pedestrian
traffic. We are requesting a thorough
engineering study to determine the feasibility of
certain measures to alleviate the strain. For
instance, the possibility of adding an additional
lane with interchangeable direction depending
on the time of day (as is done at various
locations in other cities) or adding turning lanes.
15/25
DOT
Conduct traffic or
A complete traffic study on Avenue J from
Avenue J
parking studies
McDonald Avenue to Coney Island Avenue is
McDonald
needed as well, especially at the intersection of
Avenue
Avenue J and Bay Parkway where there is a
Coney Island
constant bottleneck. The streets aren't aligned
Avenue
so that sometimes drivers may find themselves
continuing into a non-existent lane. There is
severe congestion during both AM and PM rush
hours. It can take very long to travel this strip,
especially from the Bay Parkway intersection to
Ocean Parkway.
16/25
DOT
Conduct traffic or
A complete traffic study on Avenue I from
Avenue I
parking studies
McDonald Avenue to Coney Island Avenue is
McDonald
needed. There is severe congestion as well as
Avenue
horn honking during both AM and PM rush
Coney Island
Hours. It can take up to one hour during rush
Avenue
hours to travel this strip.
17/25
DYCD
Provide, expand, or
Adequate funding is needed for the Community
enhance the
based programs that are youth oriented. More
Summer Youth
funding should be allocated to the Summer
Employment
Youth Employment Program. Many youth,
Program
especially older teenagers, are denied
employment due to lack of funding. Summer
employment serves a dual purpose in both
occupying teenagers and teaching them
responsibility and accountability.
18/25
DPR
Enhance park safety
Funding is needed for Parks Personnel to lock all
through more
parks in our district after dusk. Elected officials
security staff (police
have contributed huge sums of money to
or parks
upgrade our parks into state-of-the-art facilities
enforcement)
that are pleasant outdoor spaces for children.
However, the lack of security attracts an
element to the parks that deters youth from
wholesome play. It's a shame to have the
capital expenditures go to waste due to security
concerns.
19/25
SBS
Other expense
Due to a large amount of residents in our
workforce
district that are neither college educated, nor
development
proficient in the English Language, investing in
requests
targeted vocational training in this district, with
an emphasis on high paying and emerging skills,
is a priority that would go a long way towards
raising the current low incomes so many
families here are experiencing. There are no
Work Force 1 (WF1) centers close enough to
service the district, therefore providing funding
to fill the gap is appropriate. Nor are there any
programs that are truly Yiddish compatible.
20/25 DPR Forestry services,
including street tree maintenance
PARKS advised that the funds to repair sidewalks damaged by trees was increased. However, this increased funding has not yet resulted in actual repairs. We request PARKS repair the sidewalks damaged by trees as they said they would. Some of these areas are extremely dangerous for pedestrians and have been waiting for repairs for a very long time. One such example is the damaged sidewalk on 12th Ave. off 55th street. It was damaged by a falling tree in July 2019and has not been repaired as of mid-October 2019, despite some reported slip and falls. The sidewalk is lifted several inches off the ground.
image
21/25 DOHMH Create or promote
programs to de- stigmatize mental health problems and encourage treatment
Under the leadership of the Mayor, NYC made it a priority to improve Mental Health. This effort hasn’t succeeded in reaching CB12 residents.
This is largely due to language barriers and the stigma associated with mental or emotional difference. Thus, many residents here are left undiagnosed & untreated. This often compounds the necessity of extreme and costly interventions. CBO’s within our district are uniquely qualified to understand the culture in this insular community and can work within the parameters of the unique differences inherent in the district. Funding is required for extensive awareness campaigns to eliminate the stigma preventing anyone from asking for such help.
This aims to prevent the most vulnerable from
falling prey to the opioid epidemic.
image
22/25 DCP Study land use and
zoning to better match current use or future neighborhood needs
One of the major issues plaguing the district is the lack of affordable housing. To that end, we request some long overdue studies of commercial areas in our district, specifically the commercial strip spanning 60th street, for the purposes of being rezoned for residential development with a major focus on affordable housing.
image
image
23/25
DOT
Other expense
Upgrade street signs and markings throughout
60th Street
traffic
the district as needed. Specifically, on 60th
and 13th Ave
improvements
Street and 13th Avenue showing northbound
requests
traffic must turn either left or right as traffic
flowing on 13th avenue southbound up to 60th
street is ONE-WAY. We have multiple vehicles a
day going the wrong way southbound from
60th street to 59th Street. Also, signage is
needed that cars travelling east and west on
60th Street cannot make turns onto 13th
Avenue going northbound. This was requested
for FY2020 (212202026E) but was denied by the
Borough Commissioner because of existing "Do
Not Enter" signs. But this problem persists and
can be easily remedied with a sign directed to
the drivers who mistakenly drive the wrong way.
24/25
DPR
Provide better park
Ocean Parkway is a main thoroughfare and is
maintenance
highly trafficked. In addition, Ocean Parkway is
a Special District. The beauty of Ocean Parkway
must not be allowed to deteriorate. Some of our
elected officials have designated monies for the
upgrade and beautification of the Malls.
Maintenance must be ongoing to make sure the
upgrades and beautification remains intact. In
order to maintain this arena in a sanitary and
groomed condition, a crew should be assigned
to maintain the malls of this thoroughfare and
prevent homeless people from sleeping on the
benches. An additional crew cab truck is
requested to transport them the length and
breathe of this roadway. The Malls and trees
must receive regular attention so that the
Parkway can be properly maintained.
25/25
DPR
Forestry services,
Although PARKS maintain a 7-year pruning
including street tree
cycle, oftentimes trees fall into disrepair before
maintenance
the 7 years are out. The incidents with falling
trees or branches has been rising in our district
due to delay in treatment of sick and dying
trees. We request additional resources to
provide for a safe timeframe to check on the
health of trees specifically to prevent them from
falling during severe weather conditions.
Additionally, the timeline for the replacement of
trees is very long. We request additional
resources to speed up the process.

