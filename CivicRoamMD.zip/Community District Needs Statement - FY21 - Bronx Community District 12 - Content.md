- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 12 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1GivePg8qaY2a2Lq-avbBaCWJ6E0MQJRR/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1GivePg8qaY2a2Lq-avbBaCWJ6E0MQJRR/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
12
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 12
image
Address: 4101 White Plains Road Phone: (718) 944-3300
Email: gtorres@cb.nyc.gov
Website: www.nyc.gov/bronxcb12
Chair: Dr. William Hall District Manager: George Torres
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
The greatest joy of serving our friends and neighbors at Community Board 12, The Bronx is that of meeting them and being able to assist them in a variety of ways. Whether it involves solving a difficulty arising between local residents, rectifying a problem relative to the delivery of government services, or just lending an open and understanding ear to one who is looking to be heard, it is a blessing to get to know people and have the opportunity to work on their behalf. These sentiments are shared, we know, by all who work at our Town Hall Headquarters.
Over our many years of service at Town Hall, we have strived to make local government effective and truly accessible to neighborhood citizens. The ongoing refurbishment and renovation of Town Hall and of our Carriage House, with the aid and the support of our elected officials, is a significant accomplishment in this regard. Important as well are our engagement in innumerable meetings, frequent telephone calls, and copious correspondence that cause the hours of a typical day at the Community Board to fly by so quickly. Our objective is to keep in touch with our community and to make them aware of how much we value hearing from them. Community Board 12 is composed of several distinct neighborhoods, each one unique and vibrant in its own way. Community Board 12 is an extremely diverse community welcoming both newly arrived Irish immigrants into Woodlawn and West Indian immigrants into Baychester. This rich diversity of cultures makes Community Board 12 a desirable community.
Baychester is located in the eastern part of the district, consists of low and flat land that used to be marshland and valleys. Its boundaries are East 222nd Street to the north, Pelham Parkway to the south and Bronxwood Avenue to the west. Eastchester Road is the main commercial thoroughfare. The local subway is the IRT Dyre Avenue number 5 line. Eastchester covers roughly half a square mile. Its boundaries are the Bronx-Westchester County border to the north, the New England thruway to the east, Baychester Avenue to the south, and the intersection of East 233 Street and Baychester Avenue to the west. Boston Road is the primary thoroughfare, and Dyre Avenue is the main commercial strip. The neighborhood includes an industrial district and one New York City Housing Authority development, Boston Sector Houses. It is also home to Seton Falls Park, known as the “Grand Canyon” of the Bronx. Situated on more than 30 acres of land, this nature preserve offers a respite from its urban surroundings with a waterside walking trail, a manmade waterfall, and a bird sanctuary. Also boasting several playgrounds, Seton Falls Park offers recreation options for the whole family. Edenwald is located north of Baychester, south of Wakefield, east of Bronxwood Avenue, and west of Boston Post Road. It is home to the 47th precinct of the New York City Police Department, and to two NYCHA public developments, Baychester Houses and Edenwald Houses. Fishbay is a small, quaint neighborhood which covers approximately one-fifth of a square mile, and has a population of just under 8,000. The community is bounded by Laconia Ave. to the west and Boston Road to the east. Haffen Park, at the intersection of Gunther and Burke Avenues, has frequently been praised as a “kid-friendly playground” and has a pool. Olinville is today considered part of the Williamsbridge neighborhood, and shares the 10467 zip code. It is situated west of White Plains Road between Allerton Avenue and Gun Hill Road, and is served by the IRT White Plains Road number 2 and 5 subway lines. Wakefield was once woods and farmland like the rest of the northern Bronx. The boundaries of the 1.3 square mile neighborhood are the Westchester County border at East 243rd Street the north, East 222nd Street to the south, and the Bronx River, the Bronx River Parkway and the Metro-North Railroad tracks to the west. Wakefield is home to a number of parks, the most popular of which is Shoelace Park, the northern section of Bronx Park. Shoelace Park hugs the banks of the Bronx River, and includes a kayak launch at East 219th Street. The neighborhood, is served by the IRT White Plains Road number 2 and 5 subway lines, MetroNorth's Harlem Line, and the BxM11 express bus line. White Plains Road is the main shopping district, popular for its many fresh produce markets and Spanish, West Indian, and East Indian specialty food shops. Williamsbridge is located in the northeast section of the Bronx, and covers roughly a mile and a half. Its boundaries are East 222 Street to the north, Boston Road to the east, East Gun Hill Road to the south, and the Bronx River to the west. White Plains Road is the primary thoroughfare of Williamsbridge. The local subways are the IRT White Plains Road number 2 and 5 lines, and MetroNorth's Harlem Line also provides service to the neighborhood. Woodlawn is at the very north end of the Bronx. Its boundaries are McLean Avenue to the north -- which is also the New York/Westchester County Line -- the Bronx River to the east, Woodlawn Cemetery to the south, and Van Cortlandt Park to the west.
The main commercial thoroughfare is Katonah Avenue, which runs north-south through the heart of Woodlawn, and is a popular destination for its many fine restaurants and specialty shops. Woodlawn Cemetery is known as the resting place of many of history’s greats and has been designated a National Historic Landmark.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 12
image
The three most pressing issues facing this Community Board are:
Parks
BxCB12 is requesting more resources for the Parks Department to deal with the many complaints we receive regarding trees. Our Parks can always be made better, but our request would direct monies to maintenance; specifically street tree maintenance. Our Community Board is besieged by phone calls from residents concerned about street trees. Our complaints range from requests for tree pruning to the removal of dead trees or branches that constituents worry will do them harm or their properties. It is our understanding after discussing many of our concerns with the Parks Department that they do not have the monies necessary to increase routine maintenance. It is our understanding that the tree pruning program is now done on a seven-year rotation. We would like that time frame shortened to a three-year rotation as it used to be many years ago. Additionally, we understand that there is no budget for stump removal. Tree stumps are only removed when a new tree is being planted in its place. The concern is that tree stumps can remain for several years before being addressed. Moreover, the Parks Department implemented a rating system used to assess the risk a dangerous tree poses to the public. Similarly, they also have a system to assess sidewalks damaged by tree roots. Both systems assign a rating and the Parks Department fixes the worst rated trees and sidewalks. The concern is that the program runs out of money before they can get to all the damaged trees or sidewalks. The request would be for the administration to adequately fund these programs to zero out the pool of damaged sidewalks and trees.
Quality of life issues (noise, graffiti, petty crime, etc.)
Like most communities our biggest complaints come in a variety of Quality of Life concerns aimed at neighbor to neighbor noise complaints, street cleaning, parking and public safety. Some of these issues we address by asking agencies for specific items like asking the NYPD to equip each patrol car with a sound meter to appropriately deal with noise complaints. It is our understanding that while the NYPD responds to these types of complaints enforcement is very rare since each precinct is only outfitted with one noise meter. Moreover, there is usually a limited number of officers that are trained properly to use it. Another concern regarding the NYPD is the enforcement of speeding. Our Board has a large number of requests before DOT for speed reducers called speed humps. It can take up to two years for DOT to study the request for a speed hump due to backlog of request. While speed humps are installed to slow vehicles down it is not a failsafe and we need more enforcement from the NYPD. The last issue we need more help on is the illegal truck parking on our streets. We understand parking can be a sensitive issue for many but we have tractor trailers parking on our residential streets. We work very closely with the Precinct to conduct tow efforts but the NYPD limits what they can do monthly. We need a coordinated and sustained effort to get these trucks off our streets. These trucks can be seen parked near our schools cutting off visibility when children are crossing the street. Additionally, many of these trucks are carrying municipal waste which poses other problems with the stench it creates attracting rodents and wildlife. We need the NYPD to invest Finally, another concern for BxCB12 is the cleanliness of our district but I will deal with that in our next bullet. in more heavy tow vehicles to deal with this ongoing problem.
Trash removal & cleanliness
The cleanliness of our commercial districts is a major Quality of Life concern for Community Board. Our commercial businesses on White Plains Road, Dyre Avenue, Boston Road, East 233rd Street, Webster Avenue and East Gun Hill Road must do a better job of keeping their sidewalks and streets clean. We have asked the Department of Sanitation to step up their enforcement efforts in addition to asking for more liter basket pick-ups. Our elected officials have been very helpful in trying to address our concerns. Assembly Member Carl Heastie is funding the Doe Fund to keep White Plains Road clean. We need more of these types of clean-up initiatives to keep these corridors clear of debris especially on the weekends.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 12
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
Our concern is not with services for the homeless but rather the siting of these facilities in communities like ours. The Department of Social Services (DHS/HRA) has not been forthright with our Board regarding these facilities. The current administration released Turning the Tide to address homelessness and a plan to site 90 new shelter facilities in a more equitable manner. We view this statement and goal as being at odds with itself. The Bloomberg administration, in an effort to curb homelessness, greatly expanded the Cluster Site program in the Bronx. In other boroughs there was a combination of using hotels as transient housing for homeless individuals. Our concern lies in the fact that this administration has not shared where these cluster sites are located. This administration has not been honest in their Turning the Tide Strategy. DHS uses two hotels in our district that are located in M1-1 zones.
They do not classify these sites as hotels and have moved to make them permanent signing multi-year contracts with the providers to provide services in a building that is a hotel against City Ordinances. This is similar in nature to moving most of the Cluster Site apartments into the "Master Lease Program" and then converting those buildings into permanent shelters without community notification or involvement. This strategy burdens communities already saddled with clusters sites. I use this terminology loosely to say this strategy also employs private 1-2 family homes in my district and converts them into illegal Single Room Occupancy housing using City monies to house homeless individuals. My Community Board was never given notification on the siting of these SRO's or where the cluster sites were located before turning them into permanent housing for homeless people. Turning the Tide is a disingenuous attempt to make it seem that this administration is dealing with homeless. This Board has always been willing to do it's Fair Share in housing our own constituents that have fallen on hard times but DSS does not paint that picture. It is truly unfortunate that the agency refuses to engage this Community Board in an honest conversation about its needs .
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/10
DHS
Other facilities for
Community Board 12 is asking for a moratorium
the homeless
on the siting of facilities in this area until we are
requests
notified about all the housing DSS/DHS/HRA
funds in this district through the Master Lease
Program, CityFHEPS and all future
considerations currently in the pipeline for
development.
10/10
HRA
Provide, expand, or
CB12 has served as a satellite facility for HRA's
4101 White
enhance food
outreach efforts on Food Stamps/SNAP. Every
Plains Road
assistance, such as
Tuesday and Wednesday CB12's offices become
Food Stamps / SNAP
a hub of activity of those seeking HRA's
assistance for Food Stamps/SNAP benefits. We
encourage an expansion of these services to five
days a week and that additional services are
offered like APS. In years past HRA has said that
further study was required of the agency. We
met with officials from HRA and thought we
were close to negotiating an expansion of
services at our office. Unfortunately, those
conversations ended with no change or
expansion to the current services. We would like
to know what happened.
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 12
image
M ost Important Issue Related to Youth, Education and Child Welfare
Youth workforce development and summer youth employment
Increased funding is needed for the SYEP program to meet the demand of the youth that apply for these jobs. Summer jobs are a primary and effective means in developing skills in our youth. We encourage DYCD and the City to find meaningful internships that take advantage of New York City's stature as the greatest City on Earth. The City is the media capital of the world in addition to Wall Street, high-end law firms and any number of unique small businesses. The City should partner with these firms to target all children that might not otherwise get a foot in the door.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
6/10 DYCD Provide, expand, or
enhance the Summer Youth Employment Program
Increase funding for SYEP and look to end the yearly budget dance. Base line the increases so that those participating in the program can build upon their programs to offer better outcomes and services for our youth. We should look to models used in other City's like Philadelphia and work with the private sector to offer more meaningful summer jobs to youth.
Use the SYEP program as the doorway to internships that would otherwise not be available to those of us that do not have someone advocating on their behalf. Offer multi-year placements so that our youth have an opportunity to grow with one particular employer. End the lottery system to make sure that once a youth enters the SYEP program they can stay in it. Incentivize the hiring of youth similar to what SBS does.
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 12
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
The City should develop a better response to noise complaints. The current situation where the NYPD responds to neighbor to neighbor complaints is nor sufficient. Summonses are rarely issued as I am told that precincts only have one noise meter. Constituents are frustrated that their complaints are responded to slowly and often without a lack of enforcement when there is evidence of loud noise. NYPD's gallant efforts to enforce noise complaints is a frustrating experience for them as the tools they have lack teeth. One suggestion might be to equip each patrol car with a sound meter but we are open to better strategies.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
5/10 NYPD Other NYPD
facilities and equipment requests (Expense)
Community Board 12 requests that the NYPD equip each patrol vehicle with a sound meter to better facitilate noise complaints. It is our understanding that usually there is only one sound meter assigned to each precinct.
Additionally it is often calibrated and cannot be used during this lengthy process. Finally, we understand that each officer should be trained to handle these meters to respond to 311 complaints.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 12
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
CB12 has two transit lines in addition to the Metro North. We have several commercial districts throughout the district. The cleanliness of the district or lack there of may be the number one issue. More services are required to keep high trafficked areas like White Plains Road clean and clear of debris.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
3/10 DSNY Increase enforcement of dirty sidewalk/dirty area/failure to clean area laws
Community Board 12 is asking for increased enforcement of our dirty streets and sidewalks especially around our commercial districts. We are asking for increased services from not for profits like the Doe Fund or FedCap that focus on litter pick up and waste basket patrol all wek long including weekends.
image
4/10 DSNY Provide more
frequent litter basket collection
Request for additional funding for more services like additional Mobile Liter Patrols and Basket Service pick-ups.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 12
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Commercial district revitalization
CB12 has several commercial districts with many vacant storefronts. Moreover, there is no diversification of the types of services in those storefronts that are occupied. Many of our retail establishments are of the food services type; restaurants or convenience stores. We would like to see more offerings from retailers.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
7/10 NYCHA Install security
cameras or make other safety upgrades (Expense)
Provide funding for cameras throughout Edenwald, Boston Secor, Baychester, NYCHA Developments in order to deter crime. Crime in our N.Y.C.H.A. Housing Developments persists as a major problem and concern. The installation of cameras has only partially taken place in some projects. A complete monitoring system must be installed in each of our N.Y.C.H.A. Developments for the safety of the tenants. It is our understanding that the monies for these projects were allocated. We would like a detailed explanation on when NYCHA plans on getting these cameras installed. The monies were allocated several budget cycles in the past. We want to ensure that these monies are not redirected to other projects.
TRANSPORTATION
Bronx Community Board 12
image
M ost Important Issue Related to Transportation and Mobility
Sidewalk and curb construction
There are many sidewalks and curbs that need to be fixed within the district. Unfortunately, this responsibility lies with the homeowner and may of my homeowners do not have the resources to fix this problem. Moreover, some of the sidewalks in need of repair are so because of the City's infrastructure. Trees and their roots have cause many sidewalks to buckle or become trip hazards. DOT is woefully underfunded in dealing with this issue. We would like to see the City add more money to DOT's budget to address this issue.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 12
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Forestry services, including street tree maintenance
The Parks Department needs to increase the frequency of street tree pruning efforts. We would like to see this increase from the current seven year cycle to a three year cycle.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
We would like to see the $42,500 distributed by the City Council to each Community Board citywide base lined in the budget so we could hire more staff to sustain our operations.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/2
DPR
Reconstruct or
Reconstruct or upgrade Shoelace Park and the
upgrade a park or
Bronx River Greenway. The Parks Department
amenity (i.e.
has a Master Plan for the reconstruction and
playground, outdoor
modernization of Shoelace Park. Many of the
athletic field)
playgrounds and facilities lie in the flood plane
of the Bronx River. CB12 is asking for a plan on
how best to implement the Master Plan.
Considering the project cannot begin unless it is
fully funded is it best to parcel the Master Plan
into more project ready phases.
2/2
DCAS
Renovate, upgrade
Community Board 12 is an incredible resource
4101 White
or provide new
to the community at large. We are fortunate to
Plains Road
community board
be a building that has an open space. For the
facilities and
last several years CB12 has poured money into
equipment
upgrading our technology and facilities. We still
require more funding to upgrade our windows
and lighting in the Carriage House. We are also
asking for DCAS to make the Carriage House a
Public Assembly space with the proper DOB
permits.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/10
OMB
Other community
Please increase funding for Community Boards.
board facilities and
We ask that the City baseline the City Council
staff requests
funding. We would go so far as to request that
the Boards budget be increased to $350,000 so
that Boards will have the adequate resources to
provide the Charter-mandated services to their
Districts.
8/10 DPR Other park maintenance and safety requests
Request: Provide Funding for cameras in Seton Falls Park, Shoelace Park and Haffen Park in order to deter crime. Explanation: Community Board 12 believes that installing cameras can act as a deterrent to crimes and provide evidence that could aid law enforcement officials in the prosecution of crime in these parks. The Board asks that the Department of Parks and Recreation purchase these cameras in order to address this significant public safety issue.
image
9/10 DPR Enhance park safety
through more security staff (police or parks enforcement)
Request: Provide Funding for Additional PEP Officers or Transfer money to the NYPD so that they take the roll of the PEP Officers in all NYC Parks. Explanation: Additional PEP officers are needed to patrol our parks and playgrounds. Vandalism has increased and there is a need for additional PEP officers to patrol the parks. It is inconceivable that year after year, park patrons in Community Board 12 have to endure numerous quality of life issues because existing PEP officers are not present. We request that the Department hire more officers in order to protect our parks and their patrons.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/2
DPR
Reconstruct or
Reconstruct or upgrade Shoelace Park and the
upgrade a park or
Bronx River Greenway. The Parks Department
amenity (i.e.
has a Master Plan for the reconstruction and
playground, outdoor
modernization of Shoelace Park. Many of the
athletic field)
playgrounds and facilities lie in the flood plane
of the Bronx River. CB12 is asking for a plan on
how best to implement the Master Plan.
Considering the project cannot begin unless it is
fully funded is it best to parcel the Master Plan
into more project ready phases.
2/2
DCAS
Renovate, upgrade
Community Board 12 is an incredible resource
4101 White
or provide new
to the community at large. We are fortunate to
Plains Road
community board
be a building that has an open space. For the
facilities and
last several years CB12 has poured money into
equipment
upgrading our technology and facilities. We still
require more funding to upgrade our windows
and lighting in the Carriage House. We are also
asking for DCAS to make the Carriage House a
Public Assembly space with the proper DOB
permits.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/10
DHS
Other facilities for
Community Board 12 is asking for a moratorium
the homeless
on the siting of facilities in this area until we are
requests
notified about all the housing DSS/DHS/HRA
funds in this district through the Master Lease
Program, CityFHEPS and all future
considerations currently in the pipeline for
development.
2/10
OMB
Other community
Please increase funding for Community Boards.
board facilities and
We ask that the City baseline the City Council
staff requests
funding. We would go so far as to request that
the Boards budget be increased to $350,000 so
that Boards will have the adequate resources to
provide the Charter-mandated services to their
Districts.
3/10
DSNY
Increase
Community Board 12 is asking for increased
enforcement of
enforcement of our dirty streets and sidewalks
dirty sidewalk/dirty
especially around our commercial districts. We
area/failure to clean
are asking for increased services from not for
area laws
profits like the Doe Fund or FedCap that focus
on litter pick up and waste basket patrol all wek
long including weekends.
4/10
DSNY
Provide more
Request for additional funding for more services
frequent litter
like additional Mobile Liter Patrols and Basket
basket collection
Service pick-ups.
5/10
NYPD
Other NYPD
Community Board 12 requests that the NYPD
facilities and
equip each patrol vehicle with a sound meter to
equipment requests
better facitilate noise complaints. It is our
(Expense)
understanding that usually there is only one
sound meter assigned to each precinct.
Additionally it is often calibrated and cannot be
used during this lengthy process. Finally, we
understand that each officer should be trained
to handle these meters to respond to 311
complaints.
6/10 DYCD Provide, expand, or
enhance the Summer Youth Employment Program
Increase funding for SYEP and look to end the yearly budget dance. Base line the increases so that those participating in the program can build upon their programs to offer better outcomes and services for our youth. We should look to models used in other City's like Philadelphia and work with the private sector to offer more meaningful summer jobs to youth.
Use the SYEP program as the doorway to internships that would otherwise not be available to those of us that do not have someone advocating on their behalf. Offer multi-year placements so that our youth have an opportunity to grow with one particular employer. End the lottery system to make sure that once a youth enters the SYEP program they can stay in it. Incentivize the hiring of youth similar to what SBS does.
image
7/10 NYCHA Install security
cameras or make other safety upgrades (Expense)
Provide funding for cameras throughout Edenwald, Boston Secor, Baychester, NYCHA Developments in order to deter crime. Crime in our N.Y.C.H.A. Housing Developments persists as a major problem and concern. The installation of cameras has only partially taken place in some projects. A complete monitoring system must be installed in each of our N.Y.C.H.A. Developments for the safety of the tenants. It is our understanding that the monies for these projects were allocated. We would like a detailed explanation on when NYCHA plans on getting these cameras installed. The monies were allocated several budget cycles in the past. We want to ensure that these monies are not redirected to other projects.
image
8/10 DPR Other park maintenance and safety requests
Request: Provide Funding for cameras in Seton Falls Park, Shoelace Park and Haffen Park in order to deter crime. Explanation: Community Board 12 believes that installing cameras can act as a deterrent to crimes and provide evidence that could aid law enforcement officials in the prosecution of crime in these parks. The Board asks that the Department of Parks and Recreation purchase these cameras in order to address this significant public safety issue.
image
image
9/10
DPR
Enhance park safety through more security staff (police or parks enforcement)
Request: Provide Funding for Additional PEP Officers or Transfer money to the NYPD so that they take the roll of the PEP Officers in all NYC Parks. Explanation: Additional PEP officers are needed to patrol our parks and playgrounds. Vandalism has increased and there is a need for additional PEP officers to patrol the parks. It is inconceivable that year after year, park patrons in Community Board 12 have to endure numerous quality of life issues because existing PEP officers are not present. We request that the Department hire more officers in order to protect our parks and their patrons.
10/10
HRA
Provide, expand, or enhance food assistance, such as Food Stamps / SNAP
CB12 has served as a satellite facility for HRA's outreach efforts on Food Stamps/SNAP. Every Tuesday and Wednesday CB12's offices become a hub of activity of those seeking HRA's assistance for Food Stamps/SNAP benefits. We encourage an expansion of these services to five days a week and that additional services are offered like APS. In years past HRA has said that further study was required of the agency. We met with officials from HRA and thought we were close to negotiating an expansion of services at our office. Unfortunately, those conversations ended with no change or expansion to the current services. We would like to know what happened.
4101 White Plains Road

