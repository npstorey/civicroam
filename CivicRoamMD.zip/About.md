Page Type:: [[About]]
# Civic Roam is a public knowledge graph of local civic data and documents about New York City.
This is the Beta version of Civic Roam - no guarantees are made about the accuracy or up-to-dateness of any content.
There are three domains associated with Civic Roam:
    1. The main domain, [civicroam.org](http://civicroam.org/), is hosted on [[Obsidian]] publish software, a static site generator that generate the website based on the pages from the [Civic Roam Research Graph](https://roamresearch.com/#/app/Civic/page/TKghSZzQ6). Load time on fastest here and the design is the cleanest. But there is no [[Advanced Search]].
    2. The [civic.roam.garden](https://civic.roam.garden/) domain is also based on the pages from the [Civic Roam Research Graph](https://roamresearch.com/#/app/Civic/page/TKghSZzQ6), but is generated from the [[roam.garden]] static site generator. Level 1 [[Advanced Search]] is available here, and load time is fast, but the design is a bit less polished.
    3. The [Civic Roam Research Graph](https://roamresearch.com/#/app/Civic/page/TKghSZzQ6) itself is the source content, hosted directly on the [[Roam Research]] software. Level 2 [[Advanced Search]] is available here, but design is bare bones, and load times are slower and may require significant memory to be allocated to your web browser to view.
Civic Roam is platform agnostic, but it was originally developed with the [[Roam Research]] software, so some functionality may work better in Roam.
You can [[Download]] the [entire database](https://github.com/npstorey/civicroam) in JSON or Markdown format for use in your own [[Roam Research]], [[Obsidian]], or other graph database software. All content on Civic Roam is believed to be in the public domain, and can be reused as such, but credit to this project is appreciated.
Civic Roam is a side project created by [Nathan Storey](http://www.nathanstorey.com/).
To get in touch email civicroam [at] gmail [dot] com, or follow [@npstorey](https://twitter.com/npstorey) and [@CivicRoam](https://twitter.com/civicroam) on Twitter.
https://twitter.com/npstorey/status/1366138680524570631
