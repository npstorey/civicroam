- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 1 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1Ldb8Z25JeAIFzQEemUkswzoFOGGxI1gY/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1Ldb8Z25JeAIFzQEemUkswzoFOGGxI1gY/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
1
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 1
image
Address: 3024 Third Avenue Phone: (718) 585-7117
Email: brxcb1@optonline.net
Website: www.nyc.gov/bronxcb1
Chair: Betty Bryant District Manager: Cedric Loftin
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board One is located in the southern portion of Bronx County. The boundaries of the district are the Harlem River; East 149th Street; Park Avenue; East 159th Street; East 161st Street; Prospect Avenue; East 149th Street and the East River. The neighborhoods served are Port Morris, Mott Haven and Melrose. The district has a 2010 population of 91,497 up from 82,159 in 2000. Land Use patterns are of single family and two family residential properties, institutional, mixed residential, commercial, office, and industrial uses. The general trend of the district is one of future population growth with mixed income residents.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 1
image
The three most pressing issues facing this Community Board are:
Affordable housing
There is a need for affordable housing to stop the ever increasing serious problem of homelessness causing the necessity of shelters in the district.
Health care services
Residents in the district must have the ability to access affordable and quality health care from infants to seniors. There is a need to create a healthy environment for our seniors to maintain their independence and if needed to have supportive services. For children and their families the delivery of effective health and medical care is paramount. Although programs by our community health institutions help to improve successful outcomes, their interacting and reaching out to the underserved, residents who are the undocumented population, means early screening services for those with underlying health conditions. Screening includes cervical, breast, prostate, and colon cancer. However a reduction in obesity must be addressed. There is a need and has been the goal of creating a sustainable community and economic redevelopment through the influx of manufacturing opportunities and new affordable housing projects in the district. Programs by the City in this regard include several large scale projects within the past five years, developments including St. Ann's mixed-use development, the Via Verde - a Green Way New York Legacy project bringing over, 1,000 new housing. Additionally, the upcoming La Central - 998 mixed project will begin construction in 2016. The Next Generation New York City Housing Authority (NYCHA) long term plan includes the development of new private multifamily housing on available land within NYCHA sites including the Mill Brook housing development in the District. Businesses in Port Morris including the operation of the Bronx Brewery, the construction of a warehouse facility by Fresh Direct providing an opportunity for employment for district residents. The expansion of Cup Studios via the conversion of an 115,000 square foot warehouse at 295 Locust Avenue in the district to be called Silver Cup North for film and television production in 2016 will additionally bring in local jobs.
Unemployment
Businesses in Port Morris including the operation of the Bronx Brewery, the construction of a warehouse facility by Fresh Direct providing an opportunity for employment for district residents. The expansion of Cup Studios via the conversion of an 115,000 square foot warehouse at 295 Locust Avenue in the district to be called Silver Cup North for film and television production in 2016 will additionally bring in local jobs.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 1
image
M ost Important Issue Related to Health Care and Human Services
Chronic diseases (diabetes, heart disease, etc.)
Add funding for Asthma treatment. Bronx Community Board 1 has been designated as part of the Asthma Corridor. Funding is also needed for Asthma Education and Case Management Assistance.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Add funds for AIDS education, teenage pregnancy and infant motality programs in Community District 1. More of these programs are needed to reach out to our Elementary and High School students as well as to the youth in our Community District.
Needs for Older NYs
Increase funds to expand the crime prevention program for senior citizens. There are not enough programs in CD 1. Maintain funding level for Senior Centers in Homecare, Housekeeping, Legal Services, Nutrition and Recreation.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
4/10
DOHMH
Other programs to
Add Funding for Asthma Treatment. Bronx
address public
Community District 1 has been designated as
health issues
part of the Asthma Corridor. The Municipal
requests
Hospital in our district. Lincoln Medical &
Mental Health Center, handles approximately
50,000 pediatric visits and 45,000 pediatric
emergency room visits, 5% of which are Asthma
related. Additional funding is needed for
Asthma Education and case management
assistance.
6/10
DOHMH
Provide more
Add funds for AIDS Education, Teenage
HIV/AIDS
Pregnancy and Infant Mortality Programs in CD
information and
1. More of these programs are needed to reach
services
out to our Elementary and High School students
as well as to the youth in our Community
District.
8/10
DOHMH
Other animal and
Increase funding for Pest Control in CD 1. These
pest control
are vacant lots infested with rodents and insects
requests
in CD 1. In order to provide adequate service,
funds are needed to purchase rodenticide and
warning posters.
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 1
image
M ost Important Issue Related to Youth, Education and Child Welfare
After school programs
Forty percent of our population is comprised of adolescents between the ages of 10-19 year old. There are a substantial amount of neighborhood requests for YDDP and after-school program funding in CD1. Increased funding will help provide efficient and effective services in District 1.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Fund Construction of a new STEM-Business K-12 School at 425 Grand Concourse, site of the former PS 31.
Needs for Youth and Child Welfare
Fund development of recreational programming in the District for youth Aging-Out foster care from 18 to 25.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
1/20
SCA
Renovate or
Funding for construction of new first floor
upgrade an
classroom flooring at PS25 located at 811 East
elementary school
149th Street. The first floor within PS25, the
Bilingual School has deteriorated to such a
degree that one classroom floor has buckled
and created an unsafe environment for children
seeking to learn daily. The Board would like to
see the immediate repair of this condition.
2/20
SCA
Renovate or
Funding for the placement of critical air
upgrade an
circulation and conditioning system in PS1
elementary school
located at 335 East 152nd Street, the Courtlandt
School. Community Board 1 is within the most
profound asthma corridor of our City. We voice
our concerns about the current conditions for
learning in all of our schools. However, in PS1
the air quality and circulation is extremely poor.
Its over heated conditions are not conducive for
learning and is having an adverse impact on the
learning environment for our children. We
advocate for the allocation of Capital funding
for construction of an air condition system
within the school.
18/20
SCA
Renovate or
Funding for the creation of a library/media
564 Jackson
upgrade an
room Where the children can do homework,
Avenue,
elementary school
study and learn. Funding for cameras at the
Bronx 10455
front entrance and School Safety Agents for the
protection of the children.
19/20
SCA
Renovate or
Funding for the painting of the entire school due
519 St. Ann's
upgrade an
chipped and peeling paint. Funding to repair
Avenue
elementary school
leakage within the 5th floor classrooms.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
3/10 ACS Provide, expand, or
enhance funding to support higher education and/or workforce development opportunities for youth who are leaving foster care
Fund development of recreational programming for Aging-Out youth 18 to 25 from foster care.
There is a need for additional resources and services to support activities for this population.
image
5/10 DYCD Other youth
workforce development requests
Fund youth employment during the school year. There is a high rate of unemployment among our youth population. Part-time jobs are needed for students during the winter and spring sessions while attending school.
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 1
image
M ost Important Issue Related to Public Safety and Emergency Services
Crime prevention programs
The lack of sufficient Police Officers to address the rise in crime.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Provide and assign more Police Officers to the 40th Police Precinct and to the Police Service Area 7 of the Housing Bureau as well as the Transit Police. Due to the proliferation of illegal gun possession and a rise in shootings and homicides in our streets and Housing Authority developments, there is a need for more police presence within the 10 sectors of the 40th Precinct.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
14/20 NYPD Renovate or
upgrade existing precinct houses
Retain the present use and operation of the 40th Police Precinct House. The use of the 40th Precinct for policing services is critical to the safety of residents in the District as a satellite to support crime fighting efforts by NYPD.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
2/10
NYPD
Assign additional
Provide and assign more Police Officers to the
uniformed officers
40th Police Precinct and to the Police Service
Area 7 of the Housing Bureau as well as the
Transit Police. Due to the proliferation of illegal
gun possession and rise in shootings and
homicides in our streets and Housing Authority
Developments, there is a need for more police
presence within the 10 sectors of the 40th
Precinct.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 1
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Sewer capacity
Due to an increase in volume and CSO overflow in the immediate area, there is an impact on the local housing stock including Diego Beekman Houses. There is a need for increased sewer capacity and an expansion of the sewer lines in the area.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Allocate Funds for Capital Sewer Work to be performed int he area located on Beekman Avenue, between East 141st Street & St. Ann's Avenue.
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 1
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Commercial district revitalization
Continue funding the Commercial Revitalization Program in CD 1. There are many commercial strips in the district in need of facade and storefront improvements.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
9/10 SBS Support development of local Storefront / Facade Improvement Program
Continue Funding the Commercial Revitalization Program in CD 1. There are many commercial strips in the district in need of facade and storefront improvements. (Previous Tracking Code: 101199410E)
TRANSPORTATION
Bronx Community Board 1
image
M ost Important Issue Related to Transportation and Mobility
Street lighting
Fund major improvements including additional lighting and scraping for the Bruckner Expressway underpasses at Brook, St. Ann's, Lincoln and Willis Avenues. These improvements are needed at these locations for the safety of the community.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Fund for the reconstruction fo the East 153rd Street Bridge. Previously at this location the past administration had approved a design for a cableless Bridge at East 153rd Street adn the money was taken out of the budget. Due to the increased population in Bronx Community Districts 1 and 1 there is a need for a new bridge to be built at this location.
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/20
DOT
Repair or provide
Upgrade illumination on existing street lighting
new street lights
in the District. Street lighting throughout the
entire District at night does not appear to be
providing the proper illumination to support
public safety. The Board requests for an upgrade
ad increase in foot-candles on the existing lamp
poles, including within all pedestrian
underpasses in the District.
4/20
DOT
Repair or provide
Fund major improvements including additional
new street lights
lighting at the Major Deegan underpasses at
Brook, St. Ann's, Lincoln and Willis Avenues.
There is a need for additional lighting at the
Major Deegan underpasses at Brook, St. Ann's,
Lincoln and Willis Avenues as it is dangerous for
residents that have to pass through these
locations due to inadequate lighting.
5/20
DOT
Repair or build new
Create a new step street. The development of a
St. Ann's
step streets
Step Street at East 159th Street and ST. Ann's
Avenue East
Avenue provides a connection for residents in
159th Street
the area above St. Ann's Avenue. This Step
St. Ann's
Street is one the Board has advanced over 15
Avenue
years and continues to support. It's
development provides for residents of major
developments such as St. Ann's Terrace, a
development of 350 units accessibility from this
portion of the District. It is important as it will
connect an area cutoff from direct walking and
connection to bus routes and other features
with the important housing corridor of the
District.
image
6/20 DOT Rehabilitate bridges The reconstruction of the East 153rd Street
Bridge. Previously at this location the past Administration had approved a design for a cable-less Bridge at East 153rd Street and the money was taken out of the budget. Due to increased population in Bronx County in Boards 1 and 4 there is a need for a new bridge to be built at this location. The increased density and strained traffic conditions in the District along 149th Street, the Grand Concourse and on to East 161st Street has created limited options for drivers. The East 153rd Street Bridge is presently in the projected Capital Plan. Our Board supports development of the East 153rd Street Bridge which can reduce congestion in our District.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 1
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
To have sufficient permanent staff so that the parks and playgrounds in the district are maintained year round for the use and enjoyment of the community. Also to add to the PEP staffing so that there will be a safe environment within the parks and playgrounds.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Funds for the design and construction of Garrison Playground on the Grand Concourse is a high priority. Funds for the renovation of PS 18 Playground. Fund Construction of a Soccer Field in St. Mary's Park. Develop an Ampitheatre in St. Mary's Park. Develop a Waterfront Public Access Park on a section of the Harlem River waterfront that.
Needs for Cultural Services
No comments
Needs for Library Services
The restoration of Expense Funding in the City's FY16 Budget to allow the New York Public Library to increase hours, programs, services, materials and staff throughout the system. Capital funding to upgrade the mechanical systems, bathrooms, roofs, facades and ADA in some of the Library locations and in others there is a need for complete renovation.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
7/20 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
Redevelopment of the Garrison Playground located at East 146th Street and Walton Avenue into a Science themed Playground. A component of the City's HPD RFP and selected redevelopment plan for 425 Grand Concourse is an allocation of Capital monies. Additionally, the Borough President's Capital Allocation for FY2017 includes $500,000 for the reconstruction of the adjacent Garrison Playground. The averse closure and subsequent demolition of the former PS31 in 2015 devastated the educational capacity in the District while also creating a serious void of passive and active recreation space. The theme and the importance of science will uplift and inspire young persons of the District while providing a 21st century recreational and learning experience.
image
8/20 DPR Other park programming requests
The Board is requesting the improvement and upgrade of the St. Mary's Dog Run. An expansion of the existing Dog Run is needed. Installation of the St. Mary's Dog Run six years ago has been successful and a positive addition for residents who own dogs of all breeds in the community. At this time there is need to modernize and expand the elements and features of the Dog Run to make it accessible and functional for dogs of all sizes. The Board is requesting funding to fully develop the aspects of the St. Mary's Park Dog Run including appropriate and separate runs for different dog sizes, heights, features, signage of rules and appropriate use, equipment, supplies to support the expansion and fencing. We also seek additional PEP Officers to provide enforcement of the rules.
image
9/20
DPR
Reconstruct or
Rehabilitation and improvement of Pulaski Park
Bruckner
upgrade a park or
at Bruckner Boulevard, between Willis Avenue
Boulevard
amenity (i.e.
and Brown Place. One of the southern Parks in
playground, outdoor
the District Pulaski Park serves a population
athletic field)
which includes the adjacent Bruckner by the
Bridge development of over 350 units of studios,
1 BR's, and 2 BR's. In 2016 community
engagement by the residents occurred with the
NYC Parks Department to create a "Friends of
Pulaski Park" for cleanup and painting of the
various recreational portions of the Park. Its
active spaces are in severe disrepair and not
conducive for use by area children and adults.
10/20
DPR
Provide a new or
Fund construction of a Soccer Field in St. Mary's
expanded park or
Park. Due to the increase of a population that
amenity (i.e.
plays soccer, there is a need for additional field
playground, outdoor
capacity for this sport.
athletic field)
11/20
DPR
Reconstruct or
Develop and Rehabilitate the P.S. 5 Pontiac
upgrade a park or
Park/School Yard. The current school yard,
amenity (i.e.
utilized by the elementary school students at
playground, outdoor
P.S. 5, is in need of renovation and
athletic field)
modernization. (Previous Tracking Code:
101200802C)
12/20
NYPL
Create a new, or
Allocate Funds for Partial Renovation
renovate or upgrade
Improvements of the Woodstock Library. The
an existing public
partial renovations to be undertaken at the
library
Woodstock Library are a new roof, new air
handling unit for the basement and
supplemental building requirements, third floor
renovation and exterior rehabilitation including
window replacement. (Previous Tracking Code:
101201607C)
13/20
NYPL
Create a new, or
Funds for Partial Renovation Improvements of
renovate or upgrade
the Mott Haven Public Library in the District.
an existing public
The partial renovations to be undertaken at the
library
Mott Haven Library are interior spaces,
electrical upgrade, new furniture and
equipment. Also to totally gut the entire cellar
except for the Boiler Room, Fuel Tank Room and
Elevator Machine Room and create individual
offices or work rooms of which one would be
the 600sf OST room. (Previous Tracking Code:
101201601C)
15/20
DPR
Provide a new, or
Develop an Amphitheater in St. Mary's Park.
St. Ann's
new expansion to, a
Seasonal concerts are given every year in St.
Avenue
building in a park
Mary's Park and many of them are sponsored
by the New York City's Parks Department.
However, the department has to utilize
equipment stages to hold these events.
Therefore, a permanent onsite non-removable
Amphitheater could be utilized throughout the
year for the Parks Department and outside
contracted events held by other entities.
(Previous Tracking Code: 101201604C)
16/20
DPR
Reconstruct or
Provide Funding for the Green Thumb Gardens
upgrade a park or
in the District. To provide all the gardens in CB1
amenity (i.e.
with on-site running water, electricity, modern
playground, outdoor
fencing as well as clean soil, lumber, and other
athletic field)
materials needed to operate a functioning
garden. (Previous Tracking No: 101201602C)
17/20
DPR
Provide a new or
Develop a Waterfront Public Access Park. The
expanded park or
development of a street and a public access
amenity (i.e.
waterfront park, on a section of the Harlem
playground, outdoor
River waterfront, will provide a constructive
athletic field)
development of this area for recreational and
waterborne transportation services. (Previous
Tracking Code: 101200801C)
20/20
NYPL
Create a new, or
Funding for projects ranging from major
renovate or upgrade
renovations to targeted upgrades, including
an existing public
heating and cooling system updates, new roof,
library
windows and doors, fire alarm, security and
technology upgrades, ADA compliance and
elevator replacement.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/10
NYPL
Extend library hours
Increase Funding for New York Public Library
or expand and
Services in the District. In order to provide the
enhance library
opportunity for district children and youth to
programs
fully participate in the New York Public library's
many services, funding for the Mott Haven and
Woodstock branches needs to be increased to
allow for all libraries to be open six days and at
least forty-two hours a week. The New York
Public Library and Community Board One
request that the City restore funding to provide
robust six day service including increased hours,
diverse programming, strong collections and
sufficient staff to support these functions. In
these challenging economic times, the services
provided through the Library are needed by
New Yorkers more than ever. (Previous Tracking
Codes: 101200801E)
7/10
DPR
Improve the
Continue funding 18 permanent staff at St.
quality/staffing of
Mary's Recreational Center. This newly
existing programs
renovated center requires permanent staffing to
offered in parks or
maintain and provide services to our youth as
recreational centers
well as our adult population.
10/10
NYPL
Extend library hours
Increase funding for libraries to expand to 7-day
or expand and
service. Only 15 of the city's libraries are open 7-
enhance library
days a week the increased funding would
programs
ensure that at least one branch in every Council
District is open for 7-days. This is particularly
important when more people rely on library
services from early literacy to ESOL classes for
immigrants and story time for homeless
families.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/20
SCA
Renovate or
Funding for construction of new first floor
upgrade an
classroom flooring at PS25 located at 811 East
elementary school
149th Street. The first floor within PS25, the
Bilingual School has deteriorated to such a
degree that one classroom floor has buckled
and created an unsafe environment for children
seeking to learn daily. The Board would like to
see the immediate repair of this condition.
2/20
SCA
Renovate or
Funding for the placement of critical air
upgrade an
circulation and conditioning system in PS1
elementary school
located at 335 East 152nd Street, the Courtlandt
School. Community Board 1 is within the most
profound asthma corridor of our City. We voice
our concerns about the current conditions for
learning in all of our schools. However, in PS1
the air quality and circulation is extremely poor.
Its over heated conditions are not conducive for
learning and is having an adverse impact on the
learning environment for our children. We
advocate for the allocation of Capital funding
for construction of an air condition system
within the school.
3/20
DOT
Repair or provide
Upgrade illumination on existing street lighting
new street lights
in the District. Street lighting throughout the
entire District at night does not appear to be
providing the proper illumination to support
public safety. The Board requests for an upgrade
ad increase in foot-candles on the existing lamp
poles, including within all pedestrian
underpasses in the District.
4/20
DOT
Repair or provide
Fund major improvements including additional
new street lights
lighting at the Major Deegan underpasses at
Brook, St. Ann's, Lincoln and Willis Avenues.
There is a need for additional lighting at the
Major Deegan underpasses at Brook, St. Ann's,
Lincoln and Willis Avenues as it is dangerous for
residents that have to pass through these
locations due to inadequate lighting.
5/20
DOT
Repair or build new
Create a new step street. The development of a
St. Ann's
step streets
Step Street at East 159th Street and ST. Ann's
Avenue East
Avenue provides a connection for residents in
159th Street
the area above St. Ann's Avenue. This Step
St. Ann's
Street is one the Board has advanced over 15
Avenue
years and continues to support. It's
development provides for residents of major
developments such as St. Ann's Terrace, a
development of 350 units accessibility from this
portion of the District. It is important as it will
connect an area cutoff from direct walking and
connection to bus routes and other features
with the important housing corridor of the
District.
6/20
DOT
Rehabilitate bridges
The reconstruction of the East 153rd Street
Bridge. Previously at this location the past
Administration had approved a design for a
cable-less Bridge at East 153rd Street and the
money was taken out of the budget. Due to
increased population in Bronx County in Boards
1 and 4 there is a need for a new bridge to be
built at this location. The increased density and
strained traffic conditions in the District along
149th Street, the Grand Concourse and on to
East 161st Street has created limited options for
drivers. The East 153rd Street Bridge is presently
in the projected Capital Plan. Our Board
supports development of the East 153rd Street
Bridge which can reduce congestion in our
District.
7/20
DPR
Reconstruct or
Redevelopment of the Garrison Playground
upgrade a park or
located at East 146th Street and Walton Avenue
amenity (i.e.
into a Science themed Playground. A component
playground, outdoor
of the City's HPD RFP and selected
athletic field)
redevelopment plan for 425 Grand Concourse is
an allocation of Capital monies. Additionally,
the Borough President's Capital Allocation for
FY2017 includes $500,000 for the reconstruction
of the adjacent Garrison Playground. The averse
closure and subsequent demolition of the
former PS31 in 2015 devastated the educational
capacity in the District while also creating a
serious void of passive and active recreation
space. The theme and the importance of science
will uplift and inspire young persons of the
District while providing a 21st century
recreational and learning experience.
8/20
DPR
Other park programming requests
The Board is requesting the improvement and upgrade of the St. Mary's Dog Run. An expansion of the existing Dog Run is needed. Installation of the St. Mary's Dog Run six years ago has been successful and a positive addition for residents who own dogs of all breeds in the community. At this time there is need to modernize and expand the elements and features of the Dog Run to make it accessible and functional for dogs of all sizes. The Board is requesting funding to fully develop the aspects of the St. Mary's Park Dog Run including appropriate and separate runs for different dog sizes, heights, features, signage of rules and appropriate use, equipment, supplies to support the expansion and fencing. We also seek additional PEP Officers to provide enforcement of the rules.
9/20
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Rehabilitation and improvement of Pulaski Park at Bruckner Boulevard, between Willis Avenue and Brown Place. One of the southern Parks in the District Pulaski Park serves a population which includes the adjacent Bruckner by the Bridge development of over 350 units of studios, 1 BR's, and 2 BR's. In 2016 community engagement by the residents occurred with the NYC Parks Department to create a "Friends of Pulaski Park" for cleanup and painting of the various recreational portions of the Park. Its active spaces are in severe disrepair and not conducive for use by area children and adults.
Bruckner Boulevard
10/20
DPR
Provide a new or expanded park or amenity (i.e. playground, outdoor athletic field)
Fund construction of a Soccer Field in St. Mary's Park. Due to the increase of a population that plays soccer, there is a need for additional field capacity for this sport.
11/20
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Develop and Rehabilitate the P.S. 5 Pontiac Park/School Yard. The current school yard, utilized by the elementary school students at
P.S. 5, is in need of renovation and modernization. (Previous Tracking Code: 101200802C)
12/20
NYPL
Create a new, or
Allocate Funds for Partial Renovation
renovate or upgrade
Improvements of the Woodstock Library. The
an existing public
partial renovations to be undertaken at the
library
Woodstock Library are a new roof, new air
handling unit for the basement and
supplemental building requirements, third floor
renovation and exterior rehabilitation including
window replacement. (Previous Tracking Code:
101201607C)
13/20
NYPL
Create a new, or
Funds for Partial Renovation Improvements of
renovate or upgrade
the Mott Haven Public Library in the District.
an existing public
The partial renovations to be undertaken at the
library
Mott Haven Library are interior spaces,
electrical upgrade, new furniture and
equipment. Also to totally gut the entire cellar
except for the Boiler Room, Fuel Tank Room and
Elevator Machine Room and create individual
offices or work rooms of which one would be
the 600sf OST room. (Previous Tracking Code:
101201601C)
14/20
NYPD
Renovate or
Retain the present use and operation of the
upgrade existing
40th Police Precinct House. The use of the 40th
precinct houses
Precinct for policing services is critical to the
safety of residents in the District as a satellite to
support crime fighting efforts by NYPD.
15/20
DPR
Provide a new, or
Develop an Amphitheater in St. Mary's Park.
St. Ann's
new expansion to, a
Seasonal concerts are given every year in St.
Avenue
building in a park
Mary's Park and many of them are sponsored
by the New York City's Parks Department.
However, the department has to utilize
equipment stages to hold these events.
Therefore, a permanent onsite non-removable
Amphitheater could be utilized throughout the
year for the Parks Department and outside
contracted events held by other entities.
(Previous Tracking Code: 101201604C)
16/20
DPR
Reconstruct or
Provide Funding for the Green Thumb Gardens
upgrade a park or
in the District. To provide all the gardens in CB1
amenity (i.e.
with on-site running water, electricity, modern
playground, outdoor
fencing as well as clean soil, lumber, and other
athletic field)
materials needed to operate a functioning
garden. (Previous Tracking No: 101201602C)
17/20
DPR
Provide a new or expanded park or amenity (i.e. playground, outdoor athletic field)
Develop a Waterfront Public Access Park. The development of a street and a public access waterfront park, on a section of the Harlem River waterfront, will provide a constructive development of this area for recreational and waterborne transportation services. (Previous Tracking Code: 101200801C)
18/20
SCA
Renovate or upgrade an elementary school
Funding for the creation of a library/media room Where the children can do homework, study and learn. Funding for cameras at the front entrance and School Safety Agents for the protection of the children.
564 Jackson Avenue, Bronx 10455
19/20
SCA
Renovate or upgrade an elementary school
Funding for the painting of the entire school due chipped and peeling paint. Funding to repair leakage within the 5th floor classrooms.
519 St. Ann's Avenue
20/20
NYPL
Create a new, or renovate or upgrade an existing public library
Funding for projects ranging from major renovations to targeted upgrades, including heating and cooling system updates, new roof, windows and doors, fire alarm, security and technology upgrades, ADA compliance and elevator replacement.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/10
NYPL
Extend library hours
Increase Funding for New York Public Library
or expand and
Services in the District. In order to provide the
enhance library
opportunity for district children and youth to
programs
fully participate in the New York Public library's
many services, funding for the Mott Haven and
Woodstock branches needs to be increased to
allow for all libraries to be open six days and at
least forty-two hours a week. The New York
Public Library and Community Board One
request that the City restore funding to provide
robust six day service including increased hours,
diverse programming, strong collections and
sufficient staff to support these functions. In
these challenging economic times, the services
provided through the Library are needed by
New Yorkers more than ever. (Previous Tracking
Codes: 101200801E)
2/10
NYPD
Assign additional
Provide and assign more Police Officers to the
uniformed officers
40th Police Precinct and to the Police Service
Area 7 of the Housing Bureau as well as the
Transit Police. Due to the proliferation of illegal
gun possession and rise in shootings and
homicides in our streets and Housing Authority
Developments, there is a need for more police
presence within the 10 sectors of the 40th
Precinct.
3/10
ACS
Provide, expand, or
Fund development of recreational programming
enhance funding to
for Aging-Out youth 18 to 25 from foster care.
support higher
There is a need for additional resources and
education and/or
services to support activities for this population.
workforce
development
opportunities for
youth who are
leaving foster care
4/10
DOHMH
Other programs to
Add Funding for Asthma Treatment. Bronx
address public
Community District 1 has been designated as
health issues
part of the Asthma Corridor. The Municipal
requests
Hospital in our district. Lincoln Medical &
Mental Health Center, handles approximately
50,000 pediatric visits and 45,000 pediatric
emergency room visits, 5% of which are Asthma
related. Additional funding is needed for
Asthma Education and case management
assistance.
5/10
DYCD
Other youth
Fund youth employment during the school year.
workforce
There is a high rate of unemployment among
development
our youth population. Part-time jobs are needed
requests
for students during the winter and spring
sessions while attending school.
6/10
DOHMH
Provide more
Add funds for AIDS Education, Teenage
HIV/AIDS
Pregnancy and Infant Mortality Programs in CD
information and
1. More of these programs are needed to reach
services
out to our Elementary and High School students
as well as to the youth in our Community
District.
7/10
DPR
Improve the
Continue funding 18 permanent staff at St.
quality/staffing of
Mary's Recreational Center. This newly
existing programs
renovated center requires permanent staffing to
offered in parks or
maintain and provide services to our youth as
recreational centers
well as our adult population.
8/10
DOHMH
Other animal and
Increase funding for Pest Control in CD 1. These
pest control
are vacant lots infested with rodents and insects
requests
in CD 1. In order to provide adequate service,
funds are needed to purchase rodenticide and
warning posters.
9/10
SBS
Support
Continue Funding the Commercial Revitalization
development of
Program in CD 1. There are many commercial
local Storefront /
strips in the district in need of facade and
Facade
storefront improvements. (Previous Tracking
Improvement
Code: 101199410E)
Program
10/10
NYPL
Extend library hours
Increase funding for libraries to expand to 7-day
or expand and
service. Only 15 of the city's libraries are open 7-
enhance library
days a week the increased funding would
programs
ensure that at least one branch in every Council
District is open for 7-days. This is particularly
important when more people rely on library
services from early literacy to ESOL classes for
immigrants and story time for homeless
families.

