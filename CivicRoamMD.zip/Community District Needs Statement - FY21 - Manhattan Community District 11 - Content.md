- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 11 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1amkVDGjab3cmrQ5DjwZEKEKU8PuYL-K-/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1amkVDGjab3cmrQ5DjwZEKEKU8PuYL-K-/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
11
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 11
image
Address: 1664 Park Avenue Phone: (212) 831-8929
Email: mn11@cb.nyc.gov
Website: www.cb11m.org
Chair: Nilsa Orama District Manager: Angel Mescain
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Current residents frequently express concerns about gentrification and the loss of affordable housing, as well as the loss of the local culture. The preservation of existing affordable and public housing, as well as the construction of new, deeply affordable housing, including opportunities for affordable homeownership, is incredibly important to ensure that current residents are able to continue to live in East Harlem even as new residents move in. Anti-tenant harassment, code enforcement, and rent burden alleviation programs should all be key pieces of the anti- displacement programs that are initiated in East Harlem. Senior citizens, many of whom are on fixed incomes, are especially in need of permanently affordable housing so that they can age in place.
According to the 2013-17 American Community Survey, the median household income in East Harlem is $37,470 which is significantly lower than the median NYC median household income of $62,040--and less than half of the median household income in Manhattan--$86,693. Of the 102,991 residents age 16 and older in East Harlem, 11.2% are unemployed and 44.3% are not in the labor force. Nearly 37.1% of family incomes are below the Federal poverty line, the percentages are even higher for youth and seniors (46.5% and 33.8% respectively); one-third (31%) receive food stamps. These statistics show a community that is in need of quality education and local hiring initiatives to increase economic development and employment. Programs to help residents become self-sufficient, rather than dependent on government assistance, will make East Harlem a more prosperous and vibrant community.
The City must also focus attention and funding on improving the quality of life in East Harlem. Existing green spaces should be improved and accessible to all. Health programs and initiatives to encourage healthy eating, exercise and balanced mental health should be affordable and available without stigma. Quality schools and early childhood education are keys to lifting young people out of poverty. Affordable and convenient adult education programs are equally important to help adults adapt to changes in industries and job opportunities. Reducing crime, especially around NYCHA developments and other more volatile areas of the district ensures that residents feel safe to go around the neighborhood. The recent initiatives around 125th Street and Park Avenue to provide outreach services to the homeless, mentally ill and those living with drug addictions have been very beneficial and should continue to be funded and expanded to serve other vulnerable areas within East Harlem.
East Harlem carries more than its fair share of treatment centers, support facilities, and homeless shelters. The concentration of such facilities in our community has created challenges to the quality of life of our residents and the viability of commercial establishments along corridors such as 125th Street, Third Avenue and Second Avenue. The City must prioritize the deconcentration of these uses in our community and endeavor to abide by the Fair Share Criteria “with due regard for the social and economic impacts of such facilities upon the areas surrounding the sites”.
Transportation within and through East Harlem also needs to be improved. The Second Avenue Subway work north of 96th Street needs to commence as soon as possible, as the community is only served by the severely overcrowded Lexington Avenue line. Buses are frequently delayed due to the congestion in Midtown, especially near the Queensboro Bridge, which leaves many senior citizens and others without reliable transportation. It is important to promote walkability by addressing lighting, safety, and streetscape design, and organization traffic pattern scheduling especially under the Park Avenue viaduct, as well as biking, to decrease traffic congestion and promote exercise.
Overall, the health and vitality of East Harlem is improving, but it is still far from the averages for other Manhattan and New York City neighborhoods. Given the pressures on current infrastructure and systems inherent with an increase in population, it is imperative that the City take this time to carefully invest in the community. By meeting the budget priorities and policy recommendations laid out in this document, city agencies can improve conditions for the existing residents while ensuring that the community is prepared for future changes.
The concentration of substance abuse services and homeless shelters in East Harlem continues to place an undue burden on our community, particularly along the East 125th Street, Lexington Avenue and Third Avenue commercial corridors. Despite repeated attempts to find relief, we continue to see an increase in treatment services and shelter
beds. At the same time, it is evident that the population of street homeless individuals has increased as have the number of individuals actively using drugs in our local parks and playgrounds. Over the past year, there has been a steady uptick in the number of reports of discarded hypodermic needles being discarded in local parks, on local streets and on the grounds of our public housing campuses.
Gun violence has continued to be an issue with upticks in youth involved shootings throughout the summer months of 2019. The effectiveness of anti-violence efforts such as violence interrupter programs appears to be hamstrung by persistent underfunding. The Police Department has suggested that efforts to combat youth and gang-related violence must be funded to contain a dedicated and thorough social media observation component.
The City must prioritize the completion of its East Harlem Rezoning Points of Agreements commitments including the development of affordable housing on publicly owned sites including the East Harlem Multi-Service Center, the NYPD 25th Precinct parking lot, and the Department of Sanitation’s Lot Cleaning Unit parking lot. Additionally, if the City determines that development at the site of the Urban Assembly School complex is not feasible, it must work with the community board to identify an alternative site or sites with equal development potential. The siting, funding, and development of a new consolidated M11 garage is also a high priority for our board as is the development of affordable housing on the site that M11 garage currently occupies on 99th Street.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 11
image
The three most pressing issues facing this Community Board are:
Affordable housing
As the cost of housing continues to rise throughout New York City, the residents of neighborhoods such as East Harlem face an ever-increasing rent burden (28.4% of East Harlem households spend 30% or more of their income on rent) and the threat of displacement. With new market-rate residential developments rising with increased regularly in our community, rents have risen to levels outside the reach of our existing residents. Those residing in rent-regulated affordable housing are often faced with deteriorating housing conditions left unaddressed by unscrupulous landlords seeking to displace them in order to deregulate those units and charge market rates. Public housing, an affordable housing lifeline for so many East Harlemites continues to suffer from neglect and lack of necessary repairs. As a result, the quality and quantity of existing affordable housing in our community continues to be negatively impacted. Mayor De Blasio's Housing New York plan, which aims to build or preserve hundreds of thousands of affordable housing units throughout our city, holds the promise of delivering a significant number of new or newly rehabilitated affordable units to our neighborhood. While we have been pleased that the definition of affordable has begun to take into account and better reflect local neighborhood median incomes, there is much more to be done in that regard as it is those earning the lowest incomes that are at most risk of displacement. We expect that any residential development on property wholly publically-owned will be 100% affordable and contain a representative percentage of units for those households earning 30% of area median income. Similarly, any developments including any publically owned property must include affordable units that prioritize reflecting our local neighborhood median income. Developers of any residential properties must work with the community board and local stakeholders to thoroughly market the availability of all residential units in their project.
Land use trends (zoning, development, neighborhood preservation, etc.)
Our neighborhood has seen change throughout its history but it has always maintained its working-class identity and culture. This is no less true today when so many not only identify with their community and home but demand that it be preserved for future generations. Unguarded neighborhood change brought on by rapid redevelopment and displacement threatens to undermine neighborhood character and the communities’ sense of place. The people of the community determine its character and uniqueness but these aspects of a community can be stripped away if careful thought is not given to how change is planned for. We are proud to be East Harlem and we wish to maintain the existing character of our community. Thus we demand that the City and any new neighbors work to understand who we are, how we live, and what is unique and important about the people of East Harlem and become stakeholders with us in preserving this beloved community. Preservation includes affordable housing, food, and entertainment as well as the built form and our treasured community landmarks, parks, building, houses of worship, and institutions, etc.
Unemployment
As our national economy continues to evolve, it creates challenges for those currently lacking the education (27.3% of East Harlem residents age 25 and over have earned a bachelor’s degree), training and/or experience to compete in our ever-changing job market. This is particularly true in communities like ours where educational achievement and access to training and employment opportunities can often be a challenge. Reported unemployment in East Harlem is 8.89% compared to 6.44% citywide. Too often available employment opportunities are entry-level in the service sector. The City must prioritize enhancing job training opportunities in East Harlem which target living wages, career paths and the evolving job market. We look forward to the new satellite Workforce I Center in East Harlem but the City must also partner with local schools and workforce development organizations to help set our local youth on training and career paths that will help them be more competitive in the job market.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 11
image
M ost Important Issue Related to Health Care and Human Services
Mental health and substance abuse treatment and prevention programs
East Harlem suffers from an extremely high rate of assault-related hospitalizations, alcohol/drug-related hospitalizations, as well as psychiatric hospitalizations. According to the 2015 Community Health Profile from the Department of Health & Mental Hygiene, Manhattan Community District 11 ranks third in the city for alcohol- related hospitalizations; second for drug-related hospitalizations; and first for psychiatric hospitalizations with 2,016 incidents in the past year. According to the 2018 Community Health Profile, the rate of adult psychiatric hospitalization in East Harlem is nearly triple the citywide rate. According to the Center for Comprehensive Health Practice (CCHP), the opioid overdose death rate among East Harlem residents is 50% higher than the citywide average. The rampant drug activity continues to thrive on the corner of 125th & Lexington Avenue. According to the Department of Health (DOH), the nation's opioid epidemic has increased the number of acute Hepatitis C infections in the United States (U.S.) in 2018. Approximately 30% to 70% of people who inject drugs run the risk of being infected with Hepatitis C. There is a relationship between the opioid crisis and the rise in Hepatitis C cases. It is imperative that services for this needy population are improved to decrease the hospitalization rate and ensure that people in need are getting the appropriate treatment. However, any new mental health, alcohol or drug treatment facilities need to be sited in careful consultation with the community and the Community Board, as East Harlem already has more than its “fair share” of facilities. East Harlem should serve as a priority neighborhood for the rollout of Thrive NYC initiatives such as Mental Health First Aid Training, NYC Mental Health Corps and Youth Mental Health First Aid.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Many current programs should be expanded to ensure they are reaching as many East Harlem residents as possible. Federal initiatives to expand health care to the uninsured must be supported locally through the equitable distribution of health insurance navigator programs to reduce the high number of uninsured residents. Local, State and Federal officials must increase Medicaid reimbursement rates so local hospitals that serve low-income residents don’t suffer financially. DOHMH and the NYC Health and Hospitals should work to promote greater use of primary care physicians and expand the availability of urgent care programs to reduce the strain on local emergency rooms and decrease the number of avoidable hospital visits. The East and Central Harlem Health Insurance Assistance Demonstration Project assists NYCHA residents with insurance navigation and health services follow-up in order to increase the number of persons enrolled in insured health plans. This project is currently in four developments in East Harlem and should be expanded to serve all NYCHA residents. Additional funding should be targeted to expand existing community-based peer-led interventions to promote weight loss and prevent diabetes, which have already produced effective results.
DOE should devote more resources to develop physical education programs for all local schools and expand organized athletics. HPD and NYCHA should host a series of workshops to educate tenants and landlords on the various indoor triggers for asthma and how they can be mitigated, including pest control. Funding should be immediately increased for pest extermination and mold remediation services throughout NYCHA developments. Secondhand smoke is also another asthma trigger. Funding should be allocated towards education and awareness for children and families suffering from the symptoms of the disease. Two large grocery stores have closed in the neighborhood within the past year, and for residents, especially those above 125th Street, it can be a struggle to find healthy and affordable food options. In order to improve the local food system, support and capacity building should be provided for existing farmers’ markets and food boxes, especially so that they are convenient and
affordable to those with lower incomes. A new full-service grocery store should be encouraged as part of new developments, especially in the northern portion of the district. Mental health is also a large concern within the community, and East Harlem should be among the first neighborhoods to receive programming and assistance via the ThriveNYC initiative.
Needs for Older NYs
East Harlem seniors need a safe and secure environment in which to live, including quality affordable housing or assisted living options and reliable health care. Many of the seniors are low-income, and they are forced to choose between spending money on needed medications, food or housing, Seniors also face high rates of social isolation, and have many concerns about safety in the community, which compounds the isolation issue. The lack of housing that is affordable to fixed/low-income seniors is very concerning as many seniors wish to age in place in their community.
There are an estimated 15,643 residents of East Harlem over the age of 65 or 12.45% of the community’s population. East Harlem seniors suffer from greater mobility impairment and higher rates of poverty than seniors in NYC as a whole (ACS 2013-2017). In East Harlem, almost 32 percent of seniors are mobility-impaired as compared to
26.5 percent citywide, and 30.6 percent of local seniors live below the poverty line compared to 16 percent city- wide. Senior facilities and programs need to be accessible to those with mobility concerns and low-incomes so that the neediest populations can be served. An additional challenge for East Harlem’s seniors is that they must often contend with the needs of dependents. 44.5 percent of grandparents in East Harlem are responsible for raising their grandchildren, which adds strain to already limited financial resources and can weaken seniors’ health. Programs and facilities for seniors should include child-care or youth programming options as well in order to serve the entire family. It is well- known that HIV/AIDS is a pervasive issue in East Harlem, but senior citizens are an overlooked population when it comes to addressing the HIV/AIDS epidemic. 1 in every 6 new HIV diagnoses in the United States occurs in a person over the age of 50. Furthermore, data from the New York State Department of Health HIV/AIDS Surveillance Program show that people 60 and older had the highest rate of any age group for concurrent new HIV/AIDS diagnoses in New York City in 2013. This indicates that senior citizens are not getting tested early enough for HIV. East Harlem has a very high death rate from HIV/AIDS, and more targeted interventions and campaigns are needed to address this issue. Senior centers and assisted care facilities should be educating their residents about safe sexual practices to reduce the risk of infection.
Needs for Homeless
Resident quality of life is impacted by the disproportionate amount of special needs facilities that are sited in East Harlem. While there are social needs within the community that many of these providers address, many of their clients come from outside the district and loiter at major intersections like 125th Street and Lexington Avenue. All City agencies must consider “Fair Share” requirements when choosing where to site facilities to ensure communities are not unfairly burdened by facilities that impact quality of life. As such, no additional chemical dependency facilities or homeless shelters should be sited or expanded in East Harlem without the approval of Community Board 11.
Citywide, more low-income and supportive housing should be constructed for the homeless population. In any Mandatory Inclusionary Housing zoning changes and NYCHA infill projects, a percentage of units should be set aside for those currently in the shelter population. The federal, state and city governments should provide tax credits and other incentives to encourage developers to allocate units to lower-income, homeless populations. The East Harlem Neighborhood Plan process found that there were 12,000 households in East Harlem with a severe housing need. Of these, 626 were entering homeless shelters and 10,616 were severely burdened by housing costs and extremely vulnerable to becoming homeless (page 87 of EHNP). Legal aid, continued rent stabilization, and new housing construction that is affordable to low-income residents are all crucial measures to reduce the rate of residents becoming homeless. An additional problem related to the homeless population are synthetic cannabinoids commonly known as K2. Overdoses and arrests have dropped dramatically since city legislation was passed to criminalize the sale of this dangerous drug, and that has had a very positive impact on the community. Efforts to reduce the use of synthetic cannabinoids, as well as to connect those using the drug with housing and other services, should continue to be funded.
Needs for Low Income NYs
With so many low-income residents out of the labor force and receiving various forms of public assistance, the government must refocus its approach from poverty maintenance to poverty alleviation. The high unemployment rate and lack of well-paying jobs directly contribute to every other economic and social problem in East Harlem. HRA should partner with the Federal Social Security Administration to develop a pilot program in East Harlem with the goal of eliminating generational dependency on government benefits and shift resources away from transfer payments to human capital development. Funding should target successful education programs, local schools, job training programs, and higher education, and participants should work towards the goal of self-sufficiency to break the cycle of poverty.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
11/20 DOHMH Other programs to
address public health issues requests
Increase personnel for needle pick up on 110th, 111th, and 125th streets. Needle pick up must also occur near Clinton Houses, Marcus Garvey Park, and Ronald McNair Park.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/35
DOHMH
Create or promote
CD11 ranks first in the city for psychiatric
programs to de-
hospitalizations (2,016 per 100,000 adults).
stigmatize mental
Funding from the new ThriveNYC initiative
health problems
should be targeted to improve programming in
and encourage
East Harlem. Supportive programs should be
treatment
developed and better targeted to particular
populations to encourage people to reach out
and get help before needing hospitalization so
that their mental health needs can be positively
managed. Programs should provide assistance
with jobs, housing, education, medical issues,
and any other needs that this vulnerable
population may have.
11/35
DFTA
Enhance home care
Funding is needed to expand services to our
services
multicultural community of low income and
below federal poverty level seniors.
17/35
DOHMH
Other animal and
Provide funding for proactive measures to
pest control
mitigate rodent population in public housing,
requests
empty lots, construction areas, and train
stations where rats establish colonies.
18/35
DFTA
Increase case
Provide funding for more caseworkers.
management
capacity
21/35
DOHMH
Provide more
East Harlem residents are more than three
HIV/AIDS
times as likely to die from HIV/AIDS as the
information and
average NYC resident. Sex education services
services
should be provided, especially among
vulnerable populations, and access to HIV
preventative drugs should be easy and
affordable to all.
22/35
DFTA
Enhance home care services
Provide funding to expand hours of home care provided to insure fewer re-hospitalizations
28/35
DFTA
Allocate funds for
Provide funding to ensure faster service for
outreach services to
seniors transitioning from hospital/rehab to
homebound older
home.
adults and for
programs that allow
the elderly to age in
place
32/35
DFTA
Enhance home care
Provide funding to expand Expanded In-home
services
Services for the Elderly hours of home care.
33/35
DFTA
Enhance home care
Provide funding to hire more Spanish speaking
services
home care workers are needed in the
community.
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 11
image
M ost Important Issue Related to Youth, Education and Child Welfare
Educational attainment
Educational attainment in East Harlem begins to fall behind as early as nursery and preschool (East Harlem Neighborhood Plan - here on EHNP, p 45). While there are 6,887 children under the age of 5 years in East Harlem, only 19.8 percent (1,364) are enrolled in nursery school or preschool (2013-2017 ACS). Pre-K and daycare programs can increase their impact by partnering with existing community-based organizations. These partnerships can provide a greater breadth of programs and strengthen the neighborhood network. Pre-K, daycare and afterschool programs also have gaps in their services. The hours of the facilities sometimes do not reflect the needs of those who use them, and there is a need for more programs to serve families with infants and toddlers (EHNP). According to the 2013-2017 American Community Survey, 28.6% of residents 25 years and over do not have a high school diploma or the equivalent, while 32.5% have earned a bachelor’s degree or higher. These rates differ significantly from Manhattan’s overall rates for less than a high school degree and higher education attainment (13.96% and 60.4% percent respectively). This low rate of educational attainment contributes to a cycle of unemployment and poverty that becomes increasingly difficult to change with each generation. Moreover, Students in East Harlem struggle academically and the results impact their futures. Only 40.5% of students in East Harlem are performing at grade level in English language arts (4th grade), and only 33.7% of students are performing at grade level in math (4th grade) (DOE, 2018). The Department of Education should continue to expand its focus on STEM (science, technology, engineering, and mathematics) and include more arts, music, culture, local history, special education programs, financial education, and vocational training. Considering East Harlem’s diversity in population, it’s important that East Harlem schools place “culturally responsive-sustaining education (CR-SE)” at the center. CR-SE embraces students’ identities, placing aspects of their race, social class, gender, language, sexual orientation, nationality, religion, or ability at the center of their education. According to DOE, students that learn using CR-SE are more active in class, achieve higher grades, and graduate more often. Additionally, DOE should also expand bilingual education and English as a Second Language programs since 46% of children aged 5 to 17 speak a language other than English at home (2013-2017 ACS).
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
School facilities face significant capital and capacity limitations, which can lead to overcrowding and increased competition between schools for resources. The Department of City Planning, the Department of Education, ACS and School Construction Authority to adequately project the impacts of new development on school seat requirements and establish opportunities for new early childhood education and school facilities to be built in the base of new developments. Approaches for making student projections should include detailed analysis, such as the clear definition of school building capacities based on current surveys. Require coordination around and appropriate timing of development of school facilities as units are developed.
DOE and SCA continue to make important upgrades and advancements to facilities in the district, but more remains to be done. Some Pre-K, daycare and after-school program facilities need repairs, while others lack access to a diversity of spaces for different types of activities. Common needs include access to outdoor and recreational spaces, and more spaces for flexible uses like music, art and libraries. A survey of principals conducted as part of the 2016 East Harlem Neighborhood Plan found that the top three capital needs of District 4’s public schools are: technological upgrades, playground redevelopments, and auditorium upgrades, and the top three service needs are: social-emotional services, academic remediation and literacy programs (EHNP, pg 47).
Community-based organizations, select local schools, and the DOE should create a forum for local schools to collaborate and share best practices to encourage improvement at underperforming schools. The DOE should also provide targeted assistance and resources, with greater accountability, to under-performing schools. If after
sufficient opportunity and resources, schools continue to underperform, DOE must focus efforts on more substantial intervention strategies. Future schools should be structured as Community Schools in order to provide wrap-around services to students and their families. In a community with so many needs and challenges, schools can and should be as comprehensive in the services they offer as possible. This will help to balance out disparities that negatively affect academic performance/attainment.
Needs for Youth and Child Welfare
East Harlem’s youth face many challenges, and additional services and supports are needed, via schools, afterschool programs, and community organizations, to help vulnerable children excel at school and gain social skills. Youth, aged 0- 18, make up 16% of East Harlem’s population (ACS 2013-2017). A disproportionate amount of youth in East Harlem live in poverty, with 46.5% of residents under the age of 18 live below the poverty level within the last 12 months according to the ACS 2018 1-year estimate). Of the 9,230 East Harlem families with children under the age of 18 years, 65% are headed by an individual with no spouse present (2018 ACS 1-year estimate).
East Harlem youth face safety concerns due to the high rates of violence and gang activity, especially in public housing. To address the unique challenges associated with the youth population in East Harlem, the community and City must work together to improve after-school programs, provide opportunities for youth employment, increase extracurricular educational services and curb youth violence. Job and other activity programs specifically geared toward youth should target public housing developments and other areas with high gang activity to offer an alternative. DYCD should expand after-school and evening programming, provide viable alternatives to at-risk youth and target older teenage students with evening recreational activities. There is a lack of physical spaces for youth to spend constructive and safe time during after-school hours, weekends and summertime. Specific recommendations from the community include a movie theater, outdoor theater, recreation/cultural center, YMCA, dance space, bookstore, and teen-friendly nightlife. Developers should be incentivized to work with nonprofits to build these needed facilities and provide programming.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
3/20 SCA Provide technology
upgrade
Upgrade the electrical work and technology in 10 East Harlem school buildings as deemed necessary.
image
12/20 SCA Renovate interior
building component
Provide a Mechanical, Electrical, and Plumbing infrastructure upgrade to 10 schools in East Harlem as deemed necessary.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/35
DYCD
Provide, expand, or
Increase the amount of after school program
enhance after
seats in East Harlem, especially for older youths.
school programs for
all grade levels
8/35
DYCD
Provide, expand, or
In 2019, 70,000 of the 160,000 applicants were
enhance the
able to participate in the Summer Youth
Summer Youth
Employment Program. Increase funding to allow
Employment
for more slots, in order to expand the reach of
Program
the program. Additionally, increase the number
of Work, Learn & Grow program slots in order
to increase the reach of DYCD throughout the
school year.
30/35
DOE
Provide, expand, or
In lieu of the administration's push for PreK for
enhance funding for
All, there is a gap of services during the hours
Child Care and Head
between the end of the school day and 5:00 PM.
Start programs
Expand Child Care, Head Start Programs, and 3K
and Pre-K for All programs to cover after-school
hours.
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 11
image
M ost Important Issue Related to Public Safety and Emergency Services
Youth crime
The crime rate citywide and in East Harlem has decreased over the past two decades thanks to the hard work of law enforcement and communities working together. However, pockets of violent crime still exist in East Harlem.
Compared with the citywide rate, East Harlem has a significantly higher rate for non-fatal assault hospitalizations with 130 per 100,000 residents annually-- more than double NYC’s and Manhattan’s rates (Community Health Profile 2018). Moreover, there is a growing trend of youth violence in East Harlem, particularly related to the gangs and crews in public housing. Ongoing turf wars and revenge killings have cost many youths their lives and caused other residents to feel unsafe and isolated. According to CompStat 2.0, major crimes related to public housing in the NYPD 23rd Precinct are up 50% in the 28-day period in October 2019 compared to October 2018. There have been 9 shooting incidents combined between the 23rd and 25th Precincts in October 2019’s 28-day period, compared to 2018’s 0 shooting incidents. Programming for high-risk youth and their families should be expanded throughout the district and should include late-night and weekend programming. Offerings should be diverse and reflect community input and should include options for the families of high-risk youth. Jefferson Recreation Center and Johnson and Corsi Houses’ community centers should be used as pilot programs for expanded and diversified activities (EHNP p.113).
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Residents need to feel safe in their neighborhood, both to allow for enhanced quality of life and to act as “eyes on the street” and deter crime. Lighting should be improved in several locations, including Marcus Garvey Park, Jefferson Park, the East River Esplanade, under the Park Avenue viaduct and along commercial corridors (EHNP p. 114). According to input from the East Harlem Neighborhood Plan, the potential for strong collaboration between the police and local groups exists, but more extensive neighborhood-specific training, deeper local partnerships and increased community policing approaches are needed in order to make efforts work properly. Many individuals in East Harlem have a negative view of the police, and while stop and frisk policies are no longer a threat, law enforcement needs to continue to work to rebuild trust within the community. Many NYCHA developments have their own gangs or crews, and the violence associated with these groups has left too many members of the community dead, and others afraid to accidentally encroach on a crew’s turf. Our youth need to be exposed to
after-school and job training programs as viable alternatives to joining a crew. Local organizations that offer these resources should be supported and the police department should work with them for maximum efficiency. Mental health and domestic abuse are both large problems in East Harlem. Police officers need to be trained in how to deal with a mental health crisis so they can better assist those who may require psychiatric help rather than incarceration. Domestic violence outreach should improve to help connect victims to legal representation, counseling, housing, and job/educational assistance.
Finally, the incarceration rate in East Harlem is the fifth highest in the city and more than three times higher than the citywide rate. 302 out of every 100,000 adults in East Harlem are in jail, and this high rate has a devastating effect on their individual futures, as well as the larger community. Mayor de Blasio has made great strides to reduce arrests for low-level offenses, end stop, and frisk policies and is now working to end youth solitary confinement on Riker’s Island, but there is still more to do to change the inequity of the criminal justice system. A Diversion Center should be piloted that would connect individuals who have committed low-level offenses with mental health, shelter, and other social services rather than incarcerating them (EHNP, p. 114). This would allow residents to access needed services and potentially prevent them from committing larger crimes in the future.
Needs for Emergency Services
No comments
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
19/20 FDNY Other FDNY facilities
and equipment requests (Capital)
Provide additional funding for a Fire Safety Education unit to service East Harlem. The Fire Safety Education Unit is specially trained to conduct public education and community outreach. Studies show that the decrease in death due to fires is directly correlated with strong public education programs.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
35/35
FDNY
Expand funding for fire prevention and life safety initiatives
Provide additional funding to continue FDNY's "Get Alarmed" program. $1 million for 63,000 alarms to be installed and/or given away.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 11
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Environmental concerns affecting citizens
As described by the Building Healthy Communities initiative of the Robert Wood Johnson Foundation, your zip code can play a significant role in determining your life expectancy. East Harlem is experiencing numerous ongoing environmental concerns that are negatively affecting citizens today and will affect their health and well-being well into the future. Community Board 11 seeks to assist in identifying and addressing these interrelated concerns as the main issue relating to core infrastructure, city services, and resiliency. The environmental concerns most pressing to the livelihood of our community include air quality and pollution. The asthma hospitalization rate in East Harlem is among the highest of all neighborhoods in New York City. The number of adults with asthma is 60 percent higher than the NYC average and the hospitalization rate is 200 percent higher than the NYC average. Among East Harlem’s children, the hospitalization rates for asthma attacks is more than two times the city average. Many pollutants within East Harlem, such as the two sanitation garages, proximity to the FDR Drive and other large highways and a lack of green spaces, contribute to high levels of particulate matter in the air. In order to address the issues of dangerous levels of pollution and to provide adequately safe air quality in our community, Community Board 11 requires a consolidated sanitation facility, as well as funding to conduct air quality assessments to ensure that our neighborhoods are protected from ongoing new construction as well as existing pollutants within our community.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
East Harlem suffered severe flooding during Hurricane Sandy, and the vast majority of CD11 lies in an evacuation zone, with many large public housing complexes located in Zone 1-- the most vulnerable area. The low elevation and proximity to the East River, combined with a large number of public housing residents and seniors in the community creates a potentially dangerous situation when another storm strikes. NYC Parks is currently undergoing a coastal resiliency study in East Harlem to determine the most effective ways to protect the neighborhood. Upon completion of the study, funding should be allocated for both hard and soft infrastructure to protect the shoreline and prepare residents for future disasters. This should include living shorelines (oyster beds, marshes, berms), floodgates, community education around emergency preparedness and block/building watches to ensure vulnerable residents are taken care of.
Needs for Sanitation Services
Manhattan Community District 11 hosts three Department of Sanitation facilities. The Manhattan District 11 garage is currently located on 99th Street and First Avenue and will be relocated temporarily to a surface parking lot located on 128th Street between Second Avenue and Third Avenue. The temporary M11 garage will be located adjacent to an elementary school, a heavily utilized public park, and a newly opened cancer treatment facility. The Manhattan District 10 garage which serves Central Harlem is located at 132nd Street and Park Avenue, just five blocks from the new M11 garage. Because of the poor condition of the M10 garage building, most of the sanitation equipment is parked in the street and under the Metro-North railroad viaduct. The Manhattan Lot Cleaning Unit currently utilizes a surface parking lot on 123rd Street between Lexington Avenue and Third Avenue. While this lot is intended to be used for official DSNY equipment, it is evident that it is instead very often used to park personal vehicles. This site which was identified in the 2017 East Harlem Rezoning Points of Agreement for the development of affordable housing and is a high priority for our board.
Community Board 11 opposed the temporary relocation of the M11 garage to 128th Street in part because it would result in three surface level open-air sanitation garages located within ten blocks of each other within our community.
To resolve this underserved burden on our community and direct violation of the City’s Fair Share Mandate, CB11 proposed funding to be allocated for the construction of a new state of the art consolidated facility to house the M11 and M10 garages. This request was incorporated in the 2016 East Harlem Neighborhood Plan and the subsequent 2017 East Harlem Rezoning Points of Agreement (POA) which states that the City would “working with community stakeholders, plan for the development of an enclosed consolidated DSNY sanitation facility for M10 and M11, which meets LEED gold standards”. The POA also states that “DSNY will immediately begin planning for a permanent, long-term facility to serve District 11 sanitation needs, which includes the following goals:
image
explore options for a permanent consolidated facility that could house multiple garages, including District 11, District 10, District 9, and/or the Manhattan Lot Cleaning Unit;
image
assess suitable sites for the permanent facility that will serve residents for the next 100 years. Explore all City- owned sites and appropriate privately-owned sites in Manhattan Community Boards 9, 10, and 11, as well as the potential acquisition of the entire Block 1792.
In order to address the issue of cleanliness, there should be a campaign, led by the Department of Sanitation, consisting of community workshops, advertisements and public service announcements in community-relevant languages to reach the population of East Harlem to educate the community on the importance of keeping the streets clean. Additionally, DSNY alongside the Community Board should work together to identify problem intersections and introduce corner bins to each identified problem area. This can help mitigate the sanitary issues of East Harlem, as well as bring awareness to the quality of life issues created by littering.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
4/20 DSNY Provide new or
upgrade existing sanitation garages or other sanitation infrastructure
Build a permanent, state-of-the-art dual district sanitation garage to service Manhattan Community Districts 10 and 11. The new building should meet or exceed LEED Gold standards and be equipped with the most advanced indoor air filtration systems and zero emissions sanitation trucks.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 11
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing preservation
East Harlem’s housing stock is largely subsidized, rent-stabilized or public housing and only 22 percent of units are currently unregulated. However, data provided by the Regional Plan Association and others project that 4,230 subsidized and rent-stabilized units are at risk over the next 15 years due to expiring affordability programs. This, combined with the pressures on regulated housing due to increased development in the area, makes affordable housing programs the top concern in East Harlem. The 2016 East Harlem Neighborhood Plan estimated the “affordable housing need” in East Harlem as 12,000 households. This number is based on 626 households entering homeless shelters; 10,616 households severely burdened by housing costs, and 758 severely overcrowded households (> 1.5 persons per room). HPD’s Landlord Ambassadors pilot program was “created to stabilize the physical and financial health of small- and medium-sized multi-family buildings by helping owners implement best building management practices and navigate the process of applying for HPD financing.” This program ended in June 2019, but it should be extended in East Harlem. Programs such as this and HPDs Partners in Preservation pilot program which aims “to create partnerships between HPD and Community Based Organizations to develop and execute anti-displacement strategies in targeted neighborhoods,” are necessary to the successful preservation of much-needed affordable housing in our community.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
image
As housing costs continue to rise throughout the city, East Harlem residents face ever-increasing rents and displacement pressures. With a median income of $37,470, the housing market is increasingly out of reach for East Harlemites. It is imperative that the City prioritize policies and programs that ensure existing affordable housing units are preserved, and that new affordable units reflect the income levels of this community. The City must prioritize the completion of East Harlem Rezoning Points of Agreement commitments and develop affordable housing on city-owned sites including the East Harlem Multi-Service Center, the 25th Precinct parking lot at 119th Street and the lot being utilized by the Department of Sanitation’s Lot Cleaning Unit at 123rd Street.
Though large swaths of the district were rezoned as a result of the 2017 East Harlem Neighborhood Rezoning, we encourage the Department of City Planning to reopen and expand the rezoning area, as requested in the E ast
H arlem Neighborhood Plan and consider expanding Mandatory Inclusionary Housing (MIH) to cover First Avenue. Fine-grained zoning changes should be made throughout the community that both facilitate the development of housing affordable to existing community residents, as well as incentivizing nonresidential development.
While Mandatory Inclusionary Housing will be triggered in any new residential development taking advantage of the increased density, MIH does not go far enough to address the need for housing that is truly affordable to East Harlem residents. We call upon HPD and HDC to identify and commit additional funding sources to provide both (a) capital subsidies to reduce construction costs and (b) ongoing rental subsidies to both extend the term of affordability for affordable units in mixed-income buildings and to enable deeper levels of affordability, while still allowing for a diversity of income. We further ask that the City identify significant additional subsidies to allow for additional affordable homeownership opportunities and to provide a deeper level of affordability in new development, both on City-owned land and on developments of private property.
image
On June 18, 2019, CB11 adopted a resolution detailing its A ffordable Housing Development Guidelines, which should be utilized by City Agencies and developers to design proposals that fit the housing needs of Manhattan Community District 11. CB11 resolved that Development on Publicly Owned Sites should target 100% rent and income-restricted development with deep affordability and at a variety of low- and moderate-income rent levels in perpetuity where units are targeted 20% Extremely Low-Income, 20% Very Low-Income, 20% Low-Income, 20% Moderate-Income,
and 20% Middle-Income. Further, development on Privately Owned Sites seeking a zoning change, should include at least 30% of the residential units affordable at an average of 60% AMI in perpetuity. Thirdly, Condominium or Cooperative Development Developers are encouraged to construct affordable condominiums or cooperatives to provide homeownership opportunities to local residents. Housing proposals that integrate both affordable homeownership and rental units are also encouraged. All condominium or cooperative units should be affordable to low-moderate- and middle-income households earning between 80% and 130% of AMI.
Needs for Housing
East Harlem has a high need for affordable housing, both preserved in existing buildings and included in new construction. As more development comes to East Harlem and rising rents elevate the frequency of displacement pressures for low-income tenants, it is vital that they are made aware of their rights as tenants and have access to free legal services to protect themselves and their homes from unscrupulous landlords and developers. The City is moving in the right direction by expanding funding for the representation of tenants, but current legal aid funding must be extended beyond its current three-year term. Additionally, the idea of an anti-harassment/anti-eviction district similar to the Special Clinton District should be studied to add an extra level of protection for East Harlem tenants. Current residents should be better prepared for affordable housing lotteries as well. Housing preparedness clinics should be held regularly, and developers should be required to hire a third-party organization to conduct credit counseling and marketing.
Not only do most East Harlem residents live at or below 30% of AMI, but there is also a substantial number of those individuals who require supportive housing. There is an ongoing need in our community to preserve and develop affordable supportive housing for our seniors, veterans, disabled, and homeless populations as well as individuals living with substance use disorders and those of our neighbors returning to the community after incarceration.
Any proposals for either infill development or PACT conversions on NYCHA properties must be considered in consultation with the residents, the community board and the elected officials that represent the affected developments.
Needs for Economic Development
image
An unemployment rate of 7.3 percent in 2016, according to the State Comptroller, does not effectively communicate the challenge of underemployment paired with unaffordable housing in East Harlem. About one in eight East Harlem adults ages 16 and older is unemployed, and nearly half of residents spend more than 30% of their monthly gross income on rent. (C OMMUNITY HEALTH PROFILES 2015, NYCDOHMH) The lack of well-paying jobs directly contributes to other economic and social problems in East Harlem. According to the 2013-2017 ACS survey, the annual median household income in East Harlem was $37,470 which is significantly lower than the median NYC median household income of $62,040--and less than half of the median household income in Manhattan--$86,693. Some areas of East Harlem are even more distressed; the two census tracts, 192 and 194, that make up Wagner Houses have median incomes of $17,304 and $20,086, respectively. Of the 102,991 residents age 16 and older in East Harlem, 11.2% percent are either unemployed and 44.3% are not in the labor force. Nearly 37.1% of family incomes are below the federal poverty line and percentages even higher for youth and seniors, 46.55% and 33.84% respectively; one-third (31%) receive food stamps.
With so many East Harlem residents out of the labor force and receiving various forms of public assistance, all levels of government must refocus their approach from poverty maintenance to poverty alleviation. Workforce development programs must be targeted to the most vulnerable residents, such as the homeless, mentally handicapped, youth, women and the formerly incarcerated. This effort must include innovation and a focus on alternative methods of alleviation - a focus on small business creation, locally grown entrepreneurs and skills enhancement. In support of the many East Harlem households headed by single mothers, programs for these efforts in increased education and job-readiness, must include access to low-cost and free childcare.
As our city and state move away from policies that have contributed to mass incarceration, it is necessary to support and expand programs that meaningfully assist individuals with a history with the criminal justice system successfully reintegrate into the workforce. Paired with social services that aid this population with re-entry, the opportunity to
find meaningful and dependable means of income is vital to successful re-entry and reducing recidivism. These are our family members and neighbors; it is incumbent upon our community, service providers and our government to aid to the extent possible in their successful reintegration.
Local hiring, including building projects, retail, foodservice, and offices, has to be supported and encouraged. This can be accomplished by providing funding for a local workforce development provider that identifies, screens and refers to local residents to appropriate employers. Labor unions should also build pre-apprenticeship programs and work to ensure apprentices are moving up through the system to earn a living wage.
Overall economic activity must be increased in the community to bring more businesses, commercial activity and employment opportunity to key commercial corridors including 125th Street, 116th Street, 106th Street, Third Avenue, Second Avenue and First Avenue. Similarly, opportunities to bring economic activity to Park Avenue and Madison Avenue should be pursued. Support for small business enterprises must be encouraged and supported. The Department of Small Business Services must continue to provide assistance to local merchant organizations, including Uptown Grand Central, and local providers of business support services, including the Business Development Center at Union Settlement.
Supporting Materials: E ast Harlem Commercial District Needs Assessment
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/20
HPD
Provide more
Provide funding for the development of
housing for special
affordable housing at deeper levels of
needs households,
affordability targeting households living under
such as the formerly
30% of AMI, the developmentally disabled,
homeless
those living with mental illness and homeless
veterans.
2/20
HPD
Provide more
There remain many vacant properties or under-
housing for
utilized residential buildings in East Harlem. It is
extremely low and
imperative that the community, elected leaders
low income
and HPD work collaboratively to create the
households
necessary incentive(s) for private property
owners to upgrade and maintain their
properties for active residential use. Newly
developed or rehabilitated apartment buildings
must include a balance of mixed-income units
that also include a percentage of units for low
and extremely-low income households.
13/20
EDC
Make infrastructure
Provide funding for the development of a new
investments that
consolidated sanitation garage for Manhattan
will support growth
Community Districts 11 and 10.
in local business
districts
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
1/35 NYCHA Expand programs
for housing inspections to correct code violations
Hire additional inspectors to monitor building complaints
image
4/35 SBS Provide or expand
occupational skills training programs
Provide funding for more workforce development programs.
image
7/35
SBS
Provide or expand occupational skills training programs
East Harlem's workforce development infrastructure must address the needs of the large number of residents who are unemployed and seeking well-paying jobs. Local employment and training organizations and SBS should work to connect local residents to employment opportunities in growth industries and local development-based employment. SBS and EDC should create and package incentives to attract growth industries to locate in East Harlem, with emphasis on attracting STEM related businesses to open up additional career opportunities for local residents. SBS must increase funding for training vouchers, which would then be used by local residents for necessary advanced training and certifications. The local libraries can also be expanded to serve as workforce centers.
9/35
SBS
Assist with on-site business compliance with City regulations
City agencies that regularly enforce codes and regulations which impact small businesses must create forums where local merchants can be educated on current and changing agency rules and solicit feedback from merchants with complaints of unfair treatment. Such agencies should also ensure that inspectors enforcing agency rules in East Harlem are bilingual (particularly Spanish speaking).
10/35
EDC
Other public housing maintenance, staffing and management requests
Provide funding for the purchase of additional services vans to aid residents with annual online re-certification and maintenance requests.
12/35
DOB
Expand code enforcement
Provide funding to hire an Assistant Director for the Office of the Tenant Advocate. The focus of this office must prioritize areas across the city that have been rezoned including East Harlem.
13/35
SBS
Support local CBOs efforts to provide or expand district marketing, branding, and promotion
Additional resources should be committed to promote East Harlem's cultural offerings, including wayfinding signs along Lexington Avenue and other major corridors. The funding for the Avenue NYC program should continue for existing place-making and tourism efforts.
14/35
DOB
Expand code enforcement
Provide more funding for tenant harassment units.
16/35 NYCHA Expand programs
for housing inspections to correct code violations
HPD should create a specific program that will regularly monitor and inspect the housing conditions of vulnerable seniors, veterans and the formerly incarcerated.
image
26/35 EDC Expand programs
for certain industries, e.g. fashion, film, advanced and food manufacturing, life sciences and healthcare
EDC, in collaboration with SBS, should create and package incentives to attract growth industries to locate in East Harlem, with emphasis on attracting STEM related businesses to open up additional career opportunities for local residents.
image
31/35 SBS Support local, long-
standing businesses
Provide funding for dedicated staff for coordination with Metropolitan Transportation Authority (MTA) on the Second Avenue Subway Phase II outreach and response.
image
TRANSPORTATION
Manhattan Community Board 11
image
M ost Important Issue Related to Transportation and Mobility
Bus service (frequency and access)
Bus service within and through East Harlem needs improvement. Traffic along the 125th Street corridor causes delays in bus service, which often results in multiple busses arriving at stops at the same time and causing further congestion at major intersections. The bus lines along Madison and Fifth Avenues are often delayed and overcrowded due to congestion below 60th Street. Thankfully, the Bronx Bus Redesign will implement changes to bus lines along 125th Street that will ultimately reduce congestion and improve bus service. NYC Transit should work with the community board to ensure that service along 125th Street improves. Additionally, DOT should work alongside the community board to identify solutions to delays along North/South bus lines ahead of the Manhattan Bus Redesign. Specifically, NYC Transit should consider improving the M1 bus line by changing the route to originate north of the Queensboro Bridge, so that commuters in East Harlem are not impacted by the congestion downtown.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Per suggestions in the East Harlem Neighborhood Plan, a multi-modal transportation hub should be built that connects the Second Avenue Subway, the 125th Street Metro-North Station and the Lexington Avenue lines, as well as taxi services, bus routes, and CitiBikes. The MTA and DOT must work to improve conditions around the 125th Street Metro North Station, including the installation of better lighting, pedestrian safety improvements at the intersection, and renovation/utilization/removal of the old comfort station on the south side of 125th Street across from the Metro North Station. Additionally, Phase 2 of the Second Avenue Subway project must commence, as East Harlem is currently only serviced by the severely overcrowded Lexington Avenue lines. The Lexington Avenue trains are some of the most delayed in the city, and the MTA and NYC Transit need to continue to work to minimize delays that negatively impact riders.
Several bridges and heavily traveled commuter corridors are adjacent to or pass through East Harlem, including the Triboro/RFK Bridge, Willis Avenue Bridge, Third Avenue Bridge, Madison Avenue Bridge, the Harlem River Drive/ FDR Drive, and several popular avenues and cross streets (with most AM and PM commuter vehicles not originating from this community). Heavy vehicle traffic has a negative impact on pedestrian safety at several key intersections and it causes issues of reliability of NYC Transit bus lines. DOT should conduct studies of the entire 125th Street corridor, as well as Third Avenue between East 97th and 125th Streets, in order to develop recommendations to improve vehicular traffic flow and pedestrian safety taking into consideration East Harlem’s aging and vulnerable populations. Additionally, NYC Department of Transportation (DOT) must continue to install pedestrian crossing signals with countdown timers at all East Harlem intersections.
Moreover, the impact of vehicular traffic and congestion in East Harlem has no doubt contributed to particulate matter in the air that triggers asthma. The Department of Transportation’s efforts to encourage alternative modes of transit into and around New York City must be supported. The further disruption to right of way caused by major construction in the district should be considered an opportunity to reconstruct with vast, comprehensive and integrated improvements -- including the integration of green infrastructure -- that have the capacity to affect the community’s health, vitality and wellbeing.
Lastly, now that congestion pricing will be implemented below 60th Street, it’s pertinent that New York City Council, with the support from the Department of Transportation, implement a residential parking permit system in East Harlem to accommodate local residents and ensure commuters don’t park on local streets.
Needs for Transit Services
The MTA and NYC Transit need to continue to work to minimize delays along the Lexington Avenue train lines that negatively impact riders. The buslines along Madison and Fifth Avenues, as mentioned above, must be improved and made more dependable.
The Community Board also requests that NYC Transit increase rides per days and ridership hours for Student Metrocards. Specifically, Transit should fund up to five (5) rides per day between 5:30 AM until 10:00 PM, including weekends and summer months. This would allow youth to attend and participate in extracurricular school activities and/or work activities.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/20
NYCTA
Repair or upgrade
The MTA and City must work aggressively with
East 125
subway stations or
Federal partners to secure funding for Phase 2
Street
other transit
of the Second Avenue Subway in order to ease
Lexington
infrastructure
congestion on the Lexington Avenue lines, and
Avenue
provide and alternative to often unreliable bus
lines.
9/20
DOT
Repair or provide
NYC DOT should provide improved street
new street lights
lighting along 104th, 105th and 117th Streets
between Park Avenue and Lexington Avenue;
and 126th Street between Park Avenue and
Madison Avenue. On streets where a thick tree
canopy obscures the effectiveness of tradition
street lights, DOT should install lights that hang
below the level of the tree canopy.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
6/35
DOT
Conduct traffic or
Excessive vehicular traffic has created safety
parking studies
problems at key intersections throughout the
community. The DOT should conduct
engineering studies of the major commercial
corridors (125th and 116th Streets), considering
both traffic and parking, with the goal of
improving pedestrian safety and easing
vehicular congestion.
34/35
NYCTA
Expand bus service
The most inconsistent bus lines along Madison
frequency or hours
and Fifth Avenues, particularly the M1, must be
of operation
improved and made more dependable. NYC
Transit must consider changing these routes to
originate north of the 59th Street Bridge.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 11
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park access and park facility access
The East River Esplanade serves as a natural barrier against flooding, as well as a place for community enjoyment and exercise, but at this time there are a number of areas along the East River waterfront that are quickly deteriorating. More specifically, the underlying structural supports are in great need of repair, and will only continue to deteriorate and pose a significant danger to our residents. In order to address the issues of crumbling protective infrastructure, Community Board 11 requires a new assessment of the bulkheads, piers, and sea walls along the East River esplanade, a strategy to repair these elements of our waterfront and funding to restore these areas into much needed vibrant public spaces for our residents. Funding should be prioritized to assess the overall needs and provide repairs, including those necessary to make Pier 107 fully functional again.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Many parks in East Harlem need better maintenance and staffing. Harlem River Park, Each One Teach One, Lincoln Playground, and Marcus Garvey Park, in particular, would benefit from greater sanitation services to address their rodent and trash problems. As mentioned above, the East River Esplanade is in dire need of repairs and programming to safely activate the space.
A few of the parks in East Harlem -- including Ronald McNair Park, Harlem River Park, and Marcus Garvey Park -- have been identified as hotbeds for illicit activity and discarded needles. NYC Parks should partner with the Department of Health and Mental Hygiene and non-profit organizations to provide more services for individuals in crisis.
Needs for Cultural Services
Funding is critical to both the preservation and exploration of arts and culture programming and necessary in order to promote the foundations that provide such programming for the benefit of the East Harlem community and NYC at large. Some of the specific needs of local cultural institutions are: The Julia de Burgos Cultural Center and other smaller-scale institutions need to be considered for inclusion in the Cultural Institutions Group to make it eligible for significant capital and operating support from the City. Funding and support need to be provided for the revitalization of the historic La Marqueta, which would act as a catalyst to attract new businesses and vibrancy to the Park Avenue corridor. The newly formed Friends of La Marqueta, which includes board participation, will provide a local governance structure for the revitalized market. The Board welcomes more arts/cultural service organizations to enhance, educate and expand public interest in the arts and culture of East Harlem. A campaign to bring these entities and artists to East Harlem will solidify our community commitment to the important place our culture has in New York City and re-establish our commitment to the arts. Once established, and representative of a cross-section of the East Harlem community, this organization should work to develop comprehensive art and culture strategic master plan for the community. Given the seating capacities of East Harlem’s many theaters, NYC & Company should work with local artists and theater owners to promote East Harlem as an Off-Broadway site both for East Harlem’s artists and other aspiring artists. This would be one step towards boosting tourism and bringing much-needed capital into East Harlem.
Needs for Library Services
East Harlem's libraries are heavily used by the local community and are especially valuable to low-income residents who may not be able to afford to purchase books. In addition to books, they offer computer and language classes that are incredibly valuable and should be expanded to reach as many residents as possible. We encourage the overall budget for the New York Public Library to be increased so that libraries can maintain weekend hours and
continue to expand their collections, programming, and staffing. Specifically, in East Harlem, funding should be allocated for computers and computer literacy classes and to renovate the Aguilar Library building exterior and window.
Needs for Community Boards
The budget for each Community Board should be increased. Community Boards play a vital role in planning and quality of life advocacy for neighborhoods all across the city. However, they are hampered in their ability to effectively advocate for residents by small budgets. Increasing the budget would allow additional staff to be hired and result in an overall increase in the quality of responses and services that the community board provides.
Additional funding is especially necessary now given the many demands placed on Community Boards regarding zoning changes and housing developments under the Mayor’s Housing New York plan. Funding would also be used for technological upgrades, such as new computers and GIS licensing, translation services, improved outreach to constituents and continual professional development for staff. Community board offices must be housed in a multi- use, city-owned facility. Board office spaces should include not just staff offices but meeting areas, including a sizable conference room for our Executive Committee and other smaller meetings; an area able to hold up to 100 people for our monthly committee meetings; and an auditorium capable of seating up to 200 people for our monthly full board meetings. Since many of our community-based service institutions face similar problems in arranging usable facilities for their functions, these board meeting spaces would also serve as a general community center open to the public and specialized programming. We urge our officials to consider possible existing or new, permanent sites that can satisfy these needs so that the board can carry out our duties effectively and provide a welcoming community facility for local groups and our constituents.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/20
DPR
Reconstruct or
The East Harlem Esplanade is slowly
upgrade a park or
deteriorating and falling into the East/Harlem
amenity (i.e.
River and needs major infrastructure
playground, outdoor
improvements to rebuild or reinforce the super-
athletic field)
structure underneath the parkland and the FDR
Drive. Immediate attention should be given to
the 107th Street Pier and the 117th Street
wooden pylons. DOT and the Parks Department
should work collaboratively to achieve this goal.
7/20
DPR
Provide a new, or
Comfort stations should be installed in highly
new expansion to, a
used parks, such as Thomas Jefferson Park near
building in a park
the 114th Street Playground.
8/20
DPR
Reconstruct or
Fund the replacement of the 107th Street Pier to
upgrade a park or
allow it to be safely utilized by the community.
amenity (i.e.
Approximately $28 million is needed to
playground, outdoor
completely rebuild the Pier.
athletic field)
10/20
DPR
Provide a new, or
NYC Parks should provide funding for a new
90-98 EAST
new expansion to, a
playground and a comfort station near 132nd
132 STREET
building in a park
Street and Esplanade as part of the East Harlem
Greenway Link to be created between 125th
and 132nd Streets.
14/20
DPR
Reconstruct or
With the rehabilitation of the Fire Watchtower
upgrade a park or
in Marcus Garvey Park complete, funding must
amenity (i.e.
now be allocated for the reconstruction of the
playground, outdoor
Acropolis, paths, staircases and walls leading up
athletic field)
it.
15/20
DPR
Other requests for
Funding should be allocated to replace the
park, building, or
copper pipes and valves for the onsite water
access
system in Harlem River Park (135- 139th
improvements
Streets).
16/20
NYPL
Create a new, or renovate or upgrade an existing public library
In addition to the major renovation that the 125th Street Library branch will undertake in 2020, this branch has a shortfall in capital funding for targeted upgrades such as heating and cooling system updates; new roof, windows, and doors; fire alarm, security and technology upgrades; ADA compliance, and elevator replacements. This additional work will enhance the patron experience and beautify the branches exterior and interior to ensure the comfort of the staff and patrons inside. This additional cost for this work is $2,900,000.
17/20
BPL
Create a new, or renovate or upgrade an existing public library
The 125th Library will be closed for two years beginning in 2020. Usage will increase at the Aguilar Library as residents seek library services during this two year renovation. In an effort to ensure that all patrons have accessibility to the facilities, this branch will upgrade and rehabilitate the accessibility ramp and entrance to be ADA compliant. The cost for this work is
$397,000.
18/20
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Replace the synthetic turf field at Eugene McCabe Playground using natural materials (coconut and sand) using the internal budgeting and staffing in the same manner as the quickly replaced Lion's Gate soccer field in Sara D. Roosevelt Park.
20/20
DPR
Improve access to a parks facility
Provide funding to make all comfort stations in public parks ADA compliant.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
5/35 OMB Other community
board facilities and staff requests
Provide funding for baseline Increase the PS and OTPS budgets of Community Boards to support the vital role they play in planning and quality of life advocacy for their communities.
Increasing the budget would allow additional staff to be hired and result in an overall increase in the quality of responses and services that the community board provides.
image
15/35 DPR Other park programming requests
Funding for the Department of Parks and Recreation summer maintenance plan must be maintained at current levels.
19/35
DPR
Forestry services, including street tree maintenance
Additional NYC Forestry staff should be hired to maintain the street trees. Funding should also be directed to Trees NY.
20/35
NYPL
Extend library hours
Increase operating funding for libraries to
or expand and
expand 7-day service and ensure that at least
enhance library
one branch in every council district is open 7
programs
days
23/35
DPR
Other park
Green Thumb needs additional funding to
programming
properly execute its oversight role and ensure
requests
that community gardens are open to the public.
Additional staff should be hired to assist private
gardens as they transition to GreenThumb
Gardens.
24/35
DPR
Provide better park
Hire seasonal staff via the City Parks Workers to
maintenance
improve maintenance at all Community Parks
Initiative sites.
25/35
DCLA
Support nonprofit
The Department of Cultural Affairs should
cultural
provide seed funding for the creation of an
organizations
arts/cultural service organization in East
Harlem. Once established, and representative of
a cross-section of the East Harlem community,
this organization should work to develop a
comprehensive arts and cultural strategic
master plan for the community.
27/35
DPR
Provide better park
Currently there are no gardeners servicing parks
maintenance
in Manhattan Community Board 11. Hire
additional gardeners to service East Harlem
Parks.
29/35
DPR
Other requests for
Provide funding to reinstate the Community
park, building, or
Parks Initiative.
access
improvements
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/20
HPD
Provide more
Provide funding for the development of
housing for special
affordable housing at deeper levels of
needs households,
affordability targeting households living under
such as the formerly
30% of AMI, the developmentally disabled,
homeless
those living with mental illness and homeless
veterans.
2/20
HPD
Provide more
There remain many vacant properties or under-
housing for
utilized residential buildings in East Harlem. It is
extremely low and
imperative that the community, elected leaders
low income
and HPD work collaboratively to create the
households
necessary incentive(s) for private property
owners to upgrade and maintain their
properties for active residential use. Newly
developed or rehabilitated apartment buildings
must include a balance of mixed-income units
that also include a percentage of units for low
and extremely-low income households.
3/20
SCA
Provide technology
Upgrade the electrical work and technology in
upgrade
10 East Harlem school buildings as deemed
necessary.
4/20
DSNY
Provide new or
Build a permanent, state-of-the-art dual district
upgrade existing
sanitation garage to service Manhattan
sanitation garages
Community Districts 10 and 11. The new
or other sanitation
building should meet or exceed LEED Gold
infrastructure
standards and be equipped with the most
advanced indoor air filtration systems and zero
emissions sanitation trucks.
5/20
NYCTA
Repair or upgrade
The MTA and City must work aggressively with
East 125
subway stations or
Federal partners to secure funding for Phase 2
Street
other transit
of the Second Avenue Subway in order to ease
Lexington
infrastructure
congestion on the Lexington Avenue lines, and
Avenue
provide and alternative to often unreliable bus
lines.
6/20
DPR
Reconstruct or
The East Harlem Esplanade is slowly
upgrade a park or
deteriorating and falling into the East/Harlem
amenity (i.e.
River and needs major infrastructure
playground, outdoor
improvements to rebuild or reinforce the super-
athletic field)
structure underneath the parkland and the FDR
Drive. Immediate attention should be given to
the 107th Street Pier and the 117th Street
wooden pylons. DOT and the Parks Department
should work collaboratively to achieve this goal.
7/20
DPR
Provide a new, or
Comfort stations should be installed in highly
new expansion to, a
used parks, such as Thomas Jefferson Park near
building in a park
the 114th Street Playground.
8/20
DPR
Reconstruct or
Fund the replacement of the 107th Street Pier to
upgrade a park or
allow it to be safely utilized by the community.
amenity (i.e.
Approximately $28 million is needed to
playground, outdoor
completely rebuild the Pier.
athletic field)
9/20
DOT
Repair or provide
NYC DOT should provide improved street
new street lights
lighting along 104th, 105th and 117th Streets
between Park Avenue and Lexington Avenue;
and 126th Street between Park Avenue and
Madison Avenue. On streets where a thick tree
canopy obscures the effectiveness of tradition
street lights, DOT should install lights that hang
below the level of the tree canopy.
10/20
DPR
Provide a new, or
NYC Parks should provide funding for a new
90-98 EAST
new expansion to, a
playground and a comfort station near 132nd
132 STREET
building in a park
Street and Esplanade as part of the East Harlem
Greenway Link to be created between 125th
and 132nd Streets.
11/20
DOHMH
Other programs to
Increase personnel for needle pick up on 110th,
address public
111th, and 125th streets. Needle pick up must
health issues
also occur near Clinton Houses, Marcus Garvey
requests
Park, and Ronald McNair Park.
12/20
SCA
Renovate interior
Provide a Mechanical, Electrical, and Plumbing
building component
infrastructure upgrade to 10 schools in East
Harlem as deemed necessary.
13/20
EDC
Make infrastructure
Provide funding for the development of a new
investments that
consolidated sanitation garage for Manhattan
will support growth
Community Districts 11 and 10.
in local business
districts
14/20
DPR
Reconstruct or
With the rehabilitation of the Fire Watchtower
upgrade a park or
in Marcus Garvey Park complete, funding must
amenity (i.e.
now be allocated for the reconstruction of the
playground, outdoor
Acropolis, paths, staircases and walls leading up
athletic field)
it.
15/20
DPR
Other requests for
Funding should be allocated to replace the
park, building, or
copper pipes and valves for the onsite water
access
system in Harlem River Park (135- 139th
improvements
Streets).
16/20
NYPL
Create a new, or
In addition to the major renovation that the
renovate or upgrade
125th Street Library branch will undertake in
an existing public
2020, this branch has a shortfall in capital
library
funding for targeted upgrades such as heating
and cooling system updates; new roof, windows,
and doors; fire alarm, security and technology
upgrades; ADA compliance, and elevator
replacements. This additional work will enhance
the patron experience and beautify the
branches exterior and interior to ensure the
comfort of the staff and patrons inside. This
additional cost for this work is $2,900,000.
17/20
BPL
Create a new, or
The 125th Library will be closed for two years
renovate or upgrade
beginning in 2020. Usage will increase at the
an existing public
Aguilar Library as residents seek library services
library
during this two year renovation. In an effort to
ensure that all patrons have accessibility to the
facilities, this branch will upgrade and
rehabilitate the accessibility ramp and entrance
to be ADA compliant. The cost for this work is
$397,000.
18/20
DPR
Reconstruct or
Replace the synthetic turf field at Eugene
upgrade a park or
McCabe Playground using natural materials
amenity (i.e.
(coconut and sand) using the internal budgeting
playground, outdoor
and staffing in the same manner as the quickly
athletic field)
replaced Lion's Gate soccer field in Sara D.
Roosevelt Park.
19/20
FDNY
Other FDNY facilities
Provide additional funding for a Fire Safety
and equipment
Education unit to service East Harlem. The Fire
requests (Capital)
Safety Education Unit is specially trained to
conduct public education and community
outreach. Studies show that the decrease in
death due to fires is directly correlated with
strong public education programs.
20/20
DPR
Improve access to a
Provide funding to make all comfort stations in
parks facility
public parks ADA compliant.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/35
NYCHA
Expand programs
Hire additional inspectors to monitor building
for housing
complaints
inspections to
correct code
violations
2/35
DYCD
Provide, expand, or
Increase the amount of after school program
enhance after
seats in East Harlem, especially for older youths.
school programs for
all grade levels
3/35
DOHMH
Create or promote
CD11 ranks first in the city for psychiatric
programs to de-
hospitalizations (2,016 per 100,000 adults).
stigmatize mental
Funding from the new ThriveNYC initiative
health problems
should be targeted to improve programming in
and encourage
East Harlem. Supportive programs should be
treatment
developed and better targeted to particular
populations to encourage people to reach out
and get help before needing hospitalization so
that their mental health needs can be positively
managed. Programs should provide assistance
with jobs, housing, education, medical issues,
and any other needs that this vulnerable
population may have.
4/35
SBS
Provide or expand
Provide funding for more workforce
occupational skills
development programs.
training programs
5/35
OMB
Other community
Provide funding for baseline Increase the PS and
board facilities and
OTPS budgets of Community Boards to support
staff requests
the vital role they play in planning and quality
of life advocacy for their communities.
Increasing the budget would allow additional
staff to be hired and result in an overall increase
in the quality of responses and services that the
community board provides.
6/35
DOT
Conduct traffic or
Excessive vehicular traffic has created safety
parking studies
problems at key intersections throughout the
community. The DOT should conduct
engineering studies of the major commercial
corridors (125th and 116th Streets), considering
both traffic and parking, with the goal of
improving pedestrian safety and easing
vehicular congestion.
7/35
SBS
Provide or expand
East Harlem's workforce development
occupational skills
infrastructure must address the needs of the
training programs
large number of residents who are unemployed
and seeking well-paying jobs. Local employment
and training organizations and SBS should work
to connect local residents to employment
opportunities in growth industries and local
development-based employment. SBS and EDC
should create and package incentives to attract
growth industries to locate in East Harlem, with
emphasis on attracting STEM related businesses
to open up additional career opportunities for
local residents. SBS must increase funding for
training vouchers, which would then be used by
local residents for necessary advanced training
and certifications. The local libraries can also be
expanded to serve as workforce centers.
8/35
DYCD
Provide, expand, or
In 2019, 70,000 of the 160,000 applicants were
enhance the
able to participate in the Summer Youth
Summer Youth
Employment Program. Increase funding to allow
Employment
for more slots, in order to expand the reach of
Program
the program. Additionally, increase the number
of Work, Learn & Grow program slots in order
to increase the reach of DYCD throughout the
school year.
9/35
SBS
Assist with on-site
City agencies that regularly enforce codes and
business compliance
regulations which impact small businesses must
with City regulations
create forums where local merchants can be
educated on current and changing agency rules
and solicit feedback from merchants with
complaints of unfair treatment. Such agencies
should also ensure that inspectors enforcing
agency rules in East Harlem are bilingual
(particularly Spanish speaking).
10/35
EDC
Other public
Provide funding for the purchase of additional
housing
services vans to aid residents with annual online
maintenance,
re-certification and maintenance requests.
staffing and
management
requests
11/35
DFTA
Enhance home care
Funding is needed to expand services to our
services
multicultural community of low income and
below federal poverty level seniors.
12/35
DOB
Expand code
Provide funding to hire an Assistant Director for
enforcement
the Office of the Tenant Advocate. The focus of
this office must prioritize areas across the city
that have been rezoned including East Harlem.
13/35
SBS
Support local CBOs
Additional resources should be committed to
efforts to provide or
promote East Harlem's cultural offerings,
expand district
including wayfinding signs along Lexington
marketing,
Avenue and other major corridors. The funding
branding, and
for the Avenue NYC program should continue for
promotion
existing place-making and tourism efforts.
14/35
DOB
Expand code
Provide more funding for tenant harassment
enforcement
units.
15/35
DPR
Other park
Funding for the Department of Parks and
programming
Recreation summer maintenance plan must be
requests
maintained at current levels.
16/35
NYCHA
Expand programs
HPD should create a specific program that will
for housing
regularly monitor and inspect the housing
inspections to
conditions of vulnerable seniors, veterans and
correct code
the formerly incarcerated.
violations
17/35
DOHMH
Other animal and
Provide funding for proactive measures to
pest control
mitigate rodent population in public housing,
requests
empty lots, construction areas, and train
stations where rats establish colonies.
18/35
DFTA
Increase case
Provide funding for more caseworkers.
management
capacity
19/35
DPR
Forestry services,
Additional NYC Forestry staff should be hired to
including street tree
maintain the street trees. Funding should also
maintenance
be directed to Trees NY.
20/35
NYPL
Extend library hours
Increase operating funding for libraries to
or expand and
expand 7-day service and ensure that at least
enhance library
one branch in every council district is open 7
programs
days
21/35
DOHMH
Provide more
East Harlem residents are more than three
HIV/AIDS
times as likely to die from HIV/AIDS as the
information and
average NYC resident. Sex education services
services
should be provided, especially among
vulnerable populations, and access to HIV
preventative drugs should be easy and
affordable to all.
22/35
DFTA
Enhance home care
Provide funding to expand hours of home care
services
provided to insure fewer re-hospitalizations
23/35
DPR
Other park
Green Thumb needs additional funding to
programming
properly execute its oversight role and ensure
requests
that community gardens are open to the public.
Additional staff should be hired to assist private
gardens as they transition to GreenThumb
Gardens.
24/35
DPR
Provide better park
Hire seasonal staff via the City Parks Workers to
maintenance
improve maintenance at all Community Parks
Initiative sites.
25/35
DCLA
Support nonprofit
The Department of Cultural Affairs should
cultural
provide seed funding for the creation of an
organizations
arts/cultural service organization in East
Harlem. Once established, and representative of
a cross-section of the East Harlem community,
this organization should work to develop a
comprehensive arts and cultural strategic
master plan for the community.
26/35
EDC
Expand programs
EDC, in collaboration with SBS, should create
for certain
and package incentives to attract growth
industries, e.g.
industries to locate in East Harlem, with
fashion, film,
emphasis on attracting STEM related businesses
advanced and food
to open up additional career opportunities for
manufacturing, life
local residents.
sciences and
healthcare
27/35
DPR
Provide better park
Currently there are no gardeners servicing parks
maintenance
in Manhattan Community Board 11. Hire
additional gardeners to service East Harlem
Parks.
28/35
DFTA
Allocate funds for
Provide funding to ensure faster service for
outreach services to
seniors transitioning from hospital/rehab to
homebound older
home.
adults and for
programs that allow
the elderly to age in
place
29/35
DPR
Other requests for
Provide funding to reinstate the Community
park, building, or
Parks Initiative.
access
improvements
30/35
DOE
Provide, expand, or enhance funding for Child Care and Head Start programs
In lieu of the administration's push for PreK for All, there is a gap of services during the hours between the end of the school day and 5:00 PM. Expand Child Care, Head Start Programs, and 3K and Pre-K for All programs to cover after-school hours.
31/35
SBS
Support local, long- standing businesses
Provide funding for dedicated staff for coordination with Metropolitan Transportation Authority (MTA) on the Second Avenue Subway Phase II outreach and response.
32/35
DFTA
Enhance home care services
Provide funding to expand Expanded In-home Services for the Elderly hours of home care.
33/35
DFTA
Enhance home care services
Provide funding to hire more Spanish speaking home care workers are needed in the community.
34/35
NYCTA
Expand bus service frequency or hours of operation
The most inconsistent bus lines along Madison and Fifth Avenues, particularly the M1, must be improved and made more dependable. NYC Transit must consider changing these routes to originate north of the 59th Street Bridge.
35/35
FDNY
Expand funding for fire prevention and life safety initiatives
Provide additional funding to continue FDNY's "Get Alarmed" program. $1 million for 63,000 alarms to be installed and/or given away.

