## Civic Roam is a public knowledge graph of local civic data and documents about New York City.

[[Search]] the full text of the [[NYC Charter]], [[NYC Administrative Code]], [[Mayor's Management Report - Fiscal Year 2020]], and [[Community District Needs Statement - Fiscal Year 2021]]) all in one place.

[[Suggest]] a document or dataset to be added to Civic Roam.

[[Download]] all of the pages here for use in your [[Roam Research]], [[Obsidian]], or other [[Graph Database]].

Learn more about [[Advanced Search]].
Learn more [[About]] Civic Roam.
[[Contact]] Civic Roam.
