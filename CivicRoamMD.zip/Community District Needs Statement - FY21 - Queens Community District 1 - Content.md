- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 1 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1WkbS7kVQJXZJnYQwI1Op1Mn52Xng_9FU/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1WkbS7kVQJXZJnYQwI1Op1Mn52Xng_9FU/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
3
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 3
image
Address: 82-11 37th Ave, 606
Phone: (718) 458-2707
Email: communityboard3@nyc.rr.com
Website: www.CB3qn.nyc.gov
Chair: Renetta English District Manager: Giovanna A. Reid
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 3 FY2020 District Needs Statement The community is changing but our basic priorities remain the same. Community Board 3’s goal is to enhance the quality of life for all of its residents from our very young to seniors. Community Board 3 is comprised of the neighborhoods of North Corona, East Elmhurst and Jackson Heights, bounded by the Brooklyn- Queens Expressway to the west, Grand Central Parkway to the north, Flushing Meadow Corona Park to the east and Roosevelt Avenue to the south. The district encompasses zip codes 11368, 11369, 11370 and 11372. CB3’s land area is 3.0 square miles and is serviced by the 115th Police Precinct; Sanitation Queens West 3; Fire Engine Company 307/Ladder 154 and Engine Company 316; 17 Public schools; 11 private and parochial schools; 2 postsecondary degree granting institutions; 4 public libraries; 1 private library; 28 Day Care/ Head Start facilities; 11 known mental health facilities; 12 residences that provide services for individuals with developmental disabilities; 9 park/playgrounds; 1 vest pocket park; 7 sitting areas; 8 park strips, Diversity Plaza , 78th Street Play Street and Fisher Pool. The District lies in the shadow of La Guardia Airport, where some of its residents are employed. Airport related uses along a portion of its northernmost street Ditmars Boulevard, are obvious with the presence of hotels such as the Garden Hotel, the Marriott Hotel, the Holiday Inn Crowne Plaza, the Quality Hotel, and on the GCP, the Marriott Courtyard Hotel. National Car Rental maintains a major facility and the Vaughn College- School of Aeronautics is located in the vicinity. Our major shopping districts and commercial corridors are located along Roosevelt Avenue on the southern boundary of the District; Astoria Boulevard on the northern boundary; 37th Avenue, Northern Boulevard, 73 Street; 74th Street, 82nd Street, 90th Street, Junction Boulevard, 103rd Street . The District’s showplaces within the M-1 zone is the Bulova Corporate Center, Home Depot and Bed, Bath and Beyond. Nearby in Flushing Meadow Corona Park, CITIFIELD New York Mets and USTA. Willets Point is a stone’s throw away from our borders. Housing Stock The housing stock is very diversified encompassing brick apartment houses and Tudor style row and two-family homes. Some of the finest, architecturally distinctive dwellings in Queens County and the City can be found in Community Board3, particularly in East Elmhurst and the Jackson Heights neighborhoods. Just to mention a few notable sites; the Jackson Heights Historic District, America’s first planned “garden city” and the Louis Armstrong House/Museum, a national landmark in North Corona. Demographics Community Board 3 is a densely populated and probably the most diverse community on the planet. According to NYU Furman Center, 62.8% of our population is foreign born and the majority of our citizens originate from Latin America. Nearly Forty Eight percent (47.7%) of these residents have limited English proficiency in contrast to the Borough which is at 28.89% and the city of New York at 23.1%. We have the 4th largest population in the city of New York with residents that have limited English proficiency. More services for these constituents is critically needed. The 2010 Census reports that our population is 171.576, which means that our numbers have increased by 1.5%- (2,493) since the 2000 census. It is widely known, however, that New York was severely under-counted in the last census. We therefore believe that NYU Furman Center’s single year indicator for 2013 which projects our population to be at 185,815 is probably a more accurate count. Priorities While there are three distinct neighborhoods, North Corona, East Elmhurst and Jackson Heights, we are all working towards a common goal to improve the quality of life for our families and community. We therefore continue to advocate for our top priorities: - Construct New School Facilities in CB3- Early Childhood Center, Primary and a High School in Willets Point - Clean Up Flushing Bay and Implement the Army Core of Engineers Recommendations - Expand the Capacity of the Jackson Heights Library - Expand the East Elmhurst Library - Expand Corona Library - Construct a Library north of Northern Blvd. within Jackson Heights & East Elmhurst. - Create Affordable Housing - Reconstruct/Repair Sewers to Alleviate Backups and Flooding - Construct an Intergenerational Facility in Jackson Heights that will accommodate both youth and seniors (Boys and Girls Club) - Increase Youth Programs - Increase Senior Programs - Increase Hospital Beds - Expand Medical Services at the Corona Health Center - Increase Police Personnel at the 115th Precinct - Increase park and open space in Community Board 3, particularly in Jackson Heights - Conduct a Commercial District Needs Assessment - Construct a Performance Arts Center above the Jackson Heights Post Office
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 3
image
The three most pressing issues facing this Community Board are:
Affordable housing
There are many issues facing Community Board 3 affordable housing, senior services, health services, school overcrowding, quality of life and neighborhood preservation. It is impossible to narrow our concerns down to a few issues. All the aforementioned are important to the success of our community. Affordable Housing: According to the NYU Furman Center for renter households Community Board 3 ranks number one citywide for severe crowding.
Clearly the creation of affordable housing is important for our district.
Schools
School Overcrowding: Our primary and intermediate schools feed into severely overcrowded high schools that are located outside of the District. Community Board 3’s highest priority is to provide a first class education for our children. In order to accomplish that goal, we must first address overcrowding on all levels from elementary, intermediate to high school. Census projections indicate more overcrowding is on the horizon. While we have been fortunate to have classrooms added, along with a new elementary and intermediate school on the way; additional schools are needed. We therefore continue to advocate for more schools and keep education as our top priority.
Senior services
Senior Services: Seniors comprise 9.9 % of our overall population, transportation, mental health services, home care and escort services are urgently needed. Funding must be increased in order to ensure that our seniors receive the services that they require.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 3
image
M ost Important Issue Related to Health Care and Human Services
Other
Elder Abuse
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
As per the Department of Health, community health profiles 2015, 38% of adults that reside in Community Board 3 do not have health insurance. We have the highest rate within the city. That is why, it is important that the Corona Health Center's services be enhanced. Upgrade and expand services at the Corona Health Center. The majority of the residents in the catchment area of the center are either under or uninsured and in dire need of medical assistance. Reinstate the dental clinic and expand services to include primary care , free screenings for eye, ear, sickle cell anemia, asthma, diabetes, cholesterol, prostate and breast cancer. Promote education and awareness on nutrition, smoking cessation, mental health and treatment. A full service clinic is urgently needed in North Corona. Constituents residing in this section of the district do not have the means to travel to the health center that is located in Brooklyn; it is the only city operated facility that is offering these critical services. Increase Hospital Beds at Elmhurst Hospital and Borough-Wide Since 2008, five hospitals have closed in the Borough of Queens. Our area hospital is feeling the impact. Elmhurst Hospital is now accommodating many of the patients that used to go to the hospitals that are now closed. Elmhurst Hospital reports that in the last 7 years the emergency department volumes have gone up 33% which is very significant. Patient wait time has considerably increased. Additional hospital beds and expansion of the emergency room is sorely needed. Although Urgent Care facilities are opening around the board area and borough, it does not diminish the fact that more hospitals and the services that they provide are still needed.
Needs for Older NYs
Senior Services The senior members of our district make up nearly 10% of our population. In addition to home care, escort services, transportation and mental health services, seniors need assistance with legal and benefit services. Funding levels for DFTA and related agencies that provide these critical services must be increased.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
17/30
DOHMH
Increase health
Request: Hire additional Department of Health
inspections, e.g. for
Inspectors to conduct night inspections.
restaurants
Explanation: Unlicensed food vending along
Roosevelt Ave, Broadway, 74th and 37th
Avenues are increasing. The community would
benefit from having more inspections conducted
particularly at night where the problem is most
prevalent.
18/30
DFTA
Enhance NORC
Request: Provide funding to increase NORC
programs and
(Naturally Occurring Retirement Community)
health services
Programming in CB3. Explanation: Seniors are
the second largest population within CB3. It is
important that senior programming such as
NORC be made available to our elder residents.
Providing health and social services within the
confines of their coop/apartment complex
would significantly improve their quality of life.
CS
HHC
Renovate or
Request: Increase hospital beds in the Borough
7901
upgrade an existing
of Queens and upgrade the emergency room at
Broadway
health care facility
Elmhurst Hospital. With the closing of several
Hospitals in the Borough of Queens, area
hospitals such as Elmhurst Hospital are feeling
the impact. Additional hospital beds are sorely
needed.
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 3
image
M ost Important Issue Related to Youth, Education and Child Welfare
After school programs
Increase Funding for After School Programs. Working parents who have school aged children need these important services. In today's world, both parents are required to work and financially contribute to the household income. Children who participate in after school programs are assured of being in a safe and nurturing environment where they have homework assistance, recreation and an opportunity to spend time with their peers. After school programs are sorely needed.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Eliminate School Overcrowding Community Board3’s highest priority is to provide a first class education for our children. In order to accomplish that goal, we must first address overcrowding on all levels from elementary, intermediate to high school. Overcrowding in our neighborhood schools have been a problem for many years. The utilization rate for P. S. 228 is 173%, P. S. 212 is 139% and P. S. 222 is 139%. Census projections indicate more overcrowding is on the horizon. While we have been fortunate to have more seats added, along with a new elementary and intermediate school on the way; additional schools are still needed. We therefore will continue to advocate for more schools and keep education as our top priority.
Needs for Youth and Child Welfare
Affordable Child Care Affordable child care services are vital to working families. Parents who have children under the age of four rely on these hard to find services. In order to support our moderate income families; fully fund and open up additional day care facilities.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
1/30 SCA Provide a new or
expand an existing elementary school
Request: Construct new school facilities in CB3, especially Early Childhood Centers, and a High School at Willits Point and the former DiBlasi Ford site. Explanation: We are pleased that two new sites have been earmarked for the construction of an elementary & intermediate school; every seat will be utilized. Overcrowding of classrooms is still our most pressing problem and must be addressed. The need for additional school seats and the construction of a high school remains our first priority. An ideal location for a high school is Willets Point.
Another potential site would be the former
DeBlasi Ford car dealership located on Northern Boulevard and 114th Street.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
4/30
DYCD
Other youth
Request: Restore and Increase funding for
workforce
youth, adult and senior programming in Jackson
development
Heights, North Corona and East Elmhurst.
requests
Explanation: There is a severe shortage of
programs in CD3 that cater to the recreational
needs of our youth and seniors. Our community
deserves quality facilities and programming
that will enrich our lives.
8/30
DOE
Provide, expand, or
Request: Restore Day Care Slots and after school
enhance funding for
programs. Explanation: Our Community's
Child Care and Head
population has increased. Many of our young
Start programs
working families require day care services &
after school programs. Working parents deserve
programs that will serve the needs of their pre-
school children ages three months to five years
old.
23/30
DOE
Other educational
STEAM is a method of instruction that
programs requests
incorporates Science, Technology, Engineering,
the Arts, and Mathematics and helps to
promote student critical thinking. Every
classroom should have access to these
important resources.
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 3
image
M ost Important Issue Related to Public Safety and Emergency Services
Fire Safety
Community Board 3 supports the funding of the fire prevention and fire safety initiatives Juvenile Fire-Setters Program, Queens Fire Safety House and the Fatal Fire Team. In addition, our fire stations need upgrading.Replace the apparatus door and upgrade the kitchen. Ensure that the project is fully funded and done as expeditiously as possible. Lastly, purchase a backup generator for the 307.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Police Department Community Board 3 continues to support the Roosevelt Avenue Task Force. Keep the Roosevelt Avenue Task Force and Impact Zone initiatives in place. Our local precinct is doing an outstanding job but could benefit from an increase in personnel and additional resources. Hire civilians to cover administrative duities so that police officers can l be freed up to address crime and quality of life complaints. School Crossing Guards. Hire additional school crossing guards to cover all of our area schools. The NCO program was recently implemented in Community Board 3. We see the value of the program and its potential to make a significant impact on the quality of life of our residents. That is why, we support the proposal to have additional NCO personnel so there will be 24 hour/seven days per week coverage. We hope that serious consideration is given to our request.
Needs for Emergency Services
Fund FDNY's Smoke and Carbon Monoxide Detectors Distribution Program Community Board 3 supports this life saving program.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
18/30
FDNY
Upgrade
Replace the apparatus door.
8119
communication
Northern Blvd
equipment to
improve emergency
response
20/30
FDNY
Other FDNY facilities
Upgrade the FDNY Engine 307/154 kitchen.
8119
and equipment
Northern Blvd
requests (Capital)
22/30
FDNY
Other FDNY facilities
Purchase a Back-up Generator for 307.
8119
and equipment
Northern Blvd
requests (Capital)
28/30
NYPD
Other NYPD
The 115th Precinct does not have a tower
92-15
facilities and
dedicated for the district's use. Often times, the
Northern
equipment requests
equipment is not available when needed. It
blvd.
(Capital)
makes sense to purchase this much needed
apparatus.to ensure that our local precinct has
its own.
29/30
NYPD
Provide surveillance
Install cameras at the overpasses located at
cameras
27th & 31st drive on Ditmars Blvd.
30/30
FDNY
Provide new
Purchase a medical service vehicle for
emergency vehicles,
FDNY/EMS which will serve the Borough of
such as fire trucks or
Queens, Approximately 10 patients can be
ambulances
accommodated at one time. The current vehicle
is over twenty years.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
6/30
NYPD
Assign additional
Request: Hire additional uniform personnel.
92-15
uniformed officers
NCO officers, administrative aides, custodial
Northern Blvd
personnel and school safety guards.
Explanation: Hire additional custodial personnel
for the 115 precinct. The additional staff will
improve the precinct's day to day operations
and upkeep.
25/30 FDNY Other FDNY facilities
and equipment requests (Expense)
Purchase a Medical Services Vehicle - FDNY/EMS for the Borough of Queens (for 10 patients at a time can be attended to on this mobile vehicle). Existing vehicle is over 29 years old.
image
26/30 FDNY Other FDNY facilities
and equipment requests (Expense)
Purchase for FDNY - Medical Aide Rapid Response Vehicle - For city wide use state of the art vehicle that will transport equipment and supplies in emergency situations.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 3
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Air quality and pollution
Air Pollution Monitors CB3 is surrounded by Laguardia Airport, BQE andGrand Central Parkway. Our residents are concerned about the impact of fumes emitting from motor vehicles and planes in the community. There is a high incidence of asthma & respiratory disease in our district. The need to install air monitors in our area is clear
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Water, Sewer and Environmental Protection Clean Up Flushing Bay, Build an Additional CSO Tank in order to Dredge, Reduce Odors and Improve Water Quality. The environmental studies and recommendations on the ecological decline of Flushing Bay must be acted upon expeditiously. We call upon the City to build a CSO tank so the bay can be dredged-and the Army Corp of Engineers odor abatement recommendations can be implemented. Our objective is to bring Flushing Bay back to its Pre-World’s Fair (1964) condition and suitable for reacreational uses.. Catch Basins In order to reduce the incidence of costly emergency repairs, a regular maintenance and cleaning schedule must be established and adhered to. .Fund A Study For The Replacement of The Combined Sewer System In CB3.
Conduct a study to determine the feasibility to change out the existing combined sewer system to a storm sewer. Over the years, the incidence of flooding and sewer backups have been more frequent. In previous years, sewer backup conditions and flooding were more prevalent in East Elmhurst and North Corona where there were primarily 1-2 family homes. Today, flooding and backups can occur in any part of the district whenever there are heavy. because of the extensive development. We ask DEP to give serious consideration of our request.
Needs for Sanitation Services
Increase Litter Basket Collections Along Our Commercial Strips In order to improve the level of cleanliness throughout the district, increase litter basket collection to three times per day. Urgent attention is needed along 37th Ave.; Junction Blvd.; Roosevelt Ave.; Northern Blvd.; 103rd St. and 74th Streets; Astoria Blvd, 73rd Street and 72nd Street in Jackson Heights. Providing these additional services will have a positive impact on the affected businesses and overall community.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation Location
2/30
DEP
Investigate odor
Request: Construct Additional Holding / CSO
complaints about a
Tanks in Flushing Bay In Oder to Reduce Odors,
wastewater facility
Improve Water Flow and Quality. Explanation:
and address/repair
Construct additional holding tanks in Flushing
or make equipment
Bay in order to reduce the amount of waste
improvements as
entering into the bay. The holding tanks must be
needed (Capital)
put in place before the Bay is dredged and the
Army Corp of Engineers recommendations are
implemented.
17/30
DEP
Investigate odor
Employ interim measures to control floatables
complaints about a
going into Flushing Bay and restore the
wastewater facility
wetlands
and address/repair
or make equipment
improvements as
needed (Capital)
CS
DEP
Inspect sanitary
Request: Fund a Study For The Construction of a
sewer on specific
Separate Sewer System for 103rd & Northern
street segment and
Blvd., 25th Avenue & 81st Street, 77th Street &
repair or replace as
30th Avenue, 25th Avenue and 77th Street and
needed (Capital)
25th Avenue and 76th Street. Explanation:
Neighborhoods that were once comprised of
one & two family homes have been replaced
with units of six to ten families. These changes
have increased the demand on our
infrastructure & sewer system. Before 1996,
conditions were confined to East Elmhurst or
North of Northern Blvd. Sewer backup
conditions are now district-wide.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
1/30
DEP
Investigate air
Request: Install Air Monitors in the
quality complaints
Neighborhoods of Jackson Heights and East
at specific location
Elmhurst that are located near LaGuardia
Airport. Explanation: CB3 is surrounded by
Laguardia Airport, BQE andGrand Central
Parkway. Our residents are concerned about the
impact of fumes emanating from motor vehicles
and planes in the community. There is a high
incidence of asthma & respiratory disease in our
district. The need to install air monitors in our
area is clear.
3/30
DSNY
Provide more
Restore litter basket collections to three times
frequent litter
per day in our commercial strips – 37th Ave;
basket collection
Junction Blvd; Roosevelt Ave; Northern Blvd;
103rd Street; and 74th Street; Astoria Blvd.,
73rd and 72nd Streets in Jackson Heights. Hire
additional personnel for 11am- 7pm shift in
order to increase litter basket patrol truck
service particularly during weekends.
21/30
DSNY
Provide more
Increase sanitation residential collections to 3
frequent garbage or
times per week
recycling pick-up
22/30
DSNY
Other garbage
Increase funding for additional cleaning services
collection and
to Roosevelt Ave from 69th to 114th Streets.
recycling
infrastructure
requests (Expense)
24/30
DEP
Inspect sanitary
Increase DEP sewer and water unit personnel
sewer on specific
street segment and
repair or replace as
needed (Expense)
27/30
DSNY
Other cleaning
Provide funding for MLP service in section 31.
requests
The monies would allow sanitation to provide
additonal services to the streets located in this
section of the district.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 3
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
Affordable Housing and Homelessness Across the city, the incidence of homelessness has increased and is climbing because of the lack of affordable housing. In our district, affordable housing is one of our top concerns because there are few affordable housing units. According to the Furman report more than 53.3% of our population pay 35% or more of their income for rent. In addition, 25.5% of our residents live below the poverty level. For many of these families, it is a struggle each month. They have to make the difficult decision as to whether to pay the rent or forgo other essential needs. They are always at risk for eviction and homelessness. Our housing courts tell the story; there is a disproportionate number of minority, low income and at risk individuals in housing court. Many cannot afford an attorney and end up losing their homes. We are in a housing crisis, fewer affordable units are being developed and the focus now is to build luxury market rate apartments that cater to wealthier clientele. While there is housing construction all over the district none of the developments are intended for low to middle income families. To add to the mix, some unscrupulous landlords are forcing out families that are poor, have fixed incomes, those who cannot afford the higher rents, many seniors and disabled individuals have been impacted. Further, some of the participating property owners are opting out of the rent stabilization program. Community Board 3 therefore calls upon the City of New York to put systems in place to encourage the development of affordable housing. More has to be done, set a plan of action to encourage landlords to remain in the rent stabilization program. Develop incentives to attract new property owners to participate in rent stabilization. We critically need more affordable housing and ask that urgent attention be given to this important issue.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
: Increase staffing levels for Administrative & Community Outreach Units. Additional administrative and community personnel is needed to improve the agency's ability to disseminate information and work with property owners.
Needs for Housing
Construct Affordable Housing for Middle, Low Income Families and Seniors Around the district new buildings are going up, but nearly none of are affordable. A recent survey reported that “49 % of Queens residents shell out as much as 48% of their income on housing." In CB3, the average rental rate for apartments is approximately $1600 a month for one bedroom, which is far out of range for most working families. Young people who were born and raised in our community and seniors on fixed incomes cannot afford to live in the District. There is a urgent need for mid-low income housing facilities. We have noted that in order to pay expensive rents families are doubling and tripling up in apartments and houses. We need affordable housing that will fit in and support the needs of the existing community. Strategies and programs must be developed to stimulate the production of affordable housing facilities. Employ programs such as No property taxes for 5 years to encourage the development of affordable housing.
Needs for Economic Development
Conduct a Commercial District Needs Assessment- Last winter Community Board 3 conducted a forum for our area businesses. There was a good turnout, many of the operator’s questions centered around gaining access to capital, taxes, high rental rates, marketing, doing business with the City of New York and merchant organizing. CB3 requests that funding be provided to conduct a Commercial District Needs Assessment to support our local businesses.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
4/30 HPD Other affordable
housing programs requests (capital)
Request: Construct Affordable Housing for Middle & Low-Income seniors. Explanation: Strategies and programs must be developed to stimulate the production of new/affordable housing facilities. There is a severe shortage of housing for the aforementioned income groups.
image
5/30 HPD Provide more
housing for extremely low and low income households
Construct affordable housing for low income families. Explanation: Strategies and programs must be developed to stimulate the production of new/affordable housing facilities. There is a severe shortage of housing for the aforementioned income group.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
7/30
EDC
Expand graffiti
Request: Increase Graffiti Removal Programs.
removal services on
Explanation: To combat the increased incidence
private sites
of graffiti CD3, Additional monies are needed
to these support programs.
13/30
NYCHA
Expand programs
HPD - Hire additional inspectors to address code
for housing
enforcement, demolition and seal-up
inspections to
complaints.
correct code
violations
30/30
SBS
Other business
Implement Economic Development programs
regulatory
which would include entrepreneurial training,
assistance requests
loan packaging, micro Loan Program,
management training, export assistance..
Assistance is needed to coordinate
neighborhood redevelopment, marketing &
anti-graffiti programs. Funding these programs
would make a significant difference for the
business community in CB3..
TRANSPORTATION
Queens Community Board 3
image
M ost Important Issue Related to Transportation and Mobility
Other
District Wide Traffic Study
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Upgrade street lights located along Roosevelt Avenue from 72nd to 114th Streets. The recently installed streetlights are directed towards the street leaving the sidewalks very dark. Residents including NYPD are concerned about the unsafe conditions that could be caused due to poor or no lighting on the sidewalks. The illumination of the street lights are blocked by the elevated number 7 subway line. Enhance street lighting by installing pedestrian lights on Roosevelt Avenue at the aforementioned locations as expeditiously as possible.
Needs for Transit Services
Community Board 3 was recently made aware of MTA’s plan to modify the route for the Q32 bus line. The route will be shorten, instead of terminating at 32 Street and 7th Avenue in Manhattan the last stop will be 52nd Street and Fifth Avenue. The change will pose a major hardship for the users of this bus route. The Q32 is the only bus in our district that goes to 34th Street in Manhattan. Our seniors and mobility challenged residents are the primary users of the service. Having to transfer twice to other buses, pay an additional fare or use the subway system to continue their trip to 34th Street is not feasible. If this one stop service to Macy's, Amtrak and the 7th Avenue shopping district is curtailed our vulnerable residents will have no other means to get to their destination short of paying for an expensive cab ride. We call upon the MTA to reevaluate their plan and come up with a workable solution that will serve all of its customers.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
7/30
DOT
Other capital traffic
Traffic Study of the Grand Central Parkway exist
114th Street
improvements
located at 114th Street and Northern Blvd.
114th Street
requests
and Northern
Blvd.
8/30
DOT
Other capital traffic
Provide funding to study 114th Street and
114th Street
improvements
Astoria Blvd. located at the entrance to the GCP.
& Astoria
requests
Blvd.
9/30
DOT
Upgrade or create
Request: Beautify the center mall on Astoria
Astoria
new greenways
Boulevard. Explanation: Plant Shrubs & trees
Boulevard 82
along the Center Mall from 82 Street to 114
Street 114
Streets at Astoria Boulevard to increase
Street
greenery and beautify the community. Most
importantly, improve conditions so that
pedestrians may safely access Astoria
Boulevard. Provide funding to a not-for-profit
organization such as the Botanical Gardens to
maintain the greenery.
10/30
DOT
Upgrade or create
Request: Beautify the Center Mall on 34th
34 Street 112
new greenways
Avenue from 112th to 114th streets.
Street 114
Explanation: Plant shrubs and trees to increase
Street
greenery. Provide funding to a not-for-profit
organization to maintain the site.
12/30
DOT
Repair or build new
Redesign Step Street at Butler/Ditmars Blvd. The
25 Avenue
step streets
25th Ave step street could use a face-lift, which
and Butler
would entail improved lighting, seating areas,
Street
pruning and planting of additional greenery.
The proposed enhancements would attract
more users of this important public space.
13/30
DOT
Repair or construct
Request: Provide funding for curb repair.
new curbs or
Explanation: While the property owner is
pedestrian ramps
responsible for the repair of sidewalks and
encouraged to replace curbs, all too often,
violations go unaddressed because of financial
difficulties or neglect. Unsafe conditions are left
to the city to be corrected. It is therefore
important that funding to hire more outside
contractors to perform sidewalk and curb
repairs be increase.
14/30
DOT
Repair or construct new medians or bus pads
Request: Provide funding for bus pads. Explanation: Provide sufficient funding for the replacement of defective bus pads in areas where there is a high volume of traffic.
16/30
DOT
Improve traffic and
Install additional lights along Roosevelt Ave
pedestrian safety,
from 72nd to 112th Streets
including traffic
calming (Capital)
21/30
DOT
Repair or provide
Add Street Lights from Junction Boulevard to
new street lights
Roosevelt Avenue.
23/30
DOT
Other capital traffic
District Wide traffic study
improvements
requests
24/30
DOT
Other capital traffic
Re-evaluate traffic conditions along 75th to
75th to 78th
improvements
78th Streets and 31st Ave.
Streets 31st
requests
Ave
CS
DOT
Reconstruct streets
Request: Resurface Streets in Community Board
86th Street
3. Explanation: Resurface Northern Blvd. from
25th Avenue
Junction Blvd. to 114th street. Junction Blvd.
30th Avenue
between Northern and Roosevelt Avenues, 37th
Ave from Junction Blvd. to 114th Street, 82nd
Street from Roosevelt Ave to the BQE, Roosevelt
Ave from 114th to 69th Streets and Astoria Blvd.
from 69th to 114th Streets.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
11/30
DOT
Improve traffic and
Request: Increase funding to hire additional
pedestrian safety,
personnel to install, replace traffic/street signs,
including traffic
repair pot holes for Queens DOT Explanation:
calming (Expense)
Increase funding to hire personnel for sign
replacement and pothole repair.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 3
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
Hire Additional Park Associates
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Open Space/Recreational Facilities and Programs Our community needs and deserves more park space. It is well documented that CB3.Queens comes in second citywide as to having the least amount of park space. PlanNYC indicates that Community Board3’s open space is at .04 acres per 1000 residents, particularly in Jackson Heights. Combining the acreage of our athletic fields, courts, passive open spaces and community gardens totals .16 per 1000 resident. CB3 is woefully below the open space requirements set by NYC Neighborhood Standards. We are committed to finding creative ways in which to increase public spaces and recreational programming within our district. We have supported expanding our public space by converting local streets into temporary playstreets/plazas and purchased private property to enlarge a local park, i.e. 78th Street Playstreet, Diversity Plaza and Rory Staunton Field. While we are grateful for what has been accomplished thus far additional park space is sorely needed. We ask that funding be provided so that new sites can be identified and developed.
Needs for Cultural Services
Louis Armstrong House Museum- Education Visitor Center The Louis Armstrong House Museum is a National Historic Landmark and a New York City landmark. It is the only landmark located within the confines of Community Board3 LAMH is located in the heart of North Corona. It is reported that the museum hosts over 12,500 visitors each year. The Visitor’s Center is in its final stages of development. The new addition will allow the institution to accommodate more visitors; large groups, provide housing for the storage of the Louis Armstrong archives and expand programming to include concerts and forums. The current space is too small to conduct the aforementioned activities. Community Board 3 fully supports this project. We request that the construction of the n Visitor’s Center be fully funded; that work commence expeditiously and opened before the close of FY2017.
Needs for Library Services
Libraries Community Board 3 has four libraries and all are well utilized. The Center for Urban Future indicates that in 2014 visitors to the Jackson Heights branch exceeded 445,970, North Corona 240,466., Langston Hughes 168,849 and East Elmhurst 66,595. Our residents both adults and children rely on our local libraries for iemployment information, cultural and educational programs and general access to the internet. Libraries have always been one of our top priorities. We are pleased to see that our local facilities will be opened six days a week. We now look forward to the advancement of the following projects: The expansion of the Jackson Heights Library, the children’s center is extremely overcrowded; consideration should be given to constructing an annex that will be located close to the existing facility. The Jackson Heights facility is the most heavily utilized branch in North West Queens. The East Elmhurst Branch urgently needs a cultural facility. The project has been on the books since 1999. While the land has been acquired, and design completed ; there has not been any movement towards construction. The community is eagerly looking forward to the completion of the cultural center and opening in FY 2017. In the North West Section of CB3 there are no library facilities. The residents in this portion of the district are sorely lacking library services. Residents who live north of Northern Boulevard must travel a distance. Constituents complain that they would use library serves more frequently if there were a facility closer to their neighborhood. We ask that the QPL System seriously consider of our requests and move the aforementioned projects forward.
Needs for Community Boards
Increase Funding Levels for Community Boards and Provide Community Boards with Access to 311 Data Specific to Each Board Area (Include Addresses) . Explanation: Community Boards are understaffed, underfunded and have always worked with less even during times of prosperity. An increase in funding levels for Community Boards would
be in order. In addition, the advent of Hurricane Sandy and Irene underscored the need for improved communications with 311. We need the ability to retrieve information from the 311 data base in order to analyze conditions that impact our community.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/30
QL
Create a new, or
Construct a new building and expand the
35-51 81
renovate or upgrade
capacity of the Jackson Heights Regional Library
Street
an existing public
keep allocation in place. Explanation: The
library
Jackson Heights Branch is the most heavily
utilized library facility in Northwest Queens. The
library is the home to the most ethnically
diverse population in the City. Space for
expansion is available behind the present
structure. A new facility will significantly reduce
overcrowding.
6/30
QL
Create a new, or
Request: Construct Library in North West Sector
renovate or upgrade
of CB3. The Lexington School for the Deaf should
an existing public
be considered for a possible site. Explanation:
library
The residents in this portion of the District are
sorely lacking library facilities.
11/30
DPR
Other park
Develop unused property located near the 94th
94 Street and
programming
Street entrance to the GCP for a dog park.
Ditmars
requests
Explanation: Residents in this area would like to
Boulevard
have a dog park developed on the unused
property fronting the entrance to the Grand
Central Parkway and 94th street. There is no
facility in the immediate area.
15/30
DCAS
Renovate, upgrade
Convert Community Board's paper documents
or provide new
to electronic files. Explanation: Digitize
community board
community board's paper files. storage of paper
facilities and
documents is becoming increasingly difficult.
equipment
Our offices are usually small with little room to
add more file cabinets. Help bring community
boards' offices into the 21st century.
19/30
DPR
Other park
Upgrade Veterans Plaza (32nd Ave & 94th
32 Ave and 94
maintenance and
Street) sitting area to a recreational space for
Street
safety requests
children and adults.
25/30
DCLA
Other cultural
Construct a Community Performance Arts
facilities and
Center in Jackson Heights. The new facility
resources requests
would host local and international artists and
(Capital)
could be the home of the Jackson Heights
Orchester.
26/30
DPR
Reconstruct or
Gorman Park has received funding for the rehab
84th Street
upgrade a park or
of the playground. In FY2021 provide funding
and 25th
amenity (i.e.
for phase !!, upgrading the volleyball, basketball
Avenue
playground, outdoor
and handball courts. Further, repair catch basin
athletic field)
and eliminate ponding and sewer backup
conditions.
27/30
DPR
Reconstruct or
Upgrade Northern Playground (Including play
upgrade a parks
equipment, restrooms and sitting area)
facility
CS
QL
Create a new, or
Request: Expand East Elmhurst Library.
95-06 Astoria
renovate or upgrade
Explanation: The East Elmhurst Community
Blvd
an existing public
urgently needs a cultural facility and the
library
expansion of the library to accommodate the
increase in users. Proceed with the final phase
of the expansion; construction by the start of FY
2017
CS
QL
Create a new, or
Request: Expand Corona Library Explanation:
38-23 104 St
renovate or upgrade
This heavily used facility is one of only four
an existing public
libraries in community Board 3. Whether
library
expansion entails building up or acquiring
adjacent property, the new addition would be
welcomed.
CS
DPR
Other park
Continued Support: Repair the drainage at
programming
Flushing Meadows Corona Park.
requests
CS
DPR
Other park
Continued Support - Restore the Queens Green
programming
House at Forest Park.
requests
CS
DCLA
Support nonprofit
Construct a Visitor Center for Louis Armstrong
34-56 107
cultural
House Museum. Explanation: We request that
Street
organizations
the construction of the Visitor Center be fully
funded and work commence expeditiously.
Community Board 3 fully supports this project.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/30
QL
Extend library hours
Request: Keep Queens Libraries Open 7 Days a
or expand and
week with one late night closing at 10:00pm.
enhance library
Explanation: Our libraries are heavily utilized
programs
and do not meet the needs of CB3 constituents.
Provide funding to restore our libraries to full
operational capacity.
5/30
DPR
Other park
Request: Increase parks staffing levels for
programming
maintenance personnel. Hire a parks associates
requests
for PS 127 and Junction Boulevard parks and
assistant gardener. Explanation: CB3 requires
additional associates in our area parks.
currently there are only two associates in the
entire district, Gorman park and Travers. Our
community has increased by 40,000 residents,
we deserve more programs and services.
14/30
DPR
New equipment for
Cont. Support: Purchase a Wenger Wagon -
maintenance
Provide funding for the purchase of a Wenger
(Expense)
Wagon. Community groups depend on the parks
department to provide an inexpensive way of
showcasing their events. The Borough could use
more than one mobile stage.
15/30
DPR
Reconstruct or
Request: Install free WIFI in CB3 parks and
upgrade a building
Plazas. Explanation: Upgrade our area parks by
in a park
installing free WIFI services. Keep park users
plugged in and informed.
20/30
DPR
New equipment for
Request: Purchase a (1) Cab Pick-Up .
maintenance
Explanation: The purchase of this critical
(Expense)
equipment will make a significant improvement
on Parks day to day operations.
28/30
DPR
Other park
Funding for tihs program will provide staffing to
maintenance and
maintain the park landscapes,gardens, lawns
safety requests
and other horticultural amenities.
29/30
DPR
Enhance park safety
Request: Extend fencing at Northern Boulevard
through design
Playground. Explanation: Part of the fencing at
interventions, e.g.
this playground is chain linked and the balance
better lighting
is wrought iron. Remove the chain linked
(Expense)
portion of the fence and replace it with wrought
iron for safety and aesthetic reasons.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
9/30
Other
Other expense budget request
Improve access to government services and information by sharing 311 data with Community Boards.
10/30
Other
Other expense budget request
Re-establish Neighborhood Business Development programs.
12/30
Other
Other expense budget request
Increase staffing Level for DOB Compliance Unit.
16/30
Other
Other expense budget request
Hire Additional Consumer Affairs agents to conduct night and weekend street vending inspections.
19/30
Other
Other expense budget request
Retrofit Apartment for Seniors. (Incentive Tax Abatement for Owners)
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/30
SCA
Provide a new or
Request: Construct new school facilities in CB3,
expand an existing
especially Early Childhood Centers, and a High
elementary school
School at Willits Point and the former DiBlasi
Ford site. Explanation: We are pleased that two
new sites have been earmarked for the
construction of an elementary & intermediate
school; every seat will be utilized. Overcrowding
of classrooms is still our most pressing problem
and must be addressed. The need for additional
school seats and the construction of a high
school remains our first priority. An ideal
location for a high school is Willets Point.
Another potential site would be the former
DeBlasi Ford car dealership located on Northern
Boulevard and 114th Street.
2/30
DEP
Investigate odor
Request: Construct Additional Holding / CSO
complaints about a
Tanks in Flushing Bay In Oder to Reduce Odors,
wastewater facility
Improve Water Flow and Quality. Explanation:
and address/repair
Construct additional holding tanks in Flushing
or make equipment
Bay in order to reduce the amount of waste
improvements as
entering into the bay. The holding tanks must be
needed (Capital)
put in place before the Bay is dredged and the
Army Corp of Engineers recommendations are
implemented.
3/30
QL
Create a new, or
Construct a new building and expand the
35-51 81
renovate or upgrade
capacity of the Jackson Heights Regional Library
Street
an existing public
keep allocation in place. Explanation: The
library
Jackson Heights Branch is the most heavily
utilized library facility in Northwest Queens. The
library is the home to the most ethnically
diverse population in the City. Space for
expansion is available behind the present
structure. A new facility will significantly reduce
overcrowding.
4/30
HPD
Other affordable
Request: Construct Affordable Housing for
housing programs
Middle & Low-Income seniors. Explanation:
requests (capital)
Strategies and programs must be developed to
stimulate the production of new/affordable
housing facilities. There is a severe shortage of
housing for the aforementioned income groups.
5/30
HPD
Provide more
Construct affordable housing for low income
housing for
families. Explanation: Strategies and programs
extremely low and
must be developed to stimulate the production
low income
of new/affordable housing facilities. There is a
households
severe shortage of housing for the
aforementioned income group.
6/30
QL
Create a new, or
Request: Construct Library in North West Sector
renovate or upgrade
of CB3. The Lexington School for the Deaf should
an existing public
be considered for a possible site. Explanation:
library
The residents in this portion of the District are
sorely lacking library facilities.
7/30
DOT
Other capital traffic
Traffic Study of the Grand Central Parkway exist
114th Street
improvements
located at 114th Street and Northern Blvd.
114th Street
requests
and Northern
Blvd.
8/30
DOT
Other capital traffic
Provide funding to study 114th Street and
114th Street
improvements
Astoria Blvd. located at the entrance to the GCP.
& Astoria
requests
Blvd.
9/30
DOT
Upgrade or create
Request: Beautify the center mall on Astoria
Astoria
new greenways
Boulevard. Explanation: Plant Shrubs & trees
Boulevard 82
along the Center Mall from 82 Street to 114
Street 114
Streets at Astoria Boulevard to increase
Street
greenery and beautify the community. Most
importantly, improve conditions so that
pedestrians may safely access Astoria
Boulevard. Provide funding to a not-for-profit
organization such as the Botanical Gardens to
maintain the greenery.
10/30
DOT
Upgrade or create
Request: Beautify the Center Mall on 34th
34 Street 112
new greenways
Avenue from 112th to 114th streets.
Street 114
Explanation: Plant shrubs and trees to increase
Street
greenery. Provide funding to a not-for-profit
organization to maintain the site.
11/30
DPR
Other park
Develop unused property located near the 94th
94 Street and
programming
Street entrance to the GCP for a dog park.
Ditmars
requests
Explanation: Residents in this area would like to
Boulevard
have a dog park developed on the unused
property fronting the entrance to the Grand
Central Parkway and 94th street. There is no
facility in the immediate area.
12/30
DOT
Repair or build new
Redesign Step Street at Butler/Ditmars Blvd. The
25 Avenue
step streets
25th Ave step street could use a face-lift, which
and Butler
would entail improved lighting, seating areas,
Street
pruning and planting of additional greenery.
The proposed enhancements would attract
more users of this important public space.
13/30
DOT
Repair or construct
Request: Provide funding for curb repair.
new curbs or
Explanation: While the property owner is
pedestrian ramps
responsible for the repair of sidewalks and
encouraged to replace curbs, all too often,
violations go unaddressed because of financial
difficulties or neglect. Unsafe conditions are left
to the city to be corrected. It is therefore
important that funding to hire more outside
contractors to perform sidewalk and curb
repairs be increase.
14/30
DOT
Repair or construct
Request: Provide funding for bus pads.
new medians or bus
Explanation: Provide sufficient funding for the
pads
replacement of defective bus pads in areas
where there is a high volume of traffic.
15/30
DCAS
Renovate, upgrade
Convert Community Board's paper documents
or provide new
to electronic files. Explanation: Digitize
community board
community board's paper files. storage of paper
facilities and
documents is becoming increasingly difficult.
equipment
Our offices are usually small with little room to
add more file cabinets. Help bring community
boards' offices into the 21st century.
16/30
DOT
Improve traffic and
Install additional lights along Roosevelt Ave
pedestrian safety,
from 72nd to 112th Streets
including traffic
calming (Capital)
17/30
DEP
Investigate odor
Employ interim measures to control floatables
complaints about a
going into Flushing Bay and restore the
wastewater facility
wetlands
and address/repair
or make equipment
improvements as
needed (Capital)
18/30
FDNY
Upgrade
Replace the apparatus door.
8119
communication
Northern Blvd
equipment to
improve emergency
response
19/30
DPR
Other park maintenance and safety requests
Upgrade Veterans Plaza (32nd Ave & 94th Street) sitting area to a recreational space for children and adults.
32 Ave and 94 Street
20/30
FDNY
Other FDNY facilities
Upgrade the FDNY Engine 307/154 kitchen.
8119
and equipment
Northern Blvd
requests (Capital)
21/30
DOT
Repair or provide
Add Street Lights from Junction Boulevard to
new street lights
Roosevelt Avenue.
22/30
FDNY
Other FDNY facilities
Purchase a Back-up Generator for 307.
8119
and equipment
Northern Blvd
requests (Capital)
23/30
DOT
Other capital traffic
District Wide traffic study
improvements
requests
24/30
DOT
Other capital traffic
Re-evaluate traffic conditions along 75th to
75th to 78th
improvements
78th Streets and 31st Ave.
Streets 31st
requests
Ave
25/30
DCLA
Other cultural
Construct a Community Performance Arts
facilities and
Center in Jackson Heights. The new facility
resources requests
would host local and international artists and
(Capital)
could be the home of the Jackson Heights
Orchester.
26/30
DPR
Reconstruct or
Gorman Park has received funding for the rehab
84th Street
upgrade a park or
of the playground. In FY2021 provide funding
and 25th
amenity (i.e.
for phase !!, upgrading the volleyball, basketball
Avenue
playground, outdoor
and handball courts. Further, repair catch basin
athletic field)
and eliminate ponding and sewer backup
conditions.
27/30
DPR
Reconstruct or
Upgrade Northern Playground (Including play
upgrade a parks
equipment, restrooms and sitting area)
facility
28/30
NYPD
Other NYPD
The 115th Precinct does not have a tower
92-15
facilities and
dedicated for the district's use. Often times, the
Northern
equipment requests
equipment is not available when needed. It
blvd.
(Capital)
makes sense to purchase this much needed
apparatus.to ensure that our local precinct has
its own.
29/30
NYPD
Provide surveillance
Install cameras at the overpasses located at
cameras
27th & 31st drive on Ditmars Blvd.
30/30
FDNY
Provide new
Purchase a medical service vehicle for
emergency vehicles,
FDNY/EMS which will serve the Borough of
such as fire trucks or
Queens, Approximately 10 patients can be
ambulances
accommodated at one time. The current vehicle
is over twenty years.
CS
DEP
Inspect sanitary
Request: Fund a Study For The Construction of a
sewer on specific
Separate Sewer System for 103rd & Northern
street segment and
Blvd., 25th Avenue & 81st Street, 77th Street &
repair or replace as
30th Avenue, 25th Avenue and 77th Street and
needed (Capital)
25th Avenue and 76th Street. Explanation:
Neighborhoods that were once comprised of
one & two family homes have been replaced
with units of six to ten families. These changes
have increased the demand on our
infrastructure & sewer system. Before 1996,
conditions were confined to East Elmhurst or
North of Northern Blvd. Sewer backup
conditions are now district-wide.
CS
DOT
Reconstruct streets
Request: Resurface Streets in Community Board
86th Street
3. Explanation: Resurface Northern Blvd. from
25th Avenue
Junction Blvd. to 114th street. Junction Blvd.
30th Avenue
between Northern and Roosevelt Avenues, 37th
Ave from Junction Blvd. to 114th Street, 82nd
Street from Roosevelt Ave to the BQE, Roosevelt
Ave from 114th to 69th Streets and Astoria Blvd.
from 69th to 114th Streets.
CS
QL
Create a new, or
Request: Expand East Elmhurst Library.
95-06 Astoria
renovate or upgrade
Explanation: The East Elmhurst Community
Blvd
an existing public
urgently needs a cultural facility and the
library
expansion of the library to accommodate the
increase in users. Proceed with the final phase
of the expansion; construction by the start of FY
2017
CS
QL
Create a new, or
Request: Expand Corona Library Explanation:
38-23 104 St
renovate or upgrade
This heavily used facility is one of only four
an existing public
libraries in community Board 3. Whether
library
expansion entails building up or acquiring
adjacent property, the new addition would be
welcomed.
CS
DPR
Other park
Continued Support: Repair the drainage at
programming
Flushing Meadows Corona Park.
requests
CS
DPR
Other park
Continued Support - Restore the Queens Green
programming
House at Forest Park.
requests
CS DCLA Support nonprofit cultural organizations
Construct a Visitor Center for Louis Armstrong House Museum. Explanation: We request that the construction of the Visitor Center be fully funded and work commence expeditiously.
Community Board 3 fully supports this project.
34-56 107
Street
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/30
DEP
Investigate air
Request: Install Air Monitors in the
quality complaints
Neighborhoods of Jackson Heights and East
at specific location
Elmhurst that are located near LaGuardia
Airport. Explanation: CB3 is surrounded by
Laguardia Airport, BQE andGrand Central
Parkway. Our residents are concerned about the
impact of fumes emanating from motor vehicles
and planes in the community. There is a high
incidence of asthma & respiratory disease in our
district. The need to install air monitors in our
area is clear.
2/30
QL
Extend library hours
Request: Keep Queens Libraries Open 7 Days a
or expand and
week with one late night closing at 10:00pm.
enhance library
Explanation: Our libraries are heavily utilized
programs
and do not meet the needs of CB3 constituents.
Provide funding to restore our libraries to full
operational capacity.
3/30
DSNY
Provide more
Restore litter basket collections to three times
frequent litter
per day in our commercial strips – 37th Ave;
basket collection
Junction Blvd; Roosevelt Ave; Northern Blvd;
103rd Street; and 74th Street; Astoria Blvd.,
73rd and 72nd Streets in Jackson Heights. Hire
additional personnel for 11am- 7pm shift in
order to increase litter basket patrol truck
service particularly during weekends.
4/30
DYCD
Other youth
Request: Restore and Increase funding for
workforce
youth, adult and senior programming in Jackson
development
Heights, North Corona and East Elmhurst.
requests
Explanation: There is a severe shortage of
programs in CD3 that cater to the recreational
needs of our youth and seniors. Our community
deserves quality facilities and programming
that will enrich our lives.
5/30
DPR
Other park
Request: Increase parks staffing levels for
programming
maintenance personnel. Hire a parks associates
requests
for PS 127 and Junction Boulevard parks and
assistant gardener. Explanation: CB3 requires
additional associates in our area parks.
currently there are only two associates in the
entire district, Gorman park and Travers. Our
community has increased by 40,000 residents,
we deserve more programs and services.
6/30
NYPD
Assign additional
Request: Hire additional uniform personnel.
92-15
uniformed officers
NCO officers, administrative aides, custodial
Northern Blvd
personnel and school safety guards.
Explanation: Hire additional custodial personnel
for the 115 precinct. The additional staff will
improve the precinct's day to day operations
and upkeep.
7/30
EDC
Expand graffiti
Request: Increase Graffiti Removal Programs.
removal services on
Explanation: To combat the increased incidence
private sites
of graffiti CD3, Additional monies are needed
to these support programs.
8/30
DOE
Provide, expand, or
Request: Restore Day Care Slots and after school
enhance funding for
programs. Explanation: Our Community's
Child Care and Head
population has increased. Many of our young
Start programs
working families require day care services &
after school programs. Working parents deserve
programs that will serve the needs of their pre-
school children ages three months to five years
old.
9/30
Other
Other expense
Improve access to government services and
budget request
information by sharing 311 data with
Community Boards.
10/30
Other
Other expense
Re-establish Neighborhood Business
budget request
Development programs.
11/30
DOT
Improve traffic and
Request: Increase funding to hire additional
pedestrian safety,
personnel to install, replace traffic/street signs,
including traffic
repair pot holes for Queens DOT Explanation:
calming (Expense)
Increase funding to hire personnel for sign
replacement and pothole repair.
12/30
Other
Other expense
Increase staffing Level for DOB Compliance Unit.
budget request
13/30
NYCHA
Expand programs
HPD - Hire additional inspectors to address code
for housing
enforcement, demolition and seal-up
inspections to
complaints.
correct code
violations
14/30
DPR
New equipment for
Cont. Support: Purchase a Wenger Wagon -
maintenance
Provide funding for the purchase of a Wenger
(Expense)
Wagon. Community groups depend on the parks
department to provide an inexpensive way of
showcasing their events. The Borough could use
more than one mobile stage.
15/30
DPR
Reconstruct or upgrade a building in a park
Request: Install free WIFI in CB3 parks and Plazas. Explanation: Upgrade our area parks by installing free WIFI services. Keep park users plugged in and informed.
16/30
Other
Other expense
Hire Additional Consumer Affairs agents to
budget request
conduct night and weekend street vending
inspections.
17/30
DOHMH
Increase health
Request: Hire additional Department of Health
inspections, e.g. for
Inspectors to conduct night inspections.
restaurants
Explanation: Unlicensed food vending along
Roosevelt Ave, Broadway, 74th and 37th
Avenues are increasing. The community would
benefit from having more inspections conducted
particularly at night where the problem is most
prevalent.
18/30
DFTA
Enhance NORC
Request: Provide funding to increase NORC
programs and
(Naturally Occurring Retirement Community)
health services
Programming in CB3. Explanation: Seniors are
the second largest population within CB3. It is
important that senior programming such as
NORC be made available to our elder residents.
Providing health and social services within the
confines of their coop/apartment complex
would significantly improve their quality of life.
19/30
Other
Other expense
Retrofit Apartment for Seniors. (Incentive Tax
budget request
Abatement for Owners)
20/30
DPR
New equipment for
Request: Purchase a (1) Cab Pick-Up .
maintenance
Explanation: The purchase of this critical
(Expense)
equipment will make a significant improvement
on Parks day to day operations.
21/30
DSNY
Provide more
Increase sanitation residential collections to 3
frequent garbage or
times per week
recycling pick-up
22/30
DSNY
Other garbage
Increase funding for additional cleaning services
collection and
to Roosevelt Ave from 69th to 114th Streets.
recycling
infrastructure
requests (Expense)
23/30
DOE
Other educational
STEAM is a method of instruction that
programs requests
incorporates Science, Technology, Engineering,
the Arts, and Mathematics and helps to
promote student critical thinking. Every
classroom should have access to these
important resources.
24/30
DEP
Inspect sanitary
Increase DEP sewer and water unit personnel
sewer on specific
street segment and
repair or replace as
needed (Expense)
25/30
FDNY
Other FDNY facilities
Purchase a Medical Services Vehicle - FDNY/EMS
and equipment
for the Borough of Queens (for 10 patients at a
requests (Expense)
time can be attended to on this mobile vehicle).
Existing vehicle is over 29 years old.
26/30
FDNY
Other FDNY facilities
Purchase for FDNY - Medical Aide Rapid
and equipment
Response Vehicle - For city wide use state of the
requests (Expense)
art vehicle that will transport equipment and
supplies in emergency situations.
27/30
DSNY
Other cleaning
Provide funding for MLP service in section 31.
requests
The monies would allow sanitation to provide
additonal services to the streets located in this
section of the district.
28/30
DPR
Other park
Funding for tihs program will provide staffing to
maintenance and
maintain the park landscapes,gardens, lawns
safety requests
and other horticultural amenities.
29/30
DPR
Enhance park safety
Request: Extend fencing at Northern Boulevard
through design
Playground. Explanation: Part of the fencing at
interventions, e.g.
this playground is chain linked and the balance
better lighting
is wrought iron. Remove the chain linked
(Expense)
portion of the fence and replace it with wrought
iron for safety and aesthetic reasons.
30/30
SBS
Other business
Implement Economic Development programs
regulatory
which would include entrepreneurial training,
assistance requests
loan packaging, micro Loan Program,
management training, export assistance..
Assistance is needed to coordinate
neighborhood redevelopment, marketing &
anti-graffiti programs. Funding these programs
would make a significant difference for the
business community in CB3..
CS HHC Renovate or upgrade an existing health care facility
Request: Increase hospital beds in the Borough of Queens and upgrade the emergency room at Elmhurst Hospital. With the closing of several Hospitals in the Borough of Queens, area hospitals such as Elmhurst Hospital are feeling the impact. Additional hospital beds are sorely needed.
7901
Broadway
image

