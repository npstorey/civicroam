- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 7 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1U9zXfvaDoXHckxyc2cK1EMOS7PG0e1uc/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1U9zXfvaDoXHckxyc2cK1EMOS7PG0e1uc/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
7
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 7
image
Address: 229A E. 204th Street Phone: (718) 933-5650
Website: www.nyc.gov/bronxcb7
Chair: Emmanuel Martinez District Manager: Ischia Bravo
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
The quality of local schools continues to be a major issue of concern for local residents. The number of schools seats available in our community has not kept pace with our growing youth population and most of our schools are already experiencing overcrowding. As additional development occurs in the district, the problem will only continue to grow more serious. CB 7 is in need of more mixed income housing, as housing accommodation's continue to be one of the primary issues facing residents of our district. While the district has some of the most affordable private market rental housing in the city, many rent-stabilized and rent-controlled apartments are disappearing far quicker than new mixed housing units can be constructed. To make matters worse, the district is seeing an influx of new residents who have been priced out of their own neighborhoods in New York City, increasing competition for the affordable units available in the district. The Bronx has taken on more city-financed supportive housing in the past decade than any other borough and there is a prevailing feeling in our district that we have received a disproportionate share of these developments in our district. In addition to supportive housing facilities, the district is also home to numerous homeless shelters, half-way houses and other special needs housing. We would like to ensure housing is being built responsibly to accomodate the growth by increasing more municipal services. Quality of Life issues like noise and loitering no longer have a way to be addressed by our enforcement agencies, as they are deemed not to be a priority. Our residents deserve to have these basic needs addressed.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 7
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
CB 7 is in need of housing that will cater to the income levels in our district, as housing accommodation's continue to be one of the primary issues facing residents of our district. While the district has some of the most affordable private market rental housing in the city, many rent-stabilized and rent-controlled apartments are disappearing far quicker than new mixed housing units can be constructed. To make matters worse, the district is seeing an influx of new residents who have been priced out of their own neighborhoods in New York City, increasing competition for the affordable units available in the district. We would like streamline communication with our municipal agencies to ensure the increase in units is paired with more schools and services overall.
Schools
The quality of local schools continues to be a major issue of concern for local residents. The number of schools seats available in our community has not kept pace with our growing youth population and most of our schools are already experiencing overcrowding. As additional development occurs in the district, the problem will only continue to grow more serious.
Other
Insufficient Municipal Services: We have seen a dramatic increase in our population due to new development. Unfortunately, services like sanitation. transit have not increased to meet new demands. CB 7 needs additional services from our agencies to maintain our quality of life.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 7
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
According to the 2010 census, nearly 71,000 residents, or over fifty percent of the total population, receive some kind of government assistance. Even with existing assistance programs, many of these residents struggle to make ends meet. There is a real need to find additional means of assistance to help improve the quality of life of these residents.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
1/25 DFTA Enhance NORC
programs and health services
Initiate the Naturally Occurring Retirement Community (NORC) in our district. To provide resources to help our senior population maintain healthy living in their own apartments.
image
23/25 DOHMH Create or promote
programs for education and awareness on nutrition, physical activity, etc.
According to the most recent Community Health Survey, many residents are either overweight or obese and suffer disproportionately from related diseases such as diabetes. The Department of Health needs to have nutritional education programs for the general public in our schools and Hospitals within our district.
The Bronx still has the highest rate of health concerns in the State.
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 7
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
CEC 10, which includes most of our district, is the most overcrowded district in the Bronx and is among the most overcrowded districts citywide. As a result, students find themselves trying to learn while jammed into spaces never intended as classrooms, such as libraries, gymnasiums, laboratories, lunchrooms, and even closets. There is substantial evidence that overcrowding, particularly in high-poverty districts such as ours, can have an adverse impact on learning.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/25
SCA
Renovate interior
The Dewitt Clinton High School pool is in need of
Dewitt
building component
repairs. The students attending deserve to have
Clinton Hs
a full functioning pool.
Field House,
Bronx, New
York, NY
6/25
SCA
Provide a new or
Currently, eleven out of our fourteen grade
expand an existing
schools are operating overcapacity, with several
elementary school
of these schools severely overcapacity. Our
community is experiencing a large increase in
residential development with hundreds of
planned housing units across the district. As a
result of these new developments, school
overcrowding will continue become a larger
issue unless new grade schools are built
immediately.
CS
SCA
Provide a new or
Our existing middle schools are over capacity.
3177 Webster
expand an existing
We are in need of a new middle/intermediate
Avenue
middle/intermediate
School in the CB 7 district.
school
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
4/25
DOE
Other educational
CB 7 is requesting a Youth Center at the Former
programs requests
Bainbridge Library Center which is a city owned
property. Example: YMCA.
5/25
DYCD
Provide, expand, or
Few if any of the area students are able to
enhance after
attend Specialized High Schools. Bronx High
school programs for
School of Science is within our area but does not
middle school
serve students in our district. Test Prep for our
students (grades 6-
resident students is needed to address this
8)
issue.
7/25
DYCD
Provide, expand, or
Providing more Beacon Programs in our district
enhance
is necessary and a critical tool in keeping
Cornerstone and
kids/young adults off the street and positively
Beacon programs
engaged. Additional after-school slots are
(all ages, including
necessary to ensure all children in the district
young adults)
are given the opportunity to utilize these
services.
22/25 DOE Other educational
programs requests
Provide funding for the establishment of a Gifted and Talented program in a school within Community District 7. As well as, prep courses in CB 7.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 7
image
M ost Important Issue Related to Public Safety and Emergency Services
Public Nuisance (noise, other disturbances)
Bronx Community Board 7 has seen a dramatic increase in public Nuisances complaints. These complaints all involve our quality of life and safety. We need to have better enforcement methods from the NYPD for noise complaints and loitering. Our community needs more of a positive and engaging police presence in neighborhoods with numerous complaints.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
10/25
NYPD
Provide a new NYPD
The 52nd Precinct has over 300 officers
facility, such as a
servicing the community. Currently, the Precinct
new precinct house
is need of a sub-precinct to accommodate the
or sub-precinct
growth. There is vacant space that can
purchased by the city across the street at 3041
Webster Ave. In addition, the parking lot at the
precinct needs to be renovated to further
accommodate the growth.
CS
NYPD
Renovate or
The 52nd Precinct House is a historic landmark
3016 Webster
upgrade existing
with its trademark Tower Clock, which is not
Avenue
precinct houses
currently operational. The board requests that
the Tower Clock be repaired.
CS
NYPD
Provide surveillance
Install NYPD Security cameras on Bedford Park
cameras
and Fordham Road. Surveillance cameras are a
valuable crime fighting tool, but there are still
many areas in our community that lack camera
coverage.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
15/25
NYPD
Assign additional
The district is home to three subway lines and
transit police
there are nine stations in the district. We need
officers
officers to address common complaints that
include panhandling, card swiping and
vandalism. Additional officers would allow these
complaints to be addressed more quickly and
more efficiently.
17/25
NYPD
Increase resources
These programs will help combat the economic
for vandalism
and quality-of-life setback caused by graffiti
prevention
vandalism. A new initiative will help prevent and
programs, such as
abate graffiti vandalism on the local level,
anti-graffiti
resulting in safer, more vibrant communities.
initiatives
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 7
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
The office receives a high volume of complaints related to the cleanliness of the district. Specifically, there are a high volume of complaints related to dog waste, illegal dumping and cleanliness of the merchant areas.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
20/25
DEP
Evaluate a public
In addition to repairing catch basins the
Bainbridge
location or property
continuous flooding after storms on both
Avenue
for green
Bainbridge Avenue and Decatur and Van
infrastructure, e.g.
Cortlandt Avenue East needs to be addressed.
rain gardens,
stormwater
greenstreets, green
playgrounds
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
8/25
DSNY
Increase
The district has historically had one of the
enforcement of
highest volumes of complaints regarding canine
canine waste laws
waste. An increase in enforcement activity
would be helpful in addressing this long-
standing issue.
10/25
DSNY
Increase
We need an increase in sanitation enforcement
enforcement of
to improve the quality of our commercial
dirty sidewalk/dirty
corridors. Our shopping districts include:
area/failure to clean
Fordham Road, Kingsbridge Road, Jerome
area laws
Avenue, 204th Street and Webster Avenue.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 7
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Housing support (including tenant protection)
The residents of Bronx Community Board 7 are constantly dealing with rental issues. Tenants have rights and should be afforded more services to help with rental increases and code violations. We see too often how our residents are living in poor conditions. The living conditions can affect your quality of life, your job, your family and your mental health. There is also a need for mixed income housing to accommodate those in different income brackets.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
8/25
EDC
Make infrastructure
Allocate funding for a Full Service Community
2556
investments that
Center to include senior, youth and child care
Bainbridge
will support growth
services at the former Bronx Library Center
Avenue
in local business
located at 2556 Bainbridge Avenue. Please
districts
update on the status
14/25
HPD
Provide more
The recent push to create affordable housing
housing for medium
has resulted in additional units for low-income
income households
residents in our district. However, there has
been a severe shortage in the availability of
affordable units for middle income residents.
We are requesting the Open-Door Program to
encourage home ownership in our district.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
11/25
NYCHA
Expand programs
Provide additional Personnel for HPD
for housing
Inspections. There are many community
inspections to
residents who do not live in quality housing
correct code
because of non-compliance with housing
violations
regulations. The primary cause is not that
complaints are not recorded by HPD but the
heavy reliance of self-certification for
determining compliance. We request that HPD
move away from relying heavily on self
certification and hire additional enforcement
personnel to deal with the large number of
outstanding violations.
12/25
EDC
Improve public
In CB 7 we only have one Public Housing
2663 Heath
housing
building which is Bailey Houses. Bailey houses is
Avenue
maintenance and
in need of consistent maintence and cleaning in
cleanliness
the public hallways and on all the sidewalks
around the building. NYCHA residents deserve
to have a clean and environmentally friendly
place to live.
14/25 SBS Support development of local Storefront / Facade Improvement Program
All of our commercial strips are in need of rehabilitation and façade improvements. Funding is needed to advertise and support businesses.
image
16/25 EDC Expand graffiti
removal services on private sites
The average wait-time for graffiti removal is far too long and many residents no longer bother to report graffiti under the mistaken belief that it will not be addressed. It is clear additional resources are needed to cut-down wait times and allow for proactive graffiti removal.
image
18/25 HPD Provide or enhance
rental subsidies programs
The lack of affordable housing and the continuing decline in the number of Section 8 vouchers has made it impossible for many residents to find affordable housing options. Additional rental subsidy programs would also be helpful in creating housing options for these residents.
image
TRANSPORTATION
Bronx Community Board 7
image
M ost Important Issue Related to Transportation and Mobility
Other
Lack of frequency in our busses and subways. Poor maintenance as well.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/25
DOT
Other
DOT should expand the municipal parking
Jerome
transportation
garage at the East Gun Hill Road and Jerome to
Avenue East
infrastructure
allow for more parking availability.
Gun Hill Road
requests
East 212
Street
9/25
DOT
Upgrade or create
There is currently a city-owned vacant lot at
new greenways
Oliver Place between Marion Avenue and
Decatur Avenue. The site is not only an eyesore
for the community , but also has facilitated
numerous negative activities including loitering,
drug dealing and violent crimes. The site has
long been a target for the development of a
new park for community residents, but the
resources have never been invested to make this
plan a reality. The city should make a targeted
investment to develop a community garden on
the lot to address these outstanding issued. We
support the proposal of Bridge Arts to establish
and maintain a community garden.
12/25
NYCTA
Improve
There is s need for an elevator at the 4
accessibility of
Mosholu train station. Many residents use the 4
transit
train to get to local Hospitals like North Central
infrastructure, by
Bronx and Montefiore. The lack of accessibility
providing elevators,
is a major problem.
escalators, etc.
17/25
DOT
Other
Build a Municipal Parking Garage for overnight
transportation
use, merchants, shoppers and residents of
infrastructure
Community Board 7. there is a major need for
requests
resident and merchant parking in the
community. Land is available along Webster
Avenue in the Norwood Community.
23/25
DOT
Other
Provide Time clocks on the 5 busiest bus lines: 
transportation
41, 1, 2, 28 and 9.
infrastructure
requests
CS
DOT
Install streetscape
Improved streetscapes can be a vital tool in
Webster
improvements
helping to attract and retain quality businesses
Avenue East
and improve public safety. Streetscape
Mosholu
investment would be particularly useful in the
Parkway
Webster Avenue area to support the types of
North East
development envisioned in the Webster Avenue
Fordham
Vision Plan.
Road
CS DOT Reconstruct streets Fund Coles Lane as a Pedestrian Street with ADA
accessibility. Coles Lane is a deteriorated street with uneven steps , broken pedestrian pavement and poor drainage. It is not accessible to wheel chair bound residents who are trying to access the Bronx Library Center from Bainbridge Avenue. Instead they must traverse Fordham Road to get to the library. Additionally, Coles Lanes does not have any lighting and is an unwelcoming area after sunset. We request that DOT repair the pavement, convert the steps so that it is ADA accessible and provide upgraded street lighting.
Coles Lane Bainbridge Avenues Coles lane
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
13/25
NYCTA
Improve bus
Major cleaning and rehabilitation are needed at
cleanliness, safety
the D and 4 train lines within District 7.
or maintenance
19/25
DOT
Address traffic
As development continues to increase in the
congestion
district, traffic congestion has become an ever
increasing area of concern. The department
should explore opportunities for reducing traffic
congestion on Mosholu Parkway, Gun Hill Road,
Kingsbridge Road and Fordham Road.
21/25
NYCTA
Provide a new bus
The Bx41 currently services Webster Avenue, but
Webster
service or Select Bus
the service does not extend north of Gun Hill
Avenue Gun
Service
Road. In recent years, the area north of Gun Hill
Hill Road East
Road has experienced tremendous development
233rd Street
with the addition of hundreds of new units of
housing. The Bx41 service should be extended to
ensure these new residents have access to
transit and are connected to the lower portions
of Webster Avenue.
24/25
NYCTA
Provide a new bus
Several years ago, a plan was approved by the
service or Select Bus
MTA to add a new bus line from Fordham Road
Service
to LaGuardia Airport. The funding never
materialized and the bus line was never fully
implemented. The board continues to believe
that this vital bus line will help connect the
Bronx and Queens and provide a major link for
local residents to connect to the many jobs
available at the airport.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 7
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
The district is home to a large number of parks and parkways, making it one of the greenest districts in the city. However, the large amount of parks space has made it very difficult to provide the necessary level of maintenance to keep the parks clean and safe. Additional investment is needed in both maintenance personnel and equipment in the district.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
According to NYPL statistics (below), in Fiscal Year 2016 the libraries in CB 7 had 908,316 visits. Branch Visits Program Attendance Bronx Library Center 730,404 95,088 Mosholu Branch 177,912 19,174 Totals 908,316 114,262 The NYPL libraries within BX CB 7 are used extensively. The community relies on them to provide essential library services, as well as educational programs and community space. Many of the library locations are in need of critical upgrades, including mechanical systems, bathrooms, roofs, facades and ADA upgrades. While other locations are in need of a complete renovation.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/25
DPR
Improve access to a
Provide a new sidewalk to the Holt Place
Williamsbridge
park or playground
entrance at the Williamsbridge Oval Park.
Oval Rec
Center, Bronx,
New York, NY
4/25
DPR
Reconstruct or
New Fitness equipment is needed at the St.
St James Park
upgrade a parks
James Rec Center.
Comfort
facility
Station,
Bronx, New
York, NY
5/25
DPR
Reconstruct or
Create a fitness station on the upper level of
Williamsbridge
upgrade a parks
Williamsbridge Oval Rec Center. Community
Oval Rec
facility
Residents have requested the addition of fitness
Center, Bronx,
equipment.
New York, NY
7/25
DPR
Improve access to a
Create a jogging path around the Jerome Park
park or playground
Reservoir with an entranceway on Goulden
Avenue which would provide easier access to
residents in the district. The current plans for
the jogging path do not encircle the reservoir
and the board has implored the Parks Dept. and
DEP to reopen portions of the reservoir so the
CB7 residents have easier access to this
community amenity.
11/25
DPR
Reconstruct or
Repair the stone stairs at Williamsbridge Oval
upgrade a park or
Park and make it ADA Accessible.
amenity (i.e.
playground, outdoor
athletic field)
13/25
DPR
Reconstruct or
Fund repair of the Perimeter fencing at the
upgrade a park or
Williamsbridge Oval Park to address security
amenity (i.e.
issues. There are many portions of the current
playground, outdoor
gate surrounding WBO Park where the iron
athletic field)
gates are missing or have been compromised.
This provided opportunities for individuals to
enter the park after dark and cause a variety of
disturbances for neighborhood residents or
damage to the park's equipment or center. The
repair of this fence around WBO Park will
restore the first line of defense to the park and
serve as a deterrent to vandalism and other
quality of life issues.
15/25
DPR
Provide a new or
The board calls for the department to fund the
Exterior
expanded park or
creation of Regatta Park on the waterfront at
Street West
amenity (i.e.
Fordham Landing. In previous fiscal years, funds
Fordham
playground, outdoor
had been allocated to start the project, but
Road
athletic field)
nonetheless, the project has never gotten off the
University
ground. A renewed effort should be made to
Heights
turn this eyesore into a park space for
Bridge
community residents. We need access to the
waterfront and an update on this project.
16/25
DPR
Enhance park safety
Purchase and install Flash Cam Security
through design
cameras throughout the Parks in Community
interventions, e.g.
Board 7 to increase security. The community
better lighting
board has requested these cameras over the
(Capital)
last five years. Since then there have been
several major incidents that had the cameras
been installed they would have acted as a
deterrent to these crimes or provided evidence
that would have aided law enforcement
officials. The board requests that Parks
purchase and install these cameras to address
this increasing public safety issues.
18/25
DPR
Other requests for
Repave sidewalk along the East side of
Mosholu
park, building, or
Bainbridge Avenue from the West bound lanes
Parkway
access
of Mosholu Parkway to Mosholu Parkway North
improvements
Service Road. The sidewalk is cracked and
dangerous for pedestrians.
19/25
DPR
Reconstruct or
We need funding for a multi-purpose athletic
upgrade a park or
field at Frisch Field.
amenity (i.e.
playground, outdoor
athletic field)
21/25
DPR
Reconstruct or
Renovate Devoe Park: Recede the curbs, re-pitch
upgrade a park or
the side walks for drainage and update benches.
amenity (i.e.
playground, outdoor
athletic field)
22/25
DPR
Reconstruct or
Rehabilitate the 2 Playgrounds and play
upgrade a park or
equipment in Devoe Park
amenity (i.e.
playground, outdoor
athletic field)
24/25
DPR
Reconstruct or
Redesign and repurpose the storage house for
upgrade a park or
public use located in the middle of Devoe Park.
amenity (i.e.
playground, outdoor
athletic field)
25/25
DPR
Reconstruct or
Devoe Park-Renovate the Basketball Courts to
upgrade a park or
include new Fiberglass backboards. Reconstruct
amenity (i.e.
the court area. It is worn and in need of
playground, outdoor
resurfacing. The existing backboards are
athletic field)
outdated.
CS
DPR
Reconstruct or
The last major rehabilitation of Mosholu
upgrade a park or
Parkway took place nearly forty years ago. In
amenity (i.e.
the meantime, the park has been allowed to fall
playground, outdoor
apart with an increasing number of benches out
athletic field)
of service, stone pillars crumbling and fencing
falling apart. The board calls on the department
to work with DOT to undertake a total
rehabilitation of Mosholu Parkway.
CS
DPR
Reconstruct or
Repair the stone pillars on the eastbound and
Mosholu
upgrade a park or
westbound lanes of Mosholu Parkway Main
Parkway
amenity (i.e.
road and service road from Webster to
Webster
playground, outdoor
Bainbridge Avenues. Some of these pillars have
Avenue
athletic field)
been damaged by motor vehicle accidents.
Bainbridge
Avenues
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/25
DPR
Provide more
Devoe Park is in need of a Playground Associate
University
programs in parks or
to provide activities for the children.
Avenue,
recreational centers
Bronx, New
York, NY
6/25
DPR
Improve trash
The current number of parks personnel assigned
removal and
to trash removal is insufficient. Additional
cleanliness
personnel are needed for trash removal and
general upkeep of community park space. A
new packer just for District 7 is needed to
ensure timely cleanings. The purchase of a
mechanical broom, grass cutter, and pickup
truck for the Parks Department to address
pathway maintenance and ensure frequent
garbage collection in Community District 7
parks is needed.
9/25
DPR
Enhance park safety
Additional PEP officers are needed to patrol our
through more
parks and playgrounds to address various
security staff (police
quality of life issues including vandalism, illegal
or parks
barbecuing, etc. In Bryant Park, Whalen Park,
enforcement)
Devoe Park and Mosholu Parkway.
20/25 DPR Other park maintenance and safety requests
Provide a Gardener for Mosholu Parkway, St. James Park and Devoe Park. All these Parks have very large park area and in order to keep up with the gardening and maintenance, we feel that there is a need for a dedicated full time gardener.
image
25/25 OMB Other community
board facilities and staff requests
Provide additional Funding for Community Boards to fulfill Charter mandated Responsibilities. We are grateful for the recent increase in the budgets of community boards. However, we are requesting that the city increase the community boards budget to
$350,000 each to assure that they can provide the mandated services to the districts.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
2/25
Other
Other expense
Agency: DOT Increased Sanitation staff to
East
budget request
provide more frequent clean-ups of drug
Kingsbridge
equipment and garbage at the Kingsbridge
Road Grand
Road Underpass.
Concourse
Valentine
Avenue
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
DOT
Other
DOT should expand the municipal parking
Jerome
transportation
garage at the East Gun Hill Road and Jerome to
Avenue East
infrastructure
allow for more parking availability.
Gun Hill Road
requests
East 212
Street
2/25
SCA
Renovate interior
The Dewitt Clinton High School pool is in need of
Dewitt
building component
repairs. The students attending deserve to have
Clinton Hs
a full functioning pool.
Field House,
Bronx, New
York, NY
3/25
DPR
Improve access to a
Provide a new sidewalk to the Holt Place
Williamsbridge
park or playground
entrance at the Williamsbridge Oval Park.
Oval Rec
Center, Bronx,
New York, NY
4/25
DPR
Reconstruct or
New Fitness equipment is needed at the St.
St James Park
upgrade a parks
James Rec Center.
Comfort
facility
Station,
Bronx, New
York, NY
5/25
DPR
Reconstruct or
Create a fitness station on the upper level of
Williamsbridge
upgrade a parks
Williamsbridge Oval Rec Center. Community
Oval Rec
facility
Residents have requested the addition of fitness
Center, Bronx,
equipment.
New York, NY
6/25
SCA
Provide a new or
Currently, eleven out of our fourteen grade
expand an existing
schools are operating overcapacity, with several
elementary school
of these schools severely overcapacity. Our
community is experiencing a large increase in
residential development with hundreds of
planned housing units across the district. As a
result of these new developments, school
overcrowding will continue become a larger
issue unless new grade schools are built
immediately.
7/25
DPR
Improve access to a
Create a jogging path around the Jerome Park
park or playground
Reservoir with an entranceway on Goulden
Avenue which would provide easier access to
residents in the district. The current plans for
the jogging path do not encircle the reservoir
and the board has implored the Parks Dept. and
DEP to reopen portions of the reservoir so the
CB7 residents have easier access to this
community amenity.
8/25
EDC
Make infrastructure
Allocate funding for a Full Service Community
2556
investments that
Center to include senior, youth and child care
Bainbridge
will support growth
services at the former Bronx Library Center
Avenue
in local business
located at 2556 Bainbridge Avenue. Please
districts
update on the status
9/25
DOT
Upgrade or create
There is currently a city-owned vacant lot at
new greenways
Oliver Place between Marion Avenue and
Decatur Avenue. The site is not only an eyesore
for the community , but also has facilitated
numerous negative activities including loitering,
drug dealing and violent crimes. The site has
long been a target for the development of a
new park for community residents, but the
resources have never been invested to make this
plan a reality. The city should make a targeted
investment to develop a community garden on
the lot to address these outstanding issued. We
support the proposal of Bridge Arts to establish
and maintain a community garden.
10/25
NYPD
Provide a new NYPD
The 52nd Precinct has over 300 officers
facility, such as a
servicing the community. Currently, the Precinct
new precinct house
is need of a sub-precinct to accommodate the
or sub-precinct
growth. There is vacant space that can
purchased by the city across the street at 3041
Webster Ave. In addition, the parking lot at the
precinct needs to be renovated to further
accommodate the growth.
11/25
DPR
Reconstruct or
Repair the stone stairs at Williamsbridge Oval
upgrade a park or
Park and make it ADA Accessible.
amenity (i.e.
playground, outdoor
athletic field)
12/25
NYCTA
Improve
There is s need for an elevator at the 4
accessibility of
Mosholu train station. Many residents use the 4
transit
train to get to local Hospitals like North Central
infrastructure, by
Bronx and Montefiore. The lack of accessibility
providing elevators,
is a major problem.
escalators, etc.
13/25
DPR
Reconstruct or
Fund repair of the Perimeter fencing at the
upgrade a park or
Williamsbridge Oval Park to address security
amenity (i.e.
issues. There are many portions of the current
playground, outdoor
gate surrounding WBO Park where the iron
athletic field)
gates are missing or have been compromised.
This provided opportunities for individuals to
enter the park after dark and cause a variety of
disturbances for neighborhood residents or
damage to the park's equipment or center. The
repair of this fence around WBO Park will
restore the first line of defense to the park and
serve as a deterrent to vandalism and other
quality of life issues.
14/25
HPD
Provide more
The recent push to create affordable housing
housing for medium
has resulted in additional units for low-income
income households
residents in our district. However, there has
been a severe shortage in the availability of
affordable units for middle income residents.
We are requesting the Open-Door Program to
encourage home ownership in our district.
15/25
DPR
Provide a new or
The board calls for the department to fund the
Exterior
expanded park or
creation of Regatta Park on the waterfront at
Street West
amenity (i.e.
Fordham Landing. In previous fiscal years, funds
Fordham
playground, outdoor
had been allocated to start the project, but
Road
athletic field)
nonetheless, the project has never gotten off the
University
ground. A renewed effort should be made to
Heights
turn this eyesore into a park space for
Bridge
community residents. We need access to the
waterfront and an update on this project.
16/25
DPR
Enhance park safety
Purchase and install Flash Cam Security
through design
cameras throughout the Parks in Community
interventions, e.g.
Board 7 to increase security. The community
better lighting
board has requested these cameras over the
(Capital)
last five years. Since then there have been
several major incidents that had the cameras
been installed they would have acted as a
deterrent to these crimes or provided evidence
that would have aided law enforcement
officials. The board requests that Parks
purchase and install these cameras to address
this increasing public safety issues.
17/25
DOT
Other
Build a Municipal Parking Garage for overnight
transportation
use, merchants, shoppers and residents of
infrastructure
Community Board 7. there is a major need for
requests
resident and merchant parking in the
community. Land is available along Webster
Avenue in the Norwood Community.
18/25
DPR
Other requests for
Repave sidewalk along the East side of
Mosholu
park, building, or
Bainbridge Avenue from the West bound lanes
Parkway
access
of Mosholu Parkway to Mosholu Parkway North
improvements
Service Road. The sidewalk is cracked and
dangerous for pedestrians.
19/25
DPR
Reconstruct or
We need funding for a multi-purpose athletic
upgrade a park or
field at Frisch Field.
amenity (i.e.
playground, outdoor
athletic field)
20/25
DEP
Evaluate a public
In addition to repairing catch basins the
Bainbridge
location or property
continuous flooding after storms on both
Avenue
for green
Bainbridge Avenue and Decatur and Van
infrastructure, e.g.
Cortlandt Avenue East needs to be addressed.
rain gardens,
stormwater
greenstreets, green
playgrounds
21/25
DPR
Reconstruct or
Renovate Devoe Park: Recede the curbs, re-pitch
upgrade a park or
the side walks for drainage and update benches.
amenity (i.e.
playground, outdoor
athletic field)
22/25
DPR
Reconstruct or
Rehabilitate the 2 Playgrounds and play
upgrade a park or
equipment in Devoe Park
amenity (i.e.
playground, outdoor
athletic field)
23/25
DOT
Other
Provide Time clocks on the 5 busiest bus lines: 
transportation
41, 1, 2, 28 and 9.
infrastructure
requests
24/25
DPR
Reconstruct or
Redesign and repurpose the storage house for
upgrade a park or
public use located in the middle of Devoe Park.
amenity (i.e.
playground, outdoor
athletic field)
25/25
DPR
Reconstruct or
Devoe Park-Renovate the Basketball Courts to
upgrade a park or
include new Fiberglass backboards. Reconstruct
amenity (i.e.
the court area. It is worn and in need of
playground, outdoor
resurfacing. The existing backboards are
athletic field)
outdated.
CS
SCA
Provide a new or expand an existing middle/intermediate school
Our existing middle schools are over capacity. We are in need of a new middle/intermediate School in the CB 7 district.
3177 Webster Avenue
CS
NYPD
Renovate or
The 52nd Precinct House is a historic landmark
3016 Webster
upgrade existing
with its trademark Tower Clock, which is not
Avenue
precinct houses
currently operational. The board requests that
the Tower Clock be repaired.
CS
NYPD
Provide surveillance
Install NYPD Security cameras on Bedford Park
cameras
and Fordham Road. Surveillance cameras are a
valuable crime fighting tool, but there are still
many areas in our community that lack camera
coverage.
CS
DOT
Install streetscape
Improved streetscapes can be a vital tool in
Webster
improvements
helping to attract and retain quality businesses
Avenue East
and improve public safety. Streetscape
Mosholu
investment would be particularly useful in the
Parkway
Webster Avenue area to support the types of
North East
development envisioned in the Webster Avenue
Fordham
Vision Plan.
Road
CS
DOT
Reconstruct streets
Fund Coles Lane as a Pedestrian Street with ADA
Coles Lane
accessibility. Coles Lane is a deteriorated street
Bainbridge
with uneven steps , broken pedestrian pavement
Avenues
and poor drainage. It is not accessible to wheel
Coles lane
chair bound residents who are trying to access
the Bronx Library Center from Bainbridge
Avenue. Instead they must traverse Fordham
Road to get to the library. Additionally, Coles
Lanes does not have any lighting and is an
unwelcoming area after sunset. We request that
DOT repair the pavement, convert the steps so
that it is ADA accessible and provide upgraded
street lighting.
CS
DPR
Reconstruct or
The last major rehabilitation of Mosholu
upgrade a park or
Parkway took place nearly forty years ago. In
amenity (i.e.
the meantime, the park has been allowed to fall
playground, outdoor
apart with an increasing number of benches out
athletic field)
of service, stone pillars crumbling and fencing
falling apart. The board calls on the department
to work with DOT to undertake a total
rehabilitation of Mosholu Parkway.
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Repair the stone pillars on the eastbound and westbound lanes of Mosholu Parkway Main road and service road from Webster to Bainbridge Avenues. Some of these pillars have been damaged by motor vehicle accidents.
Mosholu Parkway Webster Avenue Bainbridge Avenues
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
DFTA
Enhance NORC
Initiate the Naturally Occurring Retirement
programs and
Community (NORC) in our district. To provide
health services
resources to help our senior population
maintain healthy living in their own apartments.
2/25
Other
Other expense
Agency: DOT Increased Sanitation staff to
East
budget request
provide more frequent clean-ups of drug
Kingsbridge
equipment and garbage at the Kingsbridge
Road Grand
Road Underpass.
Concourse
Valentine
Avenue
3/25
DPR
Provide more
Devoe Park is in need of a Playground Associate
University
programs in parks or
to provide activities for the children.
Avenue,
recreational centers
Bronx, New
York, NY
4/25
DOE
Other educational
CB 7 is requesting a Youth Center at the Former
programs requests
Bainbridge Library Center which is a city owned
property. Example: YMCA.
5/25
DYCD
Provide, expand, or
Few if any of the area students are able to
enhance after
attend Specialized High Schools. Bronx High
school programs for
School of Science is within our area but does not
middle school
serve students in our district. Test Prep for our
students (grades 6-
resident students is needed to address this
8)
issue.
6/25
DPR
Improve trash
The current number of parks personnel assigned
removal and
to trash removal is insufficient. Additional
cleanliness
personnel are needed for trash removal and
general upkeep of community park space. A
new packer just for District 7 is needed to
ensure timely cleanings. The purchase of a
mechanical broom, grass cutter, and pickup
truck for the Parks Department to address
pathway maintenance and ensure frequent
garbage collection in Community District 7
parks is needed.
7/25
DYCD
Provide, expand, or
Providing more Beacon Programs in our district
enhance
is necessary and a critical tool in keeping
Cornerstone and
kids/young adults off the street and positively
Beacon programs
engaged. Additional after-school slots are
(all ages, including
necessary to ensure all children in the district
young adults)
are given the opportunity to utilize these
services.
8/25
DSNY
Increase
The district has historically had one of the
enforcement of
highest volumes of complaints regarding canine
canine waste laws
waste. An increase in enforcement activity
would be helpful in addressing this long-
standing issue.
9/25
DPR
Enhance park safety
Additional PEP officers are needed to patrol our
through more
parks and playgrounds to address various
security staff (police
quality of life issues including vandalism, illegal
or parks
barbecuing, etc. In Bryant Park, Whalen Park,
enforcement)
Devoe Park and Mosholu Parkway.
10/25
DSNY
Increase
We need an increase in sanitation enforcement
enforcement of
to improve the quality of our commercial
dirty sidewalk/dirty
corridors. Our shopping districts include:
area/failure to clean
Fordham Road, Kingsbridge Road, Jerome
area laws
Avenue, 204th Street and Webster Avenue.
11/25
NYCHA
Expand programs
Provide additional Personnel for HPD
for housing
Inspections. There are many community
inspections to
residents who do not live in quality housing
correct code
because of non-compliance with housing
violations
regulations. The primary cause is not that
complaints are not recorded by HPD but the
heavy reliance of self-certification for
determining compliance. We request that HPD
move away from relying heavily on self
certification and hire additional enforcement
personnel to deal with the large number of
outstanding violations.
12/25
EDC
Improve public
In CB 7 we only have one Public Housing
2663 Heath
housing
building which is Bailey Houses. Bailey houses is
Avenue
maintenance and
in need of consistent maintence and cleaning in
cleanliness
the public hallways and on all the sidewalks
around the building. NYCHA residents deserve
to have a clean and environmentally friendly
place to live.
13/25
NYCTA
Improve bus
Major cleaning and rehabilitation are needed at
cleanliness, safety
the D and 4 train lines within District 7.
or maintenance
14/25
SBS
Support
All of our commercial strips are in need of
development of
rehabilitation and façade improvements.
local Storefront /
Funding is needed to advertise and support
Facade
businesses.
Improvement
Program
15/25
NYPD
Assign additional
The district is home to three subway lines and
transit police
there are nine stations in the district. We need
officers
officers to address common complaints that
include panhandling, card swiping and
vandalism. Additional officers would allow these
complaints to be addressed more quickly and
more efficiently.
16/25
EDC
Expand graffiti
The average wait-time for graffiti removal is far
removal services on
too long and many residents no longer bother to
private sites
report graffiti under the mistaken belief that it
will not be addressed. It is clear additional
resources are needed to cut-down wait times
and allow for proactive graffiti removal.
17/25
NYPD
Increase resources
These programs will help combat the economic
for vandalism
and quality-of-life setback caused by graffiti
prevention
vandalism. A new initiative will help prevent and
programs, such as
abate graffiti vandalism on the local level,
anti-graffiti
resulting in safer, more vibrant communities.
initiatives
18/25
HPD
Provide or enhance
The lack of affordable housing and the
rental subsidies
continuing decline in the number of Section 8
programs
vouchers has made it impossible for many
residents to find affordable housing options.
Additional rental subsidy programs would also
be helpful in creating housing options for these
residents.
19/25
DOT
Address traffic
As development continues to increase in the
congestion
district, traffic congestion has become an ever
increasing area of concern. The department
should explore opportunities for reducing traffic
congestion on Mosholu Parkway, Gun Hill Road,
Kingsbridge Road and Fordham Road.
20/25
DPR
Other park
Provide a Gardener for Mosholu Parkway, St.
maintenance and
James Park and Devoe Park. All these Parks
safety requests
have very large park area and in order to keep
up with the gardening and maintenance, we
feel that there is a need for a dedicated full time
gardener.
21/25
NYCTA
Provide a new bus
The Bx41 currently services Webster Avenue, but
Webster
service or Select Bus
the service does not extend north of Gun Hill
Avenue Gun
Service
Road. In recent years, the area north of Gun Hill
Hill Road East
Road has experienced tremendous development
233rd Street
with the addition of hundreds of new units of
housing. The Bx41 service should be extended to
ensure these new residents have access to
transit and are connected to the lower portions
of Webster Avenue.
22/25
DOE
Other educational
Provide funding for the establishment of a
programs requests
Gifted and Talented program in a school within
Community District 7. As well as, prep courses in
CB 7.
23/25
DOHMH
Create or promote
According to the most recent Community Health
programs for
Survey, many residents are either overweight or
education and
obese and suffer disproportionately from
awareness on
related diseases such as diabetes. The
nutrition, physical
Department of Health needs to have nutritional
activity, etc.
education programs for the general public in
our schools and Hospitals within our district.
The Bronx still has the highest rate of health
concerns in the State.
24/25
NYCTA
Provide a new bus
Several years ago, a plan was approved by the
service or Select Bus
MTA to add a new bus line from Fordham Road
Service
to LaGuardia Airport. The funding never
materialized and the bus line was never fully
implemented. The board continues to believe
that this vital bus line will help connect the
Bronx and Queens and provide a major link for
local residents to connect to the many jobs
available at the airport.
25/25
OMB
Other community
Provide additional Funding for Community
board facilities and
Boards to fulfill Charter mandated
staff requests
Responsibilities. We are grateful for the recent
increase in the budgets of community boards.
However, we are requesting that the city
increase the community boards budget to
$350,000 each to assure that they can provide
the mandated services to the districts.

