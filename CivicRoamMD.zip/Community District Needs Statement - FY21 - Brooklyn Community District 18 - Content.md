- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 18 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1tjuRai0Xs0cRyIRJdwCJorD1smWU3y-c/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1tjuRai0Xs0cRyIRJdwCJorD1smWU3y-c/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
18
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 18
image
Address: 1097 Bergen Avenue
Phone: (718) 241-0422
Email: bkbrd18@optonline.net
Chair: Saul Needle District Manager: Dorothy Turano
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Often referred to as “The Gateway District” - the neighborhoods that comprise Community Board 18 have a rich history from the earliest days of the "Canarsie Indians" to the polyglot communities that exist within our borders today. Covering one of the largest geographical land areas of any Community Board in the City, a “snap shot” look captures the heart and the spirit of Brooklyn … multi-ethnic, middle class neighborhoods with a solid tax base of single family, multi-family, mid-rise buildings and with a scattering of condominiums and cooperative development. These neighborhoods have been characterized as some of the finest places in New York to live in, raise a family, start a business, or invest in future development.
The hallmark of Community Board 18 is our network of volunteer, civic, parent, religious, and service organizations. This harmonious and constant interchange between neighborhoods, groups, residents and local elected officials has built the very foundation that keeps the fabric of our communities stable while planning for future growth and development.
Within our boundaries, are several high-rise buildings including housing for senior citizens, the homeless, and three
(3) N.Y.C. Housing Authority (NYCHA) Projects, Bayview, Breukelen, and Glenwood Houses, which require a “boots- on-the-ground” commitment to rehabilitation, full upgrading and extensive modernization. In light of the recent shocking revelations concerning the safety and lead paint issues in many of the NYCHA Developments, our Community Board is demanding a full and complete basement to roof apartment and common area inspections to determine any and all possible code violations that may exist along with a remediation plan and “tight” time table for implementation.
Floyd Bennett Field, located in our district, became part of Gateway National Recreation Area in 1972. It is an historic treasure -- the first municipal airfield and an aerial hub for fighter planes during World War II, where the sounds of the departing aircraft of Wiley Post, Amelia Earhart, and Douglas "wrong-way" Corrigan stand as a living testament to times past and the important role that Floyd Bennett Field played in the history of aviation. Views from the Control Tower at Floyd Bennett Field gave clear vision to the crisscrossing runways of New York's first Municipal Airport.
Explore Hanger B, built in 1941 by the U.S. Navy and used primarily for seaplanes spans an enormous two (2) acres in size, where airplanes return to life. Every corner of Hangar B is filled with aircraft from literally every era of aviation. The aircraft restoration efforts are the work of the Historic Aircraft Restoration Project (HARP) created and staffed entirely by volunteers and funded by grant money. HARP works hard to meet Smithsonian’s standard for aircraft restoration. You can see any sort of aircraft going as far back as a replica of the Wright Brothers model, WWII aircraft, and a fully restored Grumman JRF-5 “Goose” flying boat, which, back in the 1930’s would have been used to transport wealthy Gold Coast clientele to Wall Street, literally landing in the river. HARP is open to the public on Tuesdays and Thursdays from 9am to 1pm, Saturdays from 9am to 4pm, with ranger guided tours on Sundays from 2pm to 4pm.
The dream of a restored Floyd Bennett Field for recreational use with water-access must not be forgotten. The field's coast is a polluted cemetery for destroyed boats and debris. In short - It is the disgrace of Gateway! The restoration of the boat docks at Floyd Bennett Field and at Canarsie Pier would allow for the use of on-again, off- again water ferries at peak times to facilitate the movement of participants of large outdoor events at Gateway as well as for visitors to the Park and Aviator’s Sports Complex at Floyd Bennett Field. It would also provide a ferry commuter connection with other parts of the borough and city. The current Ferry Service Plan includes neighborhoods in all the boroughs as a link to existing ferry service to Manhattan. The service for South Brooklyn is in Bay Ridge. Mayor de Blasio promised us Ferry Service at Canarsie Pier without any results. Despite community opposition, he chose, instead, to add a ferry stop for the Coney Island area.
As a result of Super Storm “Sandy,” the Canarsie “L” Train Tunnel was flooded with seven (7) million gallons of salt water, which damaged all the electrical and communication equipment, as well as the concrete lining to the tunnel. The massive reconstruction work necessary to repair the Canarsie Tunnel is causing anticipated disruption of “L” Train service between Manhattan and Brooklyn. We will continue to work with the MTA, NYC DOT and City and State agencies to determine service levels needed to accommodate our ridership during the rehabilitation.
As we usher in the 7th Anniversary of Super Storm “Sandy,” we remain appalled by the lack of speed and clarity in not developing a strengthened coastal defense resiliency plan for our shoreline as the first line of defense against flooding and sea level rise. The Build-it-Back Program has been an absolute failure! The hopes that all of the shore communities shared after October 29, 2012 have never been realized and have been “washed away” in a sea of bureaucracy, indifference and red tape. Long range storm protection remains one of our top priorities. We must continue to partner with all levels of Government to make this battle to protect our shoreline communities a reality rather than another report lying in a pile of reports in some agency. Future additional funding through the Disaster Relief Appropriations Act of 2013 is necessary to implement short and long range goals for rebuilding and enhancing our infrastructure to accept the potential of another super storm surge. The Army Corps of Engineers must advance their flood protection plans to fortify the seawall side of the peninsula with the erection of seawalls and gates around the waterfront that could open or close in a storm threat to divert or redirect the surge.
We continue to look to the de Blasio Administration for a “boots-on-the-ground” comprehensive program of infrastructure improvement, reconstruction and development. Shocking as it may seem, our shore communities, almost seven (7) years since “Sandy,” find ourselves still re-building and recovering. With immeasurable loss of property, businesses and lives, the approach has to be less than “Band-Aid” therapy for our arterial bleeding.
We are guardingly optimistic that the Capital and Expense Budget will be more “backbone” and less “wishbone.” Our Board looks forward to a vigorous and enlightening Budget Process in the coming fiscal year.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 18
image
The three most pressing issues facing this Community Board are:
Parks
PARKS: Community Board 18 has the distinction of being "home" to the largest acreage of parkland in the City utilized by visitors from all over the city. Marine Park is home to 798 Acres of parkland and Canarsie Park is home to
132.2 Acres of parkland. Portions of both parks have been improved with recreational facilities. Marine Park also houses a nature center and nature trail. With that distinction goes a myriad of problems that must be addressed with limited manpower and equipment. Borough Commissioner, Martin Maher, and Department of Parks and Recreation Personnel, in general, demonstrate a generous spirit of cooperation and assistance in delivering timely, quality service to address the needs of our community. Within our Community Board are numerous small “vest pocket” parks that require regular attention and maintenance. Commissioner Silver calls it a framework for an equitable future. We feel that equity should include the communities that we serve and we look forward to new funds dedicated to upgrading and maintaining our neighborhood parks. We call upon the Administration to supply the Department of Parks and Recreation with the funds and tools necessary to adequately provide maintenance and care of our "under-resourced" parks and large tree population, and to provide quality recreational and cultural outlets for all ages.
Infrastructure resiliency
INFRASTRUCTURE RESILIENCY: On October 29, 2012, in the wake of super-storm “Sandy,” the East Coast saw the destruction of whole communities, businesses and infrastructure. Our neighborhoods were no exception and are still recovering. Bergen Beach, Canarsie, Gerritsen Beach/Plumb Beach, Marine Park and Mill Island suffered wide- spread damage … double-digit millions in property damage … untold personal loss … businesses destroyed and disrupted … lives lost and families uprooted. The very fabric of our neighborhoods and road conditions were torn apart. Build-it-Back is still attempting to repair damages to homes caused by their original inferior repairs. Sewers and water delivery systems must be upgraded so catch basins and storm sewers can properly drain the roadways during heavy rain storms. Resiliency programs for our waterfront communities are necessary to prevent future flooding disasters for our environment and the quality of life for our communities and residents.
Street conditions (roadway maintenance)
STREET CONDITIONS: Our street system was, in most part, build on unsupported land fill. The streets, road bed and sewer system are old and in need of full reconstruction ... not just repair ... which is nothing short of a "band aid to control arterial bleeding." They are in various stages of collapse and require personnel and funding for a staged reconstruction plan by DOT and DEP to turn the plan into reality.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 18
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
Our senior population needs the Administration to provide a "boots-on-the ground" commitment to rehabilitate, upgrade and perform an extensive modernization of our facilities and services. These facilities will provide sorely needed recreational and rehabilitative activities for our seniors to live long, productive lives. They will also be able to provide quality intergenerational programs and activities for our energetic youth population. Our network of senior centers is not fully funded to provide hot meals, not only on the weekdays, but the weekends as well.
Funding should be made available to increase the meal and senior advocacy programs throughout the Board area. Programming must provide intense outreach to identify and provide services for home-bound seniors in need of services.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Community Board 18 is the "host" to one of the largest and ever-growing senior populations in the City. Our system of senior centers and day programs is grossly inadequate. We need the centers that are currently being run, to be upgraded and at least two (2) full service centers to be built.
Full staffing of Drop-in Day Centers and a structured program of outreach to "shut-in" seniors would help to fill a growing need. Additionally, there is no one-stop location where a senior can go for help and direction. A senior citizen advocate housed at the Community Board makes good old "common sense" and should be considered for future funding.
The Health Care System needs advocacy -- not just hope, but a pressing need for a solid commitment from the Department for the Aging to establish multi-purpose senior facilities and senior housing. We look forward to long and short range objectives for meeting these goals.
Needs for Older NYs
Our senior population needs the Administration to provide a "boots-on-the ground" commitment to rehabilitate, upgrade and perform an extensive modernization of our facilities and services. These facilities will provide sorely needed recreational and rehabilitative activities for our seniors to live long, productive lives. They will also be able to provide quality intergenerational programs and activities for our energetic youth population. Our network of senior centers is not fully funded to provide hot meals, not only on the weekdays, but the weekends as well.
Funding should be made available to increase the meal and senior advocacy programs throughout the Board area. Programming must provide intense outreach to identify and provide services for home-bound seniors in need of services.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 18
image
M ost Important Issue Related to Youth, Education and Child Welfare
After school programs
Our Community Board, since its inception, has worked to build a network of innovative youth and after school programs. However, our goals can NEVER be achieved without an infusion of funding and "real" development by the City. We suggest that the Administration build on the model of the Community Service Society and their approach of the early 80's by bringing to our community a paid coordinator to develop, enhance and support the building of a truly structured Youth Service Agenda.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
We are currently working with our local elected officials, community and youth organizations, to secure funds for special programs designated to address identified youth problems. By reaching students with vitally important services, ranging from mental health support to homework help and family counseling, schools will help at-risk children succeed in the classroom and beyond. While we continue to stress the importance of traditional public school education, we also recognize the role of the Charter School in the "repurposed" educational environment. Consequently, we stand ready to work with all of the stakeholders in advancing the educational structure that best meet the needs of our children. We urge the Administration to continue to support collaboration between administrators, parents, and teachers for all students. The Americans with Disabilities Act (ADA) became federal law in 1990 and states: “No qualified individual with a disability shall, on the basis of disability, be excluded from participation in or be denied the benefits of the services programs, or activities of a public entity, or be subjected to discrimination by any public entity.” The New York City Department of Education (DOE) data indicates that only one
(1) out of every five (5) city schools is fully accessible to students, parents, staff and other community members with physical disabilities. Students with physical disabilities find themselves cut off from the majority of DOE schools because of architectural barriers and are, instead, forced to travel significant distances and make academic and curricular compromises to attend schools they can physically access. We call upon the New York City Department of Education to include $850 million additional funding in their 2020-2024 Capital Plan for accessibility projects with the goal of making at least one-third of New York City public schools in each district ADA accessible to help create a system where all are welcomed and included.
Needs for Youth and Child Welfare
There is an increasing need for child day care services as well as after school programs. Both parents working, as well as single parent households, created a desperate need for day care and after school activities for our youth.
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 18
image
M ost Important Issue Related to Public Safety and Emergency Services
Public Nuisance (noise, other disturbances)
Public Nuisance crimes such as loud noise, illegal parking, double parking, and the removal of abandoned and/or "For Sale" vehicles and 18-wheeler trucks parked on our streets must be aggressively addressed. It's unacceptable for abandoned vehicles to remain in the same location for one (1) month or longer without action, or for trucks or other illegally parked vehicles not to be removed within a few days from the city streets. The Administration must establish stronger enforcement with severe penalties for these violations as well as for the operation of licensed, unlicensed, and "dollar" vans illegally operating and parking in our communities, primarily in and around the Kings Plaza Shopping Center, and the illegal parking of Dealer cars in the Kings Plaza Shopping Center Garage. Rather than develop a strategy to shift the illegal parking and van problems from block-to-block we must adhere to a strong commitment of interminable rigorous enforcement of these "quality of life" violations.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The need for a new 63rd Precinct Stationhouse continues to be an absolute necessity. Although the Department allocates funds for rehabilitation of the antiquated Stationhouse to meet staffing needs and patrol requirements, the poor conditions and problems still exist. Funding must be set aside for relocation. Since the existence of Community Boards in 1977, we have stressed the need for a New Modern 63rd Precinct House. Each year the Department never includes funding into its Capital Plan. The new Capital Budget, with its excess “dollars” means that this year the project can be funded. We are guardingly optimistic that our wish over these last forty two (42) years becomes a reality. Modern, adequately sized police precincts are essential to good policing.
We urge the NYPD to aggressively explore the acquisition of city-owned properties. Where development costs would be minimized … new Police Precincts Do Not need to be centralized in a community … with the communications available today location is secondary to space needs!!
Needs for Emergency Services
We are optimistic that funds will be increased to establish an even greater emergency service presence for the improvement of service deliveries to battle fires, reduce crime, and enhance quality of life conditions within our Community Board area. Fire protection in a residential community comprising tens of thousands of frame dwellings is, obviously, of paramount concern. The theory used by the Fire Department for "manning" decisions includes statistics that must include, literally, thousands of homes and tens of thousands of area residents residing in those homes as well as the illegally converted apartments that have become part of the Board area since the statistical information was updated. Consequently, analysis of the Department's decision should be the subject of "up-to- date" review not budgetary constraints. We urge the Mayor's Community Affairs Unit (CAU), the Office of Citywide Event Coordination and Management (CECM), and the Department of Information Technology and Telecommunications (DOITT) to continue the strong working relationship between their centralized staff and our Community Board to assist in the coordination and approval of Street Activity Permits and the resolution of community and telecommunication issues and problems. We commend their constant expansion of internet access and support to our Board. The introduction of the multi-functional high tech kiosks is an important step in the introduction of a first-of-its-kind communication network offering up free Wi-Fi, phone calls, charging stations for mobile phones, along with a host of other functions. The Community Board has expressed concern about their placement and strongly suggest that they be placed in heavily travelled transit intersections and not be placed near any school or park. Data report listings posted on NYC.gov was an important step toward sharing 311 Citizen Service Center complaint collection data. However, we continue to stress the need to be informed about specific complaint
collection data encompassing location, tracking and resolution. Interaction and sharing of information between city agencies and the Community Board will continue to enhance service delivery and further our efforts to improve the quality of life for our residents and the business community.
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
2/31 NYPD Provide a new NYPD
facility, such as a new precinct house or sub-precinct
Select Site for 63rd Police Precinct. Renovation is impractical and was disapproved by Police Department's Capital Planning. Consequently, new funding is required.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
3/10
FDNY
Provide more
Increase Funding for Additional Personnel –
firefighters or EMS
FDNY Engine Companies 257, 309, and  323.
workers
Additional personnel necessary to provide
adequate fire protection for our Community
Board area that has increased housing stock
and is plagued throughout with substandard,
illegal apartment conversions.
4/10
NYPD
Assign additional
Increase funding for Additional Personnel – 63rd
uniformed officers
& 69th Police Precincts. We Request Funding for
twenty (20) Police Officers for the 63rd Precinct
and twenty (20) Police Officers for the 69th
Precinct, necessary to perform increased
mandated police responsibilities to patrol the
heavily populated shopping areas, including the
vicinity of the Kings Plaza Shopping Center, and
to enforce parking regulations for the illegally
parked and double parked vehicles in the
community and at the schools, in particular.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 18
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Protective Infrastructure (sea walls, flood walls, etc.)
October marks the 7th anniversary of Super Storm Sandy. While much has been accomplished in repairing and rebuilding our communities, much still remains to be done. Community Board 18 borders on Jamaica Bay. “Sandy” inflicted triple digit millions in property damage to our neighborhoods … destroyed its fabric … dislocated and closed businesses … and brought tragic fatalities to our scenic communities. The "Build It Back" Program proved to be a total failure in providing aid to our ravaged community. It was only after Mayor de Blasio, and our elected officials made a concerted effort to repurpose the program that we began to see some tangible results. Homes began to be rebuilt, businesses began to re-open, and plans were drawn to bring new life into a failed bureaucratic nightmare. There is still much to be done for homeowners and businesses to fully recover! The New York City Panel on Climate Change (NPCC) uses global climate models and a range of scenarios to develop climate projections relating to future population, economic growth, and technological change. Future 100 year Flood Zones clearly states that by the 2020’s there is an expected 10’ sea level rise. The NPCC projects that by mid-century (2050), sea levels could rise up to 21 inches, up to 39 inches by the 2080's, posing a significant threat to New York City’s low- lying neighborhoods, not just during storms, but also in the case of tidal flooding. Additionally, the NPCC predicts that there will be an increase in the most intense hurricanes occurring in the North Atlantic Basin. Higher temperatures and increased coastal flooding are the greatest risks. We must quickly build a stronger, more resilient New York. We must continue to partner with all levels of Government to make this battle to protect our shoreline communities a reality rather than another report lying in a pile of reports in some agency. Future additional funding through the Disaster Relief Appropriations Act of 2013 is necessary to implement short and long range goals for rebuilding and enhancing our infrastructure to accept the potential of another super storm surge. The Army Corps of Engineers must advance their flood protection plans to fortify the seawall side of the peninsula with the erection of seawalls and gates around the waterfront that could open or close in a storm threat to divert or redirect the surge.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
In the wake of Super-Storm Sandy … After the storm, press releases were issued, promises were made and commitments were assured. Nevertheless, those commitments and promises have had little, if any, tangible effects. Billions of dollars were sent to the City and State from the Federal Government. Sad to say after almost seven (7) years, few of our communities including those now sitting in the “A” Zone of the newly drawn Flood Zone Maps, have seen little of these dollars or productive re-build programs. The de Blasio Administration was handed a bureaucratic mess. Only now have they been able to start the process of making actual awards to begin the rebuilding and repair process. It’s still slow and bogged down in administrative “red tape.”
Public Forums funded by the Governor’s Office of Storm Recovery - New York Rising Community Reconstruction Program, and the Mayor’s Office of Housing Recovery Operations, must continue to rebuild neighborhoods impacted by "Sandy" and, through community-driven plans, prepare them to become more resilient.
Funds have been allocated and the reconstruction is in progress for the Canarsie community area sewer system from the East 108th Street area, Flatlands to Seaview Avenues. We must continue to fund the reconstruction of all our old, deteriorated and inadequate sewer systems to upgrade and meet the increased usage demand to eliminate future flooding and hazardous road conditions.
Needs for Sanitation Services
BK18 supervision and personnel have been exemplary in their willingness and demonstrated ability to work with the Board in developing the maximum potential with their limited manpower and equipment to deliver quality service
to a community experiencing ever-increasing population growth and needs as they implement further source separation and recycling programs. Recycling continues to be another top priority ... a daunting challenge in our residential community which requires more outreach and education to area residents and homeowners. Increased manpower is also needed to maintain the numerous center malls along our roadways. Neglected and unattended they grow into breeding grounds for vermin and illegal dumping creating a community nuisance and safety hazard. Lot cleaning, attention to the ASP cleaning schedule and the quick removal of the illegally placed clothing bins is a top priority. Stronger laws and enforcement with severe penalties for the placement of illegal “Clothing Donation Bins” placed throughout our communities and on private property parking lots have been put in place. Develop a strategy to “tag” the bins only to have them shifted to another must also adhere to a strong commitment of interminable rigorous enforcement of this "quality of life" violation. Snow removal is obviously one of the top priorities for the Department. After the thaw we are inundated with sink and pot holes caused by the road salt. We urge the City to move forward with the use of less corrosive snow removal materials.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
5/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Church Lane
project for specific
in conjunction with DOT, on Church Lane from
Remsen
street segments
Remsen Avenue to East 86 Street. These streets
Avenue East
currently lacking
are deteriorated. Serious flooding and buckling
87 Street
sanitary sewers
exists causing hazardous pedestrian and
vehicular travel conditions.
7/31
DEP
Develop a capital
Construct Catch Basins and Sanitary Sewers, in
East 99 Street
project for specific
conjunction with DOT, on East 99 Street
Flatlands
street segments
(mapped street), between Flatlands & Conklin
Avenue
currently lacking
Avenues. Serious flooding and hazardous road
Conklin
sanitary sewers
conditions exist. This street is not opened or
Avenue
maintained and needs to be constructed for
pedestrian and vehicular travel safety.
8/31
DEP
Evaluate a public
Construct bio swales with flowers and
Flatbush
location or property
shrubberies along the eastern right-of-way of
Avenue Belt
for green
Flatbush Avenue, south of the former Toys R Us
Parkway
infrastructure, e.g.
building, and the city-owned lot fronting Four
Avenue Z
rain gardens,
Sparrows Marsh, and north of the Westbound
stormwater
Belt Parkway ramp onto Flatbush Avenue.
greenstreets, green
Flatbush Avenue just north of the Belt Parkway
playgrounds
is the gateway to Community Board 18's
neighborhoods and to Southern Brooklyn. This
section of roadway is without a storm water
filter system, thus storm water runoff from the
road flows unfiltered into Mill Basin. The
construction of bios wales presents an
opportunity to both beautify Flatbush Avenue as
well as filter storm water.
10/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Avenue L East
project for specific
in conjunction with DOT, on Avenue L, between
69 Street East
street segments
East 69 Street and East 70 Street. Serious
70 Street
currently lacking
buckling, flooding, and hazardous road
sanitary sewers
conditions exist. This street is heavily travelled
and needs to be reconstructed for pedestrian
and vehicular travel safety.
12/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 72 Street
project for specific
in conjunction with DOT, on East 72 Street,
Ralph Avenue
street segments
between Ralph Avenue and Avenue M. Serious
Avenue M
currently lacking
buckling, flooding, and hazardous road
sanitary sewers
conditions exist. These streets are heavily
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
14/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Avenue M
project for specific
in conjunction with DOT,on Avenue M, between
East 66 Street
street segments
East 66 Street and Bergen Avenue. Serious
Bergen
currently lacking
buckling, flooding, and hazardous road
Avenue
sanitary sewers
conditions exist. These streets are heavily
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
16/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 38 Street
project for specific
in conjunction with DOT, on East 38 Street, from
Kings
street segments
Kings Highway to Flatlands Avenue. Serious
Highway
currently lacking
flooding and hazardous road conditions exist.
Flatlands
sanitary sewers
These streets are heavily travelled and need to
Avenue
be reconstructed for pedestrian and vehicular
travel safety.
18/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Foster
project for specific
in conjunction with DOT, on Foster Avenue, from
Avenue Ralph
street segments
Ralph Avenue to Remsen Avenue. Serious
Avenue
currently lacking
buckling, flooding, and hazardous road
Remsen
sanitary sewers
conditions exist. These streets are heavily
Avenue
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
20/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 45 Street
project for specific
in conjunction with DOT, on East 45 Street, from
Avenue H
street segments
Avenue H to Avenue I. Serious buckling, flooding
Avenue I
currently lacking
and hazardous road conditions exist. This street
sanitary sewers
is heavily travelled and needs to be
reconstructed for pedestrian and vehicular
travel safety.
22/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 56 Street
project for specific
in conjunction with DOT, on East 56 Street, from
Avenue J
street segments
Avenue J to Avenue K. Serious buckling, flooding
Avenue K
currently lacking
and hazardous road conditions exist. This street
sanitary sewers
is heavily travelled and needs to be
reconstructed for pedestrian and vehicular
travel safety.
24/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Flatlands 7
project for specific
in conjunction with DOT, on Flatlands 7 Street,
Street East
street segments
from East 105 Street to East 108 Street. Serious
105 Street
currently lacking
buckling, flooding, and hazardous road
East 108
sanitary sewers
conditions exist. This street is heavily travelled
Street
and needs to be reconstructed for pedestrian
and vehicular travel safety.
28/31
DEP
Develop a capital project for specific street segments currently lacking sanitary sewers
Reconstruct Catch Basins and Sanitary Sewers, in conjunction with DOT, on East 80 Street, from Foster Avenue to Glenwood Road. Serious buckling, flooding, and hazardous road conditions exist. These streets are old, deteriorated, heavily travelled, and need to be reconstructed for pedestrian and vehicular travel safety.
East 80 Street Foster Avenue Glenwood Road
30/31
DEP
Develop a capital project for specific street segments currently lacking sanitary sewers
Reconstruct Catch Basins and Sanitary Sewers, in conjunction with DOT, on Avenue N, from East 85 Street to Remsen Avenue. Serious buckling, flooding, and hazardous road conditions exist.
These streets are heavily travelled and need to be reconstructed for pedestrian and vehicular travel safety.
Avenue N East 85 Street Remsen Avenue
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
5/10
DSNY
Other cleaning
Assign Additional Personnel – Department of
requests
Sanitation. Fund additional personnel for
Brooklyn Sanitation District 18 to provide
increased maintenance, lot cleaning, basket
collection, and enforcement responsibilities.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 18
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Future land use must be controlled by zoning, public policy, and land use regulations intended to promote activities appropriate to preserve the neighborhood character and infrastructure for those who live and work there. The approval of the Zoning Text Amendments sends a clear signal of the intent of the City Administration to impact neighborhood development. We must continue to review regulations to determine if the zoning does, in fact, reflect current and future housing conditions and needs. A partner in the planning process is the Board of Standard and Appeals (BSA). BSA's original mission was to provide a relief valve for property owners in those rare circumstances where existing zoning regulations prohibited them from reasonably developing their property. BSA is frequently misused to circumvent and twist the spirit and intent of the Zoning Resolution.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
On June 30, 2009 the City Council approved the DCP ULURP Application for lower density and contextual zoning map changes for the Canarsie neighborhood. Community Board 18 unanimously supported the ULURP Application. That text amendment has set the standard for future development. We support further review by DCP and urge new efforts be made to address the population growth and the inequities in R-32A and R-4 Zoning Districts which cover large areas of our Board. It is the sense of this Board that all of the communities within our Board be reviewed to create a rational up-to-date zoning plan that reflects natural residential, commercial, and manufacturing boundaries. The current land use is largely an artifact of historical urbanization.
Future land use must be controlled by zoning, public policy, and land use regulations intended to promote activities appropriate to preserve the neighborhood character and infrastructure for those who live and work there. The approval of the Zoning Text Amendments sends a clear signal of the intent of the City Administration to impact neighborhood development. We must continue to review regulations to determine if the zoning does, in fact, reflect current and future housing conditions and needs.
A partner in the planning process is the Board of Standard and Appeals (BSA). BSA's original mission was to provide a relief valve for property owners in those rare circumstances where existing zoning regulations prohibited them from reasonably developing their property. BSA is frequently misused to circumvent and twist the spirit and intent of the Zoning Resolution.
Needs for Housing
After decades of neglect and mismanagement, NYCHA finds themselves having to address the cover-up that has drawn national attention to the reality that lead paint, asbestos, faulty boilers as well as broken elevators has made the City of New York the nation's largest slumlord. We are guardingly optimistic that the Court Appointed Monitor and mandated repairs will bring some measure of relief to the tenants of NYCHA properties that have had to endure these hardships.
Needs for Economic Development
EDC’s priorities are not necessarily “in sync” with the communities and the community boards. So, at this time, we respectfully request that any other plans or intrusions into our community, under the guise of economic development, should be shared with us in its earliest phase rather than be notified when the matter is a “fait accompli,” e.g., the “Booze Boats.”
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
2/10 EDC Improve public
housing maintenance and cleanliness
Increase Funding for Additional New York City Housing Authority (NYCHA) Maintenance Staff. Fund additional personnel essential to address all ongoing health and safety issues at the areas three (3) NYCHA housing Projects Bayview, Breukelen and Glenwood.
image
9/10 DOB Assign additional
building inspectors (including expanding training programs)
Assign Additional Building Inspectors - Department of Buildings. There is a drastic need for additional inspectors to enforce Building Code Compliance for new construction, renovations and occupancy of existing buildings.
TRANSPORTATION
Brooklyn Community Board 18
image
M ost Important Issue Related to Transportation and Mobility
Roadway maintenance
Transportation needs, particularly total street and sewer reconstruction, contract resurfacing, and scheduled repair of the roadways within the Board area, presents an ever increasing challenge. Canarsie and surrounding communities were built on landfill that rapidly deteriorated and require aggressive street and sewer reconstructive programs. The Community Board urges the Department of Transportation to advance our Board's meager Capital Project requests. Street resurfacing is a temporary "costly fix” … not a solution. It’s “band aid” therapy for a hemorrhage! Our roadways have recently seen a high increase of “sink holes” as a result of the road bed undermining from “Sandy.” An emergency “hands-on” effort by DOT and DEP must address this major community need and concern.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The DOT has undertaken the "Reconstruction of the Seven (7) Bridges on the Belt Parkway" which commenced with minimal impact in November 2009 with the first of three contracts in our Board area - Fresh Creek Bridge, Paerdegat Basin Bridge, two (2) separate bridges eastbound and westbound, and the Rockaway Parkway Bridge. The Mill Basin Draw Bridge, a fixed structure with 60-foot clearance over "Mean High Water" obviating the need for opening and closing the bridge, is now scheduled for completion. All impacts to wetlands will be mitigated in accordance with Federal and State regulations. The landscaping contract will complete the project this year.
Transportation issues persist to rank high on the problem list for our Community Board. Pedestrian, cyclist, and motor vehicle occupant safety at many of the intersections and streets within our Board area are the source of major concern. With no enforcement of regulations in place, the administration is still aggressively expanding biker- friendly infrastructure. The number of bile paths citywide has more than doubled in the last decade. Bicycle lanes clearly offer both an environmental and practical benefit in areas served by adequate mass transit alternatives and a biker-friendly population. Bike lanes, if not properly placed and enforced, will only create hazardous conditions in our board area and jeopardize the safety of pedestrians, cyclists, and motor vehicle occupants.
Public education and community participation in new street designs and configurations to improve safety must continue to be an integral part of the planning and placement process along with expanded enforcement against dangerous moving violations for drivers and cyclists to ensure safety on city streets.
Needs for Transit Services
Numerous costly and time consuming studies have been performed by outside consultants, the Departments of Transportation and City Planning, as well as the Borough President's Office, in an effort to improve pedestrian, vehicular, and bus circulation problems at the intersection of Flatbush Avenue and Avenue U. It remains one of the most accident plagued intersections in the city. The studies continue to identify the same problems and continue to propose a myriad number of improvements including changes in bus stop locations and operations, directional signage, street configuration with the widening of Avenue U and Flatbush Avenue, and the installation of pedestrian safety fencing along the South side of Avenue U, from Flatbush Avenue to East 55th Street, and on the center traffic island on Flatbush Avenue, between Avenues U and V. Conditions were worsened by the creation of a "bus layover/turnaround" and an illegal "dollar" van pick-up area on Flatbush Avenue at Avenue U, in and around Kings Plaza Shopping Center. The "App" driven car services send an Uber or Lyft to that location and have taken a bad situation and made it worse. They added to the congestion and made Flatbush Avenue and Avenue U crossroads into a pedestrian and motor vehicle traffic nightmare! Our Community Board included in our Capital Budget Priorities and Requests a request for the construction of an elevated pedestrian overpass at this intersection. -- To date... nothing of consequence has been done, except for the creation of a major "bus layover/turnaround" in front
of the Kings Plaza Shopping Center causing buses, leaving the layover, to sharply cross five (5) lanes of traffic on Flatbush Avenue to turn left onto Avenue U. The widening of the traffic islands on Flatbush Avenue has created additional confusion, danger, and further bottleneck at this dangerous intersection! All the studies performed...All the dollars spent...All the changes suggested...All the promises made...All the time and money wasted -- To date...nothing of consequence has been done. The problem is self-evident -- the solutions have been proposed -- implement the recommendations. The intersection of Flatlands and Ralph Avenues continues to be problematic with constant traffic congestion and hazardous pedestrian crossings. Traffic congestion on Ralph Avenue was exacerbated by what was projected by DOT as an engineering solution when, in fact, it complicated an already existing problem. These recent so-called "improvements," under the guise of "Vision Zero," have created hardship for the motorists, pedestrians and the City's long-time landscaping nursery tenant on the corner of Ralph and Flatlands Avenues. The MTA Select Bus Service (SBS) has failed to improve "bus reliability" ... the bus riders' chief complaint. The installation of dedicated bus lanes and longer bus stops, to accommodate the longer buses, has succeeded in causing a reduction of parking spaces for homeowners, shoppers and the inability for businesses to receive curbside deliveries during peak hours. Many of our heavily travelled roads were not designed for single-lane motor vehicle traffic, bus and bicycle lanes. The dedicated bus lane signage is confusing to motorists and pedestrians, and should ONLY ensure the lanes remain clear during peak hours and violators fined ONLY during peak hours. We implore the Administration to place a moratorium on new SBS routes until the MTA and DOT can provide a complete, fair and accurate analysis to include SBS reliability, peak hour ridership, ridership fare evasion or fare machine reliability, pedestrian street access, and motorist traffic flow.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/31
DOT
Improve traffic and
Install Pedestrian Safety Fences on the South
Avenue U
pedestrian safety,
Side of Avenue U, adjacent to Kings Plaza
Flatbush
including traffic
Shopping Center, from Flatbush Avenue to East
Avenue East
calming (Capital)
55 Street. To improve pedestrian and vehicular
55 Street
safety at Kings Plaza Shopping Center and
adjacent M.T.A. Bus turnaround.
3/31
DOT
Improve traffic and
Construct pedestrian elevated overpass at
Flatbush
pedestrian safety,
Flatbush Avenue & Avenue U, to improve
Avenue
including traffic
pedestrian and vehicular safety at this
Avenue U
calming (Capital)
dangerous intersection. Heavily travelled and
Flatbush
congested bus turnaround located adjacent to
Avenue
Kings Plaza Shopping Center as well as the
constant line up of "dollar" vans, adds to
hazardous pedestrian and vehicular travel
safety conditions at this location.
4/31
DOT
Reconstruct streets
Reconstruct Church Lane roadway and raise to
Church Lane
grade, in conjunction with DEP, from Remsen
Remsen
Avenue to East 86 Street to include new
Avenue East
sidewalks. These streets are deteriorated and
86 Street
not at grade. Serious flooding and buckling
exists causing hazardous pedestrian and
vehicular travel safety conditions.
6/31
DOT
Reconstruct streets
Construct and open roadway, in conjunction
East 99th
with DEP, East 99 Street (mapped street),
Street
between Flatlands & Conklin Avenues. Serious
Flatlands
flooding and hazardous road conditions exist.
Avenue
This street is not opened or maintained and
Conklin
needs to be constructed for pedestrian and
Avenue
vehicular travel safety.
9/31
DOT
Reconstruct streets
Reconstruct Avenue L roadway, in conjunction
Avenue L East
with DEP, from East 69 Street to East 70 Street.
69 Street East
Serious buckling, flooding, and hazardous road
70 Street
conditions exist. This street is heavily travelled
and needs to be reconstructed for pedestrian
and vehicular travel safety.
11/31
DOT
Reconstruct streets
Reconstruct East 72 Street roadway, in
East 72nd
conjunction with DEP, from Ralph Avenue to
Street Ralph
Avenue M. Serious buckling, flooding, and
Avenue
hazardous road conditions exist. These streets
Avenue M
are heavily travelled and need to be
reconstructed for pedestrian and vehicular
travel safety.
13/31
DOT
Reconstruct streets
Reconstruct Avenue M roadway, in conjunction
Avenue M
with DEP, from East 66 Street to Bergen Avenue.
East 66th
Serious buckling, flooding, and hazardous road
Street Bergen
conditions exist. These streets are heavily
Avenue
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
15/31
DOT
Reconstruct streets
Reconstruct East 38 Street roadway, in
East 38 Street
conjunction with DEP, from Kings Highway to
Kings
Flatlands Avenue. Serious flooding and
Highway
hazardous road conditions exist. These streets
Flatlands
are heavily travelled and need to be
Avenue
reconstructed for pedestrian and vehicular
travel safety.
17/31
DOT
Reconstruct streets
Reconstruct Foster Avenue roadway, in
Foster
conjunction with DEP, from Ralph Avenue to
Avenue Ralph
Remsen Avenue. Serious buckling, flooding, and
Avenue
hazardous road conditions exist. These streets
Remsen
are heavily travelled and need to be
Avenue
reconstructed for pedestrian and vehicular
travel safety.
19/31
DOT
Reconstruct streets
Reconstruct East 45 Street roadway, in
East 45th
conjunction with DEP, from Avenue H to Avenue
Street Avenue
I. Serious buckling, flooding and hazardous road
H Avenue I
conditions exist. This street is heavily travelled
and needs to be reconstructed for pedestrian
and vehicular travel safety.
21/31
DOT
Reconstruct streets
Reconstruct East 56 Street roadway, in
East 56 Street
conjunction with DEP, from Avenue J to Avenue
Avenue J
K. Serious buckling, flooding and hazardous
Avenue K
road conditions exist. This street is heavily
travelled and needs to be reconstructed for
pedestrian and vehicular travel safety.
23/31
DOT
Reconstruct streets
Reconstruct Flatlands 7 Street roadway, in
Flatlands 7
conjunction with DEP, from East 105 Street to
Street East
East 108 Street. Serious buckling, flooding, and
105 Street
hazardous road conditions exist. This street is
East 108
heavily travelled and needs to be reconstructed
Street
for pedestrian and vehicular travel safety.
25/31
DOT
Improve traffic and
Construct the mapped, unbuilt street end of
Avenue W
pedestrian safety,
Avenue W between East 69 Street and the dead
East 69 Street
including traffic
end, including barriers and signage. Serious
Dead End
calming (Capital)
hazardous road conditions exist. This street end
needs to be constructed for pedestrian and
vehicular safety.
26/31
DOT
Improve traffic and
Construct the mapped, unbuilt street end of
Avenue X East
pedestrian safety,
Avenue X, between East 69 Street and the dead
69 Street
including traffic
end, including barriers and signage. Serious
Dead End
calming (Capital)
hazardous road conditions exist. This street end
needs to be constructed for pedestrian and
vehicular safety.
27/31
DOT
Reconstruct streets
Reconstruct East 80 Street roadway from Foster
East 80th
Avenue to Glenwood Road, in conjunction with
Street Foster
the Department of Environmental Protection's
Avenue
reconstruction of catch basins and sanitary
Glenwood
sewers. Serious buckling, flooding, and
Road
hazardous road conditions exist. These streets
are old, deteriorated, heavily travelled, and
need to be reconstructed for pedestrian and
vehicular travel safety.
29/31
DOT
Reconstruct streets
Reconstruct Avenue N Roadway, in conjunction
Avenue N
with DEP, from East 85 Street to Remsen
East 85 Street
Avenue. Serious buckling, flooding, and
Remsen
hazardous road conditions exist. These streets
Avenue
are heavily travelled and need to be
reconstructed for pedestrian and vehicular
travel safety.
CS
DOT
Reconstruct streets
Reconstruction of Avenue K roadway, between
Avenue K
Bergen Avenue and Ralph Avenue, in
Bergen
conjunction with the Department of
Avenue Ralph
Environmental Protection's reconstruction of
Avenue
Catch Basins and Sanitary Sewers. Serious
buckling, flooding, and hazardous road
conditions exist. These streets are heavily
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
Reconstruction is in process.
CS
DOT
Reconstruct streets
Reconstruction of East 108 Street roadway, from
East 108th
Flatlands to Seaview Avenues, in conjunction
Street
with the Department of Environmental
Flatlands
Protection's Reconstruction of Catch Basins and
Avenue
Sanitary Sewers. Serious buckling, flooding, and
Seaview
hazardous road conditions exist. These streets
Avenue
are old, deteriorated, heavily travelled and need
to be reconstructed for pedestrian and vehicular
travel safety. Reconstruction is in process.
CS DOT Reconstruct streets Reconstruction of Bergen Avenue roadway from
Avenues K to L, and from Royce Place to Avenue U -- including raised center traffic islands, sidewalks, curbs, and designated parking spaces on the East side of Bergen Avenue -- in conjunction with the Department of Environmental Protection's reconstruction of Catch Basins and Sanitary Sewers, where necessary. These streets are old, deteriorated and heavily travelled and need to be reconstructed. Raised Center Traffic Islands are for pedestrian and vehicular travel safety.
Reconstruction is in process.
Bergen Avenue Avenue K to Avenue L Royce Place to Avenue U
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
8/10
DOT
Other expense
Increase Funding for Additional Personnel for
traffic
Street Maintenance - Department of
improvements
Transportation. Funding request to hire
requests
additional maintenance workers for asphalt
crews and street repair maintenance workers to
maintain our heavily travelled, aging streets
and infrastructure.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 18
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
The maintenance and upkeep of our parks and playgrounds continues to remain a major area of concern due to insufficient staffing and funding. Some parks and playgrounds in our District are in various stages of design, scope and reconstruction. The Board fully supports the continued funding of these projects. Several of our smaller parks and playgrounds require reconstruction or "in-house" spruce-up. We urge that these projects as well as increased staffing be addressed through the Capital and Expense Budget. The Greenstreets Program provides us with an opportunity to beautify our barren neighborhood triangles and traffic islands. We wholeheartedly support the continuation of this program. Seasonal plantings must be part of the program for it to “win” broader acceptance and acclaim. We encourage strategies for additional conservation and beautification programs. They must include sorely needed maintenance provisions. Parks' Department equipment and personnel are always in short supply. We urge that our requests, as well as Departmental requests, be given a high priority in budget negotiations for adequate maintenance and operation of our parks. The park areas within Community Board 18 provide recreational and cultural outlets for all ages and neighborhoods, and are truly a valued natural resource that must be protected and maintained. As previously stated, Marine Park comprising 798 acres, and Canarsie Park comprising
132.2 acres, are regional facilities that serve a large population outside our local neighborhoods. The large geographic area of our Community Board and its residential neighborhoods are also the "home" to the largest street tree population in the Borough. Department of Parks and Recreation budget allocations for Forestry and Maintenance must be increased to adequately address the needs of our huge parkland and tree population.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The maintenance, upkeep and improvement of our parks and playgrounds is a major concern, as previously stated.
Needs for Cultural Services
Community Board 18 supports an enhancement, on a city-wide basis, of our world-class Cultural Institutions and Programs. The New York City Department of Cultural Affairs (DCLA) is dedicated to supporting and strengthening New York City's vibrant cultural life. Among their primary missions is to ensure adequate public funding for non- profit cultural organizations, both large and small, throughout the five boroughs. DCLA also works to promote and advocate for quality arts programming and to articulate the contribution made by the cultural community to the City's economic vitality. The Department represents and serves non-profit cultural organizations involved in the visual, literary and performing arts; public-oriented science and humanities institutions including zoos, botanical gardens and historic and preservation societies; and creative artists at all skill levels who live and work within the City's five boroughs. Through its Materials for the Arts Program, DCLA provides free supplies for use in arts programs offered by non-profit groups and New York City public schools. DCLA has also changed the physical landscape of New York City through its Percent for Art program by commissioning more than 180 works of art by some of the world's leading artists at public building sites throughout the city. We support their efforts and funding sources.
Needs for Library Services
Our Community Board is "home" to five (5) branches of the Brooklyn Public Library -- Canarsie, Flatlands, Jamaica Bay, Mill Basin, and Paerdegat. The hours of operation must be permanently extended to provide easy access to accommodate the needs of our children and working-class population. Funds must be allocated to inspect, upgrade and maintain these buildings to provide our residents with up-to-the-minute information, program and technical access opportunities.
Needs for Community Boards
We urge the Administration to increase the budgets of Community Boards to allow for the hiring of a "planner" consistent with Sections 191(b)(5) and 2800(g) of the City Charter and for additional office staff in order to meet the increasing needs of the community for government access, information and programs. Community Board 18 and Community Boards, in general, cannot perform Charter mandated responsibilities with the current meager budget allocation.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
31/31
DPR
Reconstruct or
Reconstruct the Marine Park Oval, Baseball
Avenue U,
upgrade a park or
Fields and Playground. Flooding and hazardous
Brooklyn,
playground
conditions prevent safe recreational use. Marine
New York, NY
Park attracts thousands of visitors, weekly, from
all over the City. This level of usage has worn
down the park's infrastructure. Council Member
Maisel secured $4,500,000 toward the
reconstruction of the Oval Project. Additional
funding is necessary to complete the all
renovations.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/10
OMB
Provide more
Increase the budgets of Community Boards to
community board
allow for the hiring of a planner consistent with
staff
Sections 191(b)(5) and 2800(g) of the City
Charter, and for additional office staff in order
to meet the increasing needs of the community
for government access, information and
programs. Community Board 18 and
Community Boards in general, cannot perform
Charter mandated responsibilities with the
current meager budget allocation.
6/10
DPR
Forestry services,
Assign Additional Personnel - Department of
including street tree
Parks & Recreation. Assign additional personnel
maintenance
for maintenance of parks on a regular basis, and
to staff recreation centers and playgrounds,
provide increased park enforcement and park
ranger programs.
7/10
DPR
New equipment for
Increase funding for New Equipment for
maintenance
Maintenance – Department of Parks &
(Expense)
Recreation. High rangers are needed to prune
the enormous tree population in our area. Due
to the size of the many parks in our area, it is
essential that we have adequate manpower and
equipment.
10/10 BPL Extend library hours
or expand and enhance library programs
Increase Funding - Brooklyn Public Library Increased funding is necessary to maintain this vital community resource. Support for Brooklyn Public Library Expense Budget Requests to PERMANENTLY maintain extended hours of operation, Literacy Initiatives, Improved Salaries for Library Employees, Maintenance of Library Buildings, Public Access to Technology, and New Collections for Brooklyn Readers.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/31
DOT
Improve traffic and
Install Pedestrian Safety Fences on the South
Avenue U
pedestrian safety,
Side of Avenue U, adjacent to Kings Plaza
Flatbush
including traffic
Shopping Center, from Flatbush Avenue to East
Avenue East
calming (Capital)
55 Street. To improve pedestrian and vehicular
55 Street
safety at Kings Plaza Shopping Center and
adjacent M.T.A. Bus turnaround.
2/31
NYPD
Provide a new NYPD
Select Site for 63rd Police Precinct. Renovation is
facility, such as a
impractical and was disapproved by Police
new precinct house
Department's Capital Planning. Consequently,
or sub-precinct
new funding is required.
3/31
DOT
Improve traffic and
Construct pedestrian elevated overpass at
Flatbush
pedestrian safety,
Flatbush Avenue & Avenue U, to improve
Avenue
including traffic
pedestrian and vehicular safety at this
Avenue U
calming (Capital)
dangerous intersection. Heavily travelled and
Flatbush
congested bus turnaround located adjacent to
Avenue
Kings Plaza Shopping Center as well as the
constant line up of "dollar" vans, adds to
hazardous pedestrian and vehicular travel
safety conditions at this location.
4/31
DOT
Reconstruct streets
Reconstruct Church Lane roadway and raise to
Church Lane
grade, in conjunction with DEP, from Remsen
Remsen
Avenue to East 86 Street to include new
Avenue East
sidewalks. These streets are deteriorated and
86 Street
not at grade. Serious flooding and buckling
exists causing hazardous pedestrian and
vehicular travel safety conditions.
5/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Church Lane
project for specific
in conjunction with DOT, on Church Lane from
Remsen
street segments
Remsen Avenue to East 86 Street. These streets
Avenue East
currently lacking
are deteriorated. Serious flooding and buckling
87 Street
sanitary sewers
exists causing hazardous pedestrian and
vehicular travel conditions.
6/31
DOT
Reconstruct streets
Construct and open roadway, in conjunction
East 99th
with DEP, East 99 Street (mapped street),
Street
between Flatlands & Conklin Avenues. Serious
Flatlands
flooding and hazardous road conditions exist.
Avenue
This street is not opened or maintained and
Conklin
needs to be constructed for pedestrian and
Avenue
vehicular travel safety.
7/31
DEP
Develop a capital
Construct Catch Basins and Sanitary Sewers, in
East 99 Street
project for specific
conjunction with DOT, on East 99 Street
Flatlands
street segments
(mapped street), between Flatlands & Conklin
Avenue
currently lacking
Avenues. Serious flooding and hazardous road
Conklin
sanitary sewers
conditions exist. This street is not opened or
Avenue
maintained and needs to be constructed for
pedestrian and vehicular travel safety.
8/31
DEP
Evaluate a public
Construct bio swales with flowers and
Flatbush
location or property
shrubberies along the eastern right-of-way of
Avenue Belt
for green
Flatbush Avenue, south of the former Toys R Us
Parkway
infrastructure, e.g.
building, and the city-owned lot fronting Four
Avenue Z
rain gardens,
Sparrows Marsh, and north of the Westbound
stormwater
Belt Parkway ramp onto Flatbush Avenue.
greenstreets, green
Flatbush Avenue just north of the Belt Parkway
playgrounds
is the gateway to Community Board 18's
neighborhoods and to Southern Brooklyn. This
section of roadway is without a storm water
filter system, thus storm water runoff from the
road flows unfiltered into Mill Basin. The
construction of bios wales presents an
opportunity to both beautify Flatbush Avenue as
well as filter storm water.
9/31
DOT
Reconstruct streets
Reconstruct Avenue L roadway, in conjunction
Avenue L East
with DEP, from East 69 Street to East 70 Street.
69 Street East
Serious buckling, flooding, and hazardous road
70 Street
conditions exist. This street is heavily travelled
and needs to be reconstructed for pedestrian
and vehicular travel safety.
10/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Avenue L East
project for specific
in conjunction with DOT, on Avenue L, between
69 Street East
street segments
East 69 Street and East 70 Street. Serious
70 Street
currently lacking
buckling, flooding, and hazardous road
sanitary sewers
conditions exist. This street is heavily travelled
and needs to be reconstructed for pedestrian
and vehicular travel safety.
11/31
DOT
Reconstruct streets
Reconstruct East 72 Street roadway, in
East 72nd
conjunction with DEP, from Ralph Avenue to
Street Ralph
Avenue M. Serious buckling, flooding, and
Avenue
hazardous road conditions exist. These streets
Avenue M
are heavily travelled and need to be
reconstructed for pedestrian and vehicular
travel safety.
12/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 72 Street
project for specific
in conjunction with DOT, on East 72 Street,
Ralph Avenue
street segments
between Ralph Avenue and Avenue M. Serious
Avenue M
currently lacking
buckling, flooding, and hazardous road
sanitary sewers
conditions exist. These streets are heavily
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
13/31
DOT
Reconstruct streets
Reconstruct Avenue M roadway, in conjunction
Avenue M
with DEP, from East 66 Street to Bergen Avenue.
East 66th
Serious buckling, flooding, and hazardous road
Street Bergen
conditions exist. These streets are heavily
Avenue
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
14/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Avenue M
project for specific
in conjunction with DOT,on Avenue M, between
East 66 Street
street segments
East 66 Street and Bergen Avenue. Serious
Bergen
currently lacking
buckling, flooding, and hazardous road
Avenue
sanitary sewers
conditions exist. These streets are heavily
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
15/31
DOT
Reconstruct streets
Reconstruct East 38 Street roadway, in
East 38 Street
conjunction with DEP, from Kings Highway to
Kings
Flatlands Avenue. Serious flooding and
Highway
hazardous road conditions exist. These streets
Flatlands
are heavily travelled and need to be
Avenue
reconstructed for pedestrian and vehicular
travel safety.
16/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 38 Street
project for specific
in conjunction with DOT, on East 38 Street, from
Kings
street segments
Kings Highway to Flatlands Avenue. Serious
Highway
currently lacking
flooding and hazardous road conditions exist.
Flatlands
sanitary sewers
These streets are heavily travelled and need to
Avenue
be reconstructed for pedestrian and vehicular
travel safety.
17/31
DOT
Reconstruct streets
Reconstruct Foster Avenue roadway, in
Foster
conjunction with DEP, from Ralph Avenue to
Avenue Ralph
Remsen Avenue. Serious buckling, flooding, and
Avenue
hazardous road conditions exist. These streets
Remsen
are heavily travelled and need to be
Avenue
reconstructed for pedestrian and vehicular
travel safety.
18/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Foster
project for specific
in conjunction with DOT, on Foster Avenue, from
Avenue Ralph
street segments
Ralph Avenue to Remsen Avenue. Serious
Avenue
currently lacking
buckling, flooding, and hazardous road
Remsen
sanitary sewers
conditions exist. These streets are heavily
Avenue
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
19/31
DOT
Reconstruct streets
Reconstruct East 45 Street roadway, in
East 45th
conjunction with DEP, from Avenue H to Avenue
Street Avenue
I. Serious buckling, flooding and hazardous road
H Avenue I
conditions exist. This street is heavily travelled
and needs to be reconstructed for pedestrian
and vehicular travel safety.
20/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 45 Street
project for specific
in conjunction with DOT, on East 45 Street, from
Avenue H
street segments
Avenue H to Avenue I. Serious buckling, flooding
Avenue I
currently lacking
and hazardous road conditions exist. This street
sanitary sewers
is heavily travelled and needs to be
reconstructed for pedestrian and vehicular
travel safety.
21/31
DOT
Reconstruct streets
Reconstruct East 56 Street roadway, in
East 56 Street
conjunction with DEP, from Avenue J to Avenue
Avenue J
K. Serious buckling, flooding and hazardous
Avenue K
road conditions exist. This street is heavily
travelled and needs to be reconstructed for
pedestrian and vehicular travel safety.
22/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 56 Street
project for specific
in conjunction with DOT, on East 56 Street, from
Avenue J
street segments
Avenue J to Avenue K. Serious buckling, flooding
Avenue K
currently lacking
and hazardous road conditions exist. This street
sanitary sewers
is heavily travelled and needs to be
reconstructed for pedestrian and vehicular
travel safety.
23/31
DOT
Reconstruct streets
Reconstruct Flatlands 7 Street roadway, in
Flatlands 7
conjunction with DEP, from East 105 Street to
Street East
East 108 Street. Serious buckling, flooding, and
105 Street
hazardous road conditions exist. This street is
East 108
heavily travelled and needs to be reconstructed
Street
for pedestrian and vehicular travel safety.
24/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Flatlands 7
project for specific
in conjunction with DOT, on Flatlands 7 Street,
Street East
street segments
from East 105 Street to East 108 Street. Serious
105 Street
currently lacking
buckling, flooding, and hazardous road
East 108
sanitary sewers
conditions exist. This street is heavily travelled
Street
and needs to be reconstructed for pedestrian
and vehicular travel safety.
25/31
DOT
Improve traffic and
Construct the mapped, unbuilt street end of
Avenue W
pedestrian safety,
Avenue W between East 69 Street and the dead
East 69 Street
including traffic
end, including barriers and signage. Serious
Dead End
calming (Capital)
hazardous road conditions exist. This street end
needs to be constructed for pedestrian and
vehicular safety.
26/31
DOT
Improve traffic and
Construct the mapped, unbuilt street end of
Avenue X East
pedestrian safety,
Avenue X, between East 69 Street and the dead
69 Street
including traffic
end, including barriers and signage. Serious
Dead End
calming (Capital)
hazardous road conditions exist. This street end
needs to be constructed for pedestrian and
vehicular safety.
27/31
DOT
Reconstruct streets
Reconstruct East 80 Street roadway from Foster
East 80th
Avenue to Glenwood Road, in conjunction with
Street Foster
the Department of Environmental Protection's
Avenue
reconstruction of catch basins and sanitary
Glenwood
sewers. Serious buckling, flooding, and
Road
hazardous road conditions exist. These streets
are old, deteriorated, heavily travelled, and
need to be reconstructed for pedestrian and
vehicular travel safety.
28/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
East 80 Street
project for specific
in conjunction with DOT, on East 80 Street, from
Foster
street segments
Foster Avenue to Glenwood Road. Serious
Avenue
currently lacking
buckling, flooding, and hazardous road
Glenwood
sanitary sewers
conditions exist. These streets are old,
Road
deteriorated, heavily travelled, and need to be
reconstructed for pedestrian and vehicular
travel safety.
29/31
DOT
Reconstruct streets
Reconstruct Avenue N Roadway, in conjunction
Avenue N
with DEP, from East 85 Street to Remsen
East 85 Street
Avenue. Serious buckling, flooding, and
Remsen
hazardous road conditions exist. These streets
Avenue
are heavily travelled and need to be
reconstructed for pedestrian and vehicular
travel safety.
30/31
DEP
Develop a capital
Reconstruct Catch Basins and Sanitary Sewers,
Avenue N
project for specific
in conjunction with DOT, on Avenue N, from East
East 85 Street
street segments
85 Street to Remsen Avenue. Serious buckling,
Remsen
currently lacking
flooding, and hazardous road conditions exist.
Avenue
sanitary sewers
These streets are heavily travelled and need to
be reconstructed for pedestrian and vehicular
travel safety.
31/31
DPR
Reconstruct or
Reconstruct the Marine Park Oval, Baseball
Avenue U,
upgrade a park or
Fields and Playground. Flooding and hazardous
Brooklyn,
playground
conditions prevent safe recreational use. Marine
New York, NY
Park attracts thousands of visitors, weekly, from
all over the City. This level of usage has worn
down the park's infrastructure. Council Member
Maisel secured $4,500,000 toward the
reconstruction of the Oval Project. Additional
funding is necessary to complete the all
renovations.
CS
DOT
Reconstruct streets
Reconstruction of Avenue K roadway, between
Avenue K
Bergen Avenue and Ralph Avenue, in
Bergen
conjunction with the Department of
Avenue Ralph
Environmental Protection's reconstruction of
Avenue
Catch Basins and Sanitary Sewers. Serious
buckling, flooding, and hazardous road
conditions exist. These streets are heavily
travelled and need to be reconstructed for
pedestrian and vehicular travel safety.
Reconstruction is in process.
CS
DOT
Reconstruct streets
Reconstruction of East 108 Street roadway, from
East 108th
Flatlands to Seaview Avenues, in conjunction
Street
with the Department of Environmental
Flatlands
Protection's Reconstruction of Catch Basins and
Avenue
Sanitary Sewers. Serious buckling, flooding, and
Seaview
hazardous road conditions exist. These streets
Avenue
are old, deteriorated, heavily travelled and need
to be reconstructed for pedestrian and vehicular
travel safety. Reconstruction is in process.
CS
DOT
Reconstruct streets
Reconstruction of Bergen Avenue roadway from
Bergen
Avenues K to L, and from Royce Place to Avenue
Avenue
U -- including raised center traffic islands,
Avenue K to
sidewalks, curbs, and designated parking spaces
Avenue L
on the East side of Bergen Avenue -- in
Royce Place
conjunction with the Department of
to Avenue U
Environmental Protection's reconstruction of
Catch Basins and Sanitary Sewers, where
necessary. These streets are old, deteriorated
and heavily travelled and need to be
reconstructed. Raised Center Traffic Islands are
for pedestrian and vehicular travel safety.
Reconstruction is in process.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/10
OMB
Provide more
Increase the budgets of Community Boards to
community board
allow for the hiring of a planner consistent with
staff
Sections 191(b)(5) and 2800(g) of the City
Charter, and for additional office staff in order
to meet the increasing needs of the community
for government access, information and
programs. Community Board 18 and
Community Boards in general, cannot perform
Charter mandated responsibilities with the
current meager budget allocation.
2/10
EDC
Improve public
Increase Funding for Additional New York City
housing
Housing Authority (NYCHA) Maintenance Staff.
maintenance and
Fund additional personnel essential to address
cleanliness
all ongoing health and safety issues at the areas
three (3) NYCHA housing Projects Bayview,
Breukelen and Glenwood.
3/10
FDNY
Provide more
Increase Funding for Additional Personnel –
firefighters or EMS
FDNY Engine Companies 257, 309, and  323.
workers
Additional personnel necessary to provide
adequate fire protection for our Community
Board area that has increased housing stock
and is plagued throughout with substandard,
illegal apartment conversions.
4/10
NYPD
Assign additional
Increase funding for Additional Personnel – 63rd
uniformed officers
& 69th Police Precincts. We Request Funding for
twenty (20) Police Officers for the 63rd Precinct
and twenty (20) Police Officers for the 69th
Precinct, necessary to perform increased
mandated police responsibilities to patrol the
heavily populated shopping areas, including the
vicinity of the Kings Plaza Shopping Center, and
to enforce parking regulations for the illegally
parked and double parked vehicles in the
community and at the schools, in particular.
5/10
DSNY
Other cleaning
Assign Additional Personnel – Department of
requests
Sanitation. Fund additional personnel for
Brooklyn Sanitation District 18 to provide
increased maintenance, lot cleaning, basket
collection, and enforcement responsibilities.
6/10
DPR
Forestry services,
Assign Additional Personnel - Department of
including street tree
Parks & Recreation. Assign additional personnel
maintenance
for maintenance of parks on a regular basis, and
to staff recreation centers and playgrounds,
provide increased park enforcement and park
ranger programs.
7/10
DPR
New equipment for
Increase funding for New Equipment for
maintenance
Maintenance – Department of Parks &
(Expense)
Recreation. High rangers are needed to prune
the enormous tree population in our area. Due
to the size of the many parks in our area, it is
essential that we have adequate manpower and
equipment.
8/10
DOT
Other expense
Increase Funding for Additional Personnel for
traffic
Street Maintenance - Department of
improvements
Transportation. Funding request to hire
requests
additional maintenance workers for asphalt
crews and street repair maintenance workers to
maintain our heavily travelled, aging streets
and infrastructure.
9/10
DOB
Assign additional
Assign Additional Building Inspectors -
building inspectors
Department of Buildings. There is a drastic need
(including
for additional inspectors to enforce Building
expanding training
Code Compliance for new construction,
programs)
renovations and occupancy of existing buildings.
10/10
BPL
Extend library hours
Increase Funding - Brooklyn Public Library
or expand and
Increased funding is necessary to maintain this
enhance library
vital community resource. Support for Brooklyn
programs
Public Library Expense Budget Requests to
PERMANENTLY maintain extended hours of
operation, Literacy Initiatives, Improved Salaries
for Library Employees, Maintenance of Library
Buildings, Public Access to Technology, and New
Collections for Brooklyn Readers.

