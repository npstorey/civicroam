- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 9 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1C8-N-llBttkg8xd8QvGK7qAbmaY5fLv_/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1C8-N-llBttkg8xd8QvGK7qAbmaY5fLv_/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
9
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 9
image
Address: 890 Nostrand Avenue Phone: (718) 778-9279
Email: bk09@cb.nyc.gov
Website: www.communitybrd9bklyn.org
Chair: Fred Baptiste District Manager: Vacant
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Brooklyn’s Community District 9 encompasses a total land area of 1.7 sq. miles, and is one of New York’s first humanly inhabited areas. The area was once the home of the Mareckkawicks (or Brooklyn Indians,) a branch of the Canarsie tribal community, which occupied Kings County and parts of Jamaica. The area was colonized by Dutch farmers from the Netherlands (Holland) in the early 17th century. Lefferts Homestead was relocated to Prospect Park from it’s original location on Midwood Street and Flatbush Avenue, and is a living reminder of this agricultural community which flourished in our district until the early 20th century. Also of historic significance is Clove Road, snugly located in the middle of Montgomery Street/Empire Blvd/Nostrand Ave/New York Avenue, within Community District 9. A Phase 1A Archaeological Documentary Study of Clove Road, conducted by the RBA Group in 2002, found that Clove Road”… is eligible for the National Register of Historic Places under Criteria A based upon it’s association with the establishment of Kings County’s 19th Century public institutions, the Alms House, Hospital, Asylum, and Penitentiary, an event that significantly contributed to the broad pattern of New York’s urban history.” Present day Community District 9 includes a portion of the neighborhoods known as Crown Heights, Flatbush, Prospect Lefferts Gardens, and Wingate. Bordered by Prospect Park (Ocean/Flatbush), Eastern Parkway, Lincoln Terrace Park (Rochester/Utica), and Clarkson Avenue, the district includes such prestigious cultural institutions as the Brooklyn Museum; the Brooklyn Botanic Garden; the Brooklyn Public Library; and the Jewish Children’s Museum. Other notable institutions in the district include Kings County Hospital Center; one of the largest hospital complexes in the world, SUNY Health Science Center at Brooklyn; Kingsboro Psychiatric Center; Kingsbrook Jewish Medical Center; the SUNY Downstate Advanced Biotechnology Incubator and the SUNY Parkside Dialysis Center.
Collectively, these institutions form the southern-most boundary of the district. Medgar Evers College of the City University of New York; four high schools; four intermediate schools; eleven elementary schools (including new small schools and charter schools) make up the District’s public educational system. A significant number of private and parochial schools complete the educational picture. Only minutes by car or public transportation from downtown Brooklyn, Community District 9 is home to numerous small and medium-sized businesses and the 98,429 residents (2010 census) who live along our tree lined residential streets. Our many religious institutions include a number of large Catholic churches, a number of the oldest Protestant churches in the borough, and the World Headquarters of the Chabad Lubavitch Jewish Movement. Families and institutions have thrived in Community District 9 for generations. Over the past five decades, this largely middle class community has undergone extensive demographic changes, creating a unique blend of people of American, Caribbean, European, Asian and Hispanic descent. More recently, the district is seeing an emergent growth of a younger demographic: young families, as well as young single adults, have come to call this community home, due in large part to its affordability, character, and close proximity to cultural institutions, parks and public transportation. Stimulated by an upturn in the economy and zoning that accommodates this type of construction, the district is seeing a feverish growth in new apartment building construction. While there is a very great need for housing in the district, the resulting availability of "affordable apartments" do not realistically address the needs of the district's population, 38% of whom are dependent on Federal income support, and more than half of residents spend more than 30% of their gross monthly income on rent. Seeing the writing on the wall, the Community Board sought for the community to have a say in addressing the impact this type of growth would have on the district, by requesting a planning study, in an effort to achieve a more balanced growth/transformation of the district, and the need for realistically "affordable" housing. This study has not moved beyond the request stage. Community Board 9 is acutely aware that this growth brings with it a concomitant escalation in the need for vital municipal services.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 9
image
The three most pressing issues facing this Community Board are:
Affordable housing
Residents of Community Board 9 are essentially without true affordable housing, with the influx of private development, longtime residents have found themselves priced out of their homes. The residents of our district need true affordable housing that directly corresponds to the average household income within the district. The constituency of our district are largely excluded from the "Affordable Housing" offerings because of this. There is rapid development in the district that is changing the character of the community and causing a surge in rents. Long term tenants are being forced out of their apartments due to rising rents. The Area Median Income guidelines for "affordable" housing is not a realistic measure for affordability. Over half of residents in CD 9 currently spend 35% or more of their income on rent. That is a serious concern in this community. More efforts are needed to preserve the existing affordable housing available to low income residents. Community Board 9 supports the need for more realistic income guidelines that would allow the working poor, the low, and moderate income groups to be able to afford adequate housing. Additionally, the Mayor's Mandatory Inclusionary Housing Program needs to demand a larger percentage of affordable units in any new construction by developers. There is also a great need for the development of senior citizen housing as that population normally does not qualify for the affordable housing offered through the lottery system because of very low fixed incomes.
Schools
The schools in the district are not meeting the needs of the children. Families with young children want to enroll their children in quality, local public schools in safe buildings. There is major overcrowding in all the schools, the buildings are in very poor condition and do not provide the type of environment that is conducive to learning. The school buildings are in critical need of wiring upgrades to bring them up to code and to enable the use of state of the art computer technology. The need for classrooms and afterschool space, gymnasium and auditorium upgrades and/or space (none exist in many of the district's schools, including high schools), library upgrades, handicap accessibility, Wi-Fi accessibility/upgrades, as well as air conditioning.
Youth and children’s services
The youth of the district are largely underserved. There are inadequate facilities for them to participate in/ or conduct extracurricular activities. There is a lack community programming to keep the youth of the community mentally and physically engaged in a positive manner. Children left unsupervised after school often fall prey to deviant behavior that is harmful to them, to their school and to the community. Afterschool programs provide a safe place for our children, academic support for help with homework, exploring new ways to learn and enhance motivation for learning and tutoring to help. For our youth, afterschool programs provide a rich array of opportunities for social contacts and enrichment activities, especially related to sports, arts and student directed projects. For families, afterschool programs provide low or no cost care for children and youth. They also provide enrichment opportunities for families who might not be able to afford them otherwise. For the community, afterschool programs provide opportunities to integrate community resources and programs with the school during non-peak hours when space and students are more accessible . They also provide safe and supervised recreation and enrichment opportunities to reduce juvenile crime and victimization of unsupervised children and youth.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 9
image
M ost Important Issue Related to Health Care and Human Services
Access to healthy food and lifestyle programs
Eating well is important for good health. A healthy diet helps prevent many chronic diseases and conditions, such as obesity, type 2 diabetes, hypertension, stroke, cancer and heart disease which are prevalent in our district.
Expansion of outreach and educational programs are essential.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
The hospitals, health centers, long-term care facilities, nursing homes in Community District 9 need the necessary resources to be able to provide much needed preventive and managed care for chronic diseases. According to the Kings County Hospital 2019 Community Health Needs Assessment, obesity, diabetes, hypertension/high blood pressure, mental illness, heart disease, high cholesterol, stroke, and cancer are the most significant community health needs. In order for our health care facilities to expand their special outreach to low-income residents, the uninsured and underinsured, and those facing other barriers, for free screening, testing, intervention, resource education, preventive and managed care, they must be provided with the proper funding.
Needs for Older NYs
The senior citizens population in Community District 9 are in dire need of subsidized senior citizens housing
Needs for Homeless
Community District 9 has the highest concentration of shelters and transitional housing in the Borough. We require more resources to handle the increased needs of this population.
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
6/22
DFTA
Renovate or
The Christopher Blenman Senior Center is in
720 East New
upgrade a senior
need of upgrade and renovation to provide a
York Avenue
center
more comfortable environment for the seniors
and staff members. Handicap accessibility lift is
in dire need of repair or replacement. Paint is
peeling off walls.
8/22
DFTA
Renovate or
Shalom Senior Center is in need of
483 Albany
upgrade a senior
approximately 2000 sq. ft. of new floor covering
Avenue
center
to replace worn out one.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/28
DOHMH
Create or promote
The creation and implementation of community
programs for
programming geared toward nutrition and
education and
preventative measures would have a significant
awareness on
impact on the population our district.
nutrition, physical
activity, etc.
5/28
DOHMH
Reduce rat
There is increased building and construction
populations
work going on in the district which has helped
to disturb the rat population. Rats can be seen
in the street and in the subways.
13/28
DOHMH
Create or promote
Obesity, Diabetes, hypertension/highblood
programs for
pressure, heart disease, high cholesterol and
education and
obesity are problems facing our population -
awareness on
expanded education and awareness programs
nutrition, physical
will assist in the fight to combat these illnesses
activity, etc.
with proper nutrition and exercise.
15/28
DFTA
Increase home
Community District 9's senior population is
delivered meals
growing but their income is fixed, which creates
capacity
an increase need for home delivered meals.
22/28 DHS Improve safety at
homeless shelters
This homeless shelter is in Community District 9 on the border with Community District 17. It is the source of numerous complaints from residents and homeowners, especially in CD 17, regarding homeless men, including sex offenders, who wander onto private property, congregate on corners, litter, urinate, and generally impact negatively on the environment. The clients at this shelter need to be provided with alternatives to this behavior, including job training, substance abuse counseling, etc., to avoid these problems being experienced by the community.
681 Clarkson Avenue
image
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 9
image
M ost Important Issue Related to Youth, Education and Child Welfare
After school programs
Community District 9 is in urgent needs of significant after-school enrichment/extracurricular activities at local schools and parks within the district; Most families in the district find it difficult to provide adequate after-school supervision for these children – an increased after-school enrichment/extracurricular activities at local schools and parks within the district would help further develop the educational progress of these children, as well as keep them in safe environments
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
School buildings in Community District 9 are in dire need of much resources and upgrading in the following areas: PS 92 - Upgrades to plumbing, library and auditorium; additional exterior lighting due to safety concerns; whiteboards; projectors for visual arts. PS 241 - Air conditioning in classrooms and auditorium; portable STEM labs; Technology and Wi-Fi updage (Wi-Fi blocking issue); Electrical upgrade; handicap accessible auditorium; sound system in auditorium; expanded PreK (up to 6PM). PS 161 - New gymnasium; auditorium upgrade; electrical and heating upgrade; air conditioning; STEM labs; iPad carts; additional bathroom stalls; after school programs. PS 221 - Air conditioning in classrooms; auditorium upgrade; music and arts after school programs. MS 2 Parkside Prep Academy - Upgraded computer labs; Wi-Fi upgrade; culinary arts lab (only 4 stoves and refrigerator don't work so program is on hold); library upgrade; auditorium upgrade (sound system and lights specifically); cafeteria tables; space for afterschool; blind spots issues on cameras they already have. Medgar Evers Preparatory School - Need auditorium and gymnasium; additional classroom space (offices are bring used as classrooms); Arts program; 3 Technology labs; Smart classrooms; Laptop carts; Saturday school.MS 61 - Renovation of library (including tables, chairs and book shelves). Updated Smartboards, as well as new paint and flooring throughout the
building. Upgraded auditorium (particularly air conditioning and new chairs); additional air conditioners for classroom; water coolers to replace outdated water fountains. The school also needs pest control due to rats running rampant through the auditorium and outside the school rummaging in the garbage bags placed outside for garbage pick up.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
3/22
SCA
Provide a new or
Public School 161 is a school without a
330 Crown
expand an existing
gymnasium and has an auditorium that is in
Street
elementary school
need of renovation. The school needs additional
bathroom stalls to meet the needs of the large
student body. The entire school needs rewiring
to not only be up to code, but to also enable the
use of state of the art computer technology; as
well as heating and air conditioning.
4/22
SCA
Renovate or
MS 61 is in dire need of renovation. Renovation
400 Empire
upgrade a middle or
of library (including tables, chairs and book
Boulevard
intermediate school
shelves). Updated Smartboards, as well as new
paint and flooring throughout the building. The
auditorium needs air conditioning and new
seats. Electrical wiring upgrade is needed
throughout the school. The water fountains
need replacement/upgrading.
5/22
SCA
Renovate or
Medgar Evers Prep School is in dire need of a
1186 Carroll
upgrade a high
gymnasium and an auditorium. This is a high
Street
school
school, and Physical Education is a requirement
for graduation. The students are being denied
the opportunity to participate in a proper
physical education class. To fulfill these
requirements, the students often do jumping
jacks in the hallways and the basement; that is
not acceptable.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
1/28
DYCD
Provide, expand, or
P. S. 161 in CD 9 is in need of after school
330 Crown
enhance after
program such as Beacon.
Street
school programs for
elementary school
students (grades K-
5)
4/28 DYCD Provide, expand, or
enhance Cornerstone and Beacon programs (all ages, including young adults)
PS 221 - Toussaint L-Ouverture is in need of an after school program such as Beacon Program.
image
6/28 DOE Assign more teaching staff
An adequate number of teaching staff is a must! Not only to provide instruction, but consideration must be given to teachers who are often times overwhelmed by the huge number of students in their class. In addition, smaller classrooms mean that children will be provided with an atmosphere that is conducive to learning with teachers who are able to focus on them and can more efficiently manage their classrooms.
image
7/28 DOE Assign more non-
teaching staff, e.g., to provide social, health and other services
Providing all the resources for a well-balanced education is important. The need is not only there for academic instruction, but the support services of health (a nurse on the premises), guidance counselors, mediation counselors, etc., are also paramount.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 9
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
Traffic violations are occurring every day throughout CD 9 and putting our children and seniors at risk too often. The NYPD needs to do more about enforcement as we have too much double parking, violations of the speed limit, and drivers running red lights. With more frequent enforcement against speeding and reckless driving, NYPD can send a clear message that pedestrian safety is a priority.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Community Board 9 still feels that more funding is needed for crime prevention programs, because of the increase in gun violence and crime activity overall. If we have more crime prevention programs that educate the community, especially our youth, work with our local precinct, elected officials, the district attorney office, than maybe we can prevent the tragedies and violence that happens in our community every year.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/22
NYPD
Renovate or
The 71st Precinct is in need of full renovation
421 Empire
upgrade existing
and upgrading. New windows; increase service
Boulevard
precinct houses
of amps in circuit breaker boxes; locker rooms
floors to be redone and benches added; new
lockers needed;staff kitchen renovation; break
room chairs; new bunk beds for Officers; replace
all ceiling tiles; snake all drains in command;
upgrade plumbing, heating, electrical and
computer related wiring.
9/22
NYPD
Add NYPD parking
Without question, the acquisition of space for
421 Empire
facilities
garaging police vehicles is a critical need in the
Boulevard
district. Currently, because of the lack of parking
facilities, vehicles are parked on city streets,
illegally parked on sidewalks outside the
precinct making it unsafe for pedestrians. The
agency must acquire the necessary space to
remedy this situation
11/22
NYPD
Provide surveillance
Additional surveillance cameras in Community
cameras
District 9 will help to deter criminal activities,
thus lower crime in the community.
17/22
FDNY
Other FDNY facilities
Provide additional vehicles in order for
and equipment
Community Affairs to expand outreach efforts.
requests (Capital)
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
12/28
NYPD
Provide resources to
Community Board 9 would like to see the
train officers, e.g. in
expansion of Community Policing with the
community policing
necessary training provided to police officers as
they seek to carry out their duties.
16/28
NYPD
Other NYPD
Additional funding is needed for the Auxiliary
programs requests
Program in order to successfully run this
program: CB 9 advocates for funds for purchase
of new bicyles; the purchase of new bullet
resistant vests; purchase of additional vehicles;
expandable batons for auxiliaries; and for
purchase of Recruitment Materials and Banners.
17/28
FDNY
Provide more
Increase the number of Fire Marshalls in order
firefighters or EMS
to decrease the amount of time it takes to
workers
complete fire investigations. Increase FDNY
uniformed personnel and Community Affairs
staffing workforce to adequately service each
community throughout the City of New York.
18/28
FDNY
Expand funding for
The district has seen multiple fires which has
fire prevention and
not only destroyed property but lives over the
life safety initiatives
past several years. Fire Safety and fire
prevention education and outreach is critically
important in making people aware how they
can prevent fires and protect their families and
property. Increase funding for the Get Alarmed
NYC program to expand the program.
21/28
NYPD
Provide additional
The 71st Precinct Community Council is in need
421 Empire
patrol cars and
of a passenger van to transport senior citizens
Boulevard
other vehicles
to the precinct's council meetings.
24/28
FDNY
Other FDNY facilities
There should be regular inspections of fire
and equipment
hydrants throughout the City to ensure that
requests (Expense)
water pressure adequately meets FDNY's needs
during fires.
25/28
NYPD
Assign additional
Crossing guards are an esssential part of our
crossing guards
community, in light of all the recent pedestrian
incidents involving vehicles, they are vital in
helping ensure the safety of our constituents,
especially, our youth and senior citizens.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 9
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
It's essential that DSNY increase litter basket pick ups on all the main avenues in Community District 9. There are museums, tourists attractions, parades, marathons, and religious pilgrimages in Crown Heights, which draws hundreds of thousands of visitors yearly. A recent review by CB9's Environmental Protection Committee of Kingston Avenue, from Union to Montgomery Streets, documented large amounts of trash in the streets caused by container overflow. The same situation exists along Nostrand Avenue, from Eastern Parkway to Clarkson Avenue, and on Flatbush Avenue, from Empire Boulevard to Parkside Avenue. Additional personnel, trucks and litter baskets are needed; in addition to more frequent pick ups.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
The population in Community District 9 is increasing due to the conversions of one and two-family homes into multiple unit apartment dwellings. The sewer system is therefore being overburdened due to increased waste and water volumes.
Needs for Sanitation Services
Sanitation enforcement needs to be more proactive in the issuance of violations when motorists do not adhere to the Alternate Side Parking rules and prevent the mechanical brooms from properly cleaning the streets. Mechanical brooms should also be properly filled with water to prevent leaves and dirt from blowing back onto sidewalks.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/22
DSNY
Provide new or
There are major problems with Community
356 Winthrop
upgrade existing
District 9's existing sanitation garage. Not only
Street
sanitation garages
is it in an unsuitable location at 356 Winthrop
or other sanitation
Street (close proximity to Kings County Hospital,
infrastructure
SUNY Downstate Medical Center; SUNY Dialysis
Center; SUNY Biotech Facility) but it is also too
small. The results being the parking of garbage
filled sanitation trucks on the district's streets in
close proximity to residences, as well as
imposing unsafe conditions for pedestrians. This
district has endured these problems for many
years. We would like to see the allocation of
funding to renovate and expand this facility to
provide a much needed state of art facility to
address the district's needs and eliminate the
existing conditions which impact negatively on
the community.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/28
DEP
Clean catch basins
The intermittent cleaning of catch basins would
be vital in the prevention of flooding at
crosswalks during incidents of precipitation.
8/28
DSNY
Provide more
Additional basket trucks are needed to address
frequent litter
the constant overflow of litter baskets in the
basket collection
district
9/28
DSNY
Provide more on-
Numerous schools and busy commercial strips in
street trash cans
the district see more pedestrian traffic. Adding
and recycling
more on-street trash cans and recycling
containers
containers will help to improve littering and also
to reduce overflowing on-street trash cans.
10/28
DSNY
Increase
Provide additional Sanitation enforcement
enforcement of
personnel to increase the issuance of violations
alternate street
when motorists do not adhere to the Alternate
parking cleaning
Side Parking rules and prevent the mechanical
rules
brooms from properly cleaning the streets.
11/28 DSNY Other enforcement
requests
Community Board 9 would like to see the enforcement of all of the DSNY Codes.
Enforcement in the areas of ASP regulations; illegal dumping, dirty sidewalks, failure to recycle, failing to pick up after your dog, illegal posting. All of these violations impact negatively upon the cleanliness of the district. We would like the agency to provide the funding necessary to provide more effective enforcement of the sanitation codes.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 9
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Many residential blocks in Community District 9 lack proper zoning. As a result, the current zoning allows for one and two-family homes to be demolished and replaced with large market rate apartment dwellings that are not only changing the character of many of these affected residential blocks, but is leading to rapid development and tenant displacement.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
The residents of Community Board 9 live in a mix of housing of private homes and apartment buildings. The development in the district has taken place at breakneck speed, yet the pressures for affordable housing are persist. This district is disproportionately rent burdened. Future development within should take this into account, as previous use of the MIH program has been thoroughly abused.
Needs for Housing
There is a great need for the preservation of the existing rent stabilized units within Community District 9 and the creation of affordable housing for low and moderate-income families and the senior population.
Needs for Economic Development
Community Board 9 has four major commercial strips: Utica Avenue, Kingston Avenue, Nostrand Avenue and Flatbush Avenue. The revitalization of these strips to transform them into more attractive places for customers and attract viable businesses will help create jobs and economic growth.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
7/22
HPD
Provide more
There is a critical need for housing for low and
681 Clarkson
housing for
moderate income individuals and families. In
Avenue
extremely low and
addition, there is also a critical need for senior
low income
citizen housing. There is presently city owned
households
property on the grounds of Kingsboro
Psychiatrict Center that can be used for the
provision of new homes for this segment of our
population. The site is currently unused and
begging for development. Community Board 9
would much prefer that this property be used to
address the desperate need for housing that is
truly affordable to our constituents.
12/22
HPD
Provide more
There is a critical need for senior citizens
housing for special
housing as this populations is generally
needs households,
excluded from the affordable housing lotteries
such as the formerly
being offered due to very low fixed income.
homeless
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
14/28
DCP
Study land use and
Zoning is supposed to organize the way land is
zoning to better
used, determine the sizes and building uses;
match current use
however, the current zoning in Community
or future
District 9 encompases a mixture of different
neighborhood
zoning, which we have seen create numerous
needs
concerns for residents and home-owners in the
district. Community Board 9 would greatly
appreciate the opportunity to have a study of
our district to better utilize land in our district to
address the need for housing (to include height
and setback controls), open space, commercial
revitalization, upgraded/new schools, job
creation, transportation access, improved utility
services and infrastructure to support an
expected population growth
23/28
EDC
Improve public
The agency has a responsibility to repair and
718 East New
housing
renovate the thousands of apartments that are
York Avenue
maintenance and
in absolutely disgusting and deplorable
cleanliness
conditions under which families with children
and senior citizens currently live. This is
unacceptable. Adequate funding must be
provided to address and correct theses
deplorable conditions.
26/28
HPD
Other affordable
There is a need for truly affordable housing in
housing programs
the overall area of community board 9. The
requests (expense)
area has experience rapid gentrification and as
a result many long time residents have been
displaced. Beyond the minimal MIH set asides
and insufficient affordability calculations, we
require affordability for a variety of income
brackets and household sizes. Generally, a
household should not be spending more than
25-30% of their income on housing, we need
affordability that meets that standard for all
income brackets.
TRANSPORTATION
Brooklyn Community Board 9
image
M ost Important Issue Related to Transportation and Mobility
Traffic enforcement
Enforcement should be increased along our busy thoroughfares, in order to minimize traffic congestion and also to deter double parking.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
13/22
DOT
Improve traffic and
The streets of the city continue to be dangerous
pedestrian safety,
for pedestrians and motorists alike. Community
including traffic
Board 9 feels that the installation of traffic
calming (Capital)
enforcement cameras will help to reduce the
incidences of drivers running red lights, not
stopping for a stopped school bus, not giving
pedestrians the right of way in crosswalks, and
numerous other violations.
16/22
NYCTA
Repair or upgrade
The subway stations in Community District 9 are
subway stations or
in need of repair and upgrade to correct leaks,
other transit
and make stairs and platforms safe, as well as
infrastructure
improve lighting, replace missing wall tiles, etc.
19/22
DOT
Improve traffic and
As pedestrians, cyclists and motorists jostle for
pedestrian safety,
use of our neighborhood streets, the streets
including traffic
have become more unsafe. Additional traffic
calming (Capital)
safety measures can be taken to allow for the
safe use of the street by all. Community Board 9
has requested that the Department of
Transportation do a traffic calming study of the
district but, to date, DOT has not agreed to
begin one.
20/22
DOT
Roadway
Many streets in Community District 9 are in
maintenance (i.e.
need of resurfacing resulting from damage
pothole repair,
caused by winter salting and general wear and
resurfacing, trench
tear. Community District 9 would like to see an
restoration, etc.)
increase in the district's asphalt allocation and
the number of streets that are resurfaced.
21/22
DOT
Other capital traffic
Although the speed limit has been reduced to 25
improvements
mph, motorists are still speeding throughout the
requests
district. Additional traffic enforcement cameras
are necessary to alleviate this problem.
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
20/28 NYCTA Improve subway
station or train cleanliness, safety and maintenance
Increasing the frequency of cleaning the subway tracks and stations should help with the current littering problem on the tracks and stations, as well as the infestation of rodents.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 9
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Forestry services, including street tree maintenance
Tree pruning and tree/branch maintenance is a major issue in Community Board 9. Homeowners have to contend with trees that go largerly unaddressed and maintained. The conditions created as a result of these conditions are broken sidewalks and obstruction of the line of vision and mobility due to low hanging branches. Homeowners incur significant expenses in attempt to protect themselves from the liability of a trip and fall claims. Trees in the district needs to be regularly assessed for viability and safety.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
The BrooklynPublic Library facilities serving the district continue to need additional funding to meet the demand for its services. I
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
10/22
DPR
Provide a new, or
Community District 9 has long been advocating
new expansion to, a
for a community center to provide badly needed
building in a park
recreational space for the youth in the
community.
14/22
BPL
Provide more or
The Crown Heights Library is in need of the
560 New York
better equipment to
following: Boiler; HVAC & Controls; Roof; Safety
Avenue
a library
& Security Enhancement.
15/22
DPR
Provide a new or
Acquire property at Brooklyn Avenue to expand
Brooklyn
expanded park or
Wingate Park
Avenue &
amenity (i.e.
Rutland Road
playground, outdoor
athletic field)
18/22
DPR
Improve access to a
Mount Prospect Park is in need of handicap
Eastern
park or amenity (i.e.
accessibility to provide amenities and open
Parkway
playground, outdoor
access to the park by all residents of the
athletic field)
community. The steps leading to the park from
Eastern Parkway renders the park inaccessible
to some residents.
22/22
BPL
Create a new, or
Replacement of flooring and tiling. Painting of
renovate or upgrade
common areas. Reconfiguration of lay-out to
an existing public
btter serve the public.
library
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
19/28
OMB
Provide more
Increase funding to Community Boards to hire
community board
additional staff; particularly, a city planner to
staff
address the district's zoning, land use and
overall planning needs. This is something that
would be beneficial to all community boards.
27/28
DPR
Other street trees
The Parks department should increase funding
and forestry
to the Forestry Division, so that regular
services requests
maintenance may be performed on the trees
within our district.
28/28 BPL Extend library hours
or expand and enhance library programs
The Crown Heights Library would better serve the community be having extended hours to conduct community programming.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/22
NYPD
Renovate or
The 71st Precinct is in need of full renovation
421 Empire
upgrade existing
and upgrading. New windows; increase service
Boulevard
precinct houses
of amps in circuit breaker boxes; locker rooms
floors to be redone and benches added; new
lockers needed;staff kitchen renovation; break
room chairs; new bunk beds for Officers; replace
all ceiling tiles; snake all drains in command;
upgrade plumbing, heating, electrical and
computer related wiring.
2/22
DSNY
Provide new or
There are major problems with Community
356 Winthrop
upgrade existing
District 9's existing sanitation garage. Not only
Street
sanitation garages
is it in an unsuitable location at 356 Winthrop
or other sanitation
Street (close proximity to Kings County Hospital,
infrastructure
SUNY Downstate Medical Center; SUNY Dialysis
Center; SUNY Biotech Facility) but it is also too
small. The results being the parking of garbage
filled sanitation trucks on the district's streets in
close proximity to residences, as well as
imposing unsafe conditions for pedestrians. This
district has endured these problems for many
years. We would like to see the allocation of
funding to renovate and expand this facility to
provide a much needed state of art facility to
address the district's needs and eliminate the
existing conditions which impact negatively on
the community.
3/22
SCA
Provide a new or
Public School 161 is a school without a
330 Crown
expand an existing
gymnasium and has an auditorium that is in
Street
elementary school
need of renovation. The school needs additional
bathroom stalls to meet the needs of the large
student body. The entire school needs rewiring
to not only be up to code, but to also enable the
use of state of the art computer technology; as
well as heating and air conditioning.
4/22
SCA
Renovate or
MS 61 is in dire need of renovation. Renovation
400 Empire
upgrade a middle or
of library (including tables, chairs and book
Boulevard
intermediate school
shelves). Updated Smartboards, as well as new
paint and flooring throughout the building. The
auditorium needs air conditioning and new
seats. Electrical wiring upgrade is needed
throughout the school. The water fountains
need replacement/upgrading.
5/22
SCA
Renovate or
Medgar Evers Prep School is in dire need of a
1186 Carroll
upgrade a high
gymnasium and an auditorium. This is a high
Street
school
school, and Physical Education is a requirement
for graduation. The students are being denied
the opportunity to participate in a proper
physical education class. To fulfill these
requirements, the students often do jumping
jacks in the hallways and the basement; that is
not acceptable.
6/22
DFTA
Renovate or
The Christopher Blenman Senior Center is in
720 East New
upgrade a senior
need of upgrade and renovation to provide a
York Avenue
center
more comfortable environment for the seniors
and staff members. Handicap accessibility lift is
in dire need of repair or replacement. Paint is
peeling off walls.
7/22
HPD
Provide more
There is a critical need for housing for low and
681 Clarkson
housing for
moderate income individuals and families. In
Avenue
extremely low and
addition, there is also a critical need for senior
low income
citizen housing. There is presently city owned
households
property on the grounds of Kingsboro
Psychiatrict Center that can be used for the
provision of new homes for this segment of our
population. The site is currently unused and
begging for development. Community Board 9
would much prefer that this property be used to
address the desperate need for housing that is
truly affordable to our constituents.
8/22
DFTA
Renovate or
Shalom Senior Center is in need of
483 Albany
upgrade a senior
approximately 2000 sq. ft. of new floor covering
Avenue
center
to replace worn out one.
9/22
NYPD
Add NYPD parking
Without question, the acquisition of space for
421 Empire
facilities
garaging police vehicles is a critical need in the
Boulevard
district. Currently, because of the lack of parking
facilities, vehicles are parked on city streets,
illegally parked on sidewalks outside the
precinct making it unsafe for pedestrians. The
agency must acquire the necessary space to
remedy this situation
10/22
DPR
Provide a new, or
Community District 9 has long been advocating
new expansion to, a
for a community center to provide badly needed
building in a park
recreational space for the youth in the
community.
11/22
NYPD
Provide surveillance
Additional surveillance cameras in Community
cameras
District 9 will help to deter criminal activities,
thus lower crime in the community.
12/22
HPD
Provide more
There is a critical need for senior citizens
housing for special
housing as this populations is generally
needs households,
excluded from the affordable housing lotteries
such as the formerly
being offered due to very low fixed income.
homeless
13/22
DOT
Improve traffic and
The streets of the city continue to be dangerous
pedestrian safety,
for pedestrians and motorists alike. Community
including traffic
Board 9 feels that the installation of traffic
calming (Capital)
enforcement cameras will help to reduce the
incidences of drivers running red lights, not
stopping for a stopped school bus, not giving
pedestrians the right of way in crosswalks, and
numerous other violations.
14/22
BPL
Provide more or
The Crown Heights Library is in need of the
560 New York
better equipment to
following: Boiler; HVAC & Controls; Roof; Safety
Avenue
a library
& Security Enhancement.
15/22
DPR
Provide a new or
Acquire property at Brooklyn Avenue to expand
Brooklyn
expanded park or
Wingate Park
Avenue &
amenity (i.e.
Rutland Road
playground, outdoor
athletic field)
16/22
NYCTA
Repair or upgrade
The subway stations in Community District 9 are
subway stations or
in need of repair and upgrade to correct leaks,
other transit
and make stairs and platforms safe, as well as
infrastructure
improve lighting, replace missing wall tiles, etc.
17/22
FDNY
Other FDNY facilities
Provide additional vehicles in order for
and equipment
Community Affairs to expand outreach efforts.
requests (Capital)
18/22
DPR
Improve access to a
Mount Prospect Park is in need of handicap
Eastern
park or amenity (i.e.
accessibility to provide amenities and open
Parkway
playground, outdoor
access to the park by all residents of the
athletic field)
community. The steps leading to the park from
Eastern Parkway renders the park inaccessible
to some residents.
19/22
DOT
Improve traffic and
As pedestrians, cyclists and motorists jostle for
pedestrian safety,
use of our neighborhood streets, the streets
including traffic
have become more unsafe. Additional traffic
calming (Capital)
safety measures can be taken to allow for the
safe use of the street by all. Community Board 9
has requested that the Department of
Transportation do a traffic calming study of the
district but, to date, DOT has not agreed to
begin one.
20/22 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Many streets in Community District 9 are in need of resurfacing resulting from damage caused by winter salting and general wear and tear. Community District 9 would like to see an increase in the district's asphalt allocation and the number of streets that are resurfaced.
image
21/22 DOT Other capital traffic
improvements requests
Although the speed limit has been reduced to 25 mph, motorists are still speeding throughout the district. Additional traffic enforcement cameras are necessary to alleviate this problem.
image
22/22 BPL Create a new, or
renovate or upgrade an existing public library
Replacement of flooring and tiling. Painting of common areas. Reconfiguration of lay-out to btter serve the public.
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/28
DYCD
Provide, expand, or
P. S. 161 in CD 9 is in need of after school
330 Crown
enhance after
program such as Beacon.
Street
school programs for
elementary school
students (grades K-
5)
2/28
DEP
Clean catch basins
The intermittent cleaning of catch basins would
be vital in the prevention of flooding at
crosswalks during incidents of precipitation.
3/28
DOHMH
Create or promote
The creation and implementation of community
programs for
programming geared toward nutrition and
education and
preventative measures would have a significant
awareness on
impact on the population our district.
nutrition, physical
activity, etc.
4/28
DYCD
Provide, expand, or
PS 221 - Toussaint L-Ouverture is in need of an
enhance
after school program such as Beacon Program.
Cornerstone and
Beacon programs
(all ages, including
young adults)
5/28
DOHMH
Reduce rat
There is increased building and construction
populations
work going on in the district which has helped
to disturb the rat population. Rats can be seen
in the street and in the subways.
6/28
DOE
Assign more
An adequate number of teaching staff is a must!
teaching staff
Not only to provide instruction, but
consideration must be given to teachers who
are often times overwhelmed by the huge
number of students in their class. In addition,
smaller classrooms mean that children will be
provided with an atmosphere that is conducive
to learning with teachers who are able to focus
on them and can more efficiently manage their
classrooms.
7/28
DOE
Assign more non-
Providing all the resources for a well-balanced
teaching staff, e.g.,
education is important. The need is not only
to provide social,
there for academic instruction, but the support
health and other
services of health (a nurse on the premises),
services
guidance counselors, mediation counselors, etc.,
are also paramount.
8/28
DSNY
Provide more frequent litter basket collection
Additional basket trucks are needed to address the constant overflow of litter baskets in the district
9/28
DSNY
Provide more on-
Numerous schools and busy commercial strips in
street trash cans
the district see more pedestrian traffic. Adding
and recycling
more on-street trash cans and recycling
containers
containers will help to improve littering and also
to reduce overflowing on-street trash cans.
10/28
DSNY
Increase
Provide additional Sanitation enforcement
enforcement of
personnel to increase the issuance of violations
alternate street
when motorists do not adhere to the Alternate
parking cleaning
Side Parking rules and prevent the mechanical
rules
brooms from properly cleaning the streets.
11/28
DSNY
Other enforcement
Community Board 9 would like to see the
requests
enforcement of all of the DSNY Codes.
Enforcement in the areas of ASP regulations;
illegal dumping, dirty sidewalks, failure to
recycle, failing to pick up after your dog, illegal
posting. All of these violations impact negatively
upon the cleanliness of the district. We would
like the agency to provide the funding necessary
to provide more effective enforcement of the
sanitation codes.
12/28
NYPD
Provide resources to
Community Board 9 would like to see the
train officers, e.g. in
expansion of Community Policing with the
community policing
necessary training provided to police officers as
they seek to carry out their duties.
13/28
DOHMH
Create or promote
Obesity, Diabetes, hypertension/highblood
programs for
pressure, heart disease, high cholesterol and
education and
obesity are problems facing our population -
awareness on
expanded education and awareness programs
nutrition, physical
will assist in the fight to combat these illnesses
activity, etc.
with proper nutrition and exercise.
14/28
DCP
Study land use and
Zoning is supposed to organize the way land is
zoning to better
used, determine the sizes and building uses;
match current use
however, the current zoning in Community
or future
District 9 encompases a mixture of different
neighborhood
zoning, which we have seen create numerous
needs
concerns for residents and home-owners in the
district. Community Board 9 would greatly
appreciate the opportunity to have a study of
our district to better utilize land in our district to
address the need for housing (to include height
and setback controls), open space, commercial
revitalization, upgraded/new schools, job
creation, transportation access, improved utility
services and infrastructure to support an
expected population growth
15/28
DFTA
Increase home
Community District 9's senior population is
delivered meals
growing but their income is fixed, which creates
capacity
an increase need for home delivered meals.
16/28
NYPD
Other NYPD
Additional funding is needed for the Auxiliary
programs requests
Program in order to successfully run this
program: CB 9 advocates for funds for purchase
of new bicyles; the purchase of new bullet
resistant vests; purchase of additional vehicles;
expandable batons for auxiliaries; and for
purchase of Recruitment Materials and Banners.
17/28
FDNY
Provide more
Increase the number of Fire Marshalls in order
firefighters or EMS
to decrease the amount of time it takes to
workers
complete fire investigations. Increase FDNY
uniformed personnel and Community Affairs
staffing workforce to adequately service each
community throughout the City of New York.
18/28
FDNY
Expand funding for
The district has seen multiple fires which has
fire prevention and
not only destroyed property but lives over the
life safety initiatives
past several years. Fire Safety and fire
prevention education and outreach is critically
important in making people aware how they
can prevent fires and protect their families and
property. Increase funding for the Get Alarmed
NYC program to expand the program.
19/28
OMB
Provide more
Increase funding to Community Boards to hire
community board
additional staff; particularly, a city planner to
staff
address the district's zoning, land use and
overall planning needs. This is something that
would be beneficial to all community boards.
20/28
NYCTA
Improve subway station or train cleanliness, safety and maintenance
Increasing the frequency of cleaning the subway tracks and stations should help with the current littering problem on the tracks and stations, as well as the infestation of rodents.
21/28
NYPD
Provide additional
The 71st Precinct Community Council is in need
421 Empire
patrol cars and
of a passenger van to transport senior citizens
Boulevard
other vehicles
to the precinct's council meetings.
22/28
DHS
Improve safety at
This homeless shelter is in Community District 9
681 Clarkson
homeless shelters
on the border with Community District 17. It is
Avenue
the source of numerous complaints from
residents and homeowners, especially in CD 17,
regarding homeless men, including sex
offenders, who wander onto private property,
congregate on corners, litter, urinate, and
generally impact negatively on the
environment. The clients at this shelter need to
be provided with alternatives to this behavior,
including job training, substance abuse
counseling, etc., to avoid these problems being
experienced by the community.
23/28
EDC
Improve public
The agency has a responsibility to repair and
718 East New
housing
renovate the thousands of apartments that are
York Avenue
maintenance and
in absolutely disgusting and deplorable
cleanliness
conditions under which families with children
and senior citizens currently live. This is
unacceptable. Adequate funding must be
provided to address and correct theses
deplorable conditions.
24/28
FDNY
Other FDNY facilities
There should be regular inspections of fire
and equipment
hydrants throughout the City to ensure that
requests (Expense)
water pressure adequately meets FDNY's needs
during fires.
25/28
NYPD
Assign additional
Crossing guards are an esssential part of our
crossing guards
community, in light of all the recent pedestrian
incidents involving vehicles, they are vital in
helping ensure the safety of our constituents,
especially, our youth and senior citizens.
26/28 HPD Other affordable
housing programs requests (expense)
There is a need for truly affordable housing in the overall area of community board 9. The area has experience rapid gentrification and as a result many long time residents have been displaced. Beyond the minimal MIH set asides and insufficient affordability calculations, we require affordability for a variety of income brackets and household sizes. Generally, a household should not be spending more than 25-30% of their income on housing, we need affordability that meets that standard for all income brackets.
image
27/28 DPR Other street trees
and forestry services requests
The Parks department should increase funding to the Forestry Division, so that regular maintenance may be performed on the trees within our district.
image
28/28 BPL Extend library hours
or expand and enhance library programs
The Crown Heights Library would better serve the community be having extended hours to conduct community programming.
image

