- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 2 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/18C0iy7KnLl_VLFALftoLgxsCRGqYRxNp/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/18C0iy7KnLl_VLFALftoLgxsCRGqYRxNp/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•',
�
Manhattan Community District
2
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 2
image
Address: 3 Washington Square Village, 1A Phone: (212) 979-2272
Email: bgormley@cb.nyc.gov
Website: www.nyc.gov/manhattancb2
Chair: Carter Booth District Manager: Bob Gormley
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 2 Manhattan (“CB2”) continues to be greatly concerned that the City has minimized the impact of the district’s rapid changes and has neglected to adequately respond to the need to increase the ancillary services that such changes require. During these years of exponential residential growth in NoHo, SoHo, Chinatown and our Hudson River waterfront, planners have not provided for the necessary amenities that make for a healthy and growing residential community, e.g., public schools, open space and parks, access to health care, adequate public transit opportunities and public transit access, affordable retail space, and general services such as sanitation, police and fire. Each year, CB2 receives many applications for residential conversions and re-zonings. The complaints and requests that come to CB2 reflect the concerns of this new residential population. Our budget priorities for the past few years have continued to focus on servicing these new arrivals to the district, as well as our long-time residents. More specific assessments of services will be set forth throughout this Statement. I. DISTRICT OVERVIEW A. Geography Community Board 2 is a diverse district, bounded on the north by 14th Street, the south by Canal Street, the east by the Bowery/Fourth Avenue, and the west by the Hudson River. It is a unique and rapidly expanding community that includes the vibrant neighborhoods of Little Italy, part of Chinatown, SoHo, NoHo, Greenwich Village, the West Village, Gansevoort Market, the South Village and Hudson Square. B. Population Although the population in Community Board 2 has decreased slightly since the 2000 census, the recent rezoning of Hudson Square and the construction of a new residential complex on the site of the St. John’s Terminal will increase our population by several thousand residents in the coming years. In addition, we have five major universities - New York University, the New School, the Cooper Union, Hebrew Union College, and Cardozo Law School - that add a substantial non-permanent population to our neighborhoods. Several of these institutions are currently in the midst of expansion, with proposals to add many thousand more undergraduate residents to our district, along with additional full time faculty and classrooms that will increase the number of day visitors. While the students that join us every year are welcome, it is clear that the city needs to consider their numbers when looking to allocate services to District 2. C. Income structure Much of the architecture and history of our district has been maintained by residents who are determined to preserve the middle class, live-work, merchant and artisan atmosphere of our neighborhoods, past and future, but socioeconomic patterns are changing drastically. Median income for Districts 1 and 2 combined for the period 2007-2009 was $104,305. D. Housing In recent years, the median monthly rent in District 2 ascended to the highest in the City to $1,691. Rental units that are rent-regulated are 54.6%, and more than 1,300 buildings are registered with rent-stabilized units. District 2’s rank in severe overcrowding rate in rental unit conditions has been elevated from twenty-eight in the City to nineteen. We think that we are losing affordable housing stock, and fear that this will depress our middle class population, that is essential to a healthy, diverse community. E. Tourism/Visitors Within the boundaries of Community District 2 are some of the most popular tourist attractions in New York City, with millions of tourists visiting the restaurants and cafes of Little Italy and Chinatown, the galleries and boutiques of SoHo, the jazz clubs and Off-Broadway theaters of Greenwich Village, as well as burgeoning nightlife, night club and cabaret spots of the entire area. A weekend evening stroll through the Meatpacking and waterfront districts in the west, along West 4th Street and Bleecker St. toward the east, through SoHo and Chinatown in the south and on the western edge of the Bowery from Houston to 14th St reveals the nightlife that is attracting record numbers of tourists. A walk through our landmark districts is an historic delight with many well-preserved buildings dating back to the early part of the nineteenth century. We see many groups conducting walking tours in our neighborhoods, telling stories about our immigrant, arts, and bohemian history.
Tour buses travel through our small streets, obstructing pedestrian and bicycle passage as well as emergency access and deliveries, damaging our vulnerable infrastructure, idling and spewing dangerous emissions. Our street trash baskets are often overflowing, especially on the weekends, and it is up to our citizens and merchant associations to supplement the Department of Sanitation pick-ups. We require more police presence to manage the crowds. The parks in our district require more maintenance because they are not just the outdoor space for our residents, but also appeal to visitors who are looking for a pleasant stop on their way through our district. The High Line Park alone has attracted millions of visitors since its opening. Tourists are extremely welcome in our neighborhoods. They provide a significant clientele for our small businesses and cultural institutions. However, the influx of thousands of people on a daily basis puts a severe strain on our infrastructure and resources, and these additional needs are not adequately addressed in the budget allocations.
CONCLUSION/SUMMARY Community Board 2 is a community of families and preservationists: our block and community associations plant and care for trees; friends' groups care for our parks; merchants' associations help local park and City groups; civic organizations clean their streets, and residents get involved and help. We also have BIDs, that are committed to supporting our businesses, and provide security, extra sanitation services and street beautification projects to ensure that their areas remain attractive destinations. The fact that the historic beauty and integrity of our many neighborhoods has survived is clearly due to these efforts. It is time that the City makes the same commitment to our district, as have our residents and businesses. Increasingly, City agencies are asking for input from the community board regarding the issuance of licenses, changes to regulations and feedback for large development projects. However, we notice that building owners, restaurateurs and cafe entrepreneurs have found it too easy to build in complete disregard of local laws. New businesses are opened and profits are reaped while complaints sit on agency desks. Illegal and unlicensed operations continue without inspections and penalties, and residents continue to complain to the Board office. More careful attention must be paid to the zoning regulations regarding building plan examiners and sidewalk cafe application certifiers. Illegal construction continues in Community District 2. And too often, we are asked to retroactively approve illegal renovations in our historic districts. We need City agencies to establish procedures that will help us to protect our neighborhoods in line with existing laws, and then follow up with inspections to ensure that violations are cured in a timely manner.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 2
image
The three most pressing issues facing this Community Board are:
Parks
(1) Preserve Elizabeth Street Garden and Build More Affordable Housing at Alternative Site. Since 2013, CB 2 has held four public hearings and passed four resolutions in support of the permanent preservation of Elizabeth Street Garden in its entirety as public open, green space and urges the City to transfer jurisdiction over this lot to the Parks Department. CB 2 also supports the development of affordable housing at an alternative city-owned site at Hudson and Clarkson Streets, but only if the Elizabeth Street Garden is preserved. Neighborhood Underserved by Open Space. The neighborhood around Elizabeth Street Garden lacks open space. Little Italy and SoHo account for 23% of CB 2's population but have only 3% of its open space, virtually 100% paved, for an open space ratio of only 0.07 acres per 1,000 residents, as compared with the City planning goal of 2.5 acres per 1,000 residents. Furthermore, the majority of CB 2's open space is in Washington Square and Hudson River Parks, nearly a mile and 1.2 miles from the Garden, respectively. Residents in Little Italy and SoHo are less likely to use these spaces with frequency. Furthermore, Elizabeth Street Garden is located in the only downtown Manhattan neighborhood that the NYC Parks Department defines as “underserved” by open space. About the Garden. Elizabeth Street Garden is a unique community park and green space with open lawn, majestic trees, flowering garden beds, and sculptural artworks located in the Little Italy neighborhood of Manhattan, between Prince and Spring streets. City-owned and privately leased, the Garden attracts more than 100,000 visitors each year, including local elementary students, families and seniors, as well as residents from around the city and tourists from around the world, who learn about the Garden from several travel websites and guidebooks. The Garden is open to the public seven days a week, weather permitting and volunteers provide free public and educational programming. The Garden's design, size and configuration make it ideally suited for movies, music, yoga, community festivals, arts performances, educational programs, gardening and quiet meditation that are not offered in any other nearby public community space.
Schools
The NYC School Construction Authority (SCA) has the option to build a 100,000 square foot school at 509 LaGuardia Place in Greenwich Village on New York University-owned land (the Bleecker School Option), under a July 24, 2012 Restrictive Declaration by New York University (NYU) and amended by a letter from NYU to Councilmember Chin on October 21, 2014. Without action by our elected officials and NYU, the Bleecker School Option will expire on December 31, 2018 and will results in the transfer of $65+ million of value from NYC taxpayers to NYU, based on based on a real estate market where the price per buildable square foot in Manhattan averages more than $650, and arguably higher due to the lack of vacant land in Greenwich Village, either city-owned or city-optioned. Please also note, if the option expires, NYU would allocate no less than 25,000 square feet of above grade space for a community facility, when and if it decides to build the Bleecker Building. However, if for any one-year period NYU is unable to rent this space, 100% of the site reverts to NYU permanently. Bleecker School Key Community Benefit in 2012 NYU Rezoning: As part its 2012 rezoning, NYU made a good faith promise to our community for the Bleecker School, committing to a 100,000 square foot public school and a 2025 option date. As part ULURP, CB 2, the Manhattan Borough President and the NYC Department of City Planning all reviewed a rezoning package that included NYU’s commitment for a 100,000 square foot public school and a 2025 option date. However, the final rezoning approved by the NYC City Council included an option, that expired 11 years earlier on December 31, 2014. Need for Bleecker School: CB 2 recognizes the need for 600 public school seats at the Bleecker School, based on our June 2017 demographic analysis and the following drivers of demand: 1. Current elementary schools remain over capacity and overcrowded; 2. Continued development, rezoning and future zoning changes; 3. Unmet programmatic needs, such as dual-language programs, language based learning programs and inadequate space for physical education, arts, science and other non- math/ELA academic subjects; 4. Need to modernize 19th century school facilities throughout District 2 to meet 21st century education needs and comply with ADA standards for accessible design; 5. Expansion of Pre-K and 3K programs; 6. Inclusion of District 75 seats; 7. CEQR flawed methodology in estimating demand for public school seats, and growth of family-sized apartments; and, 8. Reduction in class size to comply with Contract for Excellence laws; Reinstate 2025 Option Date. To ensure that the SCA exercises its option to
build the Bleecker School, NYU must reinstate the School Election Notice to 2025. Not only is 2025 the date NYU originally promised, it also will a) give the DOE enough time to fund the school, which is currently unfunded in the DOE’s Capital Plan for FY 2020-2024; b) new school planning takes time -- 75 Morton took 12 years from advocacy to opening and NYU’s own 181 Mercer Building remains under construction; c) downtown schools at Trinity Place and Duarte Square are delayed; and, d) allows more time to consider educational needs in a dynamically changing residential environment. Duarte Square School in Hudson Square Public School & Gym. As part of the 2013 Hudson Square rezoning, Trinity Church will build the core and shell of a 444-seat elementary school, the Duarte Square School, under a March 20, 2013 Restrictive Declaration by The Rector, Church-Wardens and Vestrymen of Trinity Church in the City of New York. The DOE would fund the remaining cost, the majority of which is funded in the DOE’s Capital Plan for FY 2020-2024, released in November 2018. In addition, in a March 12, 2013 letter from the Department of Education to the Speaker of the New York City Council, the DOE has the option to build expanded recreation facilities in the Duarte Square site, including a) a double-height, 6,300 square foot gym, b) a 3,500 square foot multipurpose assembly space and c) 2,100 square foot multipurpose space. Trinity Church is exploring leasing or selling the Duarte Square School site and CB 2 want to ensure that the public school and gym commitments are not further delayed by a potential sale or lease. CB 2’s priorities for Duarte Square are to ensure that: 1. Trinity Church, or the new owner, and the SCA establish a timeframe for developing the school, 2. The SCA funds the additional recreation facilities and that these are designed with a separate entrance to allow for community use during non-school hours, 3. No charter school claims the site, and, 4. The school is designed and built with a separate gym and auditorium, not a “gymatorium,” as well as an outdoor playground. Funding Needs at Existing CB 2 Schools Underfunding = Overcrowding. Public schools in CB 2 are overcrowded and underfunded, resulting in large class sizes as principals attempt to stretch funding allocated on a per-student basis. To reduce class size, New York State needs to allocate additional funding and the DOE would need to increase capacity – one more reason to fund and build the Bleecker School. Technology. CB 2 supports additional funding for technology for MS 297, P751, PS 3, PS 41, PS 130, City-As-School High School and Broome Street Academy to ensure that all children have access to technology, a critical equity issue in education. Other Capital Projects. CB 2 also supports funding new water fountains at PS 3, air conditioning at PS 130, flexible classroom seating to build the literacy program at City-As- School High School and funding a green wall to augment the hydroponics program at City-As-School High School.
After School Programming. 75 Morton will be expanding enrollment through the 2020-21 school year, requiring additional funding for on-site after school programming, through the Department of Youth and Community Development’s School’s Out New York City. Arts Education. CB 2 wants to ensure that the DOE allocates funds for increased arts education, faculty and classrooms in our service area's public schools. Funding, Siting and Building New Public Schools The City Environment Quality Review (CEQR) process is flawed for analyzing how new development impacts public schools and overcrowding. Most development projects do not trigger an analysis of their impact on school seats and even when a new development triggers an Environmental Impact Analysis, the CEQR Technical Manual and EIS guidelines to do not accurately estimate the need for new public school seats. CB 2 recommends that: 1. The Department of City Planning develop new and better formulas, based upon current demographics, that more accurately represent the percentage of families with school age children that comprise our local population, and considers the number of families who can be expected to move into new residential development; 2. The Department of City Planning to institute a policy that would require a school impact study, using local data as required under the 2014 law, on all new residential construction and conversion, regardless of size; and, The City develop a mechanism that would require developers of all new residential buildings to contribute to a capital fund for public schools, and/or include new school seats within their projects.
Senior services
While our district ranks high in nearly every indicator, including income, we feel that measures of the median fail to tell an accurate narrative, especially where seniors are concerned. Greenwich Village has gone through a dramatic economic shift over the last twenty years or so. However, our senior residents arrived long before, when this community was less affluent, when the cost of living was less expensive, and when rents were lower and more units were rent-stabilized. We worry that misleading data threatens the funding allocated by DFTA to Greenwich House, which is the primary provider of senior services in our district. Greenwich House is expanding its program to meet increased need at West Village Houses and at Westbeth, where Greenwich House calculates approximately 50% of its 640 units now have residents growing increasingly frail and at-risk. Greenwich House works mostly under the constraint of government contracts, which can be inflexible, byzantine in their stipulations, and out-of-step with current costs. The result is that Greenwich House’s programs are unable to provide all that our curious, artistic,
intellectually vibrant seniors desire. Contract reimbursements have also failed to compensate for inflation, placing increased strain on Greenwich House’s budget Greenwich House relies on others to provide complementary services. One of these is Visiting Neighbors – a volunteer-based organization that operates what appears to be a cost-effective program aimed at improving quality of life, enhancing health indicators, and reducing hospital stays for older residents. Visiting Neighbors has been receiving discretionary City Council funds since DFTA cancelled its contract, forcing it to significantly reduce its scope. We urge DFTA to contract with Visiting Neighbors again.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 2
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
Many elders in our district have decided to “age in place”, but services for our older residents have been cut drastically. The meal program at one of our centers (First Presbyterian) was eliminated a few years ago, and our other centers are overcrowded, with multiple seatings. An important part of the meal program, social contact, seems to be ignored completely. We would like to understand the goals of the Department for the Aging because they do not seem to be in accord with our understanding of the needs. We note that several cost-effective programs for seniors – Visiting Neighbors is the most obvious – have lost funding. Again, we are joining our elected officials to work to solve this problem, but we need the City to support Visiting Neighbors, as well as adult day care facilities, in order to allow seniors to live independently in their own homes. Our elderly are vulnerable to the rampant building boom in our community, when landlords seek to push seniors out. New building permits must accommodate the elderly. Many of our seniors continue to live in rent-regulated walk-up apartments. Renovation, not removal, is needed.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
Many elders in our district have decided to “age in place”, but services for our older residents have been cut drastically. The meal program at one of our centers (First Presbyterian) was eliminated a few years ago, and our other centers are overcrowded, with multiple seatings. An important part of the meal program, social contact, seems to be ignored completely. We would like to understand the goals of the Department for the Aging because they do not seem to be in accord with our understanding of the needs. We note that several cost-effective programs for seniors – Visiting Neighbors is the most obvious – have lost funding. Again, we are joining our elected officials to work to solve this problem, but we need the City to support Visiting Neighbors, as well as adult day care facilities, in order to allow seniors to live independently in their own homes. Our elderly are vulnerable to the rampant building boom in our community, when landlords seek to push seniors out. New building permits must accommodate the elderly. Many of our seniors continue to live in rent-regulated walk-up apartments. Renovation, not removal, is needed.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/44
DFTA
Allocate funds for
These programs result in happier and healthier
outreach services to
seniors, as well as save hospital and nursing
homebound older
home costs. Current cuts have short-changed
adults and for
the needs of our elderly. Reorganization and
programs that allow
strategic prioritizing of city/state/federal
the elderly to age in
agencies may be needed.
place
3/44
DOHMH
Other programs to
Allocate funds to provide outreach and
address public
treatment that targets individuals who are
health issues
using drugs on NYC streets. We support the
requests
work of Greenwich House as our local provider
of needed substance abuse treatment to New
Yorkers within our district and without.
However, we also support DOHMH initiating an
outreach program that targets individuals
openly using drugs on public streets, so they can
get the help they need.
4/44
DHS
Expand street
Allocate additional funds for outreach and for
outreach
improved access to existing services for our
homeless population. While we recognize the
difficulty in encouraging street homeless to
accept shelter and services, we also know that
the more engagement there is with providers,
the more successful their efforts are likely to be.
Strong funding is necessary to maintain a robust
presence of outreach workers in our district.
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 2
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
New York City has the option to build a 100,000 square foot new public school in Greenwich Village – the Bleecker School. For this to happen, the NYC Department of Education (DOE) must fund the school before the option expires on December 31, 2021. As part of the New York University 2012 up-zoning, NYU’s key community giveback was the option to build the Bleecker School, a 100,000 square foot public school that would serve approximately 600 students. If the Bleecker School is not built, 100,000 square feet of school space reverts to NYU for university use. If the Bleecker School option expires on December 31, 2021, $65+ million in value transfers from NYC taxpayers to NYU, based on the average price per buildable square foot in Manhattan and arguably higher, due to the lack of vacant land in Greenwich Village. Please also note, if the option expires, NYU would allocate no less than 25,000 square feet of above grade space for a community facility, when and if it decides to build the Bleecker Building.
However, if for any one-year period NYU is unable to rent this space, 100% of the site reverts to NYU permanently. Next Step: NYC DOE Must Fund the Bleecker School by 2021. The DOE must fund the Bleecker School in its FY 2020
– FY 2024 Capital Plan before December 32, 2021, otherwise the option expires. While an extension of the option expiration date to 2025 – the date originally proposed by NYU – would allow the city more time to fund the Bleecker School, NYU has publicly stated that it will not agree to further extensions. What Kind of School Can Built at the Bleecker School Site. The Bleecker School can serve public school students from pre-kindergarten to 8th grade, i.e. PK-5, 6-8 or PK 8, but a high school would require NYU consent. The Bleecker School can serve general education students, Students with Disabilities, such as students with dyslexia, or other learning disabilities and/or District 75 students. CB 2’s Position. CB 2’s September 2019 Resolution – Dyslexia Education: A Critical Equity Issue for NYC Students – supports 1) the implementation of early screening, curriculum development, teacher training, programs and schools to support and teach children with dyslexia in NYC public schools and 2) the creation of a DOE public school program for dyslexic students at the Bleecker School Site. Currently, there are no DOE public schools or programs for students with dyslexia and language-based learning disabilities, even though there are several private special education schools and a newly opened charter school specifically designed to address the learning needs of these students.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Bleecker School: Under a July 24, 2012 Restrictive Declaration by New York University (NYU) and amended by a letter from NYU to Councilmember Chin on October 21, 2014, the NYC Department of Education has an option to build a 100,000 square foot public school at 509 LaGaurdia Place in Greenwich Village on New York University- owned land. To exercise this option, the DOE must fund the school by December 31, 2018 and start construction by July 31, 2020. The DOE may build a school to serve students through 8th grade (not high school students.) If the DOE does not exercise this option, the buildable rights revert to NYU and NYU would allocate no less than 25,000 square feet of above grade space for a community facility. In addition, under the Restrictive Declaration, NYU has the right to build up to 70,000 square feet of below grade space. Currently, the Bleecker School is not funded in the DOE Capital Plan for 2015-2019, updated in February 2017. Need for School Seats: CB 2 recognizes the need for 600 public school seats at the Bleecker School, based on our June 2017 analysis that shows: 1. 148 to 337 seat shortfall from overcrowding at all three CB 2 elementary schools for 2015-2016, based on outdated Blue Book figures that underestimate overcrowding, at 112% at PS 3, 109% at PS 41 and 109% at PS 130 as well as 114% at PS 11, 2. 88 seat shortfall at the Duarte Square School, based on a CEQR multiplier of 0.16, 3. 169 to 225 seat shortfall resulting from the 550 Washington rezoning – approved with out any school seats – based on a CEQR multipliers of 0.12 and
0.16 respectively, 4. 100+ seats to reduce kindergarten class size to comply with Contract for Excellence class size reductions (and 650+ seats for grades K-5), 5. 69 seats to expand pre-kindergarten seats to 50% of the kindergarten cohort, 6. 131 seats to expand 3K programs to 25% of the kindergarten cohort, 7. 44 seats for District 75 students at
Duarte Square, 8. 60 seats for District 75 students at Bleecker, and, 9. Additional square footage and seats to comply with physical education requirements, Next Steps: Community Board 2 is committed to ensuring that the NYC School Construction Authority exercises its option to build a school on the Bleecker Street site. To ensure that this happens, NYU needs to reinstate the School Election Notice to 2025, which was NYU’s original proposal. CB 2 also urges the SCA and the DOE to take into account the demographic analysis and projections developed by CB 2 and fund the Bleecker School in the SCA’s next five year Capital Plan. Existing Elementary Schools All three of our current primary schools (P.S. 3, 41, and 130) are overcrowded and in need of regular capital investment to maintain the adequacy of the physical plant. For us, excellent public schools are a priority. In FY 2017, the near term capital needs are for improved technology and new water fountains. Funding, Siting and Building New Public Schools The City Environment Quality Review (CEQR) process is flawed for analyzing how new development impacts public schools and overcrowding. Most development projects do not trigger an analysis of their impact on school seats and even when a new development triggers an Environmental Impact Analysis, the CEQR Technical Manual and EIS guidelines to do not accurately estimate the need for new public schools seats. CB 2 recommends that: 1. The Department of City Planning develop new and better formulas, based upon current demographics, that more accurately represent the percentage of families with school age children that comprise our local population, and considers the number of families who can be expected to move into new residential development; 2. The Department of City Planning to institute a policy that would require a school impact study, using local data as required under the 2014 law, on all new residential construction and conversion, regardless of size; and, 3. The City develop a mechanism that would require developers of all new residential buildings to contribute to a capital fund for public schools, and/or include new school seats within their projects.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/20
SCA
Provide a new or
Allocate funds for the 100,000 square foot
expand an existing
Bleecker Street School. As part of the New York
elementary school
University 2012 up-zoning, NYU’s key
community giveback was the option to build the
Bleecker School, a 100,000 square foot public
school that would serve approximately 600
students. If the Bleecker School is not built,
100,000 square feet of school space reverts to
NYU for university use. If the Bleecker School
option expires on December 31, 2021, $65+
million in value transfers from NYC taxpayers to
NYU, based on the average price per buildable
square foot in Manhattan and arguably higher,
due to the lack of vacant land in Greenwich
Village. P
9/20
SCA
Provide technology
Allocate funds for technology improvements,
upgrade
including smartboards, laptops and computers
for PS 3, PS 130, MS 297, P751, Broome Street
Academy and City-As-School High School. CB 2
supports additional funding for technology at PS
3, PS 130,MS 297, P751, Broome Street
Academy and City-As-School High to ensure that
all children have access to technology, a critical
equity issue in education.
13/20
SCA
Renovate or
Allocate funds to P.S. 3 for gymateria dividers to
upgrade an
increase flexibility and use, library renovation
elementary school
and physical fitness, including playground
equipment upgrade and enhancements to the
roof playground.
14/20
SCA
Renovate or
Allocate funds to build STEAM and Literacy
upgrade a high
programs including a Wet Lab, Maker Space,
school
Literacy Lab and Library / Media Center as well
as to add water bottle refilling stations at City-
as-School High School.
15/20
SCA
Renovate or
Allocate funds for a library at Broome Street
upgrade a high
Academy, which also would be available to The
school
Door members, as well as a cafeteria upgrade.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
8/44
DOE
Provide more funds
Allocate funds for a washing machine and dryer
for teaching
to give students access at MS 297 and City-as-
resources such as
School High School. Because students who lack
classroom material
access to laundry facilities tend to have higher
absentee rates, CB 2 supports funding the
installation of washers and dryers at schools
that serve students in temporary or transitional
housing.
12/44
DOE
Other educational
Allocate funds for curriculum development and
programs requests
teacher training for Culturally Responsive –
Sustaining Education in our district’s public
schools. CB 2 supports funding for curriculum
development and teacher training for CB 2
areas schools for Culturally Responsive –
Sustaining Education in alignment with the
Culturally Responsive - Sustaining Education
(CR-SE) Framework that the NYS Education
Department issued in March 2019 and the
definition of Culturally Responsive - Sustaining
Education (CR-SE) that the DOE approved in July
2019.
24/44
DOE
Other educational
Allocate and baseline additional funds for
programs requests
increased arts education, faculty and
classrooms in our district’s public schools based
on the CPI. Two recent studies, one by the NYC
Comptroller ("State of the Arts") and the other
by the Manhattan Borough President
("ArtsForward"), identified deficiencies in arts
programs in public schools. While some funds
were allocated in FY 2015, we ask the City to
baseline that and provide additional funding to
hire more dedicated arts faculty and provide
adequate infrastructure for arts education.
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 2
image
M ost Important Issue Related to Public Safety and Emergency Services
Public Nuisance (noise, other disturbances)
The most frequent quality of life complaints relate to noise from various sources, including bars, clubs and restaurants that generate unruly crowds, produce excessively loud amplified sound, and/or have exterior HVAC systems that generate noise levels in excess of code limits. Another source is construction activity, especially when the Department of Buildings authorizes extended daytime hours and weekend hours for projects that are adjacent to residential uses in violation of the department’s own rules for issuing such permits. Yet another is unregulated engines, on vehicles like food trucks, which produce noxious fumes as well as excessive noise.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 2
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Noise pollution
The most frequent quality of life complaints in CD2 relate to noise from various sources, including bars, clubs and restaurants that generate unruly crowds, produce excessively loud amplified sound, and/or have exterior HVAC systems that generate noise levels in excess of code limits. Another source is construction activity, especially when the Department of Buildings authorizes extended daytime hours and weekend hours for projects that are adjacent to residential uses in violation of the department’s own rules for issuing such permits. Yet another is unregulated engines, on vehicles like food trucks, which produce noxious fumes as well as excessive noise.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
5/44 DSNY Provide more on-
street trash cans and recycling containers
Allocate funds for the placement of additional litter baskets and for additional basket service. Too often, corner litter baskets in pedestrian heavy areas of CD2 are overflowing with debris. We are requesting additional resources be allocated to remedy this situation.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 2
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
CB2 strongly supports retailers and especially small businesses in our service area. Non-conforming oversized retail operations, however, often bring numerous harms to our mixed-use neighborhoods and undermine the small and local-serving retailers that employ many and serve as the backbone of a thriving economy. Balance is needed here, along with solid and consistent enforcement of local zoning. Non-permitted oversized retail, which has been allowed to operate in violation of public policy, has become a significant problem within CB2’s M1-5B zoning districts. Continuing conflicts caused by these big retail operations raise concerns among our elected officials and the residents and small business operators of CB2. We know that these oversized non-permitted operations are also a concern for the Department of Buildings, which in the spring of 2017 issued six ECB violations for illegal retail operations along the M1-5B Broadway corridor. However, during the adjudication of those ECB violations at the Office of Administrative Trials and Hearings (OATH), numerous deficiencies were observed, both in regard to zoning inspections and zoning enforcement. Our goal at CB2 is to find meaningful paths for correction of these unsatisfactory conditions, so that our local laws are upheld and the quality of life for our community is not unnecessarily diminished. Proposals towards that end were included in a letter sent to DOB on June 22, 2018. They were: ? Significant and meaningful financial penalties for violations of zoning ? Significant and meaningful penalties for improper self-certifications ? Better training and management for DOB inspectors ? Increased resources for DOB attorneys and OATH hearing officers
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
CB2 has few undeveloped sites left that are appropriate for large-scale development. Exceptions include St. John's Terminal and the Special Hudson Square District. In 2013, the City approved the Special Hudson Square District in the southwestern portion of our district. This rezoning created a mixed-use district by incentivizing residential development in combination with affordable/inclusionary housing, expanded community facility uses, ground-floor retail, and limiting as-of-right hotel development, while at the same time ensuring that commercial and manufacturing uses are retained. The proposal also included height limits and set-back regulations that will help to preserve the unique identity of the district. We are starting to see applications for conversions to residential from this neighborhood, many of which include affordable units under the auspices of the Inclusionary Housing program. Our goal is to not only encourage projects that provide affordable housing, but also encourage a sense of community and social interactions. Developer amenity packages pose a significant challenge in this regard. Another challenge is the loss of affordable units due to luxury and vacancy decontrols as well as tenant harassment, illegal landlord behavior especially with respect to construction and false DOB filings. In light of the mayor’s mandate to add affordable units, the community has been encouraging consideration of a large site that provides access and repair of the underground water infrastructure at 388 Hudson Street (next to a park) as a possible and appropriate affordable housing development site. We had strongly urged the City to consider this site in lieu of the tiny site in Little Italy known as the Elizabeth Street Garden. Our preference has gone unheeded and we continue to pursue the protection of a vital and much-loved garden in a neighborhood starved for open space.
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
TRANSPORTATION
Manhattan Community Board 2
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
One of the District’s major traffic and transportation problems is with vehicular congestion around the entrance and exit to the Holland Tunnel. The tunnel brings in great volumes of private vehicles visiting the city from out of state. In addition, trucks make many local commercial deliveries, and use our narrow streets to travel from the Hudson River to the F.D.R. Drive, south to the Financial District and to the outer boroughs. Our fragile network of narrow streets is also clogged with trucks skirting the one-way toll on the Verrazano-Narrows Bridge in order to use the toll- free Manhattan Bridge to access the Holland Tunnel. With the elimination now of toll booths on the Staten Island side of the bridge, and toll collection being done by way of E-Z Pass scanners and license plate readers, the one-way Verrazano toll is no longer feasible, and we welcome the cohesive steps now being taken in Congress to eliminate it. Every year in our budget requests, we ask that the City work with the Port Authority to consider new approaches to dealing with the traffic back-ups that are caused by the Holland Tunnel. We are pleased to note that some of these problems are now being examined by DOT's Hudson Square/West Village Transportation Study to identify and address longstanding transportation challenges as well as challenges and opportunities anticipated in the near future, and we look forward to the final report of findings and proposals that result from this study. We also ask for enforcement strategies to help keep traffic from “blocking the box” at intersections, as well as to control honking, especially now that "No Honking" signs are no longer used, and to curtail reckless driving done to circumvent congestion. We continue to work with the Hudson Square Business Improvement District to address many of these Holland Tunnel problems, and look to continue to work with them and the relevant agencies, to find and implement long lasting solutions, with hopes that these agencies will respond to our needs and recommendations.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Disabled access in our subway stations is greatly lacking, with not even a handful of stations in the CB2 District providing either elevators and/or escalators to enable the many physically challenged in our area to use the subways. Although the Capital Plan is providing for installation of more elevators and escalators throughout the city, many, many stations where such ADA accessibility is needed will still go without, including most of those in CB2.
Our goal is to have every one of the subway stations in CB2 be furnished with the elevators and escalators that will give all of our citizens the rightful access they need to get around. In addition, every effort needs to be made to repair and rehabilitate our deteriorating subway stations for users’ comfort and safety. In particular, the West 4th Street station has been severely deteriorating over many years of neglect to the point that current conditions are not only off-putting, but also a threat to people’s health and safety. All of the platforms and surrounding areas are plagued with moldy, leaky and peeling walls and ceilings, and a full rehabilitation is long overdue.
Needs for Transit Services
Community District 2 has several internationally known tourist destinations that encourage heavy nighttime and weekend usage of the district’s streets, by both cars and pedestrians. New York City Transit should be initiating a major effort to increase the use of public transportation in this context as well as in general by making it more comfortable, convenient, accessible and frequent, and making transit access points more user friendly for both visitors and residents. The removal of many of our subway station agents compromises our safety and takes away our source for vital information and orientation. We vehemently oppose these cuts that are completely counter to the sustainability goals of PlaNYC and Vision Zero. Public transportation makes more efficient use of space and energy, significantly reduces air and noise pollution, and minimizes pedestrian/vehicular conflicts. Therefore, instead of imposing these destructive cuts on a population that already depends so strongly on transit and its benefits, opportunities must be explored and followed through in providing new transit access and routes in areas of need, and sources of funding for our suffering transit system must be pinpointed and secured. CB2 has passed at different times at least three resolutions in support of congestion pricing, both to raise funds for transit
improvements and to curtail the ever-growing congestion that disrupts our streets. One major transit deprivation impact has resulted from the removal of the M6 bus route and the diversion of the M1, M3, and M5 buses from the routes they followed for many years in District 2. The new route locations are difficult, if not impossible, to reach for CB2’s sizable and growing senior and disabled populations who have depended on convenient bus service to access important destinations, such as medical facilities and food shopping. They have resulted in distances, timing, stop locations, and reduced frequencies that severely penalize the entire District’s residents, workers, parents and children because of the long waits, crowded buses, far apart stops and lack of needed accessibility. These routes need to be restored to their former locations that provide the service the community needs although with every passing year, the likelihood of this happening becomes more doubtful, but we're hopeful that the remaining existing routes can be modified for the comfort and convenience of our seniors and all our citizens who depend on these buses for transportation. In addition, every effort needs to be made to repair and rehabilitate our deteriorating subway stations for users’ comfort and safety. In particular, the West 4th Street station has been severely deteriorating over many years of neglect to the point that current conditions are not only off-putting, but also a threat to people’s health and safety. All of the platforms and surrounding areas are plagued with moldy, leaky and peeling walls and ceilings, and a full rehabilitation is long overdue. L-train stations along 14th Street are also in need of upgrades, and their 15-month closing during the Canarsie Tunnel Project presents a perfect opportunity for carrying out needed improvements, including ADA accessibility, at all three CB2 L-train stations. At this point, agreement has been reached for renovations to be done that make our 6th Avenue 14th Street station ADA accessible. We are hoping that not only CB2's other two stations on 14th Street along the L line can be made accessible in the very near future, but that all the subway stations in our district can be converted into ADA- accessible ones very quickly, something that is very needed and long overdue.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/20
NYCTA
Improve
Allocate funds to refurbish walls, floors and
accessibility of
ceilings in the West 4th Street subway station
transit
and add full disabled access by elevator at the
infrastructure, by
northern end of the station. This station, the
providing elevators,
ninth busiest in the City and a major hub for
escalators, etc.
seven subway lines, suffers from peeling walls,
leaky ceilings, and broken wall tiles. These
conditions not only affect local and transient
users but also have negative impacts on
Greenwich Village's role as an important center
of business, tourism and major institutions and
needs to be quickly addressed by the MTA's
Station Renewal Program.
6/20
DOT
Roadway
Allocate funds to reconstruct Clarkson St. from
Clarkson
maintenance (i.e.
West St. to Greenwich St. including repair &
Street
pothole repair,
replacement of Belgian blocks and installation
Greenwich
resurfacing, trench
of a granite bicycle lane. The Belgian block
Street West
restoration, etc.)
street bed on Clarkson St. bet. West and
Street
Greenwich Sts. is in great need of repair with
loose, broken, scattered and missing blocks,
large uncovered spaces, exposed manholes, and
deep ridges, posing a major hazard to
pedestrians, those in wheelchairs and with
strollers, bicyclists and drivers. Bicyclists opt to
use the sidewalk instead, endangering people
walking there. A granite strip bike lane will
provide comfortable, direct bike access and keep
bike riders off the sidewalk.
12/20
DOT
Reconstruct streets
Allocate funds to install a granite strip bicycle
Morton
lane on Morton Street between West Street and
Street West
Washington Street. The Belgian block surface is
Street
unsuitable for bikes, resulting in cyclists riding
Washington
on the sidewalks, hazardous for pedestrians.
Street
Morton Street is a main thoroughfare from the
Hudson River Park (West St) going east, calling
for an eastbound bicycle lane, granite between
West and Washington Streets and striped
eastward from Washington. The new 75 Morton
Street school makes it even more urgent to keep
bicycles safely off the sidewalks and provide for
safe bicycling for all.
16/20 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Allocate funds to repair and replace Belgian blocks on Bond St., between Broadway and the Bowery, on Wooster St. between Houston and Canal Streets., on Gansevoort and Little West 12th Streets between 9A and 8th Ave., and on 14th St. between 9th Ave. and Route 9A. Belgian Blocks are either badly damaged, missing or both and need to be restored and/or replaced.
In some cases the structural base is so deteriorated, reconstruction is needed. Current poor condition is hazardous to pedestrians and a blight to the historic districts. The restoration of these streets with Belgian blocks is essential in keeping with the nature of these historically important areas
image
CS DOT Improve traffic and pedestrian safety, including traffic calming (Capital)
Allocate funds for traffic safety measures, such as road markings and Stop signs, on Bedford St. between 6th Ave. (Ave. of the Americas) and Carmine St. Speeding vehicles, sharp curves and varied lane sizes with abrupt turns and changes, an unusually wide entrance from 6th Ave., obscured sight lines (in particular at Downing St.), insufficient signage and markings make Bedford St. exceptionally hazardous for the many pedestrians using these neighborhood streets as well as for motorists.
image
CS DOT Improve traffic and pedestrian safety, including traffic calming (Capital)
Allocate funds for parking and intersection alignment improvements, including sidewalk extensions, high visibility crosswalks and signalization changes on Greenwich Ave. from Bank St. to W. 12th St. and on W. 12th St. from Greenwich Ave. to the midblock entrance of the new AIDS Memorial Park at St. Vincent's Triangle. Broad, oddly angled intersections, long, badly marked crosswalks (or none), shortage of traffic controls and wide street beds endanger the increasing number of pedestrians crossing on Greenwich Ave. between W. 11th and W. 12th Sts. and on W. 12th St. between Greenwich and 7th Aves., heading to the new park, the AIDS memorial, the subway and to school, particularly hazardous at Bank St. and at the intersection of Greenwich Ave. and W. 12th St.
image
CS
DOT
Improve traffic and
pedestrian safety, including traffic calming (Capital)
Allocate funds to extend the corner sidewalk
extension on West St, at the northeast corner of Houston and West Sts., to widen the median on West St. at Houston, and change the traffic light signal to phasing. Numerous cars and trucks turn right rapidly from Houston St. onto West St. going north, while vehicles turn east from West onto Houston, all at the same time pedestrians are crossing West St., endangered by the fast- turning traffic and often getting stuck in the narrow West St. median. A separate green light phase for pedestrians and shortened crossings are needed to safeguard the many people traversing West St. to Pier 40 and the Hudson River Park. NYC DOT is urged to work together with NYS DOT on signalization and geometric improvements.
CS
DOT
Improve traffic and pedestrian safety, including traffic calming (Capital)
Allocate funds to study and institute safety improvements at 7th Ave. S., Carmine, Varick and Clarkson Sts. intersection, including neckdowns, traffic signal changes and repositioning, daylighting, lane reconfiguration, and other geometric improvements. Excessively long pedestrian crossings, poor visibility, motorists driving on the sidewalk, gridlock, blocked crosswalks, hazardous turning movements, intermittent speeding, irregularly angled design and chaotic Holland Tunnel- bound traffic create exceptionally dangerous conditions for the many pedestrians (residential, working, tourists/seniors and children) using this area. A promised improvement plan presentation is awaited.
7th Avenue South Carmine Street Clarkson Street
CS DOT Improve traffic and pedestrian safety, including traffic calming (Capital)
Allocate funds for the concrete widening of the subway triangle on 7th Ave. S. between Grove and Christopher Streets and on Grove St. between W. 4th St and 7th Ave. S. Different turning and traffic patterns call for safer pedestrian crossings, while the new bicycle path configuration on 7th Ave. S. has introduced a dangerous conflict for people coming from the subway who expect they can head for the 7th Ave. S. pedestrian island to cross the street, not realizing their vulnerability to bikes. The Grove St. curb edge doesn't align with the southern tip of the 7th Ave. S. island, allowing for a curbside No Parking lane leading directly into the island's protruding southern edge, particularly dangerous for both drivers and pedestrians in the snow with no visibility to avoid the island edge.
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
7/44 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
Allocate funds for traffic safety improvements at Cooper Sq. Plaza crossing (4th Ave. to Bowery at
E. 6th St.) including speed humps, signage, signalization changes. The roadway winding around and through Cooper Sq. Plaza bet 4th Avenue at E. 7th St. and the Bowery at E. 6th St. presents numerous crossing hazards to pedestrians and potential vehicular conflicts, such as buses, taxis, livery vehicles, trucks and private cars entering from the Bowery at excessive speeds, obstruction of drivers' visibility at the 4th Ave. bend in the roadway, lack of coordinated traffic light signals at the Bowery with a constant "Walk" light misleading pedestrians, and pedestrians crossing every which way, for lack of information on where to cross.
image
11/44
DOT
Improve traffic and
Allocate funds to reduce speeding and
pedestrian safety,
directional impacts at the pedestrian crossing
including traffic
on the east side of W. 8th St. at 6th Ave. and at
calming (Expense)
the intersection of W, 8th St., 6th and
Greenwich Aves. We propose considering
solutions such as installation of a traffic diverter
on the northern lane of Greenwich Ave. at 6th
Ave. and/or continuing the 6th Ave. protected
bike lane south with an extended median. The
exceptionally wide open and irregularly angled
intersection creates confusion, causes turning
conflicts, facilitates speeding and hinders
visibility, putting pedestrians in grave danger,
exemplified by the recent horrific pedestrian
fatality.
17/44
DOT
Improve traffic and
Allocate funds for traffic safety improvements at
pedestrian safety,
the intersection of Waverly Pl., Christopher and
including traffic
Grove Sts. (Stonewall Natl Monument area),
calming (Expense)
including neckdowns, sidewalk extensions,
daylighting, stop signs, improved directional
signage. Lack of visibility, wide crossings, illegal
parking, and pedestrians crossing in multiple
paths create danger and confusion for both
pedestrians and drivers at this complex,
irregular intersection. This area now
encompasses the Stonewall National
Monument, attracting increased crowds,
pedestrian activity, tour buses and other
vehicular movement, calling for swift attention
to improving safety here.
21/44
DOT
Other expense
Allocate more resources for speed hump
traffic
inspections and installation. CB2 receives many
improvements
requests for speed humps, but because of lack
requests
of DOT resources, they typically take 2 or more
years to install. Sufficient resources are needed
to gather the data to address this need and
secure proper and timely installation, including
assemblage, signage, and markings so that
community needs are met more speedily.
22/44
DOT
Other expense
Allocate funds to install speed humps on Jane St.
traffic
between Greenwich and 8th Aves., on Spring St.
improvements
bet Mott and Elizabeth Sts, and on Perry St. bet.
requests
W. 4th St. and 7th Ave. S. Excessive speeding by
automobiles, taxis and trucks with many close
and hazardous calls threatens the safety of
pedestrians crossing the street, including many
children on their way to school and call for
speed humps to slow down the dangerous
traffic.
27/44 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
Allocate funds to reduce pedestrian/vehicular conflicts at the southwest side of Christopher St. and Greenwich Ave. Pedestrians crossing Christopher St. are endangered by swift-turning motor vehicles from Greenwich Ave., confusing traffic signalization, and obscured visibility.
Traffic signal modifications, such as split phase with a dedicated green pedestrian light or a flashing arrow with delayed left turn, and daylighting at the Greenwich Ave. s.w. corner are needed.
image
30/44 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
Allocate funds to install split phase signalization, and bulb out plus daylight the northeast corner of West 13th St. and Greenwich Ave.Speeding vehicles come west on 13th St. and turn north onto Greenwich Ave. at the same time pedestrians are crossing Greenwich there; the vehicles lack visibility of both pedestrians (who have the Walk signal) and the Walk signal itself, while also advancing continuously without slowing down, enabled to speed through because the turning radius is exceptionally wide, closer to 180 degrees than a true corner turning curve, seriously endangering pedestrians.
image
32/44 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
Allocate funds to conduct a study of the blocks with and/or impacted by design changes related to dangerous traffic conditions on Jane St. btw. Greenwich and 8th Aves. and at the W. 13th St./Greenwich Ave./Horatio St. intersection, including Jane btw. Greenwich and 8th Aves., Greenwich btw. 8th Ave. & Jane, Horatio btw.
W. 4th St. and 8th Ave. and W. 13th approaching Greenwich Ave./Horatio St. Recent design, operational and regulatory changes related to increasing pedestrian safety at the Mobil gas station at Horatio St. and 8th Ave. have led to westbound traffic from W. 13th St. having to turn either north or south on Greenwich Ave. resulting in unforeseen increases in vehicular activity and speeding on Greenwich btw. W. 13th and W. 14th Sts. and on Jane St. btw. Greenwich and 8th Aves.
image
34/44 DOT Provide new traffic
or pedestrian signals
Allocate funds to install louvers on traffic light at Carmine Street on Bedford Street. A traffic light at Carmine St. on Bedford St. which is one block ahead of a hazardous crossing at Downing St. exacerbates the danger crossing Downing as drivers surge past it to catch the Carmine green light. Louvers on the Carmine traffic light would obscure the green signal, eliminating the impetus for drivers to speed up past Downing St.
image
39/44 DOT Conduct traffic or
parking studies
Allocate funds to conduct a study on the potential for installing a greenway on University Pl. from 14th St. to W. 4th St. where it would connect with Washington Sq. Park. University Pl. has been converted into a shared street btw.
13th and 14th streets and its direction reversed there, resulting in reduced vehicular traffic on University, which already is a quiet street oriented to community life. A greenway from 14th St. to Washington Sq. Park would create a calm, safe, comfortable and attractive neighborhood environment that further enhances the street's use and enjoyment.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 2
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Insufficient park or open space
The neighborhood around Elizabeth Street Garden lacks open space. Little Italy and SoHo account for 23% of CB 2's population but have only 3% of its open space, virtually 100% paved, for an open space ratio of only 0.07 acres per 1,000 residents, as compared with the City planning goal of 2.5 acres per 1,000 residents. Furthermore, the majority of CB 2's open space is in Washington Square and Hudson River Parks, nearly a mile and 1.2 miles from the Garden, respectively. Residents in Little Italy and SoHo are less likely to use these spaces with frequency. Furthermore, Elizabeth Street Garden is located in the only downtown Manhattan neighborhood that the NYC Parks Department defines as “underserved” by open space. Elizabeth Street Garden is a unique community park and green space with open lawn, majestic trees, flowering garden beds, and sculptural artworks located in the Little Italy neighborhood of Manhattan, between Prince and Spring streets. City-owned and privately leased, the Garden attracts more than 100,000 visitors each year, including local elementary students, families and seniors, as well as residents from around the city and tourists from around the world, who learn about the Garden from several travel websites and guidebooks. The Garden is open to the public seven days a week, weather permitting and volunteers provide free public and educational programming. The Garden's design, size and configuration make it ideally suited for movies, music, yoga, community festivals, arts performances, educational programs, gardening and quiet meditation that are not offered in any other nearby public community space.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
With only about .58 acres of parkland per 1000 residents, our district has one of the lowest ratios of public open space in the city, and with its fully built up high-value land, the City standard of 2.5 acres is an unobtainable goal. But important progress has been made in recent years. Along with the development of the Hudson River Park and the Highline, there has been a steady and ongoing stream of improvements to the quality and condition of our parks with recently completed renovations at Washington Square and JJ Walker and the Jane Street Triangle, along with needed repairs at the Tony Dapolito Recreation Center. Last year, the new park at St. Vincent’s Triangle finally opened to the public and the community looks forward to the ribbon-cutting for the AIDS Memorial at the northwest corner of the site. In addition, funding is in place for open space at Duarte Square, and for streetscapes within Hudson Square. Funding and design work has progressed for upgrades at Father Fagan Park and DeSalvio Playground. Funding has been obtained from a variety of sources for improvements at Pier 40, Little Red Square, Jackson Square, and SoHo Square. These initiatives will make our parks more attractive and safer, thereby providing more people a better park experience. These additions and improvements are critical, but they have not been sufficient because the population of families with young children continues to rise in our district, increasing the overcrowding of our active play spaces. In addition, several large-scale development projects and major rezoning proposals have been approved during the last year, which will add to the pressure on our parks and the need for more open space, particularly those in which active recreation will be possible. Whereas the focus of our efforts over the last few years has been on the preservation and improvement of the existing parks, we now see a need to strive to take advantage of every opportunity to create new open space. We thank our elected officials and City agencies for their support and we urge them to continue to help us protect, preserve and improve the public open space while we ask that they work with us to pursue every opportunity for creating new open space in our district. Continuing Upgrade of Parks and Playgrounds and Facilities While most of our parks are in good condition, there are still some that need renovation. DeSalvio Playground, at the corner of Prince and Mulberry Streets, was last renovated in 1996. The park is now run down, uninteresting, and underused despite its location in an area with no other parks and a growing population of families with young children. An energetic group of parents has launched a drive to get the park rebuilt and the council member has allocated some of the required funds. Father Fagan Square is also in the process of being renovated. An active group of local residents has been engaged for several years, funds have been allocated by the City Council, a design has been created, reviewed, revised and recently presented
to the community. It received a warm response, so we urge all involved parties to proceed with this project. Trees As an area with very few large parks and burdened by high vehicular traffic, our district greatly values the benefits of streets trees. We support the citywide effort to plant one million new trees. We passed a resolution urging the Parks Department to make the replacement of trees the highest priority for tree plantings in our district and we have seen some replacements. We also requested a policy change whereby tree and stump removals automatically generate a high priority request for a new tree without the need for a second 311 request.
Needs for Cultural Services
A. The Arts Community Board 2 is delighted by the arts and culture that the Whitney Museum of American Art in the Gansevoort Market district has infused into our district since opening its doors in May 2015, and also appreciates the institution’s regular communications with and support of our board. This important institution, which was originally founded in our district, is a great asset to the Far West Village and has begun to help re-focus the neighborhood as an art and design district. The Museum is an exciting center of art, with exterior exhibition spaces as well the traditional interior spaces. Integrated with the High Line Park that runs along the eastern face of the building, the museum offers restaurants, gathering places, and other public areas as part of its overall design. In addition, our district has several other fine museums, including the NYC Fire Museum, the Children’s Museum of the Arts, the Museum of Chinese in America, the Leslie Lohman Museum of Gay and Lesbian Art, the Merchant’s House Museum, and The Drawing Center, among others. CB2 is also excited about the Jackie Robinson Museum, which is scheduled to open in our district within the next couple of years. Community District 2 is also home to a unique array of performance spaces, Off-Broadway and independent theaters, film centers, and dance organizations. We take tremendous pride in the vibrant cultural scene that these organizations provide our community. These cultural organizations include: HB Playwrights; Cherry Lane Theatre; HERE; Rattlestick Playwrights Theater; Greenwich House & Greenwich House Pottery; The Gym at Judson; IRT Theater; IFC Center; Film Forum; Angelika; Cinema Village; Quad Theater; Actors Playhouse ; 13th Street Rep; Minetta Lane Theater; Westbeth Center; New Ohio; The Public Theater; Joe’s Pub; Ars Nova; Axis Theater; The Duplex; Cornelia Street Café; Peridance; Martha Graham Dance Studio; Soho Playhouse; The Greene Space (WNYC Radio); Tenri Cultural Institute; New York Studio School of Drawing, Painting and Sculpture; Lucille Lortel Theater; Village Vanguard; Institutional theaters of NYU and The New School, among others. While we have a vibrant arts and culture scene in our area, we continue to be concerned about the impact on the downtown arts scene due to the closure of so many of the district’s Off-Broadway and small theaters and other cultural spaces. The main causes are the exponential increase in rents and ongoing funding challenges faced by non-profits. Some years ago, we supported a proposal to use tax incentives that would encourage landlords to retain live performance space. In addition, CB2 strongly supports funding for the arts both in our area and citywide, and increased arts education in public schools, as a growing body of studies presents compelling evidence connecting student learning in the arts to a wide array of academic and social benefits. Namely, these various studies continue to indicate that the arts help to improve visual analysis skills and critical judgments, inspire creativity and improve motivation, collaboration, attitudes and attendance. B. Arts Advocacy Advocating for arts organizations and artists located within CB2 and for those that produce, program or present arts and culture within CB2 has been, and remains, a top priority for our board. For one, our committee has a history of writing resolutions and letters of support for non-profit arts organizations located within our district that are seeking funding or restoration of funding from grant organizations and city agencies. We were also the first community board City-wide to write a letter of support for New York City’s first comprehensive cultural plan. In addition, we speak out against entities and agencies that seek to utilize our local parks and public spaces for arts- related projects that do not have wide community support, while strongly supporting public arts projects that are in alignment with the spirit of our community and neighborhoods. We also strive to foster connections amongst arts organizations located within our district to forge stronger cultural alliances. Finally, as is widely known, CB2 has historically been the home of a wide array of talented artists and, as such, our committee remains dedicated to advocating that the work of these local artists is a part of planned arts programming within our district whenever possible.
Needs for Library Services
We are happy that long-awaited renovations and upgrades to the Jefferson Market Library are under way. On that note, we also think it is time for a master plan to renovate the Hudson Park branch to make its amenities more available. It is an amazing, albeit, somewhat inaccessible facility that has great potential if it was more readily used
by the community-at-large. Finally, we are continue to be concerned that budget cuts have resulted in a reduction in staff and in the hours of operation at the libraries in our district. These reductions impact young children and the elderly most of all. We continue to request that additional funds be allocated to keep the libraries and their community rooms open for as many hours as possible. We also ask that the New York Public Library provide a dedicated staff to create special youth programming.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/20
DPR
Provide a new or
Allocate funds for the permanent preservation
expanded park or
of the Elizabeth St. Garden, in its entirety, on
playground
land owned by NYC DCAS, on a through lot on
Elizabeth and Mott Sts., between Prince and
Spring Sts. CB2 urges DCAS to transfer
jurisdiction over this lot to the Parks Dept.
without further delay. The neighborhood
around Elizabeth St. Garden lacks open space.
Little Italy and SoHo account for 23% of CB 2's
population but have only 3% of its open space,
virtually 100% paved, for an open space ratio of
only 0.07 acres per 1,000 residents. the
Elizabeth St. Garden is located in the only
downtown Manhattan neighborhood that the
NYC Parks Department defines as “underserved”
by open space.
4/20
DPR
Enhance park safety
Allocate funds for resiliency efforts to shore up
through design
the west side of Community District 2 along the
interventions, e.g.
Hudson River Park. In the aftermath of
better lighting
Hurricane Sandy, it became clear that the
(Capital)
Hudson River waterfront was dangerously
vulnerable. After making this request last year,
the agency response was that further study of
the request was needed. We would like to know
if any study has been done and, if so, what were
the findings and recommendations.
5/20
BPL
Create a new, or
Allocate funds for Hudson Park Library to create
66 Leroy
renovate or upgrade
better accessibility for disabled persons and
Street
an existing public
strollers, including the installation of an
library
elevator, “in order to be in compliance with the
NYPL's accessibility statement that ‘everyone is
welcome and has access to the full range of
information, services and programs that are
offered in our neighborhood branches.’”
7/20
DPR
Reconstruct or
Allocate funds for the complete renovation of
upgrade a park or
the Mercer Playground. The project to redesign
playground
and renovate this space is underway and most,
though probably not all required funding has
been pledged by NYU, as the budget is
anticipated to be higher than the pledged
amount, so CB2 requests that funds be allocated
to complete this project.
8/20
DPR
Reconstruct or
Allocate funds for the complete renovation of
upgrade a park or
Vesuvio Playground. the number of children
playground
using Vesuvio Playground continues to grow.
The current design was completed in 2006 and
was not really adequate to meet the needs of
the surrounding community even at the time of
opening. Further, the current design does not
maximize the possibilities in the envelope of the
square footage available to the public and much
of it is worn down and not functioning.
10/20
DPR
Reconstruct or
Allocate funds for the complete renovation the
upgrade a park or
Tony Dapolito Recreation Center. The Dapolito
playground
Center is a hub of activity and is well-used by
young and old alike. Rather than partial
measures to address recurring problems,
Community Board 2 requests that funds be
allocated to repair, renovate and re-imagine
uses for the center.
11/20
DCLA
Renovate or
Allocate funds to Judson Memorial Church
upgrade an existing
nonsectarian nonprofit affiliate (in formation) to
cultural facility
replace aging and overused lift with new
elevator to promote ADA accessibility to 2nd &
3rd floor program spaces. Judson Memorial
Church hosts a vast array of nonsectarian
events, including a large number of arts-related
events, in its main building. For the past few
years, the lift which provides ADA access to the
second floor has been overused and is often not
functioning. We are requesting funds to replace
the aging lift with a new elevator, so the
community-at-large will continue to be able to
use the facilities that Judson generously makes
available.
17/20
DPR
Reconstruct or
Allocate funds for repair needs at JJ Walker
upgrade a park or
courts and park.
playground
18/20
DPR
Reconstruct or
Allocate funds to install an irrigation system to
Gansevoort
upgrade a park or
the planted area in Seravalli Playground.
Street,
playground
Manhattan,
New York, NY
19/20
DPR
Reconstruct or
Allocate funds for Horatio Greenstreet wall (at
upgrade a park or
West 4th and 8th Avenue) to have the wall
playground
removed and have the garden match the design
of the one on the east side of 8th Avenue and
Jane Street
20/20 DPR Reconstruct or
upgrade a parks facility
Allocate funds for the update and renovation of Minetta Playground. This very popular playground has become worn down over the years and suffers from an ongoing rat infestation problem.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/44
OMB
Other community
Allocate additional funding to community
board facilities and
boards by baselining the extra allocations that
staff requests
the City Council has approved for community
boards in the past two fiscal years. In order to
facilitate stability and long-term planning, it
would be helpful to baseline the money that the
City Council has allocated to community boards
the past two years.
28/44
DPR
Improve the
Allocate funds for staffing of gates and
quality/staffing of
expanded hours at Jefferson Market Garden.
existing programs
This garden is one of the truly special gems in
offered in parks or
CD2. The City should increase funding to it so its
recreational centers
hours can be increased and the garden can be
enjoyed by more residents in our district.
29/44
DPR
Improve the quality
Allocate funding for Washington Square
of programs offered
Association Music Fund. The Washington square
in parks or
Park Music Festival has become a popular and
recreational centers
beloved annual event. The Parks Department
should allocate additional funding to ensure
that is continues to enhance the Washington
Square Park experience.
31/44
DPR
Enhance park safety
Allocate funds for replace the fence at the Time
through design
Landscape and re-think the area completely.
interventions, e.g.
The fence surrounding this space is easily
better lighting
transgressed and intruders frequently do so.
(Expense)
33/44
DPR
Improve trash
Allocate funds for more frequent trash removal,
removal and
and/or for larger-capacity, sanitary, trash bins in
cleanliness
Parks.
36/44 DPR Provide more athletic programming (i.e. league, aquatic)
Allocate funds to increase the number of Learn to Swim programs. Learn to Swim offerings for young children especially are very limited in the neighborhood and would be very popular if offered in a heated and indoor pool at Vesuvio. EVERYONE NEEDS TO KNOW HOW TO SWIM!
image
37/44 DCLA Other cultural
facilities and resources requests (Expense)
Allocate funds to increase arts and cultural programs for CB2M community centers, such as Greenwich House, the LGBT Community Center, Center on the Square Neighborhood Senior Center and Our Lady of Pompeii Senior Center.
image
38/44 DPR Plant new street
trees
Allocate funds to plant new street trees throughout Community District 2 and to examine and assess all tree guards. Trees are very important to the quality of life along our heavily trafficked streets. Many trees have died over the years and have not been replaced. This causes trip hazards to pedestrians and creates an unmanaged appearance. Property owners eventually remove the pits causing the loss of a valuable tree location and an additional cost to the City when the tree is replanted. Regarding tree guards, inconsistent upkeep has also led to dangerous led to dangerous situations for pedestrians and abuse of the trees.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority Agency Request Explanation Location
image
2/44 Other Other expense
budget request
Allocate funds to hire additional DCA inspectors to work nights and weekends to conduct enforcement and compliance of sidewalk café regulations. A major weakness in the enforcement of the sidewalk cafe rules by the Department of Consumer Affairs is the lack of inspectors working regular shifts on the weekends and at night when many violations occur. These are peak sidewalk cafe times and it is imperative that DCA has inspectors in the field at these times. Many of the complaints we receive regarding sidewalk cafes pertain to illegal activity at these times.
image
9/44 Other Other expense
budget request
Allocate funds to enable the Street Activity Permit Office (SAPO) to conduct a study on the effects that full street closures for commercial events have on neighboring businesses and residents. Community Board 2 remains disturbed by the endless proliferation of promotional and commercial events, some permitted and some not, which are occurring regularly in SoHo and, to a lesser extent, in NoHo. These events clog sidewalks and streets and often result in chaotic street scenes costing the City money and resources as it struggles to bring order to the mayhem. Residents are inconvenienced and neighboring businesses are hurt as temporary “pop-up” shops commandeer the sidewalks, close streets and often blast music that illegally impacts the quality of life of the neighbors.
image
10/44
Other
Other expense
Allocate funds to hire additional Landmarks
budget request
enforcement officers and staff to survey
landmark districts to identify properties that
have been altered without review and
permission of the Commission and the
processing of notices of violation in a timely
manner. Changes without certificates of
appropriateness are frequent. The board, the
landmarks committee, and the residents of the
neighborhood are vigilant in documenting work
in progress without permission. The Commission
does not have staff who survey the districts for
violations of this type. They only respond to
complaints.
13/44
Other
Other expense
Allocate funds to enable the Street Activity
budget request
Permit Office (SAPO) to conduct enforcement
and compliance of street activity permits. There
has been an explosion in the number of street
events receiving permits from SAPO or
operating illegally without required permits. The
local precincts have not been able to keep up
with the proliferation of these events nor do
they always have the requisite familiarity with
what is permitted. SAPO needs funding to hire
additional staff dedicated to monitoring these
street events and noting violations when they
occur.
14/44
Other
Other expense
Allocate funds to enable the Mayor's Office of
budget request
Media and Entertainment (MOME) to conduct
enforcement and compliance of film and
television permits. As the number of film shoots
in CD2 continues to proliferate, as does the
number of complaints we receive from our
residents and businesses. We feel strongly that
MOME needs to have enforcement staff that
tracks film shoots in real time and proactively to
ensure that all permits are being adhered to.
15/44
Other
Other expense
Allocate funds for the DSNY to study the
budget request
quantity and condition of trash containers,
evaluate pick-up schedules and adjust them as
necessary, and improve trash removal by
providing more frequent litter basket collection.
16/44
Other
Other expense
Allocate funds for effective rat control
budget request
throughout Community District 2 parks. Despite
efforts by the Department of Parks and
Recreation to address the problem of rat
infestation, the CB2 office constantly receives
complaints about rats in Washington Square
Park and the parks along Avenue of the
Americas (Minetta Triangle, Minetta
Playground, and Golden Swan). We are
requesting additional resources targeting it and
note that special focus should be paid to rat
burrows and tunneling in and around trees
because such damage to the root base is
causing trees to lean and eventually damaged
trees have to be removed because of the hazard
of them falling.
18/44
Other
Other expense
Allocate funds from DFTA to implement
budget request
suggested improvements recommended by the
NYC Comptroller to address problems related to
retroactive contracts. One threat to social
service agencies is the pace of the City’s
fulfillment of city contracts. Social services
providers are compelled to advance funding to
provide services, while the City takes as long as
a year to reimburse these expenses. This
provides cash flow problems for our providers,
increasing the cost of debt service produced by
credit lines, and threatening the very existence
of providers working at small-scale. We urge the
City to improve procurement systems to shorten
the time required to register contracts.
19/44
Other
Other expense
Allocate additional funds from DFTA to cover
budget request
overhead reimbursements for Greenwich House.
Greenwich House works mostly under the
constraint of government contracts, which can
be inflexible, byzantine in their stipulations, and
out-of-step with current costs. The result is that
Greenwich House’s programs are unable to
provide all that our curious, artistic,
intellectually vibrant seniors desire. Contract
reimbursements have also failed to compensate
for inflation, placing increased strain on
Greenwich House’s budget.
20/44
Other
Other expense
Allocate funds to increase staffing levels so the
budget request
Department of Buildings can monitor approved
projects during and after construction to ensure
that the work conforms to the approved
applications
23/44
Other
Other expense
Allocate funds to DOE for teacher training and
budget request
reading and writing curricula that use the
Orton-Gillinham approach. CB 2 supports
funding for comprehensive early screening,
curriculum, teacher training, programs and
schools to support and teach children with
dyslexia and language-based learning
disabilities using research-based screeners and
programs that use the Orton-Gillingham
approach.
25/44
Other
Other expense
Allocate funds to the Health & Hospitals
budget request
Corporation for a follow-up Community Health
Assessment to examine the success of the Lenox
Hill Greenwich Village stand-alone emergency
department model to understand the impact of
the hospital’s closing; and to survey the general
experience of accessing medical services.
26/44
Other
Other expense
Allocate funding from the Parks Department for
budget request
the Washington Square Conservancy
Community Arts Grant program.
35/44
Other
Other expense
Allocate additional funding from DYCD to The
budget request
Door so it can continue and more effectively
deliver services to its target population.
Thousands of LGBTQ youth find our
neighborhood more accepting than most, and
many need help with HIV and other problems
that they are unable or unwilling to secure in
their home neighborhoods. In addition,
educational and vocational needs are often
unmet, resulting in hostility and distress among
the youth as well as our residents. Increased
support for groups that help these youth is
needed. Family Therapy Intervention Pilot.
40/44
Other
Other expense
Allocate increased funding from Small Business
budget request
Services for Hudson Square BID's new public art
initiative Hudson Square Canvas and Village
Alliance’s public art commissions.
41/44
Other
Other expense
Allocate funds from the Parks Department for a
budget request
re-imagining of the Playground of the Americas.
This often overlooked and underused
playground needs a redesign to make it more
attractive to the children in Community District
2.
42/44
Other
Other expense
Allocate funds from the Parks department to
budget request
add benches at Minetta Triangle Park.
43/44 Other Other expense
budget request
Allocate funds from the Parks Department to add benches at Golden Swan Park.
image
44/44 Other Other expense
budget request
Allocate funds from DOT to install 3-hour metered commercial parking on Crosby St. btw. Spring and Prince Sts.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority Agency Request Explanation Location
image
1/20 DPR Provide a new or
expanded park or playground
Allocate funds for the permanent preservation of the Elizabeth St. Garden, in its entirety, on land owned by NYC DCAS, on a through lot on Elizabeth and Mott Sts., between Prince and Spring Sts. CB2 urges DCAS to transfer jurisdiction over this lot to the Parks Dept. without further delay. The neighborhood around Elizabeth St. Garden lacks open space. Little Italy and SoHo account for 23% of CB 2's population but have only 3% of its open space, virtually 100% paved, for an open space ratio of only 0.07 acres per 1,000 residents. the Elizabeth St. Garden is located in the only downtown Manhattan neighborhood that the NYC Parks Department defines as “underserved” by open space.
image
2/20 SCA Provide a new or
expand an existing elementary school
Allocate funds for the 100,000 square foot Bleecker Street School. As part of the New York University 2012 up-zoning, NYU’s key community giveback was the option to build the Bleecker School, a 100,000 square foot public school that would serve approximately 600 students. If the Bleecker School is not built, 100,000 square feet of school space reverts to NYU for university use. If the Bleecker School option expires on December 31, 2021, $65+ million in value transfers from NYC taxpayers to NYU, based on the average price per buildable square foot in Manhattan and arguably higher, due to the lack of vacant land in Greenwich Village. P
image
3/20
NYCTA
Improve
Allocate funds to refurbish walls, floors and
accessibility of
ceilings in the West 4th Street subway station
transit
and add full disabled access by elevator at the
infrastructure, by
northern end of the station. This station, the
providing elevators,
ninth busiest in the City and a major hub for
escalators, etc.
seven subway lines, suffers from peeling walls,
leaky ceilings, and broken wall tiles. These
conditions not only affect local and transient
users but also have negative impacts on
Greenwich Village's role as an important center
of business, tourism and major institutions and
needs to be quickly addressed by the MTA's
Station Renewal Program.
4/20
DPR
Enhance park safety
Allocate funds for resiliency efforts to shore up
through design
the west side of Community District 2 along the
interventions, e.g.
Hudson River Park. In the aftermath of
better lighting
Hurricane Sandy, it became clear that the
(Capital)
Hudson River waterfront was dangerously
vulnerable. After making this request last year,
the agency response was that further study of
the request was needed. We would like to know
if any study has been done and, if so, what were
the findings and recommendations.
5/20
BPL
Create a new, or
Allocate funds for Hudson Park Library to create
66 Leroy
renovate or upgrade
better accessibility for disabled persons and
Street
an existing public
strollers, including the installation of an
library
elevator, “in order to be in compliance with the
NYPL's accessibility statement that ‘everyone is
welcome and has access to the full range of
information, services and programs that are
offered in our neighborhood branches.’”
6/20
DOT
Roadway
Allocate funds to reconstruct Clarkson St. from
Clarkson
maintenance (i.e.
West St. to Greenwich St. including repair &
Street
pothole repair,
replacement of Belgian blocks and installation
Greenwich
resurfacing, trench
of a granite bicycle lane. The Belgian block
Street West
restoration, etc.)
street bed on Clarkson St. bet. West and
Street
Greenwich Sts. is in great need of repair with
loose, broken, scattered and missing blocks,
large uncovered spaces, exposed manholes, and
deep ridges, posing a major hazard to
pedestrians, those in wheelchairs and with
strollers, bicyclists and drivers. Bicyclists opt to
use the sidewalk instead, endangering people
walking there. A granite strip bike lane will
provide comfortable, direct bike access and keep
bike riders off the sidewalk.
7/20
DPR
Reconstruct or
Allocate funds for the complete renovation of
upgrade a park or
the Mercer Playground. The project to redesign
playground
and renovate this space is underway and most,
though probably not all required funding has
been pledged by NYU, as the budget is
anticipated to be higher than the pledged
amount, so CB2 requests that funds be allocated
to complete this project.
8/20
DPR
Reconstruct or
Allocate funds for the complete renovation of
upgrade a park or
Vesuvio Playground. the number of children
playground
using Vesuvio Playground continues to grow.
The current design was completed in 2006 and
was not really adequate to meet the needs of
the surrounding community even at the time of
opening. Further, the current design does not
maximize the possibilities in the envelope of the
square footage available to the public and much
of it is worn down and not functioning.
9/20
SCA
Provide technology
Allocate funds for technology improvements,
upgrade
including smartboards, laptops and computers
for PS 3, PS 130, MS 297, P751, Broome Street
Academy and City-As-School High School. CB 2
supports additional funding for technology at PS
3, PS 130,MS 297, P751, Broome Street
Academy and City-As-School High to ensure that
all children have access to technology, a critical
equity issue in education.
10/20
DPR
Reconstruct or
Allocate funds for the complete renovation the
upgrade a park or
Tony Dapolito Recreation Center. The Dapolito
playground
Center is a hub of activity and is well-used by
young and old alike. Rather than partial
measures to address recurring problems,
Community Board 2 requests that funds be
allocated to repair, renovate and re-imagine
uses for the center.
11/20
DCLA
Renovate or
Allocate funds to Judson Memorial Church
upgrade an existing
nonsectarian nonprofit affiliate (in formation) to
cultural facility
replace aging and overused lift with new
elevator to promote ADA accessibility to 2nd &
3rd floor program spaces. Judson Memorial
Church hosts a vast array of nonsectarian
events, including a large number of arts-related
events, in its main building. For the past few
years, the lift which provides ADA access to the
second floor has been overused and is often not
functioning. We are requesting funds to replace
the aging lift with a new elevator, so the
community-at-large will continue to be able to
use the facilities that Judson generously makes
available.
12/20
DOT
Reconstruct streets
Allocate funds to install a granite strip bicycle
Morton
lane on Morton Street between West Street and
Street West
Washington Street. The Belgian block surface is
Street
unsuitable for bikes, resulting in cyclists riding
Washington
on the sidewalks, hazardous for pedestrians.
Street
Morton Street is a main thoroughfare from the
Hudson River Park (West St) going east, calling
for an eastbound bicycle lane, granite between
West and Washington Streets and striped
eastward from Washington. The new 75 Morton
Street school makes it even more urgent to keep
bicycles safely off the sidewalks and provide for
safe bicycling for all.
13/20
SCA
Renovate or
Allocate funds to P.S. 3 for gymateria dividers to
upgrade an
increase flexibility and use, library renovation
elementary school
and physical fitness, including playground
equipment upgrade and enhancements to the
roof playground.
14/20
SCA
Renovate or
Allocate funds to build STEAM and Literacy
upgrade a high
programs including a Wet Lab, Maker Space,
school
Literacy Lab and Library / Media Center as well
as to add water bottle refilling stations at City-
as-School High School.
15/20
SCA
Renovate or
Allocate funds for a library at Broome Street
upgrade a high
Academy, which also would be available to The
school
Door members, as well as a cafeteria upgrade.
16/20
DOT
Roadway
Allocate funds to repair and replace Belgian
maintenance (i.e.
blocks on Bond St., between Broadway and the
pothole repair,
Bowery, on Wooster St. between Houston and
resurfacing, trench
Canal Streets., on Gansevoort and Little West
restoration, etc.)
12th Streets between 9A and 8th Ave., and on
14th St. between 9th Ave. and Route 9A. Belgian
Blocks are either badly damaged, missing or
both and need to be restored and/or replaced.
In some cases the structural base is so
deteriorated, reconstruction is needed. Current
poor condition is hazardous to pedestrians and
a blight to the historic districts. The restoration
of these streets with Belgian blocks is essential
in keeping with the nature of these historically
important areas
17/20
DPR
Reconstruct or
Allocate funds for repair needs at JJ Walker
upgrade a park or
courts and park.
playground
18/20
DPR
Reconstruct or
Allocate funds to install an irrigation system to
Gansevoort
upgrade a park or
the planted area in Seravalli Playground.
Street,
playground
Manhattan,
New York, NY
19/20
DPR
Reconstruct or
Allocate funds for Horatio Greenstreet wall (at
upgrade a park or
West 4th and 8th Avenue) to have the wall
playground
removed and have the garden match the design
of the one on the east side of 8th Avenue and
Jane Street
20/20
DPR
Reconstruct or
Allocate funds for the update and renovation of
upgrade a parks
Minetta Playground. This very popular
facility
playground has become worn down over the
years and suffers from an ongoing rat
infestation problem.
CS
DOT
Improve traffic and
Allocate funds for traffic safety measures, such
pedestrian safety,
as road markings and Stop signs, on Bedford St.
including traffic
between 6th Ave. (Ave. of the Americas) and
calming (Capital)
Carmine St. Speeding vehicles, sharp curves and
varied lane sizes with abrupt turns and changes,
an unusually wide entrance from 6th Ave.,
obscured sight lines (in particular at Downing
St.), insufficient signage and markings make
Bedford St. exceptionally hazardous for the
many pedestrians using these neighborhood
streets as well as for motorists.
CS DOT Improve traffic and pedestrian safety, including traffic calming (Capital)
Allocate funds for parking and intersection alignment improvements, including sidewalk extensions, high visibility crosswalks and signalization changes on Greenwich Ave. from Bank St. to W. 12th St. and on W. 12th St. from Greenwich Ave. to the midblock entrance of the new AIDS Memorial Park at St. Vincent's Triangle. Broad, oddly angled intersections, long, badly marked crosswalks (or none), shortage of traffic controls and wide street beds endanger the increasing number of pedestrians crossing on Greenwich Ave. between W. 11th and W. 12th Sts. and on W. 12th St. between Greenwich and 7th Aves., heading to the new park, the AIDS memorial, the subway and to school, particularly hazardous at Bank St. and at the intersection of Greenwich Ave. and W. 12th St.
image
CS DOT Improve traffic and pedestrian safety, including traffic calming (Capital)
Allocate funds to extend the corner sidewalk extension on West St, at the northeast corner of Houston and West Sts., to widen the median on West St. at Houston, and change the traffic light signal to phasing. Numerous cars and trucks turn right rapidly from Houston St. onto West St. going north, while vehicles turn east from West onto Houston, all at the same time pedestrians are crossing West St., endangered by the fast- turning traffic and often getting stuck in the narrow West St. median. A separate green light phase for pedestrians and shortened crossings are needed to safeguard the many people traversing West St. to Pier 40 and the Hudson River Park. NYC DOT is urged to work together with NYS DOT on signalization and geometric improvements.
image
CS
DOT
Improve traffic and
pedestrian safety, including traffic calming (Capital)
Allocate funds to study and institute safety
improvements at 7th Ave. S., Carmine, Varick and Clarkson Sts. intersection, including neckdowns, traffic signal changes and repositioning, daylighting, lane reconfiguration, and other geometric improvements. Excessively long pedestrian crossings, poor visibility, motorists driving on the sidewalk, gridlock, blocked crosswalks, hazardous turning movements, intermittent speeding, irregularly angled design and chaotic Holland Tunnel- bound traffic create exceptionally dangerous conditions for the many pedestrians (residential, working, tourists/seniors and children) using this area. A promised improvement plan presentation is awaited.
7th Avenue
South Carmine Street Clarkson Street
CS
DOT
Improve traffic and pedestrian safety, including traffic calming (Capital)
Allocate funds for the concrete widening of the subway triangle on 7th Ave. S. between Grove and Christopher Streets and on Grove St. between W. 4th St and 7th Ave. S. Different turning and traffic patterns call for safer pedestrian crossings, while the new bicycle path configuration on 7th Ave. S. has introduced a dangerous conflict for people coming from the subway who expect they can head for the 7th Ave. S. pedestrian island to cross the street, not realizing their vulnerability to bikes. The Grove St. curb edge doesn't align with the southern tip of the 7th Ave. S. island, allowing for a curbside No Parking lane leading directly into the island's protruding southern edge, particularly dangerous for both drivers and pedestrians in the snow with no visibility to avoid the island edge.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/44
DFTA
Allocate funds for
These programs result in happier and healthier
outreach services to
seniors, as well as save hospital and nursing
homebound older
home costs. Current cuts have short-changed
adults and for
the needs of our elderly. Reorganization and
programs that allow
strategic prioritizing of city/state/federal
the elderly to age in
agencies may be needed.
place
2/44
Other
Other expense
Allocate funds to hire additional DCA inspectors
budget request
to work nights and weekends to conduct
enforcement and compliance of sidewalk café
regulations. A major weakness in the
enforcement of the sidewalk cafe rules by the
Department of Consumer Affairs is the lack of
inspectors working regular shifts on the
weekends and at night when many violations
occur. These are peak sidewalk cafe times and it
is imperative that DCA has inspectors in the field
at these times. Many of the complaints we
receive regarding sidewalk cafes pertain to
illegal activity at these times.
3/44
DOHMH
Other programs to
Allocate funds to provide outreach and
address public
treatment that targets individuals who are
health issues
using drugs on NYC streets. We support the
requests
work of Greenwich House as our local provider
of needed substance abuse treatment to New
Yorkers within our district and without.
However, we also support DOHMH initiating an
outreach program that targets individuals
openly using drugs on public streets, so they can
get the help they need.
4/44
DHS
Expand street
Allocate additional funds for outreach and for
outreach
improved access to existing services for our
homeless population. While we recognize the
difficulty in encouraging street homeless to
accept shelter and services, we also know that
the more engagement there is with providers,
the more successful their efforts are likely to be.
Strong funding is necessary to maintain a robust
presence of outreach workers in our district.
5/44
DSNY
Provide more on-
Allocate funds for the placement of additional
street trash cans
litter baskets and for additional basket service.
and recycling
Too often, corner litter baskets in pedestrian
containers
heavy areas of CD2 are overflowing with debris.
We are requesting additional resources be
allocated to remedy this situation.
6/44
OMB
Other community
Allocate additional funding to community
board facilities and
boards by baselining the extra allocations that
staff requests
the City Council has approved for community
boards in the past two fiscal years. In order to
facilitate stability and long-term planning, it
would be helpful to baseline the money that the
City Council has allocated to community boards
the past two years.
7/44
DOT
Improve traffic and
Allocate funds for traffic safety improvements at
pedestrian safety,
Cooper Sq. Plaza crossing (4th Ave. to Bowery at
including traffic
E. 6th St.) including speed humps, signage,
calming (Expense)
signalization changes. The roadway winding
around and through Cooper Sq. Plaza bet 4th
Avenue at E. 7th St. and the Bowery at E. 6th St.
presents numerous crossing hazards to
pedestrians and potential vehicular conflicts,
such as buses, taxis, livery vehicles, trucks and
private cars entering from the Bowery at
excessive speeds, obstruction of drivers' visibility
at the 4th Ave. bend in the roadway, lack of
coordinated traffic light signals at the Bowery
with a constant "Walk" light misleading
pedestrians, and pedestrians crossing every
which way, for lack of information on where to
cross.
8/44
DOE
Provide more funds
Allocate funds for a washing machine and dryer
for teaching
to give students access at MS 297 and City-as-
resources such as
School High School. Because students who lack
classroom material
access to laundry facilities tend to have higher
absentee rates, CB 2 supports funding the
installation of washers and dryers at schools
that serve students in temporary or transitional
housing.
9/44 Other Other expense
budget request
Allocate funds to enable the Street Activity Permit Office (SAPO) to conduct a study on the effects that full street closures for commercial events have on neighboring businesses and residents. Community Board 2 remains disturbed by the endless proliferation of promotional and commercial events, some permitted and some not, which are occurring regularly in SoHo and, to a lesser extent, in NoHo. These events clog sidewalks and streets and often result in chaotic street scenes costing the City money and resources as it struggles to bring order to the mayhem. Residents are inconvenienced and neighboring businesses are hurt as temporary “pop-up” shops commandeer the sidewalks, close streets and often blast music that illegally impacts the quality of life of the neighbors.
image
10/44 Other Other expense
budget request
Allocate funds to hire additional Landmarks enforcement officers and staff to survey landmark districts to identify properties that have been altered without review and permission of the Commission and the processing of notices of violation in a timely manner. Changes without certificates of appropriateness are frequent. The board, the landmarks committee, and the residents of the neighborhood are vigilant in documenting work in progress without permission. The Commission does not have staff who survey the districts for violations of this type. They only respond to complaints.
image
11/44 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
Allocate funds to reduce speeding and directional impacts at the pedestrian crossing on the east side of W. 8th St. at 6th Ave. and at the intersection of W, 8th St., 6th and Greenwich Aves. We propose considering solutions such as installation of a traffic diverter on the northern lane of Greenwich Ave. at 6th Ave. and/or continuing the 6th Ave. protected bike lane south with an extended median. The exceptionally wide open and irregularly angled intersection creates confusion, causes turning conflicts, facilitates speeding and hinders visibility, putting pedestrians in grave danger, exemplified by the recent horrific pedestrian fatality.
image
12/44
DOE
Other educational
Allocate funds for curriculum development and
programs requests
teacher training for Culturally Responsive –
Sustaining Education in our district’s public
schools. CB 2 supports funding for curriculum
development and teacher training for CB 2
areas schools for Culturally Responsive –
Sustaining Education in alignment with the
Culturally Responsive - Sustaining Education
(CR-SE) Framework that the NYS Education
Department issued in March 2019 and the
definition of Culturally Responsive - Sustaining
Education (CR-SE) that the DOE approved in July
2019.
13/44
Other
Other expense
Allocate funds to enable the Street Activity
budget request
Permit Office (SAPO) to conduct enforcement
and compliance of street activity permits. There
has been an explosion in the number of street
events receiving permits from SAPO or
operating illegally without required permits. The
local precincts have not been able to keep up
with the proliferation of these events nor do
they always have the requisite familiarity with
what is permitted. SAPO needs funding to hire
additional staff dedicated to monitoring these
street events and noting violations when they
occur.
14/44
Other
Other expense
Allocate funds to enable the Mayor's Office of
budget request
Media and Entertainment (MOME) to conduct
enforcement and compliance of film and
television permits. As the number of film shoots
in CD2 continues to proliferate, as does the
number of complaints we receive from our
residents and businesses. We feel strongly that
MOME needs to have enforcement staff that
tracks film shoots in real time and proactively to
ensure that all permits are being adhered to.
15/44
Other
Other expense
Allocate funds for the DSNY to study the
budget request
quantity and condition of trash containers,
evaluate pick-up schedules and adjust them as
necessary, and improve trash removal by
providing more frequent litter basket collection.
16/44 Other Other expense
budget request
Allocate funds for effective rat control throughout Community District 2 parks. Despite efforts by the Department of Parks and Recreation to address the problem of rat infestation, the CB2 office constantly receives complaints about rats in Washington Square Park and the parks along Avenue of the Americas (Minetta Triangle, Minetta Playground, and Golden Swan). We are requesting additional resources targeting it and note that special focus should be paid to rat burrows and tunneling in and around trees because such damage to the root base is causing trees to lean and eventually damaged trees have to be removed because of the hazard of them falling.
image
17/44 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
Allocate funds for traffic safety improvements at the intersection of Waverly Pl., Christopher and Grove Sts. (Stonewall Natl Monument area), including neckdowns, sidewalk extensions, daylighting, stop signs, improved directional signage. Lack of visibility, wide crossings, illegal parking, and pedestrians crossing in multiple paths create danger and confusion for both pedestrians and drivers at this complex, irregular intersection. This area now encompasses the Stonewall National Monument, attracting increased crowds, pedestrian activity, tour buses and other vehicular movement, calling for swift attention to improving safety here.
image
18/44 Other Other expense
budget request
Allocate funds from DFTA to implement suggested improvements recommended by the NYC Comptroller to address problems related to retroactive contracts. One threat to social service agencies is the pace of the City’s fulfillment of city contracts. Social services providers are compelled to advance funding to provide services, while the City takes as long as a year to reimburse these expenses. This provides cash flow problems for our providers, increasing the cost of debt service produced by credit lines, and threatening the very existence of providers working at small-scale. We urge the City to improve procurement systems to shorten the time required to register contracts.
image
19/44
Other
Other expense
Allocate additional funds from DFTA to cover
budget request
overhead reimbursements for Greenwich House.
Greenwich House works mostly under the
constraint of government contracts, which can
be inflexible, byzantine in their stipulations, and
out-of-step with current costs. The result is that
Greenwich House’s programs are unable to
provide all that our curious, artistic,
intellectually vibrant seniors desire. Contract
reimbursements have also failed to compensate
for inflation, placing increased strain on
Greenwich House’s budget.
20/44
Other
Other expense
Allocate funds to increase staffing levels so the
budget request
Department of Buildings can monitor approved
projects during and after construction to ensure
that the work conforms to the approved
applications
21/44
DOT
Other expense
Allocate more resources for speed hump
traffic
inspections and installation. CB2 receives many
improvements
requests for speed humps, but because of lack
requests
of DOT resources, they typically take 2 or more
years to install. Sufficient resources are needed
to gather the data to address this need and
secure proper and timely installation, including
assemblage, signage, and markings so that
community needs are met more speedily.
22/44
DOT
Other expense
Allocate funds to install speed humps on Jane St.
traffic
between Greenwich and 8th Aves., on Spring St.
improvements
bet Mott and Elizabeth Sts, and on Perry St. bet.
requests
W. 4th St. and 7th Ave. S. Excessive speeding by
automobiles, taxis and trucks with many close
and hazardous calls threatens the safety of
pedestrians crossing the street, including many
children on their way to school and call for
speed humps to slow down the dangerous
traffic.
23/44
Other
Other expense
Allocate funds to DOE for teacher training and
budget request
reading and writing curricula that use the
Orton-Gillinham approach. CB 2 supports
funding for comprehensive early screening,
curriculum, teacher training, programs and
schools to support and teach children with
dyslexia and language-based learning
disabilities using research-based screeners and
programs that use the Orton-Gillingham
approach.
24/44
DOE
Other educational
Allocate and baseline additional funds for
programs requests
increased arts education, faculty and
classrooms in our district’s public schools based
on the CPI. Two recent studies, one by the NYC
Comptroller ("State of the Arts") and the other
by the Manhattan Borough President
("ArtsForward"), identified deficiencies in arts
programs in public schools. While some funds
were allocated in FY 2015, we ask the City to
baseline that and provide additional funding to
hire more dedicated arts faculty and provide
adequate infrastructure for arts education.
25/44
Other
Other expense
Allocate funds to the Health & Hospitals
budget request
Corporation for a follow-up Community Health
Assessment to examine the success of the Lenox
Hill Greenwich Village stand-alone emergency
department model to understand the impact of
the hospital’s closing; and to survey the general
experience of accessing medical services.
26/44
Other
Other expense
Allocate funding from the Parks Department for
budget request
the Washington Square Conservancy
Community Arts Grant program.
27/44
DOT
Improve traffic and
Allocate funds to reduce pedestrian/vehicular
pedestrian safety,
conflicts at the southwest side of Christopher St.
including traffic
and Greenwich Ave. Pedestrians crossing
calming (Expense)
Christopher St. are endangered by swift-turning
motor vehicles from Greenwich Ave., confusing
traffic signalization, and obscured visibility.
Traffic signal modifications, such as split phase
with a dedicated green pedestrian light or a
flashing arrow with delayed left turn, and
daylighting at the Greenwich Ave. s.w. corner
are needed.
28/44
DPR
Improve the
Allocate funds for staffing of gates and
quality/staffing of
expanded hours at Jefferson Market Garden.
existing programs
This garden is one of the truly special gems in
offered in parks or
CD2. The City should increase funding to it so its
recreational centers
hours can be increased and the garden can be
enjoyed by more residents in our district.
29/44
DPR
Improve the quality
Allocate funding for Washington Square
of programs offered
Association Music Fund. The Washington square
in parks or
Park Music Festival has become a popular and
recreational centers
beloved annual event. The Parks Department
should allocate additional funding to ensure
that is continues to enhance the Washington
Square Park experience.
30/44
DOT
Improve traffic and
Allocate funds to install split phase
pedestrian safety,
signalization, and bulb out plus daylight the
including traffic
northeast corner of West 13th St. and
calming (Expense)
Greenwich Ave.Speeding vehicles come west on
13th St. and turn north onto Greenwich Ave. at
the same time pedestrians are crossing
Greenwich there; the vehicles lack visibility of
both pedestrians (who have the Walk signal)
and the Walk signal itself, while also advancing
continuously without slowing down, enabled to
speed through because the turning radius is
exceptionally wide, closer to 180 degrees than a
true corner turning curve, seriously endangering
pedestrians.
31/44
DPR
Enhance park safety
Allocate funds for replace the fence at the Time
through design
Landscape and re-think the area completely.
interventions, e.g.
The fence surrounding this space is easily
better lighting
transgressed and intruders frequently do so.
(Expense)
32/44
DOT
Improve traffic and
Allocate funds to conduct a study of the blocks
pedestrian safety,
with and/or impacted by design changes related
including traffic
to dangerous traffic conditions on Jane St. btw.
calming (Expense)
Greenwich and 8th Aves. and at the W. 13th
St./Greenwich Ave./Horatio St. intersection,
including Jane btw. Greenwich and 8th Aves.,
Greenwich btw. 8th Ave. & Jane, Horatio btw.
W. 4th St. and 8th Ave. and W. 13th
approaching Greenwich Ave./Horatio St. Recent
design, operational and regulatory changes
related to increasing pedestrian safety at the
Mobil gas station at Horatio St. and 8th Ave.
have led to westbound traffic from W. 13th St.
having to turn either north or south on
Greenwich Ave. resulting in unforeseen
increases in vehicular activity and speeding on
Greenwich btw. W. 13th and W. 14th Sts. and on
Jane St. btw. Greenwich and 8th Aves.
33/44
DPR
Improve trash
Allocate funds for more frequent trash removal,
removal and
and/or for larger-capacity, sanitary, trash bins in
cleanliness
Parks.
34/44
DOT
Provide new traffic
Allocate funds to install louvers on traffic light
or pedestrian
at Carmine Street on Bedford Street. A traffic
signals
light at Carmine St. on Bedford St. which is one
block ahead of a hazardous crossing at Downing
St. exacerbates the danger crossing Downing as
drivers surge past it to catch the Carmine green
light. Louvers on the Carmine traffic light would
obscure the green signal, eliminating the
impetus for drivers to speed up past Downing
St.
35/44
Other
Other expense
Allocate additional funding from DYCD to The
budget request
Door so it can continue and more effectively
deliver services to its target population.
Thousands of LGBTQ youth find our
neighborhood more accepting than most, and
many need help with HIV and other problems
that they are unable or unwilling to secure in
their home neighborhoods. In addition,
educational and vocational needs are often
unmet, resulting in hostility and distress among
the youth as well as our residents. Increased
support for groups that help these youth is
needed. Family Therapy Intervention Pilot.
36/44
DPR
Provide more
Allocate funds to increase the number of Learn
athletic
to Swim programs. Learn to Swim offerings for
programming (i.e.
young children especially are very limited in the
league, aquatic)
neighborhood and would be very popular if
offered in a heated and indoor pool at Vesuvio.
EVERYONE NEEDS TO KNOW HOW TO SWIM!
37/44
DCLA
Other cultural
Allocate funds to increase arts and cultural
facilities and
programs for CB2M community centers, such as
resources requests
Greenwich House, the LGBT Community Center,
(Expense)
Center on the Square Neighborhood Senior
Center and Our Lady of Pompeii Senior Center.
38/44
DPR
Plant new street
Allocate funds to plant new street trees
trees
throughout Community District 2 and to
examine and assess all tree guards. Trees are
very important to the quality of life along our
heavily trafficked streets. Many trees have died
over the years and have not been replaced. This
causes trip hazards to pedestrians and creates
an unmanaged appearance. Property owners
eventually remove the pits causing the loss of a
valuable tree location and an additional cost to
the City when the tree is replanted. Regarding
tree guards, inconsistent upkeep has also led to
dangerous led to dangerous situations for
pedestrians and abuse of the trees.
39/44
DOT
Conduct traffic or
parking studies
Allocate funds to conduct a study on the
potential for installing a greenway on University Pl. from 14th St. to W. 4th St. where it would connect with Washington Sq. Park. University Pl. has been converted into a shared street btw.
13th and 14th streets and its direction reversed there, resulting in reduced vehicular traffic on University, which already is a quiet street oriented to community life. A greenway from 14th St. to Washington Sq. Park would create a calm, safe, comfortable and attractive neighborhood environment that further enhances the street's use and enjoyment.
40/44
Other
Other expense budget request
Allocate increased funding from Small Business Services for Hudson Square BID's new public art initiative Hudson Square Canvas and Village Alliance’s public art commissions.
41/44
Other
Other expense budget request
Allocate funds from the Parks Department for a re-imagining of the Playground of the Americas. This often overlooked and underused playground needs a redesign to make it more attractive to the children in Community District 2.
42/44
Other
Other expense budget request
Allocate funds from the Parks department to add benches at Minetta Triangle Park.
43/44
Other
Other expense budget request
Allocate funds from the Parks Department to add benches at Golden Swan Park.
44/44
Other
Other expense budget request
Allocate funds from DOT to install 3-hour metered commercial parking on Crosby St. btw. Spring and Prince Sts.

