- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 3 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1i-hU0XSiUztv-Ze7REulYf2FswwhC1mB/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1i-hU0XSiUztv-Ze7REulYf2FswwhC1mB/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'',
Manhattan Community District
3
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 3
image
Address: 59 East 4th Street Phone: (212) 533-5300
Email: mn03@cb.nyc.gov
Website: www.nyc.gov/cb3manhattan
Chair: Alysha Lewis-Coleman District Manager: Susan Stetzer
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 3 Manhattan (CB 3) spans the East Village, Lower East Side, and part of Chinatown. It is bounded by 14th Street to the north, the East River to the east, the Brooklyn Bridge to the south, and Fourth Avenue and the Bowery to the west, extending to Baxter and Pearl Streets south of Canal Street. This community is filled with a diversity of cultures, religions, incomes, and languages. Its character comes from its heritage as a historic and present day first stop for many immigrants. Community District 3 (CD 3) is one of the largest board districts and one of the most densely populated in New York City, with approximately 159,652 residents. Our residents are very proud of their historic and diverse neighborhood, however, the very characteristics that make this district unique also make it a challenging place to plan and ensure services for all residents and businesses.
CD 3 is changing in many ways, and a number of those changes have exacerbated existing challenges and presented new ones. There is dramatic income disparity in CD 3, and the district now has the fourth highest gap between the lowest- and highest-income households out of all districts in New York City, and it is growing. Luxury housing continues to be built in the district although many people within our community live on the edge of homelessness and economic survival. An estimated 23% of residents in CD 3 are living below poverty level, with approximately 36% of children under the age of 18 and 33% of seniors living below poverty level. This income inequality is tied to the escalating rate of gentrification in the district. Median asking rents in CD 3 have increased by 26% since 2010, while median household incomes have declined from $48,070 in 2010 to $40,340 in 2017. During this time period rent regulated units were regularly being lost annually to deregulation, however, between 2016 and 2017 the number of rent regulated units in the district grew from 18,062 to 18,283.
Proposals are in the pipeline for several hundred units of new market-rate housing in the district in the coming years, and an ever-growing number of bars, restaurants, and hotels continue to proliferate as other small businesses and arts organizations struggle to remain in place. All of this puts strain on the overburdened and aging transportation infrastructure in the area, effecting system performance as well as increasing congestion and jeopardizing the safety of our streets and sidewalks. While the City embarks on repairing this infrastructure—such as the Canarsie Tunnel repairs—CD 3 residents lose important transit options and must grapple with the temporary impacts of construction and traffic congestion.
The transformation of the district from one with significant retail diversity to an increasingly nightlife- and hotel- oriented district has resulted in a loss of independent businesses and a variety of retail options that serve local needs. This has resulted in a staggering amount of quality of life concerns and complaints throughout the area, and impacts small businesses, residents, and the large number of artists, arts organizations, and cultural organizations that are so meaningful to the community. Community-based organizations that provide essential services for residents continue to struggle to provide more services and fund themselves with fewer resources, while community healthcare and social service providers face similar challenges and residents are left to grapple with service reductions.
CD 3 is also a coastal community still recovering from Superstorm Sandy in 2012 and the area is increasingly vulnerable to future climate change impacts and extreme weather scenarios that affect the waterfront. The maintenance and viability of the many beloved and essential parks in the district remains a challenge, and their importance as a crucial community resource only grows in the face of these environmental issues.
Preventing the displacement of long-time residents and commercial tenants is a community priority. CB 3 has worked to maintain the livability of the area and improve quality of life for community members, focusing on the retention of its affordable housing stock and local businesses, its community-based organizations and arts institutions, improving environmental resiliency, and protecting the many community assets that may be threatened in the future, while also meeting the diverse and varied needs of new residents and businesses as the neighborhood changes.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 3
image
The three most pressing issues facing this Community Board are:
Affordable housing
CD 3 has the fourth highest gap between the lowest- and highest-income households out of all community districts in New York City. Market-rate housing continues to be built in the district while many community members are homeless, on the edge of homeless, and struggling with economic survival. Median asking rents in CD 3 have increased by 26% since 2010, while median household incomes have declined from $48,070 in 2010 to $40,340 in 2017. 36% of low-income renter households in CD 3 are spending more than half their monthly income on housing, and CD 3 was ranked by ANHD as having the second-highest risk factor for the loss of affordable housing and residential displacement among all Manhattan Community Districts. Affordable housing being built in the district is attached to proportionally larger amounts of market-rate housing, and most of the “affordable” units do not meet the needs of low-income residents and seniors living on fixed incomes. According to HPD’s Housing New York count, there were 839 units of new affordable housing construction starts in CD 3 between 2014 and 2019, with 25 percent targeted at households earning more than $76,880 per year, despite the median household income in the district being just $40,338
Senior services
CD 3 needs critically important investments to help older residents live healthier lives and more fulfilling lives as they age in place. In CD 3 there are 27,183 residents over the age of 65 and another 9,578 residents between the ages of 60-64. Together, they make up nearly 23% of CD 3's total population. Approximately 33% of seniors in the district live below the poverty line, 36% live alone, 46% live with a disability, 37% experience ambulatory difficulties. In addition to the challenges this presents, 59% of the seniors in CD 3 are foreign born, with many speaking a language other than English at home. This requires culturally and linguistically appropriate health and social services for a large senior population and a continuum of care that covers diverse cultural, health and wellness needs.
Homelessness
The Department of Homeless Services (DHS) Hope Count for Manhattan for 2018-2019 shows a two percent decrease from last year. However, this needs to be considered in light of a a 40 percent increase in the 2016—2017 Hope Count. Homelessness reminds a priority concern in CD 3 and requires continued funding and a variety of methods and strategies to address. Travelers, young homeless people who travel to destinations depending on the weather, continue to be the most difficult subset of the street homeless population to engage. This population often include instances of drug use and aggression. Sara D. Roosevelt Park has many homeless and drug dealers and users, an increase over previous years. Drug dealers target the homeless in parks and outside shelters. A current reported drug trend is mixing K2 with crack, based on conversations with Project Renewal security and Manhattan Outreach Consortium. Additionally, Tompkins Square Park during the day is a destination for street homeless and homeless who have nearby shelter beds. For the first time this past winter the CB 3 office and the offices of elected officials received reports of many homeless in the subways, particularly the F train stops at Second Ave and East Broadway and Delancey. The Hope Count for the current year shows a 23 percent increase in homelessness in the subways, which coincides with the increase seen in CD 3. CD 3 is home to over 15 shelters, and while some shelters provide necessary beds, they are in very old buildings that do not adequately provide safe and dignified housing.
NYPD reports that adult men do not want to accept beds in shelters as they do not feel safe. We also have reports from outreach workers that adult men wait until there is a safe haven bed available rather than accept a bed in an adult men’s shelter. There is an unresolved the problem with the increasing number of street homeless and homeless people needing to seek refuge in the subways. There is a need for more supportive housing in CD 3, and the standard approaches for outreach and engagement for services and shelter do not prove productive. This should include a harm reduction approach, working with all clients and providing Narcan, feminine hygiene products, sunscreen, etc. to people on the street, and reasonable accommodations to bring dogs into safe havens. DHS should be analyzing and trying new approaches to engage the subway homeless.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 3
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
Travelers, young homeless people who travel to destinations depending on the weather, continue to be the most difficult subset of the street homeless population to engage. This population often include instances of drug use and aggression. Manhattan Outreach Consortium (MOC) outreach teams are trying a harm reduction approach working with all clients and providing Narcan, feminine hygiene products, sunscreen, etc. to people on the street. There has also for the first time been success in requesting reasonable accommodation to bring dogs into safe havens, however, the dog needs to be an emotional support animal. This is an approach that should be considered to produce engagement with travelers as well as working with Harm Reduction for outreach. For the first time this past winter the CB 3 office and the offices of elected officials received reports of many homeless in the subways, particularly the F train stops at Second Ave and East Broadway and Delancey. The Hope Count for the current year shows a 23 percent increase in homelessness in the subways. BRC and Transit NCOs report that they are having some success in having people accept beds and services, but people seem to be more difficult to engage. Current methods of engagement include removing benches and decreasing footprint for homeless and having frequent check-ins that disturbs sleep, as a part of a broader campaign that has been proven successful in reducing homelessness and convincing clients to accept services and beds However the overall increase shows that although there is some success with individuals, this does not resolve the problem of an increasing number of homeless people needing to seek refuge in the subways. Standard approaches do not prove productive. DHS should be analyzing and trying new approaches to engage the subway homeless. CD 3 is home to over 15 shelters among the highest in the City. Most of these facilities are absorbed into the community without notice. CB 3 has identified priority issues in the area of shelters and support: • Project Renewal Third Street Men’s Shelter/Kenton Hall: DHS peace officers are still needed for the protection of the shelter residents and those on the block. • Catherine Street Shelter: The building is inadequate for use as a shelter. People are housed in classrooms without nearby toilets and no running water in the rooms. • In addition, there is a need for more supportive housing in CD 3.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
CD 3 needs critically important investments to help older residents live healthier lives and more fulfilling lives as they age in place. In CD 3 there are 27,183 residents over the age of 65 and another 9,578 between the ages of 60-
64. Together they make up nearly 23% of CD 3's total ppopulation.
Approximately 33% of seniors in the district live below the poverty line. 46% live with a disability, 37% experience ambulatory difficultiies, and 36% live alone. Fifty-nine percent of CD 3 seniors are foreign born, with 24% speaking Spanish at home and 45% speaking Asian and Pacific Island languages at home. Therefore, CD 3 requires culturally and linguistically appropriate health and social services for its large senior population. In CD 3, seniors require care on a continuum that covers their diverse cultural, health and wellness needs, and there is no single correct approach that will effectively ensure their health and well-being.
Needs for Homeless
New York City is in crisis regarding the homeless population. We see this crisis reflected in CD 3 with many people observed living on the street, in subways, and overflowing shelters. The Department of Homeless Services (DHS) Hope Count for Manhattan for 2018-9 shows a two percent decrease in this last year. This needs to be considered in light of a five percent decrease the previous year, but a 40 percent increase the preceding year, 2016—7.
Travelers, young homeless people who travel to destinations depending on the weather, continue to be the most difficult subset of the street homeless population to engage. This population often include instances of drug use and aggression. A harm reduction approach is needed, working with all clients and providing Narcan, feminine hygiene products, sunscreen, etc. to people on the street. There has also for the first time been success in requesting reasonable accommodation to bring dogs into safe havens, however, the dog needs to be an emotional support animal. This is an approach that should be considered to produce engagement with travelers as well.
SDR Park has many homeless and drug dealers and users, an increase over previous years. Drug dealers target the homeless in parks and outside shelters. A current reported drug trend is mixing K 2 with crack, based on conversations with Project Renewal security and MOC. Tompkins Square Park during the day is a destination for street homeless and homeless who have shelter beds.
For the first time this past winter the CB 3 office and the offices of elected officials received reports of many homeless in the subways, particularly the F train stops at Second Ave and East Broadway and Delancey. The Hope Count for the current year shows a 23 percent increase in homelessness in the subways, which coincides with the increase seen in CD 3. BRC and Transit NCOs report that they are having some success in having people accept beds and services, but people seem to be more difficult to engage. Current methods of engagement include removing benches and decreasing footprint for homeless and having frequent check-ins that disturbs sleep, as a part of a broader campaign that has been proven successful in reducing homelessness and convincing clients to accept services and beds. However the overall increase shows that although there is some success with individuals, this does not resolve the problem of an increasing number of homeless people needing to seek refuge in the subways. Standard approaches do not prove productive.
Needs for Low Income NYs
Providing services to tenants who are dealing with the termination of basic services, egregious building code violations, and frivolous evictions is essential as development pressure in the neighborhood continues to grow. Without the work of the community-based organizations that provide these services, tenant harassment would go largely unchecked and the threat of residential displacement would increase throughout the district. Community- based organizations in CD 3 provide the first line of defense to prevent evictions with “Know Your Rights campaigns” and offer direct support and technical assistance to local tenant associations. Legal service groups such as Urban Justice Center and Manhattan Legal Services will only work with organized tenant groups, many of which are brought to them by housing groups in CD 3 such as Cooper Square Committee, CAAAV, GOLES and AAFE. A modest investment in the staffing capacity of these groups would have a large payoff in terms of preserving affordable housing and protecting tenants. 36.3% of residents living in CD 3 are foreign born. It is home to the largest concentration of Asian foreign-born residents in Manhattan with a growing base of Latino foreign-born residents.
Local grassroots non-profit organizations need to provide conveniently located services to immigrants regardless of their status. The district needs “know your rights education” for immigrants and legal services, as this year there is a shortage of immigration legal services located within or near our community. In 2015, Latino New Yorkers had the largest increase in unintentional drug overdose deaths involving heroin and/or fentanyl In 2016, Black New Yorkers had the largest increase in unintentional drug overdose deaths This is of concern in CD 3 where 33 % of residents are Black or Latino. CB 3 recommends funding for programs that train and certify “recovery coaches” or “peer mentors.” These certified peers can deliver Medicaid reimbursable services in certain licensed settings. The adult psychiatric hospitalization rate in the Lower East Side and Chinatown is higher than New York City rates overall. CB 3 supports the continued availability of multilingual, convenient prevention and inpatient and outpatient mental health services that accept all insurances including Medicaid. This should include pediatric, adolescent support for affected households. In June 2018, New York City Department of Health launched a two-week advertising campaign aimed at getting Chinese males to quit smoking. The City must build on this campaign by funding smoking cessation programs with counseling and nicotine replacement therapy aimed at people from countries/regions without strong tobacco control policies and programs.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
2/25
DFTA
Enhance NORC
NORCs in CD 3, of which there are six, provide
programs and
Supportive Services Programs to maximize and
health services
support the successful aging in place of older
residents. Many of the City's NORCs can access
health and social services in their own buildings,
building complexes or locally within their
neighborhoods. These programs are a model for
bringing necessary care and support to seniors
living in age-integrated buildings or
neighborhoods.
4/25
DFTA
Other senior center
No seniors are denied a meal through this
program requests
program, which means some senior centers
must dig deeper than others to keep up with
demand, therefore more funding would help
meet this need.
5/25
DHS
Other facilities for
Community Board 3 is currently experiencing a
the homeless
crisis with the street homeless population. There
requests
are not only more homeless individuals on the
street, but some of the beds previously
designated for street homeless have been re-
designated for subway homeless, which is also
dramatically increasing. Haven beds are low-
threshold housing that enable street homeless
to transition to housing and have proven
effective. Currently there are not always beds
available and street homeless have had to wait
for this form of shelter.
6/25
DFTA
Other senior center
In FY20, approximately $40 million of funding
program requests
for social adult day care centers were funded
through discretionary dollars and not baselined.
This had been a baselined program prior to the
2008 recession.
10/25
DFTA
Enhance home care
There is currently a waiting list for this program
services
and additional baselined funding would allow
all clients currently on the waiting list to be
absorbed into program without impacting the
optimal ratio of caseworkers-to-clients.
12/25 DFTA Increase home
delivered meals capacity
This will expand funding for eligible seniors to receive hot meal delivery twice weekly and address issues with waitlists.
image
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 3
image
M ost Important Issue Related to Youth, Education and Child Welfare
Support services for special needs youth (disabled, immigrant, non-English proficient, etc.)
CD 3 is home to more than 22,000 children under 18 years of age. 36% of family households with children under 18 are living below the poverty line. Over 26% of households in the district received public assistance or food stamps/SNAP. The families of these children rely heavily on community-based programs during after-school hours and on weekends and holidays. Those programs provide the youth and their families intervention services and support programming. In addition, young people have reported a lack of Educational and Work Readiness programs in the community. This points to the need for strong outreach and identification of programs appropriate for them. Community centers, afterschool programs, education programs and employment opportunities are necessary to positively engage these youth.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
CD 3 has a school enrollment of 19,239 students in grades K-12. 35.7% identify as Hispanic or Latino, 33.7% as Asian or Pacific Islander, 16.3% as Black or African-American, and 11.3% as White. 31.5% of elementary, middle, and high school students live at or below the poverty level, 13.6% are English Language Learners, and 21.2% are students with disabilities.
15.1% of students live in temporary housing, and on average is 17% of students are homeless for some part of the year. In CSD1, homeless students are highly segregated into two schools – PS 188 and PS 15, where over 40% of the student population is homeless. Homeless children in CD 3 require comprehensive coordination of services to reduce students learning loss as they change schools. Service providers must work together to ensure comprehensive support between NYC Department of Education Family Assistants, Shelters, DHS and outside agencies to prevent gaps in service and prevent duplications of intake and attendance.
The "choice" system of student enrollment in Community School District 1 resulted in greater segregation of the District 1 schools. It also led to a greater concentration of students such as those living in temporary housing, English language learners, and those with IEP's in a small number of schools. To address this, School District 1 began a pilot project in 2018 to support the equitable access of 1) students who qualify for free or reduced lunch (FRL), 2) students in temporary housing (STH), and English Language Learner (ELL). The goal is to improve educational outcomes.
CSD1 schools are also outdated and under-resourced. From 2014-2018, CSD1 lost 761 middle school students36, as more neighborhood families must send their children to middle schools outside CSD1 because there are not enough well-resourced schools in the school district. A state-of-the- art facility could prevent the loss of these students to better equipped and resourced schools. Therefore, CD 3 is in need of a new public-school facility.
Needs for Youth and Child Welfare
CD 3 is home to more than 18,600 children under 18 years of age. Approximately 40% of children under 18 years of age lives below the poverty level, and roughly 23% of family households with related children under 18 are living below the poverty line. Over 26% of households in the district received public assistance or food stamps/SNAP.
Families with children in this district rely heavily on community-based programs during after-school hours and on weekends and holidays. Those programs provide the youth and their families intervention services and support programming.
In addition, young people have reported a lack of Educational and Work Readiness programs in the community. This points to the need for strong outreach and identification of programs appropriate for them. Community centers, afterschool programs, education programs and employment opportunities are necessary to positively engage these youth.
COMPASS elementary school-level afterschool programs remain in high demand. Continuing expansion of funding for this program is needed. The success of universal middle school COMPASS programming can be expanded by ensuring that all high quality elementary, middle, and high school programs operate on a stable and consistent basis. The 36% of CD 3 youth living below the poverty level31 depend on consistent services and programs to succeed.
Older youth, especially at-risk youth, need employment and job training opportunities offered by the Summer Youth Employment Program (SYEP) and the Young Adult Internship Program (YAIP), which helps produce positive outcomes, such as higher lifetime earnings and higher high school attendance and graduation rates. Every year approximately 50% of applicants were turned away for lack of available slots. Funding for this program should continue to be baselined, be at its maximum level and take into account the increased cost of participant salaries.
Expansion of these programs for consistent, year-round programming and to ensure contracting non-profits can adequately plan and staff to serve our youth.
CD 3 currently has nine Cornerstone Programs at NYCHA-based Community Centers. They provide engaging, high- quality, year-round programs for adults and young people that enhance skills and promote social interaction, community engagement, and physical activity. These four programs are run by Henry Street Settlement, University Settlement, and Grand Street Settlement.
In 2018, CD 3 was the third highest Community District of origin in Manhattan for foster care placements with 67 placements (up from 56 placements in 2017). There is a need in the district for increased maintenance and expansion of Department of Youth and Community Development (DYCD) programs for these youth so they can make a successful transition from foster care to independence and adulthood.
The Youth (under 24) homeless count in January 2018 was more than 4,500, up from 2,003 in in 2017 according to Safe Horizon. In NYC these youth are overwhelmingly people of color, disproportionately identify as LGBTQ, and the majority were pregnant or parenting. A more coordinated agency approach between Department of Homeless Services (DHS) and DYCD should be the start of more coordinated response that will prevent homeless youth from “falling between” services of DYCD and DHS.
Expansion of services that offer safe spaces for LGBTQ youth, like Project Speak Out Loud (Project S.O.L) is needed. DYCD programs for LGBTQ, runaway homeless youth and adjudicated youth should be maintained and expanded. In 2019, ten new facilities opening citywide will provide services for youth - including services for LGBTQ and at-risk populations.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
12/21
SCA
Provide a new or
Eighty-five percent of Community School District
145 Clinton
expand an existing
1 schools share a building with one or more
Street
elementary school
schools, resulting in reduced access to gym, arts
and enrichment, science labs, and acceptable
hours for school lunch. With 1,000 new
apartments slated for Essex Crossing by 2024,
several hundred additional residential units
expected at the GO Broome Street and Grand
Street Guild developments, plus the potential for
more than 2,700 new residential units in Two
Bridges, there is a need for a new K through 8th
grade school at Essex Crossing site 5.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
3/25
DOE
Assign more non-
The Bridging the Gap program focuses on
teaching staff, e.g.,
schools with high homeless population and will
to provide social,
benefit from more funding.
health and other
services
7/25
DYCD
Provide, expand, or
Increase funding for structured after school
enhance after
programs for 6th-8th grade students
school programs for
middle school
students (grades 6-
8)
8/25
DYCD
Provide, expand, or
Increase funding to expand access to after
enhance after
school programs for elementary schools
school programs for
elementary school
students
11/25
ACS
Provide, expand, or
There is increased need for additional resources
enhance housing
and services to support activates for this
assistance for youth
population.
that are leaving
foster care
18/25
DOE
Other educational programs requests
More funding is required to reach a goal of guaranteed universal arts education to all public school students in NYC.
21/25
DYCD
Provide, expand, or
This is the nation's largest youth employment
enhance the
program. Increasing and baselining funding will
Summer Youth
make sure more applicants are connected with
Employment
job placements as demand currently outpaces
Program
placement and funding for this program is not
currently baselined
22/25
DYCD
Other runaway and
Runaway and homeless youth need protection
homeless youth
and help reuniting with their families whenever
requests
possible. According to Safe Horizon, there were
over 2,000 homeless youth under 24 years old in
NYC in 2017. Funding is needed for programs
that provide services such as drop-in centers,
crisis shelters, transitional independent living
programs, and street outreach and referral
services. Funding is also needed for specialized
programming for runaway and homeless
pregnant and parenting youth, as well as LGBTQ
youth.
23/25
DYCD
Provide, expand, or
CB 3 currently has four Cornerstone Programs,
enhance
which provide engaging, high-quality, year-
Cornerstone and
round programs for adults and young people
Beacon programs
that enhance skills and promote social
(all ages, including
interaction, community engagement, and
young adults)
physical activity. CB 3 programs are run by
Chinatown YMCA, Henry Street Settlement,
University Settlement, and Grand Street
Settlement. Increased funding is necessary for
summer programming.
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 3
image
M ost Important Issue Related to Public Safety and Emergency Services
Public Nuisance (noise, other disturbances)
CD 3, a primarily residential district, has the largest number of 311 commercial noise complaints year to year for any Community District in Manhattan, regularly registering more than 2,500 complaints in each of the past five years.
However, the last two fiscal years saw consecutive decreases in complaints. From Fiscal Year 2018 to Fiscal Year 2019, CD 3 saw a decrease from 3,645 to 2,994 commercial noise complaints—a decrease of almost 18 percent. The decrease in the number of commercial noise complaints may be the result of fewer complaints or may be the result of NYPD and City discouragement of using 311 for noise complaints. However the 2,294 commercial noise complaints in Fiscal Year 2019 show that the quality of life of many residents is still very negatively impacted by the growth of the area as a nightlife destination.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Many complaints related to nightlife are difficult to resolve because no agency has sole jurisdiction over noisy crowds on the street, lines outside businesses, overcrowding, and loud music. The New York State Liquor Authority (SLA), which issues licenses and has jurisdiction over compliance with the New York State Alcohol Beverage Law, has limited investigation and enforcement abilities and believes that noise and other quality of life problems caused by the saturation of liquor licenses should also be documented and enforced by the NYPD. Large rowdy crowds, traffic congestion, and horn honking are a constant result of the saturation of bars, but as these conditions are not criminal, there is little the police can do to respond to noisy, crowded streets and sidewalks.
To mitigate the negative impacts of this nightlife proliferation there needs to be strict adherence by the SLA to the 500-foot rule by not allowing new liquor licenses in saturated areas without a clear showing by the applicant of a public benefit. In addition, there must be robust enforcement of the "6 in 60" legislation enacted in 2010 which allows police to refer persistently noncompliant businesses to the SLA for NYPD violations, as well as for violations of stipulations and the conditions of a license.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
2/21 NYPD Provide surveillance
cameras
The 7th precinct needs Argus surveillance for the following locations: 1) South Street and FDR Drive; 2) Seward Park; 3) 85 Pitt St.
image
14/21 FDNY Other FDNY facilities
and equipment requests (Capital)
There is a need Need is for a specialized ambulance with bariatric stretcher and lift equipment for larger patients.
Expense Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 3
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Noise pollution
There is a need to prioritize programs that mitigate additional environmental impacts from heavy traffic and development construction burdens in CD 3. Noise is the number one complaint in CD 3. In the past this was primarily commercial noise complaints from bars followed by after-hours construction noise. Residential noise from rooftop amenities has become a new source of noise complaints, especially in the new developments in the East Village. The 9th precinct community council meetings often see residents complaining year after year about these problems. Police sometimes have trouble gaining access and have limited recourse legally. This appears to be a new problem that must be addressed legislatively.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
CD 3’s overabundance of impervious land cover increases the effects of extreme heat, and exacerbates other environmental impacts by making it harder to manage stormwater, neutralize airborne and waterborne pollutants, and dampen light and noise pollution. The City and State need to prioritize programs that mitigate additional environmental impacts, including a green infrastructure build out of street trees, rain gardens, bioswales, park forestry, and blue and green roofs to manage our burden of airborne particulate material, polluted runoff, stormwater flooding, and light and noise pollution; the inclusion of CB 3 in future planning for the Mayor’s new "Cool Neighborhoods NYC" program , which will "help mitigate the threat to public health from the urban heat island effect exacerbated during summer months."; and take active steps to study and mitigate the noise, runoff, and exhaust from subways and vehicles using our bridges and other heavy traffic corridors.
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
25/25 DSNY Provide more
frequent litter basket collection
CD 3 is a priority area in the City's neighborhood rat reduction plan and a neighborhood with increasing destination nightlife establishments. Enhanced street corner basket pickups will help with quality of life issues regarding trash and rodents, particularly with littler basket service during overtime hours.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 3
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Other
Support for the Expansion of Community Land Trusts CD 3 needs to increase affordable housing, slow gentrification, and limit residential displacement. Community Land Trusts (CLTs) are increasingly recognized as an effective mechanism for permanently preserving affordable housing. In CD 3, the Cooper Square CLT and the Cooper Square Mutual Housing Association ensure that 21 cooperative buildings, containing 328 housing units and 22 storefronts, are permanently affordable. There is also interest from a number of small property owners, community- based organizations, and non-profit affordable housing developers to establish a new Community Land Trust in Chinatown.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Improved HPD and DOB building inspection and code enforcement are necessary to maintain the safety of the housing stock in the district. Serious housing code violations in the district have increased by 46 percent since 2016. The City must adequately fund building and housing code enforcement activities to ensure the preservation of affordable housing in the district.
Needs for Housing
Thirty-six percent of low-income renter households in CD 3 are spending more than half their monthly income on housing and the district is ranked as having the second-highest risk factor for the loss of affordable housing and residential displacement amongst Manhattan Community Districts. This crisis of affordability and inequality in CD 3 will likely worsen as most affordable housing being built in the district is attached to proportionally larger amounts of market-rate housing, and most of the “affordable” units do not meet the needs of low-income residents and seniors living on fixed incomes. New housing is needed, but must be targeted at affordability levels appropriate for current neighborhood incomes. The City must help address these housing needs, slow gentrification, and limit residential displacement by supporting existing and emerging Community Land Trusts, expanding support for local orgfanizations that provide anti-displacement services to tenants, including CD 3 in the Certificate of No Harrassment pilot program, expanding supprt services for Housing Development Fund Coops, expanding support for resiliency upgrades, and funding major capital repairs at NYCHA buildings that are necessary to ensure safe and healhty living conditions for residents.
Needs for Economic Development
There has been a sustained loss of independent "mom-and-pop" stores in CD 3 due to exponentially increasing costs of doing business and increased competition from chains, destination bars, and restaurants. As the local economy becomes more and more homogenous, and the availability of local goods and services continues to decrease, residents must increasingly leave our community or shop online in order to meet their basic needs. Chain stores have altered the character of the Lower East Side by shifting purchasing power to mass-market retailers and constructing facades out of context with the rest of the historical community.
Retail stores that do survive in our community are threatened by rising costs of rents, increased security deposits, utilities taxes and “cost of doing business” such as increased minimum wage, paid family leave, paid sick time– all identified as major challenges to small business survival in several CB 3- initiated surveys of local businesses.
Property taxes have risen dramatically over the last nine years as well, and a portion of which are passed on to businesses by property owners creating a rent burden that the businesses cannot sustain. This could lead to a continued cycle of storefront vacancies, suppressed daytime foot traffic, and nightlife business proliferation in the district. The effect of property taxes is also particularly impacting small, for-profit independent theaters.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
9/25
EDC
Other public
Waste management staff and operations
housing
funding will help to combat waste and rodent
maintenance,
issues and support important physical
staffing and
improvements such as enlarged hopper doors,
management
which address these problems but are below the
requests
capital project funding threshold.
19/25
HPD
Other affordable
Community District 3 is home to a large CLT
housing programs
(Cooper Square) as well as several prospective
requests (expense)
CLTs that need support, which will contribute to
area housing and commercial affordability.
20/25
DOB
Expand code
The new After Hours Variance Enforcement Unit
enforcement
is only partially baseline funded. Having fully
baselined funding for this unit will ensure that
improved response times and enforcement
remain going forward.
TRANSPORTATION
Manhattan Community Board 3
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
There is a need to take strong, creative measures in CD 3 to reduce traffic congestion, which contributes to a vicious cycle of reduced ridership and reduced service. The MTA/NYCT will reduce service after ridership on a bus route drops below a certain threshold, and service cuts have already had a severely negative impact on vulnerable populations, including the elderly and disabled, who rely on public transportation. Local businesses need adequate loading/unloading zones for commercial delivery and curbside parking regulations need to balance competing demands of pedestrians, businesses, and motorists. Lack of loading zones make it impossible for businesses to comply with traffic rules. Pedestrian safety improvements and traffic calming measures are needed at several wide corridors with high traffic and congestion volumes, including Essex Street, Canal Street, and East Houston Street.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Accessibility and pedestrian safety are a CB 3 priority, especially with more than 9.1% of residents in the area reporting ambulatory difficulty. There are several ways to address this issue in the district, including improved accessibility of bus stops, which is necessary for seniors and people with disabilities. There are complaints to the community board and observations of bus stops being used as loading zones, which render the stops inaccessible for those in wheelchairs and walkers; adequate staffing of traffic enforcement to monitor noncompliant use of bus stops.; requiring all bus stops to have benches, particularly to accommodate seniors and people with ambulatory disabilities, and shelters where possible. The DOT franchise division should audit stops and implement complete installation of benches; and, making pedestrian safety improvements and traffic calming measures at several wide corridors with high traffic volumes, including Essex Street, Canal Street, and East Houston Street. Local businesses need adequate loading/unloading zones for commercial delivery. Curbside parking regulations need to balance competing demands of pedestrians, businesses, and motorists. Lack of loading zones make it impossible for businesses to comply with rules.
Deliveries to residences has grown exponentially because of online purchasing, but there has been no planning to mitigate this. We are seeing narrow streets blocked by second lane unloading, sidewalks and access to businesses blocked by cartons from major online vendors such as Amazon, and a lack of available space for unloading.
Needs for Transit Services
The intercity bus permit system has not been effective because there is not a means to enforce compliance and collect violations. There are frequent complaints of intercity buses laying over and picking up and discharging passengers illegally in MTA bus stops. This results in buses not being able to discharge and pick up passengers at the curb. Disabled passengers are therefore unable to board or disembark. CB 3 has received many complaints that bus companies illegally loading and unloading interferes with businesses at the location. This is generally because of large crowds blocking sidewalks and entrances to businesses and sidewalk cafes. Most of the buses are registered in other states. It appears that bus companies have realized there is not effective enforcement and stopped applying for permitted stops.
Additionally, CD 3 is underserved by public transportation, though fewer than 11% of workers in the district use a car to commute to work. Despite CD 3 being the fifth most densely populated community district in New York City, many residents are poorly served by the subway system and 15% live more than ½ mile from the nearest subway stop.
image
Capital Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 3
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
CD 3, like most community districts in New York City, is underserved in terms of open space, with less than the City- recommended 2.5 acres of open space per 1000 residents. Parks Buildings There are numerous Parks Department buildings in the district that are underutilized for the benefit of the community. These spaces are either completely closed or are used as store houses for citywide Parks operations. Our local park houses should not bear this disproportionate burden for other neighborhoods. These buildings would be better used as community facilities that could serve as neighborhood safe anchors thus increasing park safety. Comfort Stations For the use of all in the community, comfort stations in CD 3 parks, recreational fields, playgrounds and park buildings with park programming are badly needed. Recreational Use The lack of park space is exacerbated by a lack of recreational sports fields, especially for the youth of CD 3 and given the pending closure of parts of East River Park Rodents in Parks and Community Gardens Structural holes, overall disrepair, and lack of maintenance resulting in garbage overflow and a rapid increase in gentrification continues to result in continuing rodent problems in the district that must be addressed. Maintenance CB 3 members have routinely observed parks, playgrounds, plazas, greenstreets, and street trees with plantings not being properly and regularly maintained or mowed. Community Gardens CD 3 has one of the highest concentrations of Greenthumb gardens in New York City and the densest distribution of gardens in the city. Since all community gardens have the same maintenance and resource needs as public parks, CB 3 requests that all gardens under NYC Parks jurisdiction receive funding through Greenthumb and be provided with adequate infrastructure, such as available water spigots, ongoing topsoil renewal, wrought iron fencing, and electricity/solar lighting where applicable.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
There are numerous Parks Department buildings in the district that are underutilized for the benefit of the community. These spaces are either completely closed or are used as store houses for citywide Parks operations. Our local park houses should not bear this disproportionate burden for other neighborhoods. These buildings would be better used as community facilities that could serve as neighborhood safe anchors thus increasing park
safety. For the use of all in the community, comfort stations in CD 3 parks, recreational fields, playgrounds and park buildings with park programming are badly needed. The lack of park space is exacerbated by a lack of recreational sports fields, particularly for non-for-profit organizations serving youth and given the impending closure of East River Park. Parks maintenance needs to be improved, as CB 3 members have routinely observed parks, playgrounds, plazas, greenstreets, and street trees with plantings not being properly and regularly maintained or mowed.
Department of Health rat indexing shows that CD 3 has one of the highest rat failure rates in the City. While the implementation of the Neighborhood Rat Reduction program has shown some success in parks, many are still
in current need of treatment for structural holes, overall disrepair, and lack of maintenance resulting in garbage overflow. The rapid increase in gentrification continues to result in continuing rodent problems in the district that must be addressed.
CD 3 residents would benefit greatly from free wireless access in all public parks, such as the networks currently available in Tompkins Square Park and Hamilton Fish Park, which allow all in the community to use their laptops and other devices in parks.
CD 3 has one of the highest concentrations of Greenthumb gardens in New York City and the densest distribution of gardens in the city. It is essential our community gardens are protected, including giving all gardens under NYC Parks jurisdiction funding through Greenthumb and be provided with adequate infrastructure, such as available water spigots, ongoing topsoil renewal, wrought iron fencing, and electricity/solar lighting where applicable, and keeping the gardens well-lit do address a public safety need. The increase in illicit drug use, as reported by area gardeners, makes garden lighting especially relevant. For these safety reasons, an additional PEP Officer should be hired to specifically patrol the community gardens in CD 3.
Finally, bioswales and tree plantings (tree canopy) needs to begin now especially considering the ESCR project will temporarily remove trees in East River Park. Indigenous plantings should also be distributed throughout CD 3.
Needs for Cultural Services
CB3 has a large concentration of artists and arts organizations, large and small, professional and community-based, experimental and culturally specific. The arts are an important means of preservation and exploration of our exceptionally diverse community cultures, have a proven positive impact on the local economy, and are important to psychological and physical well-being of the residents of the neighborhood. Accessible arts and culture programming are key elements for civic dialogue and empowerment of our most vulnerable populations.
In the face of intensifying gentrification and the growth of exclusive, private cultural amenities in the district, neighborhood art venues, libraries, community gardens and parks provide local, often low-cost, access to cultural programming, and arts and culture should be integrated into the planning of City projects such as designated arts and cultural spaces in new publicly subsidized developments. CB 3 has identified ways the City can help achieve this:
Support arts organizations that expand promote diversity and inclusion in the cultural workforce, and to increase language access for communications and cultural programming.
Explore incentives for developers to provide below market rental space for arts businesses and nonprofits and City development should include below market opportunities for arts businesses and organizations
Include programming for public participation in the project design process of publicly subsidized projects.
City Hall should move forward in reacquiring the CHARAS/El Bohio profit community and cultural center as stated by the Mayor in the 2017 Town Hall.
The Mayor’s Office of Media and Entertainment and DCLA should support a neighborhood- level trilingual data and communication platform for cultural spaces and projects.
Support arts and cultural organizations direct participation in resiliency planning
Increase community participation and engagement with the Community Board regarding any and all new cultural/community spaces in publicly subsidized developments in the District.
Needs for Library Services
A study conducted by the Center for an Urban Future found that across the city, although library visits, book circulation and program attendance have consistently increased in the past decade, our libraries are open fewer hours than the state's largest counties and trail behind cities throughout the nation. Community Board 3 has five branches of the New York Public Library (NYPL) system: Chatham Square, Hamilton Fish, Ottendorfer, Seward Park, and Tompkins Square. The branches in Community Board 3 have amongst the highest numbers of visits in the NYPL system. Hamilton Fish, Seward Park, and Tomkins Square have all seen significant increases in the number of visits during FY18. According to NYPL statistics, in Fiscal Year 2018 the libraries in CB 3 had 975,037 visits. • The arts and cultural programming along with English for Speakers of Other Languages in this neighborhood are extremely
important to many residents, particularly families with children and seniors, who cannot otherwise afford access to commercial alternatives. • In FY20 the three systems will continue to advocate for significant capital and expense funding to support the needs of our branches across the city.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/21
DPR
Provide a new or
This will be a destination park that will provide
expanded park or
waterfront access with various amenities
amenity (i.e.
needed by the community.
playground, outdoor
athletic field)
3/21
DPR
Provide a new or
Six mall reconstructions have been completed
Allen Street
expanded park or
and seven remain. This is a highly visible
and Pike
amenity (i.e.
location, and currently unreconstructed malls
Street
playground, outdoor
attract garbage and derelict bikes. This has a
athletic field)
negative impact on local businesses and does
not address the lack of amenities needed by the
community and tourists. Additionally, $2 million
has been allocated for the Delancey Street
Comfort Station. If this project does not move
ahead, the Parks Department should reallocate
the funding to the remaining malls.
4/21
DPR
Reconstruct or
Funding needed to replace play equipment and
upgrade a park or
safety surface and address drainage and
amenity (i.e.
pavement problems.
playground, outdoor
athletic field)
5/21
DPR
Other park
Funding is needed for water source installations,
programming
electricity conduits, soil replenishment, fencing
requests
and other capital needs for community gardens
and related programs.
6/21
DPR
Reconstruct or
This building should be reconstructed for
upgrade a building
community use to increase recreational and
in a park
programmed space as this space is accessible
and has a usable bathroom, features which
make it appropriate for use by the community in
an area with a serious lack of community
spaces.
7/21
DPR
Reconstruct or
Roof needs to be replaced and lighting needs to
128 Pitt
upgrade a building
be replaced with energy-efficient fixtures.
Street
in a park
8/21
DPR
Reconstruct or
The one full size and two half-sized basketball
upgrade a park or
courts are in need of upgrade.
amenity (i.e.
playground, outdoor
athletic field)
9/21
DPR
Reconstruct or upgrade a park or playground
Repave the sidewalks surrounding three sides of the pool and playground.
Avenue D, Manhattan, New York, NY
10/21
DPR
Reconstruct or
This is one of the most popular and heavily used
upgrade a park or
parks in CD 3. Many children use the pool as
amenity (i.e.
well as daycare, school and summer camp
playground, outdoor
groups.
athletic field)
11/21
DPR
Reconstruct or
Redesign and reconstruct the playground
upgrade a park or
including new play equipment, safety surface,
amenity (i.e.
greenery, etc.
playground, outdoor
athletic field)
13/21
DPR
Reconstruct or
Replace windows and doors throughout.
80 Catherine
upgrade a building
Reconstruction of locker rooms, bathrooms, and
Street
in a park
adjacent areas including new plumbing,
plumbing fixtures, partitions, lockers, tile work
and floors.
15/21
DPR
Reconstruct or
Restoration includes the replacement of missing
upgrade a park or
granite and bronze elements, the cleaning and
amenity (i.e.
repointing of the existing granite, and the repair
playground, outdoor
or replacement of the plumbing to make the
athletic field)
foundation operable
16/21
DPR
Reconstruct or
The two full-sized basketball courts need
upgrade a park or
renovation
amenity (i.e.
playground, outdoor
athletic field)
17/21
DPR
Reconstruct or
Renovate the full size basketball court
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
18/21
DPR
Reconstruct or
Funding is needed to redesign and renovate
Cherry Street,
upgrade a park or
children's playground and water play area.
Manhattan,
playground
Current playground only has one old, small play
New York, NY
set for younger kids. Water area is non-
functional with bad drainage.
19/21
DPR
Reconstruct or
This area needs redesign and renovation to be
upgrade a park or
useable by residents.
playground
20/21 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
Redesign and reconstruct the playground including new play equipment, safety surface, greenery, etc.
image
21/21 DPR Reconstruct or
upgrade a park or playground
Sara Delano Roosevelt Park: Funding to reconstruct park pathways, adjacent brick walls and sidewalks and other areas. Sprinklers near Stanton Street are also in need of repair as well as the pathways and sidewalks which are so badly deteriorated that they present safety issues. The brick walls surrounding the park need reconstruction to improve users' safety inside and adjacent to the park's walls.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/25
OMB
Other community
Baselining increased funding will allow CBs to
board facilities and
plan ahead, to use the funding for multi-year
staff requests
contracts, and to use the funding for salaries.
13/25
DPR
Other park
Additional funds are needed to increase year-
maintenance and
round workforce for parks maintenance so that
safety requests
there is less of a need to rely on temporary or
seasonal staff.
14/25
DPR
Other park
Playground Associates provide seasonal
programming
recreation activities for children.
requests
15/25
DPR
Other park
General expense funding for gardens, soil, and
maintenance and
garden related programming is needed.
safety requests
16/25
DPR
Forestry services,
Funding would go towards keeping up with
including street tree
demand for pruning and stump removal
maintenance
requests.
17/25
DPR
Enhance park safety
Additional Parks Enforcement Police
through more
Explanation: Parks Enforcement Police provide a
security staff (police
uniformed presence where they safeguard Parks
or parks
properties and facilities and enforce rules and
enforcement)
regulations in regard to quality-of-life
conditions.
image
24/25 NYPL Extend library hours
or expand and enhance library programs
Increase funding so that all neighborhood branch libraries have access to a library 6 days a week
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/21
DPR
Provide a new or
This will be a destination park that will provide
expanded park or
waterfront access with various amenities
amenity (i.e.
needed by the community.
playground, outdoor
athletic field)
2/21
NYPD
Provide surveillance
The 7th precinct needs Argus surveillance for
cameras
the following locations: 1) South Street and FDR
Drive; 2) Seward Park; 3) 85 Pitt St.
3/21
DPR
Provide a new or
Six mall reconstructions have been completed
Allen Street
expanded park or
and seven remain. This is a highly visible
and Pike
amenity (i.e.
location, and currently unreconstructed malls
Street
playground, outdoor
attract garbage and derelict bikes. This has a
athletic field)
negative impact on local businesses and does
not address the lack of amenities needed by the
community and tourists. Additionally, $2 million
has been allocated for the Delancey Street
Comfort Station. If this project does not move
ahead, the Parks Department should reallocate
the funding to the remaining malls.
4/21
DPR
Reconstruct or
Funding needed to replace play equipment and
upgrade a park or
safety surface and address drainage and
amenity (i.e.
pavement problems.
playground, outdoor
athletic field)
5/21
DPR
Other park
Funding is needed for water source installations,
programming
electricity conduits, soil replenishment, fencing
requests
and other capital needs for community gardens
and related programs.
6/21
DPR
Reconstruct or
This building should be reconstructed for
upgrade a building
community use to increase recreational and
in a park
programmed space as this space is accessible
and has a usable bathroom, features which
make it appropriate for use by the community in
an area with a serious lack of community
spaces.
7/21
DPR
Reconstruct or
Roof needs to be replaced and lighting needs to
128 Pitt
upgrade a building
be replaced with energy-efficient fixtures.
Street
in a park
8/21
DPR
Reconstruct or
The one full size and two half-sized basketball
upgrade a park or
courts are in need of upgrade.
amenity (i.e.
playground, outdoor
athletic field)
9/21
DPR
Reconstruct or
Repave the sidewalks surrounding three sides of
Avenue D,
upgrade a park or
the pool and playground.
Manhattan,
playground
New York, NY
10/21
DPR
Reconstruct or
This is one of the most popular and heavily used
upgrade a park or
parks in CD 3. Many children use the pool as
amenity (i.e.
well as daycare, school and summer camp
playground, outdoor
groups.
athletic field)
11/21
DPR
Reconstruct or
Redesign and reconstruct the playground
upgrade a park or
including new play equipment, safety surface,
amenity (i.e.
greenery, etc.
playground, outdoor
athletic field)
12/21
SCA
Provide a new or
Eighty-five percent of Community School District
145 Clinton
expand an existing
1 schools share a building with one or more
Street
elementary school
schools, resulting in reduced access to gym, arts
and enrichment, science labs, and acceptable
hours for school lunch. With 1,000 new
apartments slated for Essex Crossing by 2024,
several hundred additional residential units
expected at the GO Broome Street and Grand
Street Guild developments, plus the potential for
more than 2,700 new residential units in Two
Bridges, there is a need for a new K through 8th
grade school at Essex Crossing site 5.
13/21
DPR
Reconstruct or
Replace windows and doors throughout.
80 Catherine
upgrade a building
Reconstruction of locker rooms, bathrooms, and
Street
in a park
adjacent areas including new plumbing,
plumbing fixtures, partitions, lockers, tile work
and floors.
14/21
FDNY
Other FDNY facilities
There is a need Need is for a specialized
and equipment
ambulance with bariatric stretcher and lift
requests (Capital)
equipment for larger patients.
15/21
DPR
Reconstruct or
Restoration includes the replacement of missing
upgrade a park or
granite and bronze elements, the cleaning and
amenity (i.e.
repointing of the existing granite, and the repair
playground, outdoor
or replacement of the plumbing to make the
athletic field)
foundation operable
16/21
DPR
Reconstruct or
The two full-sized basketball courts need
upgrade a park or
renovation
amenity (i.e.
playground, outdoor
athletic field)
17/21
DPR
Reconstruct or
Renovate the full size basketball court
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
18/21
DPR
Reconstruct or
Funding is needed to redesign and renovate
Cherry Street,
upgrade a park or
children's playground and water play area.
Manhattan,
playground
Current playground only has one old, small play
New York, NY
set for younger kids. Water area is non-
functional with bad drainage.
19/21
DPR
Reconstruct or
This area needs redesign and renovation to be
upgrade a park or
useable by residents.
playground
20/21
DPR
Reconstruct or
Redesign and reconstruct the playground
upgrade a park or
including new play equipment, safety surface,
amenity (i.e.
greenery, etc.
playground, outdoor
athletic field)
21/21
DPR
Reconstruct or
Sara Delano Roosevelt Park: Funding to
upgrade a park or
reconstruct park pathways, adjacent brick walls
playground
and sidewalks and other areas. Sprinklers near
Stanton Street are also in need of repair as well
as the pathways and sidewalks which are so
badly deteriorated that they present safety
issues. The brick walls surrounding the park
need reconstruction to improve users' safety
inside and adjacent to the park's walls.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
OMB
Other community
Baselining increased funding will allow CBs to
board facilities and
plan ahead, to use the funding for multi-year
staff requests
contracts, and to use the funding for salaries.
2/25
DFTA
Enhance NORC
NORCs in CD 3, of which there are six, provide
programs and
Supportive Services Programs to maximize and
health services
support the successful aging in place of older
residents. Many of the City's NORCs can access
health and social services in their own buildings,
building complexes or locally within their
neighborhoods. These programs are a model for
bringing necessary care and support to seniors
living in age-integrated buildings or
neighborhoods.
3/25
DOE
Assign more non-
The Bridging the Gap program focuses on
teaching staff, e.g.,
schools with high homeless population and will
to provide social,
benefit from more funding.
health and other
services
4/25
DFTA
Other senior center
No seniors are denied a meal through this
program requests
program, which means some senior centers
must dig deeper than others to keep up with
demand, therefore more funding would help
meet this need.
5/25
DHS
Other facilities for
Community Board 3 is currently experiencing a
the homeless
crisis with the street homeless population. There
requests
are not only more homeless individuals on the
street, but some of the beds previously
designated for street homeless have been re-
designated for subway homeless, which is also
dramatically increasing. Haven beds are low-
threshold housing that enable street homeless
to transition to housing and have proven
effective. Currently there are not always beds
available and street homeless have had to wait
for this form of shelter.
6/25
DFTA
Other senior center
In FY20, approximately $40 million of funding
program requests
for social adult day care centers were funded
through discretionary dollars and not baselined.
This had been a baselined program prior to the
2008 recession.
7/25
DYCD
Provide, expand, or
Increase funding for structured after school
enhance after
programs for 6th-8th grade students
school programs for
middle school
students (grades 6-
8)
8/25
DYCD
Provide, expand, or
Increase funding to expand access to after
enhance after
school programs for elementary schools
school programs for
elementary school
students
9/25
EDC
Other public
Waste management staff and operations
housing
funding will help to combat waste and rodent
maintenance,
issues and support important physical
staffing and
improvements such as enlarged hopper doors,
management
which address these problems but are below the
requests
capital project funding threshold.
10/25
DFTA
Enhance home care
There is currently a waiting list for this program
services
and additional baselined funding would allow
all clients currently on the waiting list to be
absorbed into program without impacting the
optimal ratio of caseworkers-to-clients.
11/25
ACS
Provide, expand, or
There is increased need for additional resources
enhance housing
and services to support activates for this
assistance for youth
population.
that are leaving
foster care
12/25
DFTA
Increase home
This will expand funding for eligible seniors to
delivered meals
receive hot meal delivery twice weekly and
capacity
address issues with waitlists.
13/25
DPR
Other park
Additional funds are needed to increase year-
maintenance and
round workforce for parks maintenance so that
safety requests
there is less of a need to rely on temporary or
seasonal staff.
14/25
DPR
Other park
Playground Associates provide seasonal
programming
recreation activities for children.
requests
15/25
DPR
Other park
General expense funding for gardens, soil, and
maintenance and
garden related programming is needed.
safety requests
16/25
DPR
Forestry services, including street tree maintenance
Funding would go towards keeping up with demand for pruning and stump removal requests.
17/25
DPR
Enhance park safety
Additional Parks Enforcement Police
through more
Explanation: Parks Enforcement Police provide a
security staff (police
uniformed presence where they safeguard Parks
or parks
properties and facilities and enforce rules and
enforcement)
regulations in regard to quality-of-life
conditions.
18/25
DOE
Other educational
More funding is required to reach a goal of
programs requests
guaranteed universal arts education to all public
school students in NYC.
19/25
HPD
Other affordable
Community District 3 is home to a large CLT
housing programs
(Cooper Square) as well as several prospective
requests (expense)
CLTs that need support, which will contribute to
area housing and commercial affordability.
20/25
DOB
Expand code
The new After Hours Variance Enforcement Unit
enforcement
is only partially baseline funded. Having fully
baselined funding for this unit will ensure that
improved response times and enforcement
remain going forward.
21/25
DYCD
Provide, expand, or
This is the nation's largest youth employment
enhance the
program. Increasing and baselining funding will
Summer Youth
make sure more applicants are connected with
Employment
job placements as demand currently outpaces
Program
placement and funding for this program is not
currently baselined
22/25
DYCD
Other runaway and
Runaway and homeless youth need protection
homeless youth
and help reuniting with their families whenever
requests
possible. According to Safe Horizon, there were
over 2,000 homeless youth under 24 years old in
NYC in 2017. Funding is needed for programs
that provide services such as drop-in centers,
crisis shelters, transitional independent living
programs, and street outreach and referral
services. Funding is also needed for specialized
programming for runaway and homeless
pregnant and parenting youth, as well as LGBTQ
youth.
23/25 DYCD Provide, expand, or
enhance Cornerstone and Beacon programs (all ages, including young adults)
CB 3 currently has four Cornerstone Programs, which provide engaging, high-quality, year- round programs for adults and young people that enhance skills and promote social interaction, community engagement, and physical activity. CB 3 programs are run by Chinatown YMCA, Henry Street Settlement, University Settlement, and Grand Street Settlement. Increased funding is necessary for summer programming.
image
24/25 NYPL Extend library hours
or expand and enhance library programs
Increase funding so that all neighborhood branch libraries have access to a library 6 days a week
image
25/25 DSNY Provide more
frequent litter basket collection
CD 3 is a priority area in the City's neighborhood rat reduction plan and a neighborhood with increasing destination nightlife establishments. Enhanced street corner basket pickups will help with quality of life issues regarding trash and rodents, particularly with littler basket service during overtime hours.
image

