- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 9 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1-lURasUxBRyyleoDHi6FEgPTHzOIsK5V/preview}}
- Obsidian Embed::
    - <iframe src="" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
9
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 9
image
Address: 1967 Turnbull Ave
Phone: (718) 823-3034
Email: bx09@cb.nyc.gov
Website: www.nyc.gov/bronxcb9
Chair: Brandon Ganaishlal District Manager: William Rivera
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
In devising its annual District Needs Statement, Bronx Community Board 9, has taken an opportunity to articulate its FY2019 capital and expense funding requests on the basis of concrete and objective data. The process of devising this statement has included meetings with local service chiefs, qualitative surveying of community stakeholders, and a desk-study of mayoral agency reporting on future initiatives impacting the district. Our goal is to highlight--with the highest degree of accuracy--areas for near-term funding that might assuage pressing municipal service needs vocalized by our constituency. Bronx Community Board 9 encompasses neighborhoods south of East Tremont Avenue, from the Bronx River on the west, to Westchester Creek on the east, and a shoreline along the East River to the southern-most edge of the peninsula, serving Bronx River, Castle Hill, Clason Point, Parkchester, Park Stratton, Soundview, Bruckner, Unionport, & Zerega. In total the district covers 4.1 square miles in which 184, 729 people reside. Inland, the community consists of a range of residential building types and commercial uses. Single-family detached and 1-2 family row houses are common throughout the district (1 in 5 of all lots). Clustered within a southwest pocket are 9 large NYC Public Housing Authority complexes. The neighborhood to the north of the Bruckner Expressway consists of a mixture of housing types ranging from single family detached homes to a 129 acre Parkchester community built in 1941. Near the waterfront one will find mostly framed and masonry homes built prior to 1960. It, too, has evolved to include a mixture of low rise, single-family units and patches of publicly financed towers. The district’s major streets running north and south are: White Plains Road, Bronx River, Rosedale, Soundview, Castle Hill and Zerega avenues. Major avenues cutting east and west include: Randall, Lafayette, Story and East Tremont avenues. The district’s highways consist of: the Bronx River Parkway, the Bruckner Expressway, and the Cross Bronx Expressway.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 9
image
The three most pressing issues facing this Community Board are:
Affordable housing
Contact Board Office.
Crime
Contact Board Office .
Land use trends (zoning, development, neighborhood preservation, etc.)
Contact Board Office.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 9
image
M ost Important Issue Related to Health Care and Human Services
Mental health and substance abuse treatment and prevention programs
The Board will like to see an increase in resources and prevention in this area.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Tracking  109201604E - Request Funding for Social Services Programs for Seniors
Needs for Older NYs
tracking  109199202E - Funding for Home Care Services
Needs for Homeless
We need general services for the Homeless in our district.
Needs for Low Income NYs
Additionally, after school programs are an important service to the youth of Community District 9 as roughly 1 in 3 families live below the federal poverty level. These are families that given a lack of discretionary income find it arduous to supply private enrichment activities for their children. Given this demographic reality, Community Board 9 reiterates the Bronx Borough Board’s support for Mayor DeBlasio's FY2016 Budget Priorities which includes providing universal afterschool programs to all NYC’s public middle school students, and summer programming for public afterschool programs. We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new process.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/36
HHC
Provide a new or
The Jacobi Hospital ER Fast Track unit must be a
expanded health
24 hour facility. T
care facility
29/36
DOHMH
Other animal and
We need to see who we can get more resources
pest control
for Raccoon control for residents.
requests
32/36
DOHMH
Increase health
We have seen the Health Inspectors system to
inspections, e.g. for
be a revenue based system. Focused more on
restaurants
questionable enforcement rather then
prevention and education. Which benefits the
all parties including the public.
35/36
DFTA
Enhance home care
Fund Home Care Services. There aren't sufficient
services
home care services for Community District 9's
increasing elderly population. Funds are
requested to provide for additional home care
services.
37/36
DFTA
Increase home
Provide Meals-on-Wheels Services. Funding is
delivered meals
needed for Meals-on-Wheels services; there are
capacity
not enough services for the elderly population in
Community District 9.
42/36
DFTA
Increase
Provide Funding for a Handicap Vehicle for
transportation
Transporting Seniors. Our seniors continue to
services capacity
support this request. The seniors have serious
concerns about "pickup and drop off" and
"delays in service." It was their opinion that
presently there may not be enough vehicles to
serve the needs of this aging population.
44/36 DFTA Enhance NORC
programs and health services
Seniors Request the Funding of Social Service Programs. Our seniors, during our public hearing, were very concerned over their quality of life, their limited income and essential services that they require. Therefore, they recommend the funding of social service programs, which would address their needs, to be sponsored at NYCHA sites. Also, seniors recommended sponsoring of more 2O2 Senior Citizen Housing to be built within the border of community board District 9.
image
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 9
image
M ost Important Issue Related to Youth, Education and Child Welfare
Juvenile justice and services for young offenders
The Board will like to see an increase in services we need to combat this issue and expand youth programs. In addition, expand the use of the closed schools we have after hours.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Tracking  109199005C, 109199902C, 109198703C, 109199003C, 109199603C, 109198804C, We are currently re-
evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new process.
Needs for Youth and Child Welfare
Additionally, after school programs are an important service to the youth of Community District 9 as roughly 1 in 3 families live below the federal poverty level. These are families that given a lack of discretionary income find it arduous to supply private enrichment activities for their children. Given this demographic reality, Community Board 9 reiterates the Bronx Borough Board’s support for Mayor DeBlasio's FY2016 Budget Priorities which includes providing universal afterschool programs to all NYC’s public middle school students, and summer programming for public afterschool programs. We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new process.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
3/43
SCA
Provide technology
I am attaching the technology request for
1980
upgrade
(APPA) )08X376. They are also in need of
Lafayette Ave
classroom furniture, cafeteria furniture, and air
conditioning units. no new items have been
purchased, so basically the technology is
outdated as well as the classroom furniture etc.
34/43
SCA
Renovate other site
Construct the Stevenson High School Performing
1980
component
Arts and Recreation Center. Build the proposed
LAFAYETTE
center earmarked for this school.
AVENUE
35/43
SCA
Renovate other site
Construct a Recreational Facility Adjacent to I.S.
component
174X. This junior high school is heavily
populated and in need of an outside
recreational facility adjacent to designated
parkland (Pugsley Creek Park).
36/43
SCA
Provide a new or
Construct P.S. 47 Mini School. There is severe
expand an existing
overcrowding at this school.
elementary school
37/43
SCA
Renovate other site
Design and fund a connecting, sheltered Breeze-
component
Way between the permanent and temporary
structure which will ensure the safety of the
children from grades K-3 of P.S 69.
40/43
SCA
Provide a new or
Construct an Annex to the Existing Building for
expand an existing
Additional Classroom Space at PS 119. This
elementary school
school is presently greatly overcrowded and
additional classroom space is required.
42/43
SCA
Provide a new or
Construct an annex to the existing PS 138X
expand an existing
building, for additional classroom space. This
elementary school
school is at capacity and even with rezoning the
neighborhood schools are at full utilization. This
overcrowded condition is seriously impacting on
the educational environment.
43/43
SCA
Provide a new or
Allocate Funding for a Feasibility Study to
expand an existing
Develop an Elementary School Within
elementary school
Community District 9, in School District 12.
There is a severe need to reduce area
overcrowding in the schools within Community
District 9, in School District 12.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
25/36 DYCD Provide, expand, or
enhance Cornerstone and Beacon programs (all ages, including young adults)
Identify Monies to Reinstitute Beacon Schools in Community Board Nine's District. We Are One of Largest Community Districts Within the Bronx and Many Areas Do Not Presently Have Any Services for Our Youth. To prevent crime and insure leadership development, additional Beacon Schools should be funded.
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 9
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
We need to reform this department to help us with critical traffic issues other than ticket blitzing . We request a meeting the Bronx Traffic Enforcement Commanding Officer.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Tracking  request for new psa 8 police station. We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new process.
Needs for Emergency Services
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
2/43 NYPD Provide a new NYPD
facility, such as a new precinct house or sub-precinct
Construct a Site for PSA8, NYCHA. This item, after several public hearings, was deemed more appropriately located at New York City Housing Authority - Bronx River Houses. We were advised that NYCHA was requested to renovate the Justice Sonia Sotomayor Houses (formerly Bronxdale Houses) old Community Center for use as a PSA. NYCHA is working to obtain preliminary Community Board approval and is preparing zoning overrides for mayoral approval prior to ULURP submission to Dept. of City Planning for certification.
image
41/43 FDNY Rehabilitate or
renovate existing fire houses or EMS stations
Engine 64 & Ladder 47 both need new fire house doors. Also Engine 96 & Ladder 54 need new windows.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
8/36
NYPD
Provide resources to
The NCO Program is vital and we need to double
train officers, e.g. in
NCO officers.
community policing
10/36
NYPD
Provide additional
2 vans is needed for transport PSA 8 officers.
patrol cars and
Additional equipment needed: 2 unmarked
other vehicles
vehicles.
11/36
NYPD
Assign additional
The NYCHA-PSA 8 needs 45 additional police
housing police
officers and 5 civilian employees.
officers
12/36
NYPD
Provide additional
Provide Equipment for the 43rd Precinct.
patrol cars and
Request 1 ATV (all-terrain vehicle) for the
other vehicles
precinct. This vehicle is needed to travel within
our parklands, vacant lots and other
undeveloped dirt surfaces that the patrol cars
cannot access in emergency situations. Also, we
are requesting 14 new Radio Motor Patrol Cars
with mobile data computers.
13/36 NYPD Other NYPD staff
resources requests
The 43 Pct needs more PAAs (4)
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 9
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
Needs for Sanitation Services
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
45/43 DSNY Provide new or
upgrade existing sanitation garages or other sanitation infrastructure
The Department of Sanitation Requests Funds to Move to a New (Garage) Building on Zerega Avenue. The building they are currently in is not structurally sound and is condemned.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 9
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Condition of public housing
We created a NYCHA Committee and we are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
We would like city Planning to start a zoning initiative with our Community Board. (197 Plan)
Needs for Housing
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
Needs for Economic Development
Our Community Board has recently established a Economic Development Committee and looking to strengthen this portion of the District Needs in the Next FY.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
10/43
EDC
Invest in capital
We request that Westchester Creek widened
projects to improve
(dredged) . This will enable full size barges to
access to the
pass.
waterfront
21/43
NYCHA
Install security
We need upgraded cameras in all NYCHA
cameras or make
Buildings in our district
other safety
upgrades (Capital)
33/43
HPD
Other affordable
Adequate funding is needed to rehabilitate
housing programs
privately owned housing stock through such
requests (capital)
programs as Article 8A Program, the
Participation Loan Program and the Home
Improvement Program.
44/43
NYCHA
Install security
Monroe Houses Requests That Additional Funds
cameras or make
be Allocated to Install Security Cameras Within
other safety
Their Development. The additional cameras
upgrades (Capital)
would help lower crime within this
development.
46/43
NYCHA
Other public
Monroe Houses Requests that a Capital Project
housing upgrades or
Be Created Which Would Improve Their
renovations
Infrastructure, Walkways and Paths. The current
requests
infrastructure of Monroe Houses is damaged
and needs to be repaired.
47/43
NYCHA
Renovate or
Renovate Justice Sonia Sotomayor Houses
upgrade NYCHA
Community Center as a PSA8. We originally
community facilities
requested that the NYPD construct a new PSA
or open space
but we were advised that NYCHA was requested
to renovate the Justice Sonia Sotomayor Houses
(formerly Bronxdale Houses) old Community
Center for use as a PSA. NYCHA is working to
obtain preliminary Community Board approval
and is preparing zoning overrides for mayoral
approval prior to ULURP submission to Dept. of
City Planning for certification.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
2/36
DCP
Study land use and
We would like to start a zoning initiative to
zoning to better
modify zoning in the west and north parts of our
match current use
district. During the last year we have completed
or future
community vision sessions and focus groups
neighborhood
throughout out our district and want to take the
needs
next step to change zoning for our future needs.
33/36
EDC
Other public
Continue Senior Resident Advisor Program. This
housing
program prevents unnecessary
maintenance,
institutionalization of the elderly and provides
staffing and
24 hour staffing for crisis intervention and
management
emergencies. Services are provided by trained
requests
paraprofessionals and part-time professionals.
39/36
EDC
Improve public
Bronx River Houses requests sweepers be
housing
purchased to offset and improve work
maintenance and
performance within their facility. They have lost
cleanliness
personnel over a period of several years and
stated that the bobcat would improve cleanup
and maintenance of their facility.
43/36
HPD
Other affordable
We are in need of a study to review possible
housing programs
affordable housing programs in our district.
requests (expense)
46/36
EDC
Other public
Create a tenant protection unit
housing
maintenance,
staffing and
management
requests
TRANSPORTATION
Bronx Community Board 9
image
M ost Important Issue Related to Transportation and Mobility
Parking operations
We need to develop a better to increase and sustain parking. Especially , near the Soundview ferry. Our city should mark parking spots with white lines, like other municipalities. This would increase parking. Furthermore, While nearly two thirds of residents in Community Board 9 rely on public transportation to get to work, there is only one subway line in the district and a significant portion of households are further than a mile from a subway stop.
Further, there are no subway stops in the district that are accessible by elevator, making a subway commute difficult or impossible for wheelchair users and other residents who have difficulty with stairs. Because the subway is out of walking distance for many commuters, bus service serves a critical role in the community. The district is served by several local and express bus routes, and many have seen increasing ridership and decreasing performance in recent years. For example, according to MTA data from 2015, the Bx36 route has the fifth highest ridership in the Bronx.
This route experiences a significant amount of bus “bunching,” when two buses arrive at a stop simultaneously because of delays. In 2015,Bx36 arrived in bunches 14.5% of the time. Two bus routes, the Bx39 and Bx27, provide service to the upcoming Soundview ferry stop. Both of these lines have seen increased ridership since 2010: a 12.5% increase on the Bx39 and a 10.1% increase on the Bx27. The Bx39 has had some service issues; for example, currently 10.9% of buses arrive at their stop bunched. Crowding and delays could be exacerbated when the ferry opens due to increased demand. Finally, community members have brought up quality-of-life issues related to bus service in the district. Community members are concerned about bus cleanliness and maintenance of fabric seats. Another concern is pedestrian safety, especially when buses stop outside of designated areas or block crosswalks, blocking pedestrians’ view of oncoming traffic and walk signals. Finally, buses sometimes cut through residential streets rather than turning around in designated areas, bringing noise and safety issues to these streets.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Community Board 9 has the largest district in The Bronx with nearly 200,000 residents and geographically 5 square miles. The most congested corridor, the Cross Bronx Expressway in located in our CB. In Addition, other major arteries such as the Sheridan Expressway, Bruckner Expressway, Bronx River Parkway and Hutch Parkway contribute to thousands of vehicles utilizing our district, thus effecting our traffic and transportation infrastructure.
Needs for Transit Services
Bronx Community Board 9 residents rely heavily on public transportation, and providing high-quality transit services will connect residents with needed opportunities. According to the 2013 5-year American Community Survey, 62.3% of CB9 residents primarily use public transit services to get to work. This is higher than the city average of 55.9%.
Additionally, the commute time for the working population is longer than the city average, 44.7 minutes compared to 39.2. At the same time, CB9 faces higher poverty and unemployment rates compared to the city as a whole. The poverty rate in the district is 28.4% compared to the city average of 20.3%. The unemployment rate is 13.5% compared to the city average of 10.6%. To address this discrepancy, better transit services are needed to connect residents with job opportunities both within and outside of the district. Finally, better transit services are needed to serve residents with disabilities. 11.9% of the district’s population has a disability, compared to 10.3% in NYC, and many of these residents may rely on public transportation for commutes and other traveling needs. Combined with the senior population and those approaching senior status, there is a significant portion of the population that requires high-quality transit service to meet basic needs.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/43
DOT
Reconstruct streets
the South end of CB9 was constructed over
swamp land and many streets are sinking and
are in great need of Reconstruction. Ex. White
Plains Road, Stick Ball Blvd, Lafayette Ave,
Boynton Ave, etc.
6/43
DOT
Other
Close Ave between Bruckner Blvd & Story is
Close Ave
transportation
closed illegally by man made gates. We request
Story ave
infrastructure
this street to be reopened and sidewalks
Bruckner Blvd
requests
installed for safety and improve traffic flow.
8/43
DOT
Other
We are requesting that the city re-visit the
transportation
constructing two Bridges for vehicles in CB9.
infrastructure
One on west side and east side of our district
requests
connecting to current city streets. Ex. Story and
Lafayette ave, to help relive traffic conditions
9/43
DOT
Repair or construct
We want to see every bus stop have concrete
new medians or bus
pads.
pads
14/43
NYCTA
Improve
Parkchester Train Station is one of the busiest
accessibility of
train stations in the Bronx, serving thousands or
transit
seniors and disabled individuals. We need a
infrastructure, by
elevator at this site.
providing elevators,
escalators, etc.
15/43
DOT
Repair or construct
Construct Sidewalks on Metcalf Avenue
Metcalf Ave
new curbs or
Between Watson and Westchester Avenues.
Watson Ave
pedestrian ramps
Construction of sidewalks on Metcalf Avenue,
Westchester
adjacent to the Bronx River Parkway, are
Ave
needed because residents must walk in the
street and it is dangerous.
16/43
DOT
Improve traffic and
White Plains Road & Bruckner Blvd is a very
White Plains
pedestrian safety,
dangerous intersection. A new Public School is
Road
including traffic
being constructed and set to be completed in
Bruckner Blvd
calming (Capital)
school year 2018. We are requesting a study
Watson Ave
and improvements for traffic and pedestrian
safety at this intersection. Ex. Delayed Green for
Pedestrians, additional cross walks, crossing
guards, etc.
26/43
NYCTA
Repair or upgrade subway stations or other transit infrastructure
We would like to see every bus stop in our district to have a bus shelter installed where possible, for the safety of our residents.
27/43
DOT
Other
Construct Bolton Avenue (from Gildersleeve
Bolton Ave
transportation
Avenue to O'Brien Avenue). Requires
Gildersleeve
infrastructure
development/creation of Bolton Avenue to
Ave O'Brien
requests
include sewers, curbs, catch basins, street lights,
Ave
street signs (black top, asphalt). The Parks
Department is now prepared to start the
development of Harding Park. Sidewalks and
lights are required for public access.
29/43
DOT
Reconstruct streets
We Request the Reconstruction of the following
Streets: Lafayette Avenue from Thieriot Avenue
to Castle Hill Avenue; White Plains Road from
Seward Avenue to Lafayette Avenue; Newman
Avenue from Lafayette Avenue to Randall
Avenue; White Plains Road from Bruckner Blvd
to Lafayette Avenue and Castle Hill Avenue to
White Plains Road. The road conditions
presently are dangerous and hazardous. While
repairs have been made they have the longevity
of no more than 5 years.
30/43
DOT
Repair or provide
Allocate Funds for Additional Lighting. Request
Close Ave and
new street lights
funds for additional lighting to be placed at
Bruckner Blvd
Close Avenue and Bruckner Boulevard adjacent
to the planned Close Avenue Playground.
31/43
DOT
Reconstruct streets
Reconstruct Streets & Sewers in the Clason Point
Newman Ave
Area (Newman Avenue from Soundview Avenue
Soundview
to Compton Avenue). Construction of streets &
Ave Compton
of sewers is needed for this area and the
Ave
adjacent streets.
38/43
DOT
Improve traffic and
We Request that Center Islands be Erected at:
White Plains
pedestrian safety,
White Plains Road, from Lafayette to O'brien
Road
including traffic
Avenue: Randall Avenue, from White Plains
Lafayette Ave
calming (Capital)
Road to Olmstead Avenue; Lafayette Avenue
O'Brien Ave
from Bolton Avenue to Metcalf Avenue; Story
Avenue to Seward Avenue. To ensure the safety
of the general public and address present traffic
conditions.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/36
NYCTA
Improve bus
We have received many complaints of the buses
cleanliness, safety
not being clean. Also received complaints that
or maintenance
the cloth chairs are unsanitary. Moreover, the
buses on the BX05 are old buses.
5/36
DOT
Address traffic
The intersection of Bruckner Blvd and Bronx
Bronx River
congestion
River Ave is gridlocked during rush hour.
Ave Story ave
Effecting traffic flow on story ave and streets in
Bruckner Blvd
vicinity. Residents are forced to walk to train
station because buses cant move in traffic. We
request this issue be addressed.
6/36
NYCTA
Expand bus service
We have received hundreds of complaints a year
frequency or hours
in ref to the inadequacy of service on this bus
of operation
line. During rush hours the buses are full of
riders and residents can not use this service line
and are forced to walk to work. In addition, the
service does not run after a certain time and
residents can not utilize this bus line during the
late hours. We need additional buses on this line
during rush hour.
7/36
DOT
Conduct traffic or
The intersection of Bruckner Blvd and Bronx
Bronx River
parking studies
River Ave is gridlocked during rush hour. We
Ave Bruckner
request a traffic study to be conducted at this
Blvd Bronx
intersection and surrounding streets.
River Parkway
14/36
NYCTA
Improve subway
The Parkchester Train Station was renovated a
station or train
few years ago. We have seen some issues with
cleanliness, safety
graffiti, station cleanliness and bathroom
and maintenance
maintenance. The escalator, windows, lamps,
etc need to be cleaned periodically. The
escalator looks like its never been cleaned. We
want to make sure this stations beauty is
maintained.
15/36
NYCTA
Expand subway
The number 6 train line is a very busy line in the
service frequency or
heart of our district. We have seen numerous
hours of operations
issues with service frequency.
16/36
NYCTA
Provide a new bus
We have the need to create a new service line
service or Select Bus
along with the BX05 bus line and/or on Bruckner
Service
Blvd.
17/36
DOT
Conduct traffic or
The intersection of Story Ave Bronx River Ave is
Story Ave
parking studies
gridlocked during rush hour. We request a traffic
Bronx River
study to be conducted on story ave.
Ave Metcalf
Ave
18/36
DOT
Other expense
Allocate Funds for a Traffic Study to Install
Castle Hill Ave
traffic
Traffic Devices on Castle Hill Avenue from E.
E. Tremont
improvements
Tremont Avenue to Zerega Avenue. There is a
Ave Zerega
requests
need for this due to an increased amount of
Ave
vehicular traffic on Castle Hill Avenue.
19/36
DOT
Other expense
Request a Traffic Study of the Cross Bronx
traffic
Expressway Service Road From Castle Hill
improvements
Avenue to Bronx River Avenue; and to Include
requests
Nobel Avenue from the Cross Bronx Expressway
Service Road to Mansion Street. Traffic
conditions are dangerous and hazardous and
cannot be addressed solely by the monitoring of
the 43rd Precinct.
20/36
DOT
Other expense
Allocate Funding to Conduct a Traffic Study of
traffic
Unionport, Castle Hill, Soundview and the Bronx
improvements
River Communities. There is a need for
requests
additional traffic signals or devices to alleviate
the high volume of vehicular traffic and
speeding.
22/36
DOT
Other expense
We Request that a Traffic Study be Conducted at
Castle Hill Ave
traffic
Castle Hill Avenue from Westchester Avenue to
Westchester
improvements
Bruckner Blvd, Which Would Include the
Ave Bruckner
requests
Bruckner Service Road (North and South from
Blvd
Zerega Avenue to Bronx River Avenue). Traffic
conditions are dangerous and hazardous and
cannot be addressed soley by the monitoring of
the 43rd Precinct.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 9
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Community board resources (offices, staff and equipment)
Community Board nine is the largest in the Bronx with nearly 200,000 residents. We need more resources , staff and larger office.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
Needs for Cultural Services
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
Needs for Library Services
We are currently re-evaluating and updating our needs and budget request. In addition to what the Board is submitting now ,a more comprehensive report will be submitted next fiscal year that will be better formatted for this new submission process.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/43
DCAS
Renovate, upgrade
Resources needed for community board office.
or provide new
We are moving into a new office and need
community board
upgraded equipment.
facilities and
equipment
4/43
DPR
Reconstruct or
We need this park upgraded to be conducive to
upgrade a park or
the new Soundview ferry operation.
amenity (i.e.
playground, outdoor
athletic field)
7/43
DPR
Reconstruct or
We need to upgrade this park, its underutilized.
upgrade a park or
We have started talk in our committee with
amenity (i.e.
some ideas.
playground, outdoor
athletic field)
11/43
DPR
Reconstruct or
The facilities in the park haven't been renovated
upgrade a park or
for over a decade. The paint is wearing off on
amenity (i.e.
the playground. There isn't any park personnel
playground, outdoor
to maintain park regulations. The bathrooms
athletic field)
are always locked but the park stays open
attracting loafers. This park is greatly utilized by
many families and children during the
summertime; however, it lacks amenities
considering the large size of the park. The
families and children deserve a remodeled park.
12/43
DPR
Reconstruct or
This park is greatly utilized by families in the
upgrade a park or
neighborhood to play volleyball and to relax on
amenity (i.e.
the benches; however, the current park is just an
playground, outdoor
open space. We request that the Parks
athletic field)
Department look into upgrading the amenities
to adapt to the current usage.
13/43
DCAS
Renovate, upgrade
During the past 20 years, Community Board 9
or provide new
has grown in size in its membership, committees
community board
and community meeting participants. This
facilities and
indication that the people who live and work in
equipment
my Senatorial District are becoming more active
in our local government within Community
Board 9 requires greater space to accommodate
their demands, projects and agendas. A larger
office will provide Community Board 9 with the
necessary space to meet the existing growing
needs.
17/43
DPR
Reconstruct or
Request: Construct a Cricket Field in Soundview
upgrade a park or
Park and other Parks in the District which are
amenity (i.e.
suitable for housing Cricket Fields. Explanation:
playground, outdoor
As a result of the growing South Asian and East
athletic field)
Indian populations in the district there is a
growing need for suitable facilities to
accommodate the popular sport of Cricket.
There has been a great expansion of league play
and it is important that suitable fields are
available for recreation.
18/43
NYPL
Create a new, or
$725,000 ADA elevator: this 1985 branch will
renovate or upgrade
replace the current outdated elevator and sure
an existing public
it is compliant with ADA regulations. $1,700,000
library
boiler: this project will replace the current boiler
with an energy efficient model this will make
the building more energy-efficient by reducing
energy consumption and greenhouse gas in
missions. A new boiler will ensure that the
library is adequate heated during the colder
months. HVAC. This project will replace the
HVAC system of energy efficient model. This is
an existing project I need supplemental funding.
NY PL branches are designated NYC office of
emergency management cooling centers. They
provide cool and safe environment for patrons
and community members. During periods of
extensive heat
19/43
NYPL
Create a new, or
300,000 supplemental request - HVAC. This
renovate or upgrade
project will replace the HVAC system with an
an existing public
energy efficient model. This is an existing
library
project that need supplemental funding. NYPL
branches are designated New York City office of
emergency management cooling centers. They
provide cool and safe environment for patrons
and community members during periods of
extensive heat.
20/43
NYPL
Create a new, or
$300,000 - Boiler : This project will replace the
renovate or upgrade
current boiler with an energy efficient model.
an existing public
library
22/43
NYPL
Create a new, or
$1,500,000 Exterior Request: This branch is in
renovate or upgrade
need of an exterior upgrade which will enhance
an existing public
the patron experience the repairs will beautify
library
the branches exterior parents and ensure the
comfort of staff and patrons inside.
28/43
DPR
Provide a new, or new expansion to, a building in a park
Funding for a Study to Construct and Fund a Recreational Facility in El Parque de los Ninos. Number one priority to address the needs of the constituents of Bronx River and Soundview.
Presently, there are two facilities dedicated within this Community Board which address the needs of our youth and residents and they are the YMCA (located at 2 Castle Hill Avenue) and the Kips Bay Boys and Girls Club (located on Randall Avenue and White Plains Road) and they have presently over 7,000 registered clients at each of these facilities. There are no facilities of this type within the aforementioned Bronx River/Soundview Neighborhood. It was a sentiment of those testiying that a facility of this type would help address the afterschool recreational and educational needs of
32/43
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Allocate Funds to Complete Phase II of Soundview Park. The first phase of Soundview Park has been completed. We want to develop plans for the area south of Randall Avenue between Bronx River Avenue and the Bronx River.
CS
DPR
Plant new street trees
Plant Trees in the Neighborhood Strategy Area- NSA (15 Trees Per Block, 20 Blocks Per Year). The Department of Parks and Recreation will contract out and oversee the planting of 15 trees per block, along 20 blocks.
CS
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Harding Park Playground has not been upgraded since it was constructed in 1999. We would like to see this Park renovated.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
1/36 OMB Provide more
community board staff
We serve nearly 200,000 residents making us the largest in the Bronx. we need more staff and budget for hiring and more resources.
image
24/36 DPR Other requests for
park, building, or access improvements
Fund Feasibility Study to Create a Passive Recreation Area for the Existing Starlite Park. Request Starlite Park to become a passive park for people in the area to enjoy.
26/36
DPR
New equipment for maintenance (Expense)
Allocate Parks Equipment for the M & O and Recreation Divisions. Need a grass cutting tracker and pickup trucks for the Community Board 9 area.
27/36
DPR
Forestry services,
Restore Tree Pruning and Stump Removal
including street tree
Programs. Trees are in dire need of care.
maintenance
28/36
DPR
Other park
Restore Parks Department Personnel for M & O
maintenance and
and Recreation Divisions. Personnel urgently
safety requests
needed to adequately maintain and supervise
parks and playgrounds.
30/36
NYPL
Extend library hours
THE NYPL receive the additional baseline
or expand and
funding of $18,860 and the fiscal year 2017 city
enhance library
budget. The full restoration and baseline of
programs
expense funding in the cities FY 2017 budget will
allow the New York public library to maintain
the increase in hours from 46 to 50 weekly. We
want to maintain and increase this funding.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/43
DCAS
Renovate, upgrade
Resources needed for community board office.
or provide new
We are moving into a new office and need
community board
upgraded equipment.
facilities and
equipment
2/43
NYPD
Provide a new NYPD
Construct a Site for PSA8, NYCHA. This item,
facility, such as a
after several public hearings, was deemed more
new precinct house
appropriately located at New York City Housing
or sub-precinct
Authority - Bronx River Houses. We were
advised that NYCHA was requested to renovate
the Justice Sonia Sotomayor Houses (formerly
Bronxdale Houses) old Community Center for
use as a PSA. NYCHA is working to obtain
preliminary Community Board approval and is
preparing zoning overrides for mayoral
approval prior to ULURP submission to Dept. of
City Planning for certification.
3/43
SCA
Provide technology
I am attaching the technology request for
1980
upgrade
(APPA) )08X376. They are also in need of
Lafayette Ave
classroom furniture, cafeteria furniture, and air
conditioning units. no new items have been
purchased, so basically the technology is
outdated as well as the classroom furniture etc.
4/43
DPR
Reconstruct or
We need this park upgraded to be conducive to
upgrade a park or
the new Soundview ferry operation.
amenity (i.e.
playground, outdoor
athletic field)
5/43
DOT
Reconstruct streets
the South end of CB9 was constructed over
swamp land and many streets are sinking and
are in great need of Reconstruction. Ex. White
Plains Road, Stick Ball Blvd, Lafayette Ave,
Boynton Ave, etc.
6/43
DOT
Other
Close Ave between Bruckner Blvd & Story is
Close Ave
transportation
closed illegally by man made gates. We request
Story ave
infrastructure
this street to be reopened and sidewalks
Bruckner Blvd
requests
installed for safety and improve traffic flow.
7/43
DPR
Reconstruct or
We need to upgrade this park, its underutilized.
upgrade a park or
We have started talk in our committee with
amenity (i.e.
some ideas.
playground, outdoor
athletic field)
8/43
DOT
Other
We are requesting that the city re-visit the
transportation
constructing two Bridges for vehicles in CB9.
infrastructure
One on west side and east side of our district
requests
connecting to current city streets. Ex. Story and
Lafayette ave, to help relive traffic conditions
9/43
DOT
Repair or construct
We want to see every bus stop have concrete
new medians or bus
pads.
pads
10/43
EDC
Invest in capital
We request that Westchester Creek widened
projects to improve
(dredged) . This will enable full size barges to
access to the
pass.
waterfront
11/43
DPR
Reconstruct or
The facilities in the park haven't been renovated
upgrade a park or
for over a decade. The paint is wearing off on
amenity (i.e.
the playground. There isn't any park personnel
playground, outdoor
to maintain park regulations. The bathrooms
athletic field)
are always locked but the park stays open
attracting loafers. This park is greatly utilized by
many families and children during the
summertime; however, it lacks amenities
considering the large size of the park. The
families and children deserve a remodeled park.
12/43
DPR
Reconstruct or
This park is greatly utilized by families in the
upgrade a park or
neighborhood to play volleyball and to relax on
amenity (i.e.
the benches; however, the current park is just an
playground, outdoor
open space. We request that the Parks
athletic field)
Department look into upgrading the amenities
to adapt to the current usage.
13/43
DCAS
Renovate, upgrade
During the past 20 years, Community Board 9
or provide new
has grown in size in its membership, committees
community board
and community meeting participants. This
facilities and
indication that the people who live and work in
equipment
my Senatorial District are becoming more active
in our local government within Community
Board 9 requires greater space to accommodate
their demands, projects and agendas. A larger
office will provide Community Board 9 with the
necessary space to meet the existing growing
needs.
14/43
NYCTA
Improve
Parkchester Train Station is one of the busiest
accessibility of
train stations in the Bronx, serving thousands or
transit
seniors and disabled individuals. We need a
infrastructure, by
elevator at this site.
providing elevators,
escalators, etc.
15/43
DOT
Repair or construct
Construct Sidewalks on Metcalf Avenue
Metcalf Ave
new curbs or
Between Watson and Westchester Avenues.
Watson Ave
pedestrian ramps
Construction of sidewalks on Metcalf Avenue,
Westchester
adjacent to the Bronx River Parkway, are
Ave
needed because residents must walk in the
street and it is dangerous.
16/43
DOT
Improve traffic and
White Plains Road & Bruckner Blvd is a very
White Plains
pedestrian safety,
dangerous intersection. A new Public School is
Road
including traffic
being constructed and set to be completed in
Bruckner Blvd
calming (Capital)
school year 2018. We are requesting a study
Watson Ave
and improvements for traffic and pedestrian
safety at this intersection. Ex. Delayed Green for
Pedestrians, additional cross walks, crossing
guards, etc.
17/43
DPR
Reconstruct or
Request: Construct a Cricket Field in Soundview
upgrade a park or
Park and other Parks in the District which are
amenity (i.e.
suitable for housing Cricket Fields. Explanation:
playground, outdoor
As a result of the growing South Asian and East
athletic field)
Indian populations in the district there is a
growing need for suitable facilities to
accommodate the popular sport of Cricket.
There has been a great expansion of league play
and it is important that suitable fields are
available for recreation.
18/43
NYPL
Create a new, or
$725,000 ADA elevator: this 1985 branch will
renovate or upgrade
replace the current outdated elevator and sure
an existing public
it is compliant with ADA regulations. $1,700,000
library
boiler: this project will replace the current boiler
with an energy efficient model this will make
the building more energy-efficient by reducing
energy consumption and greenhouse gas in
missions. A new boiler will ensure that the
library is adequate heated during the colder
months. HVAC. This project will replace the
HVAC system of energy efficient model. This is
an existing project I need supplemental funding.
NY PL branches are designated NYC office of
emergency management cooling centers. They
provide cool and safe environment for patrons
and community members. During periods of
extensive heat
19/43
NYPL
Create a new, or
300,000 supplemental request - HVAC. This
renovate or upgrade
project will replace the HVAC system with an
an existing public
energy efficient model. This is an existing
library
project that need supplemental funding. NYPL
branches are designated New York City office of
emergency management cooling centers. They
provide cool and safe environment for patrons
and community members during periods of
extensive heat.
20/43
NYPL
Create a new, or
$300,000 - Boiler : This project will replace the
renovate or upgrade
current boiler with an energy efficient model.
an existing public
library
21/43
NYCHA
Install security
We need upgraded cameras in all NYCHA
cameras or make
Buildings in our district
other safety
upgrades (Capital)
22/43
NYPL
Create a new, or
$1,500,000 Exterior Request: This branch is in
renovate or upgrade
need of an exterior upgrade which will enhance
an existing public
the patron experience the repairs will beautify
library
the branches exterior parents and ensure the
comfort of staff and patrons inside.
26/43
NYCTA
Repair or upgrade
We would like to see every bus stop in our
subway stations or
district to have a bus shelter installed where
other transit
possible, for the safety of our residents.
infrastructure
27/43
DOT
Other
Construct Bolton Avenue (from Gildersleeve
Bolton Ave
transportation
Avenue to O'Brien Avenue). Requires
Gildersleeve
infrastructure
development/creation of Bolton Avenue to
Ave O'Brien
requests
include sewers, curbs, catch basins, street lights,
Ave
street signs (black top, asphalt). The Parks
Department is now prepared to start the
development of Harding Park. Sidewalks and
lights are required for public access.
28/43
DPR
Provide a new, or new expansion to, a building in a park
Funding for a Study to Construct and Fund a Recreational Facility in El Parque de los Ninos. Number one priority to address the needs of the constituents of Bronx River and Soundview.
Presently, there are two facilities dedicated within this Community Board which address the needs of our youth and residents and they are the YMCA (located at 2 Castle Hill Avenue) and the Kips Bay Boys and Girls Club (located on Randall Avenue and White Plains Road) and they have presently over 7,000 registered clients at each of these facilities. There are no facilities of this type within the aforementioned Bronx River/Soundview Neighborhood. It was a sentiment of those testiying that a facility of this type would help address the afterschool recreational and educational needs of
29/43
DOT
Reconstruct streets
We Request the Reconstruction of the following Streets: Lafayette Avenue from Thieriot Avenue to Castle Hill Avenue; White Plains Road from Seward Avenue to Lafayette Avenue; Newman Avenue from Lafayette Avenue to Randall Avenue; White Plains Road from Bruckner Blvd to Lafayette Avenue and Castle Hill Avenue to White Plains Road. The road conditions presently are dangerous and hazardous. While repairs have been made they have the longevity of no more than 5 years.
30/43
DOT
Repair or provide new street lights
Allocate Funds for Additional Lighting. Request funds for additional lighting to be placed at Close Avenue and Bruckner Boulevard adjacent to the planned Close Avenue Playground.
Close Ave and Bruckner Blvd
31/43
DOT
Reconstruct streets
Reconstruct Streets & Sewers in the Clason Point Area (Newman Avenue from Soundview Avenue to Compton Avenue). Construction of streets & of sewers is needed for this area and the adjacent streets.
Newman Ave Soundview Ave Compton Ave
32/43
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Allocate Funds to Complete Phase II of Soundview Park. The first phase of Soundview Park has been completed. We want to develop plans for the area south of Randall Avenue between Bronx River Avenue and the Bronx River.
33/43
HPD
Other affordable
Adequate funding is needed to rehabilitate
housing programs
privately owned housing stock through such
requests (capital)
programs as Article 8A Program, the
Participation Loan Program and the Home
Improvement Program.
34/43
SCA
Renovate other site
Construct the Stevenson High School Performing
1980
component
Arts and Recreation Center. Build the proposed
LAFAYETTE
center earmarked for this school.
AVENUE
35/43
SCA
Renovate other site
Construct a Recreational Facility Adjacent to I.S.
component
174X. This junior high school is heavily
populated and in need of an outside
recreational facility adjacent to designated
parkland (Pugsley Creek Park).
36/43
SCA
Provide a new or
Construct P.S. 47 Mini School. There is severe
expand an existing
overcrowding at this school.
elementary school
37/43
SCA
Renovate other site
Design and fund a connecting, sheltered Breeze-
component
Way between the permanent and temporary
structure which will ensure the safety of the
children from grades K-3 of P.S 69.
38/43
DOT
Improve traffic and
We Request that Center Islands be Erected at:
White Plains
pedestrian safety,
White Plains Road, from Lafayette to O'brien
Road
including traffic
Avenue: Randall Avenue, from White Plains
Lafayette Ave
calming (Capital)
Road to Olmstead Avenue; Lafayette Avenue
O'Brien Ave
from Bolton Avenue to Metcalf Avenue; Story
Avenue to Seward Avenue. To ensure the safety
of the general public and address present traffic
conditions.
40/43
SCA
Provide a new or
Construct an Annex to the Existing Building for
expand an existing
Additional Classroom Space at PS 119. This
elementary school
school is presently greatly overcrowded and
additional classroom space is required.
41/43
FDNY
Rehabilitate or
Engine 64 & Ladder 47 both need new fire
renovate existing
house doors. Also Engine 96 & Ladder 54 need
fire houses or EMS
new windows.
stations
42/43
SCA
Provide a new or
Construct an annex to the existing PS 138X
expand an existing
building, for additional classroom space. This
elementary school
school is at capacity and even with rezoning the
neighborhood schools are at full utilization. This
overcrowded condition is seriously impacting on
the educational environment.
43/43
SCA
Provide a new or
Allocate Funding for a Feasibility Study to
expand an existing
Develop an Elementary School Within
elementary school
Community District 9, in School District 12.
There is a severe need to reduce area
overcrowding in the schools within Community
District 9, in School District 12.
44/43
NYCHA
Install security
Monroe Houses Requests That Additional Funds
cameras or make
be Allocated to Install Security Cameras Within
other safety
Their Development. The additional cameras
upgrades (Capital)
would help lower crime within this
development.
45/43
DSNY
Provide new or
The Department of Sanitation Requests Funds to
upgrade existing
Move to a New (Garage) Building on Zerega
sanitation garages
Avenue. The building they are currently in is not
or other sanitation
structurally sound and is condemned.
infrastructure
46/43
NYCHA
Other public
Monroe Houses Requests that a Capital Project
housing upgrades or
Be Created Which Would Improve Their
renovations
Infrastructure, Walkways and Paths. The current
requests
infrastructure of Monroe Houses is damaged
and needs to be repaired.
47/43
NYCHA
Renovate or
Renovate Justice Sonia Sotomayor Houses
upgrade NYCHA
Community Center as a PSA8. We originally
community facilities
requested that the NYPD construct a new PSA
or open space
but we were advised that NYCHA was requested
to renovate the Justice Sonia Sotomayor Houses
(formerly Bronxdale Houses) old Community
Center for use as a PSA. NYCHA is working to
obtain preliminary Community Board approval
and is preparing zoning overrides for mayoral
approval prior to ULURP submission to Dept. of
City Planning for certification.
CS
DPR
Plant new street
Plant Trees in the Neighborhood Strategy Area-
trees
NSA (15 Trees Per Block, 20 Blocks Per Year). The
Department of Parks and Recreation will
contract out and oversee the planting of 15
trees per block, along 20 blocks.
CS
DPR
Reconstruct or
Harding Park Playground has not been
upgrade a park or
upgraded since it was constructed in 1999. We
amenity (i.e.
would like to see this Park renovated.
playground, outdoor
athletic field)
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/36
OMB
Provide more
We serve nearly 200,000 residents making us
community board
the largest in the Bronx. we need more staff and
staff
budget for hiring and more resources.
2/36
DCP
Study land use and
We would like to start a zoning initiative to
zoning to better
modify zoning in the west and north parts of our
match current use
district. During the last year we have completed
or future
community vision sessions and focus groups
neighborhood
throughout out our district and want to take the
needs
next step to change zoning for our future needs.
3/36
HHC
Provide a new or
The Jacobi Hospital ER Fast Track unit must be a
expanded health
24 hour facility. T
care facility
4/36
NYCTA
Improve bus
We have received many complaints of the buses
cleanliness, safety
not being clean. Also received complaints that
or maintenance
the cloth chairs are unsanitary. Moreover, the
buses on the BX05 are old buses.
5/36
DOT
Address traffic
The intersection of Bruckner Blvd and Bronx
Bronx River
congestion
River Ave is gridlocked during rush hour.
Ave Story ave
Effecting traffic flow on story ave and streets in
Bruckner Blvd
vicinity. Residents are forced to walk to train
station because buses cant move in traffic. We
request this issue be addressed.
6/36
NYCTA
Expand bus service
We have received hundreds of complaints a year
frequency or hours
in ref to the inadequacy of service on this bus
of operation
line. During rush hours the buses are full of
riders and residents can not use this service line
and are forced to walk to work. In addition, the
service does not run after a certain time and
residents can not utilize this bus line during the
late hours. We need additional buses on this line
during rush hour.
7/36
DOT
Conduct traffic or
The intersection of Bruckner Blvd and Bronx
Bronx River
parking studies
River Ave is gridlocked during rush hour. We
Ave Bruckner
request a traffic study to be conducted at this
Blvd Bronx
intersection and surrounding streets.
River Parkway
8/36
NYPD
Provide resources to
The NCO Program is vital and we need to double
train officers, e.g. in
NCO officers.
community policing
10/36
NYPD
Provide additional patrol cars and other vehicles
2 vans is needed for transport PSA 8 officers. Additional equipment needed: 2 unmarked vehicles.
11/36
NYPD
Assign additional
The NYCHA-PSA 8 needs 45 additional police
housing police
officers and 5 civilian employees.
officers
12/36
NYPD
Provide additional
Provide Equipment for the 43rd Precinct.
patrol cars and
Request 1 ATV (all-terrain vehicle) for the
other vehicles
precinct. This vehicle is needed to travel within
our parklands, vacant lots and other
undeveloped dirt surfaces that the patrol cars
cannot access in emergency situations. Also, we
are requesting 14 new Radio Motor Patrol Cars
with mobile data computers.
13/36
NYPD
Other NYPD staff
The 43 Pct needs more PAAs (4)
resources requests
14/36
NYCTA
Improve subway
The Parkchester Train Station was renovated a
station or train
few years ago. We have seen some issues with
cleanliness, safety
graffiti, station cleanliness and bathroom
and maintenance
maintenance. The escalator, windows, lamps,
etc need to be cleaned periodically. The
escalator looks like its never been cleaned. We
want to make sure this stations beauty is
maintained.
15/36
NYCTA
Expand subway
The number 6 train line is a very busy line in the
service frequency or
heart of our district. We have seen numerous
hours of operations
issues with service frequency.
16/36
NYCTA
Provide a new bus
We have the need to create a new service line
service or Select Bus
along with the BX05 bus line and/or on Bruckner
Service
Blvd.
17/36
DOT
Conduct traffic or
The intersection of Story Ave Bronx River Ave is
Story Ave
parking studies
gridlocked during rush hour. We request a traffic
Bronx River
study to be conducted on story ave.
Ave Metcalf
Ave
18/36
DOT
Other expense
Allocate Funds for a Traffic Study to Install
Castle Hill Ave
traffic
Traffic Devices on Castle Hill Avenue from E.
E. Tremont
improvements
Tremont Avenue to Zerega Avenue. There is a
Ave Zerega
requests
need for this due to an increased amount of
Ave
vehicular traffic on Castle Hill Avenue.
19/36
DOT
Other expense
Request a Traffic Study of the Cross Bronx
traffic
Expressway Service Road From Castle Hill
improvements
Avenue to Bronx River Avenue; and to Include
requests
Nobel Avenue from the Cross Bronx Expressway
Service Road to Mansion Street. Traffic
conditions are dangerous and hazardous and
cannot be addressed solely by the monitoring of
the 43rd Precinct.
20/36
DOT
Other expense
Allocate Funding to Conduct a Traffic Study of
traffic
Unionport, Castle Hill, Soundview and the Bronx
improvements
River Communities. There is a need for
requests
additional traffic signals or devices to alleviate
the high volume of vehicular traffic and
speeding.
22/36
DOT
Other expense
We Request that a Traffic Study be Conducted at
Castle Hill Ave
traffic
Castle Hill Avenue from Westchester Avenue to
Westchester
improvements
Bruckner Blvd, Which Would Include the
Ave Bruckner
requests
Bruckner Service Road (North and South from
Blvd
Zerega Avenue to Bronx River Avenue). Traffic
conditions are dangerous and hazardous and
cannot be addressed soley by the monitoring of
the 43rd Precinct.
24/36
DPR
Other requests for
Fund Feasibility Study to Create a Passive
park, building, or
Recreation Area for the Existing Starlite Park.
access
Request Starlite Park to become a passive park
improvements
for people in the area to enjoy.
25/36
DYCD
Provide, expand, or
Identify Monies to Reinstitute Beacon Schools in
enhance
Community Board Nine's District. We Are One of
Cornerstone and
Largest Community Districts Within the Bronx
Beacon programs
and Many Areas Do Not Presently Have Any
(all ages, including
Services for Our Youth. To prevent crime and
young adults)
insure leadership development, additional
Beacon Schools should be funded.
26/36
DPR
New equipment for
Allocate Parks Equipment for the M & O and
maintenance
Recreation Divisions. Need a grass cutting
(Expense)
tracker and pickup trucks for the Community
Board 9 area.
27/36
DPR
Forestry services,
Restore Tree Pruning and Stump Removal
including street tree
Programs. Trees are in dire need of care.
maintenance
28/36
DPR
Other park
Restore Parks Department Personnel for M & O
maintenance and
and Recreation Divisions. Personnel urgently
safety requests
needed to adequately maintain and supervise
parks and playgrounds.
29/36
DOHMH
Other animal and pest control requests
We need to see who we can get more resources for Raccoon control for residents.
30/36
NYPL
Extend library hours
THE NYPL receive the additional baseline
or expand and
funding of $18,860 and the fiscal year 2017 city
enhance library
budget. The full restoration and baseline of
programs
expense funding in the cities FY 2017 budget will
allow the New York public library to maintain
the increase in hours from 46 to 50 weekly. We
want to maintain and increase this funding.
32/36
DOHMH
Increase health
We have seen the Health Inspectors system to
inspections, e.g. for
be a revenue based system. Focused more on
restaurants
questionable enforcement rather then
prevention and education. Which benefits the
all parties including the public.
33/36
EDC
Other public
Continue Senior Resident Advisor Program. This
housing
program prevents unnecessary
maintenance,
institutionalization of the elderly and provides
staffing and
24 hour staffing for crisis intervention and
management
emergencies. Services are provided by trained
requests
paraprofessionals and part-time professionals.
35/36
DFTA
Enhance home care
Fund Home Care Services. There aren't sufficient
services
home care services for Community District 9's
increasing elderly population. Funds are
requested to provide for additional home care
services.
37/36
DFTA
Increase home
Provide Meals-on-Wheels Services. Funding is
delivered meals
needed for Meals-on-Wheels services; there are
capacity
not enough services for the elderly population in
Community District 9.
39/36
EDC
Improve public
Bronx River Houses requests sweepers be
housing
purchased to offset and improve work
maintenance and
performance within their facility. They have lost
cleanliness
personnel over a period of several years and
stated that the bobcat would improve cleanup
and maintenance of their facility.
42/36
DFTA
Increase
Provide Funding for a Handicap Vehicle for
transportation
Transporting Seniors. Our seniors continue to
services capacity
support this request. The seniors have serious
concerns about "pickup and drop off" and
"delays in service." It was their opinion that
presently there may not be enough vehicles to
serve the needs of this aging population.
43/36 HPD Other affordable
housing programs requests (expense)
We are in need of a study to review possible affordable housing programs in our district.
image
44/36 DFTA Enhance NORC
programs and health services
Seniors Request the Funding of Social Service Programs. Our seniors, during our public hearing, were very concerned over their quality of life, their limited income and essential services that they require. Therefore, they recommend the funding of social service programs, which would address their needs, to be sponsored at NYCHA sites. Also, seniors recommended sponsoring of more 2O2 Senior Citizen Housing to be built within the border of community board District 9.
image
46/36 EDC Other public housing maintenance, staffing and management requests
Create a tenant protection unit
image

