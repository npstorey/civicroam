- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 13 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1oQTsminwquZrFxzbATEH9kkyUCjl_Yjn/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1oQTsminwquZrFxzbATEH9kkyUCjl_Yjn/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
13
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 13
image
Address: 219-41 Jamaica Avenue Phone: (718) 464-9700
Email: info@qcb13.org
Website: www.nyc.gov/queenscb13
Chair: Clive Williams District Manager: Mark McMillan
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Queens Community Board 13 is located in East/Southeast Queens with the Grand Central Parkway as its northern border, Francis Lewis Boulevard going to Springfield Boulevard as its western border, JFK Airport as its southern border and the Nassau County line as its eastern border. It is made up primarily of one- and two-family homes, with some scattering clusters of garden co-op apartments and apartment buildings. The district encompasses sixteen distinct communities, which includes: Bellaire, Bellerose, Brookville, Cambria Heights, Floral Park, Glen Oaks, Laurelton, Meadowmere, New Hyde Park, North Shore Towers, Parkside Terrace, Queens Village, Rosedale, Springfield Gardens, Warnerville and Wayanda. There is a strong sense of neighborhood identification in each of these communities. One community may fight for a long awaited library, while another struggles with clean streets, another with an influx of renters who do not respect the neighborhood norms, and some with illegal conversions. Many of our neighborhoods are under construction with water mains, sewer lines and gas lines being put in. This is particularly necessary in the southeast part of the Board area where flooding has been a persistent problem because of high watertables underground and it being located so close to Jamaica Bay. These DEP/DDC managed projects presently being undertaken are a hardship to many residents in affected blocks; yet, they understand the necessity to have had good lines of communication with the community affairs liaisons serving each project. Many areas in our communities suffer from chronic illegal dumping. Other issues affect the entire board such as a proliferation of hotels acting as shelters for the homeless, significantly beyond the fair share due our communities. There are many residential front yards being transformed into parking for the residents, with the associated illegal curb cut. In addition, backyards and driveways being used as auto repair facilities. There are too many complaints about "ponding" along driveways and curbs either to due to street repaving or new house construction. The many beautiful parks and playgrounds in the district need more staff and equipment as they are heavily used creating tremendous maintenance demands. This district has a large senior population, growing larger as people tend more to stay in the area as opposed to migrating to the south. The district's overall population is dramatically increasing. The transition in many communities involves immigrants and young families with children moving into the community and requiring services. Developers look for open lots to build with variances, or to demolish viable one- and two-family homes to build larger multi-family buildings. While these buildings add to the amount of available housing, often they do not conform to the character of surrounding houses. Many young families are moving in adding to the diversity and vibrancy of our district. However, these younger couples create need for more classrooms and additional after-school activities. The growing youth population trend indicates a critical need for for youth community center.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 13
image
The three most pressing issues facing this Community Board are:
Parks
The district has enormous amount of parkland including two big parks (Brookville and Springfield Parks) and many playgrounds. Additionally, there are parks properties including center medians, wetlands and grassy areas parallel to the highways. The Department of Parks and Recreation needs more equipment and personnel to respond to the level of activity at these areas, as well as the numerous maintenance requests from the community during the warm weather months when the grass grows high so quickly. In the two big parks volunteer groups also look for gardeners to assist in their beautification efforts.
Street conditions (roadway maintenance)
As the geographically largest Board area in Queens and the second largest in NYC, the requests for for roadway improvements are unending. Some of the requests are for streets that that have upcoming capital projects and therefore cannot be repaved until the project work is completed; other requests are that the street surface has outlived its lifespan and needs to be redone. Given the area of the Board, a provision for a percentage more of street repaving would seem appropriate.
Traffic
The office gets an unending stream of requests for speed humps. Many of our ancillary streets are wide and parallel to primary arteries; consequently, they are used as alternative routes to get past traffic. Maybe the navigation apps determining best routes contribute to this problem, as often this occurs in areas near the three highways surrounding this district. Possibly these requests reflect that many motorists simply do not respect the speed limit of 25 mph and speed down residential streets posing safety concerns for everyone, especially older people and children.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 13
image
M ost Important Issue Related to Health Care and Human Services
Other
There are three (3) things health-related: 1) Public education on "vaping." 2) Public education on the consequences of juveniles eating too much "junk food." 3) Public education relating to the fear of "flu shots." Numbers 1 & 2 are directed to young people who have tendencies for doing things not in their best interests and who do not yet understand how bad health can affect their life. Number 3 relates to adults who believe in conspiracy theories or who do not believe that this sort of inoculation is necessary.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
Renovate and upgrade all senior centers in the district. Enhance educational and recreational programs, e.g. tai chi, health initiatives. Information for additional care providers, additional senior center staffing, extended hours for senior centers. Extend home care services from 4 hours to 8 hours. Senior education programs with respect to the internet. Look into developing a NORC. Senior abuse focusing on their finances.
Needs for Homeless
Understanding that homelessness is a citywide issue, we support the City identifying abandoned properties and converting them into affordable housing through various programs that are already underway. With respect to those sheltered in hotels located within the Board area, we would like DHS to look at other communities as this Board has more has more than its fair share.
Needs for Low Income NYs
There are families with "special needs" individuals within this district that would like to see programming and education for both teenagers and adults that will lead to job opportunities allowing them a level of independence.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
6/16 DFTA Enhance educational and recreational programs
Increase funding for programming.
image
8/16 DOHMH Promote Quit
Smoking Programs
The public health issue of vaping is getting a lot of attention. Yet, most older people do not know what it is or what the paraphernalia looks like that younger people use to vape. A series of public service announcements need to be made to educate the public on this new health concern.
image
10/16 DFTA Renovate or
upgrade a senior center
Services Now For Adult Persons (SNAP) increase funding for programming.
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 13
image
M ost Important Issue Related to Youth, Education and Child Welfare
Educational attainment
In District 29, the level of achievement does not correspond to the economic status of the community. The following are some of the requests that could lift education achievement: > Smaller class sizes in early grades. > After-school programs providing educational enrichment including tutoring and the expansion of STEAM programs. > The high schools need additional funding for career counseling and mental health services. > More financial support (in high schools) for the Regents Exam and SAT preparation to ensure college readiness. > Exposure to different career tracks through community partnerships/internships.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
9/16 DOE Other educational
programs requests
Elementary schools in District 29 are under- performing. After school enrichment programming is needed so these students can perform at least at their grade level and be prepared to compete when they reach high school.
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 13
image
M ost Important Issue Related to Public Safety and Emergency Services
Fire Safety
Over the past few years there have been a number of fatal fires in this district. FDNY has been aggressive in outreach providing fire safety education in the areas where these fires have occurred. QCB 13 has partnered with FDNY, Red Cross and DOE to further extend the access to information about fire safety, and to promote the program of free smoke /CO2 detectors that get installed in resident's homes. This is particularly important in an area where there are so many densely populated wood-framed homes, and where electrical circuits are overused and candles are lit during the holiday season.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Historically, community policing has reduced crime and promoted better relations with residents. The program of Neighborhood Coordinating Officers (NCOs) has finally reached the 105 Precinct, and so far has been quite effective in solving the many quality of life issues that occur on the daily basis.
However, illegal truck parking persists as an issue in the communites adjacent to JFK Airport. While the 105 Precinct has done a tremendous job in summonsing, often this is simply a "business expense" for the truck driver. An even more effective tool at discouraging this activity is the "booting" of these trucks. This forces the driver to loose
time paying the summons before being able to drive their truck. If the 105 precinct had more "truck boots" its enforcement efforts would be even more effective.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
6/12 NYPD Other NYPD
facilities and equipment requests (Capital)
Illegal truck parking is a problem as the JFK Airport freight businesses are in the district. The 105 Precinct does an excellent job with the summonsing, but many truck drivers treat them as a cost of doing business. Truck booting freezes their ability to move, requiring them to pay a fine in person and acts as an additional deterrent.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/16
FDNY
Expand funding for
This district has had a number of fatal fires over
fire prevention and
the past few years. Fire safety education
life safety initiatives
partnered with the Smoke/CO2 Detector
giveaway and installation program with the Red
Cross is important in communities that have
many overcrowded wood-framed houses.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 13
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
On the major commercial strips garbage accumulates rapidly. Whenever there is a public trash can it becomes a magnet for bags of [uncollected] residential waste. This problem is so bad many store owners do not want waste baskets in front of their businesses because of the inevitable sanitation ticket that gets issued though most times they are not at fault. The three Council Members within QCB 13 (Grodenchik, Miller, Richards) have added funding for additional weekly collections, but this is an area of concern that needs continual monitoring. Along the service roads that abut the four highways bordering the district (Grand Central Parkway east; Cross Island Parkway south; Laurelton Parkway north and south; Belt Parkway west), there is a lot of dumping of construction waste and general garbage both inside and outside of the highway barrier fence. There is also dumping on wetlands and grassy areas. These "dumping grounds" are managed by DOT and Parks, respectively. Neither of these two agencies have the capacity to keep up with the necessary cleaning which then requires coordination with DSNY on a periodic basis.
Finally, and unfortunately, too many people litter and there needs to be a public campaign vilifying those who randomly drop their trash on the ground.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Air emissions from the planes landing near JFK Airport are creating respiratory issues including asthma and other types of sinus conditions.
More enforcement of delivery trucks with excessive idling.
Needs for Sanitation Services
Public outreach at transit hubs and along commercial strips about NO LITTERING.
Routine cleaning of vacant lot locations where frequent dumping occurs.
Outreach to schools and community centers on NO LITTERING.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
14/16
DSNY
Provide more
Jamaica Avenue has large amounts garbage put
Jamaica
frequent litter
out on a daily basis. There are numerous
Avenue 224
basket collection
restaurants and stores along this strip that
Street Francis
attracts shoppers and diners at all times of the
Lewis
day and evening. In addition, there is always
Boulevard
random residential garbage put out.This highly
traveled street by both pedestrians and
motorists needs more frequent truck pickups.
16/16
DSNY
Provide more
This section of the district needs more attention
Hillside
frequent garbage or
as the stores and fast food restaurants attract a
Avenue Cross
recycling pick-up
lot of people with the residual littering,
Island
Parkway
Lakeville Road
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 13
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Commercial district revitalization
Commercial District Revitalization, especially along the corridors of Linden Boulevard, Merrick Boulevard, Jamaica Avenue, 243 Street (Rosedale) and Guy R. Brewer Boulevard, that will bring the types of goods and services important for the community. It is important to have quality and diversity in the types of businesses that attract consumers and promote overall vitality and better quality of life.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
A prevalent issue is homeowners creating their own parking by paving over front yards and creating illegal curb cuts. Providing a budget for more inspectors can assist in addressing this growing problem.
Needs for Housing
More funding to be proactive in sealing up abandoned "zombie" houses. - Maintaining construction fences around the abandoned properties. - Maintaining the yards of abandoned properties. - Support programs that convert properties into affordable housing. - The removal of squatters from abandoned properties. - To clearly identify the agency that will identify and enforce issues specified above. - Maintain support of foreclosure legal services.
Needs for Economic Development
Create a strategic approach to local economic development. - Improve our commercial corridors through beautification and cleanliness. - Encourage various business owners to join forces to form merchant's associations.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
12/16 DOB Expand code
enforcement
There are many front and side yards that are paved over for parking. Additionally, these same homeowners create their own illegal curb cuts. DOB needs to be funded so this condition, which brings down the block where it exists, can be quickly alleviated.
TRANSPORTATION
Queens Community Board 13
image
M ost Important Issue Related to Transportation and Mobility
Roadway maintenance
QCB 13 has the largest geographical area in Queens with the commensurate larger number of streets. While it is understood that new roadways cannot be authorized while a capital project is underway, or if one is planned for a specific area, there remains many areas in the district that need repaving. Bad roads damage constituents' vehicles and should be fixed/upgraded as soon as possible. Many streets have been opened up for various reasons and the road repair was either substandard or or did not last. As time goes on this creates a moonscape that is unfair to residents who live on or use these streets.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Many of our neighborhoods are requesting traffic calming, specifically speed humps and stop signs. These traffic calming methods will slow traffic and provide more pedestrian safety.
General maintenance along the grassy areas next to the highways is a problem. On one side of the fence is DOT, the other DPR oftentimes working with DSNY. Managing or coordinating between the two often is not very efficient.
Needs for Transit Services
The Q77 presently ends southbound on 145 Avenue. The last stop should be extended to 147 Avenue so tranfer to the east-west Q111 & Q113 bus lines.
This has been discussed over the past 2 years with Council Member Richards getting involved; however, the holdup related to the turnaround for the Q77 to go northbound has been solved. It is long past due for this logical bus route extension as the two block walk for for a transfer next to Springfield Park poses difficulty for anyone who is handicapped or has physical mobility issues, safety concerns being out in the open - especially when it is dark, and exposure to the elements during inclement weather.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/12
DOT
Reconstruct streets
This street segment needs total reconstruction
147 Avenue
as it is strewn with potholes and floods at the
Brookville
slightest rain event. It goes over a waterway so
Boulevard
more planning and cost will be involved in this
232 Street
reconstruction.
2/12
DOT
Reconstruct streets
Blacktop on Hillside Avenue westbound that
Hillside
was used as repair for the roadway has
Avenue 215
"bubbled up" from bus traffic during hot
Place 213
summer days. This condition needs to be
Street
addressed before accidents occur because of
vehicles veering into other lanes to avoid the
excessive bumpiness of the roadway.
4/12
DOT
Roadway
This Community Board is surrounded by
maintenance (i.e.
highways: Grand Central Parkway to the north;
pothole repair,
Cross Island Parkway to the east, the Belt
resurfacing, trench
Parkway to the south. DOT is responsible for
restoration, etc.)
maintaining the grassy areas adjacent to these
highways. This office continually gets
complaints about dumping and general
maintenance in many locations along these
traffic arteries.
5/12
DOT
Rehabilitate bridges
Parapet wall for pedestrian crossing on North
Francis Lewis
and South sides of the bridge. (Francis Lewis
Blvd
Blvd between Brookville Blvd and Laurelton
Brookville
Parkway)
Blvd
Laurelton
Parkway
7/12
DOT
Rehabilitate bridges
Parapet wall for pedestrian crossing on North
130th ave
and South sides of the bridge. (130th ave
Brookville
between Brookville Blvd and Laurelton Parkway)
Blvd
Laurelton
Parkway
8/12
DOT
Upgrade or create
The Laurelton Mall on 135th Avenue between
135th Avenue
new plazas
229th Street and the Laurelton Parkway needs
229th Street
curbing.
Laurelton
Parkway
9/12
DOT
Repair or construct
The center median needs curbing to protect the
Francis Lewis
new curbs or
garden and irrigation system local residents
Boulevard
pedestrian ramps
have worked very hard to keep clean and
133 Avenue
beautify.
Merrick
Boulevard
11/12
NYCTA
Other transit infrastructure requests
Southbound stop at the western corner (in front of the Dollar Store) of Guy R. Brewer Boulevard (where it intersects with Farmers Boulevard).
Four (4) buses stop at this location: Q3; Q111;
Guy R. Brewer Boulevard New York
Q113; Q114.
Farmers
Boulevard
145 Drive
12/12
DOT
Repair or construct
The curbs in this area have deteriorated or
new curbs or
disappeared altogether. It is unfortunate that
pedestrian ramps
there is no money for curbs in the DOT budget,
but this needs to be in this District Needs
Statement. Glen Oaks Village area is defined as
North Shore Towers to the north, Little Neck
Parkway to the south, Long Island Jewish
Hospital/North Shore Towers to the east, and
Little Neck Parkway to the west.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
2/16
NYCTA
Expand bus service
The bus needs to go 2 blocks further south to
Springfield
frequency or hours
provide a safe and efficient transfer for riders
Boulevard
of operation
going east-west on 147 Avenue connecting with
145 Road 147
the Q111 and Q113 bus lines.
Avenue
5/16
DOT
Improve traffic and
This intersection is not perpendicular and
220 Street
pedestrian safety,
requires awkward movements to turn left both
Jamaica
including traffic
north and southbound on 222 Street to get on
Avenue
calming (Expense)
to Jamaica Avenue. Additionally, the MTA Bus
(eastbound)
Depot is two blocks away and there are
Jamaica
numerous buses all day that need to make a left
Avenue
turn at this location.
(westbound)
11/16
NYCTA
Expand bus service
This office has received complaints of
frequency or hours
overcrowded buses during the morning and
of operation
evening rush hours. Either expand service or
provide the larger buses during this time period
for rider safety and comfort.
15/16
NYCTA
Other transit service
Electronic signage indicating bus arrival times
requests
at strategic westbound bus stops (for the
morning commute) along Merrick Boulevard,
Linden Boulevard, Jamaica Avenue, Hillside
Avenue and Union Turnpike.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 13
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
The staff presently assigned to the Board's parks do an excellent job. During the summer when the parks are used more extensively, additional staff and equipment for both maintenance and safety would vastly increase the overall enjoyment of these recreational areas.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The parks and playgrounds in the district have varying needs as detailed below. Many of the MPAA areas need resurfacing, as these areas need some creativity in determining what sporting activities can be encouraged with the decline in the play of asphalt softball. In addition, better scheduling for use of grass fields with baseball and soccer.
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/12
QL
Create a new, or
The Queens Village branch of the Queens Public
94-11 217
renovate or upgrade
Library needs a handicapped ramp at its front
Street,
an existing public
entrance.
Queens, New
library
York, NY
10/12
DPR
Reconstruct or
Gunn Playground needs its MPAA repaved and
upgrade a park or
adjacent property purchased for park
amenity (i.e.
expansion. (Land swap)
playground, outdoor
athletic field)
CS
DPR
Provide a new or
Add park benches for more seating in
expanded park or
Springfield Park.
amenity (i.e.
playground, outdoor
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/16
DPR
Provide better park
More funding for lawn care equipment that can
maintenance
be used in this district during the warm weather
months when the parks are most used..
4/16
DPR
Provide better park
QCB 13 has lots of parks, playgrounds, center
maintenance
medians and grassy areas that are the
responsibility of this agency. Adequate numbers
of workers need to be assigned during the warm
weather months.
7/16
DPR
Enhance park safety
Idlewild Park is presently being developed for
149 Avenue
through design
walking tours and general nature learning. It is
Springfield
interventions, e.g.
a natural wetland that provides sanctuary to
Lane 225
better lighting
birds, various trees and plants,and is a space of
Street
(Expense)
contemplation and peace for patrons. Off-road
motor vehicles have no place in this area and
need to be prevented from entry with fencing at
a specific area of access.
13/16 DPR Enhance park safety
through more security staff (police or parks enforcement)
Increase security staff at Springfield Park Brookville Park and other parks with in the district (PEP) during warm weather months when these two parks are heavily used
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/12
DOT
Reconstruct streets
This street segment needs total reconstruction
147 Avenue
as it is strewn with potholes and floods at the
Brookville
slightest rain event. It goes over a waterway so
Boulevard
more planning and cost will be involved in this
232 Street
reconstruction.
2/12
DOT
Reconstruct streets
Blacktop on Hillside Avenue westbound that
Hillside
was used as repair for the roadway has
Avenue 215
"bubbled up" from bus traffic during hot
Place 213
summer days. This condition needs to be
Street
addressed before accidents occur because of
vehicles veering into other lanes to avoid the
excessive bumpiness of the roadway.
3/12
QL
Create a new, or
The Queens Village branch of the Queens Public
94-11 217
renovate or upgrade
Library needs a handicapped ramp at its front
Street,
an existing public
entrance.
Queens, New
library
York, NY
4/12
DOT
Roadway
This Community Board is surrounded by
maintenance (i.e.
highways: Grand Central Parkway to the north;
pothole repair,
Cross Island Parkway to the east, the Belt
resurfacing, trench
Parkway to the south. DOT is responsible for
restoration, etc.)
maintaining the grassy areas adjacent to these
highways. This office continually gets
complaints about dumping and general
maintenance in many locations along these
traffic arteries.
5/12
DOT
Rehabilitate bridges
Parapet wall for pedestrian crossing on North
Francis Lewis
and South sides of the bridge. (Francis Lewis
Blvd
Blvd between Brookville Blvd and Laurelton
Brookville
Parkway)
Blvd
Laurelton
Parkway
6/12
NYPD
Other NYPD
Illegal truck parking is a problem as the JFK
facilities and
Airport freight businesses are in the district. The
equipment requests
105 Precinct does an excellent job with the
(Capital)
summonsing, but many truck drivers treat them
as a cost of doing business. Truck booting
freezes their ability to move, requiring them to
pay a fine in person and acts as an additional
deterrent.
7/12
DOT
Rehabilitate bridges
Parapet wall for pedestrian crossing on North
130th ave
and South sides of the bridge. (130th ave
Brookville
between Brookville Blvd and Laurelton Parkway)
Blvd
Laurelton
Parkway
8/12
DOT
Upgrade or create
The Laurelton Mall on 135th Avenue between
135th Avenue
new plazas
229th Street and the Laurelton Parkway needs
229th Street
curbing.
Laurelton
Parkway
9/12
DOT
Repair or construct
The center median needs curbing to protect the
Francis Lewis
new curbs or
garden and irrigation system local residents
Boulevard
pedestrian ramps
have worked very hard to keep clean and
133 Avenue
beautify.
Merrick
Boulevard
10/12
DPR
Reconstruct or
Gunn Playground needs its MPAA repaved and
upgrade a park or
adjacent property purchased for park
amenity (i.e.
expansion. (Land swap)
playground, outdoor
athletic field)
11/12
NYCTA
Other transit
Southbound stop at the western corner (in front
Guy R.
infrastructure
of the Dollar Store) of Guy R. Brewer Boulevard
Brewer
requests
(where it intersects with Farmers Boulevard).
Boulevard
Four (4) buses stop at this location: Q3; Q111;
New York
Q113; Q114.
Farmers
Boulevard
145 Drive
12/12
DOT
Repair or construct
The curbs in this area have deteriorated or
new curbs or
disappeared altogether. It is unfortunate that
pedestrian ramps
there is no money for curbs in the DOT budget,
but this needs to be in this District Needs
Statement. Glen Oaks Village area is defined as
North Shore Towers to the north, Little Neck
Parkway to the south, Long Island Jewish
Hospital/North Shore Towers to the east, and
Little Neck Parkway to the west.
CS
DPR
Provide a new or
Add park benches for more seating in
expanded park or
Springfield Park.
amenity (i.e.
playground, outdoor
athletic field)
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/16
FDNY
Expand funding for
This district has had a number of fatal fires over
fire prevention and
the past few years. Fire safety education
life safety initiatives
partnered with the Smoke/CO2 Detector
giveaway and installation program with the Red
Cross is important in communities that have
many overcrowded wood-framed houses.
2/16
NYCTA
Expand bus service
The bus needs to go 2 blocks further south to
Springfield
frequency or hours
provide a safe and efficient transfer for riders
Boulevard
of operation
going east-west on 147 Avenue connecting with
145 Road 147
the Q111 and Q113 bus lines.
Avenue
3/16
DPR
Provide better park
More funding for lawn care equipment that can
maintenance
be used in this district during the warm weather
months when the parks are most used..
4/16
DPR
Provide better park
QCB 13 has lots of parks, playgrounds, center
maintenance
medians and grassy areas that are the
responsibility of this agency. Adequate numbers
of workers need to be assigned during the warm
weather months.
5/16
DOT
Improve traffic and
This intersection is not perpendicular and
220 Street
pedestrian safety,
requires awkward movements to turn left both
Jamaica
including traffic
north and southbound on 222 Street to get on
Avenue
calming (Expense)
to Jamaica Avenue. Additionally, the MTA Bus
(eastbound)
Depot is two blocks away and there are
Jamaica
numerous buses all day that need to make a left
Avenue
turn at this location.
(westbound)
6/16
DFTA
Enhance
Increase funding for programming.
educational and
recreational
programs
7/16
DPR
Enhance park safety
Idlewild Park is presently being developed for
149 Avenue
through design
walking tours and general nature learning. It is
Springfield
interventions, e.g.
a natural wetland that provides sanctuary to
Lane 225
better lighting
birds, various trees and plants,and is a space of
Street
(Expense)
contemplation and peace for patrons. Off-road
motor vehicles have no place in this area and
need to be prevented from entry with fencing at
a specific area of access.
8/16
DOHMH
Promote Quit
The public health issue of vaping is getting a lot
Smoking Programs
of attention. Yet, most older people do not know
what it is or what the paraphernalia looks like
that younger people use to vape. A series of
public service announcements need to be made
to educate the public on this new health
concern.
9/16
DOE
Other educational
Elementary schools in District 29 are under-
programs requests
performing. After school enrichment
programming is needed so these students can
perform at least at their grade level and be
prepared to compete when they reach high
school.
10/16
DFTA
Renovate or
Services Now For Adult Persons (SNAP) increase
upgrade a senior
funding for programming.
center
11/16
NYCTA
Expand bus service
This office has received complaints of
frequency or hours
overcrowded buses during the morning and
of operation
evening rush hours. Either expand service or
provide the larger buses during this time period
for rider safety and comfort.
12/16
DOB
Expand code
There are many front and side yards that are
enforcement
paved over for parking. Additionally, these same
homeowners create their own illegal curb cuts.
DOB needs to be funded so this condition, which
brings down the block where it exists, can be
quickly alleviated.
13/16
DPR
Enhance park safety
Increase security staff at Springfield Park
through more
Brookville Park and other parks with in the
security staff (police
district (PEP) during warm weather months
or parks
when these two parks are heavily used
enforcement)
14/16
DSNY
Provide more
Jamaica Avenue has large amounts garbage put
Jamaica
frequent litter
out on a daily basis. There are numerous
Avenue 224
basket collection
restaurants and stores along this strip that
Street Francis
attracts shoppers and diners at all times of the
Lewis
day and evening. In addition, there is always
Boulevard
random residential garbage put out.This highly
traveled street by both pedestrians and
motorists needs more frequent truck pickups.
15/16
NYCTA
Other transit service
Electronic signage indicating bus arrival times
requests
at strategic westbound bus stops (for the
morning commute) along Merrick Boulevard,
Linden Boulevard, Jamaica Avenue, Hillside
Avenue and Union Turnpike.
16/16 DSNY Provide more
frequent garbage or recycling pick-up
This section of the district needs more attention as the stores and fast food restaurants attract a lot of people with the residual littering,
Hillside Avenue Cross Island Parkway Lakeville Road
image

