- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 14 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1vHG3jDRPIhltMG5nw5MgjIRLtBHQof3v/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1vHG3jDRPIhltMG5nw5MgjIRLtBHQof3v/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
14
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 14
image
Address: 1931 Mott Ave, 311
Phone: (718) 471-7300
Email: cbrock14@nyc.rr.com
Website: www.nyc.gov/queenscb14
Chair: Dolores Orr District Manager: Jonathan Gaska
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 14 encompasses the Rockaway Peninsula and Broad Channel. It has at least 13 distinct communities, each with its own name, neighborhoods, interests and problems bound together by a common geography and history, which is both written and hidden. From a westerly to easterly direction, we point to Breezy Point, Rockaway Point, Neponsit, Belle Harbor, Rockaway Park, Rockaway Beach, Arverne/Sommerville, Edgemere, Arverne by the Sea, Bayswater , Wavecrest and Far Rockaway and Broad channel Island. The Rockaways is some eleven miles in length and is three quarters of a mile wide. With its multi-ethnic, multi-religious groupings, the concerns of the poor, the aged, the young and needy is often termed a microcosm of New York City. Patterns of housing are equally diverse with evidence of affluence in the western and most eastern sections of the district. And large concentrations of public housing and publicly assisted housing in between. While our District is still recovering from hurricane SANDY it is our belief that with government assistance our many devastated communities will recover and thrive. The board looks forward to the start of the "Downtown Far Rockaway" Plan. The board strongly feels that the CIty of NY needs to do more to prevent drownings on our beaches. The creation of a water safety and swim program for ALL school age children would help save lives. The board also requests more investment in our schools. A gifted and talented program must be located on the Peninsula , and more schools seats must be created to deal with the over crowding in some schools as well as two new schools are needed to provide space for the eventual need due to the Downtown Far Rockaway project and the newly approved development at the old Penninsula Hospital site as well as the anticipated Arverne East project . We are deeply concerned that with all the new housing to be built over 7,000 new units- the flow of traffic will be rendered to a stand still- we only have two east-west roadways and currently traffic during rush hour is diffulclt . With the anticpated housing development and an additional 3500-5000 new cars on the road every day The Department of transportation needs to look at the whole district to assure flow of trafic. FInally the need for more police officers in both the 100 and 101 precints during the beach season is neccesary as well as additional PEP officers to deal with the record breaking beach crowds every summer.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 14
image
The three most pressing issues facing this Community Board are:
Infrastructure resiliency
Flooding-It has become clear that after hurricane SANDY that protection from flooding is a major concern
.communities in our district that face Jamaica Bay are in constant jeopardy from high tides, storm surge and heavy rains. Bulk heads, street raising and storm sewers must be installed along Rockaways northern boarder and through out Broad Channel. Groins/jetties and Beach sand replenishment must be funded. Public Health- With the closing of Peninsula Hospital, St johns hospital has become over crowed and unable to handle the load . A typical wait in the emergency room exceeds 5 hours and a wait for a bed can be over a day this must be delt with . We also have been deeply disappointed in the NYC Dept of health's refusal to implement a program of the spraying/fogging of adulticide to deal with summer mosquito problem. Street Conditions- CB14 has experienced an large increase in summer tourism. This has caused traffic problems through out the district. Our roads remain in poor condition after hurricane SANDY. The expansion of Rockaway Beach blvd from Beach 62-Beach 32/Seagirt Blvd MUST be designed and funded this road way remain dangerous and over used. We also look forward to more Police officers during the summer beach season.
Transit (buses & subways)
Getting to and from Community board 14 is a Transportation nightmare - We are poorly served by mass transportation- the ferry has helped but does not serve the residents on the East end of the district- we request a AM/PM rush hour express train on the A- 2-3 Rockaway rush express trains to and from Manhattan would drastically reduce the over 1 hour commute. the re opening of the Rockaway rail line would also be a great help.
Unemployment
Community board 14 has the highest unemployment rate in the Borough of Queens- because of poor transportation and no real job opportunity except for the health care industry. Our residents have to travel long distances to get to job centers. The creation of good local jobs must be a priority
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 14
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
With the closing of Peninsula hospital health care for the many low income residents has become difficult.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
The Board would like additional funding for expansion and staffing for primary health care and emergency health care. Ideally the re-opening of Peninsula Hospital in some way would be greatly beneficial to our community
Needs for Older NYs
Our community board has a large Senior population- The need for more senior centers through out the district is evident
Needs for Homeless
Community board 14 has over 3000 units of public housing and we have the largest amount of section 8 voucher placements in the Borough of Queens. We have over 5000 nursing and Adult home beds. The Mayor recently opened a homeless shelter as well in our community. We request that the shelter be closed and that the city share the burden of housing our cities unfortunate poor and needy in other Community boards. The City is placing Homeless in the new local Hotel in addition to the shelter that the city opened . We also have the highest section 8 voucher placements in Queens the City must stop placing those in need in our communities it is destabilizing our neighborhoods
Needs for Low Income NYs
Our biggest needs in this category is primary health care and job training and economic development to create jobs in our district.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
CS HHC Provide a new or expanded health care facility
Provide funding for the expansion of St Johns Hospital
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
6/26
DOHMH
Reduce mosquito populations
Every spring and summer the communities along Jamaica bay suffer from Mosquito issues
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 14
image
M ost Important Issue Related to Youth, Education and Child Welfare
Educational attainment
While our schools are improving more needs to be done- Need for gifted and talented school on east end
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Modernization of schools in District is necessary - Computers, smart boards in every classroom
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
13/26
DOE
Other educational
study- two new high schools- a Health related
programs requests
technical school and a Aviation services high
school
21/26
DOE
Other educational
Sunset Cove new park in Broad channel- fund a
programs requests
environmental education program for school
age children
22/26
DOE
Other educational
fund/expand gifted and talented programs in
programs requests
CB14
24/26
DYCD
Provide, expand, or
expand in cb14 Beacon and compass programs
enhance
Cornerstone and
Beacon programs
(all ages, including
young adults)
26/26
DYCD
Provide, expand, or
Fund Nest and Horizon programs in CB14
enhance after
school programs for
all grade levels
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 14
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
More Police officers
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
We need more officers on Patrol and the proper equipment to assist them, to deal with sea level rise and storm , more high axel vehicle are needed in both precincts 100&101 pcts
Needs for Emergency Services
After Hurricane SANDY the need for Electric generators and emergency lighting and communication equipment is a glaring need
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
10/26 NYPD Assign additional
uniformed officers
Tourism has increased 10 fold during summer need for more Police officers.
image
14/26 NYPD Other NYPD
facilities and equipment requests (Expense)
There is a need for back up generators/boats.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 14
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Other
Storm protection/sea level rise
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
The installation of tide gates on all storm water out falls and the installation of storm sewers in parts of the district that do not have or have poorly functioning storm sewers
Needs for Sanitation Services
During summer season additional commercial basket pick up is necessary in and along shopping areas Lot cleaning also is a need
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
8/29
DEP
Develop a capital
beach 84 street from Beach channel drive north
project for specific
to dead end at the bay flood on a regular basis
street segments
storm and sanitary sewers are needed
currently lacking
sanitary sewers
9/29
DEP
Develop a capital
street flooding
project for specific
street segments
currently lacking
sanitary sewers
10/29
DEP
Inspect sanitary
add check valves and tide gates on ALL storm
sewer on specific
water outfall in district
street segment and
repair or replace as
needed (Capital)
21/29
DEP
Move a planned
on south side of Addabbo bridge on Cross bay
capital project into
blvd drainage via duct is collapsing needs
the budget for the
replacement
next fiscal year
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
3/26
DEP
Inspect sanitary
design and construct storm sewers at following
sewer on specific
locations: Wheatley street and Augustina ave
street segment and
Beach 9th street and Central ave Brunswick ave,
repair or replace as
Virginia street, Beach 12 street
needed (Expense)
12/26
DSNY
Other cleaning
Cross bay blvd median in broad channel should
requests
be cleaned once a month May through
September Rockaway freeway should be
cleaned once a month all year round
15/26
DSNY
Provide more
rockaway is a summer tourist area basket pick
frequent litter
up should be 7 days a week from june-
basket collection
september
25/26 DSNY Other garbage
collection and recycling infrastructure requests (Expense)
fund regular cleaning- of both side of Rockaway point blvd- south side- beach 169-193 streets northside Beach 184-201 streets
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 14
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Neighborhood preservation
The board is the site of over 4000 mid and high rise new affordable units to be built over next 5 years the district can not handle any more large scale development- Arverne East should be mostly market rate with affordable at 80% ami and higher density must be reduce significantly
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Our community is becoming over built and over crowded Traffic is becoming an issue and the lack of public infrastructure to handle the increase in population is becoming a burden- Low density housing should be a priority for the City of New York, new high rise,high density housing should be controlled
Needs for Housing
CB14 has had an explosion in population over the last 10 years because of a housing boom we request that The unit count in Arverne East be drastically reduced and that a more economic development/jobs /Recreation based project be supported . While the board has supported thousand of new affordable housing units in the last few years, the cretions of new market rate units should be a priority now
Needs for Economic Development
Government must help fund and develop the Greater Far Rockaway Shopping Area and assist our merchants on Rockaway Beach Blvd in Rockaway Beach on Beach 116 street and along Rockaway Beach Blvd from Beach 116 street to Beach 112 street
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation Location
18/29
NYCHA
Renovate or
improve buildings maintance
upgrade public
housing
developments
27/29
EDC
Make infrastructure
the need for restrooms at Beach 108 street ferry
investments that
terminal
will support growth
in local business
districts
29/29
NYCHA
Renovate or
fund mold remediation in NYCHA developments
upgrade NYCHA
in CB 14
community facilities
or open space
CS
EDC
Invest in capital
build ferry docks/piers and parking for two ferry
projects to improve
locations one on east side of district one on west
access to the
side of district
waterfront
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
8/26
SBS
Support
fund storefront program for Far Rockaway
development of
/Mott ave Shopping area, Rockaway Beach
local Storefront /
shopping area along Rockaway Beach blvd from
Facade
beach 102 - beach 84 street, Beach 129 street
Improvement
shopping area
Program
TRANSPORTATION
Queens Community Board 14
image
M ost Important Issue Related to Transportation and Mobility
Subway service (frequency and access)
CB14 is poorly served by mass transportation - the new ferry has been a success - A new ferry stop should be added east of Beach 84 street. An am/pm express A train service should be added - stops in Cb14q and Howard beach then express to Jay street in Brooklyn 3-4 rush hour express trains in am and pm is all that is needed.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Rockaway Beach Blvd/ Edgemere ave capital reconstruction This section must be improved and widened to two lanes in each direct from Beach 62 street to Seagirt Blvd Seagirt blvd from Beach 9th street to Nassau county line must be reconstructed with raised median ,crosswalks and traffic lights installed at some point between beach 6 and beach 3 streets
Needs for Transit Services
We are poorly served by mass transportation Improve commuter service on A train and on buses, institute a AM/PM rush hour express A train Permanently Fund Ferry service so that it runs on a regular schedule 7 days a week 52 weeks a year
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/29
DOT
Reconstruct streets
Re construct Cross bay blvd -continue to raise
streets in Broad channel install storm sewers
with tide gate
2/29
DOT
Reconstruct streets
Raise Norton drive, install storm sewers and sea
wall
4/29
DOT
Other
install safety fence along seagirt blvd
beach 31 st
transportation
camp road
infrastructure
requests
5/29
DOT
Repair or build new
repair/replace bulkheads at all street ends in
seawalls or
CB14 Rockaway and Broad channel
bulkheads
6/29
DOT
Other capital traffic
with vastly expand summer beach traffic
improvements
roadway needs improvement
requests
7/29
DOT
Roadway
fund design and re- construction of Shorefront
Shorefront
maintenance (i.e.
Parkway, include storm sewers, have crosswalks
Parkway
pothole repair,
line up, have driveways for Dayton buildings line
beach 73 st
resurfacing, trench
up with traffic lights and cross access to east
beach 108 st
restoration, etc.)
bound road way-HWQ-1682
11/29
DOT
Reconstruct streets
design and construct the project to widen
rockaway
Rockaway beach blvd/Edgemere AVE from
beach
beach 62 STREET TO beach 31 STREET
blvd/edgemere
ave beach 62
street beach
31 street
17/29
DOT
Reconstruct streets
with increase in population and density and
traffic projected from Downtown Far Rockaway
Plan this east-west roadway must be improved
19/29
NYCTA
Other transit
re institute the old Rockaway beach rail line
infrastructure
requests
25/29
DOT
Repair or build new
design build- bulkhead along Norton drive from
Norton Drive
seawalls or
cold spring road to Dunbar street
Cold Spring
bulkheads
Road Dunbar
St
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/26
DOT
Expand the
Build parking lot for ferry - increase weekend
Beach 108 st
frequency or hours
hours for ferry during summer
Beach
of operation of
Channel dr
ferries
7/26
DOT
Other expense
study the feasibility of widening Rockaway
Rockaway
traffic
Beach blvd from Beach 110 street to beach 119
Beach Blvd
improvements
street
Beach 110 St
requests
Beach 119 St
11/26
DOT
Other expense
complete the widening to two lanes in each
traffic
direction /reconstruction of this major east-west
improvements
roadway from beach 62- to seagirt blvd
requests
17/26
DOT
Other expense
Seagirt Blvd reconstruction.
traffic
improvements
requests
18/26
NYCTA
Expand subway
start a AM/PM rush hour A train service to
service frequency or
shorten commute eliminate stops in brooklyn
hours of operations
23/26
NYCTA
Other transit service
Remove tolls from Cross bay bridge
requests
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 14
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
The city must fund the remaining projects in the Rockaway Parks conceptual plan. The City must also fund sand replenishment in the areas along the beach that have suffered from erosion until the Army Corps plan has been completed , Closed beaches this past summer have led to over crowing and loss of income tour local business owners.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Our community hosts over 8 million visitors every year during the summer beach season- we require more PEP officers, better maintenance support
Needs for Cultural Services
additional funding for our Libraries and the Arts
Needs for Library Services
increase local funding for our libraries and fund the construction of new Far rockaway Library, provide more services for our youth
Needs for Community Boards
Community board budgets should be held harmless in city wide budget cuts as a matter of Policy much like the Independent Budget Office. the City budget should also provide additional funding for new Phone and computer needs as well as any technological needs that the boards may need in addition to the regular budget The board needs a new telephone system ours is 20 years old and at times does not work and cannot be repaired
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/29
DPR
Reconstruct or
Fund phase 3 of American ball fields to include
Broad
upgrade a park or
community center in Broad Channel
Channel
amenity (i.e.
playground, outdoor
athletic field)
12/29
DPR
Provide a new or
Install boat ramp at Rockaway Community park
expanded park or
inside old landfill provide parking and lighting
amenity (i.e.
and bathroom facilities
playground, outdoor
athletic field)
13/29
DPR
Reconstruct or
construct parking lot at dog run located at
beach
upgrade a building
beach 85 street area and beach channel drive
channel drive
in a park
beach 85 st
beach 86 st
14/29
DPR
Provide a new or
Park house needed at Bay view Park
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
15/29
DPR
Reconstruct or
build low ramp skate park in Bayswater park
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
16/29
DPR
Provide a new, or
provide funding for design and constriction of
beach 88
new expansion to, a
park located at beach 88 street and beach
street beach
building in a park
channel drive
channel drive
20/29
DPR
Provide a new or
Build New community park/play ground at
Beach 62
expanded park or
Parks Dept site located at Beach 62 street and
street thursby
amenity (i.e.
Thursby ave
ave
playground, outdoor
athletic field)
22/29
DPR
Provide a new, or
Construct comfort station at planned new park
new expansion to, a
"Bay breeze" beach 88 street
building in a park
23/29
DPR
Provide a new, or
build two new comfort/concession stations
Boardwalk
new expansion to, a
along boardwalk between Beach 35 and Beach
Beach 35 st
building in a park
50 streets
Beach 50 st
24/29 DPR Reconstruct or
upgrade a building in a park
construct shade structures; 17th road park, along board walk from beach 17- 108 streets Beach 25,59,67,and b 108 streets
image
26/29 DPR Improve access to a
park or amenity (i.e. playground, outdoor athletic field)
purchase and install Mobi mats at all beach entrances
image
28/29 DPR Provide new type
and/or specific type of program
create and fund water safety and swim programs for NYC school age children to prevent drownings
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/26
DPR
Other requests for
fund design and construction of Parks dept.-
park, building, or
Conceptual plan- for parks throughout district
access
improvements
4/26
DPR
Other park
hire more maintenance workers during summer
maintenance and
beach season
safety requests
5/26
OMB
Provide more
provide funding to hire experts like engineers or
1931 mott
community board
planners
ave
staff
9/26
QL
Extend library hours
extend library hours, include sunday hours at
or expand and
Far Rockaway library
enhance library
programs
16/26
DPR
Enhance park safety
provide more park enforcement police and
through design
agents during summer beach season
interventions, e.g.
better lighting
(Expense)
19/26
DPR
Other park
Remove remaining old wood jetties adjacent to
maintenance and
beach
safety requests
20/26
DPR
Other park
purchase and install Mobi matts at all beach
programming
side ramps/entrances
requests
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/29
DOT
Reconstruct streets
Re construct Cross bay blvd -continue to raise
streets in Broad channel install storm sewers
with tide gate
2/29
DOT
Reconstruct streets
Raise Norton drive, install storm sewers and sea
wall
3/29
DPR
Reconstruct or
Fund phase 3 of American ball fields to include
Broad
upgrade a park or
community center in Broad Channel
Channel
amenity (i.e.
playground, outdoor
athletic field)
4/29
DOT
Other
install safety fence along seagirt blvd
beach 31 st
transportation
camp road
infrastructure
requests
5/29
DOT
Repair or build new
repair/replace bulkheads at all street ends in
seawalls or
CB14 Rockaway and Broad channel
bulkheads
6/29
DOT
Other capital traffic
with vastly expand summer beach traffic
improvements
roadway needs improvement
requests
7/29
DOT
Roadway
fund design and re- construction of Shorefront
Shorefront
maintenance (i.e.
Parkway, include storm sewers, have crosswalks
Parkway
pothole repair,
line up, have driveways for Dayton buildings line
beach 73 st
resurfacing, trench
up with traffic lights and cross access to east
beach 108 st
restoration, etc.)
bound road way-HWQ-1682
8/29
DEP
Develop a capital
beach 84 street from Beach channel drive north
project for specific
to dead end at the bay flood on a regular basis
street segments
storm and sanitary sewers are needed
currently lacking
sanitary sewers
9/29
DEP
Develop a capital
street flooding
project for specific
street segments
currently lacking
sanitary sewers
10/29
DEP
Inspect sanitary
add check valves and tide gates on ALL storm
sewer on specific
water outfall in district
street segment and
repair or replace as
needed (Capital)
11/29
DOT
Reconstruct streets
design and construct the project to widen
rockaway
Rockaway beach blvd/Edgemere AVE from
beach
beach 62 STREET TO beach 31 STREET
blvd/edgemere
ave beach 62
street beach
31 street
12/29
DPR
Provide a new or
Install boat ramp at Rockaway Community park
expanded park or
inside old landfill provide parking and lighting
amenity (i.e.
and bathroom facilities
playground, outdoor
athletic field)
13/29
DPR
Reconstruct or
construct parking lot at dog run located at
beach
upgrade a building
beach 85 street area and beach channel drive
channel drive
in a park
beach 85 st
beach 86 st
14/29
DPR
Provide a new or
Park house needed at Bay view Park
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
15/29
DPR
Reconstruct or
build low ramp skate park in Bayswater park
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
16/29
DPR
Provide a new, or
provide funding for design and constriction of
beach 88
new expansion to, a
park located at beach 88 street and beach
street beach
building in a park
channel drive
channel drive
17/29
DOT
Reconstruct streets
with increase in population and density and
traffic projected from Downtown Far Rockaway
Plan this east-west roadway must be improved
18/29
NYCHA
Renovate or
improve buildings maintance
upgrade public
housing
developments
19/29
NYCTA
Other transit infrastructure requests
re institute the old Rockaway beach rail line
20/29
DPR
Provide a new or
Build New community park/play ground at
Beach 62
expanded park or
Parks Dept site located at Beach 62 street and
street thursby
amenity (i.e.
Thursby ave
ave
playground, outdoor
athletic field)
21/29
DEP
Move a planned
on south side of Addabbo bridge on Cross bay
capital project into
blvd drainage via duct is collapsing needs
the budget for the
replacement
next fiscal year
22/29
DPR
Provide a new, or
Construct comfort station at planned new park
new expansion to, a
"Bay breeze" beach 88 street
building in a park
23/29
DPR
Provide a new, or
build two new comfort/concession stations
Boardwalk
new expansion to, a
along boardwalk between Beach 35 and Beach
Beach 35 st
building in a park
50 streets
Beach 50 st
24/29
DPR
Reconstruct or
construct shade structures; 17th road park,
upgrade a building
along board walk from beach 17- 108 streets
in a park
Beach 25,59,67,and b 108 streets
25/29
DOT
Repair or build new
design build- bulkhead along Norton drive from
Norton Drive
seawalls or
cold spring road to Dunbar street
Cold Spring
bulkheads
Road Dunbar
St
26/29
DPR
Improve access to a
purchase and install Mobi mats at all beach
park or amenity (i.e.
entrances
playground, outdoor
athletic field)
27/29
EDC
Make infrastructure
the need for restrooms at Beach 108 street ferry
investments that
terminal
will support growth
in local business
districts
28/29
DPR
Provide new type
create and fund water safety and swim
and/or specific type
programs for NYC school age children to prevent
of program
drownings
29/29
NYCHA
Renovate or
fund mold remediation in NYCHA developments
upgrade NYCHA
in CB 14
community facilities
or open space
CS HHC Provide a new or expanded health care facility
Provide funding for the expansion of St Johns Hospital
image
CS EDC Invest in capital projects to improve access to the waterfront
build ferry docks/piers and parking for two ferry locations one on east side of district one on west side of district
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/26
DOT
Expand the
Build parking lot for ferry - increase weekend
Beach 108 st
frequency or hours
hours for ferry during summer
Beach
of operation of
Channel dr
ferries
2/26
DPR
Other requests for
fund design and construction of Parks dept.-
park, building, or
Conceptual plan- for parks throughout district
access
improvements
3/26
DEP
Inspect sanitary
design and construct storm sewers at following
sewer on specific
locations: Wheatley street and Augustina ave
street segment and
Beach 9th street and Central ave Brunswick ave,
repair or replace as
Virginia street, Beach 12 street
needed (Expense)
4/26
DPR
Other park
hire more maintenance workers during summer
maintenance and
beach season
safety requests
5/26
OMB
Provide more
provide funding to hire experts like engineers or
1931 mott
community board
planners
ave
staff
6/26
DOHMH
Reduce mosquito
Every spring and summer the communities
populations
along Jamaica bay suffer from Mosquito issues
7/26
DOT
Other expense
study the feasibility of widening Rockaway
Rockaway
traffic
Beach blvd from Beach 110 street to beach 119
Beach Blvd
improvements
street
Beach 110 St
requests
Beach 119 St
8/26
SBS
Support
fund storefront program for Far Rockaway
development of
/Mott ave Shopping area, Rockaway Beach
local Storefront /
shopping area along Rockaway Beach blvd from
Facade
beach 102 - beach 84 street, Beach 129 street
Improvement
shopping area
Program
9/26
QL
Extend library hours
extend library hours, include sunday hours at
or expand and
Far Rockaway library
enhance library
programs
10/26
NYPD
Assign additional
Tourism has increased 10 fold during summer
uniformed officers
need for more Police officers.
11/26
DOT
Other expense traffic improvements requests
complete the widening to two lanes in each direction /reconstruction of this major east-west roadway from beach 62- to seagirt blvd
12/26
DSNY
Other cleaning
Cross bay blvd median in broad channel should
requests
be cleaned once a month May through
September Rockaway freeway should be
cleaned once a month all year round
13/26
DOE
Other educational
study- two new high schools- a Health related
programs requests
technical school and a Aviation services high
school
14/26
NYPD
Other NYPD
There is a need for back up generators/boats.
facilities and
equipment requests
(Expense)
15/26
DSNY
Provide more
rockaway is a summer tourist area basket pick
frequent litter
up should be 7 days a week from june-
basket collection
september
16/26
DPR
Enhance park safety
provide more park enforcement police and
through design
agents during summer beach season
interventions, e.g.
better lighting
(Expense)
17/26
DOT
Other expense
Seagirt Blvd reconstruction.
traffic
improvements
requests
18/26
NYCTA
Expand subway
start a AM/PM rush hour A train service to
service frequency or
shorten commute eliminate stops in brooklyn
hours of operations
19/26
DPR
Other park
Remove remaining old wood jetties adjacent to
maintenance and
beach
safety requests
20/26
DPR
Other park
purchase and install Mobi matts at all beach
programming
side ramps/entrances
requests
21/26
DOE
Other educational
Sunset Cove new park in Broad channel- fund a
programs requests
environmental education program for school
age children
22/26
DOE
Other educational programs requests
fund/expand gifted and talented programs in CB14
23/26
NYCTA
Other transit service
Remove tolls from Cross bay bridge
requests
24/26
DYCD
Provide, expand, or
expand in cb14 Beacon and compass programs
enhance
Cornerstone and
Beacon programs
(all ages, including
young adults)
25/26
DSNY
Other garbage
fund regular cleaning- of both side of Rockaway
collection and
point blvd- south side- beach 169-193 streets
recycling
northside Beach 184-201 streets
infrastructure
requests (Expense)
26/26
DYCD
Provide, expand, or
Fund Nest and Horizon programs in CB14
enhance after
school programs for
all grade levels

