- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 6 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1AsAzl4f5rjnQnC2TmrPsWqTfYS6sacjj/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1AsAzl4f5rjnQnC2TmrPsWqTfYS6sacjj/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
6
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 6
image
Address: 250 Baltic Street Phone: (718) 643-3027
Email: info@BrooklynCB6.org
Website: www.nyc.gov/brooklyncb1
Chair: Peter D. Fleming District Manager: Michael Racioppo
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Brooklyn Community Board 6 represents the neighborhoods of Carroll Gardens/South Brooklyn, Cobble Hill, Columbia Waterfront, Gowanus, Park Slope and Red Hook. From the Buttermilk Channel to Prospect Park, 104,709 people (2010 Census figure) choose to make our district their home.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 6
image
The three most pressing issues facing this Community Board are:
Affordable housing
Market Forces often cause people to have to leave their homes and move farther and farther out. We need to not only plan to keep our community at home, but we need to ensure that the support networks are in place to allow them to prosper in their home neighborhoods. This also means, regardless of any possible rezoning of Gowanus, that NYCHA properties are improved and maintained not just in this fiscal year but in perpetuity.
Commercial development (retail mix, small business, MWBE support, etc.)
Empty storefronts plague our community, and we would like to see additional time and energy spent on coming up with a solution that will allow our commercial strips to not only be resilient but to also be diverse in the wares that they sell. This also means that the IBZ must be preserved and expanded in any rezoning of Gowanus.
Infrastructure resiliency
2 of the neighborhoods that make up our district are susceptible to extreme weather. Red Hook and Gowanus are within flood zones and we urge the city to determine a means to protect our citizenry, businesses and industrial community. The simple fact that Red Hook a community so negatively affected by Superstorm Sandy was left out of the DCP Resilient Neighborhoods planning process, is an example of why resiliency should be factored in throughout the city’s decision-making process. It’s especially important regarding any possible Gowanus Rezoning.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 6
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
No comments
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/26
DOHMH
Other programs to
address public
health issues
requests
3/26
DFTA
Create a new senior
Sufficient funding is requested to increase
center or other
baseline operating budget allocations in existing
facility for seniors
senior centers. At a minimum, additional
funding is sought to help keep pace with cost of
living increases which over time take more and
more resources away from the base operating
budgets from programming and salary monies.
Effectively, by not providing for regular, modest
increases the senior centers' budgets are being
decreased over time as basic costs only go up.
This need is especially pressing with an aging
population, as more and more "baby boomers"
will be placing increasing demands on these
facilities, which is anticipated to increase in the
near future.
20/26
DOHMH
Other animal and
Sufficient funds are requested for the hire of
pest control
additional Health/Pest Control Inspectors for
requests
initial field evaluations and compliance
inspections. At least one inspector per
Community Board ought to be assigned to
eliminate bottlenecks in Pest Control servicing,
ensure that annual inspections of Health-
Licensed facilities can occur, improve agency's
productivity and reduce response times for
complaint investigation.
21/26 HRA Other domestic
violence services requests
Additional funding is requested to expand the spectrum of services that provide assistance to victims of domestic violence - from counseling to protection to shelter - in order to ensure that adequate resources exist to help this vulnerable population in need. Outreach and promotional materials are needed to reach the population, provide them with convenient access to services and help educate communities on the importance of these services to remove any fear and stigma that may be attached to these facilities.
image
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 6
image
M ost Important Issue Related to Youth, Education and Child Welfare
Other
No comments
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
1/36 SCA Provide a new or
expand an existing middle/intermediate school
Sufficient funds are requested for the design and construction of a soundproofing project at the PS 321 gymnasium at 180 7th Avenue in Park Slope. The poor acoustics in the gymnasium prevents it from being effectively used a multi-purpose space in a school that is historically crowded and in need of additional space. A relatively small project to soundproof the gymnasium would enhance school space utilization, making it more suitable for a wider variety of uses.
image
36/36 SCA Renovate other site
component
Funds in the amount of at least $150,000 are requested for the design and construction of a soundproofing project at the PS 39 cafeteria at 417 6th Avenue in Park Slope. The tiny cave-like basement cafeteria is the largest open space in the school. The low tin roof and cement walls do little to absorb the loud whir of giant freezers or the noise of the fans used to cool the space due to the lack of air conditioning and window space. When you add more than 350 students during lunchtime the sounds reverberate around the room. The noise drowns out any conversations happening at the tables. By adding wall & ceiling mounted sound panels, extraneous noise will be lessened to manageable levels.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
9/26
DOE
Other educational
Sufficient funds are requested to ensure that
programs requests
every school in the Brooklyn Community Board
6 community district has anti-bullying program
resources available to all of the students, staff
and parents.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 6
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
No comments
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
No comments
image
Priority
Agency
Request
Explanation Location
28/36
NYPD
Other NYPD
Sufficient funds are requested for the acquisition
facilities and
of radar speed signs to provide advisories to
equipment requests
motorists in areas where speeding is suspected
(Capital)
or confirmed. Radar Speed Signs can provide a
constant monitoring presence to help raise
awareness and act as a potential deterrent.
Compliance with the City's new 25MPH speed
limit relies on an enforcement presence which,
at best, can be challenging given limitations of
manpower and competing deployment
priorities; to some degree these signs can help
augment these limitations.
31/36
NYPD
Other NYPD
Sufficient funds are requested for the acquisition
facilities and
and deployment of Variable Message Boards
equipment requests
(VMBs), at least one per precinct, to be used to
(Capital)
advise the public of upcoming street closures,
events, alerts and other vital information that
would enhance public safety and preparedness.
The strategic placement of VMBs can provide
important directions, reduce traffic congestion,
and otherwise assist NYPD in messaging
information to the public. Precinct Commanders
should have the flexibility to deploy VMBs as
needed and in response to ongoing changing
conditions within the precinct.
CS
FDNY
Other FDNY facilities
Sufficient funds are requested to equip every
and equipment
firehouse with an emergency generator to
requests (Capital)
ensure continuous electrical supply. Firehouses
serve as cooling stations during heat
emergencies and, in general, serve the public as
a critical local public safety facility for
emergency and medical services. Maintaining
electrical supply is essential both from an
operational standpoint and to maintain a high
degree of public confidence in the department's
ability to provide a safe haven during times of
crisis. We lost service to one of our firehouses in
Red Hook during Hurricane Sandy, and would
suggest that this site become an immediate
priority.
Priority
Agency
Request
Explanation
Location
6/26
NYPD
Other NYPD
Sufficient funds, personnel and equipment are
facilities and
needed to create a dedicated Quality of Life
equipment requests
Detail for the 78th Precinct to address the
(Expense)
ongoing issues related to the increases in night-
time activities-- especially at local bars and
restaurants--which have increased tensions
between our residential and business
communities. Despite having ample personnel
available for details related to large-scale
events at the Barclays Center, no such details
exist to regularly monitor the impacts of a
changing commercial environment as a result of
new trends in business land uses, especially in
the northern Park Slope area. The precinct mush
have sufficient resources available to ensure
that the quality of life for everyone in the
neighborhood is maintained and improved.
7/26
NYPD
Other NYPD
Sufficient funds are requested to provide for a
programs requests
substantial increase in dedicated Truck
Enforcement Program personnel to meet the
overwhelming demand in our community for
aggressive truck enforcement. Adherence to
Truck Routes is necessary to reduce conflicts
with, and impact on residential safety and
quality of life. To protect and preserve public
safety, effective enforcement is needed to
combat pervasive and dangerous violations.
12/26
NYPD
Other NYPD staff
Sufficient funds are requested to recruit and
resources requests
restore police patrol strength to safeguard the
impressive strides in public safety over the past
decade. Historically, as crime decreases and
budget pressures increase, police staff suffers
which begins the downward spiral of public
safety and increasing crime. Maintaining a
strong police force is even more necessary in the
aftermath of 9/11 to ensure public safety and
restore a high degree of confidence in keeping
and attracting residents, businesses and tourists
to the City - all essential to the City's economy.
Over the past few years we have seen a
dramatic decrease in the size of the police
patrol strength at the precinct level and this has
the community most alarmed.
17/26 NYPD Other NYPD staff
resources requests
Sufficient resources are requested to restore NYPD bicycle patrols. Bicycle patrols provide a low-cost option for policing that combines the best elements of vehicular access with flexible patrol routes. With increased bicycling, and the call for better enforcement of bicycling rules, it would also provide a more convenient way for police to engage other bicyclists in the proper education and enforcement of the rules of the road. Previous bicycle patrols involved the use of vouchered and donated bicycles making this a cost-effective program that should be reinstituted.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 6
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Other
No comments
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
34/36 DSNY Provide new or
upgrade existing sanitation garages or other sanitation infrastructure
Sufficient funds are requested for the relocation of BK2 District Sanitation Garage and Broom Garage into the Community Board 2 district to comply with coterminality requirements of the Charter. In the interim, we encourage the department to explore alternatives at the current garage location at 127 2nd Avenue including the reconstruction of the existing garage (addition of a story?) to fully accommodate all fleet vehicles and equipment off the street and sidewalk and under one roof.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
11/26
DSNY
Provide more
Sufficient funds are requested to restore the
frequent garbage or
frequency of litter basket service to a minimum
recycling pick-up for
of two collections per day, especially on
schools and
weekends, along busy commercial corridors
institutions
such as Van Brunt Street, Columbia Street, Court
Street, Smith Street, 5th Avenue, 7th Avenue,
Atlantic Avenue, and Flatbush Avenue.
Overflowing litter baskets create additional
work for the department in discretionary
cleaning, contributes to the clogging of catch
basins, and results in the unfair issuance of
summonses to victims of the strewn litter. Litter
on commercial strips negatively contributes to
the consumer's shopping experience, detracts
from the residents' quality of life, and forces the
businesses to shoulder the burden for the City
after the mess.
13/26 DSNY Other cleaning
requests
Sufficient funds are requested for the design, construction and servicing of a Containerized Garbage Collection System for the John Jay Educational Campus at 237 7th Avenue in Park Slope. Current practice involves placing excessive numbers of garbage bags in the street late afternoons, which are sometimes not collected until the next day, which attracts vermin and vectors, creates odors, and has a tendency to attract additional loose litter and debris. Containerized collection would resolve all of these problems and restore neighbor's quality of life.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 6
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Other
No comments
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
5/36
SBS
Other capital
Sufficient funds are requested for the acquisition
workforce
(if necessary), design and construction of a Red
development
Hook workforce development center. Red Hook
requests
has seen the creation of hundreds of new jobs in
the last few years from large-scale retail
development, introduction of tourism-related
industries, and induced commercial
development. Its residential population is in
need of a local job center where employment
training, recruiting and referral services can be
offered in addition to courses that promote local
entrepreneurship, and generally support the
development of the local workforce preparing
them for jobs. Because of its geographic
isolation and transportation hurdles, Red Hook
residents cannot easily access services in
Downtown Brooklyn.
8/36
NYCHA
Other public
Sufficient funds are requested for the design
housing upgrades or
and construction of new building entrance
renovations
systems for all residential buildings within
requests
NYCHA's public housing portfolio. New building
entrance systems would include vandal-proof,
tamper- proof locking mechanisms, reinforced
doors and frames, modern intercom systems
with closed circuit cameras, and remote
monitoring to automatically detect and report
security breaches and equipment failures.
9/36
EDC
Invest in capital
Sufficient funds are requested for the design
projects to improve
and construction of a solar collection array at
access to the
Piers 6- 12. Such an array should include the
waterfront
pier shed rooftops, other structure rooftops
(such as the cruise ship terminal, containerport
and PANYNJ office buildings, etc.), and canopy
arrays over parking lots at cruise ship terminal,
office buildings, etc. A solar collection array
would take advantage of the open space/lack of
shadow lines from buildings and trees, to
harvest solar energy which would be used to
defray operating costs as a clean energy
sustainability measure, and can be made
available to the community as part of a
community microgrid under development (Red
Hook Community Microgrid) to help power local
critical facilities in the event of an electrical grid
failure.
15/36
NYCHA
Renovate or
Sufficient funds are requested for the design
upgrade NYCHA
and rehabilitation of the NYPD PSA1 satellite
community facilities
building at 80 Dwight Street on NYCHA grounds
or open space
in Red Hook houses. Features of a renovated
building would include better signage, lighting,
fencing, landscaping and a more inviting
entryway so that residents feel welcome and
encouraged to use this site for positive
interactions with the police. Such a project could
also include operational enhancements to assist
the police (wireless telecommunications, fiber
optics, etc.), and resiliency and flood-proof
measures such as redundant electrical systems
(photovoltaics and generators), HVAC upgrades,
etc.
19/36
NYCHA
Renovate or
Sufficient funds are requested for a redesign
upgrade NYCHA
and rehabilitation of the existing Wyckoff
community facilities
Gardens Community Center to allow for a more
or open space
efficient and effective use of the space.
Modernization should include but not be limited
to such items as improved security system, new
lighting/electrical systems, HVAC/plumbing
upgrades, painting and masonry. A solar energy
system should also be added to the rooftop as a
sustainability and resiliency measure to enable
the center to remain powered in the event of
electrical grid disruption or failure.
23/36
HPD
Provide more
Sufficient funds are requested for the planning,
housing for special
site selection/acquisition, development and
needs households,
construction of affordable senior housing in the
such as the formerly
Carroll Gardens section of our district.
homeless
32/36
EDC
Make infrastructure
Sufficient funds are requested for the planning
investments that
and construction of a cross harbor freight tunnel
will support growth
to link New York and New Jersey by rail to 1)
in local business
provide for the efficient movement of bulk
districts
goods through the region, 2) reduce the amount
of truck traffic with its corresponding impacts
on traffic volumes, air quality, public safety, etc.,
and 3) expand opportunities for economic
growth in the region. Transportation is one of
the most significant obstacles to growth in the
region, as our bridges, tunnels and highways
experience on a daily basis. Without taking
advantage of the area's features - its waterfront
and untapped rail potential - further economic
growth in the region is threatened. Replacing
truck use by rail and barge options should be
our top priority. (REQUEST IS FOR PANYNJ!)
CS EDC Invest in capital projects to improve access to the waterfront
Sufficient funds are requested for the design and construction of a maritime cultural use at the Atlantic Basin, as we previously suggested, discussed and promised by EDC during and since the development of their Piers 6-12 study for the Brooklyn Waterfront. Many years have lapsed since the study, yet there is no cultural use in place despite the agency's commitments to the community. Funds are needed to provide suitable docking facilities, upland connections and necessary infrastructure (electrical, water, sewage, etc.) to support such a use.
image
CS EDC Invest in capital projects to improve access to the waterfront
Sufficient funds are requested for the design and construction of a maritime cultural use at the Atlantic Basin, as we previously suggested, discussed and promised by EDC during and since the development of their Piers 6-12 study for the Brooklyn Waterfront. Many years have lapsed since the study, yet there is no cultural use in place despite the agency's commitments to the community. Funds are needed to provide suitable docking facilities, upland connections and necessary infrastructure (electrical, water, sewage, etc.) to support such a use.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
4/26 SBS Other expense workforce development requests
To combat high levels of unemployment, particularly in our Gowanus and Red Hook neighborhoods, coupled with significant Federal changes in the existing public assistance programs, additional focus must be placed on preparing persons for work and expanding work opportunities. Given the far- reaching impact of unemployment and its undesirable effects on health, education and social welfare, it is imperative that front-end investment in human capital occur to ensure local economic utility.
image
5/26 NYCHA Other housing
support requests
Sufficient funds are requested for NYCHA to issue an RFP to identify and select an operator for the Gowanus Houses Community Center who would engage the community and maintain the site as an active recreation, education and cultural center.
image
16/26 NYCHA Other housing
support requests
Sufficient funds are requested for the expansion of NYCHA Maintenance personnel staff, perhaps through the creation of an in-house training program that would take employable NYCHA residents and train them in the skilled trades in an apprenticeship program and workforce development initiative. Upon successful completion of the program, graduates could be placed in maintenance and construction positions in the private market through the NYCHA- REES program.
image
24/26 SBS Other business regulatory assistance requests
Sufficient funds are requested to hire additional Waterfront Enforcement Division personnel, currently 6 persons citywide, to ensure that adequate coverage of the City's 578 miles of waterfront will be preserved and protected.
Waterfront Enforcement Division personnel are responsible for enforcing the City's building code for waterfront properties, some of the most valuable and sensitive properties in the City.
This would be a good way to reverse the trend of neglect suffered by the City's lack of waterfront development policies over the past few decades, and signify a commitment to the renewed importance of the City's waterfront as an asset and resource to draw from.
TRANSPORTATION
Brooklyn Community Board 6
image
M ost Important Issue Related to Transportation and Mobility
Other
No comments
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
2/36
NYCTA
Improve
Sufficient funds are requested for the
accessibility of
identification, design, and construction of
transit
handicapped access elements, preferably
infrastructure, by
elevators, for the Smith-9th Street subway the
providing elevators,
station, which happens to be the highest
escalators, etc.
elevated public transit point in the entire world.
Despite a recent comprehensive station
rehabilitation, escalators at this station are still
prone to frequent service disruptions which not
only inconveniences riders but makes station
access impossible for physically-challenged
individuals. This station is also the only subway
stop nearest to the Red Hook community, a
neighborhood woefully under-served by
transportation options.
3/36
DOT
Improve traffic and
In conjunction with the city's infrastructure
pedestrian safety,
work being planned under HWK700B, sufficient
including traffic
funds are requested to undertake the design
calming (Capital)
investigation and construction of appropriate
amenities and traffic calming devices to
facilitate the safe movement of pedestrians and
traffic. Such amenities could include, but not be
limited to, the reintroduction of cobblestone
treatments, historic lighting, granite curbs, etc.
The scope of the existing street reconstruction
project should be expanded to include a full
electrical upgrade for all of Red Hook with the
goal of burying the vulnerable, above-ground
electrical lines and ensuring that the grid is
modern and able to withstand future events like
Hurricane Sandy which plunged the area into
darkness for months.
4/36
DOT
Reconstruct streets
Sufficient funds are requested for the design
and construction of new traffic medians on 4th
Avenue between Pacific Street and 8th Streets
that would improve pedestrian and vehicular
safety along this busy traffic corridor. New
medians would include protected pedestrian
refuge areas and raised, planted medians with
irrigation systems, that would prevent unsafe
and unpredictable pedestrian behavior which
occurs frequently and is likely a contributing
cause to high accident rates along the corridor.
6/36 NYCTA Repair or upgrade
subway stations or other transit infrastructure
Sufficient funding is requested for the design and construction of handicapped access elements, preferrably elevators, for the Grand Army Plaza subway station, which is not only an important intermodal transfer within the transit system but also provides primary access to a number of Brooklyn's most visited cultural institutions--such as the Grand Army Plaza, Prospect Park, and the Brooklyn Public Library Central Branch--and is a gateway to the Flatbush Avenue and Park Slope commercial corridors.
image
7/36 NYCTA Improve accessibility of transit infrastructure, by providing elevators, escalators, etc.
Sufficient funds are requested to undertake a comprehensive redesign and reconstruction of this subway station to include a mezzanine arcade that would convert the underutilized underground space as a commercial area offering small shops - ideally tenanted by local entrepreneurs and independent business owners - with goods and services targeted to the patrons who routinely utilize this subway station, specifically, local residents, employees of NY Methodist Hospital, students at John Jay Educational Campus, and other employers/employees and visitors to the neighborhood. The station should also be retrofit with handicapped access points. This project would also provide a new revenue stream for NYC Transit and promote a more active use of this space.
image
12/36 DOT Reconstruct streets Funds in the amount of $26,300,000 are
requested to undertake a reconstruction of the Union Street Bridge (HBK1213), a double-leaf Scherzer Bascule bridge which spans the Gowanus Canal. This bridge received a FAIR rating yet is one of the few east-west connectors that provide access and mobility throughout our district. It is a vital corridor that links our waterfront to inland points. Deferred public investment increases the vulnerability of this structure as unanticipated structural failures may occur, resulting in increased cost and time of repair and unwarranted impacts on the surrounding community. We would also like a modified riding surface for the bicycle lane section of the bridge to make it safer and more comfortable for the cyclists who use this segment of the network.
image
13/36 DOT Reconstruct streets Funds in the amount of $26,300,000 are
requested to undertake a reconstruction of the Union Street Bridge (HBK1213), a double-leaf Scherzer Bascule bridge which spans the Gowanus Canal. This bridge received a FAIR rating yet is one of the few east-west connectors that provide access and mobility throughout our district. It is a vital corridor that links our waterfront to inland points. Deferred public investment increases the vulnerability of this structure as unanticipated structural failures may occur, resulting in increased cost and time of repair and unwarranted impacts on the surrounding community. We would also like a modified riding surface for the bicycle lane section of the bridge to make it safer and more comfortable for the cyclists who use this segment of the network.
image
16/36 DOT Reconstruct streets Sufficient funds are requested for the
reconstruction of Court Street from Atlantic to Hamilton Avenues with historic amenities.
Preliminary Design Investigation to ascertain the condition of the infrastructure along the project limits. Relocate all utility service boxes below ground, repair/replace missing curb sections, reset curb elevations, repair concrete bus pads and repair defective sidewalk conditions. Use granite curb, bluestone or pigmented concrete sidewalks, historic replica street hardware including street lights, poles-in- ground, fire alarm boxes and hydrants. Also, the inclusion of appropriate traffic calming devices such as, but not limited to, neck downs, bus bulbs, etc. as called for in the Downtown Brooklyn Traffic Calming project.
image
17/36 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Sufficient funds should be allocated toward the inclusion of special treatment street resurfacing work in the department's development of future contract work to incorporate the restoration, preservation and maintenance of cobblestone streets. This construction material serves as a traffic calming device, is far more durable than commonly used asphalt material, is a signature characteristic of streets in our Red Hook community and enhances the historic integrity of the community.
image
18/36
DOT
Rehabilitate bridges
Sufficient funds are requested for a full
rehabilitation of the 3rd Street Bridge (HBKC068), a double-leaf Bascule Bridge spanning the Gowanus Canal, to improve long- term viability of the structure. For the sake of access and mobility through the district, there are only a handful of east-west connectors that span the Gowanus Canal, on which the community is wholly reliant. Deferred investment increases the likelihood of structural failures, more costly repairs, and longer periods of disruption and inconvenience to the community when the bridge is out of service.
We would also like a modified riding surface for
the bicycle lane section of the bridge to make it safer and more comfortable for the cyclists who use this segment of the network.
22/36
DOT
Reconstruct streets
Sufficient funds are requested to remediate the problems associated with the Brooklyn-Queens Expressway Trench running through our district parallel to Hicks Street. The BQE Trench inhibits local access and mobility between the Columbia Waterfront, Carroll Gardens and Cobble Hill neighborhoods. The concentration of traffic flowing through the trench creates vibrations, noise, odors and other air emissions that impact the residential communities adjacent to the trench. The trench provides opportunities to create new open space and expand resiliency measures (photovoltaics, storm water capture/diversion, etc.). Building on the momentum of a prior study's findings, remedies and opportunities must now be considered, funded and constructed.
24/36
DOT
Other
Sufficient funds are requested for the
transportation
construction of traffic safety median islands in
infrastructure
the Furman-Atlantic-Columbia transition area,
requests
the approach to Brooklyn Bridge Park's Pier 6
public park, and area growing in popularity and
increasingly traveled by pedestrians and
recreation users. Prior to the opening of Pier 6,
this area was generally unused by pedestrians
and was almost exclusively a southbound route
used by commuters seeking to avoid the
Brooklyn-Queens Expressway. Now, with the
opening of Pier 6 and the two-way conversion of
Furman Street, vehicular and pedestrian traffic
patterns have completely altered the use and
complexion of this bustling area. Immediate in-
house improvements have done a lot to improve
safety, at the cost of aesthetics.
25/36
DOT
Other
Sufficient funds are requested for the full
transportation
installation of all terracotta street name and
infrastructure
historic district maps/narrative signage in the
requests
Carroll Gardens, Cobble Hill and Park Slope
Historic Districts. New signage is especially
needed in Park Slope with the approved
expansion of the Park Slope Historic District in
2012.
26/36
NYCTA
Other transit
Sufficient funds are requested for the
infrastructure
installation of cellular/Wi-Fi service in subways
requests
systems as a way of improving public safety by
increasing channels of communication between
riders and emergency service providers in the
event that emergency assistance is needed.
29/36
DOT
Other
Sufficient funds are requested to undertake a
transportation
replacement of the existing standard-issue
infrastructure
cobra head street lights with appropriate
requests
historic replica street lights in the
neighborhoods of Cobble Hill and Carroll
Gardens. Currently, only Atlantic Avenue, Clinton
Street and Smith Street in these neighborhoods
have such amenities. The balance of the
neighborhood's street lights should be replaced
to enhance and restore the historic integrity of
these landmark districts and historically-
sensitive areas.
30/36 DOT Repair or construct
new curbs or pedestrian ramps
In addition to the regular cement sidewalk replacement activity, we request that the department broaden its scope to include the option of restoring by contract those sidewalks which include special treatments, notably bluestone material. Not only is bluestone a more durable material with significantly longer life expectancy, it also serves to enhance the historic integrity and value of the community. Many property owners are willing to pay the extra cost to have this option, especially given the City's ability to leverage lower cost through bulk contracting.
image
33/36 DOT Reconstruct streets Sufficient funds are requested for the
acquisition, mapping, design and construction of a new City street which would extend Conover Street northward from Pioneer Street to Hamilton Avenue in Red Hook. This new street will not only provide additional capacity to handle the new traffic volumes destined for the cruise ship terminal under construction at Pier 12, but will also provide an alternative for the relocation of the Van Brunt Street leg of the City's local Truck Route network in Red Hook. It will ensure that the local street grid is not only not negatively impacted by the cruise terminal traffic but that it will benefit from relieving Van Brunt Street of trucks and removing the existing conflict by directing trucks closer to the industrial section of the neighborhood.
image
CS DOT Other transportation infrastructure requests
Sufficient funds are requested to fully fund project SEK20068 for preliminary design investigations, final design and ultimate repair of the 9th Street and Second Avenue corridors abutting the Gowanus Canal. Issues that need to be addressed include negative and insufficient curbs that have resulted in flooding and drainage problems, defective and missing sidewalks and episodic infrastructure failures on 2nd Ave. Frequent and substantial roadway ponding occurs along 9th Street--a mapped Coastal Evacuation Route--which, coupled with new and growing demands in pedestrian and vehicular traffic, requires that the street be a more reliable emergency traffic conveyor and able to withstand rainfall events without
image
CS DOT Other transportation infrastructure requests
Sufficient funds are requested to fully fund project SEK20068 for preliminary design investigations, final design and ultimate repair of the 9th Street and Second Avenue corridors abutting the Gowanus Canal. Issues that need to be addressed include negative and insufficient curbs that have resulted in flooding and drainage problems, defective and missing sidewalks and episodic infrastructure failures on 2nd Ave. Frequent and substantial roadway ponding occurs along 9th Street--a mapped Coastal Evacuation Route--which, coupled with new and growing demands in pedestrian and vehicular traffic, requires that the street be a more reliable emergency traffic conveyor and able to withstand rainfall events without
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
14/26 DOT Other expense
traffic improvements requests
Sufficient funds are requested for restoration of full- time (non-seasonal) work gangs to respond to year- round routine maintenance calls for potholes and street depressions. There has been a noticeable decrease in productivity and increase in response times in this area attributable to significant loss of manpower.
There has also been a significant delay in pothole response times during the winter-spring transition which could be remedied by maintaining more year-round personnel to respond to complaints.
image
15/26 DOT Other expense
traffic improvements requests
Sufficient funds are requested for restoration of full- time (non-seasonal) work gangs to respond to year- round routine maintenance calls for potholes and street depressions. There has been a noticeable decrease in productivity and increase in response times in this area attributable to significant loss of manpower.
There has also been a significant delay in pothole response times during the winter-spring transition which could be remedied by maintaining more year-round personnel to respond to complaints.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 6
image
image
Most Important Issue Related to Parks, Cultural and Other Community Facili es
Other
No comments
image
image
Community District Needs Related to Parks, Cultural and Other Community Facili es
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
10/36
DPR
Reconstruct or
Sufficient funds are requested for a
upgrade a building
comprehensive facility rehabilitation project for
in a park
the Red Hook Recreation Center. Scope of work
to include at a minimum upgraded
programming space for users, office space for
department personnel (i.e., painting, electrical,
windows, lighting, etc.), perimeter
improvements and outfitting with new
recreation and office equipment to support both
users and staff. It is essential that increasing
demands for local recreational opportunities be
met within the neighborhood as transportation
options available within the neighborhood limit
the extent to which local residents can take
advantage of facilities in other neighborhoods.
11/36
BPL
Create a new, or
A total of $6.35M is requested for infrastructure
renovate or upgrade
upgrades to the Carroll Gardens branch library,
an existing public
to specifically include exterior renovation and
library
windows ($1.0M), new boiler ($750k), interior
renovation ($3.0M), new furniture & equipment
($750k), and safety and security enhancements
($250k). The Carroll Gardens branch is an
unrenovated, heavily-utilized Carnegie branch.
The building's critical infrastructure needs to be
upgraded.
20/36
BPL
Create a new, or
A total of $10.2M is requested for infrastructure
renovate or upgrade
upgrades to the Pacific branch library, to
an existing public
specifically include ADA compliance for the
library
entire branch ($3.0M), new boiler ($750k),
exterior restoration ($600k), HVAC ($1.0M),
interior renovation ($3.0M), new furniture &
equipment ($600k), safety and security
enhancement ($250k), and windows ($1.0M).
The Pacific branch library is an unrenovated,
well- utilized Carnegie branch. The building's
critical infrastructure needs to be upgraded.
21/36 BPL Create a new, or
renovate or upgrade an existing public library
Funds in the amount of $3.0M are requested for the design and construction of roof and restoration of skylights ($1.0M) and exterior renovations ($2.0M) for the Park Slope branch library. The Park Slope library was recently reopened after an extensive interior renovation. This heavily-utilized branch and beloved community institution is one of the three landmarked Carnegie branches in the BPL system. A total exterior renovation would include brick work, refurbished wrought-iron fencing, stonework/repair of concrete entrance stairs, improved signage, landscaping, and sidewalk repair work.
image
27/36 DCAS Renovate, upgrade
or provide new community board facilities and equipment
Sufficient funds are requested for the design and construction of a window replacement project for 250 Baltic Street in the Cobble Hill Historic District. This 1936 building still has the original single-paned and uninsulated windows making them highly inefficient energy-wasting devices which negatively contribute to the building tenants' comfort and safety. Modern, energy- efficient windows appropriately designed to area's historic district would go a long way toward reducing heating and cooling costs, improving safety, and creating a vastly improved work environment for the State, City and non- profit entities that occupy the space in this City- owned building. While the City-State have talked about changing ownership status of this building for more than a decade, it will crumble
image
35/36 DPR Provide a new or
expanded park or amenity (i.e. playground, outdoor athletic field)
Sufficient funds are requested for the design and construction of a new park--Columbia Waterfront Park--on the City-owned properties along the westside of Columbia Street between Kane and Degraw Streets. These properties are currently in the Department of Transportation's portfolio but they have agreed to release them for the development of a future park to be built there. Much work has already gone into conceptualizing a park use of the space which, with an adequate budget, can be easily adapted into designs and construction plans.
image
CS DPR Provide a new or expanded park or amenity (i.e. playground, outdoor athletic field)
Sufficient funds are requested to undertake a series of Capital improvements to Prospect Park including, but not limited to: Lakeside Project ($9 mil additional), Long Meadow ball fields ($1.2 mil), lighting at Grand Army Plaza and the arch at Grand Army Plaza, and a continuation of traffic improvements at the Grand Army Plaza circle.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
8/26 DPR Other park maintenance and safety requests
Sufficient funds are requested to restore Parks Maintenance personnel to provide for vital maintenance and report of Parks facilities. With the added supervisory role Parks Maintenance workers perform through the departmental use of JTP and other volunteer workers, more staff are needed to continue to fulfill the traditional roles and tasks performed by Parks Maintenance staff.
image
10/26 OMB Provide more
community board staff
Funding in the amount of $450,000 is requested in order for Community Boards to fulfill their Charter mandated roles to plan and advocate for neighborhood needs. An increase in funds will be used to fund the hiring of a full-time urban planner, to keep pace with cost of living adjustments which have never been applied to Community Boards, to upgrade complaint systems software which was previously supplied and supported by prior Administrations and to expand District Office functionality with the purchase of additional equipment and supplies. Increases to budget due to collective bargaining agreements and maintaining the budget at its current level do not address this request; both are effectively negative responses which should trigger a separate letter explaining the agency's position.
image
18/26 DPR Other park maintenance and safety requests
Sufficient funds are requested to restore Parks Recreation personnel to increase the inventory and range of recreation options available particularly to our teenage youth population. With fewer part-time job opportunities and shrinking afterschool programs we are looking to increase the number of constructive options for this population to keep them engaged in productive, supervised activities.
image
19/26 DPR Other street trees
and forestry services requests
Sufficient funds are requested to hire additional Parks Forestry personnel to regularly address pruning and stump removal to maintain the health and safety of our communities. While the city allocates sufficient money for the continuous planting of new trees increasing the City's inventory of street trees, particularly with the aggressive Million Trees Initiative, corresponding increases in the Parks Forestry Division are a necessary accompaniment to ensure that sufficient resources are available for ongoing maintenance needs.
image
26/26 DPR New equipment for
maintenance (Expense)
Sufficient funds are requested to ensure the timely replacement of fleet vehicles used int he service of our public parks properties including collection vehicles, repair vehicles, enforcement patrol vehicles, pickup trucks, etc.
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority Agency Request Explanation Location
image
14/36 Other Other capital budget
request
DEP: Sufficient funds are requested to design & construct an environ'al programming site at a City-owned parcel (the Gowanus "Salt Lot") to be developed as a site for environ'al education & programming to promote sustainability in areas such as composting, recycling, stormwater capture and reuse, green infrastructure and environmental stewardship. Having a permanent site in the Gowanus watershed area, proximate to the canal, will go far in ensuring that such practices and values are regularly and widely taught and shared, making them more likely to affect the broader surrounding populations. The site should be able to accomodate both locally- based and visiting groups of all ages, including school children who could use more access to environmental education in our urban environs.
image
CS Other Other capital budget request
DEP: Sufficient funds are requested for the area wide installation of green infrastructure including, but not limited to, bioswales, offline retention capacities, rain barrels, pervious surface treatments, and other best management practices, to aggressively prevent storm water from entering into the sewer system. Reduction of storm water entry into the system is necessary to reduce the amount of Combined Sewer Overflow events that occur, particularly within the Gowanus watershed area.
Other Expense Requests
Priority Agency Request Explanation Location
image
2/26 Other Other expense
budget request
ACS: Sufficient funds are requested to maintain current levels of day care services provided to the district. ACS had previously suggested that an incredibly disproportionate share of cuts be applied to day care services in the Brooklyn CB6 district. 4 out of the 15 centers citywide slated for closure were specifically targeted to the district. Most of these slots are located in facilities directly adjacent to public housing (Red Hook and Gowanus Houses), whose residents rely on these services to enable them to work and/or attend school. Eliminating day care services removes one of the most important safety nets in the community. ACS had not attempted to renegotiate day care center leases, or otherwise lower their operating costs, before deciding to eliminate the service altogether.
image
22/26 LPC Expand staffing and
program related services
Sufficient funds are requested to provide for the hire of additional LPC inspection and enforcement personnel to address complaint investigations, improve upon agency response times to requested inspections, and foster a global atmosphere of increased compliance with landmark regulations. Given the expansion of the role of the agency through the broadening of their enforcement powers to include the issuance of civil penalties, an accompanying increase of personnel is necessary to carry out the agency's additional enforcement mandates.
image
23/26 Other Other expense
budget request
EDC: Sufficient funds are requested for the acquisition, planning and construction of a district wide tourism center, perhaps located at the Red Hook Cruise Ship Terminal, to provide a focal point for the growing tourism industry in our district. Such features as our historic brownstone residential communities (Carroll Gardens, Cobble Hill and Park Slope), Columbia Street, Gowanus and Red Hook waterfront features, Prospect Park, and other local points- of-attraction, are growing in popularity as tourists are flocking more and more to our district. A tourism center that would highlight the cultural, shopping, restaurants and other features of the district will help ensure that marketing and promotion of the district's amenities were fully leveraged.
image
25/26 Other Other expense
budget request
SBS: Sufficient funds are requested to support existing and enable additional groups to embark on feasibility studies and supportive planning activities to move toward the formation of additional Business Improvement Districts (BID) in appropriate commercial and industrial areas. BIDs are proven to be an asset for the City insofar as they provide needed administrative infrastructure designed to support local commerce at the neighborhood level.
Furthermore, the expansion of BIDs from the traditional commercial into the industrial sector will enable the City to better protect the fragile manufacturing sector, which often produces higher wage paying jobs, with specialty skills, and reduces the cost of goods in the City by making us less reliant on imports.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/36
SCA
Provide a new or
Sufficient funds are requested for the design
expand an existing
and construction of a soundproofing project at
middle/intermediate
the PS 321 gymnasium at 180 7th Avenue in
school
Park Slope. The poor acoustics in the
gymnasium prevents it from being effectively
used a multi-purpose space in a school that is
historically crowded and in need of additional
space. A relatively small project to soundproof
the gymnasium would enhance school space
utilization, making it more suitable for a wider
variety of uses.
2/36
NYCTA
Improve
Sufficient funds are requested for the
accessibility of
identification, design, and construction of
transit
handicapped access elements, preferably
infrastructure, by
elevators, for the Smith-9th Street subway the
providing elevators,
station, which happens to be the highest
escalators, etc.
elevated public transit point in the entire world.
Despite a recent comprehensive station
rehabilitation, escalators at this station are still
prone to frequent service disruptions which not
only inconveniences riders but makes station
access impossible for physically-challenged
individuals. This station is also the only subway
stop nearest to the Red Hook community, a
neighborhood woefully under-served by
transportation options.
3/36
DOT
Improve traffic and
In conjunction with the city's infrastructure
pedestrian safety,
work being planned under HWK700B, sufficient
including traffic
funds are requested to undertake the design
calming (Capital)
investigation and construction of appropriate
amenities and traffic calming devices to
facilitate the safe movement of pedestrians and
traffic. Such amenities could include, but not be
limited to, the reintroduction of cobblestone
treatments, historic lighting, granite curbs, etc.
The scope of the existing street reconstruction
project should be expanded to include a full
electrical upgrade for all of Red Hook with the
goal of burying the vulnerable, above-ground
electrical lines and ensuring that the grid is
modern and able to withstand future events like
Hurricane Sandy which plunged the area into
darkness for months.
4/36 DOT Reconstruct streets Sufficient funds are requested for the design
and construction of new traffic medians on 4th Avenue between Pacific Street and 8th Streets that would improve pedestrian and vehicular safety along this busy traffic corridor. New medians would include protected pedestrian refuge areas and raised, planted medians with irrigation systems, that would prevent unsafe and unpredictable pedestrian behavior which occurs frequently and is likely a contributing cause to high accident rates along the corridor.
image
5/36 SBS Other capital workforce development requests
Sufficient funds are requested for the acquisition (if necessary), design and construction of a Red Hook workforce development center. Red Hook has seen the creation of hundreds of new jobs in the last few years from large-scale retail development, introduction of tourism-related industries, and induced commercial development. Its residential population is in need of a local job center where employment training, recruiting and referral services can be offered in addition to courses that promote local entrepreneurship, and generally support the development of the local workforce preparing them for jobs. Because of its geographic isolation and transportation hurdles, Red Hook residents cannot easily access services in Downtown Brooklyn.
image
6/36 NYCTA Repair or upgrade
subway stations or other transit infrastructure
Sufficient funding is requested for the design and construction of handicapped access elements, preferrably elevators, for the Grand Army Plaza subway station, which is not only an important intermodal transfer within the transit system but also provides primary access to a number of Brooklyn's most visited cultural institutions--such as the Grand Army Plaza, Prospect Park, and the Brooklyn Public Library Central Branch--and is a gateway to the Flatbush Avenue and Park Slope commercial corridors.
image
7/36 NYCTA Improve accessibility of transit infrastructure, by providing elevators, escalators, etc.
Sufficient funds are requested to undertake a comprehensive redesign and reconstruction of this subway station to include a mezzanine arcade that would convert the underutilized underground space as a commercial area offering small shops - ideally tenanted by local entrepreneurs and independent business owners - with goods and services targeted to the patrons who routinely utilize this subway station, specifically, local residents, employees of NY Methodist Hospital, students at John Jay Educational Campus, and other employers/employees and visitors to the neighborhood. The station should also be retrofit with handicapped access points. This project would also provide a new revenue stream for NYC Transit and promote a more active use of this space.
image
8/36 NYCHA Other public
housing upgrades or renovations requests
Sufficient funds are requested for the design and construction of new building entrance systems for all residential buildings within NYCHA's public housing portfolio. New building entrance systems would include vandal-proof, tamper- proof locking mechanisms, reinforced doors and frames, modern intercom systems with closed circuit cameras, and remote monitoring to automatically detect and report security breaches and equipment failures.
image
9/36 EDC Invest in capital
projects to improve access to the waterfront
Sufficient funds are requested for the design and construction of a solar collection array at Piers 6- 12. Such an array should include the pier shed rooftops, other structure rooftops (such as the cruise ship terminal, containerport and PANYNJ office buildings, etc.), and canopy arrays over parking lots at cruise ship terminal, office buildings, etc. A solar collection array would take advantage of the open space/lack of shadow lines from buildings and trees, to harvest solar energy which would be used to defray operating costs as a clean energy sustainability measure, and can be made available to the community as part of a community microgrid under development (Red Hook Community Microgrid) to help power local critical facilities in the event of an electrical grid failure.
image
10/36 DPR Reconstruct or
upgrade a building in a park
Sufficient funds are requested for a comprehensive facility rehabilitation project for the Red Hook Recreation Center. Scope of work to include at a minimum upgraded programming space for users, office space for department personnel (i.e., painting, electrical, windows, lighting, etc.), perimeter improvements and outfitting with new recreation and office equipment to support both users and staff. It is essential that increasing demands for local recreational opportunities be met within the neighborhood as transportation options available within the neighborhood limit the extent to which local residents can take advantage of facilities in other neighborhoods.
image
11/36 BPL Create a new, or
renovate or upgrade an existing public library
A total of $6.35M is requested for infrastructure upgrades to the Carroll Gardens branch library, to specifically include exterior renovation and windows ($1.0M), new boiler ($750k), interior renovation ($3.0M), new furniture & equipment ($750k), and safety and security enhancements ($250k). The Carroll Gardens branch is an unrenovated, heavily-utilized Carnegie branch. The building's critical infrastructure needs to be upgraded.
image
12/36 DOT Reconstruct streets Funds in the amount of $26,300,000 are
requested to undertake a reconstruction of the Union Street Bridge (HBK1213), a double-leaf Scherzer Bascule bridge which spans the Gowanus Canal. This bridge received a FAIR rating yet is one of the few east-west connectors that provide access and mobility throughout our district. It is a vital corridor that links our waterfront to inland points. Deferred public investment increases the vulnerability of this structure as unanticipated structural failures may occur, resulting in increased cost and time of repair and unwarranted impacts on the surrounding community. We would also like a modified riding surface for the bicycle lane section of the bridge to make it safer and more comfortable for the cyclists who use this segment of the network.
image
13/36 DOT Reconstruct streets Funds in the amount of $26,300,000 are
requested to undertake a reconstruction of the Union Street Bridge (HBK1213), a double-leaf Scherzer Bascule bridge which spans the Gowanus Canal. This bridge received a FAIR rating yet is one of the few east-west connectors that provide access and mobility throughout our district. It is a vital corridor that links our waterfront to inland points. Deferred public investment increases the vulnerability of this structure as unanticipated structural failures may occur, resulting in increased cost and time of repair and unwarranted impacts on the surrounding community. We would also like a modified riding surface for the bicycle lane section of the bridge to make it safer and more comfortable for the cyclists who use this segment of the network.
image
14/36 Other Other capital budget
request
DEP: Sufficient funds are requested to design & construct an environ'al programming site at a City-owned parcel (the Gowanus "Salt Lot") to be developed as a site for environ'al education & programming to promote sustainability in areas such as composting, recycling, stormwater capture and reuse, green infrastructure and environmental stewardship. Having a permanent site in the Gowanus watershed area, proximate to the canal, will go far in ensuring that such practices and values are regularly and widely taught and shared, making them more likely to affect the broader surrounding populations. The site should be able to accomodate both locally- based and visiting groups of all ages, including school children who could use more access to environmental education in our urban environs.
image
15/36 NYCHA Renovate or
upgrade NYCHA community facilities or open space
Sufficient funds are requested for the design and rehabilitation of the NYPD PSA1 satellite building at 80 Dwight Street on NYCHA grounds in Red Hook houses. Features of a renovated building would include better signage, lighting, fencing, landscaping and a more inviting entryway so that residents feel welcome and encouraged to use this site for positive interactions with the police. Such a project could also include operational enhancements to assist the police (wireless telecommunications, fiber optics, etc.), and resiliency and flood-proof measures such as redundant electrical systems (photovoltaics and generators), HVAC upgrades, etc.
image
16/36 DOT Reconstruct streets Sufficient funds are requested for the
reconstruction of Court Street from Atlantic to Hamilton Avenues with historic amenities.
Preliminary Design Investigation to ascertain the condition of the infrastructure along the project limits. Relocate all utility service boxes below ground, repair/replace missing curb sections, reset curb elevations, repair concrete bus pads and repair defective sidewalk conditions. Use granite curb, bluestone or pigmented concrete sidewalks, historic replica street hardware including street lights, poles-in- ground, fire alarm boxes and hydrants. Also, the inclusion of appropriate traffic calming devices such as, but not limited to, neck downs, bus bulbs, etc. as called for in the Downtown Brooklyn Traffic Calming project.
image
17/36 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Sufficient funds should be allocated toward the inclusion of special treatment street resurfacing work in the department's development of future contract work to incorporate the restoration, preservation and maintenance of cobblestone streets. This construction material serves as a traffic calming device, is far more durable than commonly used asphalt material, is a signature characteristic of streets in our Red Hook community and enhances the historic integrity of the community.
image
18/36 DOT Rehabilitate bridges Sufficient funds are requested for a full
rehabilitation of the 3rd Street Bridge (HBKC068), a double-leaf Bascule Bridge spanning the Gowanus Canal, to improve long- term viability of the structure. For the sake of access and mobility through the district, there are only a handful of east-west connectors that span the Gowanus Canal, on which the community is wholly reliant. Deferred investment increases the likelihood of structural failures, more costly repairs, and longer periods of disruption and inconvenience to the community when the bridge is out of service.
We would also like a modified riding surface for
the bicycle lane section of the bridge to make it safer and more comfortable for the cyclists who use this segment of the network.
image
19/36 NYCHA Renovate or
upgrade NYCHA community facilities or open space
Sufficient funds are requested for a redesign and rehabilitation of the existing Wyckoff Gardens Community Center to allow for a more efficient and effective use of the space.
Modernization should include but not be limited to such items as improved security system, new lighting/electrical systems, HVAC/plumbing upgrades, painting and masonry. A solar energy system should also be added to the rooftop as a sustainability and resiliency measure to enable the center to remain powered in the event of electrical grid disruption or failure.
image
20/36 BPL Create a new, or
renovate or upgrade an existing public library
A total of $10.2M is requested for infrastructure upgrades to the Pacific branch library, to specifically include ADA compliance for the entire branch ($3.0M), new boiler ($750k), exterior restoration ($600k), HVAC ($1.0M), interior renovation ($3.0M), new furniture & equipment ($600k), safety and security enhancement ($250k), and windows ($1.0M).
The Pacific branch library is an unrenovated, well- utilized Carnegie branch. The building's critical infrastructure needs to be upgraded.
image
21/36 BPL Create a new, or
renovate or upgrade an existing public library
Funds in the amount of $3.0M are requested for the design and construction of roof and restoration of skylights ($1.0M) and exterior renovations ($2.0M) for the Park Slope branch library. The Park Slope library was recently reopened after an extensive interior renovation. This heavily-utilized branch and beloved community institution is one of the three landmarked Carnegie branches in the BPL system. A total exterior renovation would include brick work, refurbished wrought-iron fencing, stonework/repair of concrete entrance stairs, improved signage, landscaping, and sidewalk repair work.
image
22/36 DOT Reconstruct streets Sufficient funds are requested to remediate the
problems associated with the Brooklyn-Queens Expressway Trench running through our district parallel to Hicks Street. The BQE Trench inhibits local access and mobility between the Columbia Waterfront, Carroll Gardens and Cobble Hill neighborhoods. The concentration of traffic flowing through the trench creates vibrations, noise, odors and other air emissions that impact the residential communities adjacent to the trench. The trench provides opportunities to create new open space and expand resiliency measures (photovoltaics, storm water capture/diversion, etc.). Building on the momentum of a prior study's findings, remedies and opportunities must now be considered, funded and constructed.
image
23/36 HPD Provide more
housing for special needs households, such as the formerly homeless
Sufficient funds are requested for the planning, site selection/acquisition, development and construction of affordable senior housing in the Carroll Gardens section of our district.
image
24/36
DOT
Other
Sufficient funds are requested for the
transportation
construction of traffic safety median islands in
infrastructure
the Furman-Atlantic-Columbia transition area,
requests
the approach to Brooklyn Bridge Park's Pier 6
public park, and area growing in popularity and
increasingly traveled by pedestrians and
recreation users. Prior to the opening of Pier 6,
this area was generally unused by pedestrians
and was almost exclusively a southbound route
used by commuters seeking to avoid the
Brooklyn-Queens Expressway. Now, with the
opening of Pier 6 and the two-way conversion of
Furman Street, vehicular and pedestrian traffic
patterns have completely altered the use and
complexion of this bustling area. Immediate in-
house improvements have done a lot to improve
safety, at the cost of aesthetics.
25/36
DOT
Other
Sufficient funds are requested for the full
transportation
installation of all terracotta street name and
infrastructure
historic district maps/narrative signage in the
requests
Carroll Gardens, Cobble Hill and Park Slope
Historic Districts. New signage is especially
needed in Park Slope with the approved
expansion of the Park Slope Historic District in
2012.
26/36
NYCTA
Other transit
Sufficient funds are requested for the
infrastructure
installation of cellular/Wi-Fi service in subways
requests
systems as a way of improving public safety by
increasing channels of communication between
riders and emergency service providers in the
event that emergency assistance is needed.
27/36
DCAS
Renovate, upgrade
Sufficient funds are requested for the design
or provide new
and construction of a window replacement
community board
project for 250 Baltic Street in the Cobble Hill
facilities and
Historic District. This 1936 building still has the
equipment
original single-paned and uninsulated windows
making them highly inefficient energy-wasting
devices which negatively contribute to the
building tenants' comfort and safety. Modern,
energy- efficient windows appropriately
designed to area's historic district would go a
long way toward reducing heating and cooling
costs, improving safety, and creating a vastly
improved work environment for the State, City
and non- profit entities that occupy the space in
this City- owned building. While the City-State
have talked about changing ownership status of
this building for more than a decade, it will
crumble
facilities and equipment requests (Capital)
of radar speed signs to provide advisories to motorists in areas where speeding is suspected or confirmed. Radar Speed Signs can provide a constant monitoring presence to help raise awareness and act as a potential deterrent.
Compliance with the City's new 25MPH speed limit relies on an enforcement presence which, at best, can be challenging given limitations of manpower and competing deployment priorities; to some degree these signs can help augment these limitations.
image
29/36 DOT Other transportation infrastructure requests
Sufficient funds are requested to undertake a replacement of the existing standard-issue cobra head street lights with appropriate historic replica street lights in the neighborhoods of Cobble Hill and Carroll Gardens. Currently, only Atlantic Avenue, Clinton Street and Smith Street in these neighborhoods have such amenities. The balance of the neighborhood's street lights should be replaced to enhance and restore the historic integrity of these landmark districts and historically- sensitive areas.
image
30/36 DOT Repair or construct
new curbs or pedestrian ramps
In addition to the regular cement sidewalk replacement activity, we request that the department broaden its scope to include the option of restoring by contract those sidewalks which include special treatments, notably bluestone material. Not only is bluestone a more durable material with significantly longer life expectancy, it also serves to enhance the historic integrity and value of the community. Many property owners are willing to pay the extra cost to have this option, especially given the City's ability to leverage lower cost through bulk contracting.
image
facilities and equipment requests (Capital)
and deployment of Variable Message Boards (VMBs), at least one per precinct, to be used to advise the public of upcoming street closures, events, alerts and other vital information that would enhance public safety and preparedness. The strategic placement of VMBs can provide important directions, reduce traffic congestion, and otherwise assist NYPD in messaging information to the public. Precinct Commanders should have the flexibility to deploy VMBs as needed and in response to ongoing changing conditions within the precinct.
image
32/36 EDC Make infrastructure
investments that will support growth in local business districts
Sufficient funds are requested for the planning and construction of a cross harbor freight tunnel to link New York and New Jersey by rail to 1) provide for the efficient movement of bulk goods through the region, 2) reduce the amount of truck traffic with its corresponding impacts on traffic volumes, air quality, public safety, etc., and 3) expand opportunities for economic growth in the region. Transportation is one of the most significant obstacles to growth in the region, as our bridges, tunnels and highways experience on a daily basis. Without taking advantage of the area's features - its waterfront and untapped rail potential - further economic growth in the region is threatened. Replacing truck use by rail and barge options should be our top priority. (REQUEST IS FOR PANYNJ!)
image
33/36 DOT Reconstruct streets Sufficient funds are requested for the
acquisition, mapping, design and construction of a new City street which would extend Conover Street northward from Pioneer Street to Hamilton Avenue in Red Hook. This new street will not only provide additional capacity to handle the new traffic volumes destined for the cruise ship terminal under construction at Pier 12, but will also provide an alternative for the relocation of the Van Brunt Street leg of the City's local Truck Route network in Red Hook. It will ensure that the local street grid is not only not negatively impacted by the cruise terminal traffic but that it will benefit from relieving Van Brunt Street of trucks and removing the existing conflict by directing trucks closer to the industrial section of the neighborhood.
image
34/36 DSNY Provide new or
upgrade existing sanitation garages or other sanitation infrastructure
Sufficient funds are requested for the relocation of BK2 District Sanitation Garage and Broom Garage into the Community Board 2 district to comply with coterminality requirements of the Charter. In the interim, we encourage the department to explore alternatives at the current garage location at 127 2nd Avenue including the reconstruction of the existing garage (addition of a story?) to fully accommodate all fleet vehicles and equipment off the street and sidewalk and under one roof.
image
35/36 DPR Provide a new or
expanded park or amenity (i.e. playground, outdoor athletic field)
Sufficient funds are requested for the design and construction of a new park--Columbia Waterfront Park--on the City-owned properties along the westside of Columbia Street between Kane and Degraw Streets. These properties are currently in the Department of Transportation's portfolio but they have agreed to release them for the development of a future park to be built there. Much work has already gone into conceptualizing a park use of the space which, with an adequate budget, can be easily adapted into designs and construction plans.
image
36/36 SCA Renovate other site
component
Funds in the amount of at least $150,000 are requested for the design and construction of a soundproofing project at the PS 39 cafeteria at 417 6th Avenue in Park Slope. The tiny cave-like basement cafeteria is the largest open space in the school. The low tin roof and cement walls do little to absorb the loud whir of giant freezers or the noise of the fans used to cool the space due to the lack of air conditioning and window space. When you add more than 350 students during lunchtime the sounds reverberate around the room. The noise drowns out any conversations happening at the tables. By adding wall & ceiling mounted sound panels, extraneous noise will be lessened to manageable levels.
image
CS Other Other capital budget request
DEP: Sufficient funds are requested for the area wide installation of green infrastructure including, but not limited to, bioswales, offline retention capacities, rain barrels, pervious surface treatments, and other best management practices, to aggressively prevent storm water from entering into the sewer system. Reduction of storm water entry into the system is necessary to reduce the amount of Combined Sewer Overflow events that occur, particularly within the Gowanus watershed area.
image
CS FDNY Other FDNY facilities and equipment requests (Capital)
Sufficient funds are requested to equip every firehouse with an emergency generator to ensure continuous electrical supply. Firehouses serve as cooling stations during heat emergencies and, in general, serve the public as a critical local public safety facility for emergency and medical services. Maintaining electrical supply is essential both from an operational standpoint and to maintain a high degree of public confidence in the department's ability to provide a safe haven during times of crisis. We lost service to one of our firehouses in Red Hook during Hurricane Sandy, and would suggest that this site become an immediate priority.
image
CS EDC Invest in capital projects to improve access to the waterfront
Sufficient funds are requested for the design and construction of a maritime cultural use at the Atlantic Basin, as we previously suggested, discussed and promised by EDC during and since the development of their Piers 6-12 study for the Brooklyn Waterfront. Many years have lapsed since the study, yet there is no cultural use in place despite the agency's commitments to the community. Funds are needed to provide suitable docking facilities, upland connections and necessary infrastructure (electrical, water, sewage, etc.) to support such a use.
image
projects to improve access to the waterfront
and construction of a maritime cultural use at the Atlantic Basin, as we previously suggested, discussed and promised by EDC during and since the development of their Piers 6-12 study for the Brooklyn Waterfront. Many years have lapsed since the study, yet there is no cultural use in place despite the agency's commitments to the community. Funds are needed to provide suitable docking facilities, upland connections and necessary infrastructure (electrical, water, sewage, etc.) to support such a use.
image
CS DOT Other transportation infrastructure requests
Sufficient funds are requested to fully fund project SEK20068 for preliminary design investigations, final design and ultimate repair of the 9th Street and Second Avenue corridors abutting the Gowanus Canal. Issues that need to be addressed include negative and insufficient curbs that have resulted in flooding and drainage problems, defective and missing sidewalks and episodic infrastructure failures on 2nd Ave. Frequent and substantial roadway ponding occurs along 9th Street--a mapped Coastal Evacuation Route--which, coupled with new and growing demands in pedestrian and vehicular traffic, requires that the street be a more reliable emergency traffic conveyor and able to withstand rainfall events without
image
CS DOT Other transportation infrastructure requests
Sufficient funds are requested to fully fund project SEK20068 for preliminary design investigations, final design and ultimate repair of the 9th Street and Second Avenue corridors abutting the Gowanus Canal. Issues that need to be addressed include negative and insufficient curbs that have resulted in flooding and drainage problems, defective and missing sidewalks and episodic infrastructure failures on 2nd Ave. Frequent and substantial roadway ponding occurs along 9th Street--a mapped Coastal Evacuation Route--which, coupled with new and growing demands in pedestrian and vehicular traffic, requires that the street be a more reliable emergency traffic conveyor and able to withstand rainfall events without
image
CS DPR Provide a new or expanded park or amenity (i.e. playground, outdoor athletic field)
Sufficient funds are requested to undertake a series of Capital improvements to Prospect Park including, but not limited to: Lakeside Project ($9 mil additional), Long Meadow ball fields ($1.2 mil), lighting at Grand Army Plaza and the arch at Grand Army Plaza, and a continuation of traffic improvements at the Grand Army Plaza circle.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/26
DOHMH
Other programs to
address public
health issues
requests
2/26
Other
Other expense
ACS: Sufficient funds are requested to maintain
budget request
current levels of day care services provided to
the district. ACS had previously suggested that
an incredibly disproportionate share of cuts be
applied to day care services in the Brooklyn CB6
district. 4 out of the 15 centers citywide slated
for closure were specifically targeted to the
district. Most of these slots are located in
facilities directly adjacent to public housing (Red
Hook and Gowanus Houses), whose residents
rely on these services to enable them to work
and/or attend school. Eliminating day care
services removes one of the most important
safety nets in the community. ACS had not
attempted to renegotiate day care center
leases, or otherwise lower their operating costs,
before deciding to eliminate the service
altogether.
3/26
DFTA
Create a new senior
Sufficient funding is requested to increase
center or other
baseline operating budget allocations in existing
facility for seniors
senior centers. At a minimum, additional
funding is sought to help keep pace with cost of
living increases which over time take more and
more resources away from the base operating
budgets from programming and salary monies.
Effectively, by not providing for regular, modest
increases the senior centers' budgets are being
decreased over time as basic costs only go up.
This need is especially pressing with an aging
population, as more and more "baby boomers"
will be placing increasing demands on these
facilities, which is anticipated to increase in the
near future.
4/26
SBS
Other expense
To combat high levels of unemployment,
workforce
particularly in our Gowanus and Red Hook
development
neighborhoods, coupled with significant Federal
requests
changes in the existing public assistance
programs, additional focus must be placed on
preparing persons for work and expanding work
opportunities. Given the far- reaching impact of
unemployment and its undesirable effects on
health, education and social welfare, it is
imperative that front-end investment in human
capital occur to ensure local economic utility.
5/26
NYCHA
Other housing
Sufficient funds are requested for NYCHA to
support requests
issue an RFP to identify and select an operator
for the Gowanus Houses Community Center
who would engage the community and
maintain the site as an active recreation,
education and cultural center.
6/26
NYPD
Other NYPD
Sufficient funds, personnel and equipment are
facilities and
needed to create a dedicated Quality of Life
equipment requests
Detail for the 78th Precinct to address the
(Expense)
ongoing issues related to the increases in night-
time activities-- especially at local bars and
restaurants--which have increased tensions
between our residential and business
communities. Despite having ample personnel
available for details related to large-scale
events at the Barclays Center, no such details
exist to regularly monitor the impacts of a
changing commercial environment as a result of
new trends in business land uses, especially in
the northern Park Slope area. The precinct mush
have sufficient resources available to ensure
that the quality of life for everyone in the
neighborhood is maintained and improved.
7/26
NYPD
Other NYPD
Sufficient funds are requested to provide for a
programs requests
substantial increase in dedicated Truck
Enforcement Program personnel to meet the
overwhelming demand in our community for
aggressive truck enforcement. Adherence to
Truck Routes is necessary to reduce conflicts
with, and impact on residential safety and
quality of life. To protect and preserve public
safety, effective enforcement is needed to
combat pervasive and dangerous violations.
8/26
DPR
Other park
Sufficient funds are requested to restore Parks
maintenance and
Maintenance personnel to provide for vital
safety requests
maintenance and report of Parks facilities. With
the added supervisory role Parks Maintenance
workers perform through the departmental use
of JTP and other volunteer workers, more staff
are needed to continue to fulfill the traditional
roles and tasks performed by Parks
Maintenance staff.
9/26
DOE
Other educational
Sufficient funds are requested to ensure that
programs requests
every school in the Brooklyn Community Board
6 community district has anti-bullying program
resources available to all of the students, staff
and parents.
10/26
OMB
Provide more
Funding in the amount of $450,000 is requested
community board
in order for Community Boards to fulfill their
staff
Charter mandated roles to plan and advocate
for neighborhood needs. An increase in funds
will be used to fund the hiring of a full-time
urban planner, to keep pace with cost of living
adjustments which have never been applied to
Community Boards, to upgrade complaint
systems software which was previously supplied
and supported by prior Administrations and to
expand District Office functionality with the
purchase of additional equipment and supplies.
Increases to budget due to collective bargaining
agreements and maintaining the budget at its
current level do not address this request; both
are effectively negative responses which should
trigger a separate letter explaining the agency's
position.
11/26
DSNY
Provide more
Sufficient funds are requested to restore the
frequent garbage or
frequency of litter basket service to a minimum
recycling pick-up for
of two collections per day, especially on
schools and
weekends, along busy commercial corridors
institutions
such as Van Brunt Street, Columbia Street, Court
Street, Smith Street, 5th Avenue, 7th Avenue,
Atlantic Avenue, and Flatbush Avenue.
Overflowing litter baskets create additional
work for the department in discretionary
cleaning, contributes to the clogging of catch
basins, and results in the unfair issuance of
summonses to victims of the strewn litter. Litter
on commercial strips negatively contributes to
the consumer's shopping experience, detracts
from the residents' quality of life, and forces the
businesses to shoulder the burden for the City
after the mess.
12/26 NYPD Other NYPD staff
resources requests
Sufficient funds are requested to recruit and restore police patrol strength to safeguard the impressive strides in public safety over the past decade. Historically, as crime decreases and budget pressures increase, police staff suffers which begins the downward spiral of public safety and increasing crime. Maintaining a strong police force is even more necessary in the aftermath of 9/11 to ensure public safety and restore a high degree of confidence in keeping and attracting residents, businesses and tourists to the City - all essential to the City's economy. Over the past few years we have seen a dramatic decrease in the size of the police patrol strength at the precinct level and this has the community most alarmed.
image
13/26 DSNY Other cleaning
requests
Sufficient funds are requested for the design, construction and servicing of a Containerized Garbage Collection System for the John Jay Educational Campus at 237 7th Avenue in Park Slope. Current practice involves placing excessive numbers of garbage bags in the street late afternoons, which are sometimes not collected until the next day, which attracts vermin and vectors, creates odors, and has a tendency to attract additional loose litter and debris. Containerized collection would resolve all of these problems and restore neighbor's quality of life.
image
14/26 DOT Other expense
traffic improvements requests
Sufficient funds are requested for restoration of full- time (non-seasonal) work gangs to respond to year- round routine maintenance calls for potholes and street depressions. There has been a noticeable decrease in productivity and increase in response times in this area attributable to significant loss of manpower.
There has also been a significant delay in pothole response times during the winter-spring transition which could be remedied by maintaining more year-round personnel to respond to complaints.
image
15/26
DOT
Other expense
Sufficient funds are requested for restoration of
traffic
full- time (non-seasonal) work gangs to respond
improvements
to year- round routine maintenance calls for
requests
potholes and street depressions. There has been
a noticeable decrease in productivity and
increase in response times in this area
attributable to significant loss of manpower.
There has also been a significant delay in
pothole response times during the winter-spring
transition which could be remedied by
maintaining more year-round personnel to
respond to complaints.
16/26
NYCHA
Other housing
Sufficient funds are requested for the expansion
support requests
of NYCHA Maintenance personnel staff, perhaps
through the creation of an in-house training
program that would take employable NYCHA
residents and train them in the skilled trades in
an apprenticeship program and workforce
development initiative. Upon successful
completion of the program, graduates could be
placed in maintenance and construction
positions in the private market through the
NYCHA- REES program.
17/26
NYPD
Other NYPD staff
Sufficient resources are requested to restore
resources requests
NYPD bicycle patrols. Bicycle patrols provide a
low-cost option for policing that combines the
best elements of vehicular access with flexible
patrol routes. With increased bicycling, and the
call for better enforcement of bicycling rules, it
would also provide a more convenient way for
police to engage other bicyclists in the proper
education and enforcement of the rules of the
road. Previous bicycle patrols involved the use
of vouchered and donated bicycles making this
a cost-effective program that should be
reinstituted.
18/26
DPR
Other park
Sufficient funds are requested to restore Parks
maintenance and
Recreation personnel to increase the inventory
safety requests
and range of recreation options available
particularly to our teenage youth population.
With fewer part-time job opportunities and
shrinking afterschool programs we are looking
to increase the number of constructive options
for this population to keep them engaged in
productive, supervised activities.
19/26
DPR
Other street trees
Sufficient funds are requested to hire additional
and forestry
Parks Forestry personnel to regularly address
services requests
pruning and stump removal to maintain the
health and safety of our communities. While the
city allocates sufficient money for the
continuous planting of new trees increasing the
City's inventory of street trees, particularly with
the aggressive Million Trees Initiative,
corresponding increases in the Parks Forestry
Division are a necessary accompaniment to
ensure that sufficient resources are available for
ongoing maintenance needs.
20/26
DOHMH
Other animal and
Sufficient funds are requested for the hire of
pest control
additional Health/Pest Control Inspectors for
requests
initial field evaluations and compliance
inspections. At least one inspector per
Community Board ought to be assigned to
eliminate bottlenecks in Pest Control servicing,
ensure that annual inspections of Health-
Licensed facilities can occur, improve agency's
productivity and reduce response times for
complaint investigation.
21/26
HRA
Other domestic
Additional funding is requested to expand the
violence services
spectrum of services that provide assistance to
requests
victims of domestic violence - from counseling
to protection to shelter - in order to ensure that
adequate resources exist to help this vulnerable
population in need. Outreach and promotional
materials are needed to reach the population,
provide them with convenient access to services
and help educate communities on the
importance of these services to remove any fear
and stigma that may be attached to these
facilities.
22/26
LPC
Expand staffing and
Sufficient funds are requested to provide for the
program related
hire of additional LPC inspection and
services
enforcement personnel to address complaint
investigations, improve upon agency response
times to requested inspections, and foster a
global atmosphere of increased compliance
with landmark regulations. Given the expansion
of the role of the agency through the
broadening of their enforcement powers to
include the issuance of civil penalties, an
accompanying increase of personnel is
necessary to carry out the agency's additional
enforcement mandates.
23/26 Other Other expense
budget request
EDC: Sufficient funds are requested for the acquisition, planning and construction of a district wide tourism center, perhaps located at the Red Hook Cruise Ship Terminal, to provide a focal point for the growing tourism industry in our district. Such features as our historic brownstone residential communities (Carroll Gardens, Cobble Hill and Park Slope), Columbia Street, Gowanus and Red Hook waterfront features, Prospect Park, and other local points- of-attraction, are growing in popularity as tourists are flocking more and more to our district. A tourism center that would highlight the cultural, shopping, restaurants and other features of the district will help ensure that marketing and promotion of the district's amenities were fully leveraged.
image
24/26 SBS Other business regulatory assistance requests
Sufficient funds are requested to hire additional Waterfront Enforcement Division personnel, currently 6 persons citywide, to ensure that adequate coverage of the City's 578 miles of waterfront will be preserved and protected.
Waterfront Enforcement Division personnel are responsible for enforcing the City's building code for waterfront properties, some of the most valuable and sensitive properties in the City.
This would be a good way to reverse the trend of neglect suffered by the City's lack of waterfront development policies over the past few decades, and signify a commitment to the renewed importance of the City's waterfront as an asset and resource to draw from.
image
25/26 Other Other expense
budget request
SBS: Sufficient funds are requested to support existing and enable additional groups to embark on feasibility studies and supportive planning activities to move toward the formation of additional Business Improvement Districts (BID) in appropriate commercial and industrial areas. BIDs are proven to be an asset for the City insofar as they provide needed administrative infrastructure designed to support local commerce at the neighborhood level.
Furthermore, the expansion of BIDs from the traditional commercial into the industrial sector will enable the City to better protect the fragile manufacturing sector, which often produces higher wage paying jobs, with specialty skills, and reduces the cost of goods in the City by making us less reliant on imports.
image
26/26 DPR New equipment for
maintenance (Expense)
Sufficient funds are requested to ensure the timely replacement of fleet vehicles used int he service of our public parks properties including collection vehicles, repair vehicles, enforcement patrol vehicles, pickup trucks, etc.

