## Civic Roam is a public knowledge graph of local civic data and documents about New York City.

[[Search]] the full text of the [NYC Charter]([[__NYC Charter__]]), [NYC Administrative Code]([[__NYC Administrative Code__]]), [Mayor's Management Report]([[__Mayor's Management Report - Fiscal Year 2020__]]), and [Community District Needs Statements]([[__Community District Needs Statement - Fiscal Year 2021__]]) all in one place.

[[Suggest]] a document or dataset to be added to Civic Roam.

[[Download]] all of the pages here for use in your [[Roam Research]], [[Obsidian]], or other [[Graph Database]].

Learn more about [[Advanced Search]].
Learn more [[__About__]] Civic Roam.
[[Contact]] Civic Roam.
