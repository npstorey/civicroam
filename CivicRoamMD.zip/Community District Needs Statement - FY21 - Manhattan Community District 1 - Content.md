- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 1 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1C-QsRGwwlW1grKJK7Yyn7egTGDyMD8pJ/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1C-QsRGwwlW1grKJK7Yyn7egTGDyMD8pJ/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
image
.
2021
11¥1:
Published by:
PLANNING
February 2020
,..''
Manhattan Community District
1
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 1
image
Address: 1 Centre Street North, Room 2202
Phone: (212) 669-7970
Email: man01@cb.nyc.gov
Website: www.nyc.gov/manhattancb1
Chair: Anthony Notaro, Jr. District Manager: Lucian Reynolds
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Lower Manhattan continues to be America's fourth largest business district, even after the terrorist attacks of September 11, 2001, the financial crisis of 2008 and Superstorm Sandy in October 2012. During this time, public and private investment of over $30 billion was made in our neighborhood. Our location at the hub of the nation’s largest mass-transit network – originally built to deliver workers to the center – now works also to provide working families with a location from which they can tap into all of our region’s opportunities for work, education, recreation and culture. Lower Manhattan remains a resilient place more people want to live, work and visit. We have a lot of work to do to assure that these powerful growth trends result in a district that is livable for all.
This document describes the needs of our district for more schools, more open spaces, efficient transportation, less crowded streets and thorough preparation for future disasters. Our needs are great but the opportunity is immense: we can show how New York City can be the 21st Century’s model city for livable, equitable and thriving urban life. Pedestrian and Streetscape Surveys In response to a pedestrian survey conducted by students at Pace University during 2014, 2015 and 2016, close to 2,000 residents, workers, tourists and students were asked to identify the most serious problems for each geographic sub-district in Community District 1 (CD1). The results varied by neighborhood, but the overall responses ranked overcrowded sidewalks and streets, unclean subway stations, too much noise and garbage on the streets and the lack of affordable housing as the most serious issues facing the district. Too much construction and homelessness ranked not far behind the lack of affordable housing. In summary, residents, workers, tourists and students all want more affordable housing, more parks and open spaces and improved mobility and pedestrian experience in CD1. They also want less construction and all of its attendant byproducts of garbage, pollution, poor air quality and noise. People do still love to live, work, and visit lower Manhattan because a significant number of respondents said: "It’s Nice Here!" Livability Index In July 2017 under direction of Community Board 1 Fund for the City of New York Community Planning Fellow Jahnavi Aluri completed a year-long study of livability in our district. The study identified the factors that affect the quality of life for residents in NYC neighborhoods, measured this quality of life on a scale and compared the quality of life across different NYC neighborhoods through the Livability Index to determine how Community District 1 compares to other NYC neighborhoods. Over 200 quality of life factors were analyzed in the categories of health care and human services; youth, education and child welfare; public safety; core infrastructure and city services; land use, housing and human development; transportation; and community facilities, parks and cultural. The purpose of the study was to quantify anecdotal evidence about quality of life, to better understand where CD1 performs well or poorly, and to develop actionable steps to improve quality of life issues. The Index showed that while CD1 scored generally well, it scored notably poorly in the area of Core Infrastructure and City Services, particularly due to low scores related to pollution and street conditions. Some notable factors that CD1 scored poorly on are: homelessness; quantity of public schools; air quality; noise pollution; community center capacity; street conditions; potholes; sanitation; residential stability (transient population).
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 1
image
The three most pressing issues facing this Community Board are:
Infrastructure resiliency
Resiliency The unprecedented Superstorm Sandy in 2012 brought surges of 14 feet and numerous, serious disruptions to residents and businesses in Lower Manhattan, including power outages and loss of steam (for heat and hot water), telephone, data services and transportation, including subways which experienced flooding of tunnels. Two people were trapped by rising water and drowned. Disruptions were particularly severe in the South Street Seaport; historic buildings suffered great damage and while many businesses have reopened, some businesses and non-profit institutions are still struggling and have not fully recovered. The neighborhood surrounding the South Street Seaport was especially devastated by water up to seven feet above street level. The Lower Manhattan Coastal Resiliency Project had begun with the design stage estimated to be complete in Spring 2018. However, it is not clear if there are enough capital funds for construction once the design stage is complete as the scope of the long-term protections may include massive landfill extensions to the East Side of the District with varying cost implications that are dependent on the development program that could take place atop of the new real estate. Shovels won't be put to ground for this project for years and the City has only just proposed short or medium-term measures although we passed the seventh year anniversary of Sandy. The risk for extreme weather events is only increasing and CD1 is still left largely unprotected.
Traffic
Traffic/Mobility The rapid growth of our district has been accompanied by many challenges. Our growth was never properly planned for despite billions of dollars invested in residential and commercial development through public and private funding. Much of our district is comprised of the original colonial-era street grid, designed for people and horse traffic, not the flood of cars, trucks and buses we see today. Combined with approximately 15 million tourists annually, hundreds of thousands of workers daily and over 65,000 permanent residents and growing, this makes mobility an inherent problem. Narrow, crowded sidewalks and giant residential towers have resulted in walls of garbage. We also have a major problem with placard parking, both legal and illegal, given that this neighborhood is the center of the City’s government and headquarters to many City agencies. Crowding in Lower Manhattan is compounded by the sheer number of double-decker tour buses, personal cars and commuter buses that fill our streets. This congestion leads to critical issues such as emergency vehicles being blocked in the streets, resulting in potentially deadly increases in response times. We are encouraged that $500,000 has been dedicated for a Lower Manhattan traffic/pedestrian study. The scope is currently being developed by NYC DOT and we only hope that it results in a study that is holistic enough to capture the complex issues.
Other
Rapidly growing population Since 9/11, our district's population has been increasing rapidly. The U.S. Census documented a 77% growth between 2000 and 2010 from 34,420 to 60,978. Since the last Decennial Census, our Board has been tracking the addition of new residential units to estimate increased population using a proven methodology. The rate at which new residential units are added to our district indicates that this alarming growth trend continues. Since 2010, at least 10,000 new residential units have been added or are planned for our district, and there has been a demographic shift from unrelated singles to couples, families and children. The child population demographic trends in CD1 point to the need for additional community infrastructure and amenities in our district to serve children. In March 2013, CB1 analyzed U.S. Census data of the demographic changes by neighborhood for children ages 0 - 19 in our district. Our findings show astonishing growth. Between 2000 and 2010, the 0 - 19 population increased by 246% in the Financial District, 67% in Tribeca, and 125% in Battery Park City. While there was no net change in the Seaport/Civic Center's child population, the 0 - 4 age group increased by 57%, and the 5 - 9 age group by 44%. District-wide, there has been particularly rapid growth within the 0 - 4 and 5 - 9 age groups throughout all neighborhoods, which is cascading into area middle and high schools. These demographic trends have grave implications for our district. There has been very little planning for infrastructure to coincide with this level of growth and this has resulted in middle and high school school overcrowding, congestion, shortages of local community services and an overtaxed infrastructure system.
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 1
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
There is a need for funding for a senior services referral center in Lower Manhattan. CB1 is especially concerned about the ability of seniors to remain and age in place in our district. Fixed incomes cannot keep pace with rapid inflation in housing costs, especially rent and property taxes, that rise as neighborhoods become more desirable. Furthermore, there are multiple large residential developments that would certainly qualify for distinction as Naturally Occurring Retirement Communities.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Gouverneur Health is the closest municipal hospital to CD1 and some of our residents receive medical treatment there. It is located in CD3, CD1's neighbor to the northeast. In addition, Gouverneur, along with the Bellevue Hospital Center in CD6, is one of the WTC Environmental Health Centers of Excellence, which were established to address physical and mental health issues resulting from September 11, 2001. These Centers are part of the WTC Health Program, which is administered by the National Institute for Occupational Safety and Health (NIOSH) which was established by the James Zadroga 9/11 Health and Compensation Act of 2010. The Zadroga Act was extended for 75 years by the U.S. Congress in December, 2016 and this year was extended indefinitely.
CB1 advocated for this renewal in many resolutions and testimonies, and it was strongly supported by Rep. Jerrold Nadler, who represents CD1, and other U.S. Representatives and elected officials. The renewal was a very important victory for the community. We are also very concerned about the loss of hospital beds in all Lower Manhattan community districts. There has been an increase in illnesses in CB1 related to 9/11 and the community must have sufficient care facilities. Several years ago we lost St. Vincent's Hospital in Greenwich Village in CB2, which created great concern about whether remaining bed are sufficient for growing populations. The merger of Beth Israel and Mount Sinai has led to plans to very greatly reduce the number of beds at Beth Israel's hospital in CD6.
Needs for Older NYs
There is a need to recognize Naturally Occurring Retirement Communities in Community District 1. Large complexes that began their story as Mitchell-Lama developments have large concentrations of seniors and targeted programs to meet them where they are will make a large difference in mental and physical health outcomes. CB1 is especially concerned about the ability of seniors to remain and age in place in our district. Fixed incomes cannot keep pace with rapid inflation in housing costs, especially rent and property taxes, that rise as neighborhoods become more desirable.
Needs for Homeless
CD1 has a long history of concern for homeless people in our community. We supported John Heuss House, a drop- in facility for homeless and hungry people that was operated by Trinity Church until it closed in 2010. We also have a close relationship with the NYC Rescue Mission, which now cares for women as well as men. In addition, for nearly a decade the Coalition for the Homeless has been headquartered at Nassau and John Streets. Assaults and murders in recent years have illustrated the need for additional services for homeless and mentally ill people rather than short-sighted cuts to funding in that area. The success of our efforts to reclaim the Lower Manhattan waterfront and other open spaces as community amenities requires that people are safe and secure when they visit.
In this regard, it is important that all levels of government maintain sufficient funding for agencies that provide outreach and services to homeless people. Thrive NYC must do more to directly engage with CB 1, residents of communities adjacent to hotspots for homelessness and most importantly, those who are in need of their services.
Needs for Low Income NYs
It is a priority of CB 1 to ensure that existing rent stabilized and affordable units in the district are preserved and that development of new affordable housing units continues. We must ensure that people who teach our children, patrol our streets, and fight our fires can afford to live in the neighborhoods they serve. We therefore urge the city to build more affordable housing downtown as well as do everything possible to preserve existing units.
Additionally, we voice our concern about building owners attempting to leave programs that require rents in their buildings to remain subsidized as well as the expiration of taxation incentives for stabilized apartments.
We urge the City to do everything possible to ensure that Lower Manhattan remains a diverse community that is affordable to people in a wide range of income levels and demographic groups. This issue is further complicated by the unique governance structure that oversees buildings within Battery Park City. There are a number of affordable units within the area under the Batter Park City Authority and we call upon HPD to work with the Authority to preserve existing affordable units there.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
5/38
DOHMH
Other programs to
Increase funding for mental health and
address public
outreach to the homeless population in CB 1
health issues
through THRIVE.
requests
10/38
DFTA
Enhance NORC
Develop program to help urban communities
programs and
who live in buildings or residential campuses
health services
apply for NORC-SSP designation with the State
of New York
12/38
DHS
Other request for
provide more personnel for coordinated
services for the
homeless encampment cleanups with NYPD,
homeless
DSNY, and sometimes DPR.
28/38
HHC
Other health care
Provide funding to Gouverneur Healthcare.
227 Madison
facilities requests
Street
29/38
DOHMH
Reduce rat
Increase resources to address the proliferation
populations
of rats and other vermin in Lower Manhattan.
30/38
DHS
Provide programs
Increase funding for mental health and
for homeless
outreach to the population of homeless
veterans
veterans in CB1.
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 1
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
A priority issue in our district in recent years has been the development of new school seats to serve our rapidly growing population of young people. We therefore welcomed the announcement in December 2015 by the School Construction Authority that it would build a new 476-seat K-5 school at 77 Greenwich Street. In addition, we need funds to duplicate the Millennium High School model in an additional high school, expand the New York Assembly Harbor School on Governors Island and expand the Lower Manhattan Community Middle School.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Construct sufficient number of school seats in CB1 in the next 5-year capital plan to meet the need resulting from the rapid growth in the population of our district in recent years. There is a need for more middle school seats as well as high school seats. The residents of CD 1 would be well served by a second high school that is based on the Millennium High School model.
Needs for Youth and Child Welfare
Youth and Child Welfare has never been brought to the board as a standing issue to be addressed. CB 1 will take the next year to explore community needs in the area.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/32
SCA
Provide a new or
Expand Millennium High School leasing and
75 Broad
expand an existing
building out a floor in the building at 75 Broad
Street
high school
Street or establish another high school with the
same model as Millennium High School.
30/32
SCA
Renovate interior
Renovate or replace the elevators serving school
building component
facilities at 75 Broad Street, 81 New Street, and
26 Broadway
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/38
DOE
Improve school
Create a program to improve safety at all school
safety
lobbies in high density commercial buildings.
31/38
DOE
Other educational
Expand Student Metrocard program to cover
programs requests
full daily and weekend usage to allow for travel
to school-related events, clubs and sports.
Funding should increase to allow Metrocards for
caregivers who bring children to said events.
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 1
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
In order to continue to thrive, our community must remain secure and retain the quality of life valued by its residents and workers. In recent years the crime rate in our district has remained at reasonably low levels, however we cannot take for granted that this will continue. In addition to preventing and responding to crimes against people and property, we rely on the NYPD as well as other enforcement agencies to control quality of life problems in our busy mixed-use district, which is also a major tourist destination. These issues include idling buses, illegal placard parking, double-parking, unsafe vehicle operation, homelessness and vendors. Dangerous intersections remain a primary concern for our district. Crossing guards are especially important near schools and CB1 has advocated along with our elected officials for guards to protect the schoolchildren who cross at such intersections. The NYPD has been responsive and has assured us that permanent guards will be placed there as soon as there is a pool of people that they can place in those positions.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
CB1 has numerous and significant needs in the area of public safety. The NYPD has developed a WTC Campus Security Plan to restrict and regulate traffic at the perimeters of the site. Although we are concerned about creating a fortress-like presence in our community, CB1 is working with the NYPD, local leaders and stakeholders to find the right balance between safety considerations and livability so that the area will be thriving and vibrant, commercially successful as well as secure. We also strongly recommend that to the greatest extent possible, where safety concerns allow, areas closed after September 11, 2001 be re-opened to the public. We have worked with Friends of City Hall Park to increase public access to restricted parts of City Hall Park. Comparable ways to safely reopen Park Row are necessary to relieve severe burdens placed on nearby residents and businesses by restrictions associated with 1 Police Plaza. We are encouraged that the City has allowed Park Row to be re-opened to pedestrians and cyclists, but to the extent possible, we are interested in having Park Row re-opened and re-integrated into street grid. In addition to crime against people and property, CD1 also has many significant quality of life problems. We rely on the NYPD as well as other agencies for enforcement to keep these problems under control. Our district is a destination for many double-decker as well as commuter and tour buses. These generate complaints about idling, blocking sidewalks and street crossings, and other disruptive activity. Enforcement in this area by the NYPD, NYC DOT, DEP and other relevant agencies such as the agency that issues their permits, the NYC Department of Consumer Affairs, must continue. Other quality of life problems that occur excessively in our district include the abuse of placard parking. CB1 is home to many government agency offices and facilities, and enforcement is needed to keep under control the chronic and acute problem with government-authorized vehicles occupying limited space for parking and taking up spaces needed by emergency service and commercial vehicles. We also need to address the homeless situation discussed elsewhere by providing adequate and appropriate services for this vulnerable population.
Needs for Emergency Services
Currently, the only impediments that CB 1 identifies as potentially hurting response times to 911 calls is non- standard jurisdictional boundaries and awkwardly stored street names in the various EMS databases. Lower Manhattan has a number of oddly abbreviated street names, which may be difficult for operators to identify if the are not familiar with a caller referring to them in a different form. Three such cases are South William Street, North End Avenue, and South End Avenue, which are commonly abbreviated as S William Street, N End Avenue and S End Avenue respectively. That South William Street and William Street are so close and the former is far more obscure than the latter is not an infrequent issue. South End and North End avenues are in Battery Park City, which is largely under the jurisdiction of the Battery Park City Authority (BPCA) have proven to be challenging for EMS operators to locate during calls.
Furthermore, emergencies within parks that are in the jurisdiction of the BPCA are not New York State parks, nor are they New York City parks. They are something else entirely and do not have an established way for those who call for emergency services to direct arrival to specific locations within those areas in the same way that Central Park has numbered light poles, as an example.
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
3/38
NYPD
Assign additional
Fund additional school crossing guards in
crossing guards
needed locations, especially near elementary
schools. It is also critical to increase the pay rate
for school crossing guards and to offer full-time
positions in addition to part-time.
6/38
NYPD
Other NYPD staff
Increase hourly rate for guards and provide full
resources requests
time positions
27/38
NYPD
Assign additional
Increase personnel of 1st Precinct for quality of
uniformed officers
life issues such as bus enforcement including
double-decker and tour buses, street vendors,
crime, traffic enforcement, noise related to
disruptive bars and clubs and enforcement of
traffic and parking regulations including placard
parking, illegal parking and blocking curb cuts
and bike lanes, black cars, limos, cyclists,
motorcycles and electric bicycles. The NCO
philosophy is widely seen as a very successful
attempt to address these issues and more NCOs
should be established for more numerous, and
smaller sectors within the 1st Precinct.
33/38
NYPD
Other NYPD staff
Allocate funds for increased surveillance and
resources requests
law enforcement in non-permitted street
encampments which are causing problems of
safety, sanitation and economic distress to
residents and retail merchants.
34/38
NYPD
Assign additional
Provide traffic personnel with traffic mitigation
traffic enforcement
training and mitigation measures along Canal
officers
Street at the following intersections: West
Street, Washington Street, Greenwich Street,
Hudson Street, Varick Street and Church Street
during evening rush hours, nights and weekends
and provide the same at the intersections of
West Street and Albany, Liberty, Murray and
Warren Streets, and at the intersections of
Hudson and Vestry Streets and Hudson and
Laight Streets.
35/38 FDNY Expand funding for
fire prevention and life safety initiatives
Develop improved ways to identify specific locations in parks that are solely under the jurisdiction of the Battery Park City Authority for improved Fire/EMS response.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 1
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Protective Infrastructure (sea walls, flood walls, etc.)
At a height of seven feet, CB1 experienced one of the highest inundation levels in Manhattan during Superstorm Sandy. Two people in our district drowned and we suffered extreme damage to residential and commercial property, tunnels, public transit, telecommunications and our electrical grid. CB1 has played an active and positive role in the public process of recovery, resiliency and sustainability since Superstorm Sandy. Lower Manhattan is in immediate need of resiliency and hardening measures. It has been five years since Sandy and we are concerned about both the short-term and long-term time frame. Lower Manhattan remains largely unprotected while we face an increasing potential for suffering extreme weather events and subsequent damage. New York City has a combined sewer and storm water system. During heavy rain and snow storms, combined sewers receive higher than normal flows. According to the NYC Department of Environmental Protection (DEP), treatment plants are unable to handle flows more than twice design capacity and when this occurs, a mix of excess storm water and untreated wastewater discharges directly into the City’s waterways at certain outfalls. This is called a combined sewer overflow (CSO). We are concerned about CSOs because of their effect on water quality and recreational uses.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
There is an ongoing need to need to mitigate the negative impact of dozens of major public and private construction projects in the approximately 1.5 square miles of CB1 so that during this rapid time of transformation people will want to continue to live, work and visit our community. Inspection of construction sites to monitor and regulate dust, noise and air pollution and safety is not only needed during the workweek but also after hours and on weekends as deliveries of supplies and removal of debris are shifted to off hours to avoid peak traffic congestion.
CB1 would like to see budget increases for investment in new technologies required to advance sewage treatment plants and wastewater management e.g. greenbelts and bio swales.
Helicopters, specifically those catering to tourists, cause innumerable quality of life issues for our district including environmental concerns such as noise and air pollution. In early 2016 the City established a concession agreement with the Downtown Heliport located at Pier 6, requiring an overall reduction in the number of tourist flights, an end to tourist flights on Sunday and air quality monitoring and mitigation. While helicopter traffic has lessened and conditions have improved, most notably in relation to the moratorium on Sunday flights, the helicopter traffic is still by no means unobtrusive. This has been a good first step towards addressing the quality of life impacts from helicopter tourism, but the City must be aggressive in continuing to amend the agreement with the goal of eliminating all helicopter tourism.
Ferries are moving to surpass helicopters in frequency of disruption and magnitude of impact. An explosion of additional ferry lines and active operational hours is driving serious quality of life impacts. The Port Authority of New York & New Jersey is contracting with private ferry operators to replace cross-Hudson heavy rail operation. The additional service taxes the existing operator’s ability to selectively dispatch only quieter, cleaner vessels to dense residential areas and the result is frequent visits by extremely loud and dirty older vessels. The presence of these vessels is not only an audible disturbance, residents surrounding the pier in Battery Park City report feeling vibrations from the engines of these boats in apartments on the upper floors of large buildings.
Needs for Sanitation Services
The increase in our district's residential population and associated commercial activity has significantly increased the amount of garbage on our streets. The 9/11 Memorial along with the Statue of Liberty, The Battery, African Burial Ground, Federal Hall and other tourist attractions also put pressure on sanitation It is important that the Sanitation Department be given the resources that it needs to ensure that the streets in our district are kept clean.
Resources should also be increased to address the proliferation of vermin in Lower Manhattan. Mounds of plastic trash bags often clutter narrow streets during both day and night and are unsightly and a health hazard as well as an impediment to pedestrians. The frequency of garbage pick-ups needs to be increased. The number of days when there are piles of refuse on the street is increased because there are separate days for pickup of recyclables and trash and residential and commercial waste. When new buildings are built or old buildings are converted, the design process should take into consideration where the residents' garbage will go and how it will be picked up. The landmarked street grid of the Financial District has narrow sidewalks and streets, making it difficult and unpleasant to navigate areas congested with piles of garbage and waste left out for recycling. CB1 has joined together with a group of community stakeholders to advocate for a managed street plan in Lower Manhattan to better handle a variety of issues pertaining to vehicular, pedestrian and cyclist mobility but also including sanitation. The first step to this plan is a comprehensive traffic, mobility and street study. $500,000 has been approved for this study and the scope is currently being developed by NYC DOT. Our priorities are to ensure that the scope is appropriate and assesses critical areas like sanitation. It is imperative to the continued growth and economic development of this community that the City use the mobility study to develop and recommend to the community a set of specific and implementable measures to address the congestion challenges, mainly including the trash piles. The Department of Sanitation must also explore alternatives to storing residential trash on the sidewalk. Many cities around the world have invested in capital projects to store trash both above and below curb lanes and not within the pedestrian rights-of-way. The rate of commercial to residential conversions in Lower Manhattan is not slowing and the amount of trash that will end up on the sidewalk will only increase over time.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation Location
32/32
DEP
Evaluate a public
Work with DDG to implement stormwater
location or property
retention practices such as bioswales in Barnett
for green
Newman Triangle
infrastructure, e.g.
rain gardens,
stormwater
greenstreets, green
playgrounds
CS
DEP
Evaluate a public
Provide or expand green infrastructure, e.g.
location or property
greenbelts, bio swales - CB 1 would like to see
for green
budget increases for investment in new
infrastructure, e.g.
technologies required to advance sewage
rain gardens,
treatment plants and wastewater management.
stormwater
greenstreets, green
playgrounds
CS
DEP
Inspect water main
Replace or upgrade water mains aging
on specific street
infrastructure in water delivery systems is a
segment and repair
serious problem that results in large losses due
or replace as
to leaks. There have been several water main
needed (Capital)
breaks in Tribeca in recent years, We are looking
forward to the completion of Water Tunnel No.
3 in 2020 so that Tunnel No. 1 and No. 2 can be
closed for inspection and repairs. Continued
infrastructure upgrades and repairs of CD 1
water pipes are necessary.
CS
DSNY
Provide new or
Install waste containment compartments in the
upgrade existing
public rights-of-way in areas where residential
sanitation garages
conversion buildings overwhelm the sidewalks.
or other sanitation
Such installations may be found in other large
infrastructure
cities like Barcelona, Seville, and The Hague.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
4/38
DSNY
Other enforcement
Add personnel and resources to increase
requests
frequency of garbage pick-ups for all shifts and
graffiti removal to match the residential
population explosion in the district, and increase
enforcement of regulations for commercial
waste.
7/38
DEP
Investigate air
Outdoor noise and air monitoring units should
quality complaints
be deployed to take 24 hour readings at or
at specific location
around ferry docks in the district.
8/38
DEP
Investigate air
Increase personnel for 24/7 air/noise/idling
quality complaints
inspections (enforcement teams) including for
at specific location
helicopters, trucks, buses and construction
equipment.
13/38
DSNY
Other cleaning
provide more personnel for coordinated
requests
homeless encampment cleanups with NYPD,
DHS, and sometimes DPR.
37/38
DSNY
Provide more
Funding to study and create a special Sanitation
frequent garbage or
district in Lower Manhattan, where the historic
recycling pick-up
and narrow Colonial street grid presents unique
challenges for DSNY pickups and leads to piles
of residential trash on the sidewalks during
peak pedestrian hours.
38/38
DSNY
Increase
Increase enforcement of regulations for
enforcement of
commercial and residential waste.
dirty sidewalk/dirty
area/failure to clean
area laws
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 1
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Community Board 1 is not adequately stocked with existing affordable housing, nor does it have many opportunities to generate new affordable units. Existing zoning for much of the financial district is already set to the maximum residential density as allowed by state law. The balance of the district is either within a historic district, special zoning district regulations, or is under the jurisdiction of the Battery Park City Authority. There are simply not enough emerging units for area residents who are being pushed out of their homes as buildings exit older affordability programs such as Mitchell-Lama or other tax-levied conveyances. CB 1 supports small business believes that it is important for merchant’s associations like the Tribeca Alliance Partnership to receive support from the city in resources and attention. Given the residential and office population density of our district, we are not well served by small commercial units that best serve local retail establishments. Regional retail is expanding within the district and without more opportunities for inexpensive retail, small businesses will continue to be pushed out.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Decades-long increases in the numbers of residents, office workers and tourists have significantly increased the density of our district. This has heightened concerns about infrastructure capacity, including overcrowded streets and sidewalks, resiliency, public school seats, public transportation capacity, open spaces, and much more. Our waterfront remains particularly vulnerable. Many recently completed large developments in the CB1 area as well as those underway will add to this pressure. CB1 has discussed various ways to handle these infrastructure issues, including studying the related mobility issues, creating zoning rules to deal with how new developments can help internalize some of the impacts, concepts of a capital “impact fund” to pay for needed critical infrastructure in the district, etc.
Needs for Housing
The rapid and continuing growth of the population of CD1 in recent years has created significant challenges. Since 9/11, our district's population has been increasing rapidly. The U.S. Census documented a 77% growth between 2000 and 2010 from 34,420 to 60,978. This makes us the fastest growing residential area in all of New York City. In comparison, the entire population of New York City increased only 2% during the same time period. Since the last Decennial Census, our Board has been tracking the addition of new residential units to estimate increased population using a proven methodology (see attached). The rate at which new residential units are added to our district indicates that this alarming growth trend continues. Since 2010, at least 10,000 new residential units have been added or are planned for our district, and there has been a demographic shift from unrelated singles to couples, families and children. CD1’s rapidly growing residential population and the ongoing addition of residential units to the district's housing stock create a unique set of housing challenges in Lower Manhattan.
After 9/11, incentives for the development of housing units in Lower Manhattan spurred a boom in residential conversions, and development remains strong today. However, community infrastructure falls woefully short in meeting the needs of this considerable residential growth. As a result, CB1's top priorities include more school seats, community centers and resources for seniors. As a district with many ongoing construction projects, CD1 has extensive sidewalk sheds, scaffolding, detours, and other construction-related impacts. Scaffolding is a particular blight on our district, as City laws make it is very easy for property owners to renew permits that enable them to keep it in place indefinitely, creating circulation and safety issues and hindering economic development by blighting blocks with conditions unfriendly to retail and commercial businesses.
CD1 also strongly supports the preservation of existing affordable housing units in the district and developing as many new affordable units as possible. This has traditionally been a community with a diversity of income levels and a strong middle class, and government at all levels should do everything it can to keep this important demographic diversity.
Needs for Economic Development
Lower Manhattan has long served as a unique tourist destination, as it is rich in iconic historical, cultural, and economic assets. We receive approximately 15 million tourists annually. An ongoing project of great importance to our Board and our District has been the redevelopment of the South Street Seaport. CB1 has served on the Seaport Working Group along with various elected officials, city agencies, the Howard Hughes Corporation and other stakeholders. Our priority is revitalizing this historic area while maintaining and protecting its historical significance. Small businesses, or "mom and pop" operations are very important to our District. Supporting and preserving them are of great importance to our Board.
We understand that the NYC Economic Development Corporation views tourist helicopters as an important revenue stream. However, these flights present critical quality of life challenges for our district and we have therefore joined our elected officials in a successful effort to significantly reduce flights at the Downtown Heliport at Pier 6 in the Financial District, especially weekend flights. We must ensure that impacts from the flights do not threaten the quality of life of the increased residential population.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
3/32
SBS
Other capital
Integration of Resiliency Measures on the West
commercial district
Side of Manhattan between Battery Park City
revitalization
and Canal
requests
4/32
EDC
Invest in capital
The City is scheduled to demolish the old New
projects to improve
Market Building in the upcoming months. There
access to the
is no plan on what to build there. This idea
waterfront
comes from the 2002 Downtown East River
Waterfront Concept Plan sponsored by CB 1 and
the Alliance for Downtown NY. Such uses could
include, but are not limited to a community
center with indoor and rooftop recreation space,
public uses, community amenities, and possibly
a restaurant, rental and repair facilities for
bicycles, boats and other recreational
equipment.
5/32
EDC
Make infrastructure
These historic mid-19th century buildings that
investments that
house the Melville Gallery and other SSSM
will support growth
facilities urgently need to be upgraded to allow
in local business
for safe and legal access, security and flood
districts
resiliency. The SSSM did get a $4.8 million grant
for this renovation from LMDC but that funding
is insufficient. The project needs an additional
$3 million for capital work and $300,000 for
design and engineering.
24/32
EDC
Make infrastructure
Funds for the demolition and reconstruction of
investments that
pier/pilings underneath New Market Building
will support growth
site.
in local business
districts
31/32
EDC
Make infrastructure
Provide funds to continue transformation of
investments that
Governors Island. As the Island completed its
will support growth
ambitious 40-acre park project last year, it is
in local business
now focusing on a new plan to create a 24/7
districts
community with even more public parks,
nonprofit tenants, restaurants, and 5 million
square feet of new commercial, office and
education space. Funds are also needed for the
Islands aging or absent infrastructure and for
the maintenance of historic buildings.
CS HPD Other affordable housing programs requests (capital)
Develop and maintain affordable housing including rent stabilized rentals units.
image
CS EDC Invest in capital projects to improve access to the waterfront
Complete construction of East River Waterfront Esplanade up to Brooklyn Bridge.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
15/38
DCP
Study land use and
Allocate funds for staff to determine impact of
zoning to better
contextual zoning district proposals and revise
match current use
current zoning regulations for CB1 to better
or future
reflect delivery of City services and
neighborhood
infrastructure investment to match growth of
needs
residents, workers, tourists and students.
24/38
DCP
Study land use and
DCP should review development rights transfer
zoning to better
zoning at the South Street Seaport Historic
match current use
District, including an update and search for
or future
alternative receiving sites outside of the historic
neighborhood
district.
needs
26/38
HPD
Other affordable
Establish a program with the aim of the
housing programs
preservation of affordable housing in Battery
requests (expense)
Park City.
32/38
DCP
Study land use and
Fund a study to create zoning requirements for
zoning to better
cold waste storage rooms in newly constructed
match current use
buildings as wells as enlargements and
or future
conversions.
neighborhood
needs
image
TRANSPORTATION
Manhattan Community Board 1
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
In Lower Manhattan, narrow streets, a large number of ongoing public and private construction projects, vehicular and pedestrian conflict and crowded public transportation present many challenges. Much work needs to be done to ensure that our streets are safe and accessible to all. We are in a period of transition following the implementation of the City's bike share program and the opening of the Fulton Transit Center and the WTC Transportation hub, but we still have many significant challenges and areas of interest such as the need to better regulate commercial cyclists, improve subway and ferry service, further restrict tourist helicopters, and implement a one-seat ride to the airport and build an extension to Lower Manhattan of the 2nd Avenue Subway line.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Community District 1 faces many issues in regards to traffic and transportation infrastructure and public transit services. CB1 has worked with the NYC Department of Transportation (NYCDOT) to enhance street crossings and improve pedestrian safety on select streets, but much work still needs to be done. We have many old cobblestone streets which require reconstruction. New developments also require substantial improvement of street conditions, as in the case of the 5 Beekman development and Theater Alley. The many reconstruction projects in the district that have been completed or remain underway have caused challenges for quality of life, but ultimately improve the infrastructure in meaningful ways.
Reconstruction projects were completed recently on Liberty Street. Work is planned for West Broadway, Broadway, Front Street, Vesey Street, and Greenwich Street. Broadway remains underway and work on Worth Street and Warren Street continues, with Vestry Street just recently started.
In addition, a major multi-year project on Route 9A has largely been completed. We are looking forward to planned DOT work to rationalize the movements of cyclists, pedestrians and cars at intersections along Route 9A. The issue of a left turn on Liberty Street off Route 9A must be addressed. A taxi stand on Route 9A has also been long- requested to make the space more efficient and increase safety. CB1 works closely to monitor these projects and troubleshoot problems that arise for residents and workers in the affected areas. Other important projects such as the West Thames Street Bridge, an important passage between Battery Park City and the Financial District, is underway as well. This bridge has been in design for well over a decade and remains a priority as many pedestrians, including seniors and children, need a way to safely cross the dangerous Route 9A highway. The temporary pedestrian bridge at Rector Street was built by NYSDOT after 9/11 and needs to be replaced by a permanent structure. We have worked with the Mayor's office and NYC Economic Development Corporation (NYC EDC) to provide input on the design of the bridge so that it meets the needs of our changing community. CD1 has many dangerous intersections.
We would like enhanced streetscape improvements to ensure safety at these intersections. We are especially concerned about crossings near schools, and have advocated vigorously for crossing guards to protect schoolchildren. With much help from our elected officials and thanks to the NYPD, NYC Traffic Enforcement Agents are assisting at many of these crossings on an interim basis until permanent crossing guards can be assigned. We have been encouraged by the openings of the Fulton Transit Center and the WTC Transportation Hub. which are important components of the transportation infrastructure in Lower Manhattan. However, subway and bus overcrowding and service and station maintenance and cleanliness remain critical issues. Cyclists, specifically commercial cyclists, sometimes disregard rules and pose a threat to themselves and vehicular and pedestrian traffic. Better enforcement is needed.
Needs for Transit Services
While Lower Manhattan has plans for transportation improvements, all efforts must be made to protect one of its most valuable assets – its dense transportation network. All efforts must be made to make subways, bus routes, tunnels/underpasses, the Brooklyn Bridge, ferries and docks resilient to extreme weather events. Billions of dollars of existing investment must be hardened.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/32
DOT
Improve traffic and
Install speed cameras in the most dangerous
pedestrian safety,
intersections that are close to schools
including traffic
calming (Capital)
6/32
DOT
Improve traffic and
Build out crosswalks that serve P.S./I.S. 89.
pedestrian safety,
including traffic
calming (Capital)
7/32
DOT
Repair or construct
Continue funding projects to make intersections
new curbs or
safe for all users using best available technology
pedestrian ramps
and techniques such as sidewalk ramps, smooth
crosswalks, auditory signals, etc.
8/32
DOT
Upgrade or create
Provide funding to supplement maintenance
new greenways
and upkeep at Hudson River Park.
9/32
DOT
Other
This area had long served as an open space for
transportation
basketball, skateboarding and other activities.
infrastructure
In an area very lacking in such facilities, this
requests
open space needs to be restored and reopened
as soon as possible.
12/32
DOT
Roadway
Reconstruct and restore Franklin Street between
Franklin
maintenance (i.e.
Hudson and Varick Streets, a cobblestone street
Street
pothole repair,
within CB 1's historic district.
Hudson
resurfacing, trench
Street Varick
restoration, etc.)
Street
13/32
DOT
Other
Additional funding of up to $1.5 million apart
transportation
from the $500,000 that was already allocated in
infrastructure
order to expand the scope of the study currently
requests
being framed by DOT for traffic and mobility
analysis in the Financial District, including east
of Broadway and south of Park Row, as well as
the WTC area, to address safety, sanitation and
crowding issues as noted previously by CB1 and
numerous other groups, including for example,
the "Make Way for Lower Manhattan" initiative.
14/32
DOT
Repair or provide
Replace non-historic streetlamps with Bishops
new street lights
Crook street lamps or best fitting contextual
alternative within CB 1s historic districts.
15/32
DOT
Roadway
Repair Theater Alley behind the Park Row block.
Theater Alley
maintenance (i.e.
Beekman
pothole repair,
Street Ann
resurfacing, trench
Street
restoration, etc.)
16/32
DOT
Roadway
Repair the currently cobbled roadbed of Moore
Moore Street
maintenance (i.e.
Street between Water and Pearl Streets.
Water Street
pothole repair,
Pearl Street
resurfacing, trench
restoration, etc.)
17/32
DOT
Rehabilitate bridges
Rehabilitate the Morris Street Pedestrian Bridge
over the Brooklyn Battery Tunnel.
18/32
DOT
Install streetscape
Reconstruct the sidewalk perimeter of Pace
improvements
Plaza to compliment the massive renovations of
the entrance and public areas that make up the
main entrance of Pace University.
19/32
DOT
Roadway
Reconstruct and restore Vestry Street between
Vestry Street
maintenance (i.e.
West and Greenwich Streets, a cobblestone
West Street
pothole repair,
street within CB 1's historic district.
Greenwich
resurfacing, trench
Street
restoration, etc.)
20/32
DOT
Roadway
Reconstruct and restore Staple Street between
Staple St
maintenance (i.e.
Duane and Harrison Streets, a cobblestone
Duane St
pothole repair,
street within CB1's historic district.
Harrison St
resurfacing, trench
restoration, etc.)
21/32
DOT
Roadway
Reconstruct and restore N. Moore Street
North Moore
maintenance (i.e.
between Hudson Street and Varick Street within
Street
pothole repair,
CB1's historic district.
Hudson
resurfacing, trench
Street Varick
restoration, etc.)
Street
22/32
DOT
Roadway
Reconstruct and restore Greenwich Street
Greenwich
maintenance (i.e.
between Vestry Street and Hubert Street, a
Street Vestry
pothole repair,
cobblestone street within CB's historic district.
Street Hubert
resurfacing, trench
Street
restoration, etc.)
23/32
DOT
Roadway
Reconstruct and restore Duane Street between
Duane St
maintenance (i.e.
Greenwich and Hudson Streets, a cobblestone
Greenwich St
pothole repair,
street within CB 1's historic district.
Hudson St
resurfacing, trench
restoration, etc.)
25/32
DOT
Roadway
Reconstruct and restore Collister Alley between
Collister
maintenance (i.e.
Laight and Beach Streets, a cobblestone street
Street Laight
pothole repair,
within CB1's historic district.
Street Beach
resurfacing, trench
Street
restoration, etc.)
26/32
DOT
Other
Provide funds for improvements to areas under
transportation
and surrounding the Brooklyn Bridge, including
infrastructure
rebuilding active recreation space underneath
requests
the bridge as well as repairs to the staircase on
Frankfort Street.
27/32
DOT
Improve traffic and
Fund NYCs portion of the redesign and
South End
pedestrian safety,
reconstruction of South End Avenue in Battery
Avenue
including traffic
Park City.
Liberty Street
calming (Capital)
West Thames
Street
CS
DOT
Improve traffic and
Fund proposed intersection safety
Route 9A
pedestrian safety,
improvements that resulted from the study of
59th St
including traffic
Route 9A (West Street) traffic patterns from
Battery Place
calming (Capital)
59th Street to Battery Place, focusing on
pedestrian and vehicular interaction.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
9/38
DOT
Conduct traffic or
Conduct a Battery Park City North
River Terrace
parking studies
Neighborhood Traffic Study. This study should
Chambers
look at the impacts of increased commercial
Street Vesey
and placard parking (legitimate and
Street
illegitimate) of River Terrace from Chambers
Street to Vesey Street as well as North End
Avenue from the cul d sac to Chambers Street.
11/38
DOT
Improve traffic and
Continue expansion of placard technology,
pedestrian safety,
placard approval protocols, and rule
including traffic
enforcement in CB1 with the goal of improving
calming (Expense)
curb access, deliveries, and pedestrian
visibility/safety
14/38
DOT
Conduct traffic or parking studies
Provide funding to study the impacts of traffic impacts related to the demolition, construction, and operation of present and future facilities related to existing and planned locally operated incarceration facilities between Centre Street and Baxter Street. This study should take in the impacts of movement of detainees, visitation of detainees, and commuting practices of detention center staff. The study should also contemplate ways to minimize the burden of these impacts, especially in regards to illegal parking practices of city employees.
16/38
DOT
Address traffic congestion
Provide funding to study the Holland Tunnel area and continue to pursue actions to alleviate the continuous negative impacts.
17/38
DOT
Conduct traffic or parking studies
Fund and deliver Edgar Street Traffic Study beyond the Trinity School impact to also cover Greenwich South.
25/38
DOT
Improve traffic and pedestrian safety, including traffic calming (Expense)
Pilot education/enforcement activities to reduce bicycle riding on sidewalks and in dense crowds of pedestrians.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 1
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park access and park facility access
Quality parks are essential to the mental and physical well-being of community residents and strengthen resiliency to storms and extreme climate events. CD1 lacks sufficient active and recreational space to meet the needs of its rapidly growing population. In July 2011, CB1 documented this inadequacy in a report which found that there are approximately 3.5 million square feet of open and park space in our district. However, the analysis conducted for the report concluded that a large portion of this open space does not serve the community, is not accessible, and does not facilitate active recreation. Therefore it is extremely important that the parkland we have be of the highest quality possible and that as much new parkland and open space as possible be developed in CD1. The recent opening of the Hills on Governor's Island brought an important new amenity to the district. CB1 has long advocated for the development of public open space on Governor's Island as a resource for residents of CD1 and elsewhere.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
CB1 has some important needs associated with our existing parks and open spaces. The Battery is a vibrant part of the CD1 waterfront which provides a resilient edge as protection from future storms. Its integrity must be maintained and strengthened. CB1 looks forward to the fulfillment of inspiring plans presented in recent years. We were very pleased when the SeaGlass Carousel opened in August 2015 and we look forward to the fulfillment of other inspiring plans presented in recent years for The Battery including the Green and bikeway that will link the Hudson River Park Bikeway to the East River Esplanade, and the imaginative and educational Playspace for children designed by Frank Gehry. However some commercial activity detracts from the experience of visiting the park. We continue to receive complaints about vendors in The Battery aggressively selling tickets for bus and boat trips and blocking narrow pathways. Stepped up enforcement is needed.
East River Esplanade Open space is in short supply on the east side of Lower Manhattan. However, there is an extensive waterfront, which, when fully developed, will be a wonderful amenity for the community. We welcome efforts by NYC Economic Development Corporation (EDC) to fully realize the long anticipated East River Esplanade and Piers Project, which includes the Wall Street and Pier 15 area that are now open to the public. Additional funds will be needed to fully implement the comprehensive waterfront restoration project envisioned in the City's well- received East River Waterfront concept plan put forward in 2005. CB1 urges NYC EDC and the Department of City Planning to identify additional funds, complete a final design and move forward expeditiously to complete and maintain this project. Elizabeth H. Berger Plaza (formerly Edgar Plaza) We strongly support the redevelopment of Elizabeth H. Berger Plaza in accordance with the proposal developed by the Downtown Alliance. The 172 acres on Governors Island contain numerous well-maintained historic structures and playing fields, and we support efforts by the Trust for Governors Island to make as much of it as possible accessible to the public.
Peck Slip Park In 2006, a plan for a permanent park at Peck Slip was approved using funding through the Lower Manhattan Development Corporation. With major delays, CB1 and other community stakeholders began calling for an adjustment to the design to better accommodate the changing community. In September 2017, CB1 held a Town Hall style meeting with the Dept. of Parks and Recreation to hear from the community about what they would like to see on Peck Slip. Parks returned to CB1 with a reformulated plan based on this feedback. We look forward to the construction of Peck Slip Park in the current fiscal year.
Needs for Cultural Services
The east side of our community, which includes the South Street Seaport/Civic Center and Financial District, was radically transformed in the last decade into a thriving mixed-use community with a large residential population. Though our entire district has experienced tremendous growth in recent years, the population growth on the east
side has made it the fastest growing neighborhood in the city. However, it does not have a community center or other public recreational facility or a public library. The South Street Seaport Museum has been unable to open its galleries at 12-14 Fulton St. because of damage to the electrical systems from Sandy. Exhibits can't be mounted in rooms that are not correctly heated and air conditioned. The Museum needs to keep both its land-based premises and its ships to tell the story of how New York began and grew as a great port. They are an important cultural hub in a historic district that is unique in New York City. We also strongly support creation of the WTC Performing Arts Center (PAC) at the World Trade Center. Recently it was announced that Ronald Perelman had donated $75 million to the development of this important facility. Previously, the Lower Manhattan Development Corporation (LMDC) committed $100 million. This major new cultural center will provide needed arts programming in Lower Manhattan and also create construction and long term jobs and promote the economic revitalization of the neighborhood. The Manhattan Youth Downtown Community Center in Tribeca serves people of all ages and has developed programs in response to evolving community needs. In addition, the Asphalt Green community center and the community center at Stuyvesant High School, both in Battery Park City, serve our growing community. We need to ensure that all such facilities in CD1 receive needed funding to provide places where children and teenagers can play, learn, and grow; where our seniors can socialize and find needed resources and intellectual stimulation; and where all adults can pursue personal enrichment through fitness and continuing education. These existing facilities serve as models for what is needed east of Broadway as well.
Needs for Library Services
The population in Lower Manhattan is growing rapidly. Though the majority of the recent population growth has occurred east of Broadway, the Financial District and Seaport areas are still without a public library branch. A new library is needed to serve the many new residents in these areas. It is also important that our existing libraries in Battery Park City and on Murray Street receive sufficient resources to meet the needs of our growing population, and that funds are allocated to ensure that these libraries are open at times when residents and children need them most.
Needs for Community Boards
Community boards are charged with ensuring service delivery and protecting quality of life for those who live, work in, and visit our many districts. Furthermore, community boards often take the lead on amplifying important issues and shining a light on matters that might otherwise be missed. Over the years, community boards have grown in responsibilities while seeing their budgets remain stagnant. Community Board 1 is an incredibly important node for discussion that brings together federal, state and local governments to have important conversations about complex topics. Currently, CB 1s Environmental Protection Committee is operating like a local town hall to bring the New York State Department of Environmental Protection together with vulnerable populations to discuss brownfield remediation in the Seaport Area. The Quality of Life Committee provides a way for district residents and business owners to coordinate with utilities and the Department of Design & Construction to mitigate impacts, but also save the city money by improving the planning around these projects.
The common theme is that the CB 1 office has the responsibility to engage with the stakeholders, private industry, and government to make this possible. Community Boards are the only city agencies that are based on geographies as opposed to a scope of work, it makes sense to allow each board to specialize its staffing strategy to meet geographic needs. Currently, the budget barely permits boards to have enough staff to keep the office running and sustain the charter-mandated goals. An increase in our budget to allow boards to hire specialized staff would allow us to expand our reach and further improve coordination between community and government as well as coordination between levels of government.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation Location
10/32
DPR
Other park facilities
Replace the current pathway material at City
and access requests
Hall Park with the more durable Bluestone.
11/32
BPL
Create a new, or
Finish the remodeling of the New Amsterdam
renovate or upgrade
Branch of the NYPL as soon as possible so that it
an existing public
may reopen to the public.
library
28/32
DPR
Reconstruct or
Renovate the pathway of Bowling Green Park,
upgrade a park or
which currently pools with water after heavy
amenity (i.e.
rains.
playground, outdoor
athletic field)
29/32
NYPL
Create a new, or
Provide funding for a new library on the east
renovate or upgrade
side of CD1, where the residential population
an existing public
has been increasing rapidly with a particular
library
increase in families and children.
CS
DPR
Reconstruct or
Complete construction of Peck Slip Park.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Provide a new or
Reconstruct playground in The Battery.
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Rebuild comfort station and park office in The
upgrade a park or
Battery.
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Provide a new or
Provide additional funding for the expansion
expanded park or
and renovation of Elizabeth Berger Plaza to
amenity (i.e.
include Trinity Plaza.
playground, outdoor
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/38
OMB
Provide more
Increase Community Board budget to $400,000
community board
which would be the first increase in over 20
staff
years.
18/38
NYPL
Extend library hours
Restore funding to FY08 levels to provide
or expand and
increased hours, diverse programming, strong
enhance library
collections and sufficient staff to support these
programs
functions. The services provided through the
Library are needed by New Yorkers now more
than ever and with increased funding can be
open more hours, including evenings and
weekends, when working families need them.
21/38
DCLA
Support nonprofit
Provide ongoing, consistent funding for Seaport
12 Fulton St
cultural
Museum operations in support of programs,
organizations
ships and collections.
22/38
DPR
Provide better park
Provide funding to supplement maintenance
maintenance
and upkeep at Hudson River Park.
23/38
DPR
Enhance park safety
Increase full-time personnel for Parks
through more
Department Enforcement (PEP) Officers and
security staff (police
maintenance workers, including in the Battery.
or parks
enforcement)
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
19/38
LPC
Expand staffing and
Increase the budget of the enforcement division
program related
to hire more inspectors and analysts to better
services
levy violations for property owners that
disregard landmarks law protections.
20/38
LPC
Other staffing and
Study the Little Syria neighborhood of CD 1 for
program related
historic district protection.
requests
36/38
Other
Other expense
Develop improved ways to identify specific
budget request
locations in parks that are solely under the
jurisdiction of the Battery Park City Authority for
better targeting of service requests.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/32
DOT
Improve traffic and
Install speed cameras in the most dangerous
pedestrian safety,
intersections that are close to schools
including traffic
calming (Capital)
2/32
SCA
Provide a new or
Expand Millennium High School leasing and
75 Broad
expand an existing
building out a floor in the building at 75 Broad
Street
high school
Street or establish another high school with the
same model as Millennium High School.
3/32
SBS
Other capital
Integration of Resiliency Measures on the West
commercial district
Side of Manhattan between Battery Park City
revitalization
and Canal
requests
4/32
EDC
Invest in capital
The City is scheduled to demolish the old New
projects to improve
Market Building in the upcoming months. There
access to the
is no plan on what to build there. This idea
waterfront
comes from the 2002 Downtown East River
Waterfront Concept Plan sponsored by CB 1 and
the Alliance for Downtown NY. Such uses could
include, but are not limited to a community
center with indoor and rooftop recreation space,
public uses, community amenities, and possibly
a restaurant, rental and repair facilities for
bicycles, boats and other recreational
equipment.
5/32
EDC
Make infrastructure
These historic mid-19th century buildings that
investments that
house the Melville Gallery and other SSSM
will support growth
facilities urgently need to be upgraded to allow
in local business
for safe and legal access, security and flood
districts
resiliency. The SSSM did get a $4.8 million grant
for this renovation from LMDC but that funding
is insufficient. The project needs an additional
$3 million for capital work and $300,000 for
design and engineering.
6/32
DOT
Improve traffic and
Build out crosswalks that serve P.S./I.S. 89.
pedestrian safety,
including traffic
calming (Capital)
7/32
DOT
Repair or construct new curbs or pedestrian ramps
Continue funding projects to make intersections safe for all users using best available technology and techniques such as sidewalk ramps, smooth crosswalks, auditory signals, etc.
8/32
DOT
Upgrade or create
Provide funding to supplement maintenance
new greenways
and upkeep at Hudson River Park.
9/32
DOT
Other
This area had long served as an open space for
transportation
basketball, skateboarding and other activities.
infrastructure
In an area very lacking in such facilities, this
requests
open space needs to be restored and reopened
as soon as possible.
10/32
DPR
Other park facilities
Replace the current pathway material at City
and access requests
Hall Park with the more durable Bluestone.
11/32
BPL
Create a new, or
Finish the remodeling of the New Amsterdam
renovate or upgrade
Branch of the NYPL as soon as possible so that it
an existing public
may reopen to the public.
library
12/32
DOT
Roadway
Reconstruct and restore Franklin Street between
Franklin
maintenance (i.e.
Hudson and Varick Streets, a cobblestone street
Street
pothole repair,
within CB 1's historic district.
Hudson
resurfacing, trench
Street Varick
restoration, etc.)
Street
13/32
DOT
Other
Additional funding of up to $1.5 million apart
transportation
from the $500,000 that was already allocated in
infrastructure
order to expand the scope of the study currently
requests
being framed by DOT for traffic and mobility
analysis in the Financial District, including east
of Broadway and south of Park Row, as well as
the WTC area, to address safety, sanitation and
crowding issues as noted previously by CB1 and
numerous other groups, including for example,
the "Make Way for Lower Manhattan" initiative.
14/32
DOT
Repair or provide
Replace non-historic streetlamps with Bishops
new street lights
Crook street lamps or best fitting contextual
alternative within CB 1s historic districts.
15/32
DOT
Roadway
Repair Theater Alley behind the Park Row block.
Theater Alley
maintenance (i.e.
Beekman
pothole repair,
Street Ann
resurfacing, trench
Street
restoration, etc.)
16/32
DOT
Roadway
Repair the currently cobbled roadbed of Moore
Moore Street
maintenance (i.e.
Street between Water and Pearl Streets.
Water Street
pothole repair,
Pearl Street
resurfacing, trench
restoration, etc.)
17/32
DOT
Rehabilitate bridges
Rehabilitate the Morris Street Pedestrian Bridge
over the Brooklyn Battery Tunnel.
18/32
DOT
Install streetscape
Reconstruct the sidewalk perimeter of Pace
improvements
Plaza to compliment the massive renovations of
the entrance and public areas that make up the
main entrance of Pace University.
19/32
DOT
Roadway
Reconstruct and restore Vestry Street between
Vestry Street
maintenance (i.e.
West and Greenwich Streets, a cobblestone
West Street
pothole repair,
street within CB 1's historic district.
Greenwich
resurfacing, trench
Street
restoration, etc.)
20/32
DOT
Roadway
Reconstruct and restore Staple Street between
Staple St
maintenance (i.e.
Duane and Harrison Streets, a cobblestone
Duane St
pothole repair,
street within CB1's historic district.
Harrison St
resurfacing, trench
restoration, etc.)
21/32
DOT
Roadway
Reconstruct and restore N. Moore Street
North Moore
maintenance (i.e.
between Hudson Street and Varick Street within
Street
pothole repair,
CB1's historic district.
Hudson
resurfacing, trench
Street Varick
restoration, etc.)
Street
22/32
DOT
Roadway
Reconstruct and restore Greenwich Street
Greenwich
maintenance (i.e.
between Vestry Street and Hubert Street, a
Street Vestry
pothole repair,
cobblestone street within CB's historic district.
Street Hubert
resurfacing, trench
Street
restoration, etc.)
23/32
DOT
Roadway
Reconstruct and restore Duane Street between
Duane St
maintenance (i.e.
Greenwich and Hudson Streets, a cobblestone
Greenwich St
pothole repair,
street within CB 1's historic district.
Hudson St
resurfacing, trench
restoration, etc.)
24/32
EDC
Make infrastructure
Funds for the demolition and reconstruction of
investments that
pier/pilings underneath New Market Building
will support growth
site.
in local business
districts
25/32
DOT
Roadway
Reconstruct and restore Collister Alley between
Collister
maintenance (i.e.
Laight and Beach Streets, a cobblestone street
Street Laight
pothole repair,
within CB1's historic district.
Street Beach
resurfacing, trench
Street
restoration, etc.)
26/32
DOT
Other
Provide funds for improvements to areas under
transportation
and surrounding the Brooklyn Bridge, including
infrastructure
rebuilding active recreation space underneath
requests
the bridge as well as repairs to the staircase on
Frankfort Street.
27/32
DOT
Improve traffic and
Fund NYCs portion of the redesign and
South End
pedestrian safety,
reconstruction of South End Avenue in Battery
Avenue
including traffic
Park City.
Liberty Street
calming (Capital)
West Thames
Street
28/32
DPR
Reconstruct or
Renovate the pathway of Bowling Green Park,
upgrade a park or
which currently pools with water after heavy
amenity (i.e.
rains.
playground, outdoor
athletic field)
29/32
NYPL
Create a new, or
Provide funding for a new library on the east
renovate or upgrade
side of CD1, where the residential population
an existing public
has been increasing rapidly with a particular
library
increase in families and children.
30/32
SCA
Renovate interior
Renovate or replace the elevators serving school
building component
facilities at 75 Broad Street, 81 New Street, and
26 Broadway
31/32
EDC
Make infrastructure
Provide funds to continue transformation of
investments that
Governors Island. As the Island completed its
will support growth
ambitious 40-acre park project last year, it is
in local business
now focusing on a new plan to create a 24/7
districts
community with even more public parks,
nonprofit tenants, restaurants, and 5 million
square feet of new commercial, office and
education space. Funds are also needed for the
Islands aging or absent infrastructure and for
the maintenance of historic buildings.
32/32
DEP
Evaluate a public
Work with DDG to implement stormwater
location or property
retention practices such as bioswales in Barnett
for green
Newman Triangle
infrastructure, e.g.
rain gardens,
stormwater
greenstreets, green
playgrounds
CS
DOT
Improve traffic and
Fund proposed intersection safety
Route 9A
pedestrian safety,
improvements that resulted from the study of
59th St
including traffic
Route 9A (West Street) traffic patterns from
Battery Place
calming (Capital)
59th Street to Battery Place, focusing on
pedestrian and vehicular interaction.
CS
DPR
Reconstruct or
Complete construction of Peck Slip Park.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Provide a new or
Reconstruct playground in The Battery.
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
CS
HPD
Other affordable
Develop and maintain affordable housing
housing programs
including rent stabilized rentals units.
requests (capital)
CS
DPR
Reconstruct or
Rebuild comfort station and park office in The
upgrade a park or
Battery.
amenity (i.e.
playground, outdoor
athletic field)
CS
DEP
Evaluate a public
Provide or expand green infrastructure, e.g.
location or property
greenbelts, bio swales - CB 1 would like to see
for green
budget increases for investment in new
infrastructure, e.g.
technologies required to advance sewage
rain gardens,
treatment plants and wastewater management.
stormwater
greenstreets, green
playgrounds
CS
EDC
Invest in capital
Complete construction of East River Waterfront
projects to improve
Esplanade up to Brooklyn Bridge.
access to the
waterfront
CS
DPR
Provide a new or
Provide additional funding for the expansion
expanded park or
and renovation of Elizabeth Berger Plaza to
amenity (i.e.
include Trinity Plaza.
playground, outdoor
athletic field)
CS DEP Inspect water main on specific street segment and repair or replace as needed (Capital)
Replace or upgrade water mains aging infrastructure in water delivery systems is a serious problem that results in large losses due to leaks. There have been several water main breaks in Tribeca in recent years, We are looking forward to the completion of Water Tunnel No. 3 in 2020 so that Tunnel No. 1 and No. 2 can be closed for inspection and repairs. Continued infrastructure upgrades and repairs of CD 1 water pipes are necessary.
image
CS DSNY Provide new or upgrade existing sanitation garages or other sanitation infrastructure
Install waste containment compartments in the public rights-of-way in areas where residential conversion buildings overwhelm the sidewalks. Such installations may be found in other large cities like Barcelona, Seville, and The Hague.
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/38
OMB
Provide more
Increase Community Board budget to $400,000
community board
which would be the first increase in over 20
staff
years.
2/38
DOE
Improve school
Create a program to improve safety at all school
safety
lobbies in high density commercial buildings.
3/38
NYPD
Assign additional
Fund additional school crossing guards in
crossing guards
needed locations, especially near elementary
schools. It is also critical to increase the pay rate
for school crossing guards and to offer full-time
positions in addition to part-time.
4/38
DSNY
Other enforcement
Add personnel and resources to increase
requests
frequency of garbage pick-ups for all shifts and
graffiti removal to match the residential
population explosion in the district, and increase
enforcement of regulations for commercial
waste.
5/38
DOHMH
Other programs to
Increase funding for mental health and
address public
outreach to the homeless population in CB 1
health issues
through THRIVE.
requests
6/38
NYPD
Other NYPD staff
Increase hourly rate for guards and provide full
resources requests
time positions
7/38
DEP
Investigate air
Outdoor noise and air monitoring units should
quality complaints
be deployed to take 24 hour readings at or
at specific location
around ferry docks in the district.
8/38
DEP
Investigate air
Increase personnel for 24/7 air/noise/idling
quality complaints
inspections (enforcement teams) including for
at specific location
helicopters, trucks, buses and construction
equipment.
9/38
DOT
Conduct traffic or
Conduct a Battery Park City North
River Terrace
parking studies
Neighborhood Traffic Study. This study should
Chambers
look at the impacts of increased commercial
Street Vesey
and placard parking (legitimate and
Street
illegitimate) of River Terrace from Chambers
Street to Vesey Street as well as North End
Avenue from the cul d sac to Chambers Street.
10/38
DFTA
Enhance NORC programs and health services
Develop program to help urban communities who live in buildings or residential campuses apply for NORC-SSP designation with the State of New York
11/38
DOT
Improve traffic and
Continue expansion of placard technology,
pedestrian safety,
placard approval protocols, and rule
including traffic
enforcement in CB1 with the goal of improving
calming (Expense)
curb access, deliveries, and pedestrian
visibility/safety
12/38
DHS
Other request for
provide more personnel for coordinated
services for the
homeless encampment cleanups with NYPD,
homeless
DSNY, and sometimes DPR.
13/38
DSNY
Other cleaning
provide more personnel for coordinated
requests
homeless encampment cleanups with NYPD,
DHS, and sometimes DPR.
14/38
DOT
Conduct traffic or
Provide funding to study the impacts of traffic
parking studies
impacts related to the demolition, construction,
and operation of present and future facilities
related to existing and planned locally operated
incarceration facilities between Centre Street
and Baxter Street. This study should take in the
impacts of movement of detainees, visitation of
detainees, and commuting practices of
detention center staff. The study should also
contemplate ways to minimize the burden of
these impacts, especially in regards to illegal
parking practices of city employees.
15/38
DCP
Study land use and
Allocate funds for staff to determine impact of
zoning to better
contextual zoning district proposals and revise
match current use
current zoning regulations for CB1 to better
or future
reflect delivery of City services and
neighborhood
infrastructure investment to match growth of
needs
residents, workers, tourists and students.
16/38
DOT
Address traffic
Provide funding to study the Holland Tunnel
congestion
area and continue to pursue actions to alleviate
the continuous negative impacts.
17/38
DOT
Conduct traffic or
Fund and deliver Edgar Street Traffic Study
parking studies
beyond the Trinity School impact to also cover
Greenwich South.
18/38
NYPL
Extend library hours
Restore funding to FY08 levels to provide
or expand and
increased hours, diverse programming, strong
enhance library
collections and sufficient staff to support these
programs
functions. The services provided through the
Library are needed by New Yorkers now more
than ever and with increased funding can be
open more hours, including evenings and
weekends, when working families need them.
19/38
LPC
Expand staffing and
Increase the budget of the enforcement division
program related
to hire more inspectors and analysts to better
services
levy violations for property owners that
disregard landmarks law protections.
20/38
LPC
Other staffing and
Study the Little Syria neighborhood of CD 1 for
program related
historic district protection.
requests
21/38
DCLA
Support nonprofit
Provide ongoing, consistent funding for Seaport
12 Fulton St
cultural
Museum operations in support of programs,
organizations
ships and collections.
22/38
DPR
Provide better park
Provide funding to supplement maintenance
maintenance
and upkeep at Hudson River Park.
23/38
DPR
Enhance park safety
Increase full-time personnel for Parks
through more
Department Enforcement (PEP) Officers and
security staff (police
maintenance workers, including in the Battery.
or parks
enforcement)
24/38
DCP
Study land use and
DCP should review development rights transfer
zoning to better
zoning at the South Street Seaport Historic
match current use
District, including an update and search for
or future
alternative receiving sites outside of the historic
neighborhood
district.
needs
25/38
DOT
Improve traffic and
Pilot education/enforcement activities to reduce
pedestrian safety,
bicycle riding on sidewalks and in dense crowds
including traffic
of pedestrians.
calming (Expense)
26/38
HPD
Other affordable
Establish a program with the aim of the
housing programs
preservation of affordable housing in Battery
requests (expense)
Park City.
27/38
NYPD
Assign additional uniformed officers
Increase personnel of 1st Precinct for quality of life issues such as bus enforcement including double-decker and tour buses, street vendors, crime, traffic enforcement, noise related to disruptive bars and clubs and enforcement of traffic and parking regulations including placard parking, illegal parking and blocking curb cuts and bike lanes, black cars, limos, cyclists, motorcycles and electric bicycles. The NCO philosophy is widely seen as a very successful attempt to address these issues and more NCOs should be established for more numerous, and smaller sectors within the 1st Precinct.
28/38
HHC
Other health care facilities requests
Provide funding to Gouverneur Healthcare.
227 Madison Street
29/38
DOHMH
Reduce rat populations
Increase resources to address the proliferation of rats and other vermin in Lower Manhattan.
30/38
DHS
Provide programs for homeless veterans
Increase funding for mental health and outreach to the population of homeless veterans in CB1.
31/38
DOE
Other educational programs requests
Expand Student Metrocard program to cover full daily and weekend usage to allow for travel to school-related events, clubs and sports.
Funding should increase to allow Metrocards for caregivers who bring children to said events.
32/38
DCP
Study land use and zoning to better match current use or future neighborhood needs
Fund a study to create zoning requirements for cold waste storage rooms in newly constructed buildings as wells as enlargements and conversions.
33/38
NYPD
Other NYPD staff resources requests
Allocate funds for increased surveillance and law enforcement in non-permitted street encampments which are causing problems of safety, sanitation and economic distress to residents and retail merchants.
34/38
NYPD
Assign additional traffic enforcement officers
Provide traffic personnel with traffic mitigation training and mitigation measures along Canal Street at the following intersections: West Street, Washington Street, Greenwich Street, Hudson Street, Varick Street and Church Street during evening rush hours, nights and weekends and provide the same at the intersections of West Street and Albany, Liberty, Murray and Warren Streets, and at the intersections of Hudson and Vestry Streets and Hudson and Laight Streets.
35/38
FDNY
Expand funding for fire prevention and life safety initiatives
Develop improved ways to identify specific locations in parks that are solely under the jurisdiction of the Battery Park City Authority for improved Fire/EMS response.
36/38
Other
Other expense budget request
Develop improved ways to identify specific locations in parks that are solely under the jurisdiction of the Battery Park City Authority for better targeting of service requests.
37/38
DSNY
Provide more frequent garbage or recycling pick-up
Funding to study and create a special Sanitation district in Lower Manhattan, where the historic and narrow Colonial street grid presents unique challenges for DSNY pickups and leads to piles of residential trash on the sidewalks during peak pedestrian hours.
38/38
DSNY
Increase enforcement of dirty sidewalk/dirty area/failure to clean area laws
Increase enforcement of regulations for commercial and residential waste.

