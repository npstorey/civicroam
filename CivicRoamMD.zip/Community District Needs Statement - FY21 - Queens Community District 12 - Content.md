- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 12 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1gSl2ICLstFbhEwWtq_rfpYYAYnFLfFhp/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1gSl2ICLstFbhEwWtq_rfpYYAYnFLfFhp/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
12
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 12
image
Address: 90-28 161st Street Phone: (718) 658-3308
Email: qn12@cb.nyc.gov
Website: www.nyc.gov/queenscb12
Chair: Renee Hill District Manager: Yvonne Reddick
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 12, Queens, encompasses the area bounded by the Van Wyck Expressway (West), Hillside Avenue (South), North Conduit Avenue (South), and Francis Lewis Boulevard/Springfield Boulevard (East), encompassing the communities of Jamaica, South Jamaica, South Ozone Park, Hollis, St. Albans, Addisleigh Park, Rochdale Village, and North Springfield Gardens. It is the second largest Board in the Borough of Queens and takes up a large portion of the southeastern corner of the Borough. Officially, according to the 2010 census, we have a total population of 225,919 people. The number does not reflect nor acknowledge an under-count. The District has become a more culturally and ethnically diverse community. It is situated in the well-known flood basin of the world’s largest dam; John F. Kennedy Airport. The Airport, built on wetlands, which was our natural drainage area, has greatly contributed to a lack of adequate rainwater run-off in our community. We continue to suffer from serious infrastructure problems; our roads and sewers are inadequate to serve our community needs. A great deal of street repair has been done in Community Board 12, much more remains undone. At this time $2 Billion dollars have been allocated to Southeast Queens for flooding by the Mayor. We are faced with a serious ground water issue, in which hopefully there will be a study on ground water. Finally, through all of our struggles our communities will survive.
But, we cannot ignore the fact that basic municipal services are minimal. Extra help now will keep us stable and prevent the need for excessive amounts of rehabilitation and revitalization dollars in the future. The needs in each community are different. We at Community Board 12 will continue to fight for our fair share of city services that we are not receiving that must be provided to maintain the quality of life for all of the residents within the district.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 12
image
The three most pressing issues facing this Community Board are:
Schools
SCHOOLS - The district is faced with co-location of schools, with multiple schools in a single building.
Senior services
SENIOR SERVICES - Seniors comprise a large segment of our population, it is important that programs be developed to meet their needs. 1. Healthcare 2. Housing 3. Social Security 4. Healthy Food 5. Medicare - Medicaid
Street flooding
FLOODING - Flooding is a serious issue in CB12, it is due to lack of proper drainage causes flooding in streets and into homes, businesses and schools. An additional cause of flooding is that the groundwater table is too high.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 12
image
M ost Important Issue Related to Health Care and Human Services
State of health facilities
We continue to be confronted with a number of health problems; a high rate of breast cancer, prostate cancer, asthma, diabetes, HIV/AIDs and other chronic conditions. We are oversaturated with social service programs, however, we are not receiving quality healthcare. Primary healthcare facilities have opened but we need a full scale, quality hospital in the district.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Health care facilities and programming. We have a number of health care facilities with programs in the district, but not enough to meet the needs of a growing community. We need a hospital in the district to address many of the community resident’s needs; a primary health care facility.
Needs for Older NYs
There is a lack of facilities and programs for the older New Yorkers. Seniors comprise a large segment of our population, it is important that programs be developed to meet their needs: 1. Healthcare 2. Housing 3. Social Security 4. Healthy Food 5. Medicare - Medicaid
Needs for Homeless
We have more than our fair share of facilities of services to the homeless. We have (10) ten shelters and in 13 hotels in Community Board 12, Queens District, for more than our fair share.
Needs for Low Income NYs
We do not have enough services and programming for low-income and vulnerable new Yorkers.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
27/41 HHC Provide a new or
expanded health care facility
A full service hospital is needed in CB 12. The VA property should be considered for hospital, a Veteran Hospital also a Community Hospital.
Due to the closing of Mary Immaculate Hospital, a great strain has been put on Jamaica and Queens Hospital Center. A new Hospital can be erected on the property of the Veteran Hospital on Linden Blvd., St. Albans, NY
Expense Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 12
image
M ost Important Issue Related to Youth, Education and Child Welfare
Schools and educational facilities (Maintenance)
Education Partnering with Community Education Council Districts 27, 28 and 29 has been our priority for many years and we are proud to continue to stand with the staff, parents and students within these districts for education quality and equity. The years of Mayoral control by the previous administration caused our CDE Councils to take a considerable beating. It was extremely difficult to manage all of the issues brought by the Bloomberg administration, yet we persevered in dealing with issues such as: the effectiveness of the ATR (Absent Teacher Reserve) pool, the “Blue Book” – a document that did not provide trusted, definitive school space utilization information, “Testing to the Test”, the premature roll out of Common Core Standards, school closures, and persisting co-locations of multiple schools within one building. On numerous occasions, the Education Committee of Community Board 12 expressed our disapproval of the premise of co-location. Districts 27,28 an 29, were part of a detrimental co-location landscape that the Bloomberg administration was determined to carry out prior to his leaving office. Thus we were faced with multiple co-location proposals aimed at our elementary, middle and high schools. Under the guise of "under-utilization," educators were notified that their schools must make way for other schools deemed "high quality" by the DOE. The term was unproven in most case and highly offensive to those associated with the incumbent schools. Proposals for Southeast Queens included three (3) co-located schools with elementary and intermediate schools in existing co-location environments; a sixth (6th) co-located high school at Campus Magnet High School, and of most notable concern to us was a proposal to co-locate Success Charter Academy Elementary School (kindergarten through 4th grade) within August Martin High School, a co-located high school of three (3) schools - one of which, Voyages Preparatory High School, integrates adult-aged students up to the age of 21. Community Board 12 voiced opposition to this irresponsible proposal in our testimony to the NYC Department of Education and SUNY Charter Schools Institute. The proposal was not approved. In addition, Community Board 12 opposed the co-location of Q312 with PS 40; the co-location of Q332 with IS 72 and P.S. 993; and the co-location of Success Charter Academy Elementary School with IS 59 and P.S. 176. Most recently, we provided testimony to oppose the inclusion of New Visions Charter School within August Martin High School, joining the myriad of other schools co-located in the building. Although we were unsuccessful in that effort, we will continue to be adamant regarding our position on school co-location within our districts. Increasing class enrollment for preschool through high school-aged children persists as the population in our CDEC districts continues to rise. The need for the School Construction Authority to expand building plans in Community Board 12 continues as does the need for decreasing class size at every grade level. Additional after school programming and recreational community centers for middle and high school-aged children is essential to Community Education Council Districts 27, 28 and 29. We also request the implementation of effective school safety zones, traffic lights and speed bumps in the vicinity of every school and learning center in our CDEC districts.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
It is extremely important that quality educational programs be provided in our district, these include programs outside of the classroom like recreational programs, homework programs and other after school programs.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
28/41
SCA
Renovate or
Convert Electic heating to solar energy-$180k,
19503 Linden
upgrade an
Replace windows and security gates $95k,
Blvd
elementary school
replace kitchen floor $5k, purchase commercial
freezer $2.5k, Install new stalls in boys
bathroom $2k.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
14/18
DYCD
Provide, expand, or
Provide Sites for Summer Employment For
enhance after
Youngsters. They place youngsters at job sites
school programs for
for summer employment.
elementary school
students (grades K-
5)
15/18
DYCD
Provide, expand, or
Provide Additional Funding for additional youth
enhance the
programs and personnel in Community Board
Summer Youth
12Q. Would Like additional personnel for the
Employment
Programs.
Program
16/18
DYCD
Provide, expand, or
Provide Funding to Sustain and Enhance
enhance the
Programmatic Activities at PFLC.
Summer Youth
Employment
Program
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 12
image
M ost Important Issue Related to Public Safety and Emergency Services
Emergency and disaster preparedness
We have two Police Precincts in the District 103rd and 113th , we have request that resources be allocated for a
tow-truck to tow the 18 wheelers (Big Wheelers) using the street in the residential areas for a staging area overnight and weekend. Truck route signs are posted there is a lack of enforcement. Ongoing requests are made for more police presences in some of the residential area.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
We have two Police Precincts in the district 103rd and 113th, we have request that resources be allocated for a tow- truck to tow the (18) wheelers (Big Wheelers) using the streets in the residential areas for a staging area overnight and weekend. Truck route signs are posted there is a lack of enforcement. Ongoing requests are made for more police presences in some of the residential area.
Needs for Emergency Services
The Fire Education Program has worked really well in CB12 to reduce fatal fires in the community.
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
2/18 NYPD Assign additional
staff to address specific crimes (e.g. drug, gang-related, vice, etc.)
Increase Foot Patrol and Sector Cars for the Hollis Area. This request would improve the quality of life in this section of Hollis because there is excessive drug selling and quality of life issues that could be deterred if there was foot and sector car patrol.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 12
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water runoff and flooding
We have problems with some of our infrastructure because we have projects that have been on the books for a number of years and never moved forward because of funding. With the $2.2 Billion dollars that are allocated, a number of projects are moving forwards.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Flooding is a major problem in Community Board 12 due to a poor drainage system and a high level of ground water. Some homeowners are forced to have pumps installed in their basement but, that is not addressing the problem. Ongoing meeting have been held. A number of projects are schedule to move forward, these are all small projects that will not be addressing the major problem. Two point two hundred billion dollars have been allocated to southeast queens to address the flooding condition by the Mayor.
Needs for Sanitation Services
We are facing a major problem with Sanitation, dumping is an increasing problem. We must have more strict enforcement not less; there is a need to deal specifically with illegal dumping. We need additional manpower for street cleaning, dump-outs, and litter basket operations. Some of the dumping is in the residential area, where there are high number of vacancies due to foreclosure. In order to have cleaner streets in the residential areas, you must have alternate side of street parking in which we do not have in majority of the areas ; so the mechanical broom can clean the curb.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/41
DEP
Inspect sanitary
Reconstruct the storm sewer on 150th Street
150th St
sewer on specific
between Liberty Ave and Archer Ave
Liberty Ave
street segment and
Archer Ave
repair or replace as
needed (Capital)
5/41
DEP
Inspect water main
Reconstruct Brinkerhoff Ave (110th Ave) from
Brinkerhoff
on specific street
173rd St to 178th St. Reconstruct 176th St from
Ave 173rd St
segment and repair
Brinkerhoff Ave (110th Ave) to 109th Ave. The
178th St
or replace as
section of Brinkerhoff Ave. is in serious disrepair.
needed (Capital)
It has not been resurfaced or properly
maintained in the last 60 years. There is little to
no sidewalk between 176th and 178th streets.
The roadway is higher that the pedestrian
walkway causing water from the rain and
broken water mains to flow into the yards and
basements of homes. Between 177th and 178th
streets the roadway is so broken up, there is no
paving from the pedestrian walkway to more
than give feet into the roadway. Cars are parked
in the mud. We are submitting photographic
evidence. It is truly a deplorable condition. The
drainage issue must be resolved first by DEP
prior to DOT work.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
1/18
DSNY
Other cleaning
Institute Seven Day Basket Collection in
requests
Community District 12. Because of the
congestion of our district, especially in
downtown Jamaica by Archer Avenue and
Parsons Boulevard and also Sutphin Boulevard
and Archer Avenue where the subway station is
and the vans and vendors locate, our trash
baskets overflow in less than a day. We face a
problem of overflowing baskets which are
unsightly and create a health hazard. Seven day
collection would help lessen the problem.
image
6/18 DEP Clean catch basins Replace storm drainage on both sides of
Babylon Ave. The storm drains appear to be clogged, causing home owner flood and back-up in their homes.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 12
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
It’s a major issue in the district with all the proposed housing units and economic development in progress, we will have an increase in population and businesses, our local merchants need help to remain stable and profitable.
Community Board 12 Economic Development Committee is working with the Local Development Corp. and business groups on some of our commercial strips.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
We have an affective Land Use Committee in Community Board 12 that addresses all land use items that come before the board.
Needs for Housing
It’s a major issue in the district with all the proposed housing units and economic development being planned there will be increase in population and business groups on some of our communities. Our local merchants need help to remain stable and profitable. We are having a major problem in the district with abandoned houses; two to three years without being sealed up squatters in and out. we have a high number of vacancies due to foreclosures. Any abandoned house in a community has a great effect on the quality of life on all home owners in the Community. In Community Board 12 district, we need additional building inspectors to address working without a permit, illegal conversion, single room occupancy (SRO’s), and working on weekends. The problem continue to escalate, illegal use must not just be cited, the must not be allowed to continue. There continues to be a lack of enforcement in Community board 12, we need Consumer Affairs.
Needs for Economic Development
It’s a major issue in the district with all the proposed housing units and economic development in progress, we will have an increase in population and businesses, our local merchants need help to remain stable and profitable.
Community Board 12 Economic Development Committee is working with the Local Development Corp. and business groups on some of our commercial strips. Economic development is important for a vibrant and stable community. The new economic development plans that have been proposed in this district will hopefully address unemployment, which has been a huge issue in this district.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
32/41 HPD Provide more
housing for seniors
Fund curbs on west side of 188th, 192, 193, 195th St. 195th Place; Jamaica Ave and Hillside Ave (Jamaica to 91st Ave) Southside of 91st Ave to 187 St.
Expense Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
TRANSPORTATION
Queens Community Board 12
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
There is a serious problem with commercial traffic in residential area during weekends and overnight. "Big wheeler tractor trailers use residential street as staging area over the weekend leaving them unattended over the weekend. We have two transportation hubs in the district, Archer Avenue and Parsons Boulevard, Sutphin Boulevard and Archer Avenue.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
There is a serious problem with commercial traffic in residential areas during weekends and overnight. "Big-wheels" or 18-wheel tractor trailers use residential streets as staging areas over the weekend. Leaving them unattended over the weekend.
Needs for Transit Services
We have two transportation hubs in the district, Archer Avenue and Parsons Boulevard ,Sutphin Boulevard and Archer Avenue. At Archer Ave. and Parsons Boulevard you have the vans at the bus stops; Sutphin Boulevard and Archer Ave. you have the cars there picking up and in the bus stops. We have had numerous meetings, the problem continues to exist. We need enforcement in the areas everyday. We need stronger regulations. There is a need for new and additional buses on all of the routes except one. There should be a monitor on the same route. There is a problem with scheduling. In downtown Jamaica we have a lot of permit parking. A major traffic study is being done in the downtown area. We have four (4) subway lines (E,J,Z, and F). We also have the Long Island Railroad and the Air Train.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/41
DOT
Improve traffic and
Install sidewalks and curbs in various locations.
pedestrian safety,
sidewalks and curbs need to be installed at the
including traffic
following locations: 1: 155th St. bet. 140th Ave
calming (Capital)
& North Conduit Ave.; Corner of 156th St. and
134th ave.; 158th st. bet 140th ave and 137th
ave.; east side of 137th ave bet. Rockaway Blvd.
and 155th st. 5. south side of 155th st. bet.
Baisley Blvd. and 129th ave.; installation of
sidewalk and curbs at corner of 156th st,. bet.
134th ave and 137th ave and installation of
sidewalk and curbs on 129th ave bet. 157th st.
and Buy R. Brewer Blvd.
3/41
DOT
Reconstruct streets
Repair 116th Ave between 196th St. and 198th
116th Ave
St. 116th Av between 196th St and 198th St, is
196th St
in a serious state of disrepair. It needs
198th St
reconstruction of roadway with installation new
sewers, additional catch basins, sidewalks, curbs
street lighting and trees.
4/41
DOT
Reconstruct streets
Reconstruct 91st Ave at 197th Street. This dead
91st Ave
end street has been overlooked for 31 years.
197th St
The street is severely deteriorated. Its present
condition is a hazard to motorists and children
who play on this street
6/41
DOT
Reconstruct streets
Grading 197th Street, between 118th Ave and
119th Ave, is necessary because after any rain,
the accumulation of water prevents
homeowners from exiting and entering the
street. The water stays for days in front of the
homes. Mosquitoes and flies gather at the end
of the street, and a foul odor is also noted.
7/41
DOT
Repair or provide
Reconstruct Foch Blvd bet Marsden Street and
Foch Blvd
new street lights
Merrick Blvd., repair curbs, sidewalks, center
Marsden St
isle, sewers. Traffic light installation at 167th St..
Merrick Blvd
Roadways with steel reinforcements at corners
and increased street lighting. The recent
reconstruction of Foch Blvd. from Van Wyck
Blvd. was halted abruptly at Guy R. Brewer
Blvd., instead of continuing on to Merrick Blvd.
as the community had expected. At Merrick
Blvd. the restoration of Foch Blvd. is now being
undertaken to continue repairs eastward and
into SQPA Park through a Parks & Recreation
project.
8/41
DOT
Roadway
Resurfacing of streets. All of Liberty Ave
maintenance (i.e.
especially around 183 Street towards York
pothole repair,
College, also 193rd and 194th Street (Dunkirk-
resurfacing, trench
lots of work needed) also 118th and 119th Aves.
restoration, etc.)
Reconstruction of streets at 192nd Street near
the Montessori School off Linden Blvd., also
Springfield Blvd. around 112th St. water
accumulates whenever it rains between 118 and
119th Ave on 196th Street. Streets have holes
and are very bad for cars.
9/41
DOT
Repair or construct
Install curbs. Install curbs at the following
117th Ave
new curbs or
location 117th Ave from 195th Street to Linden
195th St
pedestrian ramps
Blvd, 190th Street from 118th Ave to 120 Ave
Linden Blvd
10/41
DOT
Improve traffic and
Resurface the street and reconstruct the
108th Ave
pedestrian safety,
sidewalk and curbs on 108th Ave and 164th
164 Place
including traffic
Place/James R. Moore Place. On 108th Avenue,
James R
calming (Capital)
new two family houses and multiple dwellings
Moore Place
have been constructed.
11/41
DOT
Roadway
Road bed repaving along street south of Liberty
103rd Rd
maintenance (i.e.
Ave to 107th Ave and 103rd Road between 171
171th St
pothole repair,
and 172 streets, 104 and 105 Aves between 172
172nd St
resurfacing, trench
and Merrick Blvd. The area has not experienced
restoration, etc.)
roadway improvement in more than 40 years
and having to handle illegal truck traffic and
development within the area has created much
need for this action.
12/41
DOT
Repair or provide
New street lighting at Parsons Blvd. and Hillside
Parsons Blvd
new street lights
Ave The lighting is very dim. Requesting brighter
Hillside Ave
lighting at Parsons Blvd.and Hillside Avenue.
13/41
DOT
Repair or provide
New street lighting at Parsons Blvd and Archer
Parsons Blvd
new street lights
Ave. New and brighter street lighting at Parsons
Archer Ave
Blvd. and Archer Ave.
14/41
DOT
Reconstruct streets
Reconstruct curbing. Reconstruct curbing on the
following street, from 180th Street to 173rd
Street, from 103rd Road to 104th Ave, from
105th Ave to 106th Ave
15/41
DOT
Reconstruct streets
Reconstruct curbs and sidewalks. Curbs and
sidewalk on the west side of Sayres Ave
between 179th Place ad 180th Street, north side
of 179th Place between Sayres Ae and 116th
Ave and the eastside of 110th Ave, between
179th Place and 180th Street. Pedestrians are
forced to walk in the street and bus passengers
have to stand in the street to get on the bus.
16/41
DOT
Reconstruct streets
Repair street off Baisley Blvd. Reconstruct
streets bounded by Baisley Blvd. south and
Baisley Blvd. on the north, North Conduit Ave on
the south. Rockaway Blvd. on the west and Guy
Brewer Blvd. on the east. Include in this
crosswalks leading to schools and to public
buses on Rockaway, Guy R. Brewer, and 134th
Ave.
17/41
DOT
Repair or provide
Archer Ave & 153 Street. New street lights to be
new street lights
installed at the corner of Archer Ave and 153
Street
18/41
DOT
Roadway
Reconstruct 199th Street Reconstruct 199th St.,
199th St
maintenance (i.e.
from 120th Ave to Linden Blvd, in St. Albans
120th Ave
pothole repair,
Linden Blvd
resurfacing, trench
restoration, etc.)
19/41
DOT
Reconstruct streets
Inspect and rebuild street in the St. Albans Civic
Improvement Association area. Repaving 118th
Ave and 197th St; curb and reconstruction from
Farmers Blvd. (111th Ave to Cross Island
Parkway) Hannibal Street in St. Albans. Also
inspect 190th Street and 118th Ave - this is a
long standing drainage problem.
20/41
DOT
Reconstruct streets
Reconstruct sidewalk with steel curve at
193rd St
southeast and southwest corner of 193rd and
Woodhull Ave
Woodhull Ave. This section of Hollis is heavily
populated with over 2000 apartment dwellers
plus homeowners. The 193rd and Woodhull Ave
area is the main entrance to the LRR Hollis
Station which is added contribution to the high
volume of traffic and paring
21/41
DOT
Reconstruct streets
Reconstruct 191 Street Reconstruct 191 St from
191 St Hillside
Hillside Ave to Jamaica Ave. This street has dips
Ave Jamaica
10 to 12 deep. Especially dangerous is the area
Ave
between 90th Ave and Jamaica Ave because
_P.S 35 is on the east side and Holy Trinity
Community School is on the west, cars lose
control, children fall, etc.
22/41
DOT
Reconstruct streets
Reconstruct Foch Bld. Between Merrick Blvd.
Foch Blvd
and 167th St. Foch Blvd, between Merrick Blvd.
Merrick Blvd
and 167 needs necessary reconstruction. There
167th St
is an urgent need for repairs to side walk and to
the center aisle. Street lighting must be
upgraded and a traffic light with turn signal
installed at 167th Street and Foch Blvd.
23/41
DOT
Other capital traffic
South Road between Guy R. Brewer Blvd. and
South Rd Guy
improvements
165th Street request widening of street. South
R. Brewer
requests
Road is very narrow, it is very difficult for
Blvd 165th St
vehicles to pass as t is a two way street. There is
sufficient land on the north side of South Road
to widen the street form Guy R. Brewer and
165th Street
24/41
DOT
Reconstruct streets
Fund curbs on west side of 188th, 192, 193,
195th Streets; 195th Place; Jamaica Ave and
Hillside Ave (Jamaica to 91st Ave); Southside of
91st Ave to 187th St.
25/41
DOT
Repair or provide
Install brighter lights at Hillside Ave and Sutphin
Hillside Ave
new street lights
Blvd.
Sutphin Blvd
26/41
DOT
Repair or provide
New street lighting at 183rd Street and Hillside
183rd St
new street lights
Ave
Hillside Ave
29/41
DOT
Reconstruct streets
Reconstruct 191 Street from Hillside /AVe to
Jamaica AVe. This street has dips 10 to 13 deep.
Especially dangerous is the area between 90th
Ave and Jamaica Ave because PS 35 is on the
east side and Holy Trinity Community School is
on the west, cars lose control, children fall, etc.
30/41
DOT
Reconstruct streets
Reconstruct Foch Blvd between Merrick Blvd
and 167th Street, needs necessary
reconstruction. There is an urgent need for
repairs to side walk and to the center aisle.
Sstreet lighting must be upgraded and a traffic
light with turn signal installed at 167 Street and
Foch Blvd.
31/41
DOT
Repair or provide
Turning signal on Farmers at Linden Blvd.
new street lights
33/41
DOT
Repair or construct
This area has fallen into disrepair. The sidewalk
new curbs or
is necessary for those wising to walk to Frmers
pedestrian ramps
Blvd. from the LIRR tunnel. There should be
spaces left for trees.
34/41
DOT
Other capital traffic
There is no turn off from Baisley to Linden Blvd.
improvements
All traffic has to go down Baisley to Farmers
requests
Blvd. There are two schools in this area (St.
Catherius and PS 36), plus there are many small
children that lived and play I this area, traffic is
constant and heavy. The children area at risk.
There have been a few accidents. This would
remove some of the traffic and insure a safer
crossin for children and seniors in the
community.
35/41
DOT
Reconstruct streets
Fund curb installation for many years our streets
have not had new curbs and the area at 109th
ave and 171 street is an abandoned eyesore.
New curbing will improve the quality of the area
36/41
DOT
Other capital traffic
There is a great deal of traffic approaching the
improvements
light at Linden & 195th Street cars park three
requests
abreast during drop off and pick up times.
Newly constructed curbs will increase
pedestrian safety.
37/41
DOT
Roadway
Request complete reconstruction of 204th
maintenance (i.e.
Street, between Jamaica Ave and LIRR street
pothole repair,
needs necessary flood relief, roadbed, curbs and
resurfacing, trench
sidewalks.
restoration, etc.)
38/41
DOT
Repair or construct
Reconstruct sidewalk on the corner of 192nd
new curbs or
Street and Jamaica Ave., northwest corner of PS
pedestrian ramps
35 elementary school. This would provide safety
for school children and deter sidewalk dumping
in the area
39/41
DOT
Roadway
Reconstruct Brinkerhoff Ave (110th Ave) from
maintenance (i.e.
173rd Street o 178th Street. Reconstruct 176th
pothole repair,
Street from Brinkerhoff Ave (110th Ave) to 109th
resurfacing, trench
Ave. The section of Brinkerhoff AVe is in serious
restoration, etc.)
disrepair. It has not been resurfaced of properly
maintained in the last 60 years. There is little to
no sidewalk between 176th and 178th streets.
The roadway is higher than the pedestrian
walkway causing water from the rain and
broken water mains to flow into the years and
basements of homes. Between 177th and 178th
Streets the roadway is so broken up, there is no
paving from the pedestrian walkway. Cars are
parked in the mud. We are submitting
photographic evidence. It is truly a deplorable
condition.
40/41
DOT
Other capital traffic
improvements requests
Construct etc. street in the South Jamaica area
bounded by South Road, Buy R. Brewer Blvd., Baisley and Sutphin Boulevards.
41/41
DOT
Other capital traffic
Construct curbs along 116th Rd. between 194th
improvements
St. and 195th St. in St. Albans. There is a great
requests
deal of traffic approaching the light at Linden
Blvd. and 195th St. Cars park three abreast
during drop off and pick up times. Newly
constructed curbs will increase pedestrian
safety.
CS
DOT
Repair or provide
Turning signal on Farmers at Linden Boulevard
Farmers Blvd
new street lights
Linden Blvd
CS
DOT
Reconstruct streets
This would provide safety for school children
and deter sidewalk dumping in the area
CS
DOT
Repair or construct
This area has fallen into disrepair. The sidewalk
new curbs or
is necessary for those wishing to walk to
pedestrian ramps
Farmers Blvd. from the LIRR tunnel. There
should be spaces left for trees.
CS
DOT
Improve traffic and
there is no turnoff from Basiley to Linden Blvd.
Basiley Blvd
pedestrian safety,
All traffic has to go down Baisley to Farmers
Linden Blvd
including traffic
Blvd. to get to Linden Blvd. There are two
calming (Capital)
schools in this area (St. Catherius and PS 36),
plus there are many small children that live an d
play in this area, traffic is constant and heavy.
The children are at risk. There have been a few
accidents. This would remove some of the traffic
and insure a safer crossing fir children and
seniors in the community.
CS
DOT
Other capital traffic
There is a great deal of traffic approaching the
Linden Blvd
improvements
light at Linden & 195th Street cars park three
195th Street
requests
abreast during drop off & pick-up times. Newly
constructed curbs will increase pedestrian
safety.
CS
DOT
Roadway
Request complete reconstruction of 204th
maintenance (i.e.
street, between Jamaica Avenue and LIRR street
pothole repair,
needs necessary flood relief, roadbed, curbs and
resurfacing, trench
sidewalks.
restoration, etc.)
CS
DOT
Repair or construct
Reconstruct sidewalk on the corner of 192nd
new curbs or
Street and Jamaica Ave, northwest corner new
pedestrian ramps
P.S. 35 elementary school. This would provide
safety for school children and deter sidewalk
dumpling in the area.
CS
DOT
Roadway
Reconstruct Brinkerhoff Avenue (110th Avenue)
Brinkerhoff
maintenance (i.e.
from 173rd Street to 178th Street. Reconstruct
Ave 173th St
pothole repair,
176th Street from Brinkerhoff Avenue (110th
178th St
resurfacing, trench
Avenue) to 109th Avenue. The section of
restoration, etc.)
Brinkerhoff Ave. is in serious disrepair. It has not
been resurfaced or properly maintained in the
last 60 years. There is little to no sidewalk
between 176th and 178th streets. The roadway
is higher that the pedestrian walkway causing
water from the rain and broken water mains to
flow into the yards and basements of homes.
Between 177th and 178th streets the roadway
is so broken up, there is no paving from the
pedestrian walkway to more than give feet into
the roadway. Cars are parked in the mud. We
are submitting photographic evidence. It is truly
a deplorable condition.
CS
DOT
Reconstruct streets
Reconstruct 204th Street between Jamaica Ave
and the LIRR. Request complete reconstruction
of 204th Street between Jamaica Ave and the
LIRR street needs necessary floor relief,
roadbed, curbs and sidewalks.
CS
DOT
Reconstruct streets
Pave and open Montauk Ave for two way traffic
from Linden Blvd. to 120 th Ave. A truning light
on Baisley and Montauk and a stop sign on
120th Ave and Montauk are needed. There is no
turnoff from Baisley to Linden Blvd. all traffic
has to go down Baisley to Farmers Blvd. to get
to Linden Blvd. There are two schools in this
area St. Catherius and PS 36; plus there are
many small children that live and play in this
area; traffic is constant and heavy. Children are
at risk. There have been a few accidents. This
would remove some of the traffic and ensure a
safer crossing for children and seniors in this
community
CS
DOT
Roadway
Improve Various Streets in Octagon
Farmers
maintenance (i.e.
Neighborhood Association Area. Improve streets
Boulevard
pothole repair,
bounded by Farmers Boulevard, Merrick
Merrick
resurfacing, trench
Boulevard and 120th Avenue.
Boulevard
restoration, etc.)
120th Avenue
CS
DOT
Reconstruct streets
Fund curb installation. for many years our
streets have not had new curbs and the area at
109th Ave and 171st Street is an abandoned
eyesore. New curbing will improve the quality of
the area.
CS
DOT
Reconstruct streets
for many years our streets have not had new
curbs and the area at 109th Ave. & 171 Street is an abandoned eyesore. New curbing will improve the quality of the area
109th Ave
171th Street
CS
DOT
Other capital traffic
Construct, etc. street in the South Jamaica area
improvements
bounded by South Road, Guy R Brewer, Baisley
requests
and Sutphin Boulevards
CS
DOT
Other capital traffic
Construct curbs along 116th Rd. between 194th
116th Rd
improvements
St. and 195th St. in St. Albans. There is a great
194th St
requests
deal of traffic approaching the light at Linden
195th St
Blvd. & 195th St. Cars park three abreast during
drop off and pick-up times. Newly constructed
curbs will increase pedestrian safety.
CS
DOT
Repair or construct
Construct curbing along 99th Ave between
new curbs or
Farmers Blvd. and 193rd Street (north side of
pedestrian ramps
99th Ave). This area has fallen into disrepair.
The sidewalk is necessary for those wishing to
walk to Farmers Blvd. from the LIRR tunnel.
There should be spaces left for trees.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
17/18
DOT
Other expense
The engineering unit is in dire need of 5
traffic
additional traffic control inspectors. The traffic
improvements
safety studies cannot be done with only one
requests
person on staff. A backlog of 3,000 studies in the
Borough is intolerable.
18/18
DOT
Improve traffic and
Replace storm drainage on both sides of
pedestrian safety,
Babylon Ave. The storm drains appear to be
including traffic
clogged, causing home owner flood and back-up
calming (Expense)
in their homes.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 12
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
We have been successful in getting majority of our parks reconstructed. Our major problem is the lack of enforcement that is needed in Baisley Park and Rufus King Park. We have a number of Cultural facilities in the district, Jamaica Arts and Learning, Black Spectrum Theatre, Jamaica Performing Arts Center, King Manor Museum, and Cultural Collaborative of Jamaica.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
We have been successful in getting majority of our parks reconstructed. Our major problem is the lack of enforcement that is needed in Baisley Park and Rufus King Park. We have a number of Cultural facilities in the district.
Needs for Cultural Services
We have been successful in getting majority of our parks reconstructed .our major problem is the lack if enforcement that is needed in Baisley Park and Rufus King Park. We have a number of Cultural facilities in the district, Jamaica Arts and Learning Black Spectrum Theater, Jamaica Performing Arts Center, Kung Manor Museum, and Cultural Collaborative of Jamaica.
Needs for Library Services
No comments
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
CS
DPR
Enhance park safety
Install Park security lighting. Lighting in Baisley
197th Street
through design
Park is insignificant; in fact many of the existing
118th Ave
interventions, e.g.
lights do not function. A recent survey in the
119th Ave
better lighting
Park resulted in security and lighting being
(Capital)
important needs.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/18
QL
Extend library hours
Fund Additional Library Personnel for South
or expand and
Jamaica Branch. The new South Jamaica Branch
enhance library
at Guy Brewer Blvd. and 108th Ave. needs
programs
additional personnel to handle the increased
number of users. This is a new library and
additional staffing will ensure its upkeep and
continued use.
4/18
DPR
Enhance park safety
Install Additional Lighting in King Park. King
through design
Park has summer concerts and other evening
interventions, e.g.
events. Adequate lighting needs to be provided
better lighting
for safety and security.
(Expense)
5/18
DPR
Enhance park safety
Hire Additional Staff for O'Connell Park. Deploy
through design
personnel for fall staffing at O'Connell Park to
interventions, e.g.
include recreational programs.
better lighting
(Expense)
7/18
DPR
Provide better park
Hire Additional Personnel for Roy Wilkins Park.
maintenance
Needed are a) Funds to employ maintenance
workers for the 54 acre Roy Wilkins Park,
particularly attendants for the newly
constructed comfort station. Workers are
required to work 7AM-10PM, 7 days/week
(total of 5460 hrs. at $10/hr. will be asstd. by
WEP workers). $54,600. b) Funds to employ 1
worker for 8 hrs/day, 7 days/week at $15/hr to
help in cleaning of the park and driving the
tractor. They will be assisted by WEP workers
($43,680). The Association must take on a
greater burden in maintaining the park at a
time when income is reduced. Increased use of
the park has brought on new pressures for the
care & protection of the park. Total=$98,280.
8/18
DPR
Other park
Purchase Equipment for Roy Wilkins Park.
maintenance and
Purchase: (A) Tractor with snow removal,
safety requests
garbage collection and grass cutting equipment:
$27,114; and a (B) carry all Turf II-daily trash
removal and security vehicle $6,253. The
Association purchased a tractor in 1984 which
has been exhausted. The care of 54 acres and
grass cutting, garbage collection and snow
removal are daily and seasonal tasks which
require the daily attention of staff. The
continuous movement throughout the park, by
motorized transport, also helps with security.
9/18
DPR
Reconstruct or
Hire a Tree Pruning Gang. Hire a tree pruning
upgrade a park or
gang for Community District  12 to clear
amenity (i.e.
backlog of trees in need of pruning.
playground, outdoor
athletic field)
10/18
DPR
Other requests for
Hire Six Park Rangers for King Park, Baisley
park, building, or
Park, O'Connell Park, Haggerty Park and Drew
access
Park. A Park Ranger presence in the Park will
improvements
ensure public safety, park cleanliness and
increased usage by the community.
11/18
DPR
Improve the
Increase the Staff of the Department's Forestry
quality/staffing of
Division. Our ongoing residential construction
existing programs
projects plans for individual trees on our streets.
offered in parks or
Unfortunately the existing street trees are not
recreational centers
pruned or maintained. Forestry has been cut
back drastically and our trees have suffered
since then. We need at least a doubling of the
forestry staff to do minimal pruning and tree
removal. The backlog is a disgrace.
12/18
DPR
Forestry services,
including street tree maintenance
Hire a stump removal Gang. Hire a stump
removal gang for community District 12. Community Board 12 has a backlog of stumps to be removed.
13/18
DPR
Other requests for
Fund King Manor museum in Jamaica. The King
150-03
park, building, or
Manor Association manages the recently
Jamaica Ave
access
restored home of Founding Father, Rufus king.
improvements
Mr. King's legacy includes important work as a
delegate to the Constitutional Convention, and
Contributions as a skilled diploma, statesman
and an outspoken opponent of Slavery. This
Historic site of national significance with
exceptional educational potential. Children,
adults and Families are participating in the
educational programs in steadily increasing
numbers. In the past 12 months there has been
a 200 percent increase in school programs and
the Manor has served four times as many
students and teachers as previously.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/41
DOT
Improve traffic and
Install sidewalks and curbs in various locations.
pedestrian safety,
sidewalks and curbs need to be installed at the
including traffic
following locations: 1: 155th St. bet. 140th Ave
calming (Capital)
& North Conduit Ave.; Corner of 156th St. and
134th ave.; 158th st. bet 140th ave and 137th
ave.; east side of 137th ave bet. Rockaway Blvd.
and 155th st. 5. south side of 155th st. bet.
Baisley Blvd. and 129th ave.; installation of
sidewalk and curbs at corner of 156th st,. bet.
134th ave and 137th ave and installation of
sidewalk and curbs on 129th ave bet. 157th st.
and Buy R. Brewer Blvd.
2/41
DEP
Inspect sanitary
Reconstruct the storm sewer on 150th Street
150th St
sewer on specific
between Liberty Ave and Archer Ave
Liberty Ave
street segment and
Archer Ave
repair or replace as
needed (Capital)
3/41
DOT
Reconstruct streets
Repair 116th Ave between 196th St. and 198th
116th Ave
St. 116th Av between 196th St and 198th St, is
196th St
in a serious state of disrepair. It needs
198th St
reconstruction of roadway with installation new
sewers, additional catch basins, sidewalks, curbs
street lighting and trees.
4/41
DOT
Reconstruct streets
Reconstruct 91st Ave at 197th Street. This dead
91st Ave
end street has been overlooked for 31 years.
197th St
The street is severely deteriorated. Its present
condition is a hazard to motorists and children
who play on this street
5/41
DEP
Inspect water main
Reconstruct Brinkerhoff Ave (110th Ave) from
Brinkerhoff
on specific street
173rd St to 178th St. Reconstruct 176th St from
Ave 173rd St
segment and repair
Brinkerhoff Ave (110th Ave) to 109th Ave. The
178th St
or replace as
section of Brinkerhoff Ave. is in serious disrepair.
needed (Capital)
It has not been resurfaced or properly
maintained in the last 60 years. There is little to
no sidewalk between 176th and 178th streets.
The roadway is higher that the pedestrian
walkway causing water from the rain and
broken water mains to flow into the yards and
basements of homes. Between 177th and 178th
streets the roadway is so broken up, there is no
paving from the pedestrian walkway to more
than give feet into the roadway. Cars are parked
in the mud. We are submitting photographic
evidence. It is truly a deplorable condition. The
drainage issue must be resolved first by DEP
prior to DOT work.
6/41
DOT
Reconstruct streets
Grading 197th Street, between 118th Ave and
119th Ave, is necessary because after any rain,
the accumulation of water prevents
homeowners from exiting and entering the
street. The water stays for days in front of the
homes. Mosquitoes and flies gather at the end
of the street, and a foul odor is also noted.
7/41
DOT
Repair or provide
Reconstruct Foch Blvd bet Marsden Street and
Foch Blvd
new street lights
Merrick Blvd., repair curbs, sidewalks, center
Marsden St
isle, sewers. Traffic light installation at 167th St..
Merrick Blvd
Roadways with steel reinforcements at corners
and increased street lighting. The recent
reconstruction of Foch Blvd. from Van Wyck
Blvd. was halted abruptly at Guy R. Brewer
Blvd., instead of continuing on to Merrick Blvd.
as the community had expected. At Merrick
Blvd. the restoration of Foch Blvd. is now being
undertaken to continue repairs eastward and
into SQPA Park through a Parks & Recreation
project.
8/41
DOT
Roadway
Resurfacing of streets. All of Liberty Ave
maintenance (i.e.
especially around 183 Street towards York
pothole repair,
College, also 193rd and 194th Street (Dunkirk-
resurfacing, trench
lots of work needed) also 118th and 119th Aves.
restoration, etc.)
Reconstruction of streets at 192nd Street near
the Montessori School off Linden Blvd., also
Springfield Blvd. around 112th St. water
accumulates whenever it rains between 118 and
119th Ave on 196th Street. Streets have holes
and are very bad for cars.
9/41
DOT
Repair or construct
new curbs or pedestrian ramps
Install curbs. Install curbs at the following
location 117th Ave from 195th Street to Linden Blvd, 190th Street from 118th Ave to 120 Ave
117th Ave
195th St Linden Blvd
10/41
DOT
Improve traffic and
Resurface the street and reconstruct the
108th Ave
pedestrian safety,
sidewalk and curbs on 108th Ave and 164th
164 Place
including traffic
Place/James R. Moore Place. On 108th Avenue,
James R
calming (Capital)
new two family houses and multiple dwellings
Moore Place
have been constructed.
11/41
DOT
Roadway
Road bed repaving along street south of Liberty
103rd Rd
maintenance (i.e.
Ave to 107th Ave and 103rd Road between 171
171th St
pothole repair,
and 172 streets, 104 and 105 Aves between 172
172nd St
resurfacing, trench
and Merrick Blvd. The area has not experienced
restoration, etc.)
roadway improvement in more than 40 years
and having to handle illegal truck traffic and
development within the area has created much
need for this action.
12/41
DOT
Repair or provide
New street lighting at Parsons Blvd. and Hillside
Parsons Blvd
new street lights
Ave The lighting is very dim. Requesting brighter
Hillside Ave
lighting at Parsons Blvd.and Hillside Avenue.
13/41
DOT
Repair or provide
New street lighting at Parsons Blvd and Archer
Parsons Blvd
new street lights
Ave. New and brighter street lighting at Parsons
Archer Ave
Blvd. and Archer Ave.
14/41
DOT
Reconstruct streets
Reconstruct curbing. Reconstruct curbing on the
following street, from 180th Street to 173rd
Street, from 103rd Road to 104th Ave, from
105th Ave to 106th Ave
15/41
DOT
Reconstruct streets
Reconstruct curbs and sidewalks. Curbs and
sidewalk on the west side of Sayres Ave
between 179th Place ad 180th Street, north side
of 179th Place between Sayres Ae and 116th
Ave and the eastside of 110th Ave, between
179th Place and 180th Street. Pedestrians are
forced to walk in the street and bus passengers
have to stand in the street to get on the bus.
16/41
DOT
Reconstruct streets
Repair street off Baisley Blvd. Reconstruct
streets bounded by Baisley Blvd. south and
Baisley Blvd. on the north, North Conduit Ave on
the south. Rockaway Blvd. on the west and Guy
Brewer Blvd. on the east. Include in this
crosswalks leading to schools and to public
buses on Rockaway, Guy R. Brewer, and 134th
Ave.
new street lights
installed at the corner of Archer Ave and 153
Street
18/41
DOT
Roadway
Reconstruct 199th Street Reconstruct 199th St.,
199th St
maintenance (i.e.
from 120th Ave to Linden Blvd, in St. Albans
120th Ave
pothole repair,
Linden Blvd
resurfacing, trench
restoration, etc.)
19/41
DOT
Reconstruct streets
Inspect and rebuild street in the St. Albans Civic
Improvement Association area. Repaving 118th
Ave and 197th St; curb and reconstruction from
Farmers Blvd. (111th Ave to Cross Island
Parkway) Hannibal Street in St. Albans. Also
inspect 190th Street and 118th Ave - this is a
long standing drainage problem.
20/41
DOT
Reconstruct streets
Reconstruct sidewalk with steel curve at
193rd St
southeast and southwest corner of 193rd and
Woodhull Ave
Woodhull Ave. This section of Hollis is heavily
populated with over 2000 apartment dwellers
plus homeowners. The 193rd and Woodhull Ave
area is the main entrance to the LRR Hollis
Station which is added contribution to the high
volume of traffic and paring
21/41
DOT
Reconstruct streets
Reconstruct 191 Street Reconstruct 191 St from
191 St Hillside
Hillside Ave to Jamaica Ave. This street has dips
Ave Jamaica
10 to 12 deep. Especially dangerous is the area
Ave
between 90th Ave and Jamaica Ave because
_P.S 35 is on the east side and Holy Trinity
Community School is on the west, cars lose
control, children fall, etc.
22/41
DOT
Reconstruct streets
Reconstruct Foch Bld. Between Merrick Blvd.
Foch Blvd
and 167th St. Foch Blvd, between Merrick Blvd.
Merrick Blvd
and 167 needs necessary reconstruction. There
167th St
is an urgent need for repairs to side walk and to
the center aisle. Street lighting must be
upgraded and a traffic light with turn signal
installed at 167th Street and Foch Blvd.
23/41
DOT
Other capital traffic
South Road between Guy R. Brewer Blvd. and
South Rd Guy
improvements
165th Street request widening of street. South
R. Brewer
requests
Road is very narrow, it is very difficult for
Blvd 165th St
vehicles to pass as t is a two way street. There is
sufficient land on the north side of South Road
to widen the street form Guy R. Brewer and
165th Street
195th Streets; 195th Place; Jamaica Ave and
Hillside Ave (Jamaica to 91st Ave); Southside of
91st Ave to 187th St.
25/41
DOT
Repair or provide
Install brighter lights at Hillside Ave and Sutphin
Hillside Ave
new street lights
Blvd.
Sutphin Blvd
26/41
DOT
Repair or provide
New street lighting at 183rd Street and Hillside
183rd St
new street lights
Ave
Hillside Ave
27/41
HHC
Provide a new or
A full service hospital is needed in CB 12. The VA
expanded health
property should be considered for hospital, a
care facility
Veteran Hospital also a Community Hospital.
Due to the closing of Mary Immaculate Hospital,
a great strain has been put on Jamaica and
Queens Hospital Center. A new Hospital can be
erected on the property of the Veteran Hospital
on Linden Blvd., St. Albans, NY
28/41
SCA
Renovate or
Convert Electic heating to solar energy-$180k,
19503 Linden
upgrade an
Replace windows and security gates $95k,
Blvd
elementary school
replace kitchen floor $5k, purchase commercial
freezer $2.5k, Install new stalls in boys
bathroom $2k.
29/41
DOT
Reconstruct streets
Reconstruct 191 Street from Hillside /AVe to
Jamaica AVe. This street has dips 10 to 13 deep.
Especially dangerous is the area between 90th
Ave and Jamaica Ave because PS 35 is on the
east side and Holy Trinity Community School is
on the west, cars lose control, children fall, etc.
30/41
DOT
Reconstruct streets
Reconstruct Foch Blvd between Merrick Blvd
and 167th Street, needs necessary
reconstruction. There is an urgent need for
repairs to side walk and to the center aisle.
Sstreet lighting must be upgraded and a traffic
light with turn signal installed at 167 Street and
Foch Blvd.
31/41
DOT
Repair or provide
Turning signal on Farmers at Linden Blvd.
new street lights
32/41
HPD
Provide more
Fund curbs on west side of 188th, 192, 193,
housing for seniors
195th St. 195th Place; Jamaica Ave and Hillside
Ave (Jamaica to 91st Ave) Southside of 91st Ave
to 187 St.
33/41
DOT
Repair or construct
new curbs or pedestrian ramps
This area has fallen into disrepair. The sidewalk
is necessary for those wising to walk to Frmers Blvd. from the LIRR tunnel. There should be spaces left for trees.
34/41
DOT
Other capital traffic
There is no turn off from Baisley to Linden Blvd.
improvements
All traffic has to go down Baisley to Farmers
requests
Blvd. There are two schools in this area (St.
Catherius and PS 36), plus there are many small
children that lived and play I this area, traffic is
constant and heavy. The children area at risk.
There have been a few accidents. This would
remove some of the traffic and insure a safer
crossin for children and seniors in the
community.
35/41
DOT
Reconstruct streets
Fund curb installation for many years our streets
have not had new curbs and the area at 109th
ave and 171 street is an abandoned eyesore.
New curbing will improve the quality of the area
36/41
DOT
Other capital traffic
There is a great deal of traffic approaching the
improvements
light at Linden & 195th Street cars park three
requests
abreast during drop off and pick up times.
Newly constructed curbs will increase
pedestrian safety.
37/41
DOT
Roadway
Request complete reconstruction of 204th
maintenance (i.e.
Street, between Jamaica Ave and LIRR street
pothole repair,
needs necessary flood relief, roadbed, curbs and
resurfacing, trench
sidewalks.
restoration, etc.)
38/41
DOT
Repair or construct
Reconstruct sidewalk on the corner of 192nd
new curbs or
Street and Jamaica Ave., northwest corner of PS
pedestrian ramps
35 elementary school. This would provide safety
for school children and deter sidewalk dumping
in the area
39/41
DOT
Roadway
maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Reconstruct Brinkerhoff Ave (110th Ave) from
173rd Street o 178th Street. Reconstruct 176th Street from Brinkerhoff Ave (110th Ave) to 109th Ave. The section of Brinkerhoff AVe is in serious disrepair. It has not been resurfaced of properly maintained in the last 60 years. There is little to no sidewalk between 176th and 178th streets.
The roadway is higher than the pedestrian walkway causing water from the rain and broken water mains to flow into the years and basements of homes. Between 177th and 178th Streets the roadway is so broken up, there is no paving from the pedestrian walkway. Cars are parked in the mud. We are submitting photographic evidence. It is truly a deplorable condition.
40/41
DOT
Other capital traffic improvements requests
Construct etc. street in the South Jamaica area bounded by South Road, Buy R. Brewer Blvd., Baisley and Sutphin Boulevards.
41/41
DOT
Other capital traffic improvements requests
Construct curbs along 116th Rd. between 194th St. and 195th St. in St. Albans. There is a great deal of traffic approaching the light at Linden Blvd. and 195th St. Cars park three abreast during drop off and pick up times. Newly constructed curbs will increase pedestrian safety.
CS
DPR
Enhance park safety through design interventions, e.g. better lighting (Capital)
Install Park security lighting. Lighting in Baisley Park is insignificant; in fact many of the existing lights do not function. A recent survey in the Park resulted in security and lighting being important needs.
197th Street 118th Ave 119th Ave
CS
DOT
Repair or provide new street lights
Turning signal on Farmers at Linden Boulevard
Farmers Blvd Linden Blvd
CS
DOT
Reconstruct streets
This would provide safety for school children and deter sidewalk dumping in the area
CS
DOT
Repair or construct new curbs or pedestrian ramps
This area has fallen into disrepair. The sidewalk is necessary for those wishing to walk to Farmers Blvd. from the LIRR tunnel. There should be spaces left for trees.
CS
DOT
Improve traffic and
there is no turnoff from Basiley to Linden Blvd.
Basiley Blvd
pedestrian safety,
All traffic has to go down Baisley to Farmers
Linden Blvd
including traffic
Blvd. to get to Linden Blvd. There are two
calming (Capital)
schools in this area (St. Catherius and PS 36),
plus there are many small children that live an d
play in this area, traffic is constant and heavy.
The children are at risk. There have been a few
accidents. This would remove some of the traffic
and insure a safer crossing fir children and
seniors in the community.
CS
DOT
Other capital traffic
There is a great deal of traffic approaching the
Linden Blvd
improvements
light at Linden & 195th Street cars park three
195th Street
requests
abreast during drop off & pick-up times. Newly
constructed curbs will increase pedestrian
safety.
CS
DOT
Roadway
Request complete reconstruction of 204th
maintenance (i.e.
street, between Jamaica Avenue and LIRR street
pothole repair,
needs necessary flood relief, roadbed, curbs and
resurfacing, trench
sidewalks.
restoration, etc.)
CS
DOT
Repair or construct
Reconstruct sidewalk on the corner of 192nd
new curbs or
Street and Jamaica Ave, northwest corner new
pedestrian ramps
P.S. 35 elementary school. This would provide
safety for school children and deter sidewalk
dumpling in the area.
CS
DOT
Roadway
Reconstruct Brinkerhoff Avenue (110th Avenue)
Brinkerhoff
maintenance (i.e.
from 173rd Street to 178th Street. Reconstruct
Ave 173th St
pothole repair,
176th Street from Brinkerhoff Avenue (110th
178th St
resurfacing, trench
Avenue) to 109th Avenue. The section of
restoration, etc.)
Brinkerhoff Ave. is in serious disrepair. It has not
been resurfaced or properly maintained in the
last 60 years. There is little to no sidewalk
between 176th and 178th streets. The roadway
is higher that the pedestrian walkway causing
water from the rain and broken water mains to
flow into the yards and basements of homes.
Between 177th and 178th streets the roadway
is so broken up, there is no paving from the
pedestrian walkway to more than give feet into
the roadway. Cars are parked in the mud. We
are submitting photographic evidence. It is truly
a deplorable condition.
CS
DOT
Reconstruct streets
Reconstruct 204th Street between Jamaica Ave
and the LIRR. Request complete reconstruction
of 204th Street between Jamaica Ave and the
LIRR street needs necessary floor relief,
roadbed, curbs and sidewalks.
CS
DOT
Reconstruct streets
Pave and open Montauk Ave for two way traffic
from Linden Blvd. to 120 th Ave. A truning light
on Baisley and Montauk and a stop sign on
120th Ave and Montauk are needed. There is no
turnoff from Baisley to Linden Blvd. all traffic
has to go down Baisley to Farmers Blvd. to get
to Linden Blvd. There are two schools in this
area St. Catherius and PS 36; plus there are
many small children that live and play in this
area; traffic is constant and heavy. Children are
at risk. There have been a few accidents. This
would remove some of the traffic and ensure a
safer crossing for children and seniors in this
community
CS
DOT
Roadway
Improve Various Streets in Octagon
Farmers
maintenance (i.e.
Neighborhood Association Area. Improve streets
Boulevard
pothole repair,
bounded by Farmers Boulevard, Merrick
Merrick
resurfacing, trench
Boulevard and 120th Avenue.
Boulevard
restoration, etc.)
120th Avenue
CS
DOT
Reconstruct streets
Fund curb installation. for many years our
streets have not had new curbs and the area at
109th Ave and 171st Street is an abandoned
eyesore. New curbing will improve the quality of
the area.
CS
DOT
Reconstruct streets
for many years our streets have not had new
109th Ave
curbs and the area at 109th Ave. & 171 Street is
171th Street
an abandoned eyesore. New curbing will
improve the quality of the area
CS
DOT
Other capital traffic
Construct, etc. street in the South Jamaica area
improvements
bounded by South Road, Guy R Brewer, Baisley
requests
and Sutphin Boulevards
CS
DOT
Other capital traffic
Construct curbs along 116th Rd. between 194th
116th Rd
improvements
St. and 195th St. in St. Albans. There is a great
194th St
requests
deal of traffic approaching the light at Linden
195th St
Blvd. & 195th St. Cars park three abreast during
drop off and pick-up times. Newly constructed
curbs will increase pedestrian safety.
CS
DOT
Repair or construct
Construct curbing along 99th Ave between
new curbs or
Farmers Blvd. and 193rd Street (north side of
pedestrian ramps
99th Ave). This area has fallen into disrepair.
The sidewalk is necessary for those wishing to
walk to Farmers Blvd. from the LIRR tunnel.
There should be spaces left for trees.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/18
DSNY
Other cleaning
Institute Seven Day Basket Collection in
requests
Community District 12. Because of the
congestion of our district, especially in
downtown Jamaica by Archer Avenue and
Parsons Boulevard and also Sutphin Boulevard
and Archer Avenue where the subway station is
and the vans and vendors locate, our trash
baskets overflow in less than a day. We face a
problem of overflowing baskets which are
unsightly and create a health hazard. Seven day
collection would help lessen the problem.
2/18
NYPD
Assign additional
Increase Foot Patrol and Sector Cars for the
staff to address
Hollis Area. This request would improve the
specific crimes (e.g.
quality of life in this section of Hollis because
drug, gang-related,
there is excessive drug selling and quality of life
vice, etc.)
issues that could be deterred if there was foot
and sector car patrol.
3/18
QL
Extend library hours
Fund Additional Library Personnel for South
or expand and
Jamaica Branch. The new South Jamaica Branch
enhance library
at Guy Brewer Blvd. and 108th Ave. needs
programs
additional personnel to handle the increased
number of users. This is a new library and
additional staffing will ensure its upkeep and
continued use.
4/18
DPR
Enhance park safety
Install Additional Lighting in King Park. King
through design
Park has summer concerts and other evening
interventions, e.g.
events. Adequate lighting needs to be provided
better lighting
for safety and security.
(Expense)
5/18
DPR
Enhance park safety
Hire Additional Staff for O'Connell Park. Deploy
through design
personnel for fall staffing at O'Connell Park to
interventions, e.g.
include recreational programs.
better lighting
(Expense)
6/18
DEP
Clean catch basins
Replace storm drainage on both sides of
Babylon Ave. The storm drains appear to be
clogged, causing home owner flood and back-up
in their homes.
7/18
DPR
Provide better park
Hire Additional Personnel for Roy Wilkins Park.
maintenance
Needed are a) Funds to employ maintenance
workers for the 54 acre Roy Wilkins Park,
particularly attendants for the newly
constructed comfort station. Workers are
required to work 7AM-10PM, 7 days/week
(total of 5460 hrs. at $10/hr. will be asstd. by
WEP workers). $54,600. b) Funds to employ 1
worker for 8 hrs/day, 7 days/week at $15/hr to
help in cleaning of the park and driving the
tractor. They will be assisted by WEP workers
($43,680). The Association must take on a
greater burden in maintaining the park at a
time when income is reduced. Increased use of
the park has brought on new pressures for the
care & protection of the park. Total=$98,280.
8/18
DPR
Other park
Purchase Equipment for Roy Wilkins Park.
maintenance and
Purchase: (A) Tractor with snow removal,
safety requests
garbage collection and grass cutting equipment:
$27,114; and a (B) carry all Turf II-daily trash
removal and security vehicle $6,253. The
Association purchased a tractor in 1984 which
has been exhausted. The care of 54 acres and
grass cutting, garbage collection and snow
removal are daily and seasonal tasks which
require the daily attention of staff. The
continuous movement throughout the park, by
motorized transport, also helps with security.
9/18
DPR
Reconstruct or
Hire a Tree Pruning Gang. Hire a tree pruning
upgrade a park or
gang for Community District  12 to clear
amenity (i.e.
backlog of trees in need of pruning.
playground, outdoor
athletic field)
10/18
DPR
Other requests for
Hire Six Park Rangers for King Park, Baisley
park, building, or
Park, O'Connell Park, Haggerty Park and Drew
access
Park. A Park Ranger presence in the Park will
improvements
ensure public safety, park cleanliness and
increased usage by the community.
11/18
DPR
Improve the
Increase the Staff of the Department's Forestry
quality/staffing of
Division. Our ongoing residential construction
existing programs
projects plans for individual trees on our streets.
offered in parks or
Unfortunately the existing street trees are not
recreational centers
pruned or maintained. Forestry has been cut
back drastically and our trees have suffered
since then. We need at least a doubling of the
forestry staff to do minimal pruning and tree
removal. The backlog is a disgrace.
12/18
DPR
Forestry services,
including street tree maintenance
Hire a stump removal Gang. Hire a stump
removal gang for community District 12. Community Board 12 has a backlog of stumps to be removed.
13/18
DPR
Other requests for
Fund King Manor museum in Jamaica. The King
150-03
park, building, or
Manor Association manages the recently
Jamaica Ave
access
restored home of Founding Father, Rufus king.
improvements
Mr. King's legacy includes important work as a
delegate to the Constitutional Convention, and
Contributions as a skilled diploma, statesman
and an outspoken opponent of Slavery. This
Historic site of national significance with
exceptional educational potential. Children,
adults and Families are participating in the
educational programs in steadily increasing
numbers. In the past 12 months there has been
a 200 percent increase in school programs and
the Manor has served four times as many
students and teachers as previously.
14/18
DYCD
Provide, expand, or
Provide Sites for Summer Employment For
enhance after
Youngsters. They place youngsters at job sites
school programs for
for summer employment.
elementary school
students (grades K-
5)
15/18
DYCD
Provide, expand, or
Provide Additional Funding for additional youth
enhance the
programs and personnel in Community Board
Summer Youth
12Q. Would Like additional personnel for the
Employment
Programs.
Program
16/18
DYCD
Provide, expand, or
Provide Funding to Sustain and Enhance
enhance the
Programmatic Activities at PFLC.
Summer Youth
Employment
Program
17/18
DOT
Other expense
The engineering unit is in dire need of 5
traffic
additional traffic control inspectors. The traffic
improvements
safety studies cannot be done with only one
requests
person on staff. A backlog of 3,000 studies in the
Borough is intolerable.
18/18
DOT
Improve traffic and
Replace storm drainage on both sides of
pedestrian safety,
Babylon Ave. The storm drains appear to be
including traffic
clogged, causing home owner flood and back-up
calming (Expense)
in their homes.

