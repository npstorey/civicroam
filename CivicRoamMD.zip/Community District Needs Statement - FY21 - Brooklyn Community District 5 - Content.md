- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 5 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1BtOFmw2XdHOwCHoSiWbr9tsiy8CRr-PZ/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1BtOFmw2XdHOwCHoSiWbr9tsiy8CRr-PZ/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
5
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 5
image
Address: 127 Pennsylvania Avevue, 2nd Floor Phone: (718) 819-5487
Email: BK05@cb.nyc.gov
Website: www.brooklyncb5.org
Chair: Andre T. Mitchell District Manager: Melinda Perkins
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 5 in Brooklyn, services over 183,000 residents living in the community of East New York, which includes the neighborhoods of Cypress Hills, City Line, Highland Park, New Lots and Spring Creek. This unique community is situated between Jamaica Avenue to the North and Jamaica Bay to the South; and is bordered to the west by Van Sinderen and Williams Avenues; and to the east by Eldert Lane and 78th Street.
East New York is a community that is rich and deeply rooted in history and currently undergoing of one of the most intense landscape transformations across the city with the implementation of the East New York Neighborhood Plan (ENY Rezone). The District has been identified as the premier community for New York City's vision for future development through the Mandatory Inclusionary Housing and Zoning for Quality and Affordability, which was voted up in the New York City Council. (a) Under the new MIH and ZQA implementations - the construction of taller buildings in denser neighborhoods is allowed with the mandate that developers set aside a certain portion of "affordable" housing units in new developments.
Brooklyn's Community Board 5 is ever-growing in its uniquely fascinating history with the discovery of one of New York City's recognized African Burial Grounds, in the New Lots section of the district. In 2013, the former City Council Member of the 42nd CD, Charles Barron, submitted the CB5 approved street co-naming for African Burial Ground Square - which covers the four-block radius of New Lots Avenue, Schenck Avenue, Livonia Avenue and Barbey Street. Today, the work continues with capital funding allocations from NYS Assembly Member Charles Barron and NYC Council Member Inez Barron and, for the renovation and renaming of the adjacent Sankofa Playground - formerly known as Schenck Playground. This was the result of the excavation process with the NYC Department of Parks and Recreation, that later confirmed remains of enslaved Africans who worked and died on those very grounds. Sankofa Playground received a multi-million dollar capital allocation along with the adjacent New Lots Library, which received close to $33 million for a complete gut renovation. These investments will bring forth one of the most culturally relevant projects in our district and CB5 is extremely proud to have the partnership and support of the Assembly Member, Council Member, and the creative teams of Brooklyn Parks, and Brooklyn Public Library.
Brooklyn, Community Board 5 also houses one of the largest retail expansions in New York City - the Gateway Center Mall - Phase II, covering over 600,000 sf in the Spring Creek area. The expansion of the Gateway Center mall helped to realize one of the most important Community Benefits Agreements (CBA) in East New York's recent history. Through the implementation of the CBA, Man Up! Inc. and the newly formed East New York Restoration Local Development Corporation worked collaboratively to provide employment open houses for the retail giants and helped to secure over 1,200 jobs for local residents which included the pre and post-construction opportunities through the project labor agreement.
Community Board 5 also houses two of the largest Industrial Business parks in the city - the East New York and Fairfield / Flatlands industrial business zones. There are hundreds of businesses within the two industrial areas stretching about 40 blocks. This is an area that currently requires greater community connection as it relates to MWBEs within the parks as well as an increase in the local hire percentage.
The district is also home to twelve NYCHA developments which provide affordable housing for thousands of ENY residents. It is one of the most important housing stocks in the district and we will continue to fight for greater investments in maintenance, back-logged repairs, quality heating systems, recycling education, and overall improvement with bulk trash removal.
CB5 also has four amazing Brooklyn Public Library branches - Arlington, Cypress Hills, Spring Creek and of course the New Lots branch which is slated to receive the complete overhaul. We continue to encourage residents of the district to take full advantage of these wonderful institutions.
Community Board 5 also houses all of the public schools within School District 19 and we have over 50 sites hosting students from Pre-K through 12th grade. We are also pleased to say that the ground breaking has been completed for a 1000 seat newly constructed elementary through middle school on the Atlantic Avenue side of the district.
CB5 also has beautifully constructed religious institutions of various faiths; delicious eateries in every section; and community based organizations that provide invaluable services to thousands of children, families, and businesses across the city. Moreover, in July, the long-awaited opening of New York City’s largest state park took place – the Shirley Chisholm State Park, right off of the Pennsylvania Avenue exit on the Belt Parkway. This was the former landfill site that was completely transformed into a beautiful open park space that now boasts a bike library, beautiful walk ways and another open space for the families of the East New York community.
Additionally, over the past decade, the district has had one of the fastest growing populations in the city; with an increasing African American demographic. According to the 2015 Neighborhood Health Profile for Community District 5, the population is made up of 52% Black (non-Hispanic); 37% Hispanic; 6% Asian; 3% White; and 2% Other. The district has also become home to one of the largest Bangladeshi populations across the city, with a high percentage of the residents in the City Line neighborhood, migrating from Bangladesh.
The people of this district are just as unique as the neighborhoods in which they live. In that regard, it is the aim of Brooklyn, Community Board 5 to fight for the very basic quality of life needs that will improve the lives of our residents. Those very basic needs include - consistent maintenance within our housing developments (both public and private); greater access to healthy and fresh food choices; district-wide education on preventive health care and healthy living methods; mixed use development projects that include long-term community wide benefits; living wage employment; dedicated funding for cultural community facilities; quality and competitive education for our children; clean and well-maintained streets; necessary upgrades and improvements to sub-street level flooding regions; and an infusion of financial support for small businesses and community based organizations.
The East New York Rezoning Plan, and all the robust initiatives that are attached to it, is the major focus right now in Community Board 5. Through the plan, East New York is slated to receive $267 million in capital investments with direct support for the renovation and upgrade of existing housing and construction of new affordable housing units; small business growth and development; roadway repairs and upgrades; new educational and community facilities, and much more.
Here is an outline of some of the key components of the East New York Plan:
1200 units of new affordable housing including senior and supportive housing • Eviction prevention support through the Tenant Support Unit • Homeowner Helpdesk which provides direct financial and legal counseling for homeowners • Up to $15,000 for first time homeowners with the Home First Down Payment Assistance Program • Renovations and upgrades to public parks spaces, including the most recent renovation of City Line Park • Repairs and renovations to the historic PAL building at 127 Pennsylvania Avenue which has served as the home base for Brooklyn, Community Board 5 for 40 years. The building now offers programming for families of East New York from the Child Center of NY and Youth Strategies Division of NYPD • Activation of a Community NYC Retrofit program to encourage smaller housing buildings to participate in the Green Housing Preservation Program • The East New York Workforce 1 center which provides direct access to employment opportunities and training, located on Atlantic Avenue • Support for commercial corridors and other small businesses throughout the district • A new 1000 seat educational facility for elementary and middle school-aged children next to the Chestnut Commons development site • Technological and structural upgrades to East New York’s Industrial Business Zones • Wi-Fi access on many commercial corridors and LINK NYC activated kiosks.
These are some of the wonderfully creative strategies being implemented that will assuredly work together in making East New York an even greater community. In that regard, we will continue to aggressively advocate to Mayor deBlasio, our local elected officials and the commissioners of our city agencies, for the very basic quality of life needs that this community deserves. Let’s work together to make sure that Brooklyn, Community Board 5 becomes an even greater community to Live, Work, and Thrive!
For information on ENY Rezone - http://www1.nyc.gov/site/planning/plans/east-new-york/east-new-york-1.page Shirley Chisholm State Park - https://parks.ny.gov/parks/200/details.aspx
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 5
image
The three most pressing issues facing this Community Board are:
Health care services
The lack of access to quality and affordable healthy food is still an extremely serious issue in CB5. According to the 2014 Shop Healthy Brooklyn initiative, as outlined in the Epi Data Brief, titled "Access to Healthy and Affordable Food in ENY", over 50% of the food establishments in the 11207 and 11208 zip codes, were bodegas. The Epi Data Brief reported that there were 264 food establishments identified in those specific zip codes of CB5 and the results were startling... 135 Bodegas = 51% of the food providers in the district 71 Fast Food Restaurants = 27% of the food providers in the district 24 Full Service Restaurants = 9% of the food providers in the district 13 Grocery Stores = 5% of the food providers in the district 12 Specialty Grocery Stores = 4.5% of the food providers in the district 8 Fruit & Vegetable Stores = 3% of the food providers in the district These numbers expose the devastating truth about how income levels in communities of color dictate the quality of services and products in neighborhoods across this city. It is also noted in the Epi Data Brief that for every 1 grocery store in the 11208 zip code, there are 5 fast food restaurants and 10 bodegas. Moreover, the brief provided statistics showing the trend that bodegas were more likely to display advertisements for unhealthy food and beverage options over fresh produce and water. In Community Board 5 there is a high percentage of adults who suffer from diabetes and 31% of adults in East New York and Starrett City are obese. This is a direct correlation to the lack of healthy food options and the saturation of advertisements for foods and beverages that provide little, if any, nutritional value. We have to work collectively to stop this blatant attack on the health and well being of our families in CB5. The time and investment must be made to further the efforts of the Shop Healthy Initiative. Here is what we are requesting: 1. We are requesting that the New York City Department of Health and Mental Hygiene, working in conjunction with the Brooklyn Borough President and the NYC Council, allocate the funding that can provide greater incentive programs for local businesses to invest in fresh produce and high quality healthy foods. 2. Further the Shop Healthy Brooklyn study to include the food establishments in the 11239 section of the district. We have a growing population in the neighborhood of Spring Creek and there are food establishments that should be educated on how they can better serve the district.
3. Support the connection between our local gardens and farmer's markets with local supermarkets and grocery stores. Since more than half of the food establishments are bodegas and a high percentage are grocery stores - local gardens and the two farmer's markets that exist in CB5 should have a direct line to providing them with fresh fruits, vegetables, herbs, and breads. 4. Invest in permanent signage that promotes healthier eating choices in local bodegas, grocery stores and places where families shop. Consistent investment and support in providing access to healthy living and healthy eating will assuredly alleviate the food-related illnesses that we suffer from in CB5. Epi Data Brief: https://www1.nyc.gov/assets/doh/downloads/pdf/epi/databrief80.pdf Shop Healthy Brooklyn: https://www1.nyc.gov/site/doh/about/press/pr2016/pr096-16.page
Land use trends (zoning, development, neighborhood preservation, etc.)
CB5 has been undergoing major zoning changes and development over the past few decades and unlike many other areas throughout the city - it results in affordable housing for homeowners and renters. However, there is a lack of community input as it relates to larger development designs and attached community benefits; as well as choice in developers and their partnering general contractors and management companies. CB5 is the last district in the city that is filled with land opportunities and is "development-ready". We are asking that HPD and DCP come back to the community board before any future projects are presented to allow for a review of the East New Your Urban Renewal Plan in it's current state and how it has impacted the community at large. We are also requesting a real community based approach to the trend of mixed-use businesses and how ground floor commercial spaces are being promoted and rented to potential local businesses and vendors. We have larger development projects in our district that have still have vacant ground floor commercial spaces because they are not being marketed to encourage local business participation or cooperative work environments that can guarantee consistent rent for the land-owner while opening up opportunities for embryo businesses share the cost of overhead.
Trash removal & cleanliness
Brooklyn Community Board 5 still has an ongoing issue with bulk trash collection in our public housing developments. The concept of public housing should not be synonymous with garbage, unkempt grounds, failing boiler systems, insufficient maintenance staff, and various levels of neglect. The maintenance staff needs to be increased immediately and provided with the necessary adequate training. Additionally, the Department of Sanitation and NYCHA's trash collection services have to coordinate pick up schedules and provide residents with on-going workshops and educational tools on recycling and best practices for bulk trash collection preparation. NYCHA is the largest provider of public housing in the nation and CB5 hosts a large amount of that stock. It is imperative that we put financial commitments and dedicated focus on how our NYCHA communities are being serviced and maintained. The residents who live within the developments deserve a real quality of life and our city agencies have to address that although the needs are great, the fact of the matter is that the buildings are filled with human beings.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 5
image
M ost Important Issue Related to Health Care and Human Services
Access to healthy food and lifestyle programs
The lack of access to quality and affordable healthy food is still an extremely serious issue in CB5. According to the 2014 Shop Healthy Brooklyn initiative, as outlined in the Epi Data Brief, titled "Access to Healthy and Affordable Food in ENY", over 50% of the food establishments in the 11207 and 11208 zip codes, were bodegas. The Epi Data Brief reported that there were 264 food establishments identified in those specific zip codes of CB5 and the results were startling... 135 Bodegas = 51% of the food providers in the district 71 Fast Food Restaurants = 27% of the food providers in the district 24 Full Service Restaurants = 9% of the food providers in the district 13 Grocery Stores = 5% of the food providers in the district 12 Specialty Grocery Stores = 4.5% of the food providers in the district 8 Fruit & Vegetable Stores = 3% of the food providers in the district These numbers expose the devastating truth about how income levels in communities of color dictate the quality of services and products in neighborhoods across this city. It is also noted in the Epi Data Brief that for every 1 grocery store in the 11208 zip code, there are 5 fast food restaurants and 10 bodegas. Moreover, the brief provided statistics showing the trend that bodegas were more likely to display advertisements for unhealthy food and beverage options over fresh produce and water. In Community Board 5 there is a high percentage of adults who suffer from diabetes and 31% of adults in East New York and Starrett City are obese. This is a direct correlation to the lack of healthy food options and the saturation of advertisements for foods and beverages that provide little, if any, nutritional value. 1. We are requesting that the New York City Department of Health and Mental Hygiene, working in conjunction with the Brooklyn Borough President and the NYC Council, allocate the funding that can provide greater incentive programs for local businesses to invest in fresh produce and high quality healthy foods. 2. Further the Shop Healthy Brooklyn study to include the food establishments in the 11239 section of the district. We have a growing population in the neighborhood of Spring Creek and there are food establishments that should be educated on how they can better serve the district.
3. Support the connection between our local gardens and farmer's markets with local supermarkets and grocery stores. Since more than half of the food establishments are bodegas and a high percentage are grocery stores - local gardens and the two farmer's markets that exist in CB5 should have a direct line to providing them with fresh fruits, vegetables, herbs, and breads. 4. Invest in permanent signage that promotes healthier eating choices in local bodegas, grocery stores and places where families shop.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
According to the 1.2015 Neighborhood Health Profile for East New York, heart disease and cancer rank as the top two causes of death; with over 3,000 people fatally stricken from the diseases combined. These figures prove that a high percentage of our residents are living with illnesses that not only impacts their physical abilities but also increases stress and discomfort for themselves and their immediate families. The direct results are hardships that permeate every fraction of physical and mental health. With greater access to healthier food and lifestyle programs we can increase life span, encourage healthier eating habits and lifestyle habits and lessen the percentage of residents who suffer from chronic illnesses, mental health challenges, potential homelessness, and the need for additional assisted living options. Additionally, the medical facilities that exist in the district must be infused with the expense funding that allows for greater outreach efforts. There are a number of clinics and medical centers in the district that are utilized by residents, when they become ill or to address specific health issues - however there is not enough general outreach conducted to encourage preventative measures, consistent health/wellness visits, and overall community health as a lifestyle.
Needs for Older NYs
The Senior population in the community must be prioritized and provided with access to quality housing; fresh food and hot meals; activities that encourage longevity and happiness; and each Senior Center should be equipped with vehicles that provide shuttle services for events throughout the district and borough.
Needs for Homeless
Community Board 5 has homeless housing and services that support families, as well as single women and men. Although the community has made a very clear statement about not wanting any new facilities that provide temporary shelter; we also recognize the need to have the resources that aid residents in temporary housing to transition to permanent housing. In that regard, all facilities in CB5 that provide temporary housing (families / single adults), should be surveyed and evaluated. Additionally, the community is completely against the careless decision from DHS/DSS to utilize new commercial hotel sites for emergency placement of homeless individuals in this city.
There is an immediate tension and feeling of disrespect that is expressed from community members to our Board and it carelessly puts the new residents who will occupy the space in a neighborhood that is not prepared or willing to embrace their presence. Furthermore, any private land transfer that involves the potential contractual agreement with a city agency, should include community input. The participation and involvement of community, is currently only encouraged for Community Advisory Boards (CABs) upon completion and execution of the contract - this is not the way to build strong communities. All Community Advisory Boards should have a mandate for Community Board membership - to include either the Chairman of the Board, the District Manager, or the Chair of the relevant committee - e.g. Chair of Social Services / Health Committee.
Needs for Low Income NYs
We have a mix income population and all types of services are need. We need training programs that will make our low income population work ready.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
4/20 DOHMH Other programs to
address public health issues requests
Funding to further the SHOP Healthy Brooklyn (NYC) program in CB5, to include zip code 11239. The original study completed in CB5 only included zip code 11207 and 11208. The results of the program outlined the great need for healthy food options in local groceries and bodegas. The Epi Data Brief generated from the initiative also showed that bodegas make up 51% of the food establishments in the 11207 areas of the district. Additionally, the brief exposed that for every grocery store, there were 5 fast food restaurants and 10 bodegas. In addition, during the Shop Health initiative, grocery store and bodega owners were given free marketing tools that promoted healthy food and beverage purchases, as well as free containers/baskets for fruit & vegetable displays.
image
5/20 DOHMH Promote Quit
Smoking Programs
Create bus station poster campaigns that include messages and images from Truth.com and/or tobaccofreekids.org. These campaigns should be primary in places of public transportation, in particular stations/stops closest to school buildings in the district. CB5's District Office team would like to participate in the dissimenation and promotion of any materials created through DOHMH to address this very serious matter. It was stated in a publication by tobaccofreekids.org, that lifetime smoking and other tobacco use almost always begins by the time children graduate from high school. Help CB5 to create the kinds of initiatives that prevent our children from long- term illnesses.
image
7/20 DFTA Enhance programs
for elder abuse victims
Create partnerships with local service agencies that directly support senior living - e.g. HRA, SS, SNAP, etc. to allow for on-site services in each senior center to assist seniors with monthly responsibilities and documentation submission deadlines. Seniors are sometimes faced with deadlines and monthly, quarterly, or annual responsibilities that can be forgotten or mismanaged. This is a way to ensure that they have support in fulfilling requirements that dictate the continuation of fixed incomes and other subsidies that they may be receiving.
image
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 5
image
M ost Important Issue Related to Youth, Education and Child Welfare
Educational attainment
Community District 5 is home to School District 19. The need for greater focus on those programs and initiatives that encourage learning and increase student activity must be implemented in District 19 schools. Our schools need to have permanently funded arts and music programs with instructors and musical instruments in every music class. Arts and music are proven methods to increase student grades and productivity, however most of our art and music programs only exist through CASA initiatives which are not permanent and depend on annual allocations from council members; or they are programs that are a part of an afterschool initiative that does not fully address the need. Arts and Music should be a part of in-school time instruction. With the percentage of residents (25 or over) who have attained college level education, being lower than 15%, there is a real need to connect our students to pathways to higher education. The earlier that students are introduced to the possibilities of college level education, the more likely it is for them to attend. The discussion of college and all that it has to offer must always be connected to formal education, within our schools. Additionally, District 19 Parent Associations need more support to aid in encouraging greater participation from parents. A parent who is deeply involved in their child's education, provides a greater support system for the child's learning. Physical Activity is also an issue - gymnasiums should be fully equipped with materials and equipment that allow for more interactive programs for the students. Childhood obesity is still at an all-time high in the district with youth diabetes being one of the predominant results, along with youth depression - these are factors that deplete children's self-esteem and increase the potential of early drop out. Consistent Physical Activity in the schools is a base-line necessity and should be taken very seriously. We need a survey to be conducted to assess the current PA programming in each school and follow up with direct and permanent funding to advance those efforts and save our children. Drug and alcohol use, including cigarette smoking is something that young people are indulging in more often, and at much younger ages than in the past.
The social use of marijuana and other drugs must be brought to the forefront of education as well. More campaigns must be created to address this very serious matter. The early exposure to drugs and alcohol creates the potential for long term use. Cigarette smoking needs to be pushed as drug use. It is still not a strong enough message, yet more teenagers pick up the habit of smoking and carry it into their adult lives, than those that indulge in experimental alcohol use.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
There is a great need to eliminate overcrowding in our schools. Any and all barriers that would prevent a child from learning must be eliminated.
School co-location has not proven to improve the performance of the schools in our district. The multiple administrations and school systems in proximity takes a focus away from the quality of education.
Needs for Youth and Child Welfare
Provide a list of all ACS Day Care sites that are currently under lease terms in CB5 with transparency of building owner and length of lease terms. Request: Ensure that all leases signed for day care/child care facilities include the city’s option for right of first refusal – to safeguard facilities from being pushed out when owner wants to sell. The lease terms should be standardized to include terms that allow for longevity of the facility and its services to children.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
3/21
DYCD
Provide, expand, or
We are appealing to the NYC Department of
576 Blake
enhance
Youth and Community Development to include
Avenue
Cornerstone and
the necessary upgrades of the Boys & Girls
Beacon programs
Restrooms in Unity Plaza Community Center.
(all ages, including
Currently, the Cornerstone Program operating
young adults)
the center is Grand Street Settlement and they
are aligned with the request. There is an
existing capital project for specific renovations
of the center through NYC Council funding
allocations from CM Barron and former Speaker
Quinn. However, the funding will not allow for
the restrooms to be upgraded due to the detail
of the project. Again, we implore that DYCD
review its capital budget to understand the
importance of this funding to be combined with
the previous allocation for the center.
12/21
SCA
Renovate interior
Complete renovation for gymnasium at Van
800 Van
building component
Siclen Community School at George Gershwin
Siclen
Campus (I.S. 166). The Gymnasium supports all
Avenue,
schools within the campus and is outdated. Full
Brooklyn,
renovation to floors, AC system, bleaches, and
New York, NY
student athletic equipment is needed to provide
full athletic programming.
13/21
SCA
Renovate other site
Renovations and upgrades for Moe Finklestein
12504
component
Athletic Complex or Thomas Jefferson Field -
Flatlands
including the bleaches, lockers, field, installation
Avenue
of score board, multi-purpose turf, and new
stationary equipment. The Thomas Jefferson
field is in serious need of upgrading. Currently
multiple home-grown youth football leagues
and cheer-leading squads utilize the field for
practices and games. Additionally, a local soccer
league has adopted the space for annual games
and tournaments.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
2/20
DOE
Other educational
Provide permanent funding for arts/music
programs requests
programs in all middle schools in District 19.
Music programs must be restored and/or
implemented back into middle schools to
prepare students for Performing Arts high
schools. Funding should be focused on hiring of
certified/trained instructors to maintain music
programs during school hours.
10/20
DYCD
Provide, expand, or
Expedite renovations at Unity Plaza Community
576 Blake
enhance
Center $1.5 million was allocated to NYCHA
Avenue,
Cornerstone and
from former City Council Speaker Quinn and
Brooklyn,
Beacon programs
former Council Member Charles Barron to Unity
New York, NY
Plaza for necessary renovations within the
Community Center and outdoor spaces, close to
six (6) years ago. To date, renovations have not
been completed. Still pending is the mural in the
amphitheater and renovations within the
Community Center for restrooms, multi-purpose
room, studio to be installed in smaller room,
dance room, and other necessary upgrades to
ceilings, etc.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 5
image
M ost Important Issue Related to Public Safety and Emergency Services
Crime prevention programs
Continued violence and acts of violence in our communities is a true health epidemic. A crime that is committed, not only has a direct impact on the person committing the crime and the victim of it; it impacts the entire community. It is a real health epidemic and the only way to effectively address it, is to implement preventive measures. Crime prevention programs are key to address the epidemic of violence that plagues our neighborhoods. Programs that include the following: • Street outreach teams that identify at-risk and high-risk members of the community • Initiatives that work to engage these populations and provide long-term counseling and life coaching • Workforce development component that assesses individuals’ employability and levels of education; and offers job readiness and placement; and educational referrals. • An assigned team of Trained and Certified Mentors who will maintain the relationship during and after completion of the program. These are actions that can work to prevent crime in neighborhoods and address violent behavior at its core. Acts of violence are reactionary outburst that stem from a number of different issues; far too often in our neighborhoods violence is the result of concerns and issues that have been neglected and disregarded. Crime Prevention Programs are definitely a way to increase the quality of life for residents of this community and break the cycles of violence that currently exist. Local Precinct - 75th precinct as well as PSA2 in CB5 to work more closely with Resident Associations and Block Associations to create more preventative measures to address public nuisance, crime, and community relationship building. Far too often, the officers from the Public Service Areas and the precincts are called in to address crime and matters of concern that exist or that have already happened. The result is usually strategies that lean more on the side of criminalizing the entire resident body as opposed to working together to improve overall quality of life.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
COMMUNITY POLICING: Community District 5 in Brooklyn is patrolled by the 75th precinct; which is one of the largest precinct areas in the city. It is for that very reason that crime prevention in this community has to be a multi- prong approach. The idea that policing alone, even at its finest, can effectively and consistently reduce crime is unrealistic. There have to be many components working together to have the most powerful and positive outcome. "The magnitude of violence – in terms of the number of victims – makes it a serious health issue. But the effects of violence also ripple through a community, causing trauma to those who witness it or live in fear of it." Excerpt: Cure Violence http://cureviolence.org/understand-violence/violence-as-a-health-issue/ POLICE PRESENCE: Policing measures are more effective when community has a strong input and involvement on how those measures are enforced and where the most need for those enforcements have been identified. Through the Commercial District Needs Assessment efforts from local development corporations in East New York, it was recognized that most small businesses along commercial corridors in the district, want to increase the police presence on the commercial strip. Assessments were completed from four commercial corridors in East New York and strip identified that an increased police presence along their corridors would help to improve their businesses. When merchants were asked what changes they needed to occur to bring more customers into their businesses - %25 of the merchants responded, which was the highest ranking response, with a need for more safety. East New York Brooklyn Commercial District Needs Assessment - NYC Department of Small Business Services / Avenue NYC http://www.nyc.gov/html/sbs/downloads/misc/cdna-eny/index.html
Needs for Emergency Services
Community District 5 has an increase in population due to the construction of thousands of units of housing. With an increase of residents, there is of course an increase of potential fired hazards. Each new development should be required to work with the local FDNY stations to implement annual Fire Safety Education workshops for all of the
residents. In addition residents should be offered the opportunity to become CPR certified or at minimum, any Resident Association, Building Captains, Resident Leadership, should be offered the CPR certification. This is a great way to keep all residents educated on fire safety methods and decrease potential fire related incidence.
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
10/21 NYPD Upgrade the
emergency response system
CB5 receives calls from local residents who complain about neighboring vacant properties being vandalized or used for drug use and sale. In some cases, although the Department of Buildings borders the windows and doors with locks, the property is still broken into and it creates an atmosphere of crime and instills fear in the residents. Once a property is deemed vacant and DOB has bordered that property - local NCO's or other assigned staff should be monitoring it consistently to ensure that the property remains secure and safety is at optimum levels for neighbors.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
8/20
NYPD
Other NYPD staff
CB5 has the highest incidences of illegally
resources requests
parked vehicles and abandoned vehicles in the
city. Our numbers have risen due to the amount
of local auto shops and garages that park their
junk or for-sale vehicles on public streets; and
other abandoned vehicles that are randomly left
on public streets for years. We need a very
specific focus on this issue and an increase in
the officers that search for these incidences in
the district.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 5
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
East New York is a beautiful community filled with well maintained and new homes, beautifully constructed private and public housing developments, active commercial corridors, dynamic school buildings, thriving gardens and so much more - However consistent trash removal in and around all of these spaces has been a issue for many years. In particular, in the public housing developments throughout the district, excessive amounts of bagged trash and bulk trash items are piled on side streets for days at a time. In most cases, trash pile ups are literally lined on street blocks that encompass housing developments. This is an immediate attack on the quality of life for residents of the developments as well as surrounding community members. The amount of garbage and the amount of time it takes to collect it, has a direct impact on the increase of rodent and pest infestations in the development which also causes an increase in asthma and other health matters that are already prevalent in this district. In addition, the aesthetic stimulates negative perception of and for the people of the community. Mountains of trash left on sidewalks where thousands of families live, work and play daily is a complete disrespect and outright disregard for the community as a whole. Businesses on some of the commercial corridors are also in dire need of an increased focus from the city on trash clean up. Instruction on how to discard trash and where to place it on the strip, has to be reiterated and enforced. Additionally, the schedule of trash removal has to be adjusted to increase pick up times.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Capital Projects in the district are not being prioritized within DEP. There are areas in the district that have capital projects pending for over 10 years and due to delays residents have been forced to endure flooding, standing water, and other measures that directly impact their quality of life.
Additionally, routine maintenance and upgrade work should be scheduled for all water mains, roadways, catch basins, and water supply systems in the district. Too many areas in the district receive emergency repair work on systems that are over due for maintenance and necessary upgrades.
Frequent updates on the 26th Ward Water Treatment Plant.
Needs for Sanitation Services
Increase pick up schedules in NYCHA developments. In some cases, multiple NYCHA developments run along the same strip which literally transforms the strip (blvd/street/avenue) into a strip of garbage. A clear example is the fact that Louis H. Pink Houses, Cypress Houses, and Boulevard Houses all run along Linden Boulevard. If the trash is not removed within those three developments, it creates an environment of air pollution, rodent attraction, limited walkway on the sidewalks and an overall disregard for quality of life for thousands of community members. Increase trash pick-up schedules on commercial corridors in district: • Sutter Avenue / between Van Sinderen and Pennsylvania Avenues • Liberty Avenue / between Euclid Avenue and Forbell Street • New Lots Avenue / between Van Sinderen Avenue and Elton Street • Fulton Street / between Large development is on the rise in CB5, and with that development comes an increase in families – which results in a larger amount of trash and recyclables that are put curbside for pick up. Areas of the district that were never developed on, now have multi-level homes, and buildings that have over 500 units of housing. The study for a tri-day pick up in CB5 needs to be conducted. For reference, please research the following summarized list of new developments (completed or nearing completion) in the district within the last 5-10 years: a. Gateway/Spring Creek Area which now encompasses: Spring Creek Nehemiah homes phases III & IV; Gateway Elton apartments with 9 buildings and 659 units - with new ground level commercial spaces b. Livonia Avenue bet. Pennsylvania Avenue & Van Sinderen which now encompasses: Livonia Commons apartments and new ground level commercial spaces – 4 buildings with 288 units c. Pitkin Avenue bet.
Berriman Apartments – new development – 6 story building with 47 units d. Redwood Senior – 81 units built on
former NYCHA parking lot (Linden Houses) e. Stanley Commons – 6 buildings with 240 units built on former NYCHA parking lot (Linden Houses) f. Linden Boulevard and Emerald Street Apartments – new development which encompasses 4 buildings and 521 units. g. Dinsmore Chestnut site – new development with over 200 units h.
Corretta Scott King Senior – 50 units i. Belmont Gardens / Conduit Blvd & Eldert Lane – 67 units
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
1/20
DSNY
Provide more
Increase pick up frequency in NYCHA
frequent garbage or
developments in CB5 • EXPLANATION: Current
recycling pick-up
pick up schedule for NYCHA facilities creates
long-standing bulk trash along corridors and
streets within the district which increases pest
infestation and leads to greater potential for
historic health issues including asthma and
others.
16/20
DSNY
Other cleaning
Increase street cleaning and maintenance along
Pitkin Avenue
requests
Pitkin Avenue commercial areas (between
Hendrix
Hendrix Street and Wyona Street) •
Street Wyona
EXPLANATION: This small commercial strip is in
Street
need of consistent street cleaning and
encouragement of local stores to participate in
the adopt a basket program.
17/20
DSNY
Other enforcement
Increase frequency of street inspection to
requests
remove abandoned vehicles and illegally parked
vehicles. • EXPLANATION: CB5 has the highest
rate of 311 complaints for illegally parked and
abandoned vehicles. We need a collaborated
agency approach to address the issue.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 5
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Housing support (including tenant protection)
With a focus on the East New York Rezoning Plan, it is imperative that housing that is slated for the community be truly affordable for the current members of the community, and all income levels that exist within the neighborhood. Also, new development is not just an opportunity for new affordable housing - community resources must be attached to all new housing to provide benefits that impact all levels of community development and economic growth. Additionally, mixed use housing that includes ground floor commercial space must include truly affordable rents for local and minority businesses. New development in CB5 over the last 10 years has included ground floor commercial - (i.e. Livonia Commons, Gateway Elton) and to date, the majority of the commercial units are vacant. This amplifies the need for greater incentives for small business owners and the need to create cooperative business solutions and lower rent options for local owners.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
The homes constructed on Loring Avenue between Sapphire Street and Amber Street cleared for development without certificate of occupancy data. Homeowners have properties that are in an area that needs structural repair and they are unable to sell or move forward with the status of the properties. How can the Department of Buildings assist with this matter?
Needs for Housing
With East New York being the point of focus for the initial influx of development under the new MIH; it is necessary for development to include economic development as well as community development. New development that comes into the community should be mixed use with businesses as well as community space, as a "Mandatory Inclusion". With an every growing non-profit community the need for open community spaces throughout the district is a necessity and mixed use development affords the opportunity for further small business development as well as community based organizations to acquire one of the most vital assets to their success - space. Create an addendum for all RFPs, RFQs, etc. – to include community board comment/suggestion. Currently community boards are not included and therefore the full proposal lacks the voice of the community in which the proposed project will exist. Given the recent re-zoning and influx of housing development – CB5’s input is crucial in creating comprehensive community development projects. Increase affordable housing opportunities for single adults returning to the district from college, military, etc. The majority of the development constructed in the community has less than 10% of the units available for single adults. This forces people returning to the district or those that have not yet embarked on the path of building families and have lived with parents/family members - to seek housing in other communities. We need to ensure that we can embrace the single members of the community.
Create greater incentives for developers to include senior housing in larger development sites, where there are multiple phases and/or buildings. It was reported from the Van Siclen shelter - operated by Samartin Village, that they have an increase in senior residents. This is due to the fact that affordable housing for seniors has not increased at an equal rate with overall new development in the district. Supportive housing has become the common addition to larger development sites which brings in new residents from other areas - however, our seniors are being pushed out and into temporary housing facilities. (Coordinate with SBS) Create incentives for developers of mixed-use development to include local small businesses for tenant opportunities. Currently, the mixed-use development in CB5 has vacant ground floor commercial space due to high rents. (Coordinate with DOHMH): Work with developer to provide greater incentives for Fresh Food markets to be included in mixed use development as healthy, community-friendly anchor tenants. While Dollar Tree and other similar corporations provide a service that the community members are familiar with – they do not add to the overall benefit of the community which includes healthy living primarily, and employment diversity. Provide a report on the amount of maintenance staff that are assigned to each NYCHA development in CB5. Increase amount of maintenance staff to address frequency of
interior cleaning schedules and grounds-keeping maintenance schedules. Commit funding for LED lighting within all CB5 NYCHA developments. Flood lighting, according to NYCHA, was a pilot program to determine the impact of lighting on decreasing crime – so there should be an immediate plan to implement the proper lighting (LED) to allow for crime reduction while complimenting the developments’ resident’s quality of life.
Needs for Economic Development
Economic empowerment in a community requires participation from small business owners, community based organizations, elected officials, and city agencies. The efforts in revitalizing the commercial corridors in East New York through the Department of Small Business Services, is a great start but it must be continued. Additionally, community based organizations need greater resources when they are tasked with engaging business owners; to increase the outcomes. Currently East New York is home to three Local Development Corporations, Cypress Hills; ENY Restoration; and LDC of East New York, along with Highland Park Community Development Corp. They each have participated in the commercial revitalization efforts through SBS. The results were printed in SBS's Avenue NYC report. Additionally resources have to be increased for those organizations that offer specific services that encourage entrepreneurship and small business development. ENY Restoration LDC provides the only small business incubator spaces for small businesses and LDC of East New York provides services for women in business as the only recognized Small Business Development Center in the community. These are services that strengthen the economic standing of the community and they need to be in receipt of increased focused funding to continue in those efforts. Issue: Office Anchor Strategy plan for East New York must be re-visited. The proposed solution to revitalizing the community to increase office/commercial space for job creation is overlooking the most obvious concern – education. The current proposal identifies a specific area at the Broadway Junction location to be developed for commercial use. The East New York Community has a varied number of commercial strips and one of the largest strip malls in the city with Gateway Center; however, the available employment does not provide the kind of wages that match the cost of living in our borough. Additionally, the EDC has proposed to have HRA as the Anchor tenant in the space at Broadway Junction – and this is redundant as HRA has an existing multiservice center in CB5, at 404 Pine Street; which provides SNAP, Medicaid, and more. Request: Create the plan that includes a CUNY facility in the space at Broadway Junction. The community has outlined that the need for higher education in the district, is an absolute necessity to prepare our young people for long-lasting career opportunities – not minimum wage positions. Economic growth in a community is not centered on the growth of business but the growth of economic empowerment of the residents who will patronize existing and future businesses.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
2/21
HPD
Provide more
Create greater incentives for developers to
housing for special
include senior housing in larger development
needs households,
sites, where there are multiple phases and/or
such as the formerly
buildings. The increase of senior homelessness is
homeless
a true crisis happening within CB5. More seniors
are reportedly residing in local shelter facilities
due to the inability to maintain rent expenses.
4/21
EDC
Make infrastructure
Allocate funding to expand the LINK NYC
investments that
program in areas where other recognized
will support growth
commercial strips exist: a. Pennsylvania Avenue
in local business
(from Atlantic Avenue to Flatlands Avenue) b.
districts
Sutter Avenue (from Pennsylvania Avenue to
Van Sinderen) c. New Lots Avenue (from Ashford
Street to Van Sinderen) d. Liberty Avenue (from
Drew Street to Crescent Street)
5/21
EDC
Make infrastructure
Include in the Anchor Tenant Strategy plan for
investments that
Broadway Junction a CUNY facility instead of
will support growth
the proposed HRA facility. To include HRA in this
in local business
new structure would be redundant and the
districts
community's voice would be ignored. The
community has outlined that the need for
higher education in the district, is an absolute
necessity to prepare our young people for long-
lasting career opportunities not minimum wage
positions. Economic growth in a community is
not centered on the growth of business but the
growth of economic empowerment of the
residents who will patronize existing and future
businesses.
8/21
HPD
Provide more
Increase incentives for developers with
housing for
proposed housing projects to include more
extremely low and
studio and 1br units in their proposals for
low income
returning citizens of the district - i.e. college
households
graduates; formerly incarcerated; single adults
and young couples. These units should still fall
within the income caps that exist in the CB5 to
avoid gentrification.
14/21 NYCHA Renovate or
upgrade public housing developments
Increase frequency of grounds cleaning and interior cleaning for all NYCHA developments in CB5. Currently there are developments that are not cleaned as frequently and the exterior grounds are not kept up. Grass is overgrowing and curbside bulk trash and regular trash is piled up along the streets; creating an environment that is infested with rodents and other infestations.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
9/20
DCP
Study land use and
Create a new study of the remaining vacant
zoning to better
land and other potential development sites in
match current use
CB5 and include the input of CB5 membership.
or future
Conduct a tour with CB5 leadership and
neighborhood
residents leadership to examine the current
needs
status of the East New York Urban Renewal Plan
and its impact on the landscape.
11/20
DCP
Study land use and
Coordinate with HPD for the Construction of a
Livonia
zoning to better
new Community Center on Livonia Avenue
Avenue
match current use
Corridor (corner of Williams Avenue) During the
Williams
or future
RFP process for development on the first phase
Avenue Van
neighborhood
of the Livonia Avenue Corridor, Dunn
Sinderen
needs
Development was selected as the developer for
Avenue
the housing project and the community was in
major support of the proposal submitted by
Dunn due to the collaboration with the Boys
Club of New York. A newly constructed Boys
Club was to be built on the fifth lot which would
have balanced the new housing units with
adequate community space for the existing and
incoming families and children. Since the
inception of the housing, the Boys Club has
backed out and the proposal still moved
forward with no community space to
accommodate the new population on the
corridor.
image
12/20
SBS
Other expense
Create greater incentives for developers to
commercial district
incorporate cooperative work spaces within
revitalization
mixed used development and other initiatives
requests
that would assist with securing local business
tenants. CB5 has large mixed-use development
that was created to encourage revitalized and
walkable commercial areas but rents are too
high for local businesses to take advantage of
the new spaces. Therefore commercial spaces
are left vacant for unnecessary lengths of time
with no activity.
13/20
SBS
Other business
Request that EDC implement mandate policy to
regulatory
inform Community Board office of any and all
assistance requests
new lease holders or business owners in the
Industrial Business Zones (Industrial Parks)
areas of the district. • EXPLANATION: Businesses
move in and out of the IBZs in CB5 and we are
not made aware of these business transactions.
Therefore we are not aware, and more
importantly, not included in the selection of
businesses coming into the IBZs. Within the last
couple of years we had to deal with the
expansion of the medical waste business that
wanted to expand their services to medical
waste storage and transfer. Additionally, when a
new business comes into the district, we want to
ensure that there is a local hiring process that is
implemented.
18/20
DOB
Address illegal
Increase amount of inspection workers for CB5
conversions and
to alleviate opportunities for squatters and
uses of buildings
illegal activity in vacant properties throughout
the district. The constituency complaint calls are
increasing regarding vacant property that is
being used for squatters and other criminal
activities. It creates an environment of fear for
neighboring residents.
19/20
DCP
Study land use and
Designate Brooklyn Community Board 5 as a
zoning to better
Cease and Desist zone to combat harassment to
match current use
seniors and all other existing homeowners in the
or future
district. Our district is under attack and we have
neighborhood
to protect our homeowner stock and monitor
needs
the potential intimidation tactics used towards
our senior homeowners from aggressive buyers
and real estate companies. Our district should
not be plagued with cheap signs about buying
homes and land - with promises of "all cash"
deals.
20/20 DCP Study land use and
zoning to better match current use or future neighborhood needs
Request to DCP to mandate that all large development housing projects , comprised of 60 or more units, include open community space. • EXPLANATION: Housing is not just about shelter, it must be comprehensive and provide full benefit to the community. Mandating open community space provides the opportunity to infuse cultural programming and creative spaces for young people and families.
image
TRANSPORTATION
Brooklyn Community Board 5
image
M ost Important Issue Related to Transportation and Mobility
Accessibility (ADA related compliance and infrastructure enhancements)
CB5 is ever changing in its infrastructure and landscape and there are a number of streets that have been ignored in the process. We want to ensure that all of our residents with ADA needs are being heard. It is imperative that all streets, walkways, corners, plazas, etc. are studied to ensure that ADA compliance has been implemented. Also, Freight routes for commercial vehicles has to be updated to ensure that all new streets, and commercial strip areas are included. Certain portions of our industrial business zones have been provided with zoning variances which now allows for more residential use and the existing routes have to include that as well to ensure that residents' homes are not damaged due to heavy vehicle traffic
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Transportation needs in the district vary depending on the section of the community in question. However, there is a need to conduct surveys to determine the feasibility of speed humps, in particular near schools, day care facilities, and playgrounds. Additionally, safety improvements must include greater community feedback and input. Surveys should be comprehensive and provide residents with an opportunity to give input on paper as well as on-line.
Conduct additional surveys at Loring Avenue, Drew, Emerald, and Fountain Avenue - to review the safety measures that were implemented and how they have negatively or positively impacted the flow of traffic for businesses and residents. a. New Bike Lanes on Loring Avenue between Eldert Lane and Emerald Street are counterproductive to successful traffic flow. They should be removed on that strip. b. Signage on Drew Street between Loring Avenue and Linden Boulevard to address the commercial (large trailers vehicles) trucks parking for extended periods of time. It obstructs vision and creates unsafe walkways, and takes away from potential residential parking c. Complaints still exist for the one-way conversion of Fountain Avenue and Loring Avenue – study to be done to revert back to two- way traffic and identify other ways to address safety measures at the intersection of Euclid Avenue, Fountain Avenue, and Loring Avenue
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
18/21
DOT
Other capital traffic
Install lighting at the intersection of Glenmore
Glenmore
improvements
and Schenck Avenues • EXPLANATION:
Avenue
requests
Glenmore Avenue near Schenck is poorly lit and
Schenck
creates a safety hazard for pedestrian and
Avenue
vehicular traffic
19/21
DOT
Improve traffic and
Install turning signal at the intersection of
Erskine Street
pedestrian safety,
Erskine Avenue and Seaview Avenue (leading
Seaview
including traffic
onto the Belt Parkway West) • EXPLANATION:
Avenue
calming (Capital)
Currently there is no direction for traffic
entering the Belt Parkway from Seaview
Avenue. South and north bound traffic is left
with no traffic signals to direct right of way
which is potential danger.
20/21
DOT
Repair or construct
Complete and expedite the installation of curb
new curbs or
cuts / pedestrian ramps to allow for full
pedestrian ramps
sidewalk access for ADA residents in the district.
EXPLANATION: Previous submissions have
been made for specific areas in CB5 for ADA
compliant curb cuts in the district.
21/21
DOT
Roadway
Re-surfacing along Riverdale Avenue from Miller
Riverdale
maintenance (i.e.
Avenue to Pennsylvania Avenue
Avenue Miller
pothole repair,
Avenue
resurfacing, trench
Pennsylvania
restoration, etc.)
Avenue
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/20
DOT
Add street signage
Install Commercial Vehicle or Freight Traffic
Elton Street
or wayfinding
signage in the Spring Creek area of the district
Vandalia
elements
on Erskine and Vandalia, Elton and Vandalia,
Avenue
and Elton and Flatlands. Currently cars, medians
Erskine
and property are being damaged due to freight
deliveries to the Gateway Center Mall. The area
needs to be included in the Smart Truck Freight
Management Plan with NYC Dept. of
Transportation.
6/20
DOT
Conduct traffic or parking studies
Request for DOT to conduct a post- implementation study on the following implemented safety projects and include neighboring residents near both street segments: Fountain Avenue (between Pitkin Avenue & Seaview Avenue) Loring Avenue (between Fountain Avenue & Drew Street)
14/20
DOT
Improve traffic and pedestrian safety, including traffic calming (Expense)
Install traffic controls at the intersection of New Lots Avenue and Van Siclen Avenue for turning traffic. • EXPLANATION: Currently the intersection supports traffic entering from New Lots, Van Siclen and also bus lines (B15 and B83) which causes confusion for turning traffic.
New Lots Avenue Van Siclen Avenue
15/20
NYCTA
Expand bus service frequency or hours of operation
Implement more frequent bus times for B84 bus line and extend routes to accommodate the new population along Elton Street corridor.
Additionally to accommodate students and faculty at the Spring Creek Community High School.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 5
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
The neighborhoods within Brooklyn Community Board 5 are continuing to grow with large development projects that cater to 2, 3, and even 4 bedroom units. This results in an increase in the population of children and families, yet the inclusion of adequate community space to accommodate this population is scarce. We are requesting the construction of a new Community Center on the Livonia Avenue Corridor. (corner of Williams Avenue) • EXPLANATION: During the RFP process for development on the first phase of the Livonia Avenue Corridor, Dunn Development was selected by HPD as the developer; and the community was in support of the proposal submitted by Dunn due to the collaboration with the Boys Club of New York. A newly constructed Boys Club was to be built on the fifth lot which would have balanced the new housing units with adequate community space for families and children. However, after the inception of the housing, the Boys Club backed out and the proposal still moved forward with no community space to accommodate the new population on the corridor.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
CB5 is very proud of the existing investments that we have in our parks and green spaces in the district. 2019 has been filled with various ribbon cuttings and ground breaking ceremonies on parks land projects. We recently learned that joint allocations from NYC Council Member Barron and NYS Assembly Barron totaled over $70 million in our district parks. This is a true investment in community and healthy livinig. However, we want to address that some projects still require a comittment from our Brooklyn Parks Department to ensure that the project is comprehensive. For example, the recent allocations to Lion's Pride Park and Success Gardens Playground does not include a comfort station in either park. The two parks encompass a large existing community and development projects that will bring in hundreds of new families.
Allocate capital funding to the renovations and upgrade of Breukelen Ball Field. Although the park is not in the CB5 district, it services the CB5 community predominantly and is home to one of CB5’s most respected and renowned youth athletic leagues – Latin Souls Youth Baseball League.
Needs for Cultural Services
CB5 needs a Cultural Center along with a Community Facility erected in our district that will be fully staffed.
Needs for Library Services
The New Lots Library in Community Board 5 is one of the cultural hubs of the community and has the support of the elected officials, block associations, and community based organizations for the renovation plans to develop the library and completely transform it into a research center and cultural library for the district. Spring Creek Library is one of the libraries in the district that is situated in one of the most densely populated neighborhoods. It is surrounded by Starrett City, Council Towers, Meadow Wood Gardens, Gateway Elton apartments and nearby NYCHA developments Penn Wortman, Linden Houses, and Boulevard Houses. However, the amount of book rotation and usage of the space is at bare minimum. We need to create incentives to bring more neighboring residents into the Spring Creek branch. An outreach plan must be implemented.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/21
DPR
Reconstruct or
Complete upgrade to Breukelen Ball Field with
upgrade a park or
emphasis on new Comfort Station and repair of
amenity (i.e.
drainage issues. Renovation plans to be
playground, outdoor
modeled after plans submitted to local elected
athletic field)
officials to bring Ballfields to full upgrade and
functionality for native youth league teams.
6/21
DCAS
Renovate, upgrade
Allow for Community Board 5 district office to
or provide new
obtain a ground floor commercial space in the
community board
district to allow for greater accessibility and
facilities and
presence in the district. The CB5 office has been
equipment
co-located in the HRA facility at 404 Pine Street
for over a year. In the facility, daily operations
are stifled due to HRA network compatibilities,
consistent issues with phone service, mail
delivery which directly impacts response for
time-sensitive materials, and overall
disconnection from constituency due to the
placement of the office, among other very
serious matters. We would like space in Livonia
Commons commercial site.
7/21
BPL
Provide more or
Cypress Hills Branch is in need of an HVAC
better equipment to
Upgrade
a library
9/21
BPL
Provide more or
Spring Creek Branch is in need of Safety &
better equipment to
Security Enhancements
a library
11/21
DPR
Reconstruct or
Renovate and upgrade the basketball courts at
upgrade a park or
Grace Playground. Existing funding is only
playground
allocated to the playground area of the park.
15/21
DPR
Reconstruct or
Allocate funding to transform larger park space
Loring
upgrade a park or
at Pink Playground to skate park and
Avenue,
playground
adult/senior exercise space • EXPLANATION:
Brooklyn,
Recent renovations were made to the
New York, NY
playground area but the larger area of the park
is still left barren and needs to be renovated to
better engage community members to fully
utilize the park.
16/21
DPR
Reconstruct or upgrade a parks facility
Secure funding for construction of comfort station at Lion’s Pride Playground • EXPLANATION: Funding has been allocated to renovate the upgrade the playground and adjacent site but a comfort station is still not included in the renovation.
Riverdale Avenue, Brooklyn, New York, NY
17/21
DPR
Reconstruct or upgrade a parks facility
Secure funding for the construction of a comfort station at Success Garden Playground • EXPLANATION: Success Gardens is the one park that will support the new families of the Livonia Commons, BRP development, as well as the residents on surrounding blocks. A comfort station would accommodate the growing population of children and families that will utilize the newly renovated space.
Livonia Avenue, Brooklyn, New York, NY
Expense Requests Related to Parks, Cultural and Other Community Facilities
The Community Board did not submit any Budget Requests in this category.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/21
DPR
Reconstruct or
Complete upgrade to Breukelen Ball Field with
upgrade a park or
emphasis on new Comfort Station and repair of
amenity (i.e.
drainage issues. Renovation plans to be
playground, outdoor
modeled after plans submitted to local elected
athletic field)
officials to bring Ballfields to full upgrade and
functionality for native youth league teams.
2/21
HPD
Provide more
Create greater incentives for developers to
housing for special
include senior housing in larger development
needs households,
sites, where there are multiple phases and/or
such as the formerly
buildings. The increase of senior homelessness is
homeless
a true crisis happening within CB5. More seniors
are reportedly residing in local shelter facilities
due to the inability to maintain rent expenses.
3/21
DYCD
Provide, expand, or
We are appealing to the NYC Department of
576 Blake
enhance
Youth and Community Development to include
Avenue
Cornerstone and
the necessary upgrades of the Boys & Girls
Beacon programs
Restrooms in Unity Plaza Community Center.
(all ages, including
Currently, the Cornerstone Program operating
young adults)
the center is Grand Street Settlement and they
are aligned with the request. There is an
existing capital project for specific renovations
of the center through NYC Council funding
allocations from CM Barron and former Speaker
Quinn. However, the funding will not allow for
the restrooms to be upgraded due to the detail
of the project. Again, we implore that DYCD
review its capital budget to understand the
importance of this funding to be combined with
the previous allocation for the center.
4/21
EDC
Make infrastructure
Allocate funding to expand the LINK NYC
investments that
program in areas where other recognized
will support growth
commercial strips exist: a. Pennsylvania Avenue
in local business
(from Atlantic Avenue to Flatlands Avenue) b.
districts
Sutter Avenue (from Pennsylvania Avenue to
Van Sinderen) c. New Lots Avenue (from Ashford
Street to Van Sinderen) d. Liberty Avenue (from
Drew Street to Crescent Street)
5/21
EDC
Make infrastructure
Include in the Anchor Tenant Strategy plan for
investments that
Broadway Junction a CUNY facility instead of
will support growth
the proposed HRA facility. To include HRA in this
in local business
new structure would be redundant and the
districts
community's voice would be ignored. The
community has outlined that the need for
higher education in the district, is an absolute
necessity to prepare our young people for long-
lasting career opportunities not minimum wage
positions. Economic growth in a community is
not centered on the growth of business but the
growth of economic empowerment of the
residents who will patronize existing and future
businesses.
6/21
DCAS
Renovate, upgrade
Allow for Community Board 5 district office to
or provide new
obtain a ground floor commercial space in the
community board
district to allow for greater accessibility and
facilities and
presence in the district. The CB5 office has been
equipment
co-located in the HRA facility at 404 Pine Street
for over a year. In the facility, daily operations
are stifled due to HRA network compatibilities,
consistent issues with phone service, mail
delivery which directly impacts response for
time-sensitive materials, and overall
disconnection from constituency due to the
placement of the office, among other very
serious matters. We would like space in Livonia
Commons commercial site.
7/21
BPL
Provide more or
Cypress Hills Branch is in need of an HVAC
better equipment to
Upgrade
a library
8/21
HPD
Provide more
Increase incentives for developers with
housing for
proposed housing projects to include more
extremely low and
studio and 1br units in their proposals for
low income
returning citizens of the district - i.e. college
households
graduates; formerly incarcerated; single adults
and young couples. These units should still fall
within the income caps that exist in the CB5 to
avoid gentrification.
9/21
BPL
Provide more or
Spring Creek Branch is in need of Safety &
better equipment to
Security Enhancements
a library
10/21
NYPD
Upgrade the
CB5 receives calls from local residents who
emergency response
complain about neighboring vacant properties
system
being vandalized or used for drug use and sale.
In some cases, although the Department of
Buildings borders the windows and doors with
locks, the property is still broken into and it
creates an atmosphere of crime and instills fear
in the residents. Once a property is deemed
vacant and DOB has bordered that property -
local NCO's or other assigned staff should be
monitoring it consistently to ensure that the
property remains secure and safety is at
optimum levels for neighbors.
11/21
DPR
Reconstruct or
Renovate and upgrade the basketball courts at
upgrade a park or
Grace Playground. Existing funding is only
playground
allocated to the playground area of the park.
12/21
SCA
Renovate interior
Complete renovation for gymnasium at Van
800 Van
building component
Siclen Community School at George Gershwin
Siclen
Campus (I.S. 166). The Gymnasium supports all
Avenue,
schools within the campus and is outdated. Full
Brooklyn,
renovation to floors, AC system, bleaches, and
New York, NY
student athletic equipment is needed to provide
full athletic programming.
13/21
SCA
Renovate other site
Renovations and upgrades for Moe Finklestein
12504
component
Athletic Complex or Thomas Jefferson Field -
Flatlands
including the bleaches, lockers, field, installation
Avenue
of score board, multi-purpose turf, and new
stationary equipment. The Thomas Jefferson
field is in serious need of upgrading. Currently
multiple home-grown youth football leagues
and cheer-leading squads utilize the field for
practices and games. Additionally, a local soccer
league has adopted the space for annual games
and tournaments.
14/21
NYCHA
Renovate or
Increase frequency of grounds cleaning and
upgrade public
interior cleaning for all NYCHA developments in
housing
CB5. Currently there are developments that are
developments
not cleaned as frequently and the exterior
grounds are not kept up. Grass is overgrowing
and curbside bulk trash and regular trash is
piled up along the streets; creating an
environment that is infested with rodents and
other infestations.
15/21
DPR
Reconstruct or
Allocate funding to transform larger park space
Loring
upgrade a park or
at Pink Playground to skate park and
Avenue,
playground
adult/senior exercise space • EXPLANATION:
Brooklyn,
Recent renovations were made to the
New York, NY
playground area but the larger area of the park
is still left barren and needs to be renovated to
better engage community members to fully
utilize the park.
16/21
DPR
Reconstruct or
Secure funding for construction of comfort
Riverdale
upgrade a parks
station at Lion’s Pride Playground •
Avenue,
facility
EXPLANATION: Funding has been allocated to
Brooklyn,
renovate the upgrade the playground and
New York, NY
adjacent site but a comfort station is still not
included in the renovation.
17/21
DPR
Reconstruct or
Secure funding for the construction of a comfort
Livonia
upgrade a parks
station at Success Garden Playground •
Avenue,
facility
EXPLANATION: Success Gardens is the one park
Brooklyn,
that will support the new families of the Livonia
New York, NY
Commons, BRP development, as well as the
residents on surrounding blocks. A comfort
station would accommodate the growing
population of children and families that will
utilize the newly renovated space.
18/21
DOT
Other capital traffic
Install lighting at the intersection of Glenmore
Glenmore
improvements
and Schenck Avenues • EXPLANATION:
Avenue
requests
Glenmore Avenue near Schenck is poorly lit and
Schenck
creates a safety hazard for pedestrian and
Avenue
vehicular traffic
19/21
DOT
Improve traffic and
Install turning signal at the intersection of
Erskine Street
pedestrian safety,
Erskine Avenue and Seaview Avenue (leading
Seaview
including traffic
onto the Belt Parkway West) • EXPLANATION:
Avenue
calming (Capital)
Currently there is no direction for traffic
entering the Belt Parkway from Seaview
Avenue. South and north bound traffic is left
with no traffic signals to direct right of way
which is potential danger.
20/21
DOT
Repair or construct
Complete and expedite the installation of curb
new curbs or
cuts / pedestrian ramps to allow for full
pedestrian ramps
sidewalk access for ADA residents in the district.
EXPLANATION: Previous submissions have
been made for specific areas in CB5 for ADA
compliant curb cuts in the district.
21/21 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Re-surfacing along Riverdale Avenue from Miller Avenue to Pennsylvania Avenue
Riverdale Avenue Miller Avenue Pennsylvania Avenue
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/20
DSNY
Provide more
Increase pick up frequency in NYCHA
frequent garbage or
developments in CB5 • EXPLANATION: Current
recycling pick-up
pick up schedule for NYCHA facilities creates
long-standing bulk trash along corridors and
streets within the district which increases pest
infestation and leads to greater potential for
historic health issues including asthma and
others.
2/20
DOE
Other educational
Provide permanent funding for arts/music
programs requests
programs in all middle schools in District 19.
Music programs must be restored and/or
implemented back into middle schools to
prepare students for Performing Arts high
schools. Funding should be focused on hiring of
certified/trained instructors to maintain music
programs during school hours.
3/20
DOT
Add street signage
Install Commercial Vehicle or Freight Traffic
Elton Street
or wayfinding
signage in the Spring Creek area of the district
Vandalia
elements
on Erskine and Vandalia, Elton and Vandalia,
Avenue
and Elton and Flatlands. Currently cars, medians
Erskine
and property are being damaged due to freight
deliveries to the Gateway Center Mall. The area
needs to be included in the Smart Truck Freight
Management Plan with NYC Dept. of
Transportation.
4/20
DOHMH
Other programs to
Funding to further the SHOP Healthy Brooklyn
address public
(NYC) program in CB5, to include zip code
health issues
11239. The original study completed in CB5 only
requests
included zip code 11207 and 11208. The results
of the program outlined the great need for
healthy food options in local groceries and
bodegas. The Epi Data Brief generated from the
initiative also showed that bodegas make up
51% of the food establishments in the 11207
areas of the district. Additionally, the brief
exposed that for every grocery store, there were
5 fast food restaurants and 10 bodegas. In
addition, during the Shop Health initiative,
grocery store and bodega owners were given
free marketing tools that promoted healthy
food and beverage purchases, as well as free
containers/baskets for fruit & vegetable
displays.
5/20
DOHMH
Promote Quit
Create bus station poster campaigns that
Smoking Programs
include messages and images from Truth.com
and/or tobaccofreekids.org. These campaigns
should be primary in places of public
transportation, in particular stations/stops
closest to school buildings in the district. CB5's
District Office team would like to participate in
the dissimenation and promotion of any
materials created through DOHMH to address
this very serious matter. It was stated in a
publication by tobaccofreekids.org, that lifetime
smoking and other tobacco use almost always
begins by the time children graduate from high
school. Help CB5 to create the kinds of
initiatives that prevent our children from long-
term illnesses.
6/20
DOT
Conduct traffic or
Request for DOT to conduct a post-
parking studies
implementation study on the following
implemented safety projects and include
neighboring residents near both street
segments: Fountain Avenue (between Pitkin
Avenue & Seaview Avenue) Loring Avenue
(between Fountain Avenue & Drew Street)
7/20
DFTA
Enhance programs
Create partnerships with local service agencies
for elder abuse
that directly support senior living - e.g. HRA, SS,
victims
SNAP, etc. to allow for on-site services in each
senior center to assist seniors with monthly
responsibilities and documentation submission
deadlines. Seniors are sometimes faced with
deadlines and monthly, quarterly, or annual
responsibilities that can be forgotten or
mismanaged. This is a way to ensure that they
have support in fulfilling requirements that
dictate the continuation of fixed incomes and
other subsidies that they may be receiving.
8/20
NYPD
Other NYPD staff
CB5 has the highest incidences of illegally
resources requests
parked vehicles and abandoned vehicles in the
city. Our numbers have risen due to the amount
of local auto shops and garages that park their
junk or for-sale vehicles on public streets; and
other abandoned vehicles that are randomly left
on public streets for years. We need a very
specific focus on this issue and an increase in
the officers that search for these incidences in
the district.
9/20
DCP
Study land use and
Create a new study of the remaining vacant
zoning to better
land and other potential development sites in
match current use
CB5 and include the input of CB5 membership.
or future
Conduct a tour with CB5 leadership and
neighborhood
residents leadership to examine the current
needs
status of the East New York Urban Renewal Plan
and its impact on the landscape.
10/20
DYCD
Provide, expand, or
Expedite renovations at Unity Plaza Community
576 Blake
enhance
Center $1.5 million was allocated to NYCHA
Avenue,
Cornerstone and
from former City Council Speaker Quinn and
Brooklyn,
Beacon programs
former Council Member Charles Barron to Unity
New York, NY
Plaza for necessary renovations within the
Community Center and outdoor spaces, close to
six (6) years ago. To date, renovations have not
been completed. Still pending is the mural in the
amphitheater and renovations within the
Community Center for restrooms, multi-purpose
room, studio to be installed in smaller room,
dance room, and other necessary upgrades to
ceilings, etc.
11/20
DCP
Study land use and
Coordinate with HPD for the Construction of a
Livonia
zoning to better
new Community Center on Livonia Avenue
Avenue
match current use
Corridor (corner of Williams Avenue) During the
Williams
or future
RFP process for development on the first phase
Avenue Van
neighborhood
of the Livonia Avenue Corridor, Dunn
Sinderen
needs
Development was selected as the developer for
Avenue
the housing project and the community was in
major support of the proposal submitted by
Dunn due to the collaboration with the Boys
Club of New York. A newly constructed Boys
Club was to be built on the fifth lot which would
have balanced the new housing units with
adequate community space for the existing and
incoming families and children. Since the
inception of the housing, the Boys Club has
backed out and the proposal still moved
forward with no community space to
accommodate the new population on the
corridor.
12/20
SBS
Other expense
Create greater incentives for developers to
commercial district
incorporate cooperative work spaces within
revitalization
mixed used development and other initiatives
requests
that would assist with securing local business
tenants. CB5 has large mixed-use development
that was created to encourage revitalized and
walkable commercial areas but rents are too
high for local businesses to take advantage of
the new spaces. Therefore commercial spaces
are left vacant for unnecessary lengths of time
with no activity.
13/20
SBS
Other business
Request that EDC implement mandate policy to
regulatory
inform Community Board office of any and all
assistance requests
new lease holders or business owners in the
Industrial Business Zones (Industrial Parks)
areas of the district. • EXPLANATION: Businesses
move in and out of the IBZs in CB5 and we are
not made aware of these business transactions.
Therefore we are not aware, and more
importantly, not included in the selection of
businesses coming into the IBZs. Within the last
couple of years we had to deal with the
expansion of the medical waste business that
wanted to expand their services to medical
waste storage and transfer. Additionally, when a
new business comes into the district, we want to
ensure that there is a local hiring process that is
implemented.
14/20
DOT
Improve traffic and
Install traffic controls at the intersection of New
New Lots
pedestrian safety,
Lots Avenue and Van Siclen Avenue for turning
Avenue Van
including traffic
traffic. • EXPLANATION: Currently the
Siclen Avenue
calming (Expense)
intersection supports traffic entering from New
Lots, Van Siclen and also bus lines (B15 and B83)
which causes confusion for turning traffic.
15/20
NYCTA
Expand bus service
Implement more frequent bus times for B84 bus
frequency or hours
line and extend routes to accommodate the new
of operation
population along Elton Street corridor.
Additionally to accommodate students and
faculty at the Spring Creek Community High
School.
16/20
DSNY
Other cleaning
Increase street cleaning and maintenance along
Pitkin Avenue
requests
Pitkin Avenue commercial areas (between
Hendrix
Hendrix Street and Wyona Street) •
Street Wyona
EXPLANATION: This small commercial strip is in
Street
need of consistent street cleaning and
encouragement of local stores to participate in
the adopt a basket program.
17/20
DSNY
Other enforcement requests
Increase frequency of street inspection to remove abandoned vehicles and illegally parked
vehicles. • EXPLANATION: CB5 has the highest
rate of 311 complaints for illegally parked and
abandoned vehicles. We need a collaborated
agency approach to address the issue.
18/20
DOB
Address illegal
Increase amount of inspection workers for CB5
conversions and
to alleviate opportunities for squatters and
uses of buildings
illegal activity in vacant properties throughout
the district. The constituency complaint calls are
increasing regarding vacant property that is
being used for squatters and other criminal
activities. It creates an environment of fear for
neighboring residents.
19/20
DCP
Study land use and
Designate Brooklyn Community Board 5 as a
zoning to better
Cease and Desist zone to combat harassment to
match current use
seniors and all other existing homeowners in the
or future
district. Our district is under attack and we have
neighborhood
to protect our homeowner stock and monitor
needs
the potential intimidation tactics used towards
our senior homeowners from aggressive buyers
and real estate companies. Our district should
not be plagued with cheap signs about buying
homes and land - with promises of "all cash"
deals.
20/20
DCP
Study land use and
Request to DCP to mandate that all large
zoning to better
development housing projects , comprised of 60
match current use
or more units, include open community space. •
or future
EXPLANATION: Housing is not just about shelter,
neighborhood
it must be comprehensive and provide full
needs
benefit to the community. Mandating open
community space provides the opportunity to
infuse cultural programming and creative
spaces for young people and families.

