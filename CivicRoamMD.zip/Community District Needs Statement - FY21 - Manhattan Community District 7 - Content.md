- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 7 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1dxTHY_wED95cTRV42wu29jxX4uy9CmNu/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1dxTHY_wED95cTRV42wu29jxX4uy9CmNu/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
7
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 7
image
Address: 250 West 87th Street, 2nd Floor Phone: (212) 362-4008
Email: office@cb7.org
Website: www.nyc.gov/manhattancb7
Chair: Mark Diller District Manager: Penelope Ryan
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
1.0 Geography and Demographics Manhattan Community District 7 encompasses Manhattan’s Upper West Side, from 59th Street to 110th Street, Central Park West to the Hudson River, and includes approximately 1.9 square miles (1,222 acres) of prime New York City real estate. According to Census data, which may undercount certain demographic groups among our neighbors, our District is home to 211,073 people, supporting approximately 50% more people per acre than the average for Manhattan, and four times more people per acre than the average for New York City. In addition to the residents who live in District 7, the Upper West Side attracts millions of visitors each year who come to enjoy its cultural institutions, parks, retail offerings, and architectural diversity. Central Park, the American Museum of Natural History, Lincoln Center, Time Warner Center, New-York Historical Society, and Riverside Park are popular destinations. 1.1 Population Density Although population has remained fairly stable over four decades, the geographic distribution of residents has shifted. According to Census tract data, approximately 6% fewer people live in the central part of the district (74th St. to 96th St.), while new development in the southern and northern ends of the district has attracted enough new residents to counter-balance that loss. Reliance on census data carries with it concerns relating to populations traditionally under-counted, which in turn are historically those at the lower end of the socio-economic spectrum, and which correlate with the perceived areas of population claimed to have been lost in the last decennial census. The undercounted populations are a particular concern because the inability to count them can result in a loss of services that are already scarce in a District that is perceived as affluent and where it is already a challenge to demonstrate need. Almost half (49%) of the occupied units in the district are one-person households. Total Population (Per Census Data) 1980 206,671 1990 210,993 (+2.1%) 2000 207,699 (-1.6%) 2010 211,073 (+1.6% 1.2 Population Distribution Although population has increased a modest 1.6% over the past decade, notable shifts occurred in the socioeconomic mix of the neighborhood. The decade saw an increase in the proportion of Caucasian residents (66% to 75%) and Asian residents (5.5% to 6.9%), while the proportion of Black residents decreased (9% to 6%) and Latino residents dropped (17% to 11%). Similarly, there was a significant shift in age distribution. Overall, adults of working ages 20-64 decreased by 6%, while children under 20 increased by 10%, and seniors over 65 increased a whopping 27% since 2000. In fact, Community District 7 has the second highest concentration of residents over 65 in all of New York City. By far the most significant demographic shift occurred in the area of household income. Over the past decade, New York City has seen: • The largest income gap in the US -- top 20% earn $371,754, bottom 20% earn $8,844. • A 52% increase in homelessness from 31,000 to over 54,600. • An increase in the poverty rate from 18% in 2007 to 21% in 2012. In Community District 7, growth in the income gap is even more pronounced, with the proportion of top earning residents nearly doubling over the past decade. In 2012, median household income was estimated at $99,000 for the Upper West Side, $68,000 for Manhattan, $52,000 for New York City, and $58,000 for New York State. However, despite a marked increase in average income, most residents would also confirm observable differences in income disparity, homelessness, and growing pockets of poverty. 2.0 Countervailing Trends: Rapid Development and Growing Pockets of Need Since the 1980’s, the Upper West Side has seen tremendous economic growth and development. Several factors, including easy access to transit (Subways 1,2,3,A,B,C,D and multiple bus lines), proximity to parks (Central Park and Riverside Park among others), strong public schools, and engaging street life make the district especially attractive to families, seniors, and people who want a short commute to Manhattan’s business centers downtown. After the recovery from the economic downturn of 2008 fueled by scandals involving mortgage-backed securities and other real estate practices, the trend toward aggressive development in the District resumed. Given the scarcity of vacant lots, much of this development involved replacing low-density buildings (often referred to as “soft sites”) with new construction that is built to the maximum density permitted by existing zoning, many consisting of luxury residential or mixed-use towers. Townhouses that were long ago divided into multiple units were (and continue to be) consolidated into single-family homes. Vacant lots (what few remained) were purchased and developed into large-scale, mixed-use complexes. Plans were approved in December 2010 to develop the last significant open lot in the district (at 59th and 11th Avenue) into Riverside Center, a 3 Million SF mixed-use complex with 2,500 residential units, commercial storefronts at the ground floor, landscaped open space, and a 100K SF school, which complex when fully occupied will increase district population by approximately 3-4% (not reflected in this report). The first two of the five buildings approved for development are now well on their way
to being occupied, and the remaining three are nearing completion. Those buildings are a block away from two additional new large-scale luxury residential towers on Fordham’s Lincoln Center campus that are now fully occupied, as well as many other family-friendly new residential construction projects in the vicinity. The construction boom continues unabated in the district. Two different developers are currently proceeding with proposals to build a residential towers that will exceed 660 feet in height on the former site of the Lincoln Square Synagogue at 200 Amsterdam Avenue and 775 feet on the former Guild for the Blind site on West 66th Street, although there are on-going disputes about each project (discussed in detail in the Land Use section below). There is no reason to believe that this trend will subside in the foreseeable future. In certain areas, the average price per square foot increased from $300/SF in 1990 to more than $1000/SF in 2015. Despite rapid development and related improvements, many areas throughout the district continue to languish. So called “pockets of poverty” make up at least 10% of the population and experience unemployment rates over 10%, high school graduation rates under 10%, high instances of obesity, diabetes, and other health problems, and a disproportionate rate of crime (10% vs. 25%). Historically, certain City support services for the economically disadvantaged have overlooked pockets of poverty surrounded by affluence, making the experience of this segment of our population all the more heartbreaking as well as increasingly difficult to serve. Recent efforts to more equitably allocate City support services are gaining traction, particularly in support services to infants, children and youth, and constant oversight and vigilance is needed to ensure that these gains are not rescinded in subsequent years' budgets.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 7
image
The three most pressing issues facing this Community Board are:
Affordable housing
Economic diversity is a value greatly appreciated by MCB7, but the Upper West Side is rapidly becoming an area characterized by high inequality and one that is closed off to low and middle-income renters. The great disparity between the many high-income families who dwell on the Upper West Side with a 2017 median household income of $126,257 and the 20% of households that are severely rent-burdened (spend more than 50% of household income on rent) is a gap that is widening. The Income Diversity Ratio (income earned by 80th percentile divided by income earned by 20th percentile) has risen to 9.2, the fourth highest in the city. A major contributor to this disparity is the lack of affordable housing. Affordable housing increases opportunities for long-time residents to remain in their community, as well as new residents, especially younger ones, to find homes in the community. The home ownership rate (co-ops, condos, and single-family houses) has risen from 29.2% in 2000 to 40.2% in 2017 while the number of rentals has declined in the same time span. MCB7 has identified the most prevalent categories of affordable housing in the community district and has identified needs and recommendations, based on these types. • Mitchell Lama Preservation – Many Mitchell-Lama buildings in MCB7 have already or will soon reach the end of their regulatory periods. This means the buildings no longer legally must be kept at affordable rents, and many have already opted to go market-rate. There are 11 Mitchell-Lama developments in MCB7 with 1,749 units and, on average, the buildings are almost 60 years old. • District Need: HPD has announced a Mitchell-Lama Reinvestment program as part of Housing NY 2.0. As this Community District is a high-rent area, Mitchell-Lama units in our community should be prioritized for preservation whenever it is indicated that they are vulnerable to going market-rate. We urge the NYS Division of Housing and Community Renewal (HCR) to place all Mitchell-Lama building under rent stabilization guidelines without regard to their date of construction if they are removed from the Mitchell-Lama program. HPD and/or HCR should aim for the longest possible regulatory period for these properties, to ensure that they remain in MCB7’s affordable housing stock and provide moderate- and middle- income housing for our community. • Housing Development Finance Corporations (HDFC) Cooperatives - These shareholder-owned HDFC cooperatives, which benefit from reduced real estate taxes in exchange for following certain standards for the selling and renting of apartments, are an important source of affordable homeownership for MCB7. Unfortunately, mismanagement of these HDFC coops has resulted in many being in a condition of insolvency and in disrepair. • District Need: HPD should assist mismanaged HDFCs by providing financial management training. Required quarterly check-ins to oversee building finances should be instituted. No monitor or manager should be required in HDFCs that are currently financially healthy and do not have extensive capital needs. HPD should work with the HDFCs to extend affordability and the tax abatement for all existing HDFCs. HPD should provide subsidies to replenish the HDFC reserves, if needed, and pay for capital improvements, provided certain terms set by HPD to ensure future solvency are followed. • Rent-regulated housing • Rent stabilized housing MCB7 welcomes recent legislation in Albany that eliminated the vacancy bonus, ‘luxury’ decontrol, preferential rents, income caps, and the four-year ‘look-back’ period. Restrictions were placed on the amount of major capital improvements (MCI) and individual apartment improvements (IAI) that can be passed to tenants and the time period of such charges. Various tenant harassment and eviction practices that had been utilized against all renters were also eliminated. MCB7 has long called for an end to these practices and thanks the legislators who worked so hard to end them. • Preservation – Speculation has been a problem in the Upper West Side for decades and is now affecting tenants at the northern boundary (Manhattan Valley) of the CD who are seeing their buildings that contain many rent-stabilized units purchased for exorbitant prices, with the assumption that the new owner will be able to increase the rent rolls. With the recent rent law changes, we are concerned about speculators defaulting on mortgages and allowing buildings to fall into disrepair. • District Need: HPD’s Neighborhood Pillars program should provide financial and technical assistance to nonprofit developers to purchase and renovate buildings in Manhattan Valley. HPD should institute long-term Regulatory Agreements to keep rent-stabilized units affordable • Reclaiming Rent-Stabilized Units – Because rent stabilization depends on self-reporting of landlords to the Division of Homes and Community Renewal, some units have been priced higher than their legal rent or have not been re-registered after temporary destabilization. Tenants have unknowingly rented these apartments and paid illegally high rents.
Many apartments were deregulated and became market-rate housing. New legislation has ended the four-year ‘look-back’ period to claim redress for overcharges. However, although overcharges may be found, reimbursement can only be made for the preceding six years. • District Need: The City should work with lawmakers in Albany to ensure that reimbursement for overcharges must be made for the entire period of those overcharges and re- stabilize the affected apartments. • Senior Housing: One-fifth (20.1%) of the 2017 population of MCB7 is aged 65 or older, an increase from 16.7% in 2010. The percentage of seniors in Manhattan is 16%; 12.4% in New York City. They need appropriate housing and social services that enable them to continue age in place in the communities where they have spent their adult lives. • District Need: The NYS Department for the Aging funds Naturally Occurring Retirement Communities (NORCs), where health and social services are provided in buildings with a substantial population of seniors. The City should work with DFTA to actively promote and fund more NORCs for our growing senior residents. ⦁ District Need: Encourage the inclusion of compact units appropriately outfitted with safety devices, such as grab bars and bannisters, in the affordable housing components in the new residential buildings currently under construction in the District. These are separate from micro-units as seniors may need daily or live-in home help. • District Need: In 2017, 11.7% of households in the CD where at least one person was more than 65 years of age lived below the poverty line. Thousands of seniors and residents eligible for the Senior Citizen Rent Increase Exemption (SCRIE) and the Disability Rent Increase Exemption (DRIE) are not currently enrolled in those programs, and therefore may be paying more rent than necessary, despite their limited income. HPD should enhance community outreach to senior centers and non-profit organizations to provide more information, including informational sessions, to ensure that every qualifying resident is getting the proper rent increase exemptions. • SROs: MCB7 is home to more than 200 single room occupancy (SRO) buildings with 13,364 dwelling units. These units continue to be the most affordable options for young singles, older veterans, the chronically ill, the formerly homeless and low-income individuals. Economic opportunity has motivated many SRO owners to convert their buildings (often contrary to zoning and housing regulations) from affordable permanent dwellings into transient hotels and/or Air BNBs, thereby removing affordable SRO units from the rental market. • District Need: Existing SROs should be rent regulated through preservation financing and regulatory agreements to ensure they are properly maintained and rented as permanent affordable housing. HPD should work with qualified nonprofits and joint venture partnerships of nonprofit and for-profit entities to purchase and rehabilitate these SROs. Additionally, when feasible, the SROs should be converted into supportive housing to serve the most vulnerable in our City. ⦁ Find New Opportunities for Affordable Housing Development: Although the number of new, very tall residential towers is rising in the southern end of the district, almost all are as-of-right – through a series of zoning lot mergers and transfer of development rights (TDR) – and therefore are not required to provide affordable housinAffordable Housing. Over the past three decades, escalating real estate prices have driven up the cost of living throughout the district. Low and middle income residents struggle to stay in their homes as more affluent families increase the demand for luxury and market rate apartments. The pernicious effects of various measures such as vacancy decontrol and luxury decontrol eliminate apartments from rent regulation with little recourse to tenants. The District is losing affordable housing at a rate far faster than any new affordable housing can be built, converted or preserved. Seniors with fixed incomes are especially vulnerable to losing their homes or to being forced out by the cumulative cost of living. Furthermore, as new developments and apartment consolidations replace low and
middle-income housing, the economic diversity of the neighborhood declines. The conditions experienced by residents of New York City Housing Authority (NYCHA), and the prospects for equitable remediation of the consequences of decades of deferred maintenance and dis-investment, are equally devastating to the supply of affordable housing. New and renewed sources of funding, together with streamlined and efficient management at every level of the operations of NYCHA campuses and facilities, is desperately needed to begin to address the needs of some of our most vulnerable neighbors.
Schools
Middle School Responses to Diversity Initiatives: As noted below, Community School District 3 (which comprises all of Community Board District 7 and a portion of Southern Harlem) (“CSD3”) has adopted set-asides for students meeting certain poverty and achievement criteria as part of the Middle School Choice process. These changes require additional supports, including dedicated social-emotional learning support for all students, enhanced enrichment support for certain students, and remedial supports for certain students, to ensure that all middle school students will have enhanced experiences as a result of the new admissions process. Additional Social Workers: The FY 2020 budget included funds for an additional 285 social workers (Citywide). It is essential that (a) the funds for these additional social workers be baselined so that the continuity of expert services provided by
these professionals is not left to a year-to-year budget negotiation, (b) that these social workers include in their professional services an emphasis on restorative justice to meet the growing needs of the students, especially our most vulnerable students, and (c) that these social workers are programmed and deployed to render the services for which they are trained and certified, and not used (except in rare emergencies) as supervisory staff for tasks such as recess and lunch monitoring. Parent Coordinators: Parent Coordinators have a vital role as effective liaisons between school administrations and parents. In many cases, effective Parent Coordinators are the most vital link to encouraging parent engagement in their children’s education. To fulfill this important role, it is critical that Parent Coordinators, like Social Workers, be assigned to duties that correspond to their professional role in fostering and encouraging parent engagement and serving as liaisons to parents. Parent Coordinators should not (except in rare emergencies) be scheduled as supervisory staff for tasks such as recess and lunch monitoring. Equity in Parent Fundraising: Schools in CSD3 fall within a broad spectrum of fundraising, with certain schools able to raise significant sums both from among their parents and through other means, while other schools have limited ability and experience in raising funds to support the school. Bridging the gap in non-DoE funds requires consideration of implementing a minimum level of revenue sharing between the schools with the greatest and least capacity for fundraising, while preserving incentives to maximize all such supports. Summer Youth Employment Program – Modifications to the Existing Programs: In connection with the SYEP initiatives noted below, the program requires adjustment in two key ways: First, additional funding is needed to include robust and meaningful training by the CBO partners of the youth employees in their charge, such as expanding the Work/Learn/Grow program. Next, SYEP should be extended to align with the summer programs that the youth employees are hired to support and supervise, for example to be coterminous with SONYC and Compass summer programs. Additional STEAM Opportunities: Other than the 8 Specialized High Schools, there are relatively few high schools in the system, and fewer still in Manhattan, that offer all of the Advanced Placement courses essential to students with ambitions in the sciences (i.e. AP Calculus AB and BC; AP Chemistry; AP Biology; and AP Physics), and fewer still that combine those offerings with accomplished offerings in the Arts. The number of high schools offering this enhanced STEAM curriculum is essential to any equity and diversity program, both for the students who aspire to but do not gain admission to the Specialized High Schools, and to those who seek a different high school experience and deserve an equal opportunity for this enhanced learning program. Elementary Schools Diversity and Inequity of Access and Resources CSD3 includes the Upper West Side section of Community District 7, and continues into the southern portion of Central Harlem. Taken as a whole, CSD3 is among the most diverse districts in the New York City public school system, whether measured by race, ethnicity, socio-economic status, student performance or other relevant measures. Yet few if any individual schools in CSD3 mirror that diversity. In addition, several schools in District 7 are situated in diverse catchment zones, but because of variation in the use of public schools, the school population does not reflect the diversity of the catchment zone. One of the direct results of the segregation of CSD3 schools is a wide and growing disparity in resources available among schools. This gulf in funding is a result of several factors, including (a) since funding follows enrollment, the schools with highest enrollment have greater funding; (b) Title I funding, which is intended to address the effects of poverty on student performance, is administered in the City of New York in a way that leaves many schools, including schools in CSD3 and District 7, with significant populations of low-income students but no corresponding funding; and (c) many of the schools in the southern portion of the District that enjoy relatively affluent parent bodies are able to raise significant funds to supplement the educational experiences in their schools at levels that other schools in District 7 cannot hope to achieve. The issue of disparate resources remains an elusive issue. The increase in enrollment in PS 191 and PS 452 due to the rezoning that took effect in 2017 to expand PS 191’s catchment, and the re-siting of PS 452 so that it can grow to three or four sections per grade (from its former two sections in grades 1-5) is providing additional resources to both schools. Systemic disparities remain, especially between under-enrolled schools in Central Harlem and schools below West 110th Street that do not have access to parent funding at a scale that the southernmost schools enjoy. The impact of disparate resources includes the inability of some schools to offer enrichment or remedial help as needed; the repurposing of dedicated space for art, science or music to classroom space; and the inability to offer afterschool programming which is essential for many working families.
Social services
Senior and Social Services. Our Upper West Side is graying. Several residential facilities have been recognized and enrolled as "NORCs" - naturally occurring retirement communities - and many more are the functional equivalent. In addition to the rent- and food-insecurity that befalls many of our seniors due to living on a fixed income in an affluent and challenging economic zone, the cumulative effects of aging in place often lead to needs not
experienced earlier in life. The challenges of aging are of course not limited to those on fixed or limited budgets, and many of our seniors who on paper are able to afford to retire where they made their homes nonetheless require new and different types of supports. It is thus critical that our district be home to social and mental health services that address the varied and complex needs experienced by our seniors who are aging in place. A NORC at Douglass Houses (where there are more than 1000 underserved seniors) is needed. Lack of health and household services and visitor contact contributes to the institutional placement of many seniors who otherwise would have been able to stay in their home. Extended In-Home Service to the Elderly Program, which provides homemaking for vulnerable homebound seniors not eligible for Medicaid, has seen drastic budget cut. The Adult Social Day Services Program, which provides therapeutic programs for seniors who are disabled (many with dementia) was eliminated. Funds for Elder Abuse Prevention Programs and Geriatric Mental Health Initiatives have not increased with the growing number of seniors. United Neighborhood house funding has remained stagnant. Volunteers and funds are needed to fill in many gaps. Affordability and access to healthy food: Overall, Community District 7 has five farmer’s markets and has a 1:3 ratio of supermarkets to bodegas (the lowest ratio in New York City). The percentage of Community District 7 residents who report eating at least one serving or more of fruits and vegetables is similar to citywide average. Approximately 1 in 10 children in grades k through 8 have obesity (citywide rate is 1 in 5). Access to healthy food is limited in low-income areas. Critically-placed grocery stores have closed and are closing, often due to luxury residential development, leaving food deserts for multiple blocks, a major issue for residents who are low- income, senior and/or disabled. Fresh produce is costly in Community District 7. Meal programs and food pantries face ongoing increases in costs of meals (due to labor and raw food costs) without a corresponding increase in government funds and donated food. In New York City, the majority of emergency food providers (54%) report running out of food. In Community District 7, Goddard’s two food pantries are at capacity and the waiting list recently grew for the food pantry located at Lincoln Square (in Amsterdam Houses and the Amsterdam Addition).
Attendance at senior meals in that development has also increased by about 10% in the past year. In addition to two food pantries, Goddard provides home delivered freshly made meals to over 500 seniors (7 days of meals delivered over 5 to 6 days a week). Goddard also feeds all children in their early childhood and youth programs. Goddard’s supportive housing provides meals and cooking facilities and their TOP clubhouse provides lunch prepared by members. Citymeals on Wheels delivers several hundred thousand meals to residents in Community District 7 each year. Food Bank for NYC delivers 1.5 million meals citywide, and to determine need, uses the Meal Gap (NYC’s official measure of food insecurity). The Meal Gap represents families’ and individuals’ missing meals that result from inadequate household food budgets. In Community District 7, the Meal Gap is 3.3 million meals. (Citywide, the Meal Gap is 208 million meals.) More than one in ten people in Community District 7 are food insecure. SNAP enrollment: In addition to the delivery of free meals, in Community District 7, over 16,000 people in 12,000 households rely on SNAP. Yet more people need SNAP than are participating. More outreach and assistance is needed for enrollment. Overall, meal providers request that the city provide a higher reimbursement rate for meals. More funding is needed to support programs that provide meals and assistance for enrollment in public benefits as well as efforts to address root causes of hunger and food insecurity. More public engagement and participation in the work of local organizations will also enable greater food security as many organizations rely on volunteers.
Medical services and benefits: In Community District 7 in 2016, 10% of residents reported not having access to needed medical care. In 2017, 5,322 residents were uninsured (2.6% of the total population compared to 7% citywide), with significantly higher rates of uninsured for people who are not citizens. Less than 1% (0.3%) of children are uninsured. In January of 2019, Mayor de Blasio announced NYC Care, a NYC Health + Hospitals initiative that will connect the uninsured with a primary care provider and support enrollment of those who are eligible for the public health system’s MetroPlus insurance plan. In Community District 7, more education and assistance with enrollment (in health insurance and public benefits) are needed. At St. Luke's and Mt. Sinai West, a "HEAL" office assists patients who do not have insurance in enrolling in insurance or Medicaid; and offers payment plans for services according to Medicare rates. The Ryan Center charges patients based upon their income. More financial counseling and legal assistance is needed when people are unable to pay medical bills (e.g., reports to collections, litigation). In addition, more information and access to comprehensive and preventative care is needed for patients who are low-income (such as infant nutrition and support for pregnant mothers). 9% of residents have incomes below the NYC government poverty threshold. Health care access for children and youth, especially those considered “disconnected”: 11% of youth aged 16 to 24 in Community District 7 are considered “disconnected,” meaning that they are not in school or working. More efforts should be made to address any mental or physical health related needs that interfere with their ability to participate in school and work. Mental health services and support: THRIVE offers Mental Health First Aid. More outreach is needed to encourage police officers and workers in
shelters, supportive housing, organizations, and schools to learn mental health first aid. More research is needed to determine needs and availability of mental health services for youth, including suicide risk assessment and prevention. According to the Centers for Disease Control and Preventon, intentional self-harm (suicide) is one of the leading causes of death for children aged 5-14 years. More funding is needed for mental health services in jails and for justice-involved youth transitioning from jails. Homelessness and supportive housing The homeless population continues to increase citywide (at close to 80,000, 5% of which are living on streets) and in Community District 7.
The lack of funds for supportive services for those living with mental health issues, addiction and other health problems, increases the risk that people with these problems will become homeless. Section 8 vouchers are difficult to procure and create a need for nonprofit organizations to seek alternative sources of funds to cover over 60% of tenants’ rent. The Human Resources Administration has described the following as priorities: anti-eviction and legal services, supportive housing, access to benefits through ACCESS HRA, and access to housing benefits and support for people with HIV. New York City and State needs to fund more supportive housing, especially permanent supportive housing, with long term funding for support services. Supportive housing is by far the most successful way to end homelessness for individuals and families, especially those living with physical and mental disabilities and other challenges. Providing housing first gets people back on their feet and allows them to pull their lives together more quickly. Research has shown a 50% decrease in alcoholism when people who are homeless are housed. However, there is not nearly enough supply to meet the record need. In addition, more housing is needed specifically for victims of domestic violence, including for people who identify as transgender or gender nonconforming. Seniors Violence Domestic and gender-based violence: Domestic violence includes family and intimate partner violence, sexual violence, stalking, and trafficking. According to the Centers for Disease Control and Prevention, approximately 1 in 4 people who identify as female and 1 in 10 people who identify as male have experienced intimate partner violence, including sexual violence, physical violence, and/or stalking. Homicide is one of the leading causes of death for children aged 1-4 in the United States. More funding is needed to support education, intervention, and recovery programs that address domestic and gender based violence and its impacts. The Mayor's Office to End Domestic and Gender-Based Violence recently opened a Learning Lab at the NYC Family Justice Center in Manhattan to provide economic empowerment programming for people who have experienced gender-based violence. And as referenced above, more housing is needed specifically for victims of domestic violence, including for people who identify as transgender or gender nonconforming.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 7
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
Community District 7 is home to an increasing number of senior citizens and to Naturally Occurring Retirement Communities (NORCs) which receive funds targeted for aging populations. A NORC at Douglass Houses (where there are more than 1000 underserved seniors) is needed. Lack of health and household services and visitor contact contributes to the institutional placement of many seniors who otherwise would have been able to stay in their home. Extended In-Home Service to the Elderly Program, which provides homemaking for vulnerable homebound seniors not eligible for Medicaid, has seen drastic budget cut. The Adult Social Day Services Program, which provides therapeutic programs for seniors who are disabled (many with dementia) was eliminated. Funds for Elder Abuse Prevention Programs and Geriatric Mental Health Initiatives have not increased with the growing number of seniors. United Neighborhood house funding has remained stagnant. Volunteers and funds are needed to fill in many gaps.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities Accessibility
Universal access to schools, transportation, and public space is a challenge in Community District 7.
S idewalks: Numerous curb cuts and sidewalks across the district require repair and are currently either dangerous or fully inaccessible for residents with disabilities. Research is needed to determine which sidewalk cuts need repairs in Community District 7.
T raffic lights and crosswalks for pedestrians: Traffic lights should reflect the pace at which seniors, children, and people who are disabled are able to move across wide streets. Sound should also be used to communicate signals to people with visual impairments.
P ublic transportation: Every subway station should be accessible and the planning process should include community input. Transit has surveyed and rated most subway stations citywide and found that most of these can be made accessible. There are approximately 30 stations in New York City that will soon begin the process of becoming accessible. In 2020, stations in Community District 7 may begin to undergo renovations to full accessibility.
P ublic buildings, playgrounds, and schools*: All public buildings should be fully accessible, especially schools, and information about accessibility should be available to the public. The Department of Education’s (DoE) website lists accessible schools, but it does not indicate degrees of accessibility (e.g., whether students and staff with physical challenges will be able to enter the front door, go to the main office or use the bathroom). The DoE should publish more specific information on its website. The DoE should also provide training on accessibility for teachers, children, and families. Accessibility includes a wide range of accommodations and this includes students enrolled in IP.S. M811 - Mickey Mantle School, a District 75 school. In addition, to whatever degree possible, renovations to playgrounds should meet standards for full accessibility and inclusion according to the goals of Universal Design.
Finally, NYCHA playground inspections, maintenance, and renovations should meet the same standards for safety, accessibility, and inclusion as DoE and DPR playgrounds.
Please also see the Youth, Education, and Libraries section.
Health care access and quality
M edical services and benefits: In Community District 7 in 2016, 10% of residents reported not having access to
needed medical care. In 2017, 5,322 residents were uninsured (2.6% of the total population compared to 7% citywide), with significantly higher rates of uninsured for people who are not citizens. Less than 1% (0.3%) of children are uninsured. In January of 2019, Mayor de Blasio announced NYC Care, a NYC Health + Hospitals initiative that will connect the uninsured with a primary care provider and support enrollment of those who are eligible for the public health system’s MetroPlus insurance plan.
In Community District 7, more education and assistance with enrollment (in health insurance and public benefits) are needed. At St. Luke's and Mt. Sinai West, a "HEAL" office assists patients who do not have insurance in enrolling in insurance or Medicaid; and offers payment plans for services according to Medicare rates. The Ryan Center charges patients based upon their income.
More financial counseling and legal assistance is needed when people are unable to pay medical bills (e.g., reports to collections, litigation).
In addition, more information and access to comprehensive and preventative care is needed for patients who are low-income (such as infant nutrition and support for pregnant mothers). 9% of residents have incomes below the NYC government poverty threshold.
L ead poisoning prevention and remediation: Most children in New York City are tested for lead poisoning by the time they turn three years old (in 2017, 80%). In recent years, numbers of children with high blood lead levels have decreased across populations and areas, yet the burden is highest for children of color and children living in high poverty neighborhoods.
When children test positive for lead poisoning (with levels greater than or equal to 15 mcg/dL), Local Law 1 of 2004 requires DOHMH to conduct environmental investigations, which include inspections, risk assessments, and care coordination with health care providers. In 2019, Mayor de Blasio launched LeadFreeNYC to eliminate child lead exposure by 2029.
Community District 7 has high numbers of children testing for lead poisoning and testing positive. But research suggests that these tests may be unreliable (e.g., the false positive rate is estimated at 70%) and results need to be interpreted by medical professionals on a case by case basis (and according to reported symptoms). Doctors’ input should inform whether and how to respond and remediate. In addition, remediation may cause harm (such as paint removal that causes disturbance). Remediation procedures should also be based on building conditions. More accurate and thorough testing, interpretation of results, and remediation may be needed to determine if children actually have lead poisoning and avoid causing unnecessary harm to children and their environments. In addition, the Department of Health and Mental Hygiene should collect and report more information to the public and MCB7, including any initial positive test, any retest results, and results six months later; as well as findings of investigations. DOHMH should report more data so Manhattan Community District 7 can review any unintended consequences of testing and investigations, including unfair distribution of resources.
image
H ealth care access for children and youth, especially those considered “disconnected”: 11% of youth aged 16 to 24 in Community District 7 are considered “disconnected,” meaning that they are not in school or working. More efforts should be made to address any mental or physical health related needs that interfere with their ability to participate in school and work.
N ursing staff in DoE schools: All pre-k through 12 public schools should have full time nursing staff available for children and youth; and every school in Community District 3 is required to have a nurse available on site every day. There is currently a shortage, so some schools have nurses who report inconsistently and others have no nurses at all.
V ision screening and care for children and youth: There is a need for all students entering school in Community District 7 to have a comprehensive vision screening. Vision screening is a comprehensive eye exam that can facilitate diagnosis of visual problems. Vision screening, eye care, and free access to glasses should be available to all children. Good vision is key to a child’s physical development, success in school and overall well-being.
According to Prevent Blindness America (formerly known as the National Society to Prevent Blindness) one in four school-age children have vision problems that, if left untreated, can affect learning ability, psychological health, and adjustment in school. But if problems are detected early, it is usually possible to treat them effectively. In addition, research studies have shown that randomly supplying children with glasses significantly improves school performance because many children do not have needed glasses and therefore cannot fully participate in activities.
Upon entering early childhood programs, kindergarten or whenever a problem is suspected, children’s eyes should be screened for visual acuity and alignment by a pediatrician, family doctor, ophthalmologist, optometrist, orthoptist or person trained in vision assessment of school-aged children. Nearsightedness (myopia) is the most common refractive error in this age group and can be corrected with eyeglasses. If an alignment problem or other eye health issue is suspected, the child should have a comprehensive exam by an ophthalmologist.
Children and youth with medical conditions (e.g., Down syndrome, prematurity, juvenile idiopathic arthritis, neurofibromatosis) or a family history of amblyopia, strabismus, retinoblastoma, congenital cataracts or congenital glaucoma are at higher risk for developing pediatric eye problems. They should receive yearly vision screening evaluations.
E ducation and information about vaping (use of e cigarettes): E-cigarette use causes negative health impacts and more research is needed to understand those impacts as well as vulnerability to addiction. Vaping among children and youth continues to rise. And more education for the public (especially for youth in schools) is needed to prevent vaping and its negative impacts. NYC Smoke-Free works with schools in Community District 7 and may benefit from more support to have greater reach and impact.
In terms of rates of other forms of substance abuse, more information is needed. The binge drinking rate in Community District 7 is comparable to the citywide average.
image
P hysical health (access to recreational activities and public spaces): Community District 7 needs more spaces for youth, especially teenagers, to enjoy recreation and socialization outside of school. The Beacon program on West 93rd Street is not conveniently located for all youth. The district also needs more spaces and free activities for adults to promote fitness and physical health.
M ental health services and support: THRIVE offers Mental Health First Aid. More outreach is needed to encourage
police officers and workers in shelters, supportive housing, organizations, and schools to learn mental health first aid.
More research is needed to determine needs and availability of mental health services for youth, including suicide risk assessment and prevention. According to the Centers for Disease Control and Preventon, intentional self-harm (suicide) is one of the leading causes of death for children aged 5-14 years.
More funding is needed for mental health services in jails and for justice-involved youth transitioning from jails.
Quality of life
H oarding and pests: Hoarding is an issue for a subset of seniors and others in Community District 7. Landlords evict people because of hoarding. Mice, rats, bedbugs and roaches are rampant where there is hoarding and open garbage exacerbates infestations. (11% of households report cockroaches in Community District 7.) Emergency services are often blocked. Case managers require special training. Cross-sector and interagency collaborations are needed to address the problem.
R ats: Community District 7 has many buildings with signs of rats and failed inspections compared to other districts. In addition to current initiatives (such as expansion of rat-proof trash cans by the Department of Sanitation), new approaches to the rat issue include working with businesses to eliminate rat-friendly conditions, shifting pickup times to make sure trash is not left out overnight, continuing and publicizing education programs like the Rat Academy, and prioritizing high-risk areas using GIS and data tracking to target trouble spots and pinpoint rat dens. In addition, education of building managers, tenant associations, block associations and enforcement by DOS are essential to controlling pest population in safe and effective manner.
S ewage: Sewage issues in NYCHA housing should be addressed quickly. (See Housing section.)
Seniors
Community District 7 is home to an increasing number of senior citizens and to Naturally Occurring Retirement Communities (NORCs) which receive funds targeted for aging populations. A NORC at Douglass Houses (where there are more than 1000 underserved seniors) is needed.
Lack of health and household services and visitor contact contributes to the institutional placement of many seniors who otherwise would have been able to stay in their home. Extended In-Home Service to the Elderly Program, which provides homemaking for vulnerable homebound seniors not eligible for Medicaid, has seen drastic budget cut. The Adult Social Day Services Program, which provides therapeutic programs for seniors who are disabled (many with dementia) was eliminated. Funds for Elder Abuse Prevention Programs and Geriatric Mental Health Initiatives have not increased with the growing number of seniors. United Neighborhood house funding has remained stagnant. Volunteers and funds are needed to fill in many gaps.
Violence
D omestic and gender-based violence: Domestic violence includes family and intimate partner violence, sexual violence, stalking, and trafficking. According to the Centers for Disease Control and Prevention, approximately 1 in 4 people who identify as female and 1 in 10 people who identify as male have experienced intimate partner violence, including sexual violence, physical violence, and/or stalking. Homicide is one of the leading causes of death for children aged 1-4 in the United States.
More funding is needed to support education, intervention, and recovery programs that address domestic and gender based violence and its impacts. The Mayor's Office to End Domestic and Gender-Based Violence recently opened a Learning Lab at the NYC Family Justice Center in Manhattan to provide economic empowerment programming for people who have experienced gender-based violence.
And as referenced above, more housing is needed specifically for victims of domestic violence, including for people who identify as transgender or gender nonconforming.
H ate crime reporting and analysis: More data is needed on reported and unreported hate crimes in New York City and Community District 7.
R esponsiveness to emergency calls: More research is needed to determine consistent speed and responsiveness to emergency 911 calls across neighborhoods in Community District 7, including in NYCHA housing.
S exual violence: The Manhattan District Attorney’s Office is working on legislation to remove an involuntary intoxication requirement for sexual assault of those who are intoxicated. Calls to the Manhattan DA’s work-related sexual violence hotline will likely double this year. There have been increases in reporting of revenge porn at the workplace and in reporting by individuals who identify as LGBTQ. More financial resources for investigations of sexual assualt and rape are needed, including child sexual abuse and exploitation. In September of 2019, The New York Times reported that online photos and videos of child sexual abuse doubled in number in the last year to 45 million.
More funding is needed for the NYPD Sex Crimes Unit to increase staffing and reduce caseloads.
C hild Victims Act: The recent passage of the Child Victims Act into law will enable more people to file claims against individuals who abused them and the institutions who enabled the abuse. Safe Horizon (SH) provides information about legal and counseling services on their website and SH partners with the Crime Victims Bar Association to offer legal services. Many claims that have been filed are against institutions, and more financial, legal, and psychological support is needed for individuals to decide whether to file claims after the one-year lookback window. The renewed focus on child sexual abuse means that even among people who do not file claims, there is a retraumatization that may occur for which supportive services are necessary.
If possible, New York City Law Department/Corporation Counsel’s Office should track numbers of claims filed as well as outcomes.
Quality of life
H oarding and pests: Hoarding is an issue for a subset of seniors and others in Community District 7. Landlords evict people because of hoarding. Mice, rats, bedbugs and roaches are rampant where there is hoarding and open garbage exacerbates infestations. (11% of households report cockroaches in Community District 7.) Emergency services are often blocked. Case managers require special training. Cross-sector and interagency collaborations are needed to address the problem.
R ats: Community District 7 has many buildings with signs of rats and failed inspections compared to other districts. In addition to current initiatives (such as expansion of rat-proof trash cans by the Department of Sanitation), new approaches to the rat issue include working with businesses to eliminate rat-friendly conditions, shifting pickup times to make sure trash is not left out overnight, continuing and publicizing education programs like the Rat Academy, and prioritizing high-risk areas using GIS and data tracking to target trouble spots and pinpoint rat dens. In addition, education of building managers, tenant associations, block associations and enforcement by DOS are essential to controlling pest population in safe and effective manner.
D omestic and gender-based violence: Domestic violence includes family and intimate partner violence, sexual violence, stalking, and trafficking. According to the Centers for Disease Control and Prevention, approximately 1 in 4 people who identify as female and 1 in 10 people who identify as male have experienced intimate partner violence, including sexual violence, physical violence, and/or stalking. Homicide is one of the leading causes of death for children aged 1-4 in the United States.
More funding is needed to support education, intervention, and recovery programs that address domestic and gender based violence and its impacts. The Mayor's Office to End Domestic and Gender-Based Violence recently opened a Learning Lab at the NYC Family Justice Center in Manhattan to provide economic empowerment programming for people who have experienced gender-based violence.
And as referenced above, more housing is needed specifically for victims of domestic violence, including for people who identify as transgender or gender nonconforming.
H ate crime reporting and analysis: More data is needed on reported and unreported hate crimes in New York City and Community District 7.
R esponsiveness to emergency calls: More research is needed to determine consistent speed and responsiveness to emergency 911 calls across neighborhoods in Community District 7, including in NYCHA housing.
S exual violence: The Manhattan District Attorney’s Office is working on legislation to remove an involuntary intoxication requirement for sexual assault of those who are intoxicated. Calls to the Manhattan DA’s work-related sexual violence hotline will likely double this year. There have been increases in reporting of revenge porn at the workplace and in reporting by individuals who identify as LGBTQ. More financial resources for investigations of sexual assualt and rape are needed, including child sexual abuse and exploitation. In September of 2019, The New York Times reported that online photos and videos of child sexual abuse doubled in number in the last year to 45 million.
More funding is needed for the NYPD Sex Crimes Unit to increase staffing and reduce caseloads.
C hild Victims Act: The recent passage of the Child Victims Act into law will enable more people to file claims against individuals who abused them and the institutions who enabled the abuse. Safe Horizon (SH) provides information about legal and counseling services on their website and SH partners with the Crime Victims Bar Association to offer legal services. Many claims that have been filed are against institutions, and more financial, legal, and psychological support is needed for individuals to decide whether to file claims after the one-year lookback window. The renewed focus on child sexual abuse means that even among people who do not file claims, there is a retraumatization that may occur for which supportive services are necessary.
If possible, New York City Law Department/Corporation Counsel’s Office should track numbers of claims filed as well as outcomes.
Needs for Older NYs
Community District 7 is home to an increasing number of senior citizens and to Naturally Occurring Retirement Communities (NORCs) which receive funds targeted for aging populations. A NORC at Douglass Houses (where there are more than 1000 underserved seniors) is needed.
Lack of health and household services and visitor contact contributes to the institutional placement of many seniors who otherwise would have been able to stay in their home. Extended In-Home Service to the Elderly Program, which provides homemaking for vulnerable homebound seniors not eligible for Medicaid, has seen drastic budget cut. The Adult Social Day Services Program, which provides therapeutic programs for seniors who are disabled (many with dementia) was eliminated. Funds for Elder Abuse Prevention Programs and Geriatric Mental Health Initiatives have not increased with the growing number of seniors. United Neighborhood house funding has remained stagnant. Volunteers and funds are needed to fill in many gaps.
Needs for Homeless
Homelessness and supportive housing
The homeless population continues to increase citywide (at close to 80,000, 5% of which are living on streets) and in Community District 7. The lack of funds for supportive services for those living with mental health issues, addiction and other health problems, increases the risk that people with these problems will become homeless. Section 8 vouchers are difficult to procure and create a need for nonprofit organizations to seek alternative sources of funds to cover over 60% of tenants’ rent.
The Human Resources Administration has described the following as priorities: anti-eviction and legal services, supportive housing, access to benefits through ACCESS HRA, and access to housing benefits and support for people with HIV.
New York City and State needs to fund more supportive housing, especially permanent supportive housing, with long term funding for support services. Supportive housing is by far the most successful way to end homelessness for individuals and families, especially those living with physical and mental disabilities and other challenges.
Providing housing first gets people back on their feet and allows them to pull their lives together more quickly. Research has shown a 50% decrease in alcoholism when people who are homeless are housed. However, there is not nearly enough supply to meet the record need.
In addition, more housing is needed specifically for victims of domestic violence, including for people who identify as transgender or gender nonconforming.
G ender equity and transparent community process: Concerns about gender equity and the need for a more transparent community process have emerged in response to the potential change at the West 107th street shelter (from a shelter with female residents to a shelter with male residents).
Needs for Low Income NYs Food insecurity and its impacts
image
A ffordability and access to healthy food: Overall, Community District 7 has five farmer’s markets and has a 1:3 ratio of supermarkets to bodegas (the lowest ratio in New York City). The percentage of Community District 7 residents who report eating at least one serving or more of fruits and vegetables is similar to citywide average. Approximately 1 in 10 children in grades k through 8 have obesity (citywide rate is 1 in 5).
Access to healthy food is limited in low-income areas. Critically-placed grocery stores have closed and are closing, often due to luxury residential development, leaving food deserts for multiple blocks, a major issue for residents who are low-income, senior and/or disabled. Fresh produce is costly in Community District 7.
Meal programs and food pantries face ongoing increases in costs of meals (due to labor and raw food costs) without a corresponding increase in government funds and donated food. In New York City, the majority of emergency food providers (54%) report running out of food. In Community District 7, Goddard’s two food pantries are at capacity and the waiting list recently grew for the food pantry located at Lincoln Square (in Amsterdam Houses and the Amsterdam Addition). Attendance at senior meals in that development has also increased by about 10% in the past year.
In addition to two food pantries, Goddard provides home delivered freshly made meals to over 500 seniors (7 days of meals delivered over 5 to 6 days a week). Goddard also feeds all children in their early childhood and youth programs. Goddard’s supportive housing provides meals and cooking facilities and their TOP clubhouse provides lunch prepared by members. Citymeals on Wheels delivers several hundred thousand meals to residents in Community District 7 each year.
Food Bank for NYC delivers 1.5 million meals citywide, and to determine need, uses the Meal Gap (NYC’s official measure of food insecurity). The Meal Gap represents families’ and individuals’ missing meals that result from inadequate household food budgets. In Community District 7, the Meal Gap is 3.3 million meals. (Citywide, the Meal Gap is 208 million meals.) More than one in ten people in Community District 7 are food insecure.
S NAP enrollment: In addition to the delivery of free meals, in Community District 7, over 16,000 people in 12,000 households rely on SNAP. Yet more people need SNAP than are participating. More outreach and assistance is needed for enrollment.
Overall, meal providers request that the city provide a higher reimbursement rate for meals. More funding is needed to support programs that provide meals and assistance for enrollment in public benefits as well as efforts to address root causes of hunger and food insecurity. More public engagement and participation in the work of local organizations will also enable greater food security as many organizations rely on volunteers.
S ewage: Sewage issues in NYCHA housing should be addressed quickly. (See Housing section.)
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
6/25
DFTA
Renovate or
Space and renovation of the senior center at
885
upgrade a senior
Douglass Houses to be run by DFTA. This could
Columbus
center
be the seed of a NORC in a community where
Ave
there are more than 1000 underserved seniors.
(DFTA)
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/34
DHS
Other facilities for
Funding for permanent supportive housing units
the homeless
for people transitioning from shelters.
requests
4/34
DHS
Other request for
4) Funding for more beds for victims of domestic
services for the
violence, including beds specifically for people
homeless
who identify as transgender or gender
nonconforming.
12/34
DOHMH
Other programs to
Funding for vision screening and free access to
address public
prescription glasses for youth to improve school
health issues
participation and success.
requests
17/34
HRA
Provide, expand, or
To increase participation/enrollment in SNAP,
enhance food
funding for staff to conduct outreach and assist
assistance, such as
people in completing applications.
Food Stamps / SNAP
19/34
DFTA
Increase home
Funding for higher reimbursement rates for
delivered meals
meals for the elderly
capacity
25/34
DOHMH
Other programs to
Funding for additional DOHMH staff to collect
address public
and report more information to the public and
health issues
MCB7 on lead testing (blood lead levels in
requests
children) and investigations, including any initial
positive test, any retest results, and results six
months later; as well as findings and outcomes
of investigations.
30/34 HRA Provide case management, cash assistance, or social services
To provide financial counseling and legal assistance for people unable to pay medical bills, funding for a pilot program supported by DOHMH and/or the NYC Law Department/ Corporation Counsel’s Office. (New)
image
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 7
image
M ost Important Issue Related to Youth, Education and Child Welfare
Other
Segregation and Inequity of Educational Opportunities and Resources CSD3 includes the Upper West Side section of Community District 7, and continues into the southern portion of Central Harlem. Taken as a whole, CSD3 is among the most diverse districts in the New York City public school system, whether measured by race, ethnicity, socio- economic status, student performance or other relevant measures. Yet few if any individual schools in CSD3 mirror that diversity. In addition, several schools in District 7 are situated in diverse catchment zones, but because of variation in the use of public schools, the school population does not reflect the diversity of the catchment zone.
One of the direct results of the segregation of CSD3 schools is a wide and growing disparity in resources available among schools. This gulf in funding is a result of several factors, including (a) since funding follows enrollment, the schools with highest enrollment have greater funding; (b) Title I funding, which is intended to address the effects of poverty on student performance, is administered in the City of New York in a way that leaves many schools, including schools in CSD3 and District 7, with significant populations of low-income students but no corresponding funding; and (c) many of the schools in the southern portion of the District that enjoy relatively affluent parent bodies are able to raise significant funds to supplement the educational experiences in their schools at levels that other schools in District 7 cannot hope to achieve. The issue of disparate resources remains an elusive issue. The increase in enrollment in PS 191 and PS 452 due to the rezoning that took effect in 2017 to expand PS 191’s catchment, and the re-siting of PS 452 so that it can grow to three or four sections per grade (from its former two sections in grades 1-5) is providing additional resources to both schools. Systemic disparities remain, especially between under-enrolled schools in Central Harlem and schools below West 110th Street that do not have access to parent funding at a scale that the southernmost schools enjoy. The impact of disparate resources includes the inability of some schools to offer enrichment or remedial help as needed; the repurposing of dedicated space for art, science or music to classroom space; and the inability to offer afterschool programming which is essential for many working families.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
M iddle School – Responses to Diversity Initiatives: As noted below, Community School District 3 (which comprises
all of Community Board District 7 and a portion of Southern Harlem) (“CSD3”) has adopted set-asides for students meeting certain poverty and achievement criteria as part of the Middle School Choice process.
These changes require additional supports, including dedicated social-emotional learning support for all students, enhanced enrichment support for certain students, and remedial supports for certain students, to ensure that all middle school students will have enhanced experiences as a result of the new admissions process.
A dditional Social Workers: The FY 2020 budget included funds for an additional 285 social workers (Citywide).
It is essential that (a) the funds for these additional social workers be baselined so that the continuity of expert services provided by these professionals is not left to a year-to-year budget negotiation, (b) that these social workers include in their professional services an emphasis on restorative justice to meet the growing needs of the students, especially our most vulnerable students, and (c) that these social workers are programmed and deployed to render the services for which they are trained and certified, and not used (except in rare emergencies) as supervisory staff for tasks such as recess and lunch monitoring.
P arent Coordinators: Parent Coordinators have a vital role as effective liaisons between school administrations and parents. In many cases, effective Parent Coordinators are the most vital link to encouraging parent engagement in their children’s education.
To fulfill this important role, it is critical that Parent Coordinators, like Social Workers, be assigned to duties that correspond to their professional role in fostering and encouraging parent engagement and serving as liaisons to parents. Parent Coordinators should not (except in rare emergencies) be scheduled as supervisory staff for tasks such as recess and lunch monitoring.
E quity in Parent Fundraising: Schools in CSD3 fall within a broad spectrum of fundraising, with certain schools able to raise significant sums both from among their parents and through other means, while other schools have limited ability and experience in raising funds to support the school.
Bridging the gap in non-DoE funds requires consideration of implementing a minimum level of revenue sharing between the schools with the greatest and least capacity for fundraising, while preserving incentives to maximize all such supports.
A dditional STEAM Opportunities: Other than the 8 Specialized High Schools, there are relatively few high schools in the system, and fewer still in Manhattan, that offer all of the Advanced Placement courses essential to students with ambitions in the sciences (i.e. AP Calculus AB and BC; AP Chemistry; AP Biology; and AP Physics), and fewer still that combine those offerings with accomplished offerings in the Arts.
The number of high schools offering this enhanced STEAM curriculum is essential to any equity and diversity program, both for the students who aspire to but do not gain admission to the Specialized High Schools, and to those who seek a different high school experience and deserve an equal opportunity for this enhanced learning program.
Elementary Schools
Diversity and Inequity of Access and Resources
CSD3 includes the Upper West Side section of Community District 7, and continues into the southern portion of Central Harlem. Taken as a whole, CSD3 is among the most diverse districts in the New York City public school system, whether measured by race, ethnicity, socio-economic status, student performance or other relevant measures. Yet few if any individual schools in CSD3 mirror that diversity.
In addition, several schools in District 7 are situated in diverse catchment zones, but because of variation in the use of public schools, the school population does not reflect the diversity of the catchment zone.
One of the direct results of the segregation of CSD3 schools is a wide and growing disparity in resources available among schools. This gulf in funding is a result of several factors, including (a) since funding follows enrollment, the schools with highest enrollment have greater funding; (b) Title I funding, which is intended to address the effects of poverty on student performance, is administered in the City of New York in a way that leaves many schools, including schools in CSD3 and District 7, with significant populations of low-income students but no corresponding
funding; and (c) many of the schools in the southern portion of the District that enjoy relatively affluent parent bodies are able to raise significant funds to supplement the educational experiences in their schools at levels that other schools in District 7 cannot hope to achieve.
The issue of disparate resources remains an elusive issue. The increase in enrollment in PS 191 and PS 452 due to the rezoning that took effect in 2017 to expand PS 191’s catchment, and the re-siting of PS 452 so that it can grow to three or four sections per grade (from its former two sections in grades 1-5) is providing additional resources to both schools.
Systemic disparities remain, especially between under-enrolled schools in Central Harlem and schools below West 110th Street that do not have access to parent funding at a scale that the southernmost schools enjoy.
The impact of disparate resources includes the inability of some schools to offer enrichment or remedial help as needed; the repurposing of dedicated space for art, science or music to classroom space; and the inability to offer afterschool programming which is essential for many working families.
The process by which the physical plant and the technology and other equipment available at schools can be upgraded can be fraught with complexity and delay. Even if capital funding identified as needed by the Community Education Council were allocated, the procurement and supervision of such materials or work can take years to accomplish. In addition, since the capital funding is stretched thin, only the most dire needs of a school’s physical plant will be slated for replacement, and the balance of such needs would at best be the subject of interim repairs.
While the scope of the needs far exceeds the funding available to local elected officials, the capital support provided by individual City Council Members, the Council as a whole, and the Borough President remain an indispensable source of capital funding for infrastructure (e.g. renovations of school libraries, auditoriums and common spaces), technology (especially computer hardware and peripherals), and the arts (especially musical instruments).
Accessibility
Only 16% of the 28 separate public school buildings located within Community School District 3, which includes all of Community District 7 plus six school buildings in Central Harlem, qualify as accessible under the Americans with Disabilities Act. Many of the non-accessible buildings were built during an era in which elevators and other means of providing equitable access was not feasible, and the cost to retrofit such buildings can be significant.
Many students with mobility disabilities must travel significant distances to a building that provides handicap accessibility. In addition, as a result of screening and admissions criteria at certain schools, the nearest accessible school building may not be available to or a viable option for certain mobility challenged students, which may exacerbate the segregation of students by race, performance level, or learning challenges.
The cost to make all 1,300 school buildings and all 1,800 separate schools under the control of the Department of Education, or even all of the 28 separate buildings in District 7, is prohibitive. A reasonable goal would be to ensure that one-third of District 3 schools are fully accessible by the end of the 2020-24 Capital Plan. This would amount to converting an additional 8 buildings to accessibility, with those buildings equitably distributed throughout the District and appropriately split between elementary and middle schools.
Schools Threatened By Construction
At least two schools in our District are facing the consequences of proximity to enormous construction projects that are expected to interfere materially with their enrollment, programming and ultimately the sustainability of their respective unique identities. PS 163 is less than 30 feet away from the proposed site for the construction of a 275- foot tall nursing home facility, which the developer seeks to build on a former parking lot that both an Environmental Impact Statement and independent testing has confirmed is riddled with lead and other toxins. PS 75/MS 250 is across a narrow street from a proposed project seeking to build a 10-story luxury building directly on top of an existing 6-story structure most of whose apartments are subject to rent regulation. In both cases, the schools front some of the most heavily trafficked and dangerous roadways in Manhattan; the block for each was the scene of a driver killing at least one pedestrian in the last few years year. Each school has been left virtually to fend for itself against airborne toxins, the impending non-stop construction noise levels that will rival that of an airport for several years, and the release of dust and particulate matter that will exacerbate asthma and respiratory distress levels in student populations already greatly above the national and City averages.
Until the prospect of disruptive construction, both schools enjoyed robust enrollment from families zoned for other schools but who choose these schools due to their unique mixes of enrichment and remedial course offerings (for example, the highly successful ICE program at PS 75/MS 250 which creates heterogeneous groupings of students with and without special needs as well as that school’s dual language immersion program, and the sought-after dual language immersion program at PS 163). The threat of the destruction of the learning environment especially for those who chose these schools has already resulted in families leaving the schools and enrolling elsewhere. The loss of the choice enrollment will threaten the economic and social viability of these valued programs, as well as the rich racial, economic and social diversity the schools seek through those programs.
While the proposed construction projects adjacent to PS 163 and PS 75/MS 250 both appear to be stalled at present, neither has been abandoned, and diligent monitoring and proactive planning is necessary to mitigate to the extent possible the effects on the learning environment of such destructive construction. While the nature and proximity of the construction would be the same regardless of the edifice to be built, it is worth noting that the project proposed near PS 75/MS 250 will not contain any affordable housing or community facility space to benefit the community.
Construction is now also underway opposite MS 54 on West 108th Street. Demolition of the three buildings used for generations as parking garages has been completed, and a Construction Advisory Group composed of representatives from the general contractor, the West Side Federation for Senior and Supportive Housing (the not- for-profit partner that will manage the new facility when built), MS 54 and its PTA, CB7, the Duke Ellington Boulevard Neighborhood Association, and various community groups is meeting regularly. The group, among other things, coordinates and provides notice of various actions to be taken by the contractor and construction engineers, and monitors the potential for release of dangerous materials. The Remedial Action Plan adopted in connection with the decision to allow this City-owned land to be redeveloped provides the key measures for this monitoring,
and protocols for addressing conditions that may arise. The general contractor and WSFSSH have already take steps to control disruption during critical instructional time such as the weeks in which the critical Statewide standardized tests are administered.
The impact of construction on an adjacent lot also threatens the students’ experiences at PS 199. The building under construction at 200 Amsterdam Avenue at West 69th Street, which gained notoriety due to allegations of an impermissibly gerrymandered zoning lot (which allegations are the subject of on-going litigation), directly abuts Sapolin Park, which in turn is adjacent to and is the playground for PS 199. The construction site has already been the subject of stop work orders arising from materials (including a hammer) falling from a great height to a sidewalk below. Thankfully, no one was injured, and the sidewalk is now enclosed in a protective scaffolding/shed, but if the building is permitted to reach its intended height of 668 feet, even a minimal error in handling tools or equipment could rain down damaging materials on areas used by the school.
The 2016 Rezoning Addressed Most Overcrowding and Uncertainty/Instability Issues
While most of the elementary schools in the southern portion of Community District 7 (which corresponds to the southern portion of CSD3) continue to operate at or slightly above their rated capacity, the rezoning of school catchments and the re-siting of three schools adopted by the District 3 Community Education Council ("CEC3") in 2016 and implemented by the Department of Education for the 2017-18 school year has all but eliminated the pernicious overcrowding and destabilizing in-zone Kindergarten waiting lists in all but one such school. Such overcrowding, and the uncertainty that it engendered among families unable to plan for their children's education, had plagued the District for more than a decade.
Uncertainty as to the location and nature of the elementary school which young children will attend is a destabilizing force on the sustainability and cohesiveness of the community. CB7 will continue to monitor in-zone waiting lists and overcrowding in CSD3 to seek solutions before they boil over into crises.
It is encouraging to note that, based on data from the two most recent Kindergarten admissions cycles, the fear that families would not embrace new school assignments to schools that had been historically segregated based on the 2016 rezoning plan has so far not been borne out by experience, and schools such as PS 191 have continued to grow and thrive in their new settings and with their expanded catchments and populations.
Middle Schools
Segregation and Lack of Diversity in District 3 Middle Schools
Prior to the admissions cycle for the 2019-20 school year, admission to middle schools in CSD3 was through a “choice” process in which 5th grade students rank their preferences on an application form, and schools use screening rubrics of their own design to determine to whom to make offers of admission. The Department of Education in 2017 adopted a change to this process, to be effective with the admissions cycle for the 2019-2020
academic year. Under the prior system, middle schools would have access to the ordinal ranking of each student’s preference for each middle school. Many of the most sought-after middle schools would only consider applicants who ranked that middle school as a 1stchoice.
Under the new procedure, called “ranking-blind” admissions, adopted by the central Department of Education without community review or input, the students’ ranked preferences will not be made available to the schools.
One concern raised by the “ranking-blind” admissions process is that it will empower the highest achieving students to apply to more than one of the four most coveted and highest-performing schools, with the potential result that the existing segregation and isolation of students in CSD3 middle schools based on achievement, special needs, socio-economic status, race or ethnicity would be exacerbated.
Of the 14 CSD3-based and 2 Citywide middle schools in the portion of CSD3 that overlaps with CB7’s Community District 7, the students in 10 of those programs consistently score below grade level on State standardized
tests. Those same 10 middle school programs have disproportionately high concentrations of students with documented special needs, students who qualify for free/reduced price lunch (the only measure of poverty available for student cohorts), and students who identify as African-American or Hispanic. The remaining 4 CSD3- based and 2 Citywide middle school programs, to varying degrees, have student cohorts that do not approach the District averages for these demographics.
The achievement gap does not begin in middle school but much earlier, and true equity in education requires quality Pre-K, Kindergarten, and Elementary School education as well.
The long-term goal must be for all elementary and middle schools in our District and beyond to be high-performing, offer true equity of educational opportunity, and end the cycle of identifying only a handful of schools as “coveted” or “sought-after.”
In 2018 CSD3, after extensive outreach to and meaningful consultation with the Community Education Council (“CEC3”), principals, parents, other educators, the District Leadership Team, and other stakeholders, adopted a further amendment to the middle school choice process with the intention of counter-acting the anticipated exacerbation of segregation of students by needs, performance and demographics.
The further amendment adopted by CSD3 with the active engagement and support of CEC3, with a resolution of approval from CB7, for the admissions cycle for the 2019-20 year will reserve at least 25% of seats at every middle school program for students who (a) score below grade level on the 4th grade State English Language Arts and Math standardized tests; (b) qualify for free/reduced price lunch; and (c) have report card grades in English Language Arts and Math that are below grade level.
Offers of admission based on the first middle school admissions cycle are only now becoming known, and the related question of whether families offered admission based on these new criteria will accept the offers and enroll in the schools to which they are matched will not be known until after the time this District Needs Statement will be submitted. CB7 will continue to monitor the impacts of these changes to the admissions processes, and will coordinate its findings and concerns with the Superintendent of CSD3 and CEC3.
Achieving more representative diversity in our schools is not just good social policy – it is good academic policy as well. Research reveals that schools that reflect the diversity of the community at large and at which students are not segregated by achievement or demographics yield observable advantages in learning and achievement for all students, both high and low performing, and for the school as a whole.
It is essential that addressing the potential exacerbation of isolation of students by achievement, needs, race or ethnicity not end with this further revision to the middle school choice process, and that the achievement gap in our District and our City be the subject of a sustained, innovative, and inspired effort that is worthy of one of the wealthiest and most progressive cities in our nation.
High Schools
The most serious new issue relating to high school admissions is the decision by the DoE to replace the prior printed version of the high school directory with a vastly abbreviated print version that essentially contains minimal information about each school and refers users to the online version of the directory.
One significant concern with this change is that many families in the public school system continue to lack internet access at home. While many workers do have internet access at their employment, the hours needed to scour the directory and analyze viable choices for their children are likely to be beyond the limited time available while at work for personal as well as the use of the internet.
Exacerbating this problem, the printed version of the directory makes cryptic references to certain critical information such as admissions priorities or requirements that are at best unclear and at worst misleading, with the result that families may spend a preference ranking on a high school to which the student does not have a reasonable chance of admission.
At the very least, the DoE must vastly increase the availability of computers with internet access for families that lack such access at home. Reasonable first venues for such expanded facilities could include public libraries, afterschool programs funded through DYCD, childcare facilities funded through ACS, and in middle and high schools themselves.
The impression that there is a scarcity of high school seats in our District is a function not of diminished capacity, although the repurposing of a portion of the former Brandeis High School to house a charter elementary school did reduce the inventory somewhat. Rather, that impression is a result of recent experience with students from our District being effectively foreclosed from six non-specialized public high schools in neighboring Community School District 2 who have admissions policies that grant an admissions priority to students from that District. Since 2004, no public high school in Community School District 3 that serves a general education population has such a geographic preference. In recent years, CSD2-priority high schools' acceptances of CSD3 students has been reduced to barely a trickle, with many CSD3 middle schools seeing none or less than a handful of their students accepted at the CSD2-priority high schools.
WESS has now phased in its first sections of high school students. The admissions preference that WESS will offer students who continue from its middle to high school grades will be the only, extremely limited exception to the absence of a CSD3-priority high school.
In part because of geographic preferences that discriminate against CSD3 students, it continues to be the case that students in our District, including those who routinely perform well above grade level, are not matched with any high school (specialized or non), and required appeals and supplementary rounds of the high school admissions process to find high school homes.
Specialized High School Admissions
The lack of diversity reflective of the Citywide population noted above with respect to elementary and middle schools has perhaps its most identifiable counterpart at the high school level in the eight specialized high
schools. Those schools (Brooklyn Latin HS; Brooklyn Technical HS; Bronx HS of Science; HS for American Studies at Lehman College; HS for Math, Science & Engineering at City College; Queens HS for Sciences at York College; Staten Island Technical HS; and Stuyvesant HS) admit students solely on the basis of a one-day test that is created independently of any other standardized test administered to NYC public school students.
The requirement that the one-day test as the sole basis of admissions (the "Specialized High School Admissions Test" or "SHSAT") is enshrined in State legislation, and thus would require an act of the New York State Legislature to modify or eliminate it. The Mayor has proposed revising admissions to the eight specialized high schools by creating automatic offers of admissions to those schools for the students with the highest performance on yet-to- be-determined assessments at every middle school in the public school system. This proposed new model, drawn from the admissions practices at the University of Texas at Austin and elsewhere, is intended to welcome students across a wider spectrum of socio-economic status, race, ethnicity, student performance, special needs and other measures. In particular, the proponents of this proposal seek to eliminate the disparity between students who spend significant amounts of time (and for some, money) taking outside courses designed to prepare them for the SHSAT, while other students are perceived not to have access or be able to afford such preparation. Many NYC public middle schools seek to offer their own prep sessions for the SHSAT, with varying degrees of rigor and results.
Complicating the consideration of any such change that the Legislature may undertake is the unique composition of certain of the specialized high schools. For example, anecdotal evidence suggests that the families who spend time and money on SHSAT prep courses are not limited to the highest socio-economic status families – many lower- income families are seen as sacrificing in order to afford prep courses to gain admissions to specialized high schools. Thus, a concern that has been raised is that ending the under-representation of one group of low-socio- economic status students could only be achieved by making it more difficult for other low-socio-economic status students to gain admission.
CB7's Core Principles include embracing diversity and inclusion. CB7 will study each proposal to achieve greater equity in high school admissions to ensure that their intended and unintended consequences align with our Core Principles in theory and in practice.
Middle and High Schools
Comprehensive Sex Education
Since 2011, New York City Department of Education (DOE) has required students to receive sexuality education as part of their mandatory single semesters of health education in both middle and high school, but reports from students, educators, and DOE itself show that even this minimal requirement is not being effectively implemented. A report released by the Comptroller in 2017 confirmed that New York City schools are not complying with the minimum standards set by New York State for sex education.
Every young person will one day have life-changing decisions to make about their sexual and reproductive health. Yet research shows that the majority of adolescents lack the knowledge required to make those decisions responsibly, leaving them vulnerable to coercion, sexually transmitted infections and unintended pregnancy.
Research has repeatedly found that sex education which provides accurate, complete, and developmentally appropriate information on human sexuality, including risk-reduction strategies and contraception, helps young people take steps to protect their health, including delaying sex, using condoms or contraception, and being monogamous.
As early as second grade, children can learn healthy ways to communicate feelings, respect others, and manage their own behaviors. The value of a high quality, age-appropriate K-12 sexual health education requirement is clear. Students benefit from a scaffolded approach to the subject, with reinforced messages of healthy relationships and self-esteem. Teachers, also, benefit from a continuity between grades and schools. When students are familiar with the basics of sexual health knowledge, teachers can spend more time providing comprehensive sexual health instruction students need.
All schools in CSD3 should implement sexual health and wellness instruction in the health curriculum taught in 6th to 12th grades in accordance with current policy, and should expand that education to include age-appropriate instruction in grades K-5 following National Sexuality Education Standards.
All schools in CSD3 should establish School Wellness Councils to set a wellness agenda for the school and ensure that physical and health education are provided. Currently, School Wellness Councils exist in about 173 schools throughout the city. Councils consist of student advisors, school staff and parents or community members who wish to contribute recommendations and feedback on school health agenda. The Department of Education provides grants ranging from $1,000 – $2,500 for schools to implement or strengthen existing councils.
Pre-K
Solving the overcrowding in Kindergarten in our District has limited the ability to expand pre-K, since the rooms that might otherwise be used for Pre-K are needed in many public school buildings are needed for additional Kindergarten sections.
Overall, of the approximately 1,200 applicants to Pre-K in 2017-18 in CSD3, only 143 were not offered a placement at a school in the District that was among the families' choices.
Also due to the scarcity of seats, the initiative to expand access to "3-K" or preschool for 3-year-olds has not been a priority that can be accommodated at this time.
The 2016 rezoning adopted by CEC3 together with the re-siting of PS 191 and PS 452 that are a part of that plan so far has created additional opportunities for pre-K. Both 191 and 452 have reported increases in Pre-K
enrollment. In addition, PS 84 has expanded from 1 to 4 sections of pre-K, using space that was freed-up by relocating the Dual Language Middle School to the O'Shea Complex as part of the re-siting/rezoning adopted in 2016.
For schools in parts of Community School District 3 that lie outside Community District 7, pre-K is an effective draw for enrollment, and the elimination of pre-K seats has been used as one of several means to create space then seized for co-locations of charter and other schools. While it is not reasonable to expect all pre-K seats needed for our District to be in public schools, forging a positive connection with families of young children builds community from the ground up and should be maximized to the extent possible.
The Mayor's announced priority for "3-K" – preschool for 3-year-olds, while welcome as a means to level playing fields among demographics and achievement, continues to struggle to find space for the number of seats that are anticipated to be needed. The UPK "Pre-K For All" initiative can barely keep pace with the demand for space in the current program.
Meeting the Needs of Students with IEPs
While tracking the delivery of mandated services to students with IEPs is an on-going data concern, estimates that as many as 40% of students Citywide do not receive all of their mandated services are alarming. Many of these reports are anecdotal, and one clear need is to develop an enhanced and more reliable system to track the delivery of such services.
There is an emphasis to implement inclusionary models to the extent consistent with students' needs and the resources of the schools to accommodate them. A companion problem of class sizes that are inconsistent with the effective delivery of services to such students must also be addressed. Whether students are better served by mandating that neighborhood zoned schools meet the needs of students with IEPs is the subject of ongoing study.
District 75 schools who serve students with needs that cannot typically be met in an inclusionary environment continue to be difficult to site and maintain.
Needs for Youth and Child Welfare
Youth Employment
The Summer Youth Employment Program (SYEP) is a significant resource for teens living at or near the poverty level, offering both a financial incentive as well as access to job-readiness skills, bankable work history, a sense of accomplishment and self-esteem, and relief from inactivity and doldrums (and the mischief to which idle hands can become prey). It has also been shown to improve school outcomes both in terms of attendance rates and grades the following year. In addition, without the availability of this work force, community-based organizations serving children and youth cannot meet their adult-to-child ratios, making those programs less effective.
SYEP has finally emerged from a 5-year period in which serial budget cuts all but decimated the program. Thanks to renewed and baselined funding, a record of over 74,000 youth were included in SYEP in the summer of 2018.
Despite these record number, some 89,000 applicants were left without a placement. DYCD believes that it has not exhausted the supply of host employers who can provide a meaningful experience, although identifying new employers or those who can expand their participation grows more difficult with the scale of the program.
Thus, the priority is to maintain baselined funding at the 74,000 position level, to engage the entire community to identify new employers and opportunities to expand SYEP, and to seek to innovate additional programs and means productively to occupy the youth who do not win placements in SYEP.
Day Care and Head Start
The need for early childhood care beyond UPK continues to grow, and is crucial for working families. The Mayor's initiative to expand all-day pre-K and now to initiate "3-K" for three-year-olds, together with expanded Head Start programming, is funded under the Early Learn initiative, are proven drivers of achievement in school for years to come as well as stability for working families.
It is essential that the funding for these programs, baselined in FY15, continue at least at the current programming levels to deliver both the services families need as well as certainty essential to good planning by service providers, families and ancillary services.
In addition, many of ACS's programs are funded on a district-wide allocation based on indicia of need on a Census tract or zip code basis that continues to leave pockets of significant unmet need in our District for publicly-funded child care, pre-K and Head Start. Either an overall funding increase to the baseline, or reform of the allocation system, is needed to ensure those with equivalent needs have equivalent access to programs and services.
In addition, added vigilance will be needed to ensure that needs continue to be met as the responsibility for Early Learn programs transitions from ACS to the DoE.
The consequences of living in the shadow of wealth for day care and Head Start can mean diminished opportunities for employment or independence as well as a lag in school readiness. Local community agencies are often the best equipped to understand local families' issues. The new RFP process for early childcare agencies should give weighted consideration to a community agency with a history of delivering service in that area.
After-School Programs
After-school programs provide a range of educational, social and recreational services in a supervised community- based setting, and are essential for many working families who need to work well past dismissal time at most schools.
Afterschool programs ensure that children are safe in the hours between the end of school and the end of their families' workday, when they would otherwise be most vulnerable, and provide opportunities for remedial instruction, enrichment, and safe play. Certain of these same programs continue to provide these same safe and affirming environments during school breaks in the summer. Education and NYPD specialists have advised CB7 that an effective means to address increased gang and “crew” activity, especially in NYCHA campuses and adjacent parks and playgrounds, would be to have safe places for youth and teens to meet and spend time outside the influence of gang activity. DYCD has indicated that the most effective way to meet those needs would be through “Beacon” and similar afterschool programs.
The FY18 and FY19 Budgets as adopted provided substantial funding for afterschool and OST programs. In many cases, the funding allocations in certain districts has seen a net increase over prior years.
Creating sustainable offerings to serve those most in need of afterschool and OST programs requires a multi-year approach, as additional capacity created in a single year may take time to fill, notwithstanding waiting lists of underserved families and children. Among other things, some populations most in need of these services may not have immediate access to information about the availability of such placements, and it may take time for a sense of reliability in planning for families to embrace these offerings.
It is therefore essential that the increased funding reflected in the FY18 and FY19 Budgets be continued and baselined into FY20 and beyond.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
4/25 SCA Renovate other site
component
The DoE/SCA 2020-24 Capital Plan includes
$750 million in new funding to make schools either compliant with the Americans with Disabilities Act (“ADA”) The goal of the Capital Plan in this regard is to convert one-third of the approximately 1,400 school buildings in the NYC DoE system to some level of accessibility. Given the funding and goals of the 2020-24 Capital Plan, a reasonable goal would be to ensure that one-third of District 3 schools are fully accessible or susceptible of affording students and faculty a reasonable accommodation by the end of the Capital Plan. This would amount to converting an additional 8 buildings to accessibility, with those buildings equitably distributed throughout the District and appropriately split between elementary and middle schools.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/34
DOE
Other educational
Support for students performing below grade
programs requests
level on in-school and standardized assessments
/ appx $500K The Department of Education
recently awarded a grant of $500,000 to each of
several school districts that are undertaking
initiatives to identify and support efforts to
increase diversity or end segregation of
students based on race, ethnicity, performance
level, and/or special needs status. District 3 /
Community District 7 has already undertaken
such initiatives, and is now working to address
the needs of students who have scored below
grade level on various in-school or standardized
assessments. District 3 should receive
equivalent funding in order to continue its work
to achieve its goals of increasing diversity while
meeting the needs of all students. (FY20 [new])
8/34 DYCD Provide, expand, or
enhance the Summer Youth Employment Program
Summer Youth Employment Programs serve several compelling needs. They provide alternatives to gang influence for at-risk youth; provide models and pathways to employment; develop positive work habits and self-esteem; and virtually every dollar earned is spent in the community. In addition, without the availability of this work force, community-based organizations serving children and youth cannot meet their adult-to-child ratios, making those programs less effective. SYEP has finally emerged from a 5-year period in which serial budget cuts all but decimated the program.
Thanks to renewed and baselined funding, a
record of over 74,000 youth were included in SYEP in the summer of 2018. Nevertheless, some 89,000 applicants were left without a placement.
image
9/34 DYCD Provide, expand, or
enhance after school programs for elementary school students (grades K- 5)
Maintain baseline funding for after-school and OST programs in public schools and in neighborhood CBOs in MCD7. Afterschool programs ensure that children are safe in the hours between the end of school and the end of their families' work day, when they would otherwise be most vulnerable, and provide opportunities for remedial instruction, enrichment, and safe play. Certain of these same programs continue to provide these same safe and affirming environments during school breaks in the summer. Education and NYPD specialists have advised CB7 that an effective means to address increased gang and crew activity, especially in NYCHA campuses and adjacent parks and playgrounds, would be to have safe places for youth and teens to meet and spend time outside the influence of gang activity.
image
image
15/34 DOE Other educational
programs requests
15) Provide Funding for Additional STEAM AP Courses. Other than the 8 Specialized High Schools, there are relatively few high schools in the system, and fewer still in Manhattan, that offer all of the Advanced Placement courses essential to students with ambitions in the sciences (i.e. AP Calculus AB and BC; AP Chemistry; AP Biology; and AP Physics), and fewer still that combine those offerings with accomplished offerings in the Arts. The number of high schools offering this enhanced STEAM curriculum is essential to any equity and diversity program, both for the students who aspire to but do not gain admission to the Specialized High Schools, and to those who seek a different high school experience and deserve an equal opportunity for this enhanced learning program.
image
16/34 DOE Other educational
programs requests
Adequate child care is a necessity for working families. The Mayor's initiative to expand all- day pre-K, together with expanded Head Start programming, is funded under the Early Learn initiative, are proven drivers of achievement in school for years to come as well as stability for working families. It is essential that the funding for these programs, baselined in FY15, continue at least at the current programming levels to deliver both the services families need as well as certainty essential to good planning by service providers, families and ancillary services.
image
22/34 DOE Other educational
programs requests
Provide Additional Support Funding so that Parent Coordinators and School Social Workers are not diverted from their professional duties and responsibilities. The FY 2020 budget included funds for an additional 285 social workers (Citywide). The budgets for most elementary and middle schools also include line items for Parent Coordinators. It is essential that the funds for these additional social workers be baselined so that the continuity of expert services provided by these professionals is not left to a year-to-year budget negotiation. (New)
image
image
26/34 DYCD Provide, expand, or
enhance the out-of- school youth program for job training and employment services
11% of youth aged 16 to 24 in Community District 7 are considered “disconnected,” meaning that they are not in school or working. To support the mental health and comprehensive needs of youth graduating and transitioning from high school to college or work, funding for a pilot program modeled after DoE/ACS programs (e.g., those designed for youth transitioning out of foster care). (DoE and ACS)
image
31/34 DOE Other educational
programs requests
Regular physical fitness is acknowledged as necessary for both physical and mental well- being. Due to overcrowding and scheduling changes around curriculum pressures and testing, schools have reduced gym classes and recess time. Most school playgrounds operated by the Dept. of Education are locked after the school day because there is no staff to supervise them. It is recommended that two school playgrounds in the MCD7 receive funding of
$55K for personnel allowing the playgrounds to remain open.
image
32/34 DOE Other educational
programs requests
Since 2011, New York City Department of Education (DOE) has required students to receive sexuality education as part of their mandatory single semesters of health education in both middle and high school, but reports from students, educators, and DOE itself show that even this minimal requirement is not being effectively implemented. Every young person will one day have life-changing decisions to make about their sexual and reproductive health. Yet research shows that the majority of adolescents lack the knowledge required to make those decisions responsibly, leaving them vulnerable to coercion, sexually transmitted infections and unintended pregnancy.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 7
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
Safety for all street users
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
New York Police Department. NYPD tracks seven major crimes as a primary indicator. Overall, major crime statistics in CD7’s precincts, PSA6 (public housing division), and Transit show a continuing downward trend.
Staffing: NYPD has moved to a data-based deployment and response system that utilizes specialized units and task forces. Consequently, the number of uniformed officers in precincts has declined over the past 5 years. In the 20th and 24th Precincts, the number of uniformed officers (134 and 126, respectively) and civilian personnel (15 and 22) have continued to decline. PSA6, whose officers are responsible for NYCHA developments in eight precincts, has 127 uniformed officers. However, actual staffing levels are lower, due to homeland security assignments, military service, and sick
leave. Recruiting, retention and civilianization are essential.
In 2017, NYPD implemented neighborhood policing. Precincts are divided into three sectors, each with two neighborhood coordinating officers (NCOs). The officers are responsible for knowing and working with the residents and businesses in their sectors. Their contact information and the dates and locations of their “Build-A-Block” meetings are available on NYPD’s website. CB7 welcomes this new program and is monitoring it to see if additional officers will be needed in the future.
Needs for Emergency Services
Fire Department. CD7 is located in the 9th and 11th Battalions and has 3 Engine and 2 Ladder Companies. In FY17, the Department responded to 10,128 incidents: 9,400 medical and non-medical emergencies, and 531 structural and 197 non-structural fires. The number and size of fires has decreased because of new construction and renovations of occupied and vacant buildings. Average response time to structural fires was 4:17 minutes; ambulance response time to life-threatening emergencies was 6:54 minutes.
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 7
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
In FY17, DSNY collected, on average, 205 tons of household garbage per day. CD7’s residential garbage continue to be transported to New Jersey by truck, which has a negative impact on air quality, roadways, vehicles, and worker productivity. Annually, MW7 collects 14,600 tons of paper and 7,781 tons of metal, glass and plastic, for a diversion rate of 24.8% of the waste stream. Over 2,464 recycling summonses were issued. More effective outreach and education could increase the diversion percentage and further reduce residential tonnage. CB7 supports the goals of the Comprehensive Solid Waste Management Plan (SWMP), including that Manhattan should assume as much responsibility as possible for its waste. MCB7 is following the implementation of the plan, including the development of the West 59th Street Marine Transfer Station. Organic recycling is an effective way to reduce garbage. DSNY enrolled many large residential buildings in CD7, but has not had much success with smaller buildings and businesses. CB7 supports outreach and training to increase organic recycling. The City is currently revamping the commercial garbage service to increase safety for workers and reduce the number of trucks on the streets. CB7 is monitoring this program. DSNY plays an important role in keeping sidewalks and streets clean. In FY17, 94.8% of the streets and 99.5% of the sidewalks were rated ’acceptably clean’. Enforcement agents issued over 4,715 health and administrative summonses, most for dirty sidewalks and failure to clean 18 inches from the curb. MCB7 supports funding for 7-day enforcement coverage, especially in commercial areas. In FY17, DSNY completed 99.9% of its mechanical broom routes on 93.6 miles of roadways and serviced over 1,000 street litter baskets with two pick-ups per day. Many local businesses and residents misuse baskets meant for litter by discarding their garbage in them. In 2018 in order to improve street cleanliness and reduce illegal use of litter baskets, DSNY began removing one-half of the street litter baskets on residential avenues. They did not reduce the number of trucks that service the baskets. Residents on Riverside Drive and West End Avenue are demanding the return of the baskets, citing overflowing baskets and increased litter on the sidewalks. CB7 is monitoring the pilot.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Recognition of the Problem
Our Upper West Side community and our City beyond are woefully unprepared for the accelerating environmental challenges before us, and are falling farther behind with each year. Many of the obstacles to achieving environmental sustainability are not strictly speaking budgetary issues, except perhaps insofar as budget decisions can have an impact on individual and collective behavior.
While many of the obstacles to environmental sustainability are also not unique to our Upper West Side District, local communities are at the heart of efforts to address those obstacles. The federal government's decision to "withdraw" from prior commitments enshrined in the Paris Accords has been met by corresponding pledges by the City of New York and many other cities, towns and States within our country to take up the cause on their own, albeit without a unified and cohesive national vision or the funding and strategic leadership that a national policy could summon. Marshaling localities and States to address climate change will be even more complicated by the federal government's open contempt for the scientific consensus concerning the role of human hands in creating and perpetuating the climate change crisis. The Environmental Protection Agency's own website buries any recognition for the man-made drivers of climate change, eroding both the funding for and the urgency of the call for overdue remedial actions.
Bolder action is needed at every level (from activists to government) to halt and begin to reverse the march to irreversible environmental destruction. Championing a respect for the role of science and systems engineering as a means to that end would be a welcome start, and one that can be modeled locally.
Preparing for Climate Change
The overwhelming consensus of experts, buttressed by empirical data, establishes that the global climate is under stress and already evinces marked change. Local anecdotal evidence of annual storms and other weather conditions that were once considered once-a-century phenomena reinforce the scientific conclusions.
Policy on a local level has been slow to respond. Few material changes to the New York City Zoning Resolution, and only a handful of changes to the Building Code in a handful of coastal zones, even mention let alone provide for the effects of rising sea levels from climate change. However, the passage in 2019 of the city’s Climate Mobilization Act gives hope. Called the municipal version of the Green New Deal, the legislation sets emissions caps for large buildings and requires landlords to retrofit these buildings to cut emissions by 40 percent by 2030 80 percent by 2050.
In our District, whose entire western border is composed of Riverside Park (but for one sea-level building complex now under construction), the effects of rising sea levels will be felt in the loss of active and passive recreation spaces, and plant and animal habitats. One need look no further than 2012 and Superstorm Sandy for the combined impact of rising sea levels and severe storm surges on residential and commercial communities. The experience of Coney Island, Staten Island and other communities in our City demonstrate that many of such impacts that are among the hardest to mitigate or recover from are visited on our poorest and most vulnerable neighbors.
Infrastructure Challenges
Inadequacies in the infrastructure of our City make addressing the reality of climate change a herculean struggle. For example, one effect of rising sea levels and more frequent catastrophic storms is the potential that the storm sewers and drainage runoff system will be overwhelmed. Since New York City has a "common" sewer system, the dual impact of rising sea levels and violent storms is not only to back up storm drains and turn roadways and open spaces into lakes, but to cause the solid waste treatment facilities either to back up or be overwhelmed and discharge human and solid waste into the Hudson River and other bodies of water. At a minimum, reducing stormwater runoff and separating it from the common sewer stream is a health as well as urban planning necessity.
Addressing the Impact of Human Activity
Not all examples of the impact of human activity on the environment are at the macro level. For years, our parks, public spaces and waterways have been befouled with non-recyclable plastic bags. In 2019, the State Legislature made New York the second state in the nation to impose a ban on most types of single-use plastic bags. The New
York City Council followed up by imposing a five-cent fee on the use of paper bags. Both measures take effect March 1, 2020.. Prior to enacting the paper bag fee, the City Council passed and the Mayor signed a ban on single-use foam products. A proposed ban on the use of plastic straws awaits a Council hearing.
Human impacts on the environment also include the invisible but pernicious deposit into our common sewer system of a host of plastics and microscopic fibers, mostly man-made and with an excessively long half-life, that in turn become part of our water supply and are ingested by land and marine animals, including humans and our pets. Some of these microfibers and microplastics are dangerous if not toxic.
The common sewer system makes weather-related storm runoff and the management of wastewater more difficult when human solid waste is added to the equation. For example, the absence of a ubiquitous and easy-to-follow program for separating organic food-related matter from the storm and wastewater system renders that common system more vulnerable. A system that facilitates organic material recycling and composting not only could yield benefits for urban gardeners and farmers, but would eliminate such waste from the management docket. The Department of Sanitation needs to expand its composting program, now available only in select areas, citywide. The City also needs to make it easier to dispose of unneeded electronics equipment. Relying on residents to haul heavy appliances to infrequent neighborhood collection events sends the message that the City is still not serious about the safe disposal of e-waste.
The Need To Revisit the Consequences of Urban Planning
Complicating factors affecting efforts to address the impact of climate change on our District and City include our system which allows certain development activities to proceed as-of-right, while others must undergo discretionary review and approval – especially since the determination of whether a development project requires a discretionary approval is not driven by the scale of the project's potential impacts on the environment or community. Some of the largest-scale development projects now underway in our City are being pursued as-of-right, thus evading the robust environmental review and other inquiries that are a part of our City's Uniform Land Use Review Procedure when discretionary approvals are required. Conversely, more modest projects may be stymied by the cost and intensity of scrutiny required to obtain approval. It is a given that greater height and density adds immeasurably to the value of development projects, and there is evidence to establish that the same height and density makes environmental sustainability more difficult to achieve and less likely to be realized. The time has come for a careful look at how and when the types of review and analysis currently associated with discretionary approvals should be required.
The Role of Energy Sources
One of the key elements of the Paris Accords and of similar measures to rein in the runaway effects of human enterprise on long-term environmental conditions is the goal of achieving defined reductions in the release of carbon and other greenhouse gases into the atmosphere.
In our City, where public transit already contributes to reducing our collective carbon footprint, the richest vein for mining for reducing carbon emissions is reform of our HVAC systems and related residential and commercial building management techniques.
An all-too-often overlooked solution to the release of carbon for HVAC needs is thermal exchangers in ground- source heat pump systems. By using the Earth's own internal temperature gradients with heat exchangers, technology is already providing developers and the governments to whom they are accountable with a means to reduce, possibly drastically, the energy needed to heat and cool and protect our living environments, and with it the greenhouse and other toxins released into our air and water.
Pursuing Solutions
Tackling the consequences of human impact on environmental sustainability, particularly given the lack of leadership on this issue at a national level, requires reform of the Zoning Resolution and the Building Code to embrace the difficult steps required to import the scientific consensus on the issue into doable steps. Those solutions must also include funding for these initiatives, recognizing that research and development must be made available to those whose means barely allow them to conform to current regulations let alone a new vision for individual and collective action.
Additional Specific Issues and Trends
Transportation Emissions.
Many Upper West Siders feel overwhelmed by traffic congestion, especially in terms of truck traffic and emissions. There is an increasing desire to reduce road traffic, including idling trucks and buses, and to create more access to energy-friendly transportation alternatives such as walking, biking, and mass transit. Enforcing the City’s prohibition against unnecessary vehicle idling has been on CB7’s list of budget priorities for several years. In 2017 the city passed a law allowing citizens to submit photo or video evidence to the Department of Environmental Protection of commercial vehicles idling and receive one-quarter of any resulting fine. Expanding this law to all vehicles would help further reduce unnecessary idling.
Many groups are interested in limiting parking both on-street and off-street to reduce the number of private cars in our District, adding protected bike lanes, and redesigning intersections to make the pedestrian experience more inviting and safer. Many have also sought more frequent transit service on busy routes.
Building Efficiency
New residential construction in the District creates opportunities to implement sustainable building systems, but as noted above existing zoning and building codes are limited and difficult to enforce. Most new buildings have glass facades, which constrict natural airflow and afford little room for energy-saving insulation, and typically depend on HVAC heating and cooling even when ambient temperatures are comfortable. Few new buildings take advantage of solar or other renewable energy sources, which CB7 encourages and believes should be incentivized.
Building Emissions
With strong early support from CB7, our City has eliminated the use of the highly toxic "No. 6" heating oil in most buildings (other than, shamefully, New York City school buildings). A large portion of those buildings which have eliminated the use of No. 6 oil have switched to systems that can use No. 4 oil, which is nothing more than a blend of cleaner No. 2 oil and the toxic No. 6. In effect, the new regulations have only cut No. 6 use in half. CB7 encourages the completion of the effort begun with the elimination of No. 6 oil by immediately requiring the phase- out of No. 4 oil on an accelerated timetable and rid our air of the particulate matter that still befouls it
Needs for Sanitation Services
Department of Sanitation. In FY17, DSNY collected, on average, 205 tons of household garbage per day. CD7’s residential garbage continues to be transported to New Jersey by truck, which has a negative impact on air quality, roadways, vehicles, and worker productivity. Annually, MW7 collects 14,600 tons of paper and 7,781 tons of metal, glass and plastic, for a diversion rate of 24.8% of the waste stream. Over 2,464 recycling summonses were issued. More effective outreach and education could increase the diversion percentage and further reduce residential tonnage.
CB7 supports the goals of the Comprehensive Solid Waste Management Plan (SWMP), including that Manhattan should assume as much responsibility as possible for its waste. MCB7 is following the implementation of the plan, including the development of the West 59th Street Marine Transfer Station.
45
Organic recycling is an effective way to reduce garbage. DSNY enrolled many large residential buildings in CD7, but has not had much success with smaller buildings and businesses. CB7 supports outreach and training to increase organic recycling.
The City is currently revamping the commercial garbage service to increase safety for workers and reduce the number of trucks on the streets. CB7 is monitoring this program.
The Columbus Avenue BID installs a Big Belly solar-powered trash can
DSNY plays an important role in keeping sidewalks and streets clean. In FY17, 94.8% of the streets and 99.5% of the sidewalks were rated ’acceptably clean’. Enforcement agents issued over 4,715 health and administrative summonses, most for dirty sidewalks and failure to clean 18 inches from the curb. MCB7 supports funding for 7-day enforcement coverage, especially in commercial areas.
In FY17, DSNY completed 99.9% of its mechanical broom routes on 93.6 miles of roadways and serviced over 1,000 street litter baskets with two pick-ups per day. Many local businesses and residents misuse baskets meant for litter by discarding their garbage in them. In 2018 in order to improve street cleanliness and reduce illegal use of litter baskets, DSNY began removing one-half of the street litter baskets on residential avenues. They did not reduce the number of trucks that service the baskets. Residents on Riverside Drive and West End Avenue are demanding the return of the baskets, citing overflowing baskets and increased litter on the sidewalks. CB7 is monitoring the pilot.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
10/34 DSNY Provide more
frequent litter basket collection
Baseline the FY20 increase in funds for street litter basket services. CD7’s 1,000 litter baskets are never empty – and often they are overflowing. The one-year increase in funding allows DSNY to service each basket within a 24- hour period instead of the 36+ hour service that was in place. The current service helps keep streets and sidewalks clean, with fewer incidents of rodent infestation and clogged catch basins and street drains, and reduces floatables in the Hudson River. (FY076; FY0810; FY0919; FY1023; FY118; FY123; FY134; FY1413; FY157; FY1626;FY1716;FY1817;FY
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 7
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing preservation
While the erosion of our affordable housing stock on the Upper West Side remains among the most critical issues confronting the community, the sources of that issue and its potential solutions are multi-faceted and complex. The answer to this complex problem is a combination of preserving the existing stock of affordable housing - whether in the form of opposing the de-regulation of rent-regulated apartments, empowering Mitchell-Lama residences to remain affordable, or rescuing NYCHA - as well as seeking to add to the stock of affordable housing whenever development opportunities are presented. In this context, real estate development is one of the most important contributing factors - not to supplant its previous invocation of affordable housing as the most important overall issue, but to supplement it. In particular, the recent trend in real estate development on the Upper West Side has been "as-of-right" development, in which a developer assembles a parcel with sufficient attributes, dimension, zoning and open space to enable it to construct a building that will undoubtedly have significant impacts on the community, but will not require any of the discretionary approvals that trigger public review such as ULURP or even City Planning Certiifcations. In the absence of such public review opportunities and the chance to evaluate a discretionary approval against criteria that address the impacts on the community, mitigating those impacts becomes an afterthought. When that reality is added to the trend of building luxury and market rate housing and commercial space, rents and values in neighboring pre-existing properties also can increase out of reach of current residents and especially those who have lived in the community for much of their lives. Thus, the upward spiral of real estate values, often at an accelerated pace, creates impacts on the district beyond our ability to address them.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
image
image
image
Nine Historic Districts, including 1100 Buildings Seventy Four Individual Designated Buildings Four Interior Landmarks
image
Four Scenic Park Landmarks
1. Affordable Housing: Community Board 7 has seen little development of affordable housing in the last decade.
This is in part due to extremely high prices for private developable sites. In
order to address the dire need for affordablehousing, a survey should be conducted, in cooperation with the relevant City Agencies, of all city-owned land and buildings in the Community Board 7 District, to determine whether potential sites exist for development of affordable housing units.
When affordable housing developers are able to find a site to develop in CB7, they face many administrative barriers in working through the land use approval process. Projects that include at least 25% of affordable units should be expedited for DCP internal review. DCP should create a dedicated "fast lane" for affordable projects to ensure they are built expeditiously.
1. Excessive Height Buildings and Zoning Lot Mergers: Two new developments in CB7 – 200 Amsterdam Avenue at West 69th Street, now completed (overall height 668 feet), and 50 West 66th Street, under construction,
also known as 36 West 66th Street (overall height 775 feet) – dwarf their neighbors and
jarringly depart from the typically activestreetscape at the base of the buildings. Both buildings are in sharp contrast to the neighborhoods in which they are located. The 66th Street building will create unacceptable shadow conditions in Central Park. These projects have been met with unanimous community opposition and community groups have filed challenges at both the Department of Buildings (DOB) and the Board of Standards and Appeals (BSA). Litigation pending under Article 78, related to the 200 Amsterdam project, contesting the legality of the proposed gerrymandered lot configuration and the dubious acquisition of additional floor area.
The excessive height of these buildings is made possible by advances in construction design, materials and techniques, and by developers’ desire to manufacture increased height to give upper level luxury apartments a desirable view. The new trends in apartment design include: floor-to-ceiling heights from 16’ or more; creation of large building lots from zoning lot mergers and/or air rights transfers and mechanical spaces inserted mid-way within the tower with excessively tall floor-to-ceiling heights creating a “void” space above the mechanical equipment. In the case of the 66th Street building, a zoning lot merger involving two zoning districts has resulted in a transfer of bulk from the building base to the tower in clear defiance of the intent of the zoning rules for the two districts. In the case of the 200 West 70th Street building, a merged zoning lot was created by splicing together barely contiguous portions of outdoor space, including walkways and a parking lot. Although the City Planning Commission and the City Council have purported to limit the use of mechanical spaces, a recent amendment to the Zoning Resolution still permits 25' voids for every 100' feet of building height. This amendment will do little or nothing to eliminate the use of voids to create supertall buildings.
The Chair of the BSA at a hearing on September 10, 2019, stated that the zoning language limits height by the number of stories and “what’s strange about that kind of 90’s argument is that at the time nobody could imagine that anyone would build such tiny floor plates. Nobody …. we’d say ‘nobody would ever build that because it’s just all staircases and elevators,’ and now we have several buildings with 4,800 square foot floor plates being built.”
Assembling lot parcels and air rights transfers pose the greatest risk as to the existing “soft sites” in the CB7 District not protected by appropriate zoning controls or historic district designation status. One such site is the ABC site between West 66th Street and West 67th Street off Columbus Avenue which was carved out of the Lincoln Square Special District. The recent sale of this 2.6-acre site in a high-density C4-7 zone, raises the possibility that one or more supertalls will be built, purportedly as of right, when ABC vacates the building in approximately 4 1/2 years.
There needs to be a reassessment of the current zoning and a possible imposition of new requirements to limit such “as-of-right” projects. The proposed new study of the District should proactively identify potential soft sites where developers could take advantage of one or more of the “loopholes” in the current permitted zoning. In particular, the following need to be reviewed: making zoning lot mergers subject to the zoning code; the imposition of height restrictions tailored to the context of specific neighborhoods or blocks; the requirement for a Special Permit if prescribed maximum heights are to be exceeded; and the inclusion of the ABC site in the Lincoln Square Special District.
BSA Reform: In general, BSA procedures need to be rationalized, made more efficient and more transparent. CB7 will continue to follow up on the status of proposed amendments to the City Charter and offer testimony where appropriate.
Construction Concerns
1. Proliferation of Multiple Construction Projects: Building or rehabilitating structures in a crowded urbanenvironment, of necessity, impedes traffic, is noisy and may attract
rodents. These inconveniences are multiplied where more than one such project is ongoing on a single block. Special rules need to be developed to provide, at a minimum, additional safeguards so as to ensure minimum disruption to sanitation collection,
on-street parking, traffic control, and ongoing pest control efforts.
1. 1. DOB Enforcement and Permitted Construction Work Hours: Many construction projects find it advantageous to engage in construction activities after permitted hours or on Sundays, in violation of city rules pertaining to hours of work. Often, DOB issues permits for late night or Saturday work. Enhanced DOB enforcement is required to police these projects and to impose meaningful penalties in the event of violations, particularly repeat violations. Additionally, DOB should enforce
restrictions contained in BSA variances, theZoning Resolution and restrictive covenants and should not issue work permits for late hours or weekends. Copies of the documents related to permitted construction bulk, materials and other features should be readily available to the public at construction sites.
DOB should, as a matter of rational policy and courtesy, promptly notify the affected community board whenever a developer files for the construction of a new building in excess of 100, 000 square feet, whether the project is alleged to be as of right or requires a special permit.
1. 1. Sidewalk Bridges and Scaffolding: Scaffolds, while a necessary evil, too often are left in place for unreasonably long periods during which no work is done. Whether this results from poor planning or a desire not to spend money on repairs, the proliferation of scaffolds and sidewalk bridges represents a blight on our sidewalks. The City should enact legislation to limit the time during which a sidewalk scaffold is in place. In the
event that a landowner needs to maintain the shed in place for a period of time in excess of the limit, the landowner should have the burden of showing necessity not caused by its own inaction or delay.
Scaffolds in place beyond the original time period or any extended time limit should be subject to a daily fine.
1. 1. Environmental Impact of Construction: Residents have complained that construction-related refuse, including hazardous materials, is not being disposed of properly within the district. CB7 requires additional investigation on the impact of
construction and the need for additional enforcement, especially demolition anddisposal of refuse from construction sites.
Columbus Avenue Beautification: Columbus Avenue is a major commercial thoroughfare. In the 60's and 70's its stores, restaurants and cafes brighten and enliven the street and pedestrian traffic is heavy. North of about 83d Street, the streetscape changes visibly. There are more vacant stores or storefronts with temporary occupants who pay little or no attention to their external appearance. In the old Upper West Side Urban Renewal area (from 86th to 96th Street, buildings are set back and building walls are bleak and uninviting. North of 97th Street, the Avenue is marked by construction of new buildings which impart an air of sterility. There is no one-size-fits-all solution to the problems posed by Columbus Avenue, but Community Board 7 believes that an imaginative and collaborative approach might yield a more inviting and attractive streetscape.
Inadequate Public Trash/Recycling Receptacles: Inadequate street receptacles for trash lead to overflowing garbage or disposal of garbage on the street. This is a quality of life issue of high importance. No matter how vibrant our neighborhood and its residents, a dirty and trash-ridden sidewalk is unattractive and depressing and invites rodents. It is unclear whether the problem results from too few receptacles, too infrequent collection, or citizen indifference, but the problem appears to be remediable with relatively little additional expenditure.
Preservation
Historic Districts and Individual Landmarks. Community Board 7 is located between 2 historic parks, Central Park and Riverside Park, both of which are designated scenic landmarks (check RSP). The avenues and side streets are filled with a variety of buildings of diverse architectural styles. In scores of blocks, rows of brownstone townhouses line the side streets, and elegant apartment buildings cap the blocks at the avenues. Many of these buildings were designed by the most outstanding architects of their times.
More than 11,000 buildings have been included as part of nine historic districts, but many significant buildings are still unprotected and threatened with demolition or inappropriate changes. While CB7’s call for protection of the Con Edison Power Plant on 59th Street and West End Avenue, designed by McKim, Meade and White, was answered in part by the designation of the building as a landmark, the Landmarks Preservation Commission made its designation subject to various conditions that could easily have the effect of materially altering the landmark structure without the customary review and community input typical for individual landmarks.
The District also boasts many outstanding individual landmarks, from the iconic Dakota apartments to the Ansonia Hotel to the Marseilles apartment building among residential structures, as well as the American Museum of Natural History campus, St. Michael's, West End Collegiate and West End Presbyterian churches, and the Broadway Fashion Building, not name but a few.
Rear Yards. One area of concern with respect to Preservation is of the incursions into and treatment of the open space in the so-called "donuts," the rear yards of townhouses located throughout the area. Greenery and open space - part of the individual residents' property enjoyed by all who face these open areas. Businesses, schools and other not-for-profit users are developing these areas, reducing the amount of greenery and open space, and changing the character of neighborhood. Others seeking more space are building up and out without regard for their neighbors and to the light and air they are altering. A committee of preservationists, land use experts and environmental advocates with the help of public officials are working to address this issue. Some of the solutions may include tax incentives, currently offered for green roofs, and the need for DOB permits for installation of concrete. PlanNYC emphasizes the importance of sustainability and we are working toward that end.
Maintenance of designated buildings. An on-going challenge is the maintenance of non-profit designated buildings such as churches and synagogues, which are frequently faced with the dilemma of how to avoid draining their limited resources without resorting to redevelopment either by modifying the existing structures or abandoning them altogether to generate funds. MCB7 encourages efforts to identify the needs of these designated buildings and provide support to maintain them.
West End Avenue Preservation. MCB7 was an early supporter of the creation of a West End Avenue Historic District to protect the rich architectural fabric of buildings from 70th to 107th Streets west of Broadway. The effort, led by the West End Preservation Society in collaboration with many other preservation organizations, succeeded in securing designation of many of the buildings sought to be protected through a series of extensions of existing historic districts. There remain a series of buildings left unprotected by the West End Avenue initiative – mostly structures on the west side of Broadway above West 96th Street, which were withdrawn from consideration at the last minute prior to designation. Further action is needed to protect these worthy structures.
Needs for Housing
Total Units
Home Ownership
Rate
% Vacant
Rental Units
Median Gross Rent
Median Income
Income Diversity Ratio
2000
29.2%
$1,499
$102,036
2006
120,652
35.6%
6%
$1,658
$112,374
6.7
2010
113,725
32.0%
3.8%
$1,734
$102,248
8.6
2016
121,595
35.2%
4.8%
$2,211
$115,612
8.8
2017
117,342
40.2%
4.7%
$1,953
$126,257
9.2
Affordable Housing
Economic diversity is a value greatly appreciated by MCB7, but the Upper West Side is rapidly becoming an area characterized by high inequality and one that is closed off to low and
middle-income renters. The great disparity between the many high-income families who dwell on the Upper West Side with a 2017 median household income of $126,257 and the 20% of households that are severely rent- burdened (spend more than 50% of household income on rent) is a gap that is widening. The Income Diversity Ratio (income earned by 80th percentile divided by income earned by 20thpercentile) has risen to 9.2, the fourth highest in the city. A major contributor to this disparity is the lack of affordable housing. Affordable housing increases opportunities for long-time residents to remain in their community, as well as new residents, especially younger ones, to find homes in the community. The home ownership rate (co-ops, condos, and single-family houses) has risen from 29.2% in 2000 to 40.2% in 2017 while the number of rentals has declined in the same time span.
MCB7 has identified the most prevalent categories of affordable housing in the community district and has identified needs and recommendations, based on these types.
image
Mitchell Lama Preservation – Many Mitchell-Lama buildings in MCB7 have already or will soon reach the end of their regulatory periods. This means the buildings no longer legally must be kept at affordable rents, and
many have already opted to go market-rate. There are 11 Mitchell-Lama developments in MCB7 with 1,749 units and, on average, the buildings are almost 60 years old.
image
image
District Need: HPD has announced a Mitchell-Lama Reinvestment program as part of Housing NY 2.0. As this Community District is a high-rent area, Mitchell-Lama units in our community should be prioritized for preservation whenever it is indicated that they are vulnerable to going market-rate. We urge the NYS Division of Housing and Community Renewal (HCR) to place all Mitchell-Lama building under rent stabilization guidelines without regard to their date of construction if they are removed from the Mitchell-Lama program. HPD and/or HCR should aim for the longest possible regulatory period for these properties, to ensure that they remain in MCB7’s affordable housing stock and provide moderate- and middle-income housing for our community.
image
Housing Development Finance Corporations (HDFC) Cooperatives - These shareholder-owned HDFC cooperatives, which benefit from reduced real estate taxes in exchange for following certain standards for the selling and renting of apartments, are an important source of affordable homeownership for MCB7.
Unfortunately, mismanagement of these HDFC coops has resulted in many being in a condition of insolvency and in disrepair.
image
image
District Need: HPD should assist mismanaged HDFCs by providing financial management training. Required quarterly check-ins to oversee building finances should be instituted. No monitor or manager should be required in HDFCs that are currently financially healthy and do not have extensive capital needs. HPD should work with the HDFCs to extend affordability and the tax abatement for all existing HDFCs. HPD should provide subsidies to replenish the HDFC reserves, if needed, and pay for capital improvements, provided certain terms set by HPD to ensure future solvency are followed.
image
Rent-regulated housing
image
image
Rent stabilized housing
MCB7 welcomes recent legislation in Albany that eliminated the vacancy bonus, ‘luxury’ decontrol, preferential rents, income caps, and the four-year ‘look-back’ period. Restrictions were placed on the amount of major capital improvements (MCI) and individual apartment improvements (IAI) that can be passed to tenants and the time period of such charges. Various tenant harassment and eviction practices that had been utilized against all renters were also eliminated. MCB7 has long called for an end to these practices and thanks the legislators who worked so hard to end them.
image
image
image
Preservation – Speculation has been a problem in the Upper West Side for decades and is now affecting tenants at the northern boundary (Manhattan Valley) of the CD who are seeing their buildings that contain many rent-stabilized units purchased for exorbitant prices, with the assumption that the new owner will be able to increase the rent rolls. With the recent rent law changes, we are concerned about speculators defaulting on mortgages and allowing buildings to fall into disrepair.
image
image
image
image
District Need: HPD’s Neighborhood Pillars program should provide financial and technical assistance to nonprofit developers to purchase and renovate buildings in Manhattan Valley. HPD should institute long-term Regulatory Agreements to keep rent-stabilized units affordable
image
image
image
Reclaiming Rent-Stabilized Units – Because rent stabilization depends on self-reporting of landlords to the Division of Homes and Community Renewal, some units have been priced higher than their legal rent or have not been re-registered after temporary destabilization. Tenants have unknowingly rented these apartments and paid illegally high rents. Many apartments were deregulated and became market-rate housing. New legislation has ended the four-year ‘look-back’ period to claim redress for overcharges. However, although overcharges may be found, reimbursement can only be made for the preceding six years.
image
image
image
image
District Need: The City should work with lawmakers in Albany to ensure that reimbursement for overcharges must be made for the entire period of those overcharges and re-stabilize the affected apartments.
image
image
Senior Housing: One-fifth (20.1%) of the 2017 population of MCB7 is aged 65 or older, an increase from 16.7% in 2010. The percentage of seniors in Manhattan is 16%; 12.4% in New York City. They need appropriate housing and social services that enable them to continue age in place in the communities where they have spent their adult lives.
image
image
District Need: The NYS Department for the Aging funds Naturally Occurring Retirement Communities (NORCs), where health and social services are provided in buildings with a substantial population of seniors. The City should work with DFTA to actively promote and fund more NORCs for our growing senior residents.
⦁ District Need: Encourage the inclusion of compact units appropriately outfitted with safety devices, such as grab bars and bannisters, in the affordable housing components in the new residential buildings currently under construction in the District. These are separate from micro-units as seniors may need daily or live-in home help.
image
image
image
District Need: In 2017, 11.7% of households in the CD where at least one person was more than 65 years of age lived below the poverty line. Thousands of seniors and residents eligible for the Senior Citizen Rent Increase Exemption (SCRIE) and the Disability Rent Increase Exemption (DRIE) are not currently enrolled in those programs, and therefore may be paying more rent than necessary, despite their limited income. HPD should enhance community outreach to senior centers and non- profit organizations to provide more information, including informational sessions, to ensure that every qualifying resident is getting the proper rent increase exemptions.
image
SROs: MCB7 is home to more than 200 single room occupancy (SRO) buildings with 13,364 dwelling units. These units continue to be the most affordable options for young singles, older veterans, the chronically ill, the formerly homeless and low-income individuals. Economic opportunity has motivated many SRO owners to
convert their buildings (often contrary to zoning and housing regulations) from affordable permanent dwellings into transient hotels and/or Air BNBs, thereby removing affordable SRO units from the rental market.
image
image
District Need: Existing SROs should be rent regulated through preservation financing and regulatory agreements to ensure they are properly maintained and rented as permanent affordable housing. HPD should work with qualified nonprofits and joint venture partnerships of nonprofit and for-profit entities to purchase and rehabilitate these SROs. Additionally, when feasible, the SROs should be converted into supportive housing to serve the most vulnerable in our City.
⦁ Find New Opportunities for Affordable Housing Development: Although the number of new, very tall residential towers is rising in the southern end of the district, almost all are as-of-right – through a series of zoning lot mergers and transfer of development rights (TDR) – and therefore are not required to provide affordable housing. Virtually no buildings are being built that primarily provide affordable housing. The decline of existing affordable housing and the lack of replacement housing requires exploration of supplemental sources.
image
District Need: The City should explore new development of micro units, infill development on public land, and connecting faith-based organizations with trusted developers to develop on underutilized land owned by faith- based organizations.
The City should survey the publicly-owned land in the district and look for underbuilt lots. Lots containing one-story firehouses, police stations, libraries and other such community services could be built out with brand new facilities for these city agencies and incorporate affordable housing above.
image
District Need: The City should look to the possibility of requiring special permits for buildings over a certain size that would require permanent affordable housing in such buildings based on the amount of additional height due to zoning lot mergers and TDFs.
⦁ Increase the Availability of Mixed-Income Housing: There has been a significant reduction in the availability of housing that is accessible to those with incomes at 100-150 percent of AMI. Rents are at an all-time high, making MCB7 virtually inaccessible to young adults (including those who cannot afford to live in the communities in which they grew up), young families, and retirees. New construction all too often creates residential units that sell or rent at luxury rates beyond the reach of many New Yorkers earning moderate incomes.
image
District Need: Developers should be incentivized to include a mix of income levels in any new development in the Community District.
⦁ Provide Tenants with the Necessary Knowledge and Resources to Fight for their Rights: Residents remain unaware of their options for recourse in the event of an abusive or law-breaking landlord. Some residents lack knowledge of potential services, or enter into contracts with landlords known to be abusive. Thanks to the 2017 Right to Counsel Legislation, tenants facing eviction and who meet certain income tests are eligible to have an
attorney represent them in Housing Court free of charge. As this program is rolled out to all of the Upper West Side, it is important that the City closely monitor the need and resources available to ensure the program lives up to its intentions.
image
District Need: Create programs that rate building managers and owners to inform potential residents of existing problems and corrective services. This should include a full rollout of the Certificate of No Harassment Program in MCB7.
⦁ District Need: Continue outreach to tenants in MCB7 so that they are aware of the availability of free counsel to those who qualify in Housing Court. Our local nonprofits providing legal services should be receiving whatever resources they need to do this important work.
⦁ Warehousing and Short-Term Rentals: Affordable housing units are lost due to warehousing and illegal short term rentals and Air BNBs. City Council has passed legislation to further monitor this illegal activity.
image
District Need: In order to enforce any new regulation or legislation, monitoring of suspected short-term rentals should be enhanced, as well as the response to 311 complaints.
New York City Housing Authority (NYCHA)
The District includes over 30 buildings and approximately 7,400 units. There are smaller buildings scattered in the community and two large developments – Amsterdam Houses and Frederick Douglass Houses – which are all managed by NYCHA. Wise Towers and the “Brownstones” are part of a Rental Assistance Demonstration (RAD) program, which is a public-private partnership that will provide funding to rehabilitate those buildings. It is imperative that during the conversion to the RAD program all tenants, local service organizations and elected officials be actively involved in all stages of the process.
image
Lack of funding and resources for capital needs and operating expenses have contributed to multiple problems. NYCHA and the residents of our community face many challenges including: inadequate security, broken elevators, leaking roofs, inadequate or no heating, major plumbing problems, mold, lead paint, electrical outages, inadequate trash removal, unsanitary conditions, pest infestations, inadequate staffing levels, poor maintenance, a labyrinthine process for addressing individual maintenance needs (i.e. a leaking pipe may require 4 to 6 separate tickets and visits before the problem is fixed), lack of data, leaking roofs; and inadequate funding for resident services, youth and senior centers. Mold, pests, other unsanitary conditions and lead paint cause multiple illnesses in residents, especially those at greatest risk: young children, the elderly and those with compromised immune systems. Seniors, the disabled and those who have difficulty climbing stairs are often shuttered in their apartments when the elevators are not working.
Many residents need access to subsidized or complementary child care in order to work and attend school. There is a large percentage of seniors in the NYCHA developments in CD7.
image
District Need:
The City needs to develop a data collection and response system.
It needs to quickly and efficiently address the abatement of mold and lead paint.
New security equipment is needed and existing equipment must be adequately maintained.
All NYCHA developments in CD7 need increased funding for staff, sanitation supplies and equipment.
Elevators must be repaired and/or upgraded.
Programs for seniors and youth must be adequately funded and maintained.
Several buildings at Amsterdam Houses are scheduled for boiler replacement, elevator replacement, playground updates and other upgrades for FYs 2019, 2020 and 2022. Several buildings at Frederick Douglass I and II are scheduled for new bulk crushers, new fire alarm systems, gas riser replacement, exterior site lighting and playground updates. These are essential, but do not adequately address the problems facing the residents of these complexes.
Needs for Economic Development
Small businesses are vital to the Upper West Side community. However, when you speak with our neighborhood shops, restaurants and bar owners, they often express frustration with the regulatory burdens posed on them by government, and how the market forces are changing the way they operate.
Fines, bureaucratic red tape, high rent, taxes, increasing labor costs and lawsuits make it challenging for our local businesses to thrive, and even survive. Online shopping, innovations and changes in purchasing behavior are transforming the business environment.
The NYC Department of Small Business Services (SBS) is an agency that serves as an important resource to this sector. Unfortunately, it is often subject to the same bureaucratic logjams as the actual businesses. If SBS were able to recommend modifications of existing regulations or appoint a dedicated watchdog division, it could coordinate more adeptly between the relevant agencies. In a landmark building or historic district such as the Upper West Side, requirements by the Landmarks Preservation Commission (LPC) often do not comport with those of NYC Department of Consumer Affairs, nor the NYC Department of Buildings. These issues become exceptionally burdensome to many of the small businesses in our community, especially as they pertain to ADA (Americans with Disabilities Act) compliance. Specifically, because so many grade level stores and restaurants are located in older buildings in which entrances and plumbing cannot be modified, they are continuously exposed to fines by LPC and other agencies, as well as spurious lawsuits issued by private individuals.
SBS should work with Community Boards, small business owners, Business Improvement Districts (BIDs) and other business associations to develop a list of proposed regulatory reforms, policies and programs that will support local businesses and eliminate bureaucratic red tape, and to designate an agency tasked with overall regulatory oversight over small businesses.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
1/25 NYCHA Renovate or
upgrade public housing developments
Plumbing and sewer systems. $25M Allocate funding to upgrade plumbing and sewer systems at Wise Consolidation Housing Complexes and Douglass Houses. 38 brownstones at Wise are using outdated Cooper B Union Shower Bodies long past their 60-year expiration.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
5/34
NYCHA
Renovate or
Additional funds for skilled trades personnel and
upgrade public
resident skilled trades training at Amsterdam
housing
Houses, Frederick Douglass Houses, Wise
developments
Towers Consolidated and DeHostos. NYCHA
developments in CD7 have a significant backlog
of repair requests in residents apartments.
Repairs are made when there are enough of
them to warrant the issuance of a contract.
Having skilled trades (plumbers, electricians,
carpenters) do the work at these developments
would result in timely repairs, a reduction of the
backlogs and increased well-being for the
residents. Furthermore, more resources need to
be put into training NYCHA residents to fill the
jobs that should be directed at addressing the
backlog of repair requests.
6/34
NYCHA
Other housing
Additional HPD headcount for Code
oversight and
Enforcement inspectors. Post rent reform, more
emergency
of the housing stock may suffer from a lack of
programs
repairs or ongoing investment. Additional
inspectors will ensure that no tenants live in
squalid or unsafe conditions due to a lack of
investment by landlords and enforcement by the
city.
TRANSPORTATION
Manhattan Community Board 7
image
M ost Important Issue Related to Transportation and Mobility
Other
Street Safety: MCB7 continues to prioritize safety of all users of streets, across the district. CB7 places particular urgency in protecting human life Over the past years, the NYC Department of Transportation (DOT) has implemented safety upgrades at many intersections, including the West End Avenue Corridor and into 2018 has proposed additional corridors for improvements. While the deaths and serious injury rates have declined, we need to do better in our efforts to achieve Vision Zero. MCB7 recommends the use of tools that will improve safety, including: curb extensions, pedestrian islands, protected bike lanes, mid-block bulb-outs, split-phase signals, leading pedestrian intervals, raised crosswalks, left turn bans, Barnes Dances, narrowed lanes, abrupt changes in road surface, and lower speed limits - all tools which, when implemented district-wide, could reduce speeding and failure to yield (two leading causes of pedestrian deaths). MCB7 welcomes a comprehensive district-wide analysis of transportation issues, with immediate consideration given to issues including: - ● Continued monitoring of Commercial Loading Zones - along the redesigned Amsterdam and Columbus Avenues and also along Central Park West and West End Avenue - to support the increased need for delivery use while reducing and hopefully eliminating the blockage of travel lanes by double parked vehicles ● Enforcement. CB7 requests enforcement of the 25 mile per hour speed limit, and the 20 mile per hour speed limit around all schools, which will improve pedestrian and student safety. Specific safety measures include: - Countdown timers at all intersections to alert pedestrians to the amount of time they have for a safe crossing of the street. This is especially important for people with disabilities and seniors. - “Stop Here on Red” Signs for left turns on every street on Broadway to ensure that motorists know they must stop in the median of the “Broadway Malls” and wait for a green light before proceeding.
Striping, Signage and neckdowns which alert motorists that they are entering a school block and will improve safety for students traveling to and from school - Red Light Cameras to discourage drivers from running the lights - Speed Cameras/Speed Signs to reduce speeding on our streets to reduce serious crashes and injuries - Left Turn Calming measures - more pedestrians are injured by left turning vehicles - Daylighting at every corner - Increased enforcement of traffic violations especially speeding, failure to yield and running red lights. - Increased enforcement of motor vehicles standing or parked illegally in bike lanes is also a concern - Portable breath tests which the PD has stated are effective and needed in MCB7
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
7 Bike paths, including 2 protected bike lanes
50 Citibike Stations (though not all presently open)
14 NYC Transit bus routes
7 MTA subway routes, 14 stations
70% of MCB7 workers travel by mass transit Crashes:
YTD in 2018 (through 11/6/18), there have been 1,632 crashes reported to NYPD, with 267 injuries (95 pedestrian, 50 cyclist, 122 motorists).
Injuries:
Over the past years, the NYC Department of Transportation (DOT) has implemented safety upgrades at many intersections, including the West End Avenue Corridor and into 2018 has proposed additional corridors for improvements.
The number of transportation-related injuries has decreased nearly 20% in the past year. While the deaths and serious injury rates have declined, we need to do better in our efforts to achieve Vision Zero.
MCB7 recommends the use of tools that will improve safety, including: curb extensions, pedestrian islands,
protected bike lanes, mid-block bulb-outs, split-phase signals, leading pedestrian intervals, raised crosswalks, left turn bans, Barnes Dances, narrowed lanes, abrupt changes in road surface, and lower speed limits - all tools which, when implemented district-wide, could reduce speeding and failure to yield (two leading causes of pedestrian deaths).
MCB7 welcomes a comprehensive district-wide analysis of transportation issues, with immediate consideration given to: -
The corridor between 95th and 100th Streets, superblock west of Central Park West.
Continued monitoring of Commercial Loading Zones - along the redesigned Amsterdam and Columbus Avenues and also along Central Park West and West End Avenue, which CB7 has extensively studied this year - to support the increased need for delivery use while reducing
and hopefully eliminating the blockage of travel lanes by double parked vehicles.
Narrow the travel lanes on West 66th Street between Amsterdam and West End Avenues, along with curb extensions in order to discourage speeding on the wide street. (A similar design was implemented on 70th Street.)
Change the timing on the traffic signal at 66th Street and West End Ave to discourage speeding to make the light.
Addition of crosstown protected bike lanes
Add signage at the 79th & 96th St interchanges of the Henry Hudson Pkwy alerting motorists of the 25 mph speed limit unless otherwise posted, NYC Law-No Right turns at red lights.
Recommend a study of the crosstown block of West 94th Street
Install a 96th Street exit option for southbound traffic on the Henry Hudson Parkway. This will relieve the intense traffic on the narrower and residential 95th Street. Allowing traffic to exit onto 96th Street will provide direct travel to the Central Park transverse and provide a safer pedestrian experience on 95th Street, which was never intended to be a major thoroughfare.
Concurrently, MCB7 encourages continued measures to ensure pedestrian safety throughout the district, including:
Data. CB7 hopes to have complete data on the top 10 collision-prone intersections/areas of the District, understanding that this need is constantly updating and evolving
Enforcement. CB7 requests enforcement of the 25 mile per hour speed limit, and the 20 mile per hour speed limit around all schools, which will improve pedestrian and student safety.
Specific safety measures include:
Countdown timers at all intersections to alert pedestrians to the amount of time they have for a safe crossing of the street. This is especially important for people with disabilities and seniors.
“Stop Here on Red” Signs for left turns on every street on Broadway to ensure that motorists know they must stop in the median of the “Broadway Malls” and wait for a green light before proceeding.
Striping, Signage and neckdowns which alert motorists that they are entering a school block and will improve safety for students traveling to and from school
Red Light Cameras to discourage drivers from running the lights, especially at Central Park West and 63rd, 86th, 96th and 97th Streets, West End Avenue at 66, 72, 79 and 96th Streets.
Install radar devices alerting motorists of their current speed.
Speed Cameras/Speed Signs to reduce speeding on our streets to reduce serious crashes and injuries - Left Turn Calming measures - more pedestrians are injured by left turning vehicles
Daylighting at every corner, as well as the most dangerous intersections
Safety improvements for Columbus Circle to enable pedestrians and bicyclists to safely navigate
the circle including traffic calming measures, signage and striping
Traffic light mid-block on 106th Street between Columbus and Amsterdam Avenue to enable seniors and those with disabilities to safely cross the street mid-block between two senior residences, the Jewish Home Life and Red Oak Apartments. DOT said they would explore the feasibility of making a light push-button activated when someone wanted to cross.
Increased enforcement of traffic violations especially speeding, failure to yield and running red lights.
Increased enforcement of motor vehicles standing or parked illegally in bike lanes is also a concern - Portable breath tests which the PD has stated are effective and needed in MCB7
Protected Bike Lane on 110th Street and safety improvements for Frederick Douglass Circle
Shared Streets:
The “Complete Streets” on Amsterdam and Columbus Avenues create new challenges for MCB7 to
balance the needs of pedestrians, cyclists, motorists and local businesses. Loading Zones are a serious concern for local businesses and residents, because it reduces curbside parking. Some have argued that raising the price and timing of metered parking would increase turn over at available curbside spaces.
Double Parking has become a problem on all the Avenues in MCB7. MCB7 requests that DOT implement as soon as possible the loading zone plan adopted by MCB7 for Central Park West and West End Avenue to mitigate this problem.
Mixing Zones: Mixing Zones increase the risk for cyclists, who often cannot be seen by the driver of the motor vehicle and there have been some serious injuries.
Pedestrian Islands provide refuge and shorter crossing distances for pedestrians and thrill gardeners who enjoy tending the tree pits.
The mixing zones where motor vehicles enter the bike lanes to turn create a danger for cyclists who are often in the blind spot for the driver of the vehicle.
Shared Sidewalks: The increased congestion on sidewalks of local residents, tourists and visitors has emboldened street vendors to take advantage of new markets. The proliferation of food trucks and sidewalk vendors frustrates Upper West Siders because of the lack of enforcement and/or licensing.
Additionally, street furniture (newsstands, bus shelters, bike rack, news boxes, pay phones, mail boxes, benches, etc.) and sidewalk cafes overcrowd the sidewalks. MCB7 encourages a comprehensive approach to optimizing shared use and management of sidewalks to eliminate obstructions and visual clutter.
MCB7 encourages minimizing permanently enclosed sidewalk cafes especially after they have become vacant.
Except in rare circumstances, enclosed cafes unduly narrow the sidewalk and cause pedestrian congestion. Perhaps a mechanism could be created to guarantee the removal of structures when they become vacant.
Parking: While car ownership by residents of MCB7 is down, MCB7 residents have strong and varied opinions about the amount of paid private garage space to be allocated in the district. Increasing the amount of free parking would likely contribute to increased pollution, congestion, frustration, etc. The goal is to balance the need for access to motor vehicles while minimizing the negative aspects.
Alternatives to Private Motor Vehicles:
Emerging Technologies: CB7 supports the exploration of emerging technologies that can be implemented in the district as a way to safely and more equitably move people, goods and services within the District and throughout the City. These technologies include, but are not limited to: bike share, pedal- assist and motorized bikes, ride share/ride hail, electric scooters, autonomous vehicles, and civilian and possibly commercial drones. In many cases, these technologies can serve as valuable "last mile" solutions to successfully transport people to mass transit, which remains the most feasible option for the majority of CB7 residents, if funding and service issues are improved.
These technologies also could help more efficiently and safely move goods to retail establishments or to the elderly or health care providers. CB7 believes that the use of these emerging technologies, if regulated responsibly, could align with and potentially advance CB7's core priorities related to a clean environment, affordable housing, equity among residents, and overall pedestrian and residential safety.
Congestion Pricing: MCB7 continues to support congestion pricing and supports a lock box that will ensure that all funds raised go to mass transit. This will help advance the MTA’s Fast Forward plan, which would raise funds for transit improvements (see below), reduce congestion and improve air quality.
Bike ridership: Bike ridership has grown rapidly in the district, with Citibike expansion into MCB7, the protected bike lanes on Columbus and Amsterdam Avenue, and additional bike paths. More people are riding to and from work, on errands and for recreational purposes. Ensuring safety for cyclists & pedestrians is paramount, as is educating cyclists to obey the rules of the road and bike safely. We look forward to receiving DOT’s further proposals to build out a comprehensive network of protected bike lanes in order to promote safe and efficient cycling.
Additional District Needs: Street and Sidewalk Improvements.
Heavy use by motor vehicles, combined with a high number of utility cuts and the high volume of sleet and snow over the past few years have created poor street conditions in MCB7. Many of our blocks are riddled with ruts, potholes, faded striping and bad curbs. These conditions produce unsafe conditions for both vehicles and pedestrians. Significant resurfacing of the streets is needed, including decreasing the amount of time between
milling to paving.
Sidewalks are in need of repair throughout MCB7, especially at street corners where water ponds. Many sidewalks have violations near sidewalk vaults on Amsterdam Avenue and Broadway. The replacement of a sidewalk vault requires special engineering and is often cost-prohibitive. MCB7 recommends that other methods be looked at to coat existing sidewalk surfaces over vaulted areas, when replacement is not feasible.
Budget Priorities for Transportation Thermoplastic street markings
With many lane markings fading, as well as lane alignments shifting, it is vitally important for safety that the Department of Transportation have the requisite funds in their budget for painting and maintaining lane markings, pedestrian crossings, and no-parking zones. (New)
"NYC Law-no right on red", "NYC Speed Limit 25mph unless otherwise posted" signs
There is a lack of signage where the Henry Hudson Parkway exits on to West Side streets, at the 79t h Street and 95t h -96t h Street exits. As this may the first place vehicles are actually on NYC streets from their point of origin, it is essential that New York City's rules & regulations be visible to motorists who may not be aware of them.
Additionally, there is a paucity of speed limit signage throughout the West Side. (FY1628;FY1728)
Street-scape safety improvements
Safety at many street intersections could be helped by simple- to- build street improvements. Bulb-outs with sidewalk extensions help decrease the turning radius to slow turning vehicles and shorten the crossing distance for the pedestrian. Starting with those improvements identified in CB7’s Nelson- Nygaard study of the West 90’s, and reviewed and approved by CB7- traffic islands, curb extensions, and simple traffic guiding changes should be implemented to make this area safer. Beginning with the corners in CB7 identified as the most dangerous to cross - those reported with failure to yield
crashes, violations, and those reported with vehicles turning with excessive speed - corner curb extensions should be implemented to slow turning vehicles and shorten the pedestrian crossing. In the most dangerous intersections overall, directed lane treatments, islands, signal changes, countdown signals, and raised crosswalks should all be considered, reviewed, and implemented for what would effectively improve safety. (FY1423; FY158; FY1610;FY171)
Street and curb lane resurfacing ($200K/lane mile)
There are 193.6 lane miles of paved streets in CD7, slightly more than 10% of the lane mileage of all of Manhattan. The huge increase in street cuts for utility work, including fiber optics and cable, and construction has left CD7’s streets in dire shape. Side streets and intersections are particularly rutted.
Many blocks on Broadway, Amsterdam Avenue and Columbus Avenue have ruts as deep as 6 inches in the parking lanes near the curbs. (FY0514; FY0611; FY0812; FY0813; FY0918; FY109; FY1115; FY124; FY132; FY1414; FY1515; FY1618;FY177)
Visually Handicapped - Accessibility
Those of our community with handicaps, are frequently unable to share in a quality of life open to others and a free access to the world outside their homes. Moving along the streets, the visually handicapped have no way of knowing if it is safe to cross the street We are recommending that audible signals be developed by DOT to indicate red lights. (FY1512; FY1626;FY179)
Riverside Drive, West 104t h-110t h Streets ($2.95M) Pedestrian-initiated traffic crossings in Central Park
Electric and other infrastructure, and programming capacity, to coordinate traffic signals in Central Park electronically, including providing the ability for pedestrian walk signals to be activated by "push buttons" when pedestrians want to cross the Drives. The traffic signals in Central Park were installed decades ago, essentially to govern private motor vehicle traffic, which has increasingly been prohibited in the Park. CB7 supports, at a
minimum, a trial period during which all private motor vehicles would be prohibited from using the Drives at all times. But currently, regardless of time of day and the amount of motor traffic and other conditions in the Park, the signals on the Drives can only be governed manually. The confusion among cyclists as to whether they must to stop at red lights when no pedestrians are crossing, and the failure of many cyclists to do so -- among other factors -- has highlighted the need to provide up to date functionality to the traffic signal system in Central Park, so that the thousands of recreational users -- pedestrians (including runners), cyclists, skaters, etc. -- can be made as safe as possible from collisions on the Drives. (FY1612;FY1713)
Curb-cuts
DOT does not have funding to repair existing curb-cuts/pedestrian ramps. CB7 is conducting a survey of all curb-cuts in the district. Phase One of the survey covering 57 curb-cuts from West 60t h-89t h Streets identified the following conditions: 10 super-bad; i.e.: basically impassable, require immediate fix; 23 severe cases; definitely high-priority and should be repaired as soon as possible; 15 bad but not yet terrible, yet if allowed to deteriorate would probably become severe cases; 9 not great but not good; bear watching. (FY133; FY149; FY1521; FY168;FY1716)
Speed cameras throughout MCD7
Speeding near schools continues to be a problem throughout the district, with some areas, such as West 95th/West 96th Street-with nearby entrances/exits to the Henry Hudson Parkway, a particular
concern. Strategically placed speed cameras would make the areas close to schools much safer for children and all pedestrians. (FY1419; FY155;FY169;FY1717)
Red light cameras throughout MCD7
Failure to yield & running red/amber lights with the resultant vehicular/pedestrian accidents resulting in serious injury and/or loss of life - continues to be a serious concern throughout the district. The placement of red light cameras - particularly in areas known to be at a high risk for vehicular/pedestrian conflicts - would send a strong message to operators of vehicles that speeding and improper/illegal movements will not be tolerated, and violators will be prosecuted to the fullest extent of the law. (FY1419; FY1524; FY1615;FY1719)
Variable traffic signal timing (Pilot)
Many intersections have variable crowd conditions depending on time of day - for instance, when schools let out, the PM rush hour, the AM rush, etc. DOT has said they cannot at this time program traffic signals by time of day. We believe this technology is important for safety, and must be pursued. (FY147; FY1525; FY1617;FY1721)
Speed/red light camera pilot to enforce TLC (only) violations (Pilot)
Pending a check of the legality of such a program, this would catch TLC-licensed vehicles who are speeding or running red lights, or other illegal movements. (FY1630;FY1727)
Needs for Transit Services
Subways: MCB7 has the 3rd highest numbers of subway commuters in New York City. It is served by two major subway lines with 7 routes. Along Broadway the 1 serves local and the 2,3 serve express stations.
Along Central Park West the B/C lines serve local and express stations and the A/D serve express stations. On the Central Park West Line more trains after rush hour (“shoulder” periods) are urgently needed to alleviate long wait times and overcrowding. Service cuts have caused most off-peak trains to be overcrowded. While additional cars are being added to the C line, more frequent service is needed. We believe transit signal prioritization of certain key intersections can speed bus service (see below).
Buses: Bus service district-wide needs to improve. MCB7 supports on-street supervision to improve NYC Transit’s
response of actual operating conditions, especially on weekends. M104 truncated at Times Square continues to impact thousands of riders who relied on one-seat ride to E 42n d. M11 service levels are
insufficient to handle growing demand, especially among the elderly M60 which connects the Upper West Side to Central Harlem and La Guardia Airport, a major success for the MTA, needs to be extended further south to Broadway/96th Street area. Select Bus Service, which is now on the M79 and M86 routes, needs to be added to the M96 route. Subway Elevators and escalators
Funding for elevators and escalators in all subway renovations. (FY1730)
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/25
DOT
Improve traffic and
Fund speed and red light cameras (including
pedestrian safety,
dummy cameras throughout MCD7.) Failure to
including traffic
yield & running red/amber lights with the
calming (Capital)
resultant vehicular/pedestrian accidents
resulting in serious injury and/or loss of life -
continues to be a serious concern throughout
the district. The placement of red light cameras
particularly in areas known to be at a high risk
for vehicular/pedestrian conflicts - would send a
strong message to operators of vehicles that
speeding and improper/illegal movements will
not be tolerated, and violators will be
prosecuted to the fullest extent of the law.
(FY1419; FY1524;
FY1615;FY1719;FY1821;FY195;FY205)
9/25
DOT
Improve traffic and
Fund street-scape safety improvements. $1M
pedestrian safety,
Safety at many street intersections could be
including traffic
helped by simple- to- build street improvements.
calming (Capital)
Locations include the northbound service road
on Riverside Drive, the 95th St exit from the
Henry Hudson Pkwy, 97th & Riverside Drive,
95th & Riverside Drive, 96th & West End Ave,
66th St between Amsterdam & West End Aves.
Bulb-outs with sidewalk extensions help
decrease the turning radius to slow turning
vehicles and shorten the crossing distance for
the pedestrian. Starting with those
improvements identified in CB7s Nelson-
Nygaard study of the West 90s, and reviewed
and approved by CB7- traffic islands, curb
extensions, and simple traffic guiding changes
should be implemented to make this area safer.
10/25
DOT
Roadway
Fund street and curb lane resurfacing:There are
maintenance (i.e.
193.6 lane miles of paved streets in CD7, slightly
pothole repair,
more than 10% of the lane mileage of all of
resurfacing, trench
Manhattan. The huge increase in street cuts for
restoration, etc.)
utility work, including fiber optics and cable,
and construction has left CD7s streets in dire
shape. Side streets and intersections are
particularly rutted. Many blocks on Broadway,
Amsterdam Avenue and Columbus Avenue have
ruts as deep as 6 inches in the parking lanes
near the curbs.
14/25
DOT
Improve traffic and
Visually Handicapped - Accessibility Those of our
pedestrian safety,
community with handicaps, are frequently
including traffic
unable to share in a quality of life open to
calming (Capital)
others and a free access to the world outside
their homes. Moving along the streets, the
visually handicapped have no way of knowing if
it is safe to cross the street We are
recommending that audible signals be
developed by DOT to indicate red lights.
(FY1512;
FY1626;FY179;FY1811;FY196;FY2019)
16/25
DOT
Improve traffic and
The purpose would be to catch TLC-licensed
pedestrian safety,
vehicles who are speeding or running red lights,
including traffic
or other illegal movements. Given the
calming (Capital)
prevalence of such vehicles, special enforcement
resources are warranted.
20/25
NYCTA
Improve
Making all of the subway stations in MCD7
accessibility of
accessible to handicapped and mobility-
transit
challenged riders is and will continue to be a
infrastructure, by
priority, as most of the stations in the district
providing elevators,
remain inaccessible to wheelchair users. Getting
escalators, etc.
more people on our subways and buses is a key
component in getting visitors and residents to
their destinations quickly and safely.
24/25
DOT
Improve traffic and
Funding for an Upper West Side pilot for
pedestrian safety,
variable traffic signal timing. Many intersections
including traffic
have variable crowd conditions depending on
calming (Capital)
time of day - for instance, when schools let out,
the PM rush hour, the AM rush, etc. DOT has
said they cannot at this time program traffic
signals by time of day. We believe this
technology is important for safety, and must be
pursued.
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
image
18/34 DOT Add street signage
or wayfinding elements
There is a lack of signage where the Henry Hudson Parkway exits on to West Side streets, at the 79th Street and 95th -96th Street exits. As this may the first place vehicles are actually on NYC streets from their point of origin, it is essential that New York City's rules & regulations be visible to motorists who may not be aware of them. Additionally, there is a paucity of speed limit signage throughout the West Side.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 7
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Community board resources (offices, staff and equipment)
Increase Community Board budgets by baselining the City Council’s grant. Community boards have not received a budget increase for non-personnel costs in more than twenty years. Meanwhile, costs and demands for services have increased dramatically. The NYC Council included one-time grants of $42.5K for each community board in the FY19 and FY20 budgets. The Council imposed specific restrictions on how the funds may be used. Baselining this amount without restrictions will enable the boards to plan their budgets and continue their vital service role. (FY084; FY096; FY101; FY111, FY121; FY131; FY141; FY151; FY161;FY171;FY181;FY191;FY201)
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Major Public Parks
image
image
Riverside Park - 267 acres Riverside Park South – 23 acres
image
image
Theodore Roosevelt Park – 17.5 acres Central Park (shared with CB 8, 10, 11 and 5)
image
11 Public Playgrounds
image
image
59th Street Recreation Center (Gertrude Ederle Recreation Center) 6 Small Parks and Broadway Malls
Parks Serving Community District 7
Riverside Park
Theodore Roosevelt Park Central Park
Straus Park
Verdi Square Park
Community District 7 boasts access to two of Manhattan's (and New York City's) most revered parks: Central Park, which forms the entire eastern border of CD7, and Riverside Park and Riverside Park South, which forms the entire western border. Both of these parks were initially laid out by the seminal landscape architects Frederick Law Olmsted and Calvert Vaux, although both parks show the effects of subsequent revisions and renovations. These two parks provide space for both active and passive recreation. In addition, CD7 is home to 11 playgrounds under the jurisdiction of the Department of Parks and Recreation ("DPR"), as well as a host of playgrounds appurtenant to public schools and under the exclusive jurisdiction of the Department of Education ("DoE").
CD7 encompasses an additional 35.5 acres of parkland in smaller parks, including Straus Park at West 106th Street; Theodore Roosevelt Park at West 77-81 Street; Verdi Square Park at West 72nd Street; Dante Park at West 63rd Street; Tucker Square Park at West 66th Street; and the system of Broadway Malls. Central Park is administered through a contract with the Central Park Conservancy. DPR maintains the remaining parkland with 10 *fact
check full-time workers, including a full-time horticulturist, as well as with seasonal workers and job-training participants, all of whom are essential to maintaining this parkland and running programs in these spaces to serve the public's needs.
Issues Affecting DPR's Ability to Serve the Community's Needs
Structural Funding Challenges
Parks funding, especially for capital requirements, is an inadequate percentage of the overall City budget. For example, Chicago spends more on parks than does New York City, even though Chicago's population is one-third the size. In addition, critical funding for both operating expenses and capital improvements for parks is left to year-by- year negotiations between the offices of the Mayor and City Council, and relies heavily on ad-hoc funding from Council Member items, the portion of the City budget under the discretion of the Borough President, and other
one-off and non-baselined funding streams. Funding is not driven by an integrated needs assessment or a long-term vision, but rather is frequently provided, if at all, on a project-by-project basis.
Equity and Inclusiveness
Equity and inclusion are increasingly recognized as issues in park funding and management. Certain parks, most notably Central Park through the Central Park Conservancy, and to a more modest extent Riverside Park through the Riverside Park Conservancy (f/k/a the Riverside Park Fund), enjoy unprecedented access to private donations and independent fundraising. Smaller neighborhood parks in CD7, like many similar spaces throughout our City, have no or limited access to such funding. Within CD7, the disparity in access to funding and its impact on the experience in public open space can readily be demonstrated by a comparison of the overall conditions of playgrounds north of West 96th Street versus those to the south. The Community Parks Initiative instituted by the Parks Department is a first step in addressing this disparity. Like many long-term solutions, the first step is to recognize the existence of the problem. The Community Parks Initiative decentralizes the task of meeting local needs by inquiring directly of local users and neighbors of parks and playgrounds what resources they most value, and in what priority certain investments should be made. While the funding disparity of our most storied and popular urban parks will remain, this Initiative creates a mechanism for responsiveness
Accessibility 2.0
Inclusion issues are not limited to funding disparities. Community Board 7 (CB7) has led an effort to introduce a broader approach to accessibility beyond the obligation to make open space reachable to those with mobility challenges. Through a dedicated Task Force, CB7 has spearheaded a successful effort to envision a truly inclusive Bloomingdale Playground, where children of varying degrees of mobility can not only gain entry to a common space, but can actually participate in shared activities.
The Need for a Broader Vision
The experiences of seeking one-off funding streams for individual projects, and the effort to re-imagine how play spaces can be organized and built to include the entire population, highlights the need for proactive creativity in visioning park usage and funding. Too often park funding finds projects that continue existing programs or uses without any consideration of new opportunities or potentially unmet needs. For example, CD7 includes only one outdoor public swimming pool, located at Frederick Douglass Playground. The potential for such visioning can be found through the Summer on the Hudson initiative, which brings exercise classes, cultural programs, movies, and innovative active and passive recreation opportunities to Riverside Park during the warmer months. Engaging in a visioning effort to capture evolving needs and the potential for our existing open space to meet them may also spawn as-yet untapped funding sources.
Competing Needs and Users
A separate set of issues confronting our parks and open spaces concerns competing uses that are at times at odds or even mutually exclusive. In bottleneck areas in Riverside and Central Parks, the confluence of pedestrians, cyclists, skaters, runners and others can create conflicts not easily solved with the limited funding for infrastructure changes or staffing. In parkland used for public plazas such as Columbus Circle, Frederick Douglass Circle, and Lincoln Center, the use of spaces for skateboarding can compete with the more passive recreation uses for which this plazas were intended.
The Impact of Climate Change
Re-envisioning the use of parkland and the funding to support it should include starting now to plan for the effects of climate change. Every scientific study confirms the inevitability of sea-level rises in the foreseeable future, and the entirety of CD7 is bordered to the west by the Hudson River. The vulnerability of Riverside Park to frequent storm surges and violent storms, as well as the erosion those phenomena leave behind, must be a part of our forward-looking planning. Climate change also brings with it a much longer season for park usage, requiring a new vision for staffing and an altered maintenance schedule.
Needs for Cultural Services
Several community centers bring diverse programming and support services to residents of the Upper West Side.
Needs for Library Services
CD7 is home to three NYPL branches and the Performing Arts Library at Lincoln Center. Local demand is increasing for a variety of library services, and our libraries have become even more important community centers, providing internet access for communications, job-search resources, and self-improvement and skill-building.
Bloomingdale Branch St.Agnes Branch
Riverside Branch Performing Arts Branch
The Bloomingdale branch is currently closed for much-needed renovations that are expected to include a dedicated space for teen use, bathroom renovations, and a greater number of computers for public use, all desperately needed in a community that has experienced increased demand from successful outreach and from increased residential construction nearby. New carpeting and lighting are also still needed, as are dedicated computers and separate spaces for children and older adult users. Of these needs, the purchase of new furniture for the teen space and related equipment, estimated at $100,000, is a priority.
In addition, the Bloomingdale Branch has recently reclaimed a large basement space that is ripe for investment and development into the types of uses such as programming, computer access and support for those using the branch libraries as conduits for job searches and understanding benefits and rights that this mixed-income community needs. Seizing this space and converting it to productive community use must be a priority, although the NYPL has no direct funding available for such a project.
Continuing current funding adequate to sustain a fully staffed 6-day schedule is essential, especially for providing vital resources to low-income residents. This funding is not baselined, and must be renewed annually. Moreover, the branch libraries in our district and beyond are still struggling with staffing levels that were set during the period of fiscal retraction after the economic downturn over a decade ago. The increased demand for a plethora of library and community services should be reflected in enhanced funding sufficient to reclaim the staffing lost to a previous era.
The Performing Arts Library at Lincoln Center is a City-wide treasure of singular expertise and importance. Its facility is showing the wear of its frequent use and the demands that new technologies and new preservation techniques demand of its diverse collection. While the entire City that benefits from this extraordinary facility should likewise share in its restoration and upkeep, MCB7 is proud to take leadership roles in ensuring these needs are met for the present and future.
Needs for Community Boards
CB7 provides tremendous value to the district, employing a staff of 3 people and the work of 50 dedicated volunteer board members to improve lives on the Upper West Side.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/25
NYPL
Create a new, or
Renovation of the Basement of the
150 West 100
renovate or upgrade
Bloomingdale Branch Library appx $4M. The
Street
an existing public
basement of the Bloomingdale branch library
library
(on West 100th Street between Amsterdam and
Columbus Avenues) was rescued from moribund
dead storage of useless items during FY 2016,
and has been laying fallow (apart from use as a
staging area for maintenance efforts and
supplies) ever since. The raw space presents an
unprecedented opportunity to meet a variety of
needs of the community that the Bloomingdale
branch library serves. The the basement space
could be configured to accommodate computer
resources, programming space for health,
wellness and fitness programs, additions to the
hard copy collections, and community meetings
and outreach efforts by the NYPL and by local
community groups.
5/25
DPR
Reconstruct or
Full renovation of the playground an pool areas
upgrade a building
(estimate t/b/d); repaving the handball courts
in a park
($325K).
7/25
DPR
New equipment for
Purchase pickup trucks with snow plow, salt
maintenance
spreader and Tommy lift gate, one each for
(Capital)
Riverside Park and District 7; and Toolcat multi-
purpose vehicles, including snow plow, snow
brush, cleaning brush and front-end loader
bucket, one each for Riverside Park and District
7; and a mini-packer for garbage collection
($110,000). These vehicles are necessary for the
park operations. They will permit far more
efficient deployment of the limited number of
staff personnel, reduce or eliminate waiting
times for existing shared vehicles to become
available and/or to be repaired, and reduce
unnecessary use of fuel. Council Member Helen
Rosenthal allocated funds for several vehicles
several years ago, but heavy use, additional
wear and tear on existing vehicles being highly
important to operations.
8/25
DPR
Reconstruct or
Renovate the playground, including new play
upgrade a building
equipment, safety surface (the element of the
in a park
playground that is in the worst condition),
drinking fountain, lighting, fencing and
landscaping. This playground will have access to
comfort station facilities that will be
incorporated into a new building being
constructed immediately to the west of the site.
11/25
NYPL
Create a new, or
Renovate the Performing Arts Library (Lincoln
Lincoln Cent
renovate or upgrade
Center) The Performing Arts Library serves both
an existing public
local and City-wide needs. The Performing Arts
library
Library boasts a vigorous circulation and is
heavily used, and enhances the cultural identity
and resources of our Upper West Side
community. The building is in need of extensive
need of system-wide structural renovation,
including foundation waterproofing; sidewalk
replacement and drainage management; safety
and security upgrades such as improved exterior
lighting, replacement of exterior doors and
security cameras; as well as replacement of the
HVAC systems including steam pressure
stations, air compressors and steam heaters.
The A/C component is critical is critical the
preservation of fragile manuscripts, scores, etc.
12/25
DPR
Reconstruct or
Cherry Walk, Riverside Park, 100th to 129th
upgrade a park or
Streets, at the Hudson River. $5M Full
amenity (i.e.
reconstruction of the existing bicycle and
playground, outdoor
pedestrian path is desperately needed, including
athletic field)
repaving the existing asphalt path, installing
new park security lighting, and reconstructing
sections of the existing rip rap edge and the
landscape between the Henry Hudson Parkway
and Hudson River. The Cherry Walk is part of the
Hudson River Greenway. Since it was
constructed nearly two decades ago, and
particularly as other sections of the Greenway
to the north and south of this segment have
been opened, the number of cyclists using the
Cherry Walk, both commuters and recreational
cyclists, has exploded. The Cherry Walk is also
heavily used by walkers and runners. See the
Riverside Park Master Plan (2016).
13/25
DPR
Reconstruct or
Gertrude Ederle Recreation Center, West 60th
upgrade a building
Street. Replace skylight over the multi-purpose
in a park
room, built in the early 1900s, in the old portion
of the building. During heavy rains, activities in
the gym and fitness room currently have to be
suspended because of leaking, which is
damaging the rubber floor.
15/25
DPR
Reconstruct or
Dinosaur Playground, West 97th Street,
upgrade a building
Riverside Park Reconstruct the playground,
in a park
including new play equipment and swings,
safety surface, refurbish bathrooms in the
adjacent comfort station, which would be made
accessible for people with disabilities.
17/25
DPR
Reconstruct or
These paths and sidewalk areas are badly
Riverside Park
upgrade a park or
deteriorated and have suffered severely from
& Riverside
amenity (i.e.
the past lack of routine maintenance. The
Drive West 95
playground, outdoor
project would include drainage, retaining walls
West 110
athletic field)
and steps in this area.
18/25
DPR
Reconstruct or
These bluestone stairs are an important
upgrade a park or
pedestrian route between the river level and the
amenity (i.e.
Promenade level of the park, and they are badly
playground, outdoor
deteriorated.
athletic field)
19/25
DPR
Reconstruct or
NYC DOT is in the final design stage for a
upgrade a park or
massive reconstruction project at the 79th
amenity (i.e.
Street Rotunda. However, that project does not
playground, outdoor
include restoration or improvements to adjacent
athletic field)
park landscapes or structures. These bluestone
stairs and pathway, which provide pedestrian
access from Riverside Drive through to the east
side of the Rotunda, are badly deteriorated. It is
highly desirable that they be restored in the
same time frame as the Rotunda itself.
21/25
DPR
Reconstruct or upgrade a building in a park
Restore the interior and exterior of the Monument, provide ADA access to the terrace and restore the plaza areas. A recent engineering study commissioned by OMB concluded that this 115-year old monument dedicated to the Union Army is in an advanced state of deterioration. Since that report, the upper terraces and stairs adjacent to the Monument itself have been closed off with wire fencing to protect the public from falling stonework. The entire site is literally falling apart, with loosened joints, chipped stone and various other types of damage from the passage of time and from vandalism. The estimated cost to restore only the Monument building is $13M, but DPR and consultants recommend doing the entire project at one time.
West 89 Street and Riverside Dr
22/25
DPR
Reconstruct or upgrade a building in a park
Matthew Sapolin Playground, West 70th Street, PS199. Upgrade the playground, including resurfacing the pavement around spray shower, replacing the safety surface, and replacing the backboards.
23/25
DPR
Reconstruct or upgrade a building in a park
Restore perimeter sidewalk - Central Park The Parks perimeter sidewalks along Central Park West have buckled and present tripping hazards. Hex pavers, curbs and benches would be replaced. Columbus Circle has been reconstructed, and the CPW sidewalks in its immediate vicinity have been restored. The section of the sidewalk between 86th and 90th Streets was recently reconstructed as part of a landscape restoration project of the Central Park Conservancy. The remaining sections of the CPW sidewalk along Central Park from 77th Street to 109th Street still need funding for restoration.
25/25 DPR Provide a new or
expanded park or amenity (i.e. playground, outdoor athletic field)
The West 69th Street Transfer Bridge in Riverside Park off of West 69th Street is a unique relic of the industrial history of the Riverside Park South area as a major freight rail yard. The plans for Riverside Park South have always included restoration of the Transfer Bridge. Phase 2 of the restoration is fully funded and is in the final design phase. That final design phase has continued for an unusually long time because of issues involving getting electric power to the site, as well as the federal funding source, which requires additional levels of review. Phase 3 would connect the Transfer Bridge with the adjacent Esplanade, allowing members of the public to access the Transfer Bridge itself for recreational and educational uses.
image
CS DPR Other park facilities and access requests
The kayak dock at 72nd Street and the Hudson in Riverside Park needs to be repaired in order to restore the free kayaking program that it serves. Non-profit volunteer groups conducted a free program from the time the dock was installed there in 2003 through 2015. Over 90,000 people participated. In the spring of 2016, one of the dock’s pilings failed, making the launching site unusable, and the free kayaking program had to be suspended pending restoration of the dock and its underwater infrastructure. Borough President Brewer and Council Member Helen Rosenthal allocated
$195,000 and $210,000 respectively for FY18.
The final cost of the project depends upon a series of factors and the involvement of various governmental agencies, and cannot be determined without additional investigation.
image
CS DPR Reconstruct or upgrade a building in a park
Renovate the schoolyard, which serves P.S. 84 and the adjacent community, into a multi- purpose play area with synthetic turf that can be fully utilized by the students during the school day and neighborhood youths after school and on weekends. Council Member Helen Rosenthal has allocated $750,000, which has been assigned to the School Construction Authority to do the work. Because the project has been funded but not done, CB7 lists it for continuing support.
Expense Requests Related to Parks, Cultural and Other Community Facilities
image
Priority Agency Request Explanation Location
image
1/34 OMB Other community
board facilities and staff requests
Community boards have not received a budget increase for non-personnel costs in more than twenty years. Meanwhile, costs and demands for services have increased dramatically. The NYC Council included one-time grants of $42.5K for each community board in the FY19 and FY20 budgets. The Council imposed specific restrictions on how the funds may be used.
Baselining this amount without restrictions will enable the boards to plan their budgets and continue their vital service role. (FY084; FY096; FY101; FY111, FY121; FY131; FY141; FY151; FY161;FY171;FY181;FY191;FY201)
image
7/34 DPR Enhance park safety
through more security staff (police or parks enforcement)
Park Enforcement Personnel (PEP officers) for Riverside Park and District 7. Community District 7 is covered by the 16 city funded PEP that report out of North Meadow in Central Park.
They cover both the east and west sides of Manhattan from 59th Street to 125th Streets, and Riverside Park. They also help cover other calls that fixed post officers in Central Park cannot cover. In addition four fixed-post officers, who are paid for under dedicated funding, patrol Riverside Park South and are available in Riverside Park only for emergency conditions.
An additional eight officers and a sergeant ($60K per officer, more for a sergeant) for Manhattan would increase safety and help address graffiti and other vandalism, littering, skateboarding, homeless, alcohol, off-leash, smoking, etc.
image
11/34
NYPL
Extend library hours
Increase NYPL Staff and Operating Budget.
or expand and
While the operation of branch and research
enhance library
libraries have been stabilized, and 6-day service
programs
at most locations has been restored, those
restorations were made by the City Council and
were not baselined. Branch libraries increasingly
serving as a lifeline to vulnerable constituents
for services as varied as access to jobs and
computer resources to research and
recreational reading to safe havens for teens
and youth. It is critical that this lifeline that
branch libraries represent to the entire
community be available 7 days a week in our
District. In addition, only in the last one- to two
years have branches begun to have sufficient
budget room to begin to replace the
professional staff lost to reductions and
attrition.
13/34
DPR
Other park
Permanent staffing for Districts 7 and 14
maintenance and
(Riverside Park). Parks full-time workforce is
safety requests
responsible for park maintenance and
cleanliness: (Associate Park Service Workers,
City Parks Workers, and Gardeners). Additional
funds are needed to rebuild the agencys
permanent, year-round workforce
14/34
DPR
Provide a new or
Solar trash compactors help control the rat
expanded park or
population. The installation of solar trash
amenity (i.e.
compactors has been successful in, for example,
playground, outdoor
Theodore Roosevelt Park. Two compactors are
athletic field)
needed for Straus Park, and approximately 13-
16 compactors deployed at various playgrounds
in District 7 could substantially help to reduce
the rat population.
20/34
DPR
Provide better park
Pest control personnel. The rodent population in
maintenance
parks has exploded in recent years. In District 7,
Verdi Square, Straus, Theodore Roosevelt and
Riverside Parks, the Broadway Malls, and
several playgrounds have had extreme rodent
infestations. A second dedicated exterminator
for District 7 and Riverside Park would allow
Parks to address infestations through a variety
of systematic and sustainable measures,
including the newly available dry ice method,
which, like more traditional methods, requires a
licensed exterminator.
21/34 DPR Provide better park
maintenance
Synthetic Turf Field Maintenance Crew. $330K Establish a crew to repair and maintain the six synthetic turf fields in Community District 7.
DPRs synthetic turf installations experience heavy use throughout the year, as well as the effects of severe winters. These funds would allow DPR to contract for regular service to repair and maintain these synthetic surfaces, in order to extend their useful lives and prevent injuries to the youth and adults who use them.
image
24/34 DPR Provide more programs in parks or recreational centers
Playground Associates. Eight playground associates would provide valuable programming and supervision for children, assist with park maintenance and provide a safety presence from July through Labor Day in Frederick Douglass Playground (West 100th/Amsterdam), Happy Warrior Playground (West 98th/Amsterdam), Sol Bloom Playground (West 91st/Columbus), Tecumseh Playground (West 77th/Amsterdam), Bennerson Playground (West 64th/Amsterdam Houses), Neufeld Playground (West 76th/Riverside Park), Dinosaur Playground (West 97th/Riverside Park) and River Run Playground (Wests 83rd Street/Riverside Park).
image
28/34 DPR Provide better park
maintenance
DPR has more than 8,400 street trees in District
This does not include the trees in Central and Riverside Parks. While DPR looks to adjacent building owners to maintain, including voluntary plantings, the beds of street trees, DPR itself does not have any service to maintain the tree beds. In many tree beds, the soil becomes so compacted that water and air cannot reach the tree roots. DPR should have a service that assures that all street trees will thrive. A program in MCD7 addressed, at a minimum, to maximizing the DPR partnership with private neighbors, would demonstrate the importance of tree stewardship; the diversion of rain water away from sidewalks and sewers; and the value of disruption of disruption of rat burrows.
image
image
29/34 DPR Provide better park
maintenance
DPR has more than 8,400 street trees in District
7. This does not include the trees in Central and Riverside Parks. Many of these street trees have dead branches; most have not been trimmed for a long time. When stumps remain in place, trees cannot be replanted. Funding for emergency pruning and stump removal and a 10-year pruning cycle would make it possible for Parks to respond more rapidly to requests for tree pruning and stump removal, would reduce safety concerns, and would allow replacement of trees that have been removed.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
23/34
Other
Other expense
Funding for financial, legal, and psychological
budget request
support for individuals to decide whether or not
to file claims under the Child Victims Act during
and after the one-year look back window. The
public focus on child sexual abuse means that
even among people who do not file claims,
there is a retraumatization that may occur for
which supportive services are necessary.
27/34
Other
Other expense
The Mayor's Office to End Domestic and
budget request
Gender-Based Violence recently opened a
Learning Lab at the NYC Family Justice Center in
Manhattan to provide economic empowerment
programming for people who have experienced
domestic and gender-based violence. Funding
for a pilot program in Community District 7 that
implements the Learning Lab (ENDGBV) model
with a dedicated focus on Community District
residents is needed to ensure equitable access.
33/34
Other
Other expense
Funding for staff from the New York City Law
budget request
Department/Corporation Counsel’s Office to
track numbers of claims filed under the CVA as
well as outcomes
34/34
Other
Other expense
Funding for mental health services in jails and
budget request
for justice-involved youth transitioning from
jails.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
NYCHA
Renovate or
Plumbing and sewer systems. $25M Allocate
upgrade public
funding to upgrade plumbing and sewer
housing
systems at Wise Consolidation Housing
developments
Complexes and Douglass Houses. 38
brownstones at Wise are using outdated Cooper
B Union Shower Bodies long past their 60-year
expiration.
2/25
NYPL
Create a new, or
Renovation of the Basement of the
150 West 100
renovate or upgrade
Bloomingdale Branch Library appx $4M. The
Street
an existing public
basement of the Bloomingdale branch library
library
(on West 100th Street between Amsterdam and
Columbus Avenues) was rescued from moribund
dead storage of useless items during FY 2016,
and has been laying fallow (apart from use as a
staging area for maintenance efforts and
supplies) ever since. The raw space presents an
unprecedented opportunity to meet a variety of
needs of the community that the Bloomingdale
branch library serves. The the basement space
could be configured to accommodate computer
resources, programming space for health,
wellness and fitness programs, additions to the
hard copy collections, and community meetings
and outreach efforts by the NYPL and by local
community groups.
3/25
DOT
Improve traffic and
Fund speed and red light cameras (including
pedestrian safety,
dummy cameras throughout MCD7.) Failure to
including traffic
yield & running red/amber lights with the
calming (Capital)
resultant vehicular/pedestrian accidents
resulting in serious injury and/or loss of life -
continues to be a serious concern throughout
the district. The placement of red light cameras
particularly in areas known to be at a high risk
for vehicular/pedestrian conflicts - would send a
strong message to operators of vehicles that
speeding and improper/illegal movements will
not be tolerated, and violators will be
prosecuted to the fullest extent of the law.
(FY1419; FY1524;
FY1615;FY1719;FY1821;FY195;FY205)
4/25
SCA
Renovate other site
The DoE/SCA 2020-24 Capital Plan includes
component
$750 million in new funding to make schools
either compliant with the Americans with
Disabilities Act (“ADA”) The goal of the Capital
Plan in this regard is to convert one-third of the
approximately 1,400 school buildings in the NYC
DoE system to some level of accessibility. Given
the funding and goals of the 2020-24 Capital
Plan, a reasonable goal would be to ensure that
one-third of District 3 schools are fully
accessible or susceptible of affording students
and faculty a reasonable accommodation by the
end of the Capital Plan. This would amount to
converting an additional 8 buildings to
accessibility, with those buildings equitably
distributed throughout the District and
appropriately split between elementary and
middle schools.
5/25
DPR
Reconstruct or
Full renovation of the playground an pool areas
upgrade a building
(estimate t/b/d); repaving the handball courts
in a park
($325K).
6/25
DFTA
Renovate or
Space and renovation of the senior center at
885
upgrade a senior
Douglass Houses to be run by DFTA. This could
Columbus
center
be the seed of a NORC in a community where
Ave
there are more than 1000 underserved seniors.
(DFTA)
7/25
DPR
New equipment for
Purchase pickup trucks with snow plow, salt
maintenance
spreader and Tommy lift gate, one each for
(Capital)
Riverside Park and District 7; and Toolcat multi-
purpose vehicles, including snow plow, snow
brush, cleaning brush and front-end loader
bucket, one each for Riverside Park and District
7; and a mini-packer for garbage collection
($110,000). These vehicles are necessary for the
park operations. They will permit far more
efficient deployment of the limited number of
staff personnel, reduce or eliminate waiting
times for existing shared vehicles to become
available and/or to be repaired, and reduce
unnecessary use of fuel. Council Member Helen
Rosenthal allocated funds for several vehicles
several years ago, but heavy use, additional
wear and tear on existing vehicles being highly
important to operations.
8/25 DPR Reconstruct or
upgrade a building in a park
Renovate the playground, including new play equipment, safety surface (the element of the playground that is in the worst condition), drinking fountain, lighting, fencing and landscaping. This playground will have access to comfort station facilities that will be incorporated into a new building being constructed immediately to the west of the site.
image
9/25 DOT Improve traffic and
pedestrian safety, including traffic calming (Capital)
Fund street-scape safety improvements. $1M Safety at many street intersections could be helped by simple- to- build street improvements. Locations include the northbound service road on Riverside Drive, the 95th St exit from the Henry Hudson Pkwy, 97th & Riverside Drive, 95th & Riverside Drive, 96th & West End Ave, 66th St between Amsterdam & West End Aves. Bulb-outs with sidewalk extensions help decrease the turning radius to slow turning vehicles and shorten the crossing distance for the pedestrian. Starting with those improvements identified in CB7s Nelson- Nygaard study of the West 90s, and reviewed and approved by CB7- traffic islands, curb extensions, and simple traffic guiding changes should be implemented to make this area safer.
image
10/25 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Fund street and curb lane resurfacing:There are
193.6 lane miles of paved streets in CD7, slightly more than 10% of the lane mileage of all of Manhattan. The huge increase in street cuts for utility work, including fiber optics and cable, and construction has left CD7s streets in dire shape. Side streets and intersections are particularly rutted. Many blocks on Broadway, Amsterdam Avenue and Columbus Avenue have ruts as deep as 6 inches in the parking lanes near the curbs.
image
image
11/25
NYPL
Create a new, or
Renovate the Performing Arts Library (Lincoln
Lincoln Cent
renovate or upgrade
Center) The Performing Arts Library serves both
an existing public
local and City-wide needs. The Performing Arts
library
Library boasts a vigorous circulation and is
heavily used, and enhances the cultural identity
and resources of our Upper West Side
community. The building is in need of extensive
need of system-wide structural renovation,
including foundation waterproofing; sidewalk
replacement and drainage management; safety
and security upgrades such as improved exterior
lighting, replacement of exterior doors and
security cameras; as well as replacement of the
HVAC systems including steam pressure
stations, air compressors and steam heaters.
The A/C component is critical is critical the
preservation of fragile manuscripts, scores, etc.
12/25
DPR
Reconstruct or
Cherry Walk, Riverside Park, 100th to 129th
upgrade a park or
Streets, at the Hudson River. $5M Full
amenity (i.e.
reconstruction of the existing bicycle and
playground, outdoor
pedestrian path is desperately needed, including
athletic field)
repaving the existing asphalt path, installing
new park security lighting, and reconstructing
sections of the existing rip rap edge and the
landscape between the Henry Hudson Parkway
and Hudson River. The Cherry Walk is part of the
Hudson River Greenway. Since it was
constructed nearly two decades ago, and
particularly as other sections of the Greenway
to the north and south of this segment have
been opened, the number of cyclists using the
Cherry Walk, both commuters and recreational
cyclists, has exploded. The Cherry Walk is also
heavily used by walkers and runners. See the
Riverside Park Master Plan (2016).
13/25
DPR
Reconstruct or
Gertrude Ederle Recreation Center, West 60th
upgrade a building
Street. Replace skylight over the multi-purpose
in a park
room, built in the early 1900s, in the old portion
of the building. During heavy rains, activities in
the gym and fitness room currently have to be
suspended because of leaking, which is
damaging the rubber floor.
14/25
DOT
Improve traffic and
Visually Handicapped - Accessibility Those of our
pedestrian safety,
community with handicaps, are frequently
including traffic
unable to share in a quality of life open to
calming (Capital)
others and a free access to the world outside
their homes. Moving along the streets, the
visually handicapped have no way of knowing if
it is safe to cross the street We are
recommending that audible signals be
developed by DOT to indicate red lights.
(FY1512;
FY1626;FY179;FY1811;FY196;FY2019)
15/25
DPR
Reconstruct or
Dinosaur Playground, West 97th Street,
upgrade a building
Riverside Park Reconstruct the playground,
in a park
including new play equipment and swings,
safety surface, refurbish bathrooms in the
adjacent comfort station, which would be made
accessible for people with disabilities.
16/25
DOT
Improve traffic and
The purpose would be to catch TLC-licensed
pedestrian safety,
vehicles who are speeding or running red lights,
including traffic
or other illegal movements. Given the
calming (Capital)
prevalence of such vehicles, special enforcement
resources are warranted.
17/25
DPR
Reconstruct or
These paths and sidewalk areas are badly
Riverside Park
upgrade a park or
deteriorated and have suffered severely from
& Riverside
amenity (i.e.
the past lack of routine maintenance. The
Drive West 95
playground, outdoor
project would include drainage, retaining walls
West 110
athletic field)
and steps in this area.
18/25
DPR
Reconstruct or
These bluestone stairs are an important
upgrade a park or
pedestrian route between the river level and the
amenity (i.e.
Promenade level of the park, and they are badly
playground, outdoor
deteriorated.
athletic field)
19/25
DPR
Reconstruct or
NYC DOT is in the final design stage for a
upgrade a park or
massive reconstruction project at the 79th
amenity (i.e.
Street Rotunda. However, that project does not
playground, outdoor
include restoration or improvements to adjacent
athletic field)
park landscapes or structures. These bluestone
stairs and pathway, which provide pedestrian
access from Riverside Drive through to the east
side of the Rotunda, are badly deteriorated. It is
highly desirable that they be restored in the
same time frame as the Rotunda itself.
20/25
NYCTA
Improve
Making all of the subway stations in MCD7
accessibility of
accessible to handicapped and mobility-
transit
challenged riders is and will continue to be a
infrastructure, by
priority, as most of the stations in the district
providing elevators,
remain inaccessible to wheelchair users. Getting
escalators, etc.
more people on our subways and buses is a key
component in getting visitors and residents to
their destinations quickly and safely.
21/25
DPR
Reconstruct or
Restore the interior and exterior of the
West 89
upgrade a building
Monument, provide ADA access to the terrace
Street and
in a park
and restore the plaza areas. A recent
Riverside Dr
engineering study commissioned by OMB
concluded that this 115-year old monument
dedicated to the Union Army is in an advanced
state of deterioration. Since that report, the
upper terraces and stairs adjacent to the
Monument itself have been closed off with wire
fencing to protect the public from falling
stonework. The entire site is literally falling
apart, with loosened joints, chipped stone and
various other types of damage from the
passage of time and from vandalism. The
estimated cost to restore only the Monument
building is $13M, but DPR and consultants
recommend doing the entire project at one
time.
22/25
DPR
Reconstruct or
Matthew Sapolin Playground, West 70th Street,
upgrade a building
PS199. Upgrade the playground, including
in a park
resurfacing the pavement around spray shower,
replacing the safety surface, and replacing the
backboards.
23/25
DPR
Reconstruct or
Restore perimeter sidewalk - Central Park The
upgrade a building
Parks perimeter sidewalks along Central Park
in a park
West have buckled and present tripping
hazards. Hex pavers, curbs and benches would
be replaced. Columbus Circle has been
reconstructed, and the CPW sidewalks in its
immediate vicinity have been restored. The
section of the sidewalk between 86th and 90th
Streets was recently reconstructed as part of a
landscape restoration project of the Central
Park Conservancy. The remaining sections of the
CPW sidewalk along Central Park from 77th
Street to 109th Street still need funding for
restoration.
24/25 DOT Improve traffic and
pedestrian safety, including traffic calming (Capital)
Funding for an Upper West Side pilot for variable traffic signal timing. Many intersections have variable crowd conditions depending on time of day - for instance, when schools let out, the PM rush hour, the AM rush, etc. DOT has said they cannot at this time program traffic signals by time of day. We believe this technology is important for safety, and must be pursued.
image
25/25 DPR Provide a new or
expanded park or amenity (i.e. playground, outdoor athletic field)
The West 69th Street Transfer Bridge in Riverside Park off of West 69th Street is a unique relic of the industrial history of the Riverside Park South area as a major freight rail yard. The plans for Riverside Park South have always included restoration of the Transfer Bridge. Phase 2 of the restoration is fully funded and is in the final design phase. That final design phase has continued for an unusually long time because of issues involving getting electric power to the site, as well as the federal funding source, which requires additional levels of review. Phase 3 would connect the Transfer Bridge with the adjacent Esplanade, allowing members of the public to access the Transfer Bridge itself for recreational and educational uses.
image
CS DPR Other park facilities and access requests
The kayak dock at 72nd Street and the Hudson in Riverside Park needs to be repaired in order to restore the free kayaking program that it serves. Non-profit volunteer groups conducted a free program from the time the dock was installed there in 2003 through 2015. Over 90,000 people participated. In the spring of 2016, one of the dock’s pilings failed, making the launching site unusable, and the free kayaking program had to be suspended pending restoration of the dock and its underwater infrastructure. Borough President Brewer and Council Member Helen Rosenthal allocated
$195,000 and $210,000 respectively for FY18.
The final cost of the project depends upon a series of factors and the involvement of various governmental agencies, and cannot be determined without additional investigation.
image
image
CS DPR Reconstruct or upgrade a building in a park
Renovate the schoolyard, which serves P.S. 84 and the adjacent community, into a multi- purpose play area with synthetic turf that can be fully utilized by the students during the school day and neighborhood youths after school and on weekends. Council Member Helen Rosenthal has allocated $750,000, which has been assigned to the School Construction Authority to do the work. Because the project has been funded but not done, CB7 lists it for continuing support.
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/34
OMB
Other community
Community boards have not received a budget
board facilities and
increase for non-personnel costs in more than
staff requests
twenty years. Meanwhile, costs and demands
for services have increased dramatically. The
NYC Council included one-time grants of $42.5K
for each community board in the FY19 and FY20
budgets. The Council imposed specific
restrictions on how the funds may be used.
Baselining this amount without restrictions will
enable the boards to plan their budgets and
continue their vital service role. (FY084;
FY096; FY101; FY111, FY121; FY131;
FY141; FY151;
FY161;FY171;FY181;FY191;FY201)
2/34
DOE
Other educational
Support for students performing below grade
programs requests
level on in-school and standardized assessments
/ appx $500K The Department of Education
recently awarded a grant of $500,000 to each of
several school districts that are undertaking
initiatives to identify and support efforts to
increase diversity or end segregation of
students based on race, ethnicity, performance
level, and/or special needs status. District 3 /
Community District 7 has already undertaken
such initiatives, and is now working to address
the needs of students who have scored below
grade level on various in-school or standardized
assessments. District 3 should receive
equivalent funding in order to continue its work
to achieve its goals of increasing diversity while
meeting the needs of all students. (FY20 [new])
3/34
DHS
Other facilities for
Funding for permanent supportive housing units
the homeless
for people transitioning from shelters.
requests
4/34
DHS
Other request for
4) Funding for more beds for victims of domestic
services for the
violence, including beds specifically for people
homeless
who identify as transgender or gender
nonconforming.
5/34 NYCHA Renovate or
upgrade public housing developments
Additional funds for skilled trades personnel and resident skilled trades training at Amsterdam Houses, Frederick Douglass Houses, Wise Towers Consolidated and DeHostos. NYCHA developments in CD7 have a significant backlog of repair requests in residents apartments.
Repairs are made when there are enough of them to warrant the issuance of a contract. Having skilled trades (plumbers, electricians, carpenters) do the work at these developments would result in timely repairs, a reduction of the backlogs and increased well-being for the residents. Furthermore, more resources need to be put into training NYCHA residents to fill the jobs that should be directed at addressing the backlog of repair requests.
image
6/34 NYCHA Other housing
oversight and emergency programs
Additional HPD headcount for Code Enforcement inspectors. Post rent reform, more of the housing stock may suffer from a lack of repairs or ongoing investment. Additional inspectors will ensure that no tenants live in squalid or unsafe conditions due to a lack of investment by landlords and enforcement by the city.
image
7/34 DPR Enhance park safety
through more security staff (police or parks enforcement)
Park Enforcement Personnel (PEP officers) for Riverside Park and District 7. Community District 7 is covered by the 16 city funded PEP that report out of North Meadow in Central Park.
They cover both the east and west sides of Manhattan from 59th Street to 125th Streets, and Riverside Park. They also help cover other calls that fixed post officers in Central Park cannot cover. In addition four fixed-post officers, who are paid for under dedicated funding, patrol Riverside Park South and are available in Riverside Park only for emergency conditions.
An additional eight officers and a sergeant ($60K per officer, more for a sergeant) for Manhattan would increase safety and help address graffiti and other vandalism, littering, skateboarding, homeless, alcohol, off-leash, smoking, etc.
image
image
8/34 DYCD Provide, expand, or
enhance the Summer Youth Employment Program
Summer Youth Employment Programs serve several compelling needs. They provide alternatives to gang influence for at-risk youth; provide models and pathways to employment; develop positive work habits and self-esteem; and virtually every dollar earned is spent in the community. In addition, without the availability of this work force, community-based organizations serving children and youth cannot meet their adult-to-child ratios, making those programs less effective. SYEP has finally emerged from a 5-year period in which serial budget cuts all but decimated the program.
Thanks to renewed and baselined funding, a
record of over 74,000 youth were included in SYEP in the summer of 2018. Nevertheless, some 89,000 applicants were left without a placement.
image
9/34 DYCD Provide, expand, or
enhance after school programs for elementary school students (grades K- 5)
Maintain baseline funding for after-school and OST programs in public schools and in neighborhood CBOs in MCD7. Afterschool programs ensure that children are safe in the hours between the end of school and the end of their families' work day, when they would otherwise be most vulnerable, and provide opportunities for remedial instruction, enrichment, and safe play. Certain of these same programs continue to provide these same safe and affirming environments during school breaks in the summer. Education and NYPD specialists have advised CB7 that an effective means to address increased gang and crew activity, especially in NYCHA campuses and adjacent parks and playgrounds, would be to have safe places for youth and teens to meet and spend time outside the influence of gang activity.
image
image
10/34
DSNY
Provide more
Baseline the FY20 increase in funds for street
frequent litter
litter basket services. CD7’s 1,000 litter baskets
basket collection
are never empty – and often they are
overflowing. The one-year increase in funding
allows DSNY to service each basket within a 24-
hour period instead of the 36+ hour service that
was in place. The current service helps keep
streets and sidewalks clean, with fewer
incidents of rodent infestation and clogged
catch basins and street drains, and reduces
floatables in the Hudson River. (FY076;
FY0810; FY0919; FY1023; FY118; FY123;
FY134; FY1413; FY157;
FY1626;FY1716;FY1817;FY
11/34
NYPL
Extend library hours
Increase NYPL Staff and Operating Budget.
or expand and
While the operation of branch and research
enhance library
libraries have been stabilized, and 6-day service
programs
at most locations has been restored, those
restorations were made by the City Council and
were not baselined. Branch libraries increasingly
serving as a lifeline to vulnerable constituents
for services as varied as access to jobs and
computer resources to research and
recreational reading to safe havens for teens
and youth. It is critical that this lifeline that
branch libraries represent to the entire
community be available 7 days a week in our
District. In addition, only in the last one- to two
years have branches begun to have sufficient
budget room to begin to replace the
professional staff lost to reductions and
attrition.
12/34
DOHMH
Other programs to
Funding for vision screening and free access to
address public
prescription glasses for youth to improve school
health issues
participation and success.
requests
13/34
DPR
Other park
Permanent staffing for Districts 7 and 14
maintenance and
(Riverside Park). Parks full-time workforce is
safety requests
responsible for park maintenance and
cleanliness: (Associate Park Service Workers,
City Parks Workers, and Gardeners). Additional
funds are needed to rebuild the agencys
permanent, year-round workforce
14/34
DPR
Provide a new or
Solar trash compactors help control the rat
expanded park or
population. The installation of solar trash
amenity (i.e.
compactors has been successful in, for example,
playground, outdoor
Theodore Roosevelt Park. Two compactors are
athletic field)
needed for Straus Park, and approximately 13-
16 compactors deployed at various playgrounds
in District 7 could substantially help to reduce
the rat population.
15/34
DOE
Other educational
15) Provide Funding for Additional STEAM AP
programs requests
Courses. Other than the 8 Specialized High
Schools, there are relatively few high schools in
the system, and fewer still in Manhattan, that
offer all of the Advanced Placement courses
essential to students with ambitions in the
sciences (i.e. AP Calculus AB and BC; AP
Chemistry; AP Biology; and AP Physics), and
fewer still that combine those offerings with
accomplished offerings in the Arts. The number
of high schools offering this enhanced STEAM
curriculum is essential to any equity and
diversity program, both for the students who
aspire to but do not gain admission to the
Specialized High Schools, and to those who seek
a different high school experience and deserve
an equal opportunity for this enhanced learning
program.
16/34
DOE
Other educational
Adequate child care is a necessity for working
programs requests
families. The Mayor's initiative to expand all-
day pre-K, together with expanded Head Start
programming, is funded under the Early Learn
initiative, are proven drivers of achievement in
school for years to come as well as stability for
working families. It is essential that the funding
for these programs, baselined in FY15, continue
at least at the current programming levels to
deliver both the services families need as well as
certainty essential to good planning by service
providers, families and ancillary services.
17/34
HRA
Provide, expand, or
To increase participation/enrollment in SNAP,
enhance food
funding for staff to conduct outreach and assist
assistance, such as
people in completing applications.
Food Stamps / SNAP
18/34
DOT
Add street signage
There is a lack of signage where the Henry
or wayfinding
Hudson Parkway exits on to West Side streets,
elements
at the 79th Street and 95th -96th Street exits. As
this may the first place vehicles are actually on
NYC streets from their point of origin, it is
essential that New York City's rules &
regulations be visible to motorists who may not
be aware of them. Additionally, there is a
paucity of speed limit signage throughout the
West Side.
19/34
DFTA
Increase home
Funding for higher reimbursement rates for
delivered meals
meals for the elderly
capacity
20/34
DPR
Provide better park
Pest control personnel. The rodent population in
maintenance
parks has exploded in recent years. In District 7,
Verdi Square, Straus, Theodore Roosevelt and
Riverside Parks, the Broadway Malls, and
several playgrounds have had extreme rodent
infestations. A second dedicated exterminator
for District 7 and Riverside Park would allow
Parks to address infestations through a variety
of systematic and sustainable measures,
including the newly available dry ice method,
which, like more traditional methods, requires a
licensed exterminator.
21/34
DPR
Provide better park
Synthetic Turf Field Maintenance Crew. $330K
maintenance
Establish a crew to repair and maintain the six
synthetic turf fields in Community District 7.
DPRs synthetic turf installations experience
heavy use throughout the year, as well as the
effects of severe winters. These funds would
allow DPR to contract for regular service to
repair and maintain these synthetic surfaces, in
order to extend their useful lives and prevent
injuries to the youth and adults who use them.
22/34
DOE
Other educational
Provide Additional Support Funding so that
programs requests
Parent Coordinators and School Social Workers
are not diverted from their professional duties
and responsibilities. The FY 2020 budget
included funds for an additional 285 social
workers (Citywide). The budgets for most
elementary and middle schools also include line
items for Parent Coordinators. It is essential that
the funds for these additional social workers be
baselined so that the continuity of expert
services provided by these professionals is not
left to a year-to-year budget negotiation. (New)
23/34
Other
Other expense
Funding for financial, legal, and psychological
budget request
support for individuals to decide whether or not
to file claims under the Child Victims Act during
and after the one-year look back window. The
public focus on child sexual abuse means that
even among people who do not file claims,
there is a retraumatization that may occur for
which supportive services are necessary.
24/34
DPR
Provide more
Playground Associates. Eight playground
programs in parks or
associates would provide valuable
recreational centers
programming and supervision for children,
assist with park maintenance and provide a
safety presence from July through Labor Day in
Frederick Douglass Playground (West
100th/Amsterdam), Happy Warrior Playground
(West 98th/Amsterdam), Sol Bloom Playground
(West 91st/Columbus), Tecumseh Playground
(West 77th/Amsterdam), Bennerson Playground
(West 64th/Amsterdam Houses), Neufeld
Playground (West 76th/Riverside Park),
Dinosaur Playground (West 97th/Riverside Park)
and River Run Playground (Wests 83rd
Street/Riverside Park).
25/34
DOHMH
Other programs to
Funding for additional DOHMH staff to collect
address public
and report more information to the public and
health issues
MCB7 on lead testing (blood lead levels in
requests
children) and investigations, including any initial
positive test, any retest results, and results six
months later; as well as findings and outcomes
of investigations.
26/34
DYCD
Provide, expand, or
11% of youth aged 16 to 24 in Community
enhance the out-of-
District 7 are considered “disconnected,”
school youth
meaning that they are not in school or working.
program for job
To support the mental health and
training and
comprehensive needs of youth graduating and
employment
transitioning from high school to college or
services
work, funding for a pilot program modeled after
DoE/ACS programs (e.g., those designed for
youth transitioning out of foster care). (DoE and
ACS)
27/34
Other
Other expense
The Mayor's Office to End Domestic and
budget request
Gender-Based Violence recently opened a
Learning Lab at the NYC Family Justice Center in
Manhattan to provide economic empowerment
programming for people who have experienced
domestic and gender-based violence. Funding
for a pilot program in Community District 7 that
implements the Learning Lab (ENDGBV) model
with a dedicated focus on Community District
residents is needed to ensure equitable access.
28/34
DPR
Provide better park
DPR has more than 8,400 street trees in District
maintenance
7. This does not include the trees in Central and
Riverside Parks. While DPR looks to adjacent
building owners to maintain, including voluntary
plantings, the beds of street trees, DPR itself
does not have any service to maintain the tree
beds. In many tree beds, the soil becomes so
compacted that water and air cannot reach the
tree roots. DPR should have a service that
assures that all street trees will thrive. A
program in MCD7 addressed, at a minimum, to
maximizing the DPR partnership with private
neighbors, would demonstrate the importance
of tree stewardship; the diversion of rain water
away from sidewalks and sewers; and the value
of disruption of disruption of rat burrows.
29/34
DPR
Provide better park
DPR has more than 8,400 street trees in District
maintenance
7. This does not include the trees in Central and
Riverside Parks. Many of these street trees have
dead branches; most have not been trimmed for
a long time. When stumps remain in place, trees
cannot be replanted. Funding for emergency
pruning and stump removal and a 10-year
pruning cycle would make it possible for Parks
to respond more rapidly to requests for tree
pruning and stump removal, would reduce
safety concerns, and would allow replacement
of trees that have been removed.
30/34
HRA
Provide case
To provide financial counseling and legal
management, cash
assistance for people unable to pay medical
assistance, or social
bills, funding for a pilot program supported by
services
DOHMH and/or the NYC Law Department/
Corporation Counsel’s Office. (New)
31/34
DOE
Other educational
Regular physical fitness is acknowledged as
programs requests
necessary for both physical and mental well-
being. Due to overcrowding and scheduling
changes around curriculum pressures and
testing, schools have reduced gym classes and
recess time. Most school playgrounds operated
by the Dept. of Education are locked after the
school day because there is no staff to supervise
them. It is recommended that two school
playgrounds in the MCD7 receive funding of
$55K for personnel allowing the playgrounds to
remain open.
32/34
DOE
Other educational
Since 2011, New York City Department of
programs requests
Education (DOE) has required students to
receive sexuality education as part of their
mandatory single semesters of health education
in both middle and high school, but reports from
students, educators, and DOE itself show that
even this minimal requirement is not being
effectively implemented. Every young person
will one day have life-changing decisions to
make about their sexual and reproductive
health. Yet research shows that the majority of
adolescents lack the knowledge required to
make those decisions responsibly, leaving them
vulnerable to coercion, sexually transmitted
infections and unintended pregnancy.
33/34
Other
Other expense
Funding for staff from the New York City Law
budget request
Department/Corporation Counsel’s Office to
track numbers of claims filed under the CVA as
well as outcomes
34/34
Other
Other expense
Funding for mental health services in jails and
budget request
for justice-involved youth transitioning from
jails.

