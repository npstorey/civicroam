- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 2 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1uimfE0NXpBhreAdhTKE-Q4Ruvdf1nguw/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1uimfE0NXpBhreAdhTKE-Q4Ruvdf1nguw/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
2
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 2
image
Address: 350 Jay Street, 8 Floor
Phone: 718-596-5410
Email: cb2k@nyc.rr.com
Website: www.nyc.gov/brooklyncb2
Chair: Lenny Singletary District Manager: Robert Perris
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community District 2 consists of Downtown Brooklyn, the residential and mixed-use neighborhoods around the downtown core, and the industrial park in the former Brooklyn Navy Yard. Downtown Brooklyn is the city's third largest central business district and the civic center for the most populous county in New York State. Most of the residential neighborhoods in the district were first developed in the nineteenth-century and primarily consist of rowhouses and low-scale commercial streets. There are also taller buildings constructed in the 1950s and 1960s as part of government housing programs and more recently through private development. These residential neighborhoods are Boerum Hill, Bridge Plaza, Brooklyn Heights, Fort Greene and Clinton Hill. The neighborhoods closer to the East River contain a mix of residential and commercial uses, including traditional and TAMI (tech, advertising, media and information) industry, in buildings developed during various periods in a variety of scales and styles. Dumbo, Fulton Ferry Landing and Vinegar Hill are the waterfront neighborhoods in the community. There are several specially-mapped districts within Community District 2. The community district is home to eight, and a portion of a ninth, business improvement districts. Ten historic districts are located here. Over 100 acres is mapped parkland. Community District 2 overlaps with parts of three congressional, two state senate, three assembly and three city council districts.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 2
image
The three most pressing issues facing this Community Board are:
Affordable housing
The affordable housing crisis is a citywide issue and one that will be extremely difficult to resolve. The city is losing affordable units of housing faster than new units can be constructed. When Mayor Bill de Blasio announced his goal of building or preserving 200,000 units of affordable housing over 10 years, the NYU Furman Center commented that it will take a million new apartments to impact housing cost from the supply side. As neighborhoods in Brooklyn Community District 2 gentrify at a faster pace, the issue is increasingly acute here.
Schools
The Department of Education (DOE) seems unable to plan for localized growth in school population. It is understandable that the DOE does not want to construct expensive schools for which there is no need but its 'wait- and-see' approach, in combination with the long lead time necessary to site and construct a school, results in painful waits for additional capacity. The city rezoned Downtown Brooklyn in 2004 and the first school serving the neighborhood may be completed by the 20th anniversary of the land use changes.
Other
The "Triple Cantilever" section of the Brooklyn-Queens Expressway, on the western edge of Brooklyn Heights, has outlived its engineered life. New York State Department of Transportation began in 2008 the environmental review and alternative analysis for the renovation or replacement of the structure but walked away from the project in 2011. The New York City Department of Transportation (NYCDOT) has restarted the project and achieved some early success; $1.7 billion in funding and State approval for a design-build procurement process. However, a proposal to build a temporary highway at the same elevation as the Brooklyn Heights promenade, the highest of the three levels, was met with resounding opposition from the community and some local elected officials. Community Board 2 hopes that NYCDOT can find a workable solution for re-routing the 153,000 cars that use the highway daily and get the project schedule back on track.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 2
image
M ost Important Issue Related to Health Care and Human Services
Environmental health issues (noise, lead, respiratory illness, etc.)
According to the New York City health department's 2018 Community Health Profile for (nominally) Fort Greene and Brooklyn Heights, the levels of fine particulate matter (PM2.5) was notably higher in Community District 2 than in Brooklyn or the city as a whole; 8.8, 7.8 and 7.5 micrograms per cubic meter, respectively. The data was obtained in a 2016 DOHMH community air survey. This may be attributable in part to traffic on the Brooklyn-Queens Expressway, which travels through the district, as well as arterials leading to and from the Brooklyn and Manhattan bridges. As a possible corollary, the health profile also reported a high rate of child asthma emergency room visits, 249 per 10,000 children between the ages of five and 17. By comparison, the figure for Brooklyn is 186 visits.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Brooklyn Community District 2 (CD2) is home to a large number of health care facilities, in some cases disproportionately so. This results in part from the extensive transportation network in the district, which makes it accessible to the rest of the borough. According to the register of "Selected Facilities and Program Sites" prepared by the Department of City Planning, there are 28 mental health service centers in CD2, 24 chemical dependency service centers and 20 residential programs for adults and families. In an analysis prepared in support of a board resolution passed in 2011, it was determined that 23 percent of the borough's beds for chemical dependency services then were located in CD2. Six Brooklyn community districts combined provided less than the number located here and five districts provided no beds at all. One-quarter of the out-patient substance abuse program sites in Brooklyn were located in CD2, making it the predominant host in 2011. Similarly, the district ranked first for the borough's out-patient substance abuse program sites. Community Board 2 (CB2) knows that health care facilities are not necessarily bad neighbors and how well a program is operated is the determining factor, not the services provided. The community board has in recent years not objected to the expansion and consolidation of existing services in the district or the relocation of facilities from elsewhere. However, saturation is always a concern for CB2.
Needs for Older NYs
The 2010 decennial census recorded 15,433 older adults residing in substantial concentrations in Brooklyn Community District 2. There are 13 residential developments where more than 30 percent of the residents, or approximately 3,700 people, are age 60 or older. Of these, seven met government guidelines for designation as Naturally Occurring Retirement Communities, or NORCs. In surveys conducted through Community Board 2, nearly all respondents indicated a desire to remain in their homes for as long as possible. More than half responded that they would welcome a nurse or social worker who will make regularly scheduled visits to their development.
Needs for Homeless
There has been a noticeable increase in street homelessness in Brooklyn Community District 2. Small groups of people without homes congregate in several locations, including Columbus Park, the plaza in front of Long Island University and at Fox Square. Telephone calls from the district office and community residents to 311 or directly to Street to Home, operated by a Department of Homeless Services contractor, do not seem to result in a reduction of the homeless population. This is attributable to a variety of explanations, including resistance from the individuals we hope to assist. However, the district office receives no follow-up reports from Street to Home and therefore we do not know what we might do differently.
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
7/22
DHS
Upgrade existing
The Department of Homeless Services-managed
39 Auburn
facilities for the
Auburn residence must be upgraded generally,
Place
homeless
with expanded electrical system capacity and a
code-compliant fire alarm system of particular
concern.
11/22
DFTA
Renovate or
Paint the exterior and renovate the electrical
105 North
upgrade a senior
and fire alarm systems at the Willoughby (aka
Portland
center
Whitman and Round Top) Senior Center.
Avenue
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/25
DOHMH
Create or promote
Increased mental health support for teenagers
programs to de-
in schools. School programs will offer easy
stigmatize mental
access and ability to provide treatment prior to
health problems
crisis situation.
and encourage
treatment
2/25
DOHMH
Reduce rat
Increase funding for rodent management in
populations
parks and Greenstreets. [formerly Tracking Code
202201603E]
4/25
DHS
Improve safety at
The women's shelter at 200 Tillary Street is a
200 Tillary
homeless shelters
source of a high number of 911 calls.
Street
5/25
DOHMH
Reduce rat
Large number of rodent sighting reports
populations
influenced the health department to select
Brooklyn Heights and Dumbo to be indexed and
monitored. However residents in Fort Greene
and Boerum Hill are increasingly concerned
about the growing rat populations. Restaurant
owners and owners of large residential
buildings should be encouraged to discard
garbage in rodent proof containers.
12/25
DOHMH
Provide more
While levels of new infections are at record
295 Flatbush
HIV/AIDS
lows, rates remain high in Brooklyn, with CD2
Avenue
information and
having 33.1 new cases per 100,000 people.
Extension
services
Educational campaigns need to target the
demographic groups with the highest rates of
new infection.
17/25
DOHMH
Promote vaccinations and immunizations
Increase the rates of vaccination for HPV and influenza.
295 Flatbush Avenue Extension
19/25
DFTA
Enhance NORC
At eight cooperative apartment buildings in
programs and
Community District 2 (Kingsview Homes,
health services
Willoughby Walk, St. James Tower, Ryerson
Tower, Pratt Tower, Cadman Plaza North,
Cadman Towers and 75 Henry Street), more
than 50 percent of the residents are 60-years-
old or older.
21/25
DFTA
Enhance home care
Many of the elderly are healthy but frail and
services
need assistance with errands and, maintenance
of their homes. These adults are not provided
for in existing programs.
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 2
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
Community District 2 overlaps with approximately half of Community School District 13 and also contains the northernmost portion of Community School District 15. Although there is unutilized capacity in some schools in CD2, it is often not where additional seats are needed. Community Board 2 urges the Department of Education and the School Construction Authority to employ a range of strategies for using capacity in an effective way.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
The Department of Education and School Construction Authority need to construct a new school, or perhaps several schools, for the residents of Downtown Brooklyn.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/22
SCA
Provide a new or
Construct a new elementary school in
expand an existing
Downtown Brooklyn. In the 15 years since the
elementary school
2004 rezoning, thousands of units of housing
had been built but there are still no new school
facilities for the growing neighborhood.
[formerly Tracking Code 202201501C]
6/22
SCA
Provide a new or
Construct additional elementary and
expand an existing
intermediate public schools to accommodate
elementary school
the increase in student population resulting
from the development of Pacific Park, formerly
known as Atlantic Yards. [formerly Tracking
Code 202200804C]
9/22
SCA
Provide technology
Provide new or expanded science labs and
upgrade
technology facilities at district elementary and
intermediate schools.
21/22
SCA
Renovate or
Renovate high school cafeterias to food court
upgrade a high
design to increase student participation in
school
meals.
22/22
SCA
Renovate interior
Brooklyn Technical High School with over 5,400
building component
students produces more trash than can be
handled within the building as designed.
Additional indoor or outdoor storage, secured
from vermin, needs to be constructed.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
3/25 DYCD Provide, expand, or
enhance Cornerstone and Beacon programs (all ages, including young adults)
Increase funding for after-school, Saturday and summer programs that are built on solid youth development principles, are evidence-based and offer a balance of sports, arts and academics within a strength-based perspective. [Formerly Tracking Code 202199704E]
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 2
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
As it has in most of New York City, the rate of crime has been greatly reduced in Community District 2, which is patrolled by the 84th and 88th precincts, Police Service Area 3, Transit District 30 and to a lesser extent the 78th Precinct. Despite the overall reductions, there were several scary daytime shootings in Downtown Brooklyn last year and again in fall 2019. Perhaps the most alarming incident occurred on October 1, 2018 at 3:45 pm, while students were on the street, making their way from schools to their transportation home. On July 13, 2018, three people were injured, two of them bystanders. There were two other shootings last year, four in as many months. NYPD's Patrol Borough Brooklyn North deployed additional officers near the courts and throughout the central business district and a period of calm followed. However, there were recently two more shootings in just two weeks; on September 26 at the Metrotech Center academic/office park and on October 11 in the Jay Street-Metrotech subway station. According to the New York Daily News, CompStat data reports that shooting incidents have increased citywide, year-over-year, with 629 shootings last year and 660 through November 13, 2019.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
14/22
NYPD
Renovate or
Renovate and expand the 88th Precinct House.
298 Classon
upgrade existing
The landmarked building is inadequate for
Avenue
precinct houses
contemporary service delivery but is unlikely to
be replaced. [formerly Tracking Code
202200702C]
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
7/25
NYPD
Assign additional
Increase intersection control agents in
traffic enforcement
Community District 2, specifically at Flatbush
officers
Avenue and Nevins Street, Atlantic Avenue and
Hicks Street, and Flatbush and Myrtle Avenues.
[formerly Tracking Code 202200401E]
8/25
NYPD
Assign additional
Increase personnel and equipment at the 88th
uniformed officers
Precinct. The 88th Precinct Youth and
Community Council determined that the 88th
Precinct is understaffed in comparison to the
neighboring 84th Precinct. [formerly Tracking
Code 202200704E]
20/25
FDNY
Expand funding for
Hire additional FDNY inspectors to inspect new
fire prevention and
"high-rise" construction. [formerly Tracking
life safety initiatives
Code 202201604E]
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 2
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water pollution control
Although the environmental impact occurs outside of Brooklyn Community District 2 (CD2), the community board is concerned about Combined Sewer Overflows (CSO) into the Gowanus Canal that result from occasional heavy rainfall in CD2. High Level Storm Sewers have been identified as an important mitigation for CSO in the canal.
Community Board 2 urges the expeditious completion of SEK20067, the second phase of the "High Level Storm Sewer and Water Main on 3rd Avenue Project."
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
16/22 DSNY Provide new or
upgrade existing sanitation garages or other sanitation infrastructure
Construct a District 2 sanitation garage within the boundaries of Brooklyn Community District
2. Co-locating the District 2 garage with another district results in delayed service and unnecessary vehicle exhaust emissions.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
13/25
DEP
Clean catch basins
Clean every catch basin in the district,
particularly those located at the corners of
Livingston Street and Bond Street, and Ashland
Place and Lafayette Avenue. There is a lot of
debris in these storm drains and on the corners
noted here, there is always standing water
during and for over 24 hours after a storm.
16/25
DSNY
Increase
Illegal dumping occurs consistently on
enforcement of
commercial streets. In some cases the
illegal dumping laws
perpetrator is obvious but current rules require
a dumper to be caught in the act. The rules/law
should be updated to include technological
evidence.
25/25
DSNY
Increase
The sidewalk outside many restaurants is
enforcement of
covered with grease due to improper storage of
dirty sidewalk/dirty
trash and failure to clean after pick-up. This
area/failure to clean
action provides a feeding ground for rodents.
area laws
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 2
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
Clearly, the most important issue in Brooklyn Community District 2 and throughout the city is affordable housing. Community Board 2 (CB2) believes that the issue is even broader, a need for affordable communities. In its report, State of New York City's Housing and Neighborhoods in 2014, the NYU Furman Center ranked the district's median rent ninth highest in the city, at $2,995. That is a phenomenal $2,000 increase from a decade earlier. A survey conducted for Brooklyn Community Board 2 by the Center for Worker Education at City College found the issue to be the most pressing concern for respondents, regardless of income. The survey was taken in the census tracts where the three NYCHA developments are located and in adjacent tracts that had experienced considerable gentrification. Various programs and projects have produced and continue to generate new units of affordable housing. Community Board 2 would like the incentive programs to require a higher proportion of affordable units and for the income thresholds to be lower. The community board would also like to see more two- and three- bedroom apartments constructed so that families can stay in their homes as household size grows. Finally, CB2 encourages the City to put in place policies and programs that will contribute to affordable retail. The value of affordable housing is diminished when residents need to travel to another neighborhood to shop.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Almost all of Brooklyn Community District 2 has been rezoned in the past two decades, beginning with Vinegar Hill in 1997. For the most part, the land use actions have accomplished the intended goals but there have been two failures. Little affordable housing has been constructed in the areas where density bonuses were mapped to incentivize its development. The Downtown Brooklyn Development Plan, intended to strengthen the city's third central business district, has instead produced a high-rise, bedroom community.
Needs for Housing
No comments
Needs for Economic Development
Significant economic activity is and has been occurring in Brooklyn Community District 2 (CD2). Most of the neighborhoods are gentrifying and there is considerable investment in the commercial districts. CD2 is home to eight business improvement districts and part of a ninth, which is believed to be the highest number in any community district in the city. Office vacancy rates are lower than they have been in years. However, in this case a rising tide has not raised all ships. The unemployment rate in the three NYCHA developments is 29 percent, three times the rate (9.8%) of the district. The median household income in the Farragut, Ingersoll and Whitman houses is roughly $17,000. Three-quarters of the households there earn less than $35,000 and almost one-third manage somehow on less than $10,000. By comparison, the median income is for the district as a whole is approximately
$83,000 and the households earning less than $35,000 constitute less than 30 percent of the total. Policies and programs need to be developed and executed so the residents with the greatest need benefit more from the economic vitality of Community District 2. The Brooklyn Navy Yard Development Corporation (BNYDC) has led the way in this regard. For example, at its newly developed Green Manufacturing Center, BNYDC obtained a 31 percent rate of MWBE contracting and 46 percent rate of MWBE hiring. The local contracting and hiring rates were 14 and 18 percent, respectively. Admittedly, as a public benefit corporation, the Navy Yard has more flexibility than a for- profit entity but it serves as an example of the kind of effort that we need to see more of in CD2.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/22
NYCHA
Install security
Replace outdoor lights at the Farragut, Ingersoll
cameras or make
and Whitman houses, especially in the vicinity
other safety
of the building entrances. [formerly Tracking
upgrades (Capital)
Code 202201602C]
4/22
NYCHA
Renovate or
Renovate the Whitman Community Center at
149 North
upgrade NYCHA
the Whitman Houses.
Oxford Walk
community facilities
or open space
5/22
NYCHA
Renovate or
Renovation of 75, 77, 99 and 110 Waverly
upgrade NYCHA
Avenue, which have been wholly or partially
community facilities
vacant for years. [formerly Tracking Code
or open space
202201202C]
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
11/25
EDC
Expand tax incentive
Provide incentives or tax abatements to create
programs to help
and maintain affordable commercial and retail
neighborhood
spaces for small businesses within the district.
businesses construct
or improve space
15/25
DCP
Study land use and
Revaluate the Downtown Brooklyn
zoning to better
Development Plan for possible follow-up land
match current use
use action to stimulate more commercial
or future
development. The Downtown Brooklyn
neighborhood
Development Plan was intended to make the
needs
city's third central business district more
competitive in a regional market. Instead, it has
resulted in residential construction.
18/25
SBS
Provide or expand
Increase the number of Small Business Services
assistance to obtain
compliance advisers to assist small businesses
licenses and permits
meet city regulations.
23/25
SBS
Provide or expand
Fund biannual business planning and operations
business education
courses tailored toward the development and
to businesses and
growth of small businesses within the district.
entrepreneurs
TRANSPORTATION
Brooklyn Community Board 2
image
M ost Important Issue Related to Transportation and Mobility
Other
The "Triple Cantilever" section of the Brooklyn-Queens Expressway (BQE), generally located between Atlantic Avenue and the Brooklyn Bridge, has out-lived its engineered life. After the state transportation department terminated its efforts to rehabilitate or renovate the structure, half a decade was lost to inaction. The New York City Department of Transportation (NYCDOT) took the lead on the project in 2016, holding occasional public meetings to keep interested parties informed. At the meeting held on September 27, 2018, NYCDOT presented two alternatives for rebuilding the aging structure, both of which met with community opposition. Several people made public their own proposals for replacing the Triple Cantilever, which either recommended a different method of construction or an alternative design for the highway. In April 2019, Mayor Bill de Blasio announced an expert panel to review the project opportunities and constraints and the various alternatives. At the outset, the goal was to have the panel issue a report during the summer and for the formal environmental process to begin by the end of the year. To date, however, the panel has not released its findings and NYCDOT has conducted little community outreach. The current status of the project is concerning. If traffic needs to be re-routed from this section of the BQE, the impacts will be felt not just in Community District 2 but throughout the metropolitan region.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The transportation network in Brooklyn Community District 2 (CD2) is extensive and varied. The Brooklyn and Manhattan bridges convey, respectively, 105,679 and 85,484 vehicles between the two boroughs daily in 2016, the last year for which data was found. Depending on the weather, between 1,000 and 30,000 pedestrians cross the Brooklyn Bridge each day, many of them tourists. The East River crossings act as funnels for cyclists traveling to or from Manhattan and CD2 is well served by bike lanes. Citi Bike docking stations are distributed throughout the district, although the operator continues to struggle to balance the system. Thirteen subway and 11 bus lines move passengers through the district and beyond. According to the MTA, the Jay Street-Metrotech, Atlantic Avenue- Barclays Center, and Court Street-Borough Hall subway stations rank 23rd, 24th, and 27th respectively for average weekday ridership in the 420-station system. Atlantic Terminal serves as a hub for the Long Island Rail Road (LIRR) and the Brooklyn-Queens E expressway is a resource for motorists to and from Queens and Long Island.
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
12/22
DOT
Install streetscape
Extend the Flatbush Avenue streetscape
Flatbush
improvements
improvements from DeKalb to Atlantic avenues.
Avenue
Extension would match the original geographic
DeKalb
scope of the project, which was truncated due
Avenue
to budget constraints. [formerly Tracking Code
Atlantic
202201402C]
Avenue
15/22
DOT
Upgrade or create
Development of a plaza on the triangle bounded
new plazas
by Flatbush, Atlantic and Fourth Avenues,
known as Times Plaza. The plaza was expanded
as part of traffic calming associated with the
Barclays Center but is inhospitable and
unattractive. [formerly Tracking Code
202201505C]
17/22
DOT
Install streetscape
Develop fully the Atlantic Avenue Gateway
Atlantic
improvements
beneath the BQE at the foot of Atlantic Avenue.
Avenue
[formerly Tracking Code 202201502C]
Furman
Street Hicks
Street
20/22
DOT
Improve traffic and
Install school zone speed camera at the
Flatbush
pedestrian safety,
Manhattan-bound Flatbush Avenue Extension,
Avenue
including traffic
between Willoughby Street and Myrtle Avenue.
Extension
calming (Capital)
Willoughby
Street Myrtle
Avenue
CS
DOT
Rehabilitate bridges
Refurbish or replace the "Triple Cantilever"
I-278 Atlantic
section of the Brooklyn-Queens Expressway, in
Ave Brooklyn
Brooklyn Heights. The "Triple Cantilever" section
Bridge
of the Brooklyn-Queens Expressway is older
than its engineered life. Failure of the structure
would negatively impact traffic in at least three
counties. Although part of the BQE, the
Department of Transportation considers the
"Triple Cantilever" a bridge. [formerly Tracking
Code 202201603C]
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
14/25
DOT
Conduct traffic or
Study the creation of (a) commuter van
parking studies
terminal(s) in Downtown Brooklyn and review
current commuter van pick-up and drop-off
locations. Licensed and illegal commuter vans
are creating traffic congestion without
structured stops. [formerly Tracking Code
202200801C]
22/25
DOT
Conduct traffic or
A traffic study of the intersection of Flatbush
Flatbush
parking studies
Avenue and Nevins Street with the intention of
Avenue
improving pedestrian safety and vehicular
Fulton Street
traffic flow.
Nevins Street
24/25
DOT
Conduct traffic or
Fund the study, modeling and implementation
parking studies
of traffic control strategies to address issues
identified by Community Board 2 -- as part of
the Downtown Brooklyn Traffic Calming Study --
at Tillary Street & Flatbush Avenue and
Schermerhorn Street & Flatbush Avenue.
[formerly Tracking Code 202200502C]
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 2
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
Every year, community boards across the city identify parks in the districts that they serve as needing renovation or reconstruction. The formal response to the great majority of these budget requests is, "Department of Parks and Recreation funds are insufficient for this project. We recommend this project be brought to the attention of your elected officials, i.e. Borough President and/or City Council member." It is not so much that the funds are insufficient as they are non-existent until an elected official makes a budget allocation for a specific capital project. This may not be the most equitable way to prioritize what parks are funded. The time may have come for the administration to provide Capital Budget funding directly to the parks department, which has for years prepared lists of its facilities that most need investment. If this is too radical a change, the City could perhaps start be establishing a fund for the largest municipal parks. The cost of renovating the larger parks (Fort Greene and Commodore Barry, for example in Community District 2) is too high for the borough president and council member to shoulder on their own, even in partnership. The result is often deferred maintenance and piecemeal renovation when it does occur.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Like most of New York City, Brooklyn Community District 2 is unlikely to achieve the city's ideal of 2.5 acres of open space per 1,000 residents, even with the addition of Brooklyn Bridge Park. While parks and playgrounds are spread throughout the district, parkland is scarce in Boerum Hill and the southern portion of Clinton Hill. According to respondents to a survey conducted by the board, most of the district parks are in good condition. A majority of the almost 250 respondents stated that the bathrooms were open during posted hours at least some of the time.
However, those who primarily use McLaughlin Park, Fort Greene Park and Underwood Playground said the bathrooms there are almost never open and when they are open, they are usually unclean. Users noted that there is never a parks employee on site, except at Fort Greene Park.
Needs for Cultural Services
Brooklyn Community District 2 is rich in organizations that provide access to visual, written and performing arts, in the "cultural district" centered on the Brooklyn Academy of Music and elsewhere. In a survey released by the Downtown Brooklyn Arts Alliance, 32 of its members reported a total of 5,107,586 patrons--2,772,064 residing in Brooklyn--and $214 million in economic impact. Members of the Alliance work with school-based and non-school- based programs to serve 64,378 Brooklynites who might have otherwise been bared. Traditionally, high admission cost or lack of awareness of available cultural institutions has limited access to low-income families. Cool Culture, a local non-profit, helped 759 families residing in Community District 2 with children through age six to overcome these obstacles.
Needs for Library Services
The Brooklyn Public Library (BPL) has surpassed its traditional role of being a repository for books and a place for quiet study. Today you can access computers, have a snack at the café, participate in cultural or interactive events, receive advice on starting or expanding a business and more. While the services offered by the BPL and attendance continues to grow, their discretionary budget is subject to the annual threat of reduction. While the library system's budget is often restored, in whole or in part, but the negotiation is an unnecessary waste of time and energy.
One service that the library provides but is not part of its mission or programming is as a destination for people, some without permanent housing, during the day. Community Board 2 believes that this ad hoc role of libraries be embraced and social workers be hired to help connect these patrons with the services they need beyond someplace
to go during the hours when the libraries are open.
Needs for Community Boards
The Community Board 2 (CB2) district office is located on the eighth floor of a Downtown Brooklyn office building. On December 12, 2018, the community board voted 31-0-1 to submit a space request form for the relocation of its office to a more visible and community-friendly space. In response to the community board's application, the Department of Citywide Administrative Services (DCAS) sent an architect to survey the current office. The
DCAS Porfolio Planning & Management group reported, "The inconvenience of having to pass through security is not seen to be reason alone to relocate, therefore PPM would not currently support any consideration to move this facility." CB2 asked DCAS to reconsider and the agency responded by saying some other tenants in the building also wish to relocate while other wish to increase the size of their office. This potentially presents a future opportunity for the community board to move but is highly tentative. Community Board 2 remains steadfast in its belief that it needs a more accessible district office.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/22
DPR
Reconstruct or
Obtain additional funds for continuing phases of
upgrade a park or
renovation of Commodore Barry Park as per
amenity (i.e.
completed master plan. This is the only city-
playground, outdoor
owned athletic field in Community District 2 and
athletic field)
is used by large numbers of local residents and
those from beyond the district. [formerly
Tracking Code 202200006C]
8/22
DPR
Reconstruct or
Create a grading and drainage plan to address
upgrade a park or
erosion problems in Fort Greene Park. [formerly
amenity (i.e.
Tracking Code 202201601C]
playground, outdoor
athletic field)
10/22
DPR
Reconstruct or
Renovate Cadman Plaza Park north of the War
upgrade a park or
Memorial, including infrastructure and
amenity (i.e.
specifically water supply, to coordinate and
playground, outdoor
complement the design with that of the
athletic field)
completed southern section and Whitman Park
where renovations have been completed.
[formerly Tracking Code 202201001C]
13/22
DPR
Provide a new or
Fund the acquisition and construction of
expanded park or
additional park space throughout Community
amenity (i.e.
District 2 and in particular in the underserved
playground, outdoor
areas of Boerum Hill and eastern Clinton Hill.
athletic field)
[formerly Tracking Code 202200203C]
18/22
DPR
Reconstruct or
Refurbish the Fort Greene Park Tennis Courts
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
19/22
DPR
Reconstruct or
Renovate the bathrooms at Oracle Playground.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Provide a new, or
Improve the conditions of the Brooklyn War
new expansion to, a
Memorial and restore the interior to usable
building in a park
space. Bring both the exterior and interior
spaces into ADA Compliance. [formerly Tracking
Code 202200604C]
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/25
DPR
Provide better park
Fund full-time seasonal Playground Associates
maintenance
at the following locations: Fort Greene Park,
McLaughlin Park, Pierrepont Playground, 16
Sycamores Park, Commodore Barry Park,
Crispus Attucks Playground, Underwood
Playground, Washington Hall Park, Parham
Playground and JHS 113 Playground. [formerly
Tracking Code 202200602E]
9/25
BPL
Extend library hours
Increase budgets for all district library personnel
or expand and
and supplies to retain qualified staff and
enhance library
maintain high-quality service throughout the
programs
week. Maintain extended library hours and
expand library programs. [formerly Tracking
Code 202200003E]
10/25
DPR
Other park
Open clean bathrooms during the posted hours.
maintenance and
Extend hours during the summer.
safety requests
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/22
NYCHA
Install security
Replace outdoor lights at the Farragut, Ingersoll
cameras or make
and Whitman houses, especially in the vicinity
other safety
of the building entrances. [formerly Tracking
upgrades (Capital)
Code 202201602C]
2/22
SCA
Provide a new or
Construct a new elementary school in
expand an existing
Downtown Brooklyn. In the 15 years since the
elementary school
2004 rezoning, thousands of units of housing
had been built but there are still no new school
facilities for the growing neighborhood.
[formerly Tracking Code 202201501C]
3/22
DPR
Reconstruct or
Obtain additional funds for continuing phases of
upgrade a park or
renovation of Commodore Barry Park as per
amenity (i.e.
completed master plan. This is the only city-
playground, outdoor
owned athletic field in Community District 2 and
athletic field)
is used by large numbers of local residents and
those from beyond the district. [formerly
Tracking Code 202200006C]
4/22
NYCHA
Renovate or
Renovate the Whitman Community Center at
149 North
upgrade NYCHA
the Whitman Houses.
Oxford Walk
community facilities
or open space
5/22
NYCHA
Renovate or
Renovation of 75, 77, 99 and 110 Waverly
upgrade NYCHA
Avenue, which have been wholly or partially
community facilities
vacant for years. [formerly Tracking Code
or open space
202201202C]
6/22
SCA
Provide a new or
Construct additional elementary and
expand an existing
intermediate public schools to accommodate
elementary school
the increase in student population resulting
from the development of Pacific Park, formerly
known as Atlantic Yards. [formerly Tracking
Code 202200804C]
7/22
DHS
Upgrade existing
The Department of Homeless Services-managed
39 Auburn
facilities for the
Auburn residence must be upgraded generally,
Place
homeless
with expanded electrical system capacity and a
code-compliant fire alarm system of particular
concern.
8/22
DPR
Reconstruct or upgrade a park or
Create a grading and drainage plan to address erosion problems in Fort Greene Park. [formerly
amenity (i.e.
Tracking Code 202201601C]
playground, outdoor
athletic field)
9/22
SCA
Provide technology
Provide new or expanded science labs and
upgrade
technology facilities at district elementary and
intermediate schools.
10/22
DPR
Reconstruct or
Renovate Cadman Plaza Park north of the War
upgrade a park or
Memorial, including infrastructure and
amenity (i.e.
specifically water supply, to coordinate and
playground, outdoor
complement the design with that of the
athletic field)
completed southern section and Whitman Park
where renovations have been completed.
[formerly Tracking Code 202201001C]
11/22
DFTA
Renovate or
Paint the exterior and renovate the electrical
105 North
upgrade a senior
and fire alarm systems at the Willoughby (aka
Portland
center
Whitman and Round Top) Senior Center.
Avenue
12/22
DOT
Install streetscape
Extend the Flatbush Avenue streetscape
Flatbush
improvements
improvements from DeKalb to Atlantic avenues.
Avenue
Extension would match the original geographic
DeKalb
scope of the project, which was truncated due
Avenue
to budget constraints. [formerly Tracking Code
Atlantic
202201402C]
Avenue
13/22
DPR
Provide a new or
Fund the acquisition and construction of
expanded park or
additional park space throughout Community
amenity (i.e.
District 2 and in particular in the underserved
playground, outdoor
areas of Boerum Hill and eastern Clinton Hill.
athletic field)
[formerly Tracking Code 202200203C]
14/22
NYPD
Renovate or
Renovate and expand the 88th Precinct House.
298 Classon
upgrade existing
The landmarked building is inadequate for
Avenue
precinct houses
contemporary service delivery but is unlikely to
be replaced. [formerly Tracking Code
202200702C]
15/22
DOT
Upgrade or create
Development of a plaza on the triangle bounded
new plazas
by Flatbush, Atlantic and Fourth Avenues,
known as Times Plaza. The plaza was expanded
as part of traffic calming associated with the
Barclays Center but is inhospitable and
unattractive. [formerly Tracking Code
202201505C]
16/22
DSNY
Provide new or
Construct a District 2 sanitation garage within
upgrade existing
the boundaries of Brooklyn Community District
sanitation garages
2. Co-locating the District 2 garage with another
or other sanitation
district results in delayed service and
infrastructure
unnecessary vehicle exhaust emissions.
17/22
DOT
Install streetscape
Develop fully the Atlantic Avenue Gateway
Atlantic
improvements
beneath the BQE at the foot of Atlantic Avenue.
Avenue
[formerly Tracking Code 202201502C]
Furman
Street Hicks
Street
18/22
DPR
Reconstruct or
Refurbish the Fort Greene Park Tennis Courts
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
19/22
DPR
Reconstruct or
Renovate the bathrooms at Oracle Playground.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
20/22
DOT
Improve traffic and
Install school zone speed camera at the
Flatbush
pedestrian safety,
Manhattan-bound Flatbush Avenue Extension,
Avenue
including traffic
between Willoughby Street and Myrtle Avenue.
Extension
calming (Capital)
Willoughby
Street Myrtle
Avenue
21/22
SCA
Renovate or
Renovate high school cafeterias to food court
upgrade a high
design to increase student participation in
school
meals.
22/22
SCA
Renovate interior
Brooklyn Technical High School with over 5,400
building component
students produces more trash than can be
handled within the building as designed.
Additional indoor or outdoor storage, secured
from vermin, needs to be constructed.
CS
DPR
Provide a new, or
Improve the conditions of the Brooklyn War
new expansion to, a
Memorial and restore the interior to usable
building in a park
space. Bring both the exterior and interior
spaces into ADA Compliance. [formerly Tracking
Code 202200604C]
CS DOT Rehabilitate bridges Refurbish or replace the "Triple Cantilever"
section of the Brooklyn-Queens Expressway, in Brooklyn Heights. The "Triple Cantilever" section of the Brooklyn-Queens Expressway is older than its engineered life. Failure of the structure would negatively impact traffic in at least three counties. Although part of the BQE, the Department of Transportation considers the "Triple Cantilever" a bridge. [formerly Tracking Code 202201603C]
I-278 Atlantic Ave Brooklyn Bridge
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
DOHMH
Create or promote
Increased mental health support for teenagers
programs to de-
in schools. School programs will offer easy
stigmatize mental
access and ability to provide treatment prior to
health problems
crisis situation.
and encourage
treatment
2/25
DOHMH
Reduce rat
Increase funding for rodent management in
populations
parks and Greenstreets. [formerly Tracking Code
202201603E]
3/25
DYCD
Provide, expand, or
Increase funding for after-school, Saturday and
enhance
summer programs that are built on solid youth
Cornerstone and
development principles, are evidence-based and
Beacon programs
offer a balance of sports, arts and academics
(all ages, including
within a strength-based perspective. [Formerly
young adults)
Tracking Code 202199704E]
4/25
DHS
Improve safety at
The women's shelter at 200 Tillary Street is a
200 Tillary
homeless shelters
source of a high number of 911 calls.
Street
5/25
DOHMH
Reduce rat
Large number of rodent sighting reports
populations
influenced the health department to select
Brooklyn Heights and Dumbo to be indexed and
monitored. However residents in Fort Greene
and Boerum Hill are increasingly concerned
about the growing rat populations. Restaurant
owners and owners of large residential
buildings should be encouraged to discard
garbage in rodent proof containers.
6/25
DPR
Provide better park
Fund full-time seasonal Playground Associates
maintenance
at the following locations: Fort Greene Park,
McLaughlin Park, Pierrepont Playground, 16
Sycamores Park, Commodore Barry Park,
Crispus Attucks Playground, Underwood
Playground, Washington Hall Park, Parham
Playground and JHS 113 Playground. [formerly
Tracking Code 202200602E]
7/25
NYPD
Assign additional
Increase intersection control agents in
traffic enforcement
Community District 2, specifically at Flatbush
officers
Avenue and Nevins Street, Atlantic Avenue and
Hicks Street, and Flatbush and Myrtle Avenues.
[formerly Tracking Code 202200401E]
8/25
NYPD
Assign additional
Increase personnel and equipment at the 88th
uniformed officers
Precinct. The 88th Precinct Youth and
Community Council determined that the 88th
Precinct is understaffed in comparison to the
neighboring 84th Precinct. [formerly Tracking
Code 202200704E]
9/25
BPL
Extend library hours
Increase budgets for all district library personnel
or expand and
and supplies to retain qualified staff and
enhance library
maintain high-quality service throughout the
programs
week. Maintain extended library hours and
expand library programs. [formerly Tracking
Code 202200003E]
10/25
DPR
Other park
Open clean bathrooms during the posted hours.
maintenance and
Extend hours during the summer.
safety requests
11/25
EDC
Expand tax incentive
Provide incentives or tax abatements to create
programs to help
and maintain affordable commercial and retail
neighborhood
spaces for small businesses within the district.
businesses construct
or improve space
12/25
DOHMH
Provide more
While levels of new infections are at record
295 Flatbush
HIV/AIDS
lows, rates remain high in Brooklyn, with CD2
Avenue
information and
having 33.1 new cases per 100,000 people.
Extension
services
Educational campaigns need to target the
demographic groups with the highest rates of
new infection.
13/25
DEP
Clean catch basins
Clean every catch basin in the district,
particularly those located at the corners of
Livingston Street and Bond Street, and Ashland
Place and Lafayette Avenue. There is a lot of
debris in these storm drains and on the corners
noted here, there is always standing water
during and for over 24 hours after a storm.
14/25
DOT
Conduct traffic or
Study the creation of (a) commuter van
parking studies
terminal(s) in Downtown Brooklyn and review
current commuter van pick-up and drop-off
locations. Licensed and illegal commuter vans
are creating traffic congestion without
structured stops. [formerly Tracking Code
202200801C]
15/25
DCP
Study land use and
Revaluate the Downtown Brooklyn
zoning to better
Development Plan for possible follow-up land
match current use
use action to stimulate more commercial
or future
development. The Downtown Brooklyn
neighborhood
Development Plan was intended to make the
needs
city's third central business district more
competitive in a regional market. Instead, it has
resulted in residential construction.
16/25
DSNY
Increase
Illegal dumping occurs consistently on
enforcement of
commercial streets. In some cases the
illegal dumping laws
perpetrator is obvious but current rules require
a dumper to be caught in the act. The rules/law
should be updated to include technological
evidence.
17/25
DOHMH
Promote
Increase the rates of vaccination for HPV and
295 Flatbush
vaccinations and
influenza.
Avenue
immunizations
Extension
18/25
SBS
Provide or expand
Increase the number of Small Business Services
assistance to obtain
compliance advisers to assist small businesses
licenses and permits
meet city regulations.
19/25
DFTA
Enhance NORC
At eight cooperative apartment buildings in
programs and
Community District 2 (Kingsview Homes,
health services
Willoughby Walk, St. James Tower, Ryerson
Tower, Pratt Tower, Cadman Plaza North,
Cadman Towers and 75 Henry Street), more
than 50 percent of the residents are 60-years-
old or older.
20/25
FDNY
Expand funding for
Hire additional FDNY inspectors to inspect new
fire prevention and
"high-rise" construction. [formerly Tracking
life safety initiatives
Code 202201604E]
21/25
DFTA
Enhance home care
Many of the elderly are healthy but frail and
services
need assistance with errands and, maintenance
of their homes. These adults are not provided
for in existing programs.
22/25
DOT
Conduct traffic or
A traffic study of the intersection of Flatbush
Flatbush
parking studies
Avenue and Nevins Street with the intention of
Avenue
improving pedestrian safety and vehicular
Fulton Street
traffic flow.
Nevins Street
23/25
SBS
Provide or expand
Fund biannual business planning and operations
business education
courses tailored toward the development and
to businesses and
growth of small businesses within the district.
entrepreneurs
24/25 DOT Conduct traffic or
parking studies
Fund the study, modeling and implementation of traffic control strategies to address issues identified by Community Board 2 -- as part of the Downtown Brooklyn Traffic Calming Study -- at Tillary Street & Flatbush Avenue and Schermerhorn Street & Flatbush Avenue. [formerly Tracking Code 202200502C]
image
25/25 DSNY Increase
enforcement of dirty sidewalk/dirty area/failure to clean area laws
The sidewalk outside many restaurants is covered with grease due to improper storage of trash and failure to clean after pick-up. This action provides a feeding ground for rodents.
image

