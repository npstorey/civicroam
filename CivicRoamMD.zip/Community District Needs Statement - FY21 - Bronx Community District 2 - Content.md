- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 2 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1feVQ1_jsPX6II_hPMh17ljGt9DNzyJDW/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1feVQ1_jsPX6II_hPMh17ljGt9DNzyJDW/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
2
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 2
image
Address: 1029 East 163rd Street, 202
Phone: (718) 328-9125
Email: brxcb2@optonline.net
Website: http://bxcb2.org/
Chair: Roberto Crespo District Manager: Rafael Acevedo
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community District 2 is located in the Southeast corner of the Bronx, bounded by the Bronx River on the east, the East River on the south, E. 149th Street and Prospect Avenue on the west and portions of E. 169th Street, E. 167th Street and Westchester Avenue on the north. It is comprised of the neighborhoods of Hunt’s Point, Longwood and the southeastern portion of Morrisiania. The Europeans first settled Hunt’s Point in 1663. At this time, Edward Jessup and John Richardson arrived on the peninsula and purchased the land from the Wekkguasegeeck tribe indigenous to the area. After Jessup died, his widow, Elizabeth entrusted the land to Thomas Hunt Jr., her son in-law. Once part of West Farms in lower Westchester County, the area was annexed to New York City in 1874 and began to develop after a subway line from Manhattan was extended in 1904. As more people moved to the area, the city’s business owners began to realize the advantages of locating to Hunt’s Point. Among them were the convenient access to the Tri-State region, the existing rail lines running through the Hunt’s Point area and the abundance of space available for the development of industrial and commercial activity. The population was predominantly Jewish along with a few German, Irish and Italian immigrants; later it became largely Puerto Rican and African- American. By the 1960’s local housing was deteriorating and many white residents left for the suburbs. Hunt’s Point was beset by poverty, drugs, and crime in the 1970’s and early 1980’s. Characterized by frequent arson and mass abandonment, this period was undoubtedly the low point in the area’s rich and diverse history. Living conditions became so difficult that almost 60,000 residents, approximately two-thirds of the existing population left, or were forced out, of the neighborhood during the 1970’s. Conditions later vastly improved through the initiatives of SEBCO Development Corp., Banana Kelly Community Improvement Association, South Bronx Development Corp., the Bronx Borough President’s Office, and the New York City Department of Housing Preservation & Development which created new housing and rehabilitated existing housing. The success of their efforts are clearly evident. Between 1980 and 1990, the population of the district grew by 14.7 percent, the largest margin of growth of any community in the Bronx. From 1990 to 2000 the Growth rate was 18.7 percent, the second highest in the borough. Since 1992, we have seen the development of over 4,800 new housing units. Of the new units, two-thirds are located in what were once vacated buildings and one-third are newly created low-density housing. So thorough is the development and renovation of the district that no city owned apartment building in the community stands vacant.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 2
image
The three most pressing issues facing this Community Board are:
Parks
This District is in dire need of a recreational playground where the growing number of young men and women can go to be engaged in competitive sports. Youth - Increase funding for both after school programs and summer day camp programs run by community based organizations, such as tutoring, counseling, the arts, music & education. Increase full funding for Summer Youth Programs. This District is in dire need of a recreational playground where the growing number of young men and women can go to be engaged in competitive sports.
Schools
Schools - The District is having a growth in residents without new seating capacity in the local schools. Also, the District is in dire need of more Pre-K and 3K seating. Increase funding for both after school programs and summer day camp programs run by community based organizations, such as tutoring, counseling, the arts, music & education Increase full funding for Summer Youth Programs.
Youth and children’s services
Increase funding for both after school programs and summer day camp programs run by community based organizations, such as tutoring, counseling, the arts, music & education Increase full funding for Summer Youth Programs.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 2
image
M ost Important Issue Related to Health Care and Human Services
Animal and pest control services
Increase pest control extermination services in our community to include Mosquito abatement, Raccoons, rat abatement and bedbug control.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
Increase funding for senior services enhance daily delivery service of “Meals On Wheels" and restore HEAP Program along with general food banks.
Needs for Homeless
Homeless families in shelters in the district are expressing concerns that their providers are not providing adequate services to help them acheive permenant housing and lack of support services. There is also a lack of transparency of properly informing the community when a homeless shelter is coming to the community.
Needs for Low Income NYs
Increase the number of Food Pantries and Soup Kitchens.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
8/8 DOHMH Other animal and
pest control requests
Increase pest control extermination services in our community to include Mosquito abatement, Raccoons, Rat abatement and bedbug control
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 2
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
We have an increase in population and need more seating capacity. Also, we need more Pre-k and 3K services. .
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Increase funding for both after school programs and summer day camp programs run by community based organizations, such as tutoring, counseling, the arts, music & education.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
1/5 SCA Provide a new or
expand an existing middle/intermediate school
Construct new Public Schools to address the increase in population
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
2/8 DYCD Provide, expand, or
enhance after school programs for elementary school students (grades K- 5)
Increase funding for after school programs and summer day camp programs operated by Community Based organizations.
image
3/8 DOE Other educational
programs requests
Increase funding for both after school programs and summer day camp programs run by community based organizations, such as tutoring, counseling, the arts, music & education
image
7/8 DOE Improve school safety
Increase funds for enhanced school safety/speed zone cameras
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 2
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
Increase the 41st precinct’s funds for enhanced personnel throughout the entire district due to the increase in foot traffic and vehicle traffic. Increase NYPD Truck Enforcement to address the illegal parked vehicles/trailers within Community District 2 (Every community board should have its own deployment unit: 1 Sgt. and 6-8 Officers)
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Increase the 41st precinct’s funds for enhanced personnel throughout the entire district due to the increase in foot traffic and vehicle traffic. - Increase funds for enhanced school safety personnel - Increase Park Enforcement Patrol Agents Within Community District 2 (Every community board should have its own deployment unit: 1 Sgt. and 6-8 Officers)
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
5/8 NYPD Other NYPD programs requests
Increase NYPD Truck Enforcement to address the illegal parked vehicles/trailers within Community District 2 (Every community board should have its own deployment unit: 1 Sgt. and 6-8 Officers)
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 2
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Environmental concerns affecting citizens
Illegal Dumping
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
When there is a rain storm there are certain locations in the district in which flooding is common due to: 1. No Catch Basins 2. Clogged Catch Basins
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
1/8 DSNY Increase enforcement of illegal dumping laws
Increase Sanitation enforcement to address illegal dumping within Community District 2 (Every community board should have its own deployment unit: 1 Sgt. and 6-8 Officers)
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 2
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Housing support (including tenant protection)
Affordable housing developments being created in this community is not meeting the needs of our residents because the AMI formula being used does not fit with our financial and economic needs.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
There is a need for affordable housing for single low income and middle income individuals.
Needs for Economic Development
The Hunts Point Workforce One does not provide adequate jobs that meet the needs of our community.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
TRANSPORTATION
Bronx Community Board 2
image
M ost Important Issue Related to Transportation and Mobility
Street lighting
Fund major improvements including additional lighting and scraping for the Bruckner Expressway underpasses at Brook, St. Ann's, Lincoln and Willis Avenues. These improvements are needed at these locations for the safety of the community.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/5
DOT
Install streetscape improvements
Street re-paving needed throughout District on yearly basis.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 2
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
Parks department personnel in the district is at a bare minimum and more staffing is needed. More PEP is needed to address a recent spike in homeless activity.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
District Service Cabenit meetings are mandated by the NYC Charter in which City Agencies are required to attend. However, there are agencies who do not attend at all: HPD, DOE, HRA, NYCHA and Consumer Affairs
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
2/5 DPR Provide a new or
expanded park or amenity (i.e. playground, outdoor athletic field)
Develop Drake Park African Burial Ground as a historical site and cultural center
image
4/5 DPR Provide a new or
expanded park or amenity (i.e. playground, outdoor athletic field)
Provide funding to enhance the Green-way in CB2 to include two high priority items: (1) the development of the unused DOS Marine Transfer Station on Farraguat Avenue for use as a "Seaport" attraction and establish a harbor pier patrol site and Water Taxi Stop. (2) Create a Boardwalk promenade along the waterfront parallel to the Green-way with benches and trees
image
5/5 DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Complete Printers Park Phase III
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
6/8 DPR Enhance park safety
through more security staff (police or parks enforcement)
Increase Park Enforcement Patrol Agents Within Community District 2 (Every community board should have its own deployment unit: 1 Sgt. and 6-8 Officers)
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority Agency Request Explanation Location
image
4/8 Other Other expense budget request
Increase funding for senior services enhance daily delivery service of “Meals On Wheels" and restore HEAP Program along with general food banks.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/5
SCA
Provide a new or
Construct new Public Schools to address the
expand an existing
increase in population
middle/intermediate
school
2/5
DPR
Provide a new or
Develop Drake Park African Burial Ground as a
expanded park or
historical site and cultural center
amenity (i.e.
playground, outdoor
athletic field)
3/5
DOT
Install streetscape
Street re-paving needed throughout District on
improvements
yearly basis.
4/5
DPR
Provide a new or
Provide funding to enhance the Green-way in
expanded park or
CB2 to include two high priority items: (1) the
amenity (i.e.
development of the unused DOS Marine
playground, outdoor
Transfer Station on Farraguat Avenue for use as
athletic field)
a "Seaport" attraction and establish a harbor
pier patrol site and Water Taxi Stop. (2) Create a
Boardwalk promenade along the waterfront
parallel to the Green-way with benches and
trees
5/5
DPR
Reconstruct or
Complete Printers Park Phase III
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/8
DSNY
Increase
Increase Sanitation enforcement to address
enforcement of
illegal dumping within Community District 2
illegal dumping laws
(Every community board should have its own
deployment unit: 1 Sgt. and 6-8 Officers)
2/8
DYCD
Provide, expand, or
Increase funding for after school programs and
enhance after
summer day camp programs operated by
school programs for
Community Based organizations.
elementary school
students (grades K-
5)
3/8
DOE
Other educational
Increase funding for both after school programs
programs requests
and summer day camp programs run by
community based organizations, such as
tutoring, counseling, the arts, music &
education
4/8
Other
Other expense
Increase funding for senior services enhance
budget request
daily delivery service of “Meals On Wheels" and
restore HEAP Program along with general food
banks.
5/8
NYPD
Other NYPD
Increase NYPD Truck Enforcement to address
programs requests
the illegal parked vehicles/trailers within
Community District 2 (Every community board
should have its own deployment unit: 1 Sgt. and
6-8 Officers)
6/8
DPR
Enhance park safety
Increase Park Enforcement Patrol Agents Within
through more
Community District 2 (Every community board
security staff (police
should have its own deployment unit: 1 Sgt. and
or parks
6-8 Officers)
enforcement)
7/8
DOE
Improve school
Increase funds for enhanced school
safety
safety/speed zone cameras
8/8
DOHMH
Other animal and
Increase pest control extermination services in
pest control
our community to include Mosquito abatement,
requests
Raccoons, Rat abatement and bedbug control

