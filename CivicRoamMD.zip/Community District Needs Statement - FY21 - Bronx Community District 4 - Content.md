- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 4 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1AvrEoMHFB2rq9yCXNKUpT7diQ9p00Rx2/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1AvrEoMHFB2rq9yCXNKUpT7diQ9p00Rx2/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
4
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 4
image
Address: 1650 Selwyn Avenue, 11A Phone: (718) 299-0800
Email: bx04@cb.nyc.gov
Website: www.nyc.gov/bronxcb4
Chair: Kathleen Saunders District Manager: Paul Philps
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community District Four, the Capital District is made up of the following neighborhoods: Mt. Eden, Highbridge, West Concourse, East Concourse, and Concourse Village. Our district is bounded by the Cross Bronx Expressway to the North, East 149th Street to the South, Webster to Park Avenue on the East and the Harlem River on the West. Over 145,000 residents call Community District Four home. We celebrate their distinct cultures and points of view. Our district is a great place to visit, work and live. We are the host to the world renown, Yankee Stadium, Bronx Terminal Market/Gateway Center, the Borough’s Court System, the Bronx Museum of the Arts, the future home of the Bronx Children's Museum, NYCFC soccer team and many Art Deco buildings along the Grand Concourse Historic District.
We continue to attract public and private investment leveraging our locational advantages (20 minutes from midtown Manhattan) excellent transit access, regional access with the Metro North and Major Deegan Expressway, combined with our extraordinary network of open space and recreational facilities. The district has been the beneficiary of significant public and private investments:
image
September 2017-Awarded $10 Million Downtown Revitalization Grant
image
October 2017-City Council approved Lower Concourse North. Project includes expansion and new amenities at Mill Pond Park, 1,000 units of affordable housing, state-of-the-art movie theater, and future home of the Hip Hop Museum.
image
March 2018-City Council approved Jerome Avenue Neighborhood Plan which will result in $189 invested in the creation and preservation of affordable housing, design and construction of new open space, design and construction of new state-of-the art middle school.
image
August 2018-MTA Rehabilitation and revitalization of 167th Street and 174th Street stations on the B/D subway lines.
image
September 2019-MTA announces elevator installation at 170th Street station on 4 train as part of 2020-2024 Capital Plan.
While we welcome these investments, many of which are long overdue, additional funding for both capital and expense are needed to keep pace with the steadily increasing population. While the Median HH income is half that of Manhattan and more than fifty percent of area residents are rent-burdened. Unemployment is higher than the Bronx and NYC and almost double that of the national average. In a District where many people are struggling on a day-to-day basis, we need to invest and allocate more resources to job training/development and job creation to provide a solid employment network for area residents. Traffic and congestion continue to plaque the district.
From Yankee game days, concerts, football, soccer games and tour buses, the levels of pedestrian and vehicular traffic are unprecedented. Infrastructure investment is one of our greatest needs. Roads, subways and buses are bursting at the seams. The construction of the 153rd Street Bridge would not only provide relief for area traffic congestion, it would create significant economic development opportunities and transform the landscape of the South Bronx. Growth and prosperity can be advantageous to everyone, but only if it is facilitated in a manner that is inclusive and equitable. We want the district to continue to progress, but only if it is done responsibly with integrity and with input and consideration for all constituents.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 4
image
The three most pressing issues facing this Community Board are:
Quality of life issues (noise, graffiti, petty crime, etc.)
Noise complaints (particularly in the summer months) a result of congregating and hanging out on residential blocks impedes residents ability to coexist peacefully and enjoy the sanctity of their home.
Schools
The construction of a new 458-seat middle school as part of the Jerome Avenue Points of Agreement satisfies a long-standing need, however we must keep pace as new needs arise from additional growth.
Youth and children’s services
Programming and services for youth are also a top priority in the District, where sixty percent of the community is foreign-born (compared to thirty-seven percent of New Yorkers), thirty percent of community members have limited proficiency in the English language, and a quarter of area residents live below the poverty level. Equity demands investments in resources for the District's youth, such as youth centers, an expansion of the New York Public library system, and new public schools, so that the our youth will be prepared for success as adults living in the District.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 4
image
M ost Important Issue Related to Health Care and Human Services
Chronic diseases (diabetes, heart disease, etc.)
We are home to a young, predominantly minority population. Compared to the U.S., the prevalence of some health risk factors, including: obesity; lack of access to fresh produce; and obesity which can lead to diabetes and hypertension. Poverty plays a key role in these factors, as thirty-six percent of area residents live below the poverty level (4th highest among all Community Districts). According to the 2018 Community Health Profile, the adult obesity rate is 34% higher than the rest of NYC. Obesity can lead to high-blood pressure, diabetes and other chronic diseases. Seventeen percent of residents have been diagnosed with diabetes and 42% of adults have been diagnosed with hypertension. These and other factors contribute to the high prevalence of chronic diseases that are not well managed in the district. Education plays an important role in improving community health, and we are therefore advocating for a significant increase in funding for community- based education, programming and services focused on health and wellness with a focus on access to healthy food and active living. DOHMH in collaboration with CDOT and DPR and a strong network of community-based organizations can effectively begin to stem the tide here, and improve the District's health profile.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
As the senior population grows in the Borough and the District we must ensure that we actively engage in programs and services to benefit our elderly population.
Needs for Homeless
Bronx Community District Four does not want to be viewed as a community that is insensitive to needs of the homeless. Homelessness is a serious issue in New York City and we have done our part in working with organizations that provide supportive housing in our community and taking on more than our fair share of these types of facilities. We have serious concerns and issues related to DHS regarding its communication and notification process. There have been a number of policy and procedural changes pertaining to housing the homeless that we support; however, we must be viewed as partners and treated accordingly when homeless individuals and families are to be housed in the District. We need to fully understand the scope of changes being proposed by the Department and the City and how they will be implemented to address the issue of homelessness. We request a commitment from DHS and the City that they will engage in a substantive conversation regarding changes to communicate more thoroughly and regularly with respect to their considerations and proposals. The concept of "fair share" is deeply flawed as there appears no real mechanism to enforce that policy. Numbers tell the story and Community District Four leads all community districts in the number of shelter facilities and the number of homeless people sheltered in addition to having the only DHS intake facility in the district. Distinctions we are less than thrilled about. We will continue to reiterate our position that we are uninterested in the siting of any new facilities in our district or increasing the number of homeless families and individuals we house.
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
15/29 DHS, HRA
Other homelessness prevention program request
We recommend that DHS strengthen its partnership with HPD to increase the number of new affordable housing units made available to individuals and families. Currently the set aside for homeless families is 10%. This is particularly important as Community District Four has the largest number of cluster sights citywide, a high proportion of homeless facilities and a DHS intake center within its borders.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
11/26
DFTA
Increase
Access and mobility are major concerns for
transportation
seniors in the District. We request that DOHMH
services capacity
collaborate with existing senior centers and care
providers in the district to create additional
programs that will allow seniors to get out for
shopping, exercise and entertainment. Mid-
Bronx Senior Citizen Council, Highbridge
Community Development Corporation and
BronxWorks are organizations that work with
seniors and operate senior facilities in the
District.
12/26
DOHMH
Create or promote
Actions to assist in the reduction in obesity and
programs for
diabetes among residents in the district 1.
education and
Promote healthy eating options. a. Throughout
awareness on
the district, there are limited options for
nutrition, physical
purchasing healthier foods at grocery stores and
activity, etc.
restaurants, particularly in our commercial
corridors. We support programs such as the
DOHMHs Shop Healthy Initiative help to
educate store owners on how to provide positive
messaging, setup healthier alternatives, and
work with distributors to bring healthier foods
to the stores. b. We also ask the NYCEDC to
support the DOHMHs mission of expanding
access to healthier foods by considering
significant modifications to the Food Retail
Expansion to Support Health (FRESH) program.
These modifications should include smaller and
varied tax break options.
15/26 DOHMH Create or promote
programs to de- stigmatize mental health problems and encourage treatment
We have a number of facilities throughout the district for formerly homeless individual and families. Many of these are individuals with a history of mental illness. While we do not advocate for any additional facilities of this type in our district we want to ensure that the individuals that are here receive proper care.
This benefits the individuals and their families as well as area residents. DOHMH should work with DHS to identify these facilities and target those that would benefit from additional programming and/or services.
image
16/26 HRA Assist low income
households in paying for energy costs
Fifty-six percent of all District households are rent-burdened, meaning their gross rent was more than 35 percent of their household income. We request that HRA work with Con Edison, DEP and HPD to create literature and conduct outreach educating tenants on how to save energy and lower energy costs.
Additionally, HPD should continue to target older buildings in need of upgrades and offer low-interest loans to upgrade energy systems throughout - with the strict and clear understanding that the cost of these upgrades are to be shouldered by building owners, and NOT tenants.
image
17/26 DHS, HRA
Provide, expand, or enhance rental assistance programs
Homelessness has reached historic levels in NYC. According to the Coalition for the Homeless, as of August 2019, there are 61,674 homeless people, including 21,934 homeless families with 21,802 homeless children, sleeping each night in the New York City municipal shelter system.
Families make up nearly three-quarters of the homeless shelter population. The city is investing hundreds of millions of dollars in new affordable housing. We respectfully request that the City ramp up it's efforts to permanently house families and individuals living in the shelter system.
image
18/26 HRA Provide, expand, or
enhance job training
Unemployment plays a key role in the socio- economic status of local residents. While unemployment both nationally and in the Bronx has hit record lows (3.7 percent and 5.6 percent) respectively, unemployment in Community District Four is slightly higher at 7.4 percent.
While the percentage of unemployed residents has consistently decreased, we must continue to create jobs and economic opportunities.
Moreover, tens of thousands residents are underemployed, and therefore, still impoverished. Community District Four advocates for HRA to work with SBS, EDC and community-based organizations to create better employment opportunities for District residents.
image
20/26 DOHMH Create or promote
programs for education and awareness on nutrition, physical activity, etc.
As nearly forty percent of our population is under the age of 25 it is important to underscore the importance of nutrition, healthy eating and physical activity. We request that DOHMH increase outreach and education related to food and nutrition. There should be a focus on targeting middle schools and working with community-based organizations with youth programs and active tenant associations and groups. Bronx Lebanon Hospital and Hostos Community College should be leveraged as resources.
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 4
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
SCA identified a number of unfunded seats in their FY2015 – 2019 Capital Plan. A new 458-seat primary school will be built in CSD 9 (Block 2871, Lots 61, 140). The city will also construct a new 572 seat school in CSD 7, Sub district
3. That being said the SCA released a new 5-year capital plan this year which will likely identify additional seat shortfalls. In addition, the district continues to see new residential construction and from 2006-2016 the population has increased more than thirteen percent. Lack of adequate school seats and overcrowding has a direct impact on children's ability to learn. The city should be much more proactive in researching and identifying new school sites across the district.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Educational attainment plays an important role in an individual’s employment profile and their capacity for career advancement, which directly impacts the economic empowerment of that individual's family. However, the physical condition and location of educational facilities, while not a holistic solution, is an important component of that formula. The development of quality educational facilities will mitigate overcrowding while creating an environment that fosters learning and child well-being. Educational attainment is one of the key indicators of success and quality of education provided and acquired by area residents. Currently the percentage of residents with less than a 9th grade education and from 9th grade to 12th grade is nearly double that of NYC. Furthermore, the district trails both the Bronx and NYC in terms of percentage of residents with Bachelors and Graduate degrees.
Needs for Youth and Child Welfare
Nearly thirty percent of Community District Four's residents are under the age of 18, and many of these residents are immigrants or children of immigrants who live below the poverty threshold. With an Area Median Income of
$32,120, the City must make every effort to support Community District Four's low-income families in every way possible, via a wide variety of services and programs relating to children and child welfare.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
3/29 SCA Provide a new or
expand an existing middle/intermediate school
The Jerome Avenue Neighborhood Plan calls for construction of a new 458-seat primary school with a state-of-the art gym. CSD 7 is currently operating near capacity . As part of the Lower Concourse North project the city has agreed to construct a new 572 seat middle school. SCA has released its 2020-2024, likely resulting in additional deficits and capacity issues. We respectfully request siting and funding to address seat deficits in the next SCA capital plan.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
4/26
DYCD
Provide, expand, or
Community District Four's many working
enhance after
families and single-parent households require
school programs for
no-cost after-school care. Free after-school care
middle school
allows parents to work and maintain
students (grades 6-
employment, keeps children safe, and enhances
8)
children's educational attainment. It also allows
families to use scarce financial resources on
other pressing needs. Accordingly, we request
that DYCD increase funding at existing
organizations district-wide to provide after
school programs. They should also partner with
local schools to provide additional funding to
site after schools programs.
19/26 DYCD Provide, expand, or
enhance the Summer Youth Employment Program
As stated previously we have one of the highest teen birth rates and some of the lowest numbers in terms of English and Math proficiency. Providing positive reinforcement to our youth is important and Summer Youth Employment is desperately needed particularly in a District with a meager Area Median Income ($32,120) and nearly thirty-five percent of the population living at the poverty level. DYCD should continue to increase funding for Summer Youth Employment. DYCD should also work with local organizations and the Bronx Borough President's office to create additional work places to host youth for the summer and throughout the school year as well.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 4
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
In January 2019 it was reported that the 44th precinct was one of six identified to have violent crime rates at least twice as high as the city average representing some of the city's most undeserved neighborhoods The District has experienced a notable increase in shootings and gang-related activity. Gang-related activity continues to plague certain areas within the District and significantly impedes residents' quality of life. The 44th precinct does an outstanding job with the resources available, but clearly more resources and different strategies need to be employed to keep the district and particularly the residents of Highbridge safe. An investment in more resources for the 44th precinct, i.e. more officers is necessary to adequately address the unique needs of a district that increases in population and activity from year-to-year.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The Neighborhood Coordinating Officers (NCOs) program (which is loosely based on the Senior Lead Officer Program in Los Angeles, where senior lead officers help organize and direct crime-fighting and quality-of-life initiatives in each of the Los Angeles Police Department’s 22 divisions) has been extremely well-received by Community District Four. We continue to have an excellent rapport with the NYPD's 44th precinct. They are committed, professional and very responsive. We want them to be equipped with sufficient and adequate personnel to handle the activity in the District as we focus on working together with the precinct to stem all crimes, improve quality of life, and provide a safe environment for all community residents.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
14/29
NYPD
Add NYPD parking
Parking is an enormous issue district-wide. The
East 169th
facilities
44th precinct currently has vehicles parked on
Street Jerome
the streets, sidewalks etc. There are a number
Avenue East
of lots and garages nearby. We request that the
168th Street
city purchase one of those for the sole purpose
to store NYPD vehicles and NYPD officers
personal vehicles to alleviate congestion,
provide more on-street spaces for residents and
create a safer, pedestrian friendly environment.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
8/26
NYPD
Assign additional
The 44th precinct is one of the most active in
uniformed officers
the city. We recently received new recruits from
the academy but as the District grows we need
growth in our key service sectors to keep pace.
We request the City allocate funding for more
permanent new officers in the next fiscal year.
The Community Affairs Division is fantastic and
with more officers in the division there is a great
opportunity to increase their presence and
awareness district wide and increase positive
relations between police and the community.
We request an increase in officers as well in the
next fiscal year.
9/26
NYPD
Assign additional
The Community Affairs Division is fantastic and
community affairs
with more officers in the division there is a great
officers
opportunity to increase their presence and
awareness district wide and increase positive
relations between police and the community.
We request an increase in officers as well in the
next fiscal year. This will be particularly helpful
in staffing the NCO program and assigning
additional resources to parts of the district that
need it most. (i.e. Highbridge)
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 4
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
We have received a number of upgrades throughout the district to more environmentally-friendly trash receptacles for heavily trafficked commercial areas, as well as silver bullet receptacles to replace wire baskets along the Grand Concourse. We have also received increased pickup service and cleaning for the new receptacles. The District wants to continue to increase its SCORECARD number--particularly with respect to the cleaning up of dog waste. We request that sanitation enforcement be properly staffed to handle the pickup and cleaning needs in the District as the District's population and its associated waste management needs continue to grow.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
The cleanliness of the Capital District is critical as we see more than 3.5 million tourists each year and counting. In order to continue to attract investment and economic opportunity it is on the critical path that we enhance our image as one that is clean and safe. We urge the restoration of DSNY personnel, including "hand" cleaners, to adequately maintain our streets and sidewalks. Community District Four experiences difficulties with irregular cleaning and maintenance schedules for the extraordinary number of underpasses, step streets and sitting areas located in our district. We recommend a concerted inter-agency approach to address high traffic areas . While we understand that resources are limited we ask that given the steadily increasing population growth in our district and increased levels of activity in terms of events, tourism and transit ridership be given consideration and that significant additional resources be allocated.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
3/26 DSNY Increase enforcement of dirty sidewalk/dirty area/failure to clean area laws
This should be concentrated along commercial corridors (East 167th Street, Ogden Avenue, East 170th Street and 161st Street area.)
image
25/26 DSNY Provide more
frequent garbage or recycling pick-up
In highly trafficked commercial areas: 161, 167th, 170, Mt Eden and around our highly used park facilities there should be concerted efforts to clean those areas during peak times and after events.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 4
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing preservation
Housing New York: A Five-Borough, Ten Year Plan is Mayor de Blasio’s comprehensive plan to address the City’s affordable housing crisis. The plan seeks to invest in the development of 80,000 new income restricted units and preserve 120,000 existing affordable housing units over a ten-year period. The plan is projected to create 194,000 construction jobs and 7,100+ permanent jobs. The Housing Plan presents a tremendous opportunity to protect area residents who are most vulnerable to displacement, while also creating opportunities for residents to grow within and/or return to these neighborhoods, and provide permanent jobs in the construction trade. With a large inventory of stable affordable housing stock (more than 60 percent of housing in the District is regulated) we feel that a multi-pronged approach to maintain affordability in housing for existing tenants will help support many of our low-income residents and is the District's top housing, economic development, and land use priority. Fifty-six percent of all households in Community District Four are “rent-burdened.” The City has a great opportunity and responsibility to preserve affordable housing in a densely-populated community district where a third of residents live below the poverty level and public subsidy plays a pivotal in new housing construction. In order to increase the income levels and improve the socio-economic status of local residents in District Four, there must be significant investments in job training, job placement, skills assessment and business development. The Department of Small Business Services (SBS) and to a lesser degree the NYCEDC should play a key role in facilitating programs and policies to achieve these goals.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Community District Four continues to evolve through a series of land use changes over the past several years including: Lower Concourse North (aka Bronx Point) and Jerome Avenue Neighborhood Study. The Jerome Avenue Neighborhood Plan has committed considerable resources to the development of affordable housing, new open space and improvements to transportation infrastructure. Bronx Point will lead to the development of more than 1,000 units of affordable housing, more than 2 additional acres of open space through the expansion of Mill Pond park and improvements to key intersections on 149th street and Exterior Street. Over time as these changes come to fruition, the landscape in these areas and surrounding blocks will be significantly altered. Today more than 145,000 people reside in Community District Four. This growth will continue while the community faces a number of challenges including high unemployment, rising rents, access to fresh food, open space, access and mobility, health and wellness and affordable housing. Community District Four has a number of city-owned properties currently used for parking. These properties are a woefully underutilized public resource. Many of the aforementioned issues and challenges could be addressed by changing the use of these parcels to better serve area residents. In October 2019, on behalf of Community Board Four the Urban Land Institute (ULI) will conduct a Technical Assistance Panel (TAP) to develop ideas/recommendations around the redevelopment of these city-owned parcels. The results of the panel's findings could be used to inform future District Needs Statements and Budget Priorities. We will continue to monitor these properties to ensure that any change in use is reflective of community needs and maximizes the return on a valuable public resource.
Needs for Housing
Achieving economic diversity in Community District Four is critical to the District's growth and well-being; accordingly, we are requesting an investment in new affordable housing units for moderate- and middle-income individuals and families, in addition to the preservation and development of affordable housing for low-income individuals and families. While the median income is $32,120 in the District, the majority of District residents are rent-burdened and otherwise economically disadvantaged. While ensuring the development and preservation of affordable housing at lower-income tiers is a top priority, we also want to create opportunities for middle and
moderate income residents to live in the District allowing upwardly mobile so that residents are able to remain in the District and benefit from the District's economic growth. This includes options for home ownership. Currently, most new developments do not offer many options for people such as recent college graduates or a two-parent households who have worked themselves through college or trade school and can afford better and larger living accommodations. If we do not create more opportunities for higher income earners, the District will continue to be marked by high unemployment and a low median income; moreover, the District will continue to miss out on the benefits of an economically diverse population. We request new affordable housing developments for moderate- and middle-income families so that the District's residents can stay in the District as they grow and prosper--thus, bringing prosperity and growth to the entire District. We also must reiterate that we are longer interested in any type of supportive housing particulary any with DHS affilaition.
Needs for Economic Development
Community District Four benefits from the regional draw of the 161St Street/Capital District area, including: the Bronx County Court; Bronx Supreme Court; the 161st Street BID; waterfront access; Bronx Terminal Market's million square feet of retail; and Yankee Stadium, which draws more than 3.5 million visitors per year. Major employers include Bronx Lebanon Hospital, the Yankees and Hostos Community College. The District looks to increase its competitiveness for investments from both the public and private sectors, and enhance commercial opportunities, in order to enhance the District's economic development and provide more amenities and resources for District residents. Currently, unemployment is high, outpacing unemployment rates in the Bronx and in New York City overall. Furthermore, a large number of area residents are underemployed. In order to increase the income levels and improve the socio-economic status of local residents we request significant investments in job training, job placement, skills assessment and business development. Currently, the closest Workforce One Center is located in Hunts Point or on Fordham Road, both of which are inconvenient for District Four residents. In order to serve the thousands of job seekers, existing and future business owners the city should develop a new Workforce One Center. Such a center would bridge the gap between the existing centers and could focus specifically on the linguistic and educational needs of the District's large Latin, Caribbean, African-American, and West African immigrant populations.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
11/29 SBS Other capital workforce development requests
Develop a new Workforce One Center -Currently the closest Workforce One Center is located in Hunts Point or on Fordham Road. In order to serve the thousands of job seekers, existing and future business owners the city should develop a new Workforce One Center as a part of the Jerome Neighborhood Plan. -The center would bridge the gap between the existing centers and could focus specifically on local needs: large immigrant population (Latino and West African) and the auto-industry.
image
17/29 HPD Provide more
housing for medium income households
To increase the Districts economic index, we support the development of affordable housing for moderate and middle-income individuals and families as an added element to our new housing stock. The lack of affordable housing at these income levels contributes to the flight of moderate and middle-income families from our district. It is in the interest of our Community District to promote economic diversity within our community. We strongly advocate for City and State funds for the middle-income new construction program and the creation of independent living facilities for seniors. We strongly encourage the use of public funds at the city and state level for permanent affordable housing and home ownership, not supportive housing (DHS related).
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
5/26
SBS
Other expense
Continued support for the creation of the
workforce
Jerome Avenue Workforce partnership to enable
development
them to develop a employer/employee network
requests
similar to the Lower East Employment Network
for the purpose of engaging developers,
potential employers in the neighborhood,
providing sector-specific training for local
residents, screening candidates for available
positions in emerging markets as well as make
referrals where necessary. Localized Street
Vendor Program o Create a pilot program with
DOHMH, SBS, MOIA and DCA o Legitimize
existing food carts operating without a license
(smaller fee) Ensures/promotes health and well-
being by creating standards for business
operation Incentivize program for small mom
and pop businesses to grow as the
neighborhood grows.
6/26
NYCHA
Expand programs
HPD should increase its funding for code
for housing
enforcement inspectors and provide incentives
inspections to
to property owners to repair and retrofit their
correct code
buildings in accordance with the building codes
violations
like 8A loan and Participation loan programs.
The city should reinstate the Neighborhood
Preservation Office to deal with code
enforcement, anti-harassment and
displacement. This would provide a team of
individuals geographically-based to deal
immediately and directly with these issues.
10/26
DCP
Study land use and
Community Board Four request that DCP
zoning to better
engage in a master planning exercise to
match current use
determine the highest and best use for the city-
or future
owned parcels concentrated along Jerome
neighborhood
Avenue and around Bronx Terminal Market. This
needs
approach ensures that the redevelopment of
these parcels reflects community needs and
integrates with the existing fabric of the
neighborhood. Uses that should to be
considered: Development of affordable housing
at a variety of income levels including home-
ownership (NO SUPPORTIVE HOUSING) New
Schools for CSD 7 and CSD 9, new community
facility space, inclusion of small businesses and
non-profit entities as part of mixed-use
developments to encourage entrepreneurship,
new open space and state of the art
recreation/community centers similar to West
Bronx Recreation Center.
image
13/26
SBS
Assist with on-site
business compliance with City regulations
As part of the Jerome Avenue Neighborhood
Study -Enable businesses to be better neighbors by offering comprehensive services related to compliance and auto-industry standards. Work directly with business owners to remedy violation and licensing to increase their compliance.
Jerome
Avenue Mcclellan Street Cross Bronx Expressway
14/26
EDC
Expand access to low cost financing to help neighborhood businesses construct or improve space
We should support the continued growth and expansion of small businesses throughout the District. EDC and SBS should partner to help small businesses develop business plans and financing packages to support them. They should think outside the box to create new programs and incentives that address the needs of area residents. They should partner with local financial institutions like Spring Bank.
TRANSPORTATION
Bronx Community Board 4
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
The residents of Community District Four continue to voice their concerns and frustrations related to traffic congestion. The District's traffic-related challenges will be exacerbated by new hotel and residential development and an increase in film and television permits, if an investment in traffic management and mitigation measures is not undertaken immediately. While Community District Four welcomes economic activity with enthusiasm, area residents must benefit, and certainly not be further disadvantaged by that activity. The District requests clarification with respect to the traffic reconfiguration plan for the "Court Corridor" in addition to far better communication from all city agencies, particularly from the Mayor's Office of Media and Entertainment on street closures, alternate routes and No Parking. Traffic congestion is a serious issue that negatively impacts residents' quality of life and the end benefit for Community District Four residents remains to be seen. We also request the placement of permanent traffic control agents at said “Corridor” area for traffic relief assistance at a minimum during peak periods and special events, such as Yankee Games, concerts, College Football, Bronx Week, etc.. We also request that those with parking placards not "create" additional parking in areas not designated for parking and adhere to the same rules as all other drivers. We ask for cooperation from traffic enforcement to ensure these rules and procedures are followed.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
We continue to voice our concerns about traffic conditions in our District and advocate for the development of the East 153rd Street Bridge. While we understand the project remains in the projected capital plan, we stand firm in our support for the bridge development, which we believe would ease traffic congestion along 149th and 161st Streets, as well as create much needed jobs and be an economic development driver for the district. Transportation and traffic are of particular importance to us since aside from being the "Capital District" of this County; Community District Four is also the geographic center of the metropolitan region. In 2006 construction was to commence and the Department of Transportation received the Art Commission Award for Excellence in Design. The proposed bridge is a single tower cable stayed bridge, located over the Old Mott Haven Rail yard, connecting Concourse Village West at the west end and Park Avenue at the east end. It would have been the first new bridge built in 50 years and the first cable-stayed vehicular bridge in New York City. Bronx Point which will include 1,000 units of affordable housing, a cinema, retail and office space and the Hip Hop Museum, the Bronx Children's Museum and the potential development of a soccer stadium, hotel and other uses on city-owned parcels subleased to Bronx Parking Development, underscore the critical need to develop the 153rd Street Bridge. It should be noted that none of the aforementioned projects were contemplated at the time the bridge was slated to be constructed. We should also note that City Island, an area with far less density rejected a state-of-the art design for a bridge and subsequently settled on a more straight-forward bridge that was recently completed. The Community Board has long advocated for measures that would make parking easier while reducing congestion and improving safety. It is important to note that as we start from square one with this request, new development continues not only in Community District Four but also Community District One, Yankee Stadium has now become a year-round operation hosting soccer, concerts, hockey and football. All of this significantly increases the number of people traveling in around and to the district year round.
Needs for Transit Services
Access and mobility throughout the area is key.The MTA currently operates at 468 subway stations citywide and 230 bus routes. More than 80 percent of District residents use public transportation to commute to work and for other official/personal engagements. This includes the 4 train (one of the busiest in the entire network, which currently operates over capacity with no quantifiable plans to mitigate the issue), the B/D trains, and the Bx1/2 (the 6th busiest bus route in the city). It should be noted that the Bronx has the largest bus ridership of the five boroughs.
Additionally, the District population has increased nearly 20 percent between 2000-2016, and continues to grow. Consequently, improvements to existing transportation infrastructure--including increased service; increased accessibility for residents living with disabilities and families operating strollers; improvements to local streets; enhanced lighting, and the resurfacing of our most vital north-south corridor - the Grand Concourse - are top District priorities.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/29
DOT
Other
153rd Street Bridge We continue to voice our
153rd Street
transportation
concerns about traffic conditions in our District
and Park Ave
infrastructure
and so we continue to advocate for the
requests
development of the East 153rd Street Bridge.
We stand firm in our support for development of
this bridge, which would alleviate traffic
congestion along 149th and 161st Streets and
local streets in the neighborhood. The proposed
bridge would be a single tower cable stayed
bridge, located over the Old Mott Haven Rail
yard, connecting Concourse Village West at the
west end and Park Avenue at the east end.
2/29
NYCTA
Improve
Provide an elevator/or escalator along the 4 at
accessibility of
Burnside or 170th Street and one on the B/D
transit
line between East 167th Street and East 183rd
infrastructure, by
Street.
providing elevators,
escalators, etc.
7/29
DOT
Reconstruct streets
The entire 161 Street corridor should be
resurfaced and is in need of major
improvements. Removal and resurfacing asphalt
and brick. The Board has complained about this
for many years. The redbrick and asphalt along
the corridor is cracked and is in serious need of
repair. In addition, the texture of the brick does
not allow for safe travel during inclement
weather because it becomes very slippery and
slick. The corridor sees increased vehicular and
foot traffic with more tourism, filming and
events. The resurfacing should focus on 161 and
intersecting street segments from Macombs
Dam Road to Park Avenue.
8/29
DOT
Repair or build new
step streets
There are a total of 17 step streets in the
District. (7) are Top 20 priority Step Streets but as more than 70 percent of area residents use public transit or walk, connections and access are of the utmost importance. We request a schedule and timeline for rehabilitation of all step streets in the district and a discussion on priorities based on travel patterns and connections to transit, major institutions and employers. Priority should be given to the following: 1) Clay & 169th Street 2) Jerome near Anderson Behind PS 73 (include lighting) 3) 168th Street (Shakespeare to ELG) 4) Shakespeare and Anderson (167th Street) We also request that CDOT and DSNY collaborate on a comprehensive maintenance and clean up program for these step streets with regularly scheduled clean ups.
9/29
NYCTA
Repair or upgrade subway stations or other transit infrastructure
Station Enhancements/Rehabilitation: 170th Street Mt. Eden Avenue
10/29
DOT
Repair or provide new street lights
Install higher intensity lighting along Jerome Avenue. This special lighting is needed due to the elevated rail lines that cause the area to be dark and unsafe due to the poor lighting.
Jerome Avenue 161 Street 174th street
12/29
DOT
Install streetscape improvements
We request streetscape improvements be made around commercial corridors including painting, lighting, seating and improved circulation and mobility. (167th Street, 170th Street and Mount Eden)
16/29
DOT
Other transportation infrastructure requests
The Board request that the Department of Transportation conduct full rehabilitation and upgrade to underpasses at 170th, 167th Street, 174th Street, specifically replace the metal protective mesh, the chipped, and spalled concrete. Enhanced lighting would also be appropriate at these sites.
22/29
DOT
Other transportation infrastructure requests
Exterior Street from 150 Street to 153rd Street (exit ramp to Major Deegan Expressway North). We request that DOT mimic all new capital infrastructure investments being made as part of the Bronx Point, particularly as the Bronx Children's Museum is scheduled to open in 2019.
Exterior Street 150
153
23/29 DOT Repair or construct
new curbs or pedestrian ramps
Exterior Street from 150 Street to 153rd Street (exit ramp to Major Deegan Expressway North). We request identical treatments for curb cuts and pedestrian ramps as Bronx Point, particularly as the Bronx Children's Museum is scheduled to open in 2020.
Exterior Street 150
153
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
2/26
NYCTA
Expand bus service
Increased bus service in areas such as
frequency or hours
Highbridge to improve access for area residents
of operation
and merchants -Bx3, BX11, Bx36 or Bx18, BX6,
Bx35, BX36,extent line along BX32 to 167th
street, BX40/41, BX42
23/26
NYCTA
Provide a new bus
Explore the possibility of a Select BX19 and
service or Select Bus
Select BX1 to accommodate the continued
Service
growth along the Grand Concourse and along
the 149th Street corridor.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 4
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
Community Board Four represents the Bronx’s Capital District -- which includes the Borough’s Executive, Judicial and Economic Power and significant parkland including Franz Sigel, Joyce Kilmer, Mullaly, Macombs Dam and Claremont parks. We are very excited about the future investments to Grant Park, expansion of Mill Pond Park and the development of Corporal Fischer. Given the existing open space network and pending additions to our parks portfolio, we respectfully request that the NYC Parks Department and local elected officials invest in the maintenance of the District's many parks, playgrounds, and green spaces. Community Board Four is also home to Yankee Stadium, which draws over three million visitors worldwide each year. The stadium hosts more than 80 home games, the annual Pinstripe Bowl (NCAA), Army college football games, boxing and soccer matches, concerts and hockey matches annually. In addition, a number of significant parks/cultural/community facility-related capital projects are underway in the District, including the redevelopment of the 149th Street Post Office, Bronx Point which includes upgrades and the expansion of Mill Pond Park and the Hip Hop Museum, the opening of the Bronx Children's Museum and the expansion of the Bronx Museum of the Arts. The cleanliness and upkeep of the district's parks, cultural assets, and community facilities are essential to the overall health and well-being of the District and are critical to the enjoyment of area residents and millions of visitors to the area each year. In addition to park care and maintenance, the relocation of the Community Board office is a top priority. We are currently located on the 11th floor of a residential building that is not handicapped accessible. The elevators are consistently out-of-order leading to wait times of up to thirty minutes. We need to be in an office setting with the appropriate infrastructure and access to enable us to provide adequate service delivery for area constituents.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Open space and greening play an important role in quality of life for area residents and workers. Community District Four benefits from some of the most active open space resources in the Borough with its proximity to Yankee Stadium which hosts baseball, soccer, hockey and football year round and sees millions of visitors every year. We also have the greatest number of parks properties in the Borough (101) and counting. In recent years parks we have added Mill Pond Park to our portfolio, the redevelopment of Macombs Dam Park and capital investments in various other parks throughout the District. As we look to increase our portfolio with the development and expansion of Grant Park, development of Corporal Fisher and the expansion of Mill Pond Park, maintenance and upkeep are critical for residents and visitors to benefit from our vast open space portfolio and to continue to attract tourists and public and private investment. Now more than ever the role of a Parks Administrator, additional PEP officers, maintenance and horticulture staff are on the critical path to maintaining the Capital District's competitive edge.
Needs for Cultural Services
We need to expand the education and recreation opportunities available to everyone in the district, particularly our young people. The Bronx Museum of the Arts and the Bronx Children's Museum are valuable resources for arts and culture that provide a tremendous resource to the district and should receive consideration for additional staff and funding and programming.
Needs for Library Services
Community District Four has three branches of the New York Public Library (NYPL) system: Grand Concourse, High Bridge, and Melrose. According to NYPL statistics (below), in Fiscal Year 2018 the libraries in CB 4 had 340,986 visits. With programming ranging from early literacy classes and technology training, to citizenship assistance and English language courses, as well as unlimited access to free internet and laptops and computers; NYPL consistently provides a depth and breadth of free, essential services that simply cannot be matched. These programs are extremely important to residents, especially our immigrant, elderly and underserved communities, as they often cannot otherwise afford access to commercial alternatives. As you know, libraries are often the first place that
communities turn to for help and information, and our branches are uniquely positioned to provide relevant and up to date information to New York’s most vulnerable populations. Libraries are a place for learning and for safe and open access to information.
Needs for Community Boards
We recently received a funding increase of $42,500 due to City Council support. These funds were utilized to upgrade office equipment and support more than (9) community-based events. That being said without increased funding that is base lined to hire more staff it becomes more and more difficult to manage the increased day to day responsibilities. We have seen significant increases in population growth and economic development activity. This results in more people, businesses, children and entities to serve. We are currently operating on an internal budget of $233, 911 for a district with more than 145,000 residents. Actually, the financial figure is far less than that since much of the Board's budget is pre-allocated for fixed expenses. Community Boards provide direct and almost immediate access between community residents and city government. That link should be strengthened. We are the integral link between the community and a multitude of city agencies that provide services to the district. We are called upon with greater urgency to fill the gaps without the adequate financial resources to support those endeavors. Community Boards are essential to community engagement and participation in all facets of city government and we believe wholeheartedly in fulfilling our mission to the best of our abilities. We are grateful that the City Council and the Mayor increased our budgets, but we still have more work to do and in order to better serve the district additional funding for staff is necessary to achieve those goals. With adequate fiscal support, Community Boards can go beyond essential service delivery and become an invaluable resource for the community, the borough and the city.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
4/29
DPR
Provide a new or
Corporal Irwin Fisher Park is approximately 1.5
WEST 169 ST
expanded park or
acres of gated, unimproved NYC Parks green
amenity (i.e.
space that has never been accessible by the
playground, outdoor
community since its acquisition some twenty
athletic field)
years ago. The Community and the Community
Board urge the city to fund the design and
development of this park and target pre-teens
(teenagers can use the ample Nelson Avenue
Park facilities two blocks away.) This park will
serve a community that continues to grow and
provide recreational space that our children
rightfully deserve. Through the Jerome Avenue
Neighborhood Development Fund (NDF) $4.62
million was allocated.
5/29
DPR
Improve access to a
Grant Park was to be completed in stages to
building in a park
permit continued use by children of some areas
of the park. However, the development of a
series of large sink holes in the children's play
area in the park's southwestern quadrant has
effectively shut down the entire park
indefinitely. This adversely impacts the entire
community the park has historically served.
Currently nearly $30 million ($25.7 through
NDF) has been allocated for reconstruction of
the park, roadbed, playground and basketball
court.
6/29
DCAS
Renovate, upgrade
Community Boards play an integral role in
575 Exterior
or provide new
dealing with land use and zoning matters, the
Street
community board
City budget, municipal service delivery and
facilities and
many other matters critical to the quality of life
equipment
of thousands of area residents. Our current
location does not allow for such engagement, as
mandated by the NYC Charter. We are currently
located on the 11th floor of a residential
building in (2) apartments adapted for office
use. We respectfully request relocation of the
Board office to a location more suitable for the
agency's mission. We have had preliminary
discussions with the Bronx Point development
team as well the developer of Concourse Village
West. Furthermore we request that the future
redevelopment of any city-owned property be
given consideration for new relocation
13/29
DPR
Other requests for
park, building, or access improvements
Active development of a contiguous path joining
the bike/run waterfront paths along Mill Pond Park (in Bronx CB4) to Roberto Clemente State Park (Bronx CB5) which also has a segment of a new bike/running path along the waterfront that ends at a chain linked fence separating the park land from property belonging to the Metro North/MTA train car cleaning facilities at the parks southern border. Using the precedent of the Riverbank Park in Manhattan, a similar greenway can be developed along the perimeter of the MTA's Bronx facility.
18/29
DPR
Reconstruct or upgrade a building in a park
Both the Skate park and bike park in Mullaly Park are in poor condition and need partial or complete renovation. We respectfully request funding for renovation for both.
19/29
DPR
Reconstruct or upgrade a building in a park
Claremont Park-Reconstruct/renovate both comfort stations
20/29
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Macombs Dam Park-Reconstruction of synthetic turf field
21/29
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Complete reconstruction/renovation of Merriam Playground.
24/29
DPR
Reconstruct or upgrade a building in a park
There is a storage house/facility in Franz Sigel that is underutilized. CB4 recommends that this facility be rehabilitated and converted to concessions and used as a facility for outdoor concerts and performances.
25/29
DPR
Other requests for
park, building, or access improvements
Additional BBQ zones within the District are
requested along with better signage clearly stating the Parks Departments barbeque policy. Mill Pond is the only park within the entire District that is designed with barbeque grills on the park grounds. Mill Ponds limited grills, which are greatly enjoyed, fall short of the demand for such amenities throughout the District. This unmet demand is compounded by the fact that Mill Pond is remotely situated under the Major Deegan Expressway which, assuredly serves as a deterrent to travel to the location. Consequently, every weekend from late Spring through the end of Summer, the Districts marquis parks (Claremont, Franz Sigel, Mullaly and Joyce Kilmer) are overrun with unmanageable barbeque gatherings.
26/29
DPR
New equipment for maintenance (Capital)
Vehicles to replace aging fleet. The Parks Department relies on vehicles that are constantly out of service and over five years old. Parks also needs to service larger parks with smaller, safer, and more efficient small utility vehicles.
27/29
DPR
Improve access to a park or amenity (i.e. playground, outdoor athletic field)
Claremont Park-Reconstruction of the playgrounds
28/29
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Goble Playground-Reconstruction of the playground
29/29
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
West Bronx Recreation Center Provide new light posts (light fixtures) and summer water play sprinklers.
1527 Jessup
CS NYPL Create a new, or renovate or upgrade an existing public library
Capital The Library is seeking much-needed capital funding to ensure that our branches can continue to meet the growing needs of our communities. Anticipated projects range from major renovations to targeted upgrades, including: - Heating and cooling system updates
New roof, windows and doors - Fire alarm, security and technology upgrades - ADA compliance - Elevator replacement Current priority capital needs in Bronx CB 4 - include: - Melrose Library $ 1,220, 000 -This branch will undergo a major renovation, replacing and improving outdated structures which will enhance the patron experience. The renovation will beautify the branches exterior and interior appearance and ensure the comfort of staff and patrons inside.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/26
DPR
Provide better park
The Board request a budget line item for a CB4
maintenance
Parks Administrator. Under the supervision of
the Bronx Borough Commissioner this individual
would manage CB4 parks system wide and
would be responsible for the following:
maintenance, special events, recreational
facilities, personnel, developing and helping to
establish Friends of groups to assist with
maintenance, cleanup, beautification in high
trafficked areas, manage grant application and
funding streams for special projects ,
community relations/outreach and
programming.
7/26
DPR
Provide better park
CB4 respectfully requests additional PEP officers
maintenance
be assigned to Borough to assist in maintenance
and upkeep particularly during the summer
months.
21/26
DPR
Provide better park
Increase City Park Workers for enhanced park
maintenance
maintenance. In order to increase the level of
service and parks and to keep up with new
additions to the parks system, 68 City Park
Workers are requested to service the parks
throughout the borough. These CPWs will be fix
posts and be placed on mobile crews as well as
cut grass.
22/26 DPR Provide better park
maintenance
Increase the number of Horticultural Employees. Over the years, the horticultural elements throughout the borough have increased in size and scale. These gardens and landscape have made the borough more beautiful, but they require an immense amount of maintenance. In order to maintain these gardens, 30 additional employees are needed.
image
24/26 DPR Provide better park
maintenance
Additional Playground Associates. Playground Associates are one of the best kept secrets during the summer months. Children can go to their neighborhood playground and have structured activities five days per week during the summer months when they are not in school. As we sorely lack, recreational and community centers, Thirty-Six (36) additional Playground Associates are requested for the entire borough.
image
26/26 DPR Provide better park
maintenance
Recreation Specialists for Recreation Centers Our Recreation Centers are centers of culture, programming, fitness, and inclusion. They host great programming, summer camps, workout classes, and they are a place for children and adults to feel safe. Twelve (12) Recreation Specialists are requested to increase programming in the centers.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/29
DOT
Other
153rd Street Bridge We continue to voice our
153rd Street
transportation
concerns about traffic conditions in our District
and Park Ave
infrastructure
and so we continue to advocate for the
requests
development of the East 153rd Street Bridge.
We stand firm in our support for development of
this bridge, which would alleviate traffic
congestion along 149th and 161st Streets and
local streets in the neighborhood. The proposed
bridge would be a single tower cable stayed
bridge, located over the Old Mott Haven Rail
yard, connecting Concourse Village West at the
west end and Park Avenue at the east end.
2/29
NYCTA
Improve
Provide an elevator/or escalator along the 4 at
accessibility of
Burnside or 170th Street and one on the B/D
transit
line between East 167th Street and East 183rd
infrastructure, by
Street.
providing elevators,
escalators, etc.
3/29
SCA
Provide a new or
The Jerome Avenue Neighborhood Plan calls for
expand an existing
construction of a new 458-seat primary school
middle/intermediate
with a state-of-the art gym. CSD 7 is currently
school
operating near capacity . As part of the Lower
Concourse North project the city has agreed to
construct a new 572 seat middle school. SCA
has released its 2020-2024, likely resulting in
additional deficits and capacity issues. We
respectfully request siting and funding to
address seat deficits in the next SCA capital
plan.
expanded park or
acres of gated, unimproved NYC Parks green
amenity (i.e.
space that has never been accessible by the
playground, outdoor
community since its acquisition some twenty
athletic field)
years ago. The Community and the Community
Board urge the city to fund the design and
development of this park and target pre-teens
(teenagers can use the ample Nelson Avenue
Park facilities two blocks away.) This park will
serve a community that continues to grow and
provide recreational space that our children
rightfully deserve. Through the Jerome Avenue
Neighborhood Development Fund (NDF) $4.62
million was allocated.
5/29
DPR
Improve access to a
Grant Park was to be completed in stages to
building in a park
permit continued use by children of some areas
of the park. However, the development of a
series of large sink holes in the children's play
area in the park's southwestern quadrant has
effectively shut down the entire park
indefinitely. This adversely impacts the entire
community the park has historically served.
Currently nearly $30 million ($25.7 through
NDF) has been allocated for reconstruction of
the park, roadbed, playground and basketball
court.
6/29
DCAS
Renovate, upgrade
Community Boards play an integral role in
575 Exterior
or provide new
dealing with land use and zoning matters, the
Street
community board
City budget, municipal service delivery and
facilities and
many other matters critical to the quality of life
equipment
of thousands of area residents. Our current
location does not allow for such engagement, as
mandated by the NYC Charter. We are currently
located on the 11th floor of a residential
building in (2) apartments adapted for office
use. We respectfully request relocation of the
Board office to a location more suitable for the
agency's mission. We have had preliminary
discussions with the Bronx Point development
team as well the developer of Concourse Village
West. Furthermore we request that the future
redevelopment of any city-owned property be
given consideration for new relocation
resurfaced and is in need of major
improvements. Removal and resurfacing asphalt
and brick. The Board has complained about this
for many years. The redbrick and asphalt along
the corridor is cracked and is in serious need of
repair. In addition, the texture of the brick does
not allow for safe travel during inclement
weather because it becomes very slippery and
slick. The corridor sees increased vehicular and
foot traffic with more tourism, filming and
events. The resurfacing should focus on 161 and
intersecting street segments from Macombs
Dam Road to Park Avenue.
8/29
DOT
Repair or build new
There are a total of 17 step streets in the
step streets
District. (7) are Top 20 priority Step Streets but
as more than 70 percent of area residents use
public transit or walk, connections and access
are of the utmost importance. We request a
schedule and timeline for rehabilitation of all
step streets in the district and a discussion on
priorities based on travel patterns and
connections to transit, major institutions and
employers. Priority should be given to the
following: 1) Clay & 169th Street 2) Jerome near
Anderson Behind PS 73 (include lighting) 3)
168th Street (Shakespeare to ELG) 4)
Shakespeare and Anderson (167th Street) We
also request that CDOT and DSNY collaborate
on a comprehensive maintenance and clean up
program for these step streets with regularly
scheduled clean ups.
9/29
NYCTA
Repair or upgrade
Station Enhancements/Rehabilitation: 170th
subway stations or
Street Mt. Eden Avenue
other transit
infrastructure
10/29
DOT
Repair or provide
Install higher intensity lighting along Jerome
Jerome
new street lights
Avenue. This special lighting is needed due to
Avenue 161
the elevated rail lines that cause the area to be
Street 174th
dark and unsafe due to the poor lighting.
street
workforce
the closest Workforce One Center is located in
development
Hunts Point or on Fordham Road. In order to
requests
serve the thousands of job seekers, existing and
future business owners the city should develop a
new Workforce One Center as a part of the
Jerome Neighborhood Plan. -The center would
bridge the gap between the existing centers and
could focus specifically on local needs: large
immigrant population (Latino and West African)
and the auto-industry.
12/29
DOT
Install streetscape
We request streetscape improvements be made
improvements
around commercial corridors including painting,
lighting, seating and improved circulation and
mobility. (167th Street, 170th Street and Mount
Eden)
13/29
DPR
Other requests for
Active development of a contiguous path joining
park, building, or
the bike/run waterfront paths along Mill Pond
access
Park (in Bronx CB4) to Roberto Clemente State
improvements
Park (Bronx CB5) which also has a segment of a
new bike/running path along the waterfront
that ends at a chain linked fence separating the
park land from property belonging to the Metro
North/MTA train car cleaning facilities at the
parks southern border. Using the precedent of
the Riverbank Park in Manhattan, a similar
greenway can be developed along the perimeter
of the MTA's Bronx facility.
14/29
NYPD
Add NYPD parking
Parking is an enormous issue district-wide. The
East 169th
facilities
44th precinct currently has vehicles parked on
Street Jerome
the streets, sidewalks etc. There are a number
Avenue East
of lots and garages nearby. We request that the
168th Street
city purchase one of those for the sole purpose
to store NYPD vehicles and NYPD officers
personal vehicles to alleviate congestion,
provide more on-street spaces for residents and
create a safer, pedestrian friendly environment.
15/29
DHS,
Other homelessness
We recommend that DHS strengthen its
HRA
prevention program
partnership with HPD to increase the number of
request
new affordable housing units made available to
individuals and families. Currently the set aside
for homeless families is 10%. This is particularly
important as Community District Four has the
largest number of cluster sights citywide, a high
proportion of homeless facilities and a DHS
intake center within its borders.
transportation
Transportation conduct full rehabilitation and
infrastructure
upgrade to underpasses at 170th, 167th Street,
requests
174th Street, specifically replace the metal
protective mesh, the chipped, and spalled
concrete. Enhanced lighting would also be
appropriate at these sites.
17/29
HPD
Provide more
To increase the Districts economic index, we
housing for medium
support the development of affordable housing
income households
for moderate and middle-income individuals
and families as an added element to our new
housing stock. The lack of affordable housing at
these income levels contributes to the flight of
moderate and middle-income families from our
district. It is in the interest of our Community
District to promote economic diversity within
our community. We strongly advocate for City
and State funds for the middle-income new
construction program and the creation of
independent living facilities for seniors. We
strongly encourage the use of public funds at
the city and state level for permanent affordable
housing and home ownership, not supportive
housing (DHS related).
18/29
DPR
Reconstruct or
Both the Skate park and bike park in Mullaly
upgrade a building
Park are in poor condition and need partial or
in a park
complete renovation. We respectfully request
funding for renovation for both.
19/29
DPR
Reconstruct or
Claremont Park-Reconstruct/renovate both
upgrade a building
comfort stations
in a park
20/29
DPR
Reconstruct or
Macombs Dam Park-Reconstruction of synthetic
upgrade a park or
turf field
amenity (i.e.
playground, outdoor
athletic field)
21/29
DPR
Reconstruct or
Complete reconstruction/renovation of Merriam
upgrade a park or
Playground.
amenity (i.e.
playground, outdoor
athletic field)
transportation
(exit ramp to Major Deegan Expressway North).
Street 150
infrastructure
We request that DOT mimic all new capital
153
requests
infrastructure investments being made as part
of the Bronx Point, particularly as the Bronx
Children's Museum is scheduled to open in
2019.
23/29
DOT
Repair or construct
Exterior Street from 150 Street to 153rd Street
Exterior
new curbs or
(exit ramp to Major Deegan Expressway North).
Street 150
area in the park's southwestern quadrant has
effectively shut down the entire park
indefinitely. This adversely impacts the entire
community the park has historically served.
Currently nearly $30 million ($25.7 through
NDF) has been allocated for reconstruction of
the park, roadbed, playground and basketball
court.
6/29
DCAS
Renovate, upgrade
Community Boards play an integral role in
575 Exterior
or provide new
dealing with land use and zoning matters, the
Street
community board
City budget, municipal service delivery and
facilities and
many other matters critical to the quality of life
equipment
of thousands of area residents. Our current
location does not allow for such engagement, as
mandated by the NYC Charter. We are currently
located on the 11th floor of a residential
building in (2) apartments adapted for office
use. We respectfully request relocation of the
Board office to a location more suitable for the
agency's mission. We have had preliminary
discussions with the Bronx Point development
team as well the developer of Concourse Village
West. Furthermore we request that the future
redevelopment of any city-owned property be
given consideration for new relocation
resurfaced and is in need of major
improvements. Removal and resurfacing asphalt
and brick. The Board has complained about this
for many years. The redbrick and asphalt along
the corridor is cracked and is in serious need of
repair. In addition, the texture of the brick does
not allow for safe travel during inclement
weather because it becomes very slippery and
slick. The corridor sees increased vehicular and
foot traffic with more tourism, filming and
events. The resurfacing should focus on 161 and
intersecting street segments from Macombs
Dam Road to Park Avenue.
8/29
DOT
Repair or build new
There are a total of 17 step streets in the
step streets
District. (7) are Top 20 priority Step Streets but
as more than 70 percent of area residents use
public transit or walk, connections and access
are of the utmost importance. We request a
schedule and timeline for rehabilitation of all
step streets in the district and a discussion on
priorities based on travel patterns and
connections to transit, major institutions and
employers. Priority should be given to the
following: 1) Clay & 169th Street 2) Jerome near
Anderson Behind PS 73 (include lighting) 3)
168th Street (Shakespeare to ELG) 4)
Shakespeare and Anderson (167th Street) We
also request that CDOT and DSNY collaborate
on a comprehensive maintenance and clean up
program for these step streets with regularly
scheduled clean ups.
9/29
NYCTA
Repair or upgrade
Station Enhancements/Rehabilitation: 170th
subway stations or
Street Mt. Eden Avenue
other transit
infrastructure
10/29
DOT
Repair or provide
Install higher intensity lighting along Jerome
Jerome
new street lights
Avenue. This special lighting is needed due to
Avenue 161
the elevated rail lines that cause the area to be
Street 174th
dark and unsafe due to the poor lighting.
street
workforce
the closest Workforce One Center is located in
development
Hunts Point or on Fordham Road. In order to
requests
serve the thousands of job seekers, existing and
future business owners the city should develop a
new Workforce One Center as a part of the
Jerome Neighborhood Plan. -The center would
bridge the gap between the existing centers and
could focus specifically on local needs: large
immigrant population (Latino and West African)
and the auto-industry.
12/29
DOT
Install streetscape
We request streetscape improvements be made
improvements
around commercial corridors including painting,
lighting, seating and improved circulation and
mobility. (167th Street, 170th Street and Mount
Eden)
13/29
DPR
Other requests for
Active development of a contiguous path joining
park, building, or
the bike/run waterfront paths along Mill Pond
access
Park (in Bronx CB4) to Roberto Clemente State
improvements
Park (Bronx CB5) which also has a segment of a
new bike/running path along the waterfront
that ends at a chain linked fence separating the
park land from property belonging to the Metro
North/MTA train car cleaning facilities at the
parks southern border. Using the precedent of
the Riverbank Park in Manhattan, a similar
greenway can be developed along the perimeter
of the MTA's Bronx facility.
14/29
NYPD
Add NYPD parking
Parking is an enormous issue district-wide. The
East 169th
facilities
44th precinct currently has vehicles parked on
Street Jerome
the streets, sidewalks etc. There are a number
Avenue East
of lots and garages nearby. We request that the
168th Street
city purchase one of those for the sole purpose
to store NYPD vehicles and NYPD officers
personal vehicles to alleviate congestion,
provide more on-street spaces for residents and
create a safer, pedestrian friendly environment.
15/29
DHS,
Other homelessness
We recommend that DHS strengthen its
HRA
prevention program
partnership with HPD to increase the number of
request
new affordable housing units made available to
individuals and families. Currently the set aside
for homeless families is 10%. This is particularly
important as Community District Four has the
largest number of cluster sights citywide, a high
proportion of homeless facilities and a DHS
intake center within its borders.
transportation
Transportation conduct full rehabilitation and
infrastructure
upgrade to underpasses at 170th, 167th Street,
requests
174th Street, specifically replace the metal
protective mesh, the chipped, and spalled
concrete. Enhanced lighting would also be
appropriate at these sites.
17/29
HPD
Provide more
To increase the Districts economic index, we
housing for medium
support the development of affordable housing
income households
for moderate and middle-income individuals
and families as an added element to our new
housing stock. The lack of affordable housing at
these income levels contributes to the flight of
moderate and middle-income families from our
district. It is in the interest of our Community
District to promote economic diversity within
our community. We strongly advocate for City
and State funds for the middle-income new
construction program and the creation of
independent living facilities for seniors. We
strongly encourage the use of public funds at
the city and state level for permanent affordable
housing and home ownership, not supportive
housing (DHS related).
18/29
DPR
Reconstruct or
Both the Skate park and bike park in Mullaly
upgrade a building
Park are in poor condition and need partial or
in a park
complete renovation. We respectfully request
funding for renovation for both.
19/29
DPR
Reconstruct or
Claremont Park-Reconstruct/renovate both
upgrade a building
comfort stations
in a park
20/29
DPR
Reconstruct or
Macombs Dam Park-Reconstruction of synthetic
upgrade a park or
turf field
amenity (i.e.
playground, outdoor
athletic field)
21/29
DPR
Reconstruct or
Complete reconstruction/renovation of Merriam
upgrade a park or
Playground.
amenity (i.e.
playground, outdoor
athletic field)
transportation
(exit ramp to Major Deegan Expressway North).
Street 150
infrastructure
We request that DOT mimic all new capital
153
requests
infrastructure investments being made as part
of the Bronx Point, particularly as the Bronx
Children's Museum is scheduled to open in
2019.
23/29
DOT
Repair or construct
Exterior Street from 150 Street to 153rd Street
Exterior
new curbs or
(exit ramp to Major Deegan Expressway North).
Street 150
pedestrian ramps
We request identical treatments for curb cuts
153
and pedestrian ramps as Bronx Point,
particularly as the Bronx Children's Museum is
scheduled to open in 2020.
24/29
DPR
Reconstruct or
There is a storage house/facility in Franz Sigel
upgrade a building
that is underutilized. CB4 recommends that this
in a park
facility be rehabilitated and converted to
concessions and used as a facility for outdoor
concerts and performances.
25/29
DPR
Other requests for
Additional BBQ zones within the District are
park, building, or
requested along with better signage clearly
access
stating the Parks Departments barbeque policy.
improvements
Mill Pond is the only park within the entire
District that is designed with barbeque grills on
the park grounds. Mill Ponds limited grills,
which are greatly enjoyed, fall short of the
demand for such amenities throughout the
District. This unmet demand is compounded by
the fact that Mill Pond is remotely situated
under the Major Deegan Expressway which,
assuredly serves as a deterrent to travel to the
location. Consequently, every weekend from late
Spring through the end of Summer, the Districts
marquis parks (Claremont, Franz Sigel, Mullaly
and Joyce Kilmer) are overrun with
unmanageable barbeque gatherings.
26/29
DPR
New equipment for
Vehicles to replace aging fleet. The Parks
maintenance
Department relies on vehicles that are
(Capital)
constantly out of service and over five years old.
Parks also needs to service larger parks with
smaller, safer, and more efficient small utility
vehicles.
27/29
DPR
Improve access to a
Claremont Park-Reconstruction of the
park or amenity (i.e.
playgrounds
playground, outdoor
athletic field)
28/29 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
Goble Playground-Reconstruction of the playground
image
29/29 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
West Bronx Recreation Center Provide new light posts (light fixtures) and summer water play sprinklers.
1527 Jessup
image
CS NYPL Create a new, or renovate or upgrade an existing public library
Capital The Library is seeking much-needed capital funding to ensure that our branches can continue to meet the growing needs of our communities. Anticipated projects range from major renovations to targeted upgrades, including: - Heating and cooling system updates
New roof, windows and doors - Fire alarm, security and technology upgrades - ADA compliance - Elevator replacement Current priority capital needs in Bronx CB 4 - include: - Melrose Library $ 1,220, 000 -This branch will undergo a major renovation, replacing and improving outdated structures which will enhance the patron experience. The renovation will beautify the branches exterior and interior appearance and ensure the comfort of staff and patrons inside.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/26
DPR
Provide better park
The Board request a budget line item for a CB4
maintenance
Parks Administrator. Under the supervision of
the Bronx Borough Commissioner this individual
would manage CB4 parks system wide and
would be responsible for the following:
maintenance, special events, recreational
facilities, personnel, developing and helping to
establish Friends of groups to assist with
maintenance, cleanup, beautification in high
trafficked areas, manage grant application and
funding streams for special projects ,
community relations/outreach and
programming.
2/26
NYCTA
Expand bus service
Increased bus service in areas such as
frequency or hours
Highbridge to improve access for area residents
of operation
and merchants -Bx3, BX11, Bx36 or Bx18, BX6,
Bx35, BX36,extent line along BX32 to 167th
street, BX40/41, BX42
3/26
DSNY
Increase
This should be concentrated along commercial
enforcement of
corridors (East 167th Street, Ogden Avenue,
dirty sidewalk/dirty
East 170th Street and 161st Street area.)
area/failure to clean
area laws
4/26
DYCD
Provide, expand, or
Community District Four's many working
enhance after
families and single-parent households require
school programs for
no-cost after-school care. Free after-school care
middle school
allows parents to work and maintain
students (grades 6-
employment, keeps children safe, and enhances
8)
children's educational attainment. It also allows
families to use scarce financial resources on
other pressing needs. Accordingly, we request
that DYCD increase funding at existing
organizations district-wide to provide after
school programs. They should also partner with
local schools to provide additional funding to
site after schools programs.
5/26
SBS
Other expense
Continued support for the creation of the
workforce
Jerome Avenue Workforce partnership to enable
development
them to develop a employer/employee network
requests
similar to the Lower East Employment Network
for the purpose of engaging developers,
potential employers in the neighborhood,
providing sector-specific training for local
residents, screening candidates for available
positions in emerging markets as well as make
referrals where necessary. Localized Street
Vendor Program o Create a pilot program with
DOHMH, SBS, MOIA and DCA o Legitimize
existing food carts operating without a license
(smaller fee) Ensures/promotes health and well-
being by creating standards for business
operation Incentivize program for small mom
and pop businesses to grow as the
neighborhood grows.
6/26
NYCHA
Expand programs
HPD should increase its funding for code
for housing
enforcement inspectors and provide incentives
inspections to
to property owners to repair and retrofit their
correct code
buildings in accordance with the building codes
violations
like 8A loan and Participation loan programs.
The city should reinstate the Neighborhood
Preservation Office to deal with code
enforcement, anti-harassment and
displacement. This would provide a team of
individuals geographically-based to deal
immediately and directly with these issues.
7/26
DPR
Provide better park
CB4 respectfully requests additional PEP officers
maintenance
be assigned to Borough to assist in maintenance
and upkeep particularly during the summer
months.
8/26
NYPD
Assign additional
The 44th precinct is one of the most active in
uniformed officers
the city. We recently received new recruits from
the academy but as the District grows we need
growth in our key service sectors to keep pace.
We request the City allocate funding for more
permanent new officers in the next fiscal year.
The Community Affairs Division is fantastic and
with more officers in the division there is a great
opportunity to increase their presence and
awareness district wide and increase positive
relations between police and the community.
We request an increase in officers as well in the
next fiscal year.
9/26 NYPD Assign additional
community affairs officers
The Community Affairs Division is fantastic and with more officers in the division there is a great opportunity to increase their presence and awareness district wide and increase positive relations between police and the community.
We request an increase in officers as well in the next fiscal year. This will be particularly helpful in staffing the NCO program and assigning additional resources to parts of the district that need it most. (i.e. Highbridge)
image
10/26 DCP Study land use and
zoning to better match current use or future neighborhood needs
Community Board Four request that DCP engage in a master planning exercise to determine the highest and best use for the city- owned parcels concentrated along Jerome Avenue and around Bronx Terminal Market. This approach ensures that the redevelopment of these parcels reflects community needs and integrates with the existing fabric of the neighborhood. Uses that should to be considered: Development of affordable housing at a variety of income levels including home- ownership (NO SUPPORTIVE HOUSING) New Schools for CSD 7 and CSD 9, new community facility space, inclusion of small businesses and non-profit entities as part of mixed-use developments to encourage entrepreneurship, new open space and state of the art recreation/community centers similar to West Bronx Recreation Center.
image
11/26 DFTA Increase transportation services capacity
Access and mobility are major concerns for seniors in the District. We request that DOHMH collaborate with existing senior centers and care providers in the district to create additional programs that will allow seniors to get out for shopping, exercise and entertainment. Mid- Bronx Senior Citizen Council, Highbridge Community Development Corporation and BronxWorks are organizations that work with seniors and operate senior facilities in the District.
image
12/26
DOHMH
Create or promote
Actions to assist in the reduction in obesity and
programs for
diabetes among residents in the district 1.
education and
Promote healthy eating options. a. Throughout
awareness on
the district, there are limited options for
nutrition, physical
purchasing healthier foods at grocery stores and
activity, etc.
restaurants, particularly in our commercial
corridors. We support programs such as the
DOHMHs Shop Healthy Initiative help to
educate store owners on how to provide positive
messaging, setup healthier alternatives, and
work with distributors to bring healthier foods
to the stores. b. We also ask the NYCEDC to
support the DOHMHs mission of expanding
access to healthier foods by considering
significant modifications to the Food Retail
Expansion to Support Health (FRESH) program.
These modifications should include smaller and
varied tax break options.
13/26
SBS
Assist with on-site
As part of the Jerome Avenue Neighborhood
Jerome
business compliance
Study -Enable businesses to be better neighbors
Avenue
with City regulations
by offering comprehensive services related to
Mcclellan
compliance and auto-industry standards. Work
Street Cross
directly with business owners to remedy
Bronx
violation and licensing to increase their
Expressway
compliance.
14/26
EDC
Expand access to
We should support the continued growth and
low cost financing to
expansion of small businesses throughout the
help neighborhood
District. EDC and SBS should partner to help
businesses construct
small businesses develop business plans and
or improve space
financing packages to support them. They
should think outside the box to create new
programs and incentives that address the needs
of area residents. They should partner with local
financial institutions like Spring Bank.
15/26
DOHMH
Create or promote
We have a number of facilities throughout the
programs to de-
district for formerly homeless individual and
stigmatize mental
families. Many of these are individuals with a
health problems
history of mental illness. While we do not
and encourage
advocate for any additional facilities of this type
treatment
in our district we want to ensure that the
individuals that are here receive proper care.
This benefits the individuals and their families
as well as area residents. DOHMH should work
with DHS to identify these facilities and target
those that would benefit from additional
programming and/or services.
16/26 HRA Assist low income
households in paying for energy costs
Fifty-six percent of all District households are rent-burdened, meaning their gross rent was more than 35 percent of their household income. We request that HRA work with Con Edison, DEP and HPD to create literature and conduct outreach educating tenants on how to save energy and lower energy costs.
Additionally, HPD should continue to target older buildings in need of upgrades and offer low-interest loans to upgrade energy systems throughout - with the strict and clear understanding that the cost of these upgrades are to be shouldered by building owners, and NOT tenants.
image
17/26 DHS, HRA
Provide, expand, or enhance rental assistance programs
Homelessness has reached historic levels in NYC. According to the Coalition for the Homeless, as of August 2019, there are 61,674 homeless people, including 21,934 homeless families with 21,802 homeless children, sleeping each night in the New York City municipal shelter system.
Families make up nearly three-quarters of the homeless shelter population. The city is investing hundreds of millions of dollars in new affordable housing. We respectfully request that the City ramp up it's efforts to permanently house families and individuals living in the shelter system.
image
18/26 HRA Provide, expand, or
enhance job training
Unemployment plays a key role in the socio- economic status of local residents. While unemployment both nationally and in the Bronx has hit record lows (3.7 percent and 5.6 percent) respectively, unemployment in Community District Four is slightly higher at 7.4 percent.
While the percentage of unemployed residents has consistently decreased, we must continue to create jobs and economic opportunities.
Moreover, tens of thousands residents are underemployed, and therefore, still impoverished. Community District Four advocates for HRA to work with SBS, EDC and community-based organizations to create better employment opportunities for District residents.
image
19/26
DYCD
Provide, expand, or
As stated previously we have one of the highest
enhance the
teen birth rates and some of the lowest
Summer Youth
numbers in terms of English and Math
Employment
proficiency. Providing positive reinforcement to
Program
our youth is important and Summer Youth
Employment is desperately needed particularly
in a District with a meager Area Median Income
($32,120) and nearly thirty-five percent of the
population living at the poverty level. DYCD
should continue to increase funding for Summer
Youth Employment. DYCD should also work with
local organizations and the Bronx Borough
President's office to create additional work
places to host youth for the summer and
throughout the school year as well.
20/26
DOHMH
Create or promote
As nearly forty percent of our population is
programs for
under the age of 25 it is important to
education and
underscore the importance of nutrition, healthy
awareness on
eating and physical activity. We request that
nutrition, physical
DOHMH increase outreach and education
activity, etc.
related to food and nutrition. There should be a
focus on targeting middle schools and working
with community-based organizations with
youth programs and active tenant associations
and groups. Bronx Lebanon Hospital and Hostos
Community College should be leveraged as
resources.
21/26
DPR
Provide better park
Increase City Park Workers for enhanced park
maintenance
maintenance. In order to increase the level of
service and parks and to keep up with new
additions to the parks system, 68 City Park
Workers are requested to service the parks
throughout the borough. These CPWs will be fix
posts and be placed on mobile crews as well as
cut grass.
22/26
DPR
Provide better park
Increase the number of Horticultural Employees.
maintenance
Over the years, the horticultural elements
throughout the borough have increased in size
and scale. These gardens and landscape have
made the borough more beautiful, but they
require an immense amount of maintenance. In
order to maintain these gardens, 30 additional
employees are needed.
23/26
NYCTA
Provide a new bus
Explore the possibility of a Select BX19 and
service or Select Bus
Select BX1 to accommodate the continued
Service
growth along the Grand Concourse and along
the 149th Street corridor.
24/26 DPR Provide better park
maintenance
Additional Playground Associates. Playground Associates are one of the best kept secrets during the summer months. Children can go to their neighborhood playground and have structured activities five days per week during the summer months when they are not in school. As we sorely lack, recreational and community centers, Thirty-Six (36) additional Playground Associates are requested for the entire borough.
image
25/26 DSNY Provide more
frequent garbage or recycling pick-up
In highly trafficked commercial areas: 161, 167th, 170, Mt Eden and around our highly used park facilities there should be concerted efforts to clean those areas during peak times and after events.
image
26/26 DPR Provide better park
maintenance
Recreation Specialists for Recreation Centers Our Recreation Centers are centers of culture, programming, fitness, and inclusion. They host great programming, summer camps, workout classes, and they are a place for children and adults to feel safe. Twelve (12) Recreation Specialists are requested to increase programming in the centers.

