- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Staten Island Community District 1 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1UJXlhcseg_RLc5eT6qM5XcJicxf_hGUm/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1UJXlhcseg_RLc5eT6qM5XcJicxf_hGUm/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Staten Island Community District
1
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Staten Island Community Board 1
image
Address: 1 Edgewater Plaza, 217
Phone: (718) 981-6900
Email: sicb1@si.rr.com
Website: www.nyc.gov/sicb1
Chair: Nicholas Siclari District Manager: Joseph Carroll
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 1 represents Staten Island's North Shore neighborhoods and the Board focuses its attention on economic and waterfront development; sensible zoning to increase housing along transit corridors; transportation infrastructure improvement, including the expansion of mass transit; youth and senior services; public safety; a substantial increase in public health services; quality of life improvements; and, attention to the recovery of the North Shore's business community following "Sandy" with a focus on the hardening of the infrastructure, wave attenuation, surface water management;, and reimbursement for losses the storm engendered. There is an increased vitality to the district engendered by the aggregation of one billion dollars in private investment coupled with the Mayor's Bay Street Corridor Affordable Housing Plan. However, unless the City commits to extensive infrastructure improvements the tax revenues from Lighthouse Point, the Navy Pier and Empire Outlets current tenancy will be at risk and the Bay Street Corridor Affordable Housing Plan will fail, especiall since building height will not give developers the returns needed to constuct such affordable units. The streets require massive reinvestment to prevent quick deterioration and to provide sensible access to the venues and to downtown St.
George, including the new court complex. A new traffic timing algorithm needs to be written to make sense of the poorly configured current traffic light controls. The Wagner property at Howard Avenue and Clove Road must be purchased to create a turning lane, thus leaving two travel lanes and a left turn lane. Mass transit will be a must and has to consist of SIRTOA improvents, SBS and BRT service and a dedicated busway along Richmond Terrace. Zoning along the corridor from Snug Harbor to Stapleton needs to be amended from M to C4-2 which would allow the development of afordable housing in a larger part of the Board's district. The funds provided by DFTA and DYCD require a substantial increases to the S.I. allocation to meet the needs S.I.'s expanding senior population and the needs of our now very diverse population of youngsters with special attention focused on drug addiction prevention and on increased recreational programming for the young ones, and, especially, early identification of and treatment for children with disabilities. Since there is no HHC full service hospital in the borough, NYC needs to alocate a proportionally fair amount of tax levied funds to the two S.I. hospital systems. The Board has tasked our Health Committee with the job of working with the Borough President and our health care service providers to "create a culture of wellness." The Board is grateful to the HHC for building an "Urgi-care" facility in the underserved Clifton/Park Hill community; however, while this is a step in the right direction, it is not curative of the underlying lack of NYC support to the borough's hospital systems. The dramatic economic growth linked with the Bay Street Affordable Housing plan will make public safety more complex and will require an increase in NYPD staffing and construction of the new 120th precinct in Stapleton. This growth, and the growth in St. George will require a proximate siting of a fully staffed and equipped house for FDNY. The quality of life for SICB1's district will be enhanced by providing DPR with an equitable base line capital budget to improve and upgrade all the parks in SICB1, increase PEP staffing, provide restrooms in all DPR public facilities and develop the North Shore Greenway Trail. While the Board applauds and thanks our elected officials for providing funding to DPR, it is unfair these official have to use resources for an agency when other agencies have their own capital funding. Most importantly, Parks needs at least $130 million to rebuild Cromwell Center over Lyon's Pool. The North Shore Bluebelt or its hard infrastructure alternative and the Victory Boulevard sewer need $20-$30 million to stop the endless flooding within the communities from Westerleigh to West New Brighton. Finally, the Board looks forward to the relocation of the DOS District 1 garage from the environmental justice community along Jersey and Brook Streets to the appropriate location within the old landfill. Thereafter, the Board will encourage adaptive reuse of the DS1 site.
4. TOP THREE PRESSING ISSUES OVERALL
Staten Island Community Board 1
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
North Shore zoning neither reflects current land use nor wisely prepares for future land use. M zones abut R zones, parking requirements do not reflect the Borough's reality of auto use, C zones are poorly sited, affordable housing corridors do not exist, there are no transit corridors, there is no thought of preservation and,our open spaces are being obliterated.
Traffic
The biggest impediment to the quality of life on Staten Island is traffic The DOT cannot keep pace with the increasing use of vehicles and contrary to Manhattan-centric thinking vehicles are the only way to get around out here. There is no grid system, the roads are in disrepair, commutes are endless, shopping is an ordeal, school buses are slow and there is only one small rail system.
Transit (buses & subways)
Commuting on SI is hell. Every bus has to trundle for miles on broken roads to deliver folks to work and children to school. Bus schedules do not meet commuters" needs, express service is inadequate, the BRT plan proposes to eliminate access to the ferry terminal and the SIRR only serves a small part of the Borough.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Staten Island Community Board 1
image
M ost Important Issue Related to Health Care and Human Services
Other
Equitable Hospital Services and support. SI has no Municipal Hospital and there is no allowance made to help fiance the operations of the two hospital systems on the Island. This lack of funding either for a municipal hospital or to help the two systems is a disregard by leadership for the health and well being of the Staten Island community, especially in CB1 where there are more residents in medical distress than in other parts of the Island.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Again, as stated often in this section, the health care system on Staten Island does not receive equitable funding thus placing all residents at risk.
Needs for Older NYs
The two biggest needs in the district are affordable housing and abuse prevention programming.
Needs for Homeless
Although the homeless population has increased and diversified, the resources given to our one agency are inadequate to provide housing, shelter, prevention, referrals and counseling.
Needs for Low Income NYs
Job training and employment programming and domestic abuse prevention are the most significant programs the district needs.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
8/40 HHC Other health care
facilities requests
Provide 5% of the HHC tax levy capital budget to the two SI Hospital systems to provide equity to the City's medical care delivery system and to ensure the access to health care for Staten Islanders.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/25
DFTA
Enhance programs
Elder abuse is increasing dramatically and this
for elder abuse
trend must be halted.
victims
2/25
DOHMH
Create or promote
create programs to provide community
programs to de-
education regarding the mental and physical
stigmatize mental
health issues of transgendered youth.
health problems
and encourage
treatment
3/25
DHS
Expand
Staten Island has one service provider and
homelessness
funding is insufficient to provide for the actual
prevention
homelessness that needs to be resolved and the
programs
programming required to prevent
homelessness.
4/25
HRA
Provide, expand, or
With the high joblessness rate in North Shore
enhance job training
communities, there is a great need to provide
folks with skill set training in fields where jobs
are available. There is also a need to partner
with labor unions to help the unemployed get
the skills' training required to get a union card.
6/25
HRA
Provide social
There is an immediate need to provide
services for
additional funds to the District Attorney's
domestic violence
domestic violence program. This crime is
survivors (legal
increasing and an all out effort is needed to
services, counseling,
round up the abusers and take care of those
referral to
abused.
supportive services,
etc.)
19/25 DOHMH Other programs to
address public health issues requests
To provide folks are trained in safe food handling thus decreasing public danger.
image
YOUTH, EDUCATION AND CHILD WELFARE
Staten Island Community Board 1
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
There are not enough pre-k through 14 seats available now and this will be exasperated when the developments in St. George, Stapleton and the Bay Street Affordable Housing Corridor are completed. This shortage creates chaos in the school system and impacts all the seriated items. Moreover, the massive parochial school closings have added even more stress to the public system and notwithstanding the successful efforts of Councilwoman Rose to secure new schools, the pace of development still is exceeding this new capacity.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
The increased economic and housing actifvity in our district and the closing of most parochial schools is causing and untoward burden on a public system that already has most schools at over-capacity.
Needs for Youth and Child Welfare
The district needs additonal day care to allow parents the opportunity to work.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
6/40
SCA
Provide a new or
Middle schools have exceeded capacity.
expand an existing
middle/intermediate
school
7/40
SCA
Provide a new or
The high schools are beyond capacity.
expand an existing
high school
9/40
SCA
Provide a new or
This one of the few schools in the City without a
expand an existing
gym and it has a growing immigrant community
elementary school
population taxing makeshift resources.
22/40
SCA
Renovate other site
Pave and stripe the P.S. 21 schoolyard.
component
27/40
SCA
Renovate or
provide padding to the support poles in the
upgrade an
P.S.21 for multi-purpose uses.
elementary school
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
5/25
DYCD
Provide, expand, or
This excellent program needs substantial
enhance the
increases to its funding to allow a larger
Summer Youth
number of young people to benefit from being
Employment
able to have a Summer job that not only
Program
provides cash but also skills training.
7/25
DOE
Provide, expand, or
Increase by a three-fold factor the number of
enhance funding for
slots available for day care.
Child Care and Head
Start programs
8/25
ACS
Provide, expand, or
provide sufficient funding for youth
enhance preventive
development and delinquency prevention
services and
programs.
community based
alternatives for
youth
9/25
DOE
Other educational programs requests
fund visual arts and performance programming
11/25
DYCD
Provide, expand, or
The expansion of after school programs in the
enhance after
elementary grades is a very important service
school programs for
that enhances educational skills as well as
elementary school
enabling parents to work, especially inP.S.31;P.S.
students (grades K-
1o; P.S. 16; P.S.59; P.S.13; P.S. 74; P.S. 18; and,
5)
P.S.4.
12/25
DYCD
Provide, expand, or
Adult literacy is critical to employment and the
enhance adult
high unemployment rate in some Board areas is
literacy programs
caused by adults lack of literacy. This is a crucial
services
skill and these literacy programs need
immediate and sufficient funding.
21/25
DOE
Expand or improve
to be sure there are no hungry children in our
nutritional
City.
programs, e.g.,
school meals
24/25
DYCD
Provide, expand, or
To provide educational options and enrichment
enhance after
choices for our youngsters.
school programs for
elementary school
students (grades K-
5)
25/25
DYCD
Provide, expand, or
To be sure young people have a safe and
enhance after
productive place to go at night.
school programs for
all grade levels
PUBLIC SAFETY AND EMERGENCY SERVICES
Staten Island Community Board 1
image
M ost Important Issue Related to Public Safety and Emergency Services
Public safety facilities (precinct, fire houses, etc.)
The current 120 Precinct is outmoded and an impediment to traffic access around downtown St. George. NYPD owns property on Hill Street and should locate the precinct there.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Therre is a need fo vertical patrols in our housing comlexes and a need for CPOP-like patrols in our other residential and commercial communities,
Needs for Emergency Services
The redevelopment of St. George and Stapleton along with the implementation of the Affordable Housing program as well as the increased response times caused by the awful traffic conditions is creating an urgent need for a new FDNY facility.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/40
NYPD
Provide a new NYPD
With the proposed Bay Street Corridor
facility, such as a
Affordable Housing rezoning, coupled with the
new precinct house
new North Shore residential and commercial
or sub-precinct
redevelopment, the current 120th is no longer
adequate for the personnel and equipment nd
vehicles needed to keep the public safe. The
proposed Hill Street stationhouse needs to be
built.
4/40
FDNY
Provide new
The population is rising and will rise faster with
facilities such as a
the St. George, Stapleton and Bay Street
firehouse or EMS
Corridor Affordable Housing programs,
station
including the expanded commercial activities.
Since response times have risen, this new facility
a matter will become one of exrtreme public
safety importance.
28/40
FDNY
Provide new
For use in natural emergencies or terrorism
emergency vehicles,
activities.
such as fire trucks or
ambulances
Expense Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Staten Island Community Board 1
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water runoff and flooding
Several areas need storm sewers to prevent property destruction and flooding.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
The North Shore Bluebelt and the Victory Boulevard and the Forest Avenue drainage areas must be sewered to stop the endless flooding therein.
Needs for Sanitation Services
DoS service is excellent and the Board is thankful to Commissioner Garcia and Councilwoman Rose that District 1 will be relocating!
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
10/40
DEP
Inspect water main
To stop flooding.
on specific street
segment and repair
or replace as
needed (Capital)
16/40
DEP
Inspect water main
To end flooding and ponding.
on specific street
segment and repair
or replace as
needed (Capital)
17/40
DEP
Inspect water main
To stop property destruction and flooding.
on specific street
segment and repair
or replace as
needed (Capital)
18/40
DEP
Develop a capital
Top stop endless property destruction from
project for specific
flooding.
street segments
currently lacking
sanitary sewers
20/40
DEP
Inspect water main
To eliminate damage from flooding.
on specific street
segment and repair
or replace as
needed (Capital)
38/40
DEP
Inspect sanitary
To prevent flooding and property damage.
sewer on specific
street segment and
repair or replace as
needed (Capital)
Expense Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Staten Island Community Board 1
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
All your listed items are predicated upon appropriate zoning and the district is lacking in that regard. The zoning throughout Rosebank, Shore Acres and Fort Wadsworth needs amending and the zoning from Snug Harbor to the Ferry needs to be changed to C4-2. The Bay Street Corridor Affordable Housing Program will fail unless there is concurrent infrastructure development.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
The district is an uneven collection of M zones within and beside R zones and the R zones are an uneven array of categories. Affordable housing, area stability and appropriate land use requires zoning reflective of good planning and careful needs assessment.
Needs for Housing
There is a great need for affordable housing and for senior housing.
Needs for Economic Development
The district is primed for about a one billion dollar private sector investment which will require the EDC to make corresponding investment to the infrastructure from the NY Wheel site to the Navy Pier site, including creating connectivty from Stapleton to the Homeport. Furthermore, the EDC will have to negotiate land swaps and ROW usages to create the North Shore Grenway Heritage Trail and to allow for the creation of an SBS or BRT dedicated route along the old ROW. The development of BID's and the support for small businesses, incubators and art oriented development will need to be a preeminent part of all future economic develpopment plans.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
11/40
EDC
Make infrastructure
Redevelop the site of the failed Wheel into an
investments that
economic tour de force.
will support growth
in local business
districts
29/40
EDC
Invest in capital
The New York Containerport infrastructure is in
300 Western
projects to improve
need of better truck access and in need of a new
Ave
access to the
pier and an expansion of the site.
waterfront
30/40
EDC
Invest in capital
To stay competitive, Howland Hook needs
projects to improve
improved docks and new cranes.
access to the
waterfront
37/40
EDC
Make infrastructure
The infrastructure from Empire Outlets to the
Front St Bay
investments that
Navy Pier must be upgraded to allow for better
Street
will support growth
traffic control, better drainage control and
hannah street
in local business
better downtown connectivity.
districts
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
15/25 DCP Other zoning and
land use requests
The corridor from Snug Harbor to Vanderbilt Avenue needs to be zoned C 4-2 to permit affordable housing, including sites affordable for seniors.
image
17/25 DCP Study land use and
zoning to better match current use or future neighborhood needs
Undertake a comprehensive study of current and trending land use and zoning to craft appropriate zoning maps.
image
23/25 DOB Address illegal
conversions and uses of buildings
With land running out, the new approach is to try to increase profitability by doing untoward building conversions, especially in R zones which greatly impact zoning performance protections.
TRANSPORTATION
Staten Island Community Board 1
image
M ost Important Issue Related to Transportation and Mobility
Traffic safety
Staten Island has congested unkempt roadways, poor signal coordination, poorly imagined bike lanes and too many vehicles. The result of these factors causes poor driving habits, accidents and danger to pedestrians and bike riders.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Street conditions, traffic flow, BRT lanes, smart lights and bulkhead improvents in St. George and Rosebank are required.
Needs for Transit Services
SBS and BRT services, local fleet increases and scheduling increases to the SIRTOA coupled with station reconstruction of the Stapleton station.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
12/40
DOT
Improve traffic and
To make it safe for students to walk to school
pedestrian safety,
and to ease the terrible congestion on Clove
including traffic
Road.
calming (Capital)
14/40
DOT
Upgrade or create
Improve the streetscape along the greenway
new greenways
with lighting, sidewalks and additions attractive
to business development.
15/40
DOT
Repair or construct
replace curbs on colonial court and Tompkins
new curbs or
between Lyman and Hylan.
pedestrian ramps
19/40
DOT
Other
Purchase Augustinian property from Howard
clove road
transportation
Avenue to the service road to build a dedicated
howard
infrastructure
turn lane.
avenue
requests
narrows road
north
21/40
NYCTA
Repair or upgrade
The Stapleton station needs to be made safe to
subway stations or
accomodate the development of the Navy Pier
other transit
project.
infrastructure
23/40
DOT
Improve traffic and
There have been multiple pedestrian accidents
pedestrian safety,
here. It is dangerous.
including traffic
calming (Capital)
24/40
DOT
Improve traffic and
To move traffic safely at major intersections,
pedestrian safety,
high pedestrian crossings, schools and business
including traffic
areas.
calming (Capital)
25/40
DOT
Other capital traffic
To ease awful SIE and local road congestion
improvements
when ships are in port.
requests
31/40
DOT
Reconstruct streets
reconstruct dixon and lake avenues
32/40
DOT
Upgrade or provide
Routes isolated from trafic congestion are
new Select Bus
needed to get folks to work in a timely manner.
Service (SBS) routes
33/40 DOT Other capital traffic
improvements requests
The streets are deteriorating.
image
36/40 DOT Improve traffic and
pedestrian safety, including traffic calming (Capital)
To make pedestrians safe and ease traffic congestion.
image
40/40 DOT Improve traffic and
pedestrian safety, including traffic calming (Capital)
The destruction of Bank Street for the now demised NY Wheel has created traffic chaos on the Terrace. The street needs to be rebuilt to allow easy access to the ferry and to parking.
image
CS DOT Repair or provide new street lights
Additional street lighting on vanderbilt avenue vanderbilt
avenue richmond road bay street
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
20/25
DOT
Other expense traffic improvements requests
To keep riders out of the elements.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Staten Island Community Board 1
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Library facilities and access
Rosebank is a large and growing area without a library.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Along with Cromwell, the DPR should be allocated a dedicated base line budget of at least $100 million and $17 million to acquire the last phase of the Goodhue property.
Needs for Cultural Services
The base line funding for both small cultural groups and CIG's needs to be increase to allow service to keep up with population growth.
Needs for Library Services
The libraries have been heavily used and require not only facility repair and equipment purchases but also staff additions and program expansions. Moreover, the Rosebank community is in great need of a library.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/40
DPR
Provide a new, or
Cromwell Center needs to be rebuilt above
new expansion to, a
Lyons Pool thus staying central to the district
building in a park
and including a year round aquatic facility.
3/40
DPR
Other requests for
SI Parks needs a base line capital budget of
park, building, or
$100 million to allow for the building of new
access
and renovation of old facilities without elected
improvements
officials having to pay for these items. It is a
gross inequity.
13/40
DPR
Provide a new or
Design and build the North Shore Greenway
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
26/40
DPR
Provide a new or
Provide bathrooms (at the least, portable
expanded park or
toilets)and water fountains in all North Shore
amenity (i.e.
parks lacking the same.
playground, outdoor
athletic field)
34/40
NYPL
Create a new, or
renovate with ada compliance the port
renovate or upgrade
richmond, st. george, west new brighton and
an existing public
Westerleigh libraries.
library
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
10/25 DPR Improve access to a
building in a park
Staff should be provided to keep bathrooms open as long as each park is open.
image
13/25 DPR Enhance park safety
through more security staff (police or parks enforcement)
To have adequate safety protection for parks.
image
16/25 DCLA Support nonprofit
cultural organizations
Fund culturals with budgets under $24,900 and culturals in business for at least five years with a minimum of $25,000 each to enable these small but essential parts of our cultural community to thrive.
image
18/25 DCLA Support nonprofit
cultural organizations
Provide $50,000 to Snug Harbor's school program.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
5/40
Other
Other capital budget request
Rosebank has requested a library for 25 years. The land behind St. Mary's school is available for purchase and a deal should be enacted ASAP.
35/40
Other
Other capital budget request
The structures of these buildings need work keeping them in good condition.
39/40
Other
Other capital budget request
For public safety.
Other Expense Requests
Priority Agency Request Explanation Location
image
14/25 Other Other expense
budget request
Provide Cultural Affairs funding to these programs for disabled children.
image
22/25 Other Other expense
budget request
Provide Department of the Aging funding increases to the SI senior centers, a place for respite and companionship.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/40
NYPD
Provide a new NYPD
With the proposed Bay Street Corridor
facility, such as a
Affordable Housing rezoning, coupled with the
new precinct house
new North Shore residential and commercial
or sub-precinct
redevelopment, the current 120th is no longer
adequate for the personnel and equipment nd
vehicles needed to keep the public safe. The
proposed Hill Street stationhouse needs to be
built.
2/40
DPR
Provide a new, or
Cromwell Center needs to be rebuilt above
new expansion to, a
Lyons Pool thus staying central to the district
building in a park
and including a year round aquatic facility.
3/40
DPR
Other requests for
SI Parks needs a base line capital budget of
park, building, or
$100 million to allow for the building of new
access
and renovation of old facilities without elected
improvements
officials having to pay for these items. It is a
gross inequity.
4/40
FDNY
Provide new
The population is rising and will rise faster with
facilities such as a
the St. George, Stapleton and Bay Street
firehouse or EMS
Corridor Affordable Housing programs,
station
including the expanded commercial activities.
Since response times have risen, this new facility
a matter will become one of exrtreme public
safety importance.
5/40
Other
Other capital budget
Rosebank has requested a library for 25 years.
request
The land behind St. Mary's school is available
for purchase and a deal should be enacted
ASAP.
6/40
SCA
Provide a new or
Middle schools have exceeded capacity.
expand an existing
middle/intermediate
school
7/40
SCA
Provide a new or
The high schools are beyond capacity.
expand an existing
high school
8/40
HHC
Other health care
Provide 5% of the HHC tax levy capital budget to
facilities requests
the two SI Hospital systems to provide equity to
the City's medical care delivery system and to
ensure the access to health care for Staten
Islanders.
9/40
SCA
Provide a new or
This one of the few schools in the City without a
expand an existing
gym and it has a growing immigrant community
elementary school
population taxing makeshift resources.
10/40
DEP
Inspect water main
To stop flooding.
on specific street
segment and repair
or replace as
needed (Capital)
11/40
EDC
Make infrastructure
Redevelop the site of the failed Wheel into an
investments that
economic tour de force.
will support growth
in local business
districts
12/40
DOT
Improve traffic and
To make it safe for students to walk to school
pedestrian safety,
and to ease the terrible congestion on Clove
including traffic
Road.
calming (Capital)
13/40
DPR
Provide a new or
Design and build the North Shore Greenway
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
14/40
DOT
Upgrade or create
Improve the streetscape along the greenway
new greenways
with lighting, sidewalks and additions attractive
to business development.
15/40
DOT
Repair or construct
replace curbs on colonial court and Tompkins
new curbs or
between Lyman and Hylan.
pedestrian ramps
16/40
DEP
Inspect water main
To end flooding and ponding.
on specific street
segment and repair
or replace as
needed (Capital)
17/40
DEP
Inspect water main
To stop property destruction and flooding.
on specific street
segment and repair
or replace as
needed (Capital)
18/40
DEP
Develop a capital
Top stop endless property destruction from
project for specific
flooding.
street segments
currently lacking
sanitary sewers
19/40
DOT
Other
Purchase Augustinian property from Howard
clove road
transportation
Avenue to the service road to build a dedicated
howard
infrastructure
turn lane.
avenue
requests
narrows road
north
20/40
DEP
Inspect water main
To eliminate damage from flooding.
on specific street
segment and repair
or replace as
needed (Capital)
21/40
NYCTA
Repair or upgrade
The Stapleton station needs to be made safe to
subway stations or
accomodate the development of the Navy Pier
other transit
project.
infrastructure
22/40
SCA
Renovate other site
Pave and stripe the P.S. 21 schoolyard.
component
23/40
DOT
Improve traffic and
There have been multiple pedestrian accidents
pedestrian safety,
here. It is dangerous.
including traffic
calming (Capital)
24/40
DOT
Improve traffic and
To move traffic safely at major intersections,
pedestrian safety,
high pedestrian crossings, schools and business
including traffic
areas.
calming (Capital)
25/40
DOT
Other capital traffic
To ease awful SIE and local road congestion
improvements
when ships are in port.
requests
26/40
DPR
Provide a new or
Provide bathrooms (at the least, portable
expanded park or
toilets)and water fountains in all North Shore
amenity (i.e.
parks lacking the same.
playground, outdoor
athletic field)
27/40
SCA
Renovate or upgrade an elementary school
provide padding to the support poles in the
P.S.21 for multi-purpose uses.
28/40
FDNY
Provide new
For use in natural emergencies or terrorism
emergency vehicles,
activities.
such as fire trucks or
ambulances
29/40
EDC
Invest in capital
The New York Containerport infrastructure is in
300 Western
projects to improve
need of better truck access and in need of a new
Ave
access to the
pier and an expansion of the site.
waterfront
30/40
EDC
Invest in capital
To stay competitive, Howland Hook needs
projects to improve
improved docks and new cranes.
access to the
waterfront
31/40
DOT
Reconstruct streets
reconstruct dixon and lake avenues
32/40
DOT
Upgrade or provide
Routes isolated from trafic congestion are
new Select Bus
needed to get folks to work in a timely manner.
Service (SBS) routes
33/40
DOT
Other capital traffic
The streets are deteriorating.
improvements
requests
34/40
NYPL
Create a new, or
renovate with ada compliance the port
renovate or upgrade
richmond, st. george, west new brighton and
an existing public
Westerleigh libraries.
library
35/40
Other
Other capital budget
The structures of these buildings need work
request
keeping them in good condition.
36/40
DOT
Improve traffic and
To make pedestrians safe and ease traffic
pedestrian safety,
congestion.
including traffic
calming (Capital)
37/40
EDC
Make infrastructure
The infrastructure from Empire Outlets to the
Front St Bay
investments that
Navy Pier must be upgraded to allow for better
Street
will support growth
traffic control, better drainage control and
hannah street
in local business
better downtown connectivity.
districts
38/40 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
To prevent flooding and property damage.
image
39/40 Other Other capital budget
request
For public safety.
image
40/40 DOT Improve traffic and
pedestrian safety, including traffic calming (Capital)
The destruction of Bank Street for the now demised NY Wheel has created traffic chaos on the Terrace. The street needs to be rebuilt to allow easy access to the ferry and to parking.
image
CS DOT Repair or provide new street lights
Additional street lighting on vanderbilt avenue vanderbilt
avenue richmond road bay street
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
DFTA
Enhance programs
Elder abuse is increasing dramatically and this
for elder abuse
trend must be halted.
victims
2/25
DOHMH
Create or promote
create programs to provide community
new greenways
with lighting, sidewalks and additions attractive
to business development.
15/40
DOT
Repair or construct
replace curbs on colonial court and Tompkins
new curbs or
between Lyman and Hylan.
pedestrian ramps
16/40
DEP
Inspect water main
To end flooding and ponding.
on specific street
segment and repair
or replace as
needed (Capital)
17/40
DEP
Inspect water main
To stop property destruction and flooding.
on specific street
segment and repair
or replace as
needed (Capital)
18/40
DEP
Develop a capital
Top stop endless property destruction from
project for specific
flooding.
street segments
currently lacking
sanitary sewers
19/40
DOT
Other
Purchase Augustinian property from Howard
clove road
transportation
Avenue to the service road to build a dedicated
howard
infrastructure
turn lane.
avenue
requests
narrows road
north
20/40
DEP
Inspect water main
To eliminate damage from flooding.
on specific street
segment and repair
or replace as
needed (Capital)
21/40
NYCTA
Repair or upgrade
The Stapleton station needs to be made safe to
subway stations or
accomodate the development of the Navy Pier
other transit
project.
infrastructure
22/40
SCA
Renovate other site
Pave and stripe the P.S. 21 schoolyard.
component
23/40
DOT
Improve traffic and
There have been multiple pedestrian accidents
pedestrian safety,
here. It is dangerous.
including traffic
calming (Capital)
24/40
DOT
Improve traffic and
To move traffic safely at major intersections,
pedestrian safety,
high pedestrian crossings, schools and business
including traffic
areas.
calming (Capital)
25/40
DOT
Other capital traffic
To ease awful SIE and local road congestion
improvements
when ships are in port.
requests
26/40
DPR
Provide a new or
Provide bathrooms (at the least, portable
expanded park or
toilets)and water fountains in all North Shore
amenity (i.e.
parks lacking the same.
playground, outdoor
athletic field)
27/40
SCA
Renovate or upgrade an elementary school
provide padding to the support poles in the
P.S.21 for multi-purpose uses.
28/40
FDNY
Provide new
For use in natural emergencies or terrorism
emergency vehicles,
activities.
such as fire trucks or
ambulances
29/40
EDC
Invest in capital
The New York Containerport infrastructure is in
300 Western
projects to improve
need of better truck access and in need of a new
Ave
access to the
pier and an expansion of the site.
waterfront
30/40
EDC
Invest in capital
To stay competitive, Howland Hook needs
projects to improve
improved docks and new cranes.
access to the
waterfront
31/40
DOT
Reconstruct streets
reconstruct dixon and lake avenues
32/40
DOT
Upgrade or provide
Routes isolated from trafic congestion are
new Select Bus
needed to get folks to work in a timely manner.
Service (SBS) routes
33/40
DOT
Other capital traffic
The streets are deteriorating.
improvements
requests
34/40
NYPL
Create a new, or
renovate with ada compliance the port
renovate or upgrade
richmond, st. george, west new brighton and
an existing public
Westerleigh libraries.
library
35/40
Other
Other capital budget
The structures of these buildings need work
request
keeping them in good condition.
36/40
DOT
Improve traffic and
To make pedestrians safe and ease traffic
pedestrian safety,
congestion.
including traffic
calming (Capital)
37/40
EDC
Make infrastructure
The infrastructure from Empire Outlets to the
Front St Bay
investments that
Navy Pier must be upgraded to allow for better
Street
will support growth
traffic control, better drainage control and
hannah street
in local business
better downtown connectivity.
districts
38/40 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
To prevent flooding and property damage.
image
39/40 Other Other capital budget
request
For public safety.
image
40/40 DOT Improve traffic and
pedestrian safety, including traffic calming (Capital)
The destruction of Bank Street for the now demised NY Wheel has created traffic chaos on the Terrace. The street needs to be rebuilt to allow easy access to the ferry and to parking.
image
CS DOT Repair or provide new street lights
Additional street lighting on vanderbilt avenue vanderbilt
avenue richmond road bay street
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
DFTA
Enhance programs
Elder abuse is increasing dramatically and this
for elder abuse
trend must be halted.
victims
2/25
DOHMH
Create or promote
create programs to provide community
programs to de-
education regarding the mental and physical
stigmatize mental
health issues of transgendered youth.
health problems
and encourage
treatment
3/25
DHS
Expand
Staten Island has one service provider and
homelessness
funding is insufficient to provide for the actual
prevention
homelessness that needs to be resolved and the
programs
programming required to prevent
homelessness.
4/25
HRA
Provide, expand, or
With the high joblessness rate in North Shore
enhance job training
communities, there is a great need to provide
folks with skill set training in fields where jobs
are available. There is also a need to partner
with labor unions to help the unemployed get
the skills' training required to get a union card.
5/25
DYCD
Provide, expand, or
This excellent program needs substantial
enhance the
increases to its funding to allow a larger
Summer Youth
number of young people to benefit from being
Employment
able to have a Summer job that not only
Program
provides cash but also skills training.
6/25
HRA
Provide social
There is an immediate need to provide
services for
additional funds to the District Attorney's
domestic violence
domestic violence program. This crime is
survivors (legal
increasing and an all out effort is needed to
services, counseling,
round up the abusers and take care of those
referral to
abused.
supportive services,
etc.)
7/25
DOE
Provide, expand, or
Increase by a three-fold factor the number of
enhance funding for
slots available for day care.
Child Care and Head
Start programs
8/25
ACS
Provide, expand, or
provide sufficient funding for youth
enhance preventive
development and delinquency prevention
services and
programs.
community based
alternatives for
youth
9/25
DOE
Other educational
fund visual arts and performance programming
programs requests
10/25
DPR
Improve access to a
Staff should be provided to keep bathrooms
building in a park
open as long as each park is open.
11/25
DYCD
Provide, expand, or
The expansion of after school programs in the
enhance after
elementary grades is a very important service
school programs for
that enhances educational skills as well as
elementary school
enabling parents to work, especially inP.S.31;P.S.
students (grades K-
1o; P.S. 16; P.S.59; P.S.13; P.S. 74; P.S. 18; and,
5)
P.S.4.
12/25
DYCD
Provide, expand, or
Adult literacy is critical to employment and the
enhance adult
high unemployment rate in some Board areas is
literacy programs
caused by adults lack of literacy. This is a crucial
services
skill and these literacy programs need
immediate and sufficient funding.
13/25
DPR
Enhance park safety
To have adequate safety protection for parks.
through more
security staff (police
or parks
enforcement)
14/25
Other
Other expense
Provide Cultural Affairs funding to these
budget request
programs for disabled children.
15/25
DCP
Other zoning and
The corridor from Snug Harbor to Vanderbilt
land use requests
Avenue needs to be zoned C 4-2 to permit
affordable housing, including sites affordable
for seniors.
16/25
DCLA
Support nonprofit
Fund culturals with budgets under $24,900 and
cultural
culturals in business for at least five years with a
organizations
minimum of $25,000 each to enable these small
but essential parts of our cultural community to
thrive.
17/25
DCP
Study land use and
Undertake a comprehensive study of current
zoning to better
and trending land use and zoning to craft
match current use
appropriate zoning maps.
or future
neighborhood
needs
18/25
DCLA
Support nonprofit
Provide $50,000 to Snug Harbor's school
cultural
program.
organizations
19/25
DOHMH
Other programs to
To provide folks are trained in safe food
address public
handling thus decreasing public danger.
health issues
requests
20/25
DOT
Other expense
To keep riders out of the elements.
traffic
improvements
requests
21/25
DOE
Expand or improve
to be sure there are no hungry children in our
nutritional
City.
programs, e.g.,
school meals
22/25
Other
Other expense
Provide Department of the Aging funding
budget request
increases to the SI senior centers, a place for
respite and companionship.
23/25
DOB
Address illegal
With land running out, the new approach is to
conversions and
try to increase profitability by doing untoward
uses of buildings
building conversions, especially in R zones which
greatly impact zoning performance protections.
24/25
DYCD
Provide, expand, or
To provide educational options and enrichment
enhance after
choices for our youngsters.
school programs for
elementary school
students (grades K-
5)
25/25
DYCD
Provide, expand, or
To be sure young people have a safe and
enhance after
productive place to go at night.
school programs for
all grade levels

