- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 10 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1z41lmz-G5SXUcWxxTkawORImrB_LBml4/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1z41lmz-G5SXUcWxxTkawORImrB_LBml4/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
10
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 10
image
Address: 115-01 Lefferts Blvd. Phone: (718) 843-4488
Email: qn10@cb.nyc.gov
Website: www.nyc.gov/queenscb10
Chair: Betty Braton District Manager: Karyn Petersen
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 10 is located in Southwest Queens. Within the Board’s boundaries are all of the Howard Beach communities located within zip code 11414; all of those communities located within Ozone Park zip code 11417; all of the South Ozone Park zip code 11420 communities; and approximately half of the Richmond Hill South zip code 11419. A small part of zip code 11430 is also within our boundaries, but it is not populated, except for a homeless shelter, as most of that zip code’s geography is on-airport. Community Board 10 encompasses approximately 4,000 acres and just over 6 square miles of the borough’s land area. Our Board abuts JFK International Airport and Jamaica Bay. What occurs at both are important to our residents. New York City’s only casino facility is located virtually in the center of our Board area. All the communities located within our Board are in close proximity to it. People in all of our communities share similar concerns regarding current activity and future development plans at the casino. At present, Resorts World has begun construction of a 400 room hotel at the site. There are also plans to develop 140,000 sq. ft. of exhibition space. Community Board 10, located in Southwest Queens, is racially diverse and generally economically stable. Our district has a large foreign-born population and a growing senior population.
Approximately 1/3 of our district's land area was inundated by Superstorm Sandy's floodwaters in 2012. Sandy negatively impacted about 20,000 of our residents and caused damage to approximately 5,000 homes and many of our businesses. Now, 5 years later, much needed resiliency projects and coastal protection projects are not moving forward in a timely manner. General Needs: • Housing – continued building code enforcement; better strategies to provide adequate maintenance of vacant/abandoned homes; better strategies to identify current owners of vacant properties; effective requirement for ongoing maintenance of vacant homes • Land Use – contextual rezoning; implementation of resiliency projects; prohibit pawn shops as allowable in C2 use groups; eliminate off-street parking requirement waivers for community facilities and commercial development; increase DOB inspection personnel; review/alter DOB self-certification process; insure use/occupancy code compliance • Transportation – provide reliable bus service without reducing travel lanes for other vehicles; expand express bus service; implement “Super A” subway service; continue rehabilitation of all el stations; increase accessibility to all el stations not yet made accessible; construct southbound Aqueduct Station platform; maintain current levels of on-street parking availability on all our commercial corridors; provide Q11 late night service; improve accessibility to Hamilton Beach; reduce speeding; enforce parking regulations; improve infrastructure; periodically review implemented traffic calming measures and correct negative impacts; require Community Board review of parking regulation changes; post No Truck signage • Parks – assign maintenance personnel at each park daily; provide year round recreation services in parks; expand summer programs for youth; provide appropriate recreation services and facilities for seniors; provide a recreation center; provide a swimming pool; provide a park facility north of Rockaway Blvd.; expand forestry service; increase forestry personnel • Public Facilities - expand library service; increase funding to Boys & Girls Club of MetroNY; provide for local review of youth services funding; restore Youth Coordinator position; eliminate all fees for public purpose use of school buildings; construct new schools; expand school art and music programs; identify sites for PreK services; provide additional senior centers; close Skyway Men’s Shelter and reopen former Skyway Family Shelter; require Community Board review of any and all proposed ACS facilities, relocate Close to Home Limited Secure facility from South Ozone Park location. • Public Safety – continue to increase number of permanently assigned police officers in 106th Pct.; support peace officer status for Resorts World security force; expand noise violation enforcement; reduce backlogs; reduce response times; improve 311 complaint intake process and action taken reporting; increase critical infrastructure protection; expand OEM education initiatives; expand fire safety education; continue distribution of smoke and CO2 detectors • Water, Sewer, Sanitation – inspect, clean, and repair all catch basins; clean all catch basins in Sandy zone annually prior to hurricane season; resolve long-standing poor drainage conditions; expand installation of green infrastructure in poor drainage areas; develop and employ better strategies to insure cleanliness of vacant lots; expand basket collection on commercial strips; provide daily collection of school garbage during 4-12 PM time period • Economic Development – expand business services; provide more direct grants to business owners in Sandy zone • Resiliency, Sustainability – provide flood surge protection; protect power supply; prevent sewer backup; protect vulnerable population; improve Build it Back; construct bulkheads; provide financial incentives to encourage elevation and/or relocation of critical building utilities; upgrade sewage pumping station; support and implement all components of Howard Beach NY Rising recommended projects; implement ecosystem restoration project in Spring Creek Park • Community Boards – continue to baseline budget; restore agency business parking permits to Board Chairpersons; improve 311 and other reporting systems
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 10
image
The three most pressing issues facing this Community Board are:
Quality of life issues (noise, graffiti, petty crime, etc.)
Due to the addition of more police officers and the excellent work our precinct personnel, crime, as measured by the 7 major felony categories, was reduced during FY 2019. That trend appears to be continuing thus far into FY2020. However, policing-related quality of life concerns persist. Residential noise complaints and complaints of derelict vehicles continue to be made by our residents in all parts of the district. Quality of Life issues related to other agencies also persist although to a lesser degree than those related to policing.
Infrastructure resiliency
Our district was severely impacted by tidal flooding in 2012 from Superstorm Sandy. Not long after Sandy, our Lindenwood community experienced damage from stormwater flooding during rain events due to issues related to the sewer system. A third of our district's land mass, over 20,000 of our residents, and approximately 5,000 of our homes were flooded and damaged. The homeowners suffered both physical and financial damage. In many cases neither FEMA assistance, flood insurance coverage, nor Build it Back aid was sufficient to meet their needs. The Cross Bay Blvd. commercial corridor and virtually all of its retail and other establishments were damaged both physically and economically. Surge protection and other resiliency projects must be implemented at a far faster pace. Our stormwater drainage system must be fully inspected and upgraded, particularly in all parts of Howard Beach. Areas where there are long-standing ponding conditions throughout our district must be corrected.
Programs to provide homeowners in our Sandy-impacted area with financial incentives whether through reduced property taxes, tax incentives, direct grants, or a combination of methods to encourage them to implement resiliency improvements that most are finding are costly and beyond their means to do. Uncertainty as to what the future holds in regard to the flood insurance issues they face may have a destabilizing impact on the neighborhoods in coming years if homeowners cannot afford either increased flood insurance premiums or the needed resiliency improvements to effect reductions in those insurance premiums. It is imperative that the city implement coastal protection measures, such as bulkheads on city-owned street stubends adjacent to Hawtree Basin and Shellbank Basin, to better protect our neighborhoods so that the burden is not solely on the homeowners.
Street conditions (roadway maintenance)
Our residents regularly complain of conditions where roadway maintenance is needed. Although we have seen milling and repaving of some streets more is needed. Some streets within our neighborhoods have not been repaved for more than 20 years. All of our roadways are suffering from more general wear and tear due to increased traffic therefore they need to be maintained more frequently. There is a need to insure that when trenching occurs, whether by private contractors, utility companies, or city agencies, that repairs and repaving are timely and performed satisfactorily so that new ponding conditions or other problems with the street condition arise.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 10
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
Services to seniors in our district need to be increased. Census 2010 reported we have almost 22,000 residents over age 60. Approximately 7,000 more of our residents will reach age 60 over the next few years. There is only one city funded senior center in our district to serve a large and growing population of older residents. When services should have been expanding to meet the needs of our growing senior population, we have experienced services being diminished. There is a need to fully fund and re-open the Wakefield Senior Center to serve our growing senior population in South Ozone Park. There is also a need to develop a new properly operated center to replace the de- funded center that formerly served many of our Indo- Caribbean seniors as that population is also growing.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
There is no hospital facility in the district to serve our population, many of whom are foreign-born, elderly, or both. In recent years, hospitals have been closed in Queens resulting in less beds within the borough to serve a growing population.
Needs for Older NYs
There is only one city-funded senior center located in our district. The sole city-funded senior center in our district was displaced by Superstorm Sandy. It has now moved and is operational at the Catholic Charities operated Peter Striano senior housing facility. This site is located in that segment of the district that has the largest concentration of older residents. About 35% of our district's total of persons over age 60 reside in Neighborhood Tabulation Area QN57 where this senior housing/senior center facility is located. Over 28% of the people who live within QN57 are over age 60. Three of the four census tracts within NTA QN57 rank among the census tracts in the Borough of Queens with the most seniors. In census tract 892 33% of the population is over age 60 and this census tract ranks 5th highest in Queens in terms of its total number of persons over age 60. In census tract 62.01, 40% of the population is over age 60 and it ranks 8th highest in the borough in the number of seniors. Census tract 884's population is 25% over age 60 and it ranks 14th highest in the borough. QN57 is the area of our Board inundated by Superstorm Sandy. It is imperative that this center be well funded by DFTA, its services expanded, and that its funding be fully immune from any cuts until the community is fully recovered from Sandy impacts. There is a need for additional funding so that appropriate support personnel may be available there daily to assist the thousands of neighborhood seniors now living in damaged homes trying to cope with numerous social and economic issues.
Another 15% of our district's residents who are over age 60 live in QN56 in close proximity to the site. Almost half of our district's over 60 population reside in NTA QN56 and QN57 together. This Catholic Charities facility literally sits on the border between those two NTAs. There is a need for DFTA and other city agencies to work closely with Catholic Charities to bring even more quality services to this facility to better serve our growing senior population.
The facility serves the community-at-large as well as its residents. Our South Ozone Park community and our Richmond Hill community have no city-funded senior centers. There is a need to provide additional services within those parts of our district. Our seniors should not have to go to areas outside of Community Board 10 to attend a senior center and have programming available for them.
Needs for Homeless
There is a need to close the Skyway Men's Shelter and reopen Skyway as a family shelter. There is a need to provide additional security at homeless shelters. There is a need to cease using hotels to house homeless persons.
Needs for Low Income NYs
There is a need to provide a multi-service center facility to serve our low income and vulnerable residents. Such a facility would serve to be a one-stop location where information, services, and programs could be provided. There is a need to expand SNAP.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
8/30 DFTA Create a new senior
center or other facility for seniors
Request funds to be made available to build new senior centers. Senior population continues to grow and additional services are needed.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
25/36 DFTA Increase case
management capacity
Support case management, increased allocation for meals, funding for elder abuse programs, legal services for the elderly and to improve transportation. The request is to ensure agency resources are sufficient to fulfill agency mission.
image
31/36 DHS Improve safety at
homeless shelters
Support for additional security, recreation and added programs. To ensure agency resources are sufficient to fulfill agency mission
image
34/36 DOHMH Create or promote
programs to de- stigmatize mental health problems and encourage treatment
Support for mental health services.
image
35/36 HRA Provide, expand, or
enhance food assistance, such as Food Stamps / SNAP
Support SNAP Outreach Campaign
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 10
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
School seats are needed to serve the children of School District 27. Proper educational facilities with a full range of services are imperative for all children. Our CB District needs less juvenile justice programs and more services for our school age children during and after school hours.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
One new school was constructed in our district that opened in Sept, 2017. However, additional school seats are needed. Additional sites for new school construction must be located and construction must be expedited to ensure adequate educational facilities for our children. Over 20% of our population is under age 18. The influx of families with school age children continues, particularly in the northern and eastern parts of our area. Many of the school buildings are overcrowded and parents see a diminished range of what is being offered to the students at the elementary school level. More art and music programs are needed. Parents are concerned with the quality of education and the safety factor as students move to the Middle Schools and the High Schools. The physical plants of many of our school buildings still need attention. Appropriate sites for additional Pre-Kindergarten services are needed. Most of the schools in our area have had their play areas diminished in recent years by the placement of transportable classrooms and/or modular additions. All transportable classrooms need to be replaced with permanent seats available to our students. Every child in our Community Board area must have a seat in his or her neighborhood school and each school must provide a full range of educational services. Queens has 18% of its children eligible for EarlyLearn NYC programs. Yet out of 362 center-based EarlyLearnNYC, only 38 were located in Queens during the 2014-15 school year. CB10 had zero. Despite the fact that 19% of our families with children under 5 who live within zipcode 11420 live in households with incomes below federal poverty guidelines, ACS opted to establish 2 juvenile justice facilities without any community consultation, rather than provide any EarlyLearn Centers. Additional schools would serve our real youth needs far better than these juvenile jails.
Needs for Youth and Child Welfare
ACS has established juvenile justice facilities within our district. Far better oversight of the provider agencies is needed.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
1/30 SCA Provide a new or
expand an existing elementary school
Within Community District 10's area, serious overcrowding has created a desperate need for additional classrooms in new schools. Expansion of preK programs add to the need for additional school buildings and seats.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
18/36
DOE
Other educational
Establish a contribution by the Department of
programs requests
Education for Joint Operated Playgrounds. Joint
operated playgrounds are presently
maintained/operated solely with Parks
Department personnel and budget. Due to
severe cutbacks, the responsibility must be
shared as joint operated implies. Dept. of
Education must contribute a fair share to this
program. This is a matter of safety for the
children that use these playgrounds.
24/36
DOE
Provide, expand, or
CB 10 suffers from a lack of Early Learn Centers
enhance funding for
within our District.
Child Care and Head
Start programs
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 10
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
Quality of Life
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
New York City's only casino is located in our precinct. Over 10 million people visit it annually and that number is growing. Other locations in the city with similar high numbers of visitors are served with more officers than we are in the view of our residents. The casino facility is expanding. The ambient population our community experiences dictates that additional resources continue to be provided to the 106 Precinct. Our police precinct has no parking facility. One is needed. Additional upgrades are needed to the stationhouse building. Our district is adjacent to JFK International Airport. There are more than 300 acres of federal parkland within our district that are directly under flight paths. The Buckeye Pipeline that carries jet fuel to the airport runs through our district. As indicated above, the Resorts World Casino attracts large numbers of people on a daily basis. Much of the trucking carrying cargo to and from the airport traverses through our community. There is a need to provide more resources that better protect people and the critical infrastructure from potential terrorist attacks. Additional cameras in our are are desired by our residents and, in the view of the Board, will serve to better protect people and aid in investigative activities.
Needs for Emergency Services
Our growing population and the high number of illegal residential units created in cellars and attics point to a need for more emergency services and more/expanded educational programs. Close to half of our residents are foreign- born and some are unaware of basic safety practices common in the U.S. There is an increasing demand for fire services and our fire houses need upgrading of buildings and equipment.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
7/30
NYPD
Provide surveillance
Provide additional ARGUS surveillance cameras.
cameras
18/30
NYPD
Renovate or
Build 106th Precinct Parking lot. Lack of parking
upgrade existing
space in the perimeter of the 106th Precinct
precinct houses
arouses residents' ire and blocks trucks and
other larger vehicles like fire engines from
readily navigating the streets near the Precinct.
The precinct block abuts Liberty Ave. which is a
congested corridor. Lack of off street parking
exacerbates congestion.
22/30
FDNY
Other FDNY facilities
Purchase of generators.
and equipment
requests (Capital)
25/30
FDNY
Rehabilitate or
Upgrade firehouse buildings. Many of the
renovate existing
firehouses are old buildings that need upgrades
fire houses or EMS
such as new roofs, apparatus, floor
stations
replacements, waterproofing, pointing,
electrical upgrades as well as new kitchens and
bathrooms.
27/30
NYPD
Renovate or
Support Capital improvements at the Precinct
upgrade existing
level. Many of the Police Department's facilities
precinct houses
are old buildings that need upgrades regularly.
We request facility upgrades at the 106 Pct.
28/30
FDNY
Other FDNY facilities
These ambulances are designed with lifts and
and equipment
special wheel chairs to be used for individuals
requests (Capital)
over 500 lbs.
29/30
FDNY
Other FDNY facilities
To be used for disasters to shelter and treat
and equipment
individuals in one place.
requests (Capital)
30/30
FDNY
Other FDNY facilities
This equipment is used to respond ahead with a
and equipment
liaison to coordinate.
requests (Capital)
CS
NYPD
Renovate or
Upgrade locker rooms
upgrade existing
precinct houses
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/36
NYPD
Assign additional
Assign additional personnel to the 106th Police
uniformed officers
Precinct for all patrol services.
11/36
FDNY
Provide more
Request more funding for EMS & Firefighting
firefighters or EMS
classes.
workers
12/36
FDNY
Expand funding for
Support for smoke CO detectors/batteries. To
fire prevention and
ensure protection for senior citizens and
life safety initiatives
residents.
14/36
NYPD
Other NYPD staff
Request additional resources for civilians and
resources requests
larger class. To insure adequate levels of service.
23/36
FDNY
Expand funding for
Support mobile CPR unit. With additional
fire prevention and
funding FDNY can produce instructional DVDs in
life safety initiatives
multiple languages, increase their community
outreach and conduct more classes throughout
all 5 boroughs especially on the weekends.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 10
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Protective Infrastructure (sea walls, flood walls, etc.)
A third of our District was severely flooded during Sandy. Permanent repairs are needed at the treatment plant serving our Lindenwood area to prevent further flooding from rain events. Resiliency projects to provide our residential and commercial areas protection from tidal storm surges must be advanced. Tide gates at the mouths of Shellbank and Hawtree Basins are desired by our residents and would provide needed neighborhood protection.
Improvements to existing bulkheads on city-owned properties and construction of bulkheads on city-owned properties where there are none are needed and would improve neighborhood protection from tidal flooding that comes from those 2 waterways.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
There are still areas within Community Board 10 not served by sanitary sewers as well as areas not served by storm sewers. There are numerous ponding conditions throughout the district for which solutions must be found. Our residents complain regularly of clogged and non-functioning catch basins. All catch basins in our Sandy zone need to be fully inspected, repaired if necessary, and cleaned on a far more regular basis. Prior to the onset of hurricane season each year and at any time when major coastal flooding is predicted it is imperative that all catch basins in our district's Sandy zone be cleaned.
Needs for Sanitation Services
There are numerous dump out sites with CB10. They need to be cleaned more frequently. There is a need for additional mechanical broom service without requiring implementation of alternate street parking in our residential areas. Our commercial strips need additional basket services, particularly on Liberty Avenue which has a high pedestrian volume and residential uses above the stores. There is a need for the Bergen Landing DSNY facility to serve only equipment and personnel serving CB10. There is also a need for daily 4-12 pickup at every school in which there is food service.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
3/36
DEP
Inspect sanitary
Provide ongoing inspection and maintenance of
sewer on specific
sewers and catch basins.To assure that flooding
street segment and
of the magnitude that engulfed the community
repair or replace as
board area recently does not occur again, it is
needed (Expense)
essential that ongoing inspection and
maintenance of sewers and catch basins occur
on a far more regular basis.
5/36
DSNY
Increase cleaning of
Additional support for increased MLP's
dump-out/drop-off
(Motorized Litter Patrol) for bi-weekly cleaning
locations
of Dump Out Sites . Once a week cleaning is
inadequate.
10/36
DSNY
Other cleaning
Request for JTP workers for cleaning
requests
19/36
DSNY
Other garbage
Remove two Districts (CDs 8 and 12) from the
collection and
Bergen Landing facility. The overcrowded facility
recycling requests
adversely impacts the adjacent residential
community. Trucks parked/stored outside
generate foul odors.
20/36
DSNY
Other cleaning
Request for mechanical broom for Community
requests
Board 10 for daily basis, 6 days a week, Monday
through Saturday at metered areas. Needed to
maintain adequate levels of street cleanliness
throughout Community Board 10.
22/36
DSNY
Provide more
Additional basket trucks to be assigned to the
frequent garbage or
commercial districts within Community Board
recycling pick-up
10 for seven days a week on a permanent basis.
A basket truck is needed for daily pick-ups on
commercial strips where there is a very large
pedestrian population and baskets overflow
daily.
29/36
DSNY
Provide or expand
Continued support for sustainability programs.
NYC organics
With additional funding DSNY can increase their
collection program
community outreach.
36/36 DSNY Provide more on-
street trash cans and recycling containers
request purchase of high-end litter baskets. The high-end little baskets are designed for easiler use and maintenance to assure the cleanliness of the community.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 10
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
Most of the complaints to DOB by residents in all parts of our district relate to illegal conversions and un-permitted construction. There are numerous indications of vacant bank-owned properties in disrepair within our district due to foreclosure crisis. The number of untended, vacant homes has now increased due to the impact of Superstorm Sandy on our area. There is a continuing need for the city to develop an enforceable policy requiring owners of such properties to promptly secure them and provide for ongoing maintenance. Identifying who are the actual owners of such properties continues to be problematic and it is often difficult for our staff to do so in a timely manner. It is also difficult to contact these owners after they have been identified.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Studies related to increasing resiliency for homes and businesses in our Sandy zone need to be completed and programs need to be developed to offset the costs of resiliency improvements for homeowners and business owners.
Needs for Housing
There is a need for additional personnel to support enforcement efforts.
Needs for Economic Development
Economic development services are needed to assist businesses on our local commercial strips. This is especially needed on our Crossbay Blvd. retail strip in Howard Beach where virtually every business suffered economic loss due to Superstorm Sandy. Additional services are also needed on our Rockaway Blvd. and Liberty Avenue commercial strips.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
27/36 SBS Other expense commercial district revitalization requests
Continue funding neighborhood business development programs and provide support for increased revitalization efforts on all commercial/retail strips within CB10.
TRANSPORTATION
Queens Community Board 10
image
M ost Important Issue Related to Transportation and Mobility
Other
Traffic congestion and roadway maintenance
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
There is a need for expanded roadway maintenance, additional staffing at DOT to address ever-increasing deterioration of infrastructure, and reconstruction of streets and roadways in our district. There is a need to harden storm surge protection in our Sandy zone at all points where city roadways abut parkland at our shoreline and at all points where city street stub ends abut waterways. There is a need for expanded bus service without reducing roadway lanes available for other vehicles or available on-street parking. There is a need to not remove any of the existing turning lanes on Crossbay Blvd. south of Rockaway Blvd. There is a need to reconfigure 3 locations where merging traffic is problematic.
Needs for Transit Services
There is a need to provide additional bus service without reducing available traffic lanes for other vehicles. Our residents are expressing this concern regarding plans to provide SBS service. Many of our residents have expressed opposition to plans presented to them for SBS service on the Crossbay Blvd./Woodhaven Blvd. corridor as well as intense dissatisfaction with the result occurring where implementation has taken place.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
2/30
DOT
Roadway
Grade, pave etc. 104th Street from Russell
104 Street
maintenance (i.e.
Street to 165 Avenue. Roadway in deteriorating
Russell Street
pothole repair,
condition and may have been underminded as a
165 Avenue
resurfacing, trench
result of Hurricane Sandy. This is the only north-
restoration, etc.)
south roadway servicing the Hamilton Beach
community.
3/30
DOT
Repair or build new
Harden coastal protection including bulkheads
seawalls or
where parkland abuts city streets and all other
bulkheads
roadway stub ends.
4/30
DOT
Roadway
Continue support for roadway maintenance for
maintenance (i.e.
entire CB 10 area.
pothole repair,
resurfacing, trench
restoration, etc.)
5/30
DOT
Repair or construct
Continue support for sidewalk repair for entire
new curbs or
CB10 area.
pedestrian ramps
6/30
DOT
Reconstruct streets
Reconstruct Queens portion of Jewel Street
Area, including sewers together with substantial
roadway and water main replacement. Needed
to eliminate severe flooding conditions. Grade
changes must be such that the impact upon the
residents will be minimal.
11/30
DOT
Reconstruct streets
A full reconstruction of Lincoln Street and 132nd
Lincoln Street
Street between 116th Avenue and Foch Blvd. is
& 132nd St.
needed to bring the two streets up to current
116th Avenue
NYC DOT standards, including building out the
Foch Blvd.
grassy space as a proper sidewalk. The roadbed
between Foch Blvd. and 116th Ave. is flat
without proper grading for water drainage.
Drainage needs to be studied and improved. A
concrete base, if missing is needed to provide
proper structures to the street. The curb reveals
are substandard and the catch basins need to
be reviewed. A catch basin in the grassy area
needs to be relocated as well. The local
community board is requesting a sidewalk
extension into the overgrown grassy space at
the intersection of 132nd Street and Lincoln
Street.
14/30
DOT
Roadway
Support trench restoration in Community Board
maintenance (i.e.
10.
pothole repair,
resurfacing, trench
restoration, etc.)
16/30
DOT
Repair or construct
Continued support for curb maintenance for
new curbs or
entire CB10 area.
pedestrian ramps
19/30
DOT
Reconstruct streets
Request Street Reconstruction of 130th Street
Between 107 & 109 Avenues Including Hawtree
Creek Road from 109 Street to 111 Avenue and
All Ancillary Street Work. To eliminate severe
flooding conditions and mondify the grade so
that the impact upon the streets will be
minimal.
23/30
DOT
Reconstruct streets
Reconfigure the merge from the southbound
Van Wyck
Van Wyck Expressway into North Conduit
Expressway
Avenue and onto the Belt Parkway westbound
North
on that property which is City Owned. A very
Conduit Ave
hazardous situation exists for motorists exiting
Belt Parkway
the Van Wyck Expressway Southbound. In order
to enter the Belt Parkway Westbound, they have
to merge across traffic lanes on North Conduit
Avenue in a short distance.
24/30
DOT
Other
Reconfigure Cohancy Street exit of the
North
transportation
westbound Belt Parkway. A very dangerous
Conduit Belt
infrastructure
situation exists for motorists who need to merge
Pkwy
requests
across traffic to the right on North Conduit
Cohancy St
Avenue in order to access Albert Road or Cross
Bay Boulevard. There is limited sight distance
and roadway distance for drivers to maneuver
their vehicles safely to the right.
26/30
DOT
Reconstruct streets
Reconstruct Linden Blvd./South Conduit Avenue
Linden Blvd
Merge. Added signalization has alleviated
South
existing conditions however increasing traffic
Conduit Ave
and the construction of a new shopping center
in the immediate vicinity exacerbates
conditions, further improvements are needed
CS
DOT
Reconstruct streets
Grade, pave etc. 94th Street area ( The Next
Phase). Reconstruct streets bounded by
Rockaway Boulevard on the north, Hawtree Ave
on the east, North Conduit Ave on the south and
Cross Bay Boulevard on the west in Ozone Park.
Serious flooding and drainage problems are
causing safety and health hazards. In the winter,
water freezes and buses and cars must go up
and down one way streets and jump curbs in
order to pass. (next phase).
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
9/36 DOT Other expense
traffic improvements requests
Support for pothole repair crew/arterial maintenance. Innumerable potholes and large street depressions are causing hazardous roadway conditions for the motorist and pedestrian and must be addressed.
image
26/36 DOT Other expense
traffic improvements requests
Support Safe Streets for Seniors program. With additional funding, DOT can increase their community outreach
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 10
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
Park access and forestry services
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The area north of Rockaway Blvd. within CB10 is our most densely populated area. The only parkland in that section of the district are at either end geographically which leaves a large segment of our population with limited access. Our Howard Beach area has a large older adult population but is served by only two joint operated school playgrounds which do not meet their recreational needs. A recreation center is desirable to better provide service to our residents. Superstorm Sandy damaged and destroyed much of our tree canopy. Forestry services must be expanded.
Needs for Cultural Services
Cultural programming is desirable. However, there are limited sites available other than schools. Therefore, cultural programs within our schools should be expanded.
Needs for Library Services
Library services are desired. CB10 supports the QBPL requests for new and renovated facilities and expanded service hours and programming. Due to lack of public transportation to the nearest branch library there is a need to construct a small library to meet the needs of our Hamilton Beach community. Within our Howard Beach area our Hamilton Beach community has the highest percentage of youth, and walking to the Howard Beach branch is difficult.
Needs for Community Boards
There is a need to permanently base-line the budgets of CBs. In local communities the services, outreach, and opportunities for public discussion we provide are needed. Our budgets need to be excluded whenever “across the board cuts” are initiated. This exclusion from cuts should be offset by the fact that our work is carried out not only with city budget dollars but with the contribution of pro-bono service our members provide. Our Chairpersons serve as agency heads. Although unsalaried, chairpersons perform numerous functions. They must attend numerous meetings within and outside of Board boundaries. Agency parking permits are needed for both District Managers and Chairpersons. More detailed information is still required as to what action was taken by agencies regarding the complaints made to 311. All Community Boards should be provided with lists, at least on a weekly basis, of all complaints made to 311 within the district and the agency response to each. Many times complaints involve more than one agency to solve the issue. Having such lists readily provided without having to go to the Open Data Portal to filter and sort out complaints would be helpful.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation Location
9/30
DPR
Reconstruct or
Reconstruction of P.O. Edward Byrne Park.
upgrade a park or
Ballfield and playground deteriorating and in
amenity (i.e.
dire need of repair.
playground, outdoor
athletic field)
10/30
DPR
Provide a new or
Comfort Station needed at P.O. Edward Byrne
expanded park or
Park as there is no facility.
amenity (i.e.
playground, outdoor
athletic field)
12/30
DPR
Other park
Funding for this program will help renovate park
maintenance and
sites with persistent paved surface, sidewalks,
safety requests
fencing and other capital repair needs.
15/30
QL
Create a new, or
Construct a new library in Hamilton Beach. The
renovate or upgrade
community has approximately 320 homes with
an existing public
an estimated 500 to 600 school age children.
library
The nearest branch is located at 156th Avenue
and 92nd Street which is inconvenient and a
hardship for those using public transportation.
20/30
DPR
Other requests for
Construct Parks Department recreation center
park, building, or
within our district. There is no recreation center
access
located in southwest Queens. Such a center
improvements
would meet some of recreational needs of our
youth and senior populations year-round. There
is no pool in southwest Queens.
21/30
DPR
Other requests for
Support Forest Park Greenhouse and contract
park, building, or
staffing. Plants grown in this facility support
access
Parks and public spaces in Community Board 10.
improvements
CS
DPR
Reconstruct or
Upgrade playground for Judge Park
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Renovation of P.O. Nicholas DeMutiis
upgrade a park or
Park.Playground deteriorating and in need of
amenity (i.e.
dire repair.
playground, outdoor
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/36
DPR
Other park
Additional support for Parks personnel to better
maintenance and
address forestry services.
safety requests
4/36
DPR
Other street trees
Support for DPR contracts related to
and forestry
maintenance of street trees
services requests
6/36
DPR
Other park
Assign Park Staff to Reconstructed Parks &
maintenance and
Jointly Operated Parks/Playgrounds. In order to
safety requests
protect the large capital dollar expenditure, it is
essential to assign park staff to each
reconstructed facility.
7/36
DPR
Other park
Additional personnel to cut overgrown weeds
maintenance and
along primary and secondary roadways.
safety requests
Necessary so that the visibility of the motorist is
not obscured.
8/36
DPR
Other park
Support for maintenance personnel for Park
maintenance and
maintained Greenstreets and malls.
safety requests
13/36
DPR
Other park
Funding for this program will provide staffing to
maintenance and
maintain park landscapes, gardens, lawns and
safety requests
other horticultural amenities.
15/36
DPR
New equipment for
For daily Park maintenance
maintenance
(Expense)
16/36
DPR
Other park
Provide an additional mobile crew. An
maintenance and
additional mobile crew of 3 PSWs and 3 CSAs,
safety requests
during the summer, would permit the level and
quality of maintenance necessary for the many
parks and ball fields widely dispersed within the
community. Need 1 PSW year-round plus 1 CSA
summer for Tudor Park and 102nd St. and
Liberty Avenue Park. PS 232 and Judge
Memorial park have a PSW in place and need a
CSA for summer where no comfort
station/maintenance structure exists. Someone
should be assigned for a few hours daily.
30/36 DPR Enhance park safety
through design interventions, e.g. better lighting (Expense)
Increase Height of Fencing at Tennis Courts from 10 to 15 ft. at P.O. Edward Byrne Park, North Conduit Avenue between 131st and 133rd Streets in order to prevent tennis balls from going over existing fence and startling motorists or causing crashes.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority Agency Request Explanation Location
image
13/30 Other Other capital budget
request
Correct drainage problem to alleviate street flooding. Correct drainage problem on 125th, 126th, 127th Streets between Rockaway Blvd. and North Conduit Avenue, South Ozone Park to alleviate street flooding.
image
17/30 Other Other capital budget
request
Construct a sanitary sewer from the outlet of the existing sewer at 160th Avenue and 102nd Street, etc. A sanitary sewer is needed in the remaining area not served starting from the outlet of the existing sewer on 160th Avenue and 102nd Street, going east and west of 102nd Street between Russell Street and 160th Avenue.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
17/36
Other
Other expense
Our goal is to have a permanent 5 day a week
budget request
site and staffing in Community District 10 Q to
serve as a single point of entry within the
community
21/36
Other
Other expense
With additional funding DSNY can increase their
budget request
community service.
28/36
Other
Other expense
Support for arterial maintenance. Arterial
budget request
Highways within CB 10 are large and need
ongoing maintenance.
32/36
Other
Other expense
Support for more staff examiners, clerical staff,
budget request
record scanning staff and inspectors for the
Department of Buildings. To insure that the
agency resources are sufficient to address illegal
conversions, illegal construction, and all other
DOB responsibilities.
33/36
Other
Other expense
Request funding for additional DOT engineering
budget request
and planning staff to ensure that the agency
resources are sufficient to fulfill agency mission
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/30
SCA
Provide a new or
Within Community District 10's area, serious
expand an existing
overcrowding has created a desperate need for
elementary school
additional classrooms in new schools. Expansion
of preK programs add to the need for additional
school buildings and seats.
2/30
DOT
Roadway
Grade, pave etc. 104th Street from Russell
104 Street
maintenance (i.e.
Street to 165 Avenue. Roadway in deteriorating
Russell Street
pothole repair,
condition and may have been underminded as a
165 Avenue
resurfacing, trench
result of Hurricane Sandy. This is the only north-
restoration, etc.)
south roadway servicing the Hamilton Beach
community.
3/30
DOT
Repair or build new
Harden coastal protection including bulkheads
seawalls or
where parkland abuts city streets and all other
bulkheads
roadway stub ends.
4/30
DOT
Roadway
Continue support for roadway maintenance for
maintenance (i.e.
entire CB 10 area.
pothole repair,
resurfacing, trench
restoration, etc.)
5/30
DOT
Repair or construct
Continue support for sidewalk repair for entire
new curbs or
CB10 area.
pedestrian ramps
6/30
DOT
Reconstruct streets
Reconstruct Queens portion of Jewel Street
Area, including sewers together with substantial
roadway and water main replacement. Needed
to eliminate severe flooding conditions. Grade
changes must be such that the impact upon the
residents will be minimal.
7/30
NYPD
Provide surveillance
Provide additional ARGUS surveillance cameras.
cameras
8/30
DFTA
Create a new senior
Request funds to be made available to build
center or other
new senior centers. Senior population continues
facility for seniors
to grow and additional services are needed.
9/30
DPR
Reconstruct or
Reconstruction of P.O. Edward Byrne Park.
upgrade a park or
Ballfield and playground deteriorating and in
amenity (i.e.
dire need of repair.
playground, outdoor
athletic field)
10/30
DPR
Provide a new or
Comfort Station needed at P.O. Edward Byrne
expanded park or
Park as there is no facility.
amenity (i.e.
playground, outdoor
athletic field)
11/30
DOT
Reconstruct streets
A full reconstruction of Lincoln Street and 132nd
Lincoln Street
Street between 116th Avenue and Foch Blvd. is
& 132nd St.
needed to bring the two streets up to current
116th Avenue
NYC DOT standards, including building out the
Foch Blvd.
grassy space as a proper sidewalk. The roadbed
between Foch Blvd. and 116th Ave. is flat
without proper grading for water drainage.
Drainage needs to be studied and improved. A
concrete base, if missing is needed to provide
proper structures to the street. The curb reveals
are substandard and the catch basins need to
be reviewed. A catch basin in the grassy area
needs to be relocated as well. The local
community board is requesting a sidewalk
extension into the overgrown grassy space at
the intersection of 132nd Street and Lincoln
Street.
12/30
DPR
Other park
Funding for this program will help renovate park
maintenance and
sites with persistent paved surface, sidewalks,
safety requests
fencing and other capital repair needs.
13/30
Other
Other capital budget
Correct drainage problem to alleviate street
request
flooding. Correct drainage problem on 125th,
126th, 127th Streets between Rockaway Blvd.
and North Conduit Avenue, South Ozone Park to
alleviate street flooding.
14/30
DOT
Roadway
Support trench restoration in Community Board
maintenance (i.e.
10.
pothole repair,
resurfacing, trench
restoration, etc.)
15/30
QL
Create a new, or
Construct a new library in Hamilton Beach. The
renovate or upgrade
community has approximately 320 homes with
an existing public
an estimated 500 to 600 school age children.
library
The nearest branch is located at 156th Avenue
and 92nd Street which is inconvenient and a
hardship for those using public transportation.
16/30
DOT
Repair or construct new curbs or pedestrian ramps
Continued support for curb maintenance for entire CB10 area.
17/30
Other
Other capital budget
Construct a sanitary sewer from the outlet of
request
the existing sewer at 160th Avenue and 102nd
Street, etc. A sanitary sewer is needed in the
remaining area not served starting from the
outlet of the existing sewer on 160th Avenue
and 102nd Street, going east and west of 102nd
Street between Russell Street and 160th
Avenue.
18/30
NYPD
Renovate or
Build 106th Precinct Parking lot. Lack of parking
upgrade existing
space in the perimeter of the 106th Precinct
precinct houses
arouses residents' ire and blocks trucks and
other larger vehicles like fire engines from
readily navigating the streets near the Precinct.
The precinct block abuts Liberty Ave. which is a
congested corridor. Lack of off street parking
exacerbates congestion.
19/30
DOT
Reconstruct streets
Request Street Reconstruction of 130th Street
Between 107 & 109 Avenues Including Hawtree
Creek Road from 109 Street to 111 Avenue and
All Ancillary Street Work. To eliminate severe
flooding conditions and mondify the grade so
that the impact upon the streets will be
minimal.
20/30
DPR
Other requests for
Construct Parks Department recreation center
park, building, or
within our district. There is no recreation center
access
located in southwest Queens. Such a center
improvements
would meet some of recreational needs of our
youth and senior populations year-round. There
is no pool in southwest Queens.
21/30
DPR
Other requests for
Support Forest Park Greenhouse and contract
park, building, or
staffing. Plants grown in this facility support
access
Parks and public spaces in Community Board 10.
improvements
22/30
FDNY
Other FDNY facilities
Purchase of generators.
and equipment
requests (Capital)
23/30
DOT
Reconstruct streets
Reconfigure the merge from the southbound
Van Wyck
Van Wyck Expressway into North Conduit
Expressway
Avenue and onto the Belt Parkway westbound
North
on that property which is City Owned. A very
Conduit Ave
hazardous situation exists for motorists exiting
Belt Parkway
the Van Wyck Expressway Southbound. In order
to enter the Belt Parkway Westbound, they have
to merge across traffic lanes on North Conduit
Avenue in a short distance.
24/30
DOT
Other
Reconfigure Cohancy Street exit of the
North
transportation
westbound Belt Parkway. A very dangerous
Conduit Belt
infrastructure
situation exists for motorists who need to merge
Pkwy
requests
across traffic to the right on North Conduit
Cohancy St
Avenue in order to access Albert Road or Cross
Bay Boulevard. There is limited sight distance
and roadway distance for drivers to maneuver
their vehicles safely to the right.
25/30
FDNY
Rehabilitate or
Upgrade firehouse buildings. Many of the
renovate existing
firehouses are old buildings that need upgrades
fire houses or EMS
such as new roofs, apparatus, floor
stations
replacements, waterproofing, pointing,
electrical upgrades as well as new kitchens and
bathrooms.
26/30
DOT
Reconstruct streets
Reconstruct Linden Blvd./South Conduit Avenue
Linden Blvd
Merge. Added signalization has alleviated
South
existing conditions however increasing traffic
Conduit Ave
and the construction of a new shopping center
in the immediate vicinity exacerbates
conditions, further improvements are needed
27/30
NYPD
Renovate or
Support Capital improvements at the Precinct
upgrade existing
level. Many of the Police Department's facilities
precinct houses
are old buildings that need upgrades regularly.
We request facility upgrades at the 106 Pct.
28/30
FDNY
Other FDNY facilities
These ambulances are designed with lifts and
and equipment
special wheel chairs to be used for individuals
requests (Capital)
over 500 lbs.
29/30
FDNY
Other FDNY facilities
To be used for disasters to shelter and treat
and equipment
individuals in one place.
requests (Capital)
30/30
FDNY
Other FDNY facilities
This equipment is used to respond ahead with a
and equipment
liaison to coordinate.
requests (Capital)
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Upgrade playground for Judge Park
image
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Renovation of P.O. Nicholas DeMutiis Park.Playground deteriorating and in need of dire repair.
image
CS DOT Reconstruct streets Grade, pave etc. 94th Street area ( The Next
Phase). Reconstruct streets bounded by Rockaway Boulevard on the north, Hawtree Ave on the east, North Conduit Ave on the south and Cross Bay Boulevard on the west in Ozone Park. Serious flooding and drainage problems are causing safety and health hazards. In the winter, water freezes and buses and cars must go up and down one way streets and jump curbs in order to pass. (next phase).
image
CS NYPD Renovate or upgrade existing precinct houses
Upgrade locker rooms
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/36
NYPD
Assign additional
Assign additional personnel to the 106th Police
uniformed officers
Precinct for all patrol services.
2/36
DPR
Other park
Additional support for Parks personnel to better
maintenance and
address forestry services.
safety requests
3/36
DEP
Inspect sanitary
Provide ongoing inspection and maintenance of
sewer on specific
sewers and catch basins.To assure that flooding
street segment and
of the magnitude that engulfed the community
repair or replace as
board area recently does not occur again, it is
needed (Expense)
essential that ongoing inspection and
maintenance of sewers and catch basins occur
on a far more regular basis.
4/36
DPR
Other street trees
Support for DPR contracts related to
and forestry
maintenance of street trees
services requests
5/36
DSNY
Increase cleaning of
Additional support for increased MLP's
dump-out/drop-off
(Motorized Litter Patrol) for bi-weekly cleaning
locations
of Dump Out Sites . Once a week cleaning is
inadequate.
6/36
DPR
Other park
Assign Park Staff to Reconstructed Parks &
maintenance and
Jointly Operated Parks/Playgrounds. In order to
safety requests
protect the large capital dollar expenditure, it is
essential to assign park staff to each
reconstructed facility.
7/36
DPR
Other park
Additional personnel to cut overgrown weeds
maintenance and
along primary and secondary roadways.
safety requests
Necessary so that the visibility of the motorist is
not obscured.
8/36
DPR
Other park
Support for maintenance personnel for Park
maintenance and
maintained Greenstreets and malls.
safety requests
9/36
DOT
Other expense
Support for pothole repair crew/arterial
traffic
maintenance. Innumerable potholes and large
improvements
street depressions are causing hazardous
requests
roadway conditions for the motorist and
pedestrian and must be addressed.
10/36
DSNY
Other cleaning requests
Request for JTP workers for cleaning
11/36
FDNY
Provide more
Request more funding for EMS & Firefighting
firefighters or EMS
classes.
workers
12/36
FDNY
Expand funding for
Support for smoke CO detectors/batteries. To
fire prevention and
ensure protection for senior citizens and
life safety initiatives
residents.
13/36
DPR
Other park
Funding for this program will provide staffing to
maintenance and
maintain park landscapes, gardens, lawns and
safety requests
other horticultural amenities.
14/36
NYPD
Other NYPD staff
Request additional resources for civilians and
resources requests
larger class. To insure adequate levels of service.
15/36
DPR
New equipment for
For daily Park maintenance
maintenance
(Expense)
16/36
DPR
Other park
Provide an additional mobile crew. An
maintenance and
additional mobile crew of 3 PSWs and 3 CSAs,
safety requests
during the summer, would permit the level and
quality of maintenance necessary for the many
parks and ball fields widely dispersed within the
community. Need 1 PSW year-round plus 1 CSA
summer for Tudor Park and 102nd St. and
Liberty Avenue Park. PS 232 and Judge
Memorial park have a PSW in place and need a
CSA for summer where no comfort
station/maintenance structure exists. Someone
should be assigned for a few hours daily.
17/36
Other
Other expense
Our goal is to have a permanent 5 day a week
budget request
site and staffing in Community District 10 Q to
serve as a single point of entry within the
community
18/36
DOE
Other educational
Establish a contribution by the Department of
programs requests
Education for Joint Operated Playgrounds. Joint
operated playgrounds are presently
maintained/operated solely with Parks
Department personnel and budget. Due to
severe cutbacks, the responsibility must be
shared as joint operated implies. Dept. of
Education must contribute a fair share to this
program. This is a matter of safety for the
children that use these playgrounds.
19/36
DSNY
Other garbage
Remove two Districts (CDs 8 and 12) from the
collection and
Bergen Landing facility. The overcrowded facility
recycling requests
adversely impacts the adjacent residential
community. Trucks parked/stored outside
generate foul odors.
20/36
DSNY
Other cleaning
Request for mechanical broom for Community
requests
Board 10 for daily basis, 6 days a week, Monday
through Saturday at metered areas. Needed to
maintain adequate levels of street cleanliness
throughout Community Board 10.
21/36
Other
Other expense
With additional funding DSNY can increase their
budget request
community service.
22/36
DSNY
Provide more
Additional basket trucks to be assigned to the
frequent garbage or
commercial districts within Community Board
recycling pick-up
10 for seven days a week on a permanent basis.
A basket truck is needed for daily pick-ups on
commercial strips where there is a very large
pedestrian population and baskets overflow
daily.
23/36
FDNY
Expand funding for
Support mobile CPR unit. With additional
fire prevention and
funding FDNY can produce instructional DVDs in
life safety initiatives
multiple languages, increase their community
outreach and conduct more classes throughout
all 5 boroughs especially on the weekends.
24/36
DOE
Provide, expand, or
CB 10 suffers from a lack of Early Learn Centers
enhance funding for
within our District.
Child Care and Head
Start programs
25/36
DFTA
Increase case
Support case management, increased allocation
management
for meals, funding for elder abuse programs,
capacity
legal services for the elderly and to improve
transportation. The request is to ensure agency
resources are sufficient to fulfill agency mission.
26/36
DOT
Other expense
Support Safe Streets for Seniors program. With
traffic
additional funding, DOT can increase their
improvements
community outreach
requests
27/36
SBS
Other expense
Continue funding neighborhood business
commercial district
development programs and provide support for
revitalization
increased revitalization efforts on all
requests
commercial/retail strips within CB10.
28/36
Other
Other expense budget request
Support for arterial maintenance. Arterial Highways within CB 10 are large and need ongoing maintenance.
29/36
DSNY
Provide or expand
Continued support for sustainability programs.
NYC organics
With additional funding DSNY can increase their
collection program
community outreach.
30/36
DPR
Enhance park safety
Increase Height of Fencing at Tennis Courts from
through design
10 to 15 ft. at P.O. Edward Byrne Park, North
interventions, e.g.
Conduit Avenue between 131st and 133rd
better lighting
Streets in order to prevent tennis balls from
(Expense)
going over existing fence and startling motorists
or causing crashes.
31/36
DHS
Improve safety at
Support for additional security, recreation and
homeless shelters
added programs. To ensure agency resources
are sufficient to fulfill agency mission
32/36
Other
Other expense
Support for more staff examiners, clerical staff,
budget request
record scanning staff and inspectors for the
Department of Buildings. To insure that the
agency resources are sufficient to address illegal
conversions, illegal construction, and all other
DOB responsibilities.
33/36
Other
Other expense
Request funding for additional DOT engineering
budget request
and planning staff to ensure that the agency
resources are sufficient to fulfill agency mission
34/36
DOHMH
Create or promote
Support for mental health services.
programs to de-
stigmatize mental
health problems
and encourage
treatment
35/36
HRA
Provide, expand, or
Support SNAP Outreach Campaign
enhance food
assistance, such as
Food Stamps / SNAP
36/36
DSNY
Provide more on-
request purchase of high-end litter baskets. The
street trash cans
high-end little baskets are designed for easiler
and recycling
use and maintenance to assure the cleanliness
containers
of the community.

