- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 10 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1NX5tz_Ewkfhw-nZ9tPHImNFpMUpRNiUa/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1NX5tz_Ewkfhw-nZ9tPHImNFpMUpRNiUa/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
10
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 10
image
Address: 3165 E. Tremont Avenue Phone: (718) 892-1161
Email: bx10@cb.nyc.gov
Website: www.nyc.gov/bronxcb10
Chair: Joseph Russo District Manager: Matthew Cruz
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Bronx Community Board 10 is one of the largest geographic Community Board Districts in the borough of The Bronx. The Board serves the communities of Pelham Bay, City Island, Country Club, Throggs Neck, Co-op City, Westchester Square and Zerega. It features one of the most diverse housing categories in the City. It primarily consists of 1-3 family homes. However, it is home to the largest housing cooperative in New York State in Co-op City and is home to a sizable public housing stock in that of Middletown Plaza, Throggs Neck Houses and Randall-Balcom Houses. Bronx Community Board 10 is a district surrounded by the following water bodies: Eastchester Bay, Long Island Sound and the East River. These bodies of water highlight the need for storm resiliency measures that will protect our communities from tidal surges that are expected to come from major storms such as Hurricane Sandy. As proper stewards for the Board's service areas, we at Bronx CB 10 took it upon ourselves to conduct an examination of the Board's storm surge defenses. We were ably assisted in this effort by the Bronx Borough President's Office and the Fund for the City of New York, who provided us with an Urban Fellow, who was a graduate student at Pratt Institute, to conduct a comprehensive survey of our shoreline communities and to determine the type of defenses against storm surges that are needed. The research yielded recommendations such as earth berms, rock jetties and sea walls control coastal flooding from the storms. The Board further felt that the storm sewers should be examined as well. High functioning and adequately sized sewers are needed for the water to drain off. The Board is interested in seeing DEP and DOT develop joint projects for these purposes. Bronx Community Board 10 is experiencing population growth in nearly all of its neighborhoods. It is crucial that the City continue to renovate our parks, increase recreational programming for children and seniors, increase school seats, refurbish and maintain our roads and sidewalks, further commit to the livelihood of our small businesses through business improvement district formation and repair our public housing stock so that our most vulnerable are protected. With population growth comes further strains on our public resources such as mass transit. Bronx Community Board 10 residents experience one of the longest subway rides to Manhattan according to New York University. With this in mind, it is crucial for the City of New York to study ways to take advantage of our largely unused waterways for possible ferry service and to find ways to expand bus service throughout all of Co-op City and City Island. Bronx Community Board 10 stands ready to support measures that will go toward enhancing the quality-of-life our residents. The City should take the ensuing priorities as the start of a much larger endeavor to plan the future of Bronx Community Board 10 in a way that enhances quality-of-life and ensures that the Board's service areas are seeing the resources it needs.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 10
image
The three most pressing issues facing this Community Board are:
Quality of life issues (noise, graffiti, petty crime, etc.)
Bronx Community Board 10 chose quality-of-life, resiliency measures and transit as its three most pressing needs. However, senior services, recreational and cultural programming at our parks, cleanliness along our corridors, thriving schools, traffic mitigation and an increased focus on quality-of-life enforcement are issues that many of our residents want the City to continue to focus on going forward. According to the City's Department of City Planning, many of Board 10's residents are aging in place. We ask that the City provide the Board Service Area with more resources through the Department for the Aging for our seniors. Bronx Community Board 10 is home to the largest park in the City of New York. The need for more Parks Enforcement Officers is an annual request. Additionally, Pelham Bay Park needs more staffing to protect its unique horticulture. According to the City's Department of City Planning, Bronx Community Board 10 has one of the higher car-usage rates. We ask that the City (and the State of New York) assist us with extensive traffic mitigation and further resources for the repair and maintenance of our subways as well as examine the feasibility of transit alternatives along our waterfronts. Bronx Community Board 10 is seeing an increase in residential and commercial development. Neighborhood context and identity are items we will discuss with City Planning to ensure that zoning protects our neighborhoods' character. Bronx Community Board 10 is serviced by the 45th Precinct. Because the Board Service Area is bounded by highways, we ask that the City enforce quality-of-life concerns so that our communities are not victims to grand larceny and petty crimes. The 45th Precinct officers are detailed annually to other areas of the borough. Bronx Community Board 10 continues to request that the City provide the Board Service Area with adequate policing resources at all times as the safety of our communities is our top priority. Lastly, Bronx Community Board 10 streets and roadways are constantly flooding during rainstorms. A storm such as Hurricane Sandy will only make matters worse. We ask that the City's Department of Environmental Protection contact the Board to begin studying areas where flooding is constant.
Resiliency measures are needed throughout our waterfront communities.
Traffic
As aforementioned, Community Board 10 remains near the top of community districts in terms of automobile usage and ownership. Traffic congestion has worsened. Roadway maintenance is needed annually. Further traffic controls were requested at specific intersections. In order to mitigate these symptoms, we ask that the City of New York remain steadfast in its approach of providing ferry service in Throggs Neck and continue to lend its support and resources for the proposed MTA Metro North train station in Co-op City.
Trash removal & cleanliness
Community Board 10's population is increasing. We ask that the City of New York initiate a study of our district to ensure we are receiving adequate sanitation resources. Historically, Community Board 10 has ranked near the top in cleanliness in the Bronx. However, our district office has seen an increase in illegal dumping and over-flowing litter basket complaints. Along our highway service roads, illegal dumping is a daily occurrence. It behooves the City of New York to be able to receive video complaints of perpetrators committing this action.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 10
image
M ost Important Issue Related to Health Care and Human Services
Other
Community Board 10 residents, much like other communities throughout the city, suffer from issues stemming from substance abuse. While we sometimes question the location of programs, Community Board 10 remains committed to working with public agencies on addressing this matter. Additionally, mental health services are needed for the increasing homeless population. Community Board 10 notices an increase in homeless persons at our commercial corridors and train stations.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Our Board is served by the Jack D. Weiler Hospital of Montefiore Medical Center and its medical school, the Albert Einstein College of Medicine. We are also served by Jacobi Hospital of NYC Health and Hospitals (NYC H+H). The two hospitals are in close proximity to each other. By contract and custom, the medical school provides physicians to Jacobi Hospital. Both have busy emergency rooms that are used by many residents of our borough. To counteract this, we ask that the City, through the NYC H+H, develop an educational campaign as to the use and drawbacks of emergency service care and when an alternative, such as an urgent care, may be better suited for them.
Needs for Older NYs
According to City Planning, Bronx Community Board 10's is home too a high senior citizen population. Co-op City is a Naturally Occurring Retirement Communnity, or NORC. With this in mind, Bronx Community Board 10 asks that the City, through DFTA and its corresponding senior centers, invest in more case management, educational activities, trips and health promotion for our seniors.
Needs for Homeless
Bronx Community Board 10 is located in the northeast Bronx. Its business services are concentrated in several commercial areas: E. Tremont Avenue, Crosby Avenue, Westchester Square, Bartow Avenue and City Island Avenue. DHS placed a shelter for 95 women and children in a former hotel, on the outskirts of our Board area. It has no laundry facilities on site, so the women must take two buses to reach the nearest laundry mat. There are no cooking facilities (microwaves in the rooms) flouting the requirements of the Comptroller's Memorandum governing Emergency Contracts that states such facilities must be located in rooms where women with children or pregnant women are domiciled. There is anecdotal evidence from the community at large, that the meals offered to the clients at the shelter are unappetizing and that they are often discarded. One of the contractual goals of the shelter operators is to provide the clients with opportunities for job training. employment and enhanced social services.
Bronx Community Board 10 is home to three City of New York-operated shelters. We ask that the City bear in mind that under the Fair Share Criteria, Bronx Community Board 10 has met its requirement.
Needs for Low Income NYs
Many CB 10 residents apply for and receive SNAP Benefits. According to City Planning's Community District Profile, CB 10's unemployment is higher than the City's average while roughly 20% of our residents are seniors. Simply put, SNAP benefits are a lifeline for many residents and we ask that the City to enhance this resource with additional funding. The City of New York should study the feasibility of having a SNAP Center in the confines of CB 10 so that our seniors and low-income families do not have to travel to other parts of the borough.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
19/27 DOHMH Reduce mosquito
populations
Many of the communities in our Board service area are surrounded by water. We ask that the NYC DOHMH work with the Board to form a more targeted approach to mosquito praying.
image
20/27 DHS Expand street
outreach
Bronx Works is a vital resource to our community. The Board Office contacts the agency routinely to service homeless persons. We ask that the City continue to fund this agency.
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 10
image
M ost Important Issue Related to Youth, Education and Child Welfare
Schools and educational facilities (Maintenance)
Community Board 10 is aware that many of its schools need capital improvements. The Board is committed to identifying those needs and submitting requests throughout the fiscal year. Additionally, Community Board 10 remains committed to ensuring every public school has after school programming.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
12/21 SCA Renovate or upgrade a middle or intermediate school
The I.S. 192 Campus located at 650 Hollywood Avenue in Throggs Neck requests additional resources for new air conditioners throughout the campus.
image
21/21 SCA Provide technology
upgrade
Bronx Community Board 10 supports P.S. 304 PTA's request for security cameras throughout the other schools at its location. We also support this request for all of Bronx Community Board 10 public schools.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
5/27
DOE
Other educational
Community Board 10 is one of the community
programs requests
board agencies that promotes the CTE
internship programming. We ask that the City
consider expanding programs to other
industries such as law and real estate.
6/27
DOE
Other educational
Young adult programming is needed in order to
programs requests
combat substance abuse issues and to deter
young people from products like e-cigarettes.
Programming should be operated out of schools
in our community district.
7/27
DOE
Other educational
The P.S. 175 schoolyard should be opened and
programs requests
available to the community after school and on
weekends.
8/27
DYCD
Provide, expand, or
The on-site after school programming in CB 10
enhance after
are the following elementry schools: The Child
school programs for
development Center of the Mosholu Montefiore
elementary school
Community Center at PS 153, the Child
students (grades K-
Development Center of the Mosholu Montefiore
5)
Community Center at PS 160, the Directions For
Our Youth Program at PS 72, the Kips Bay
Program at PS 304, the Kips Bay Program at
Throggs Neck Community Association of NYCHA
, Sports and Arts in Schools Foundation at PS
178 and PS 175, the YMCA Program at PS 14 ,
are excellent and require additional funding.
9/27
DYCD
Provide, expand, or enhance after school programs for middle school students (grades 6-
8)
The on-site after school programming at the following Middle Schools should receive increased funding: The Child Development Center of the Mosholu Montefiore Community Center at the Equality Charter School, Direction for Youth at IS 180 and IS 181, East Side Houses at the (Urban Assembly Academy of Civic Engagement), Kips Bay Boys and Girls Club at MS101X, Sports and Arts In Schools Foundation at Truman HS , Xposure Foundation at Mott Hall School, New York Junior Tennis League at PS 71. The Phipps Community Development Beacon Program at IS 192 Piagentini-Jones School should be fully funded.
16/27
DYCD
Provide, expand, or enhance the Summer Youth Employment Program
We are encouraged by the City's commitment to increase funding for the summer youth employment program. We ask that the City continue to enhance this vital program.
18/27
DOE
Other educational programs requests
CB 10 is in close proximity to Montefiore Hospital, Jacobi Hospital, Albert Einstein College of Medicine and Calvary Hospital. The Board recommends that the City establish a uniquely- specialized high school such as one that pertains to the field health care. An example of this model is the High School for Medical Professions in the borough of Brooklyn.
27/27
DYCD
Provide, expand, or enhance Cornerstone and Beacon programs (all ages, including young adults)
Bronx Community Board 10 asks that the City study the feasibility of a youth center in Co-op City.
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 10
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
The 45th Precinct lost its dedicated drug module. It now shares it with the neighboring 43rd Precinct. With the opioid epidemic, precincts should have its own. We ask that the City's Police Department and Bronx Patrol Borough re-establish a drug module at the 45th Precinct. Additionally, Bronx Community Board 10 is constantly concerned that our district is not receiving the manpower it deserves to address quality-of-life concerns. We ask that the NYPD provide in writing to us why the City feels our precinct has adequate manpower. According to Compstat, through the week of October 14, 2019 to October 20, 2019 the 45th Precinct contains only a single category in negative territory. Each crime category has surpassed its 2018 benchmark.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The entirety of the 45th Precinct is surrounded by highways. We ask that the City give the 45th Precinct its own drug module and continue to enforce quality-of-life issues such as noise. Additionally, we thank the NYPD for establishing the Neighborhood Coordination Officers program this calendar year.
Needs for Emergency Services
Emergency services are crucial components to the livelihood of a community. We ask that the FDNY, along with the NYPD, report to the Board in writing that any location service apparatus being used is accurate. For example, the community of Edgewater Park is often misidentified. The City should work with the Board immediately on this issue.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
CS
NYPD
Other NYPD
The office of the Mayor and the NYPD must
facilities and
remain committed to fully funding the
equipment requests
renovation and sound abatement of Rodman's
(Capital)
Neck. Additionally, additional lighting is needed
along the entrance of the property to increase
visibility.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/27
NYPD
Assign additional
In addition to steady Harbor Patrol throughout
community affairs
the year, a neighborhood coordination officer
officers
program should be established for the Bronx
Harbor Patrol. This will help facilitate
communication between waterfront
communities and the NYPD.
2/27
NYPD
Assign additional
The current amount of Neighborhood
community affairs
Coordination Officers is inadequate since
officers
Community Board 10 is one of the largest
geographic districts in the City. Our current
program has six. We ask that the NYPD assign
at least three (3) additional officers to the
program.
4/27
NYPD
Other NYPD staff
Community Board 10 is largely surrounded by
resources requests
water. We ask that the NYPD provide a
dedicated Harbor Patrol Unit throughout the
year for our community. Currently, there is only
one Harbor Patrol Unit for the borough and is
not adequate.
13/27
NYPD
Other NYPD staff
Establishments along corridors such as East
2877 Barkley
resources requests
Tremont Avenue, Westchester Avenue and
Avenue
Bartow Avenue recieve the bulk of noise
complaints in Community Board 10. We ask
that the City provide the 45th Precinct with
additional sound meters.
17/27 NYPD Provide additional
patrol cars and other vehicles
Equip the agency with large tow trucks and a facility in which impounded trucks can be stored to counteract the plethora of abandoned vehicles along our highway service roads, near parks and in and around our residential communities.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 10
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Protective Infrastructure (sea walls, flood walls, etc.)
Almost all of Bronx Community Board 10 communities are bounded by the East River, Long Island Sound and Eastchester Bay. During Hurricane Sandy several of our communities, most notably City Island and Edgewater Park, were severely damaged. Had the wind not changed course, the damage to our Community Board's waterfront communities would have been devastating. The Board is interested in seeing the protective systems installed that will serve as breaks to storm surges. Additionally, the Board would like to see the sewers assessed to determine if they are sized correctly to handle the very large storm flow that will come onto the land.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Bronx Community Board 10 would like to see a joint DEP/DOT program to survey our areas and install storm breaks like earthen berms and sea walls. If a major hurricane type storm were to hit our Board, we would experience storm surges that would deposit massive amounts of water on land causing massive damage and flooding that would result in stagnant pools of water that will take days to drain, because the sewers are inadequate to meet the increased demands of drainage. Neighborhoods like City Island would experience flooding on streets like Tier, Bay, Fordham, Hawkins, Carroll, Centre, Winter, Early, Pell, Reynolds, Pilot, Marine, Buckley, Horton, Schofield, Rochelle, Beach, Kilroe, Sutherland and Terrace Streets; King Avenue and Fordham Place are inadequately protected. In Edgewater Park, which has a sea wall, 1st, 2nd and 4th Avenue, Pennyfield Avenue and Soundview Drive are vulnerable; Silver Beach, which also has a sea wall, is also prone to flooding. Acorn, Beach, Ceder, Daisy, Elm, Fern, Geranium, and Hazel Streets, Ivy, Jasmine, Edgar, Dare, Casler, Bevy, Alan, Schuyler Places, Indian Terrace, and the campus of SUNY Maritime College, are all prone to flooding. Within Locust Point, Locust Point Avenue, Tierney Place, Longstreet Avenue and Hatting Avenue, the Hammond Cove and Locust Point Marina area, and Calhoun and Schurz Avenues in Throggs Neck will be badly affected, as well as Clarence and Randall Avenues and Country Club.
The end of Lafayette Avenue in Ferry Point and all of Ferry Point Park will be flooded. The Board would like to see that both agencies develop a plan to stop the storm water surges and to provide a sewer system that will be able to handle them.
Needs for Sanitation Services
Bronx Community Board 10 enjoys one of the highest rates of recycling in the City. Co-op City, the largest housing cooperative in the State recycles and processes its own waste and we are still limited to one day a week pick up. For several years, the Board has been requesting an additional day for pickup. We believe that we have proven our commitment to the City's recycling goals and therefore, request another day.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
3/27
DEP
Investigate and
The City should work with state and federal
address a hazardous
partners to conduct water quality testing of
materials complaint
Eastchester Bay.
at a specific
address/location
21/27
DSNY
Provide more on-
Bronx Community Board 10 requests more
street trash cans
receptacles on Westchester Avenue between
and recycling
East Tremont Avenue to Burr Avenue. We also
containers
request more receptacles from East Tremont
Avenue from Bruckner Boulevard to Schurz
Avenue.
23/27
DSNY
Expand disposal
This event is well-attended. Bronx Community
events for
Board 10 request two to three safe disposal
hazardous
events each year.
household waste
24/27
DSNY
Increase
Bronx Community Board 10 supports the City
enforcement of
allocating more resources toward stopping
illegal dumping laws
illegal dumping. The City of New York should
look for ways to accept video when receiving
complaints through 311 as a way to apprehend
perpetrators.
25/27
DSNY
Increase
The City of New York and New York City Council
enforcement of
must look for ways to increase civil penalties for
illegal posting laws
posting signage on utility poles and street light
fixtures.
26/27
DSNY
Increase vacant lot
New York City Department of Transportation is
cleaning
notorious for not cleaning its own property,
including along the highways. We constantly
ask the Department of Sanitation to service
these areas through its Lot Cleaning Unit. We
ask that the City provide more manpower to
DSNY so that it can clean NYCDOT's property or
that a large citywide unit be created within
NYCDOT to service and maintain NYCDOT
property.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 10
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
Community Board 10 is replete with illegal basement apartments and zoning and building code infractions. Both NYC HPD and NYC DOB should be able to inspect complaints under 30 days to address these potential life threatening matters.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
All of CB 10 is in a Lower Growth Management Area. However, we are finding that in R7-1 districts, parking is waived in certain cases when the lot size is too narrow. With the growth in basement apartments, parking is further limited. Strengthening parking requirements is a solution to the multi story buildings that are replacing formerly one and two-family homes. Bronx Community Board 10 asks that the City Planning Department conduct a neighborhood study to assess development trends, strengthening parking requirements and current transportation services.
Needs for Housing
We ask that the City of New York remove any and all lead in the Throggs Neck Houses apartments. We ask that the City provide adequate heat and hot water through the winter months. Bronx Community Board 10 received complaints on both matters. We stand ready to assist in identifying residents that are in danger and how the City can improve their living space in an expeditious manner.
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
14/21 NYCHA Renovate or
upgrade public housing developments
At Throggs Neck Houses, there is dilapidated playground equipment, units that flood and have mold, malfunctioning elevators, broken street sidewalks, broken entrance doors and roofs that are in disrepair from deferred maintenance. NYCHA residents, a third of whom are seniors, need these repairs immediately. The Board asks that the City increase funding to NYCHA's capital plan for these projects.
image
CS EDC Invest in capital projects to improve access to the waterfront
We are pleased that NYC EDC initiated a study for Throggs Neck ferry service. We are in hopes that ferry service in Community Board 10 becomes a reality in 2023.
Expense Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
TRANSPORTATION
Bronx Community Board 10
image
M ost Important Issue Related to Transportation and Mobility
Other
There are many transportation and mobility concerns in Community Board 10. Highway and local street congestion is worsening. Other than Pelham Bay Station, not a single NYCT train stop has an elevator for the mobility-impaired community to use. The Westchester Square station is an ideal location for elevator service from the MTA NYCT. Street lighting is inadequate on Westchester and East Tremont Avenues. We request that the NYC DOT initiate a study of the Westchester Avenue corridor.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The Board seeks several capital reconstruction projects and light surveys.
Needs for Transit Services
Because of a lack of subway network, bus service is crucial to Bronx Community Board 10. In years past, we have requested expanded service in Co-op City and City Island and a long East Tremont Avenue via the BX 40 and BX 42 routes. Bus service, according to many media outlets and think tanks, has slowed in New York City while ridership has decreased. It is crucial we look toward ways to improve bus service and expand in areas where there is no NYCT footprint.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/21
DOT
Reconstruct streets
Community Board 10 requests that the NYC
DOT reconstruct Revere Avenue between Dewey
Avenue and Sampson Avenue due to the
roadway sinking.
4/21
DOT
Reconstruct streets
Middletown Road, in Pelham Bay, is sinking. The
asphalt is cracking in many areas. We ask that
the NYC DOT initiate a study for capital
reconstruction of Middletown Road from
Bruckner Boulevard to Westchester Avenue.
5/21
DOT
Reconstruct streets
Please consider Huntington Avenue between
Miles Avenue and Sampson Avenue for capital
reconstruction.
6/21
DOT
Reconstruct streets
Please consider Sampson Avenue between
Sampson
Calhoun Avenue and Quincy Avenue for capital
Avenue
reconstruction.
Calhoun
Avenue
Quincy
Avenue
7/21
DOT
Reconstruct streets
Please consider Pennyfield Avenue for a full
Pennyfield
capital reconstruction with sidewalks and curbs.
Avenue
Harding
Avenue
Mitchell Place
8/21
DOT
Other
Community Board 10 asks that the NYC DOT
transportation
and NYC EDC initiate a study for ferry service at
infrastructure
Orchard Beach.
requests
9/21
DOT
Other
Community Board 10 fully supports the in-kind
Meagher
transportation
resurfacing of the Meagher Avenue entrance
Avenue
infrastructure
into Edgewater Park. This entrance is used by
requests
hundreds of MTA Buses and has caused wear
and tear.
13/21
DOT
Reconstruct streets
The following streets in the Throggs Neck
section require capital reconstruction: Wenner
Place, Jay Place and Rohr Place.
17/21
DOT
Repair or provide
We request that the NYC DOT initiate a street
Pelham Bay
new street lights
light survey on Westchester Avenue from Castle
Taxpayer
Hill Avenue to Burr Avenue.
Association
18/21 DOT Repair or provide
new street lights
We request that the City provide additional street lights on East Tremont Avenue from Bruckner Boulevard to Schurz Avenue.
Westchester Avenue East Tremont Avenue Castle Hill Avenue
image
19/21 NYCTA Improve
accessibility of transit infrastructure, by providing elevators, escalators, etc.
The Board would like to see the adoption in the MTA Capital Plan of elevator service for Buhre Ave and Westchester Square Stations of the IRT 6.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
11/27
NYCTA
Expand bus service
Several years ago the MTA New York City Transit
frequency or hours
had to reconfigure the bus service within Co-op
of operation
City, because of fiscal constraints. The resultant
situation was that the northern portion of the
development saw service on the BX 26 and BX
28 truncated. A new bus known as the BX 38
was created to link up with the BX 26 and BX 28.
We ask for expanded service along these lines
as well as on the Bx29, BxM7, BxM8, BxM9.
These lines provide are a lifeline to many
commuters in CB 10.
22/27
DOT
Conduct traffic or
We ask that NYCDOT study how to improve
parking studies
parking in Pelham Bay. Specifically, we ask that
the City review if City parking signage may be
removed to accommodate parking. Additionally,
please enforce illegal curb cuts as it removes
vital on-street parking spaces.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 10
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
The NYC Parks Department is grossly underfunded. Bronx Community Board 10 wishes to see area parks repaired and updated. Enhancing the experience at our parks goes a long way toward fostering community development and improving our quality-of-life. Pelham Bay Park is the largest park in New York City. Bronx Community Board 10 requests that the city hire the appropriate amount of staffing in its horticulture unit at Pelham Bay Park, fully invest in the Orchard Beach Pavilion and Bath House. In addition, we ask that the City fully fund the tree and sidewalks program and enhance funding for tree pruning.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Community Board 10 has several playgrounds and parks in desperate need of renovation. We ask that the Parks Department provide cost estimates for each park listed in this statement.
Needs for Cultural Services
No comments
Needs for Library Services
The Westchester Square Library is scheduled for a new building. It is an innovative design that the Board supports and the community welcomes. Funding is in place and the Board looks forward to its construction. The Board expects that the library will be a state of the art facility that will offer innovative and popular programs.The Board is home to several other fine libraries and we have always advocated for their funding. It is hoped that they will receive the needed resources to carry on its great work.
Needs for Community Boards
The additional funding that all Community Boards received is extremely helpful. We ask that the City baseline the funding as it helps Boards fund events and neighborhood clean-ups.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/21
DPR
Reconstruct or
The Athletic Field at Pelham Bay Park is utilized
upgrade a park or
by thousands of area residents. The field is in
amenity (i.e.
great need of maintenance. We ask that the City
playground, outdoor
provide the Department of Parks and Recreation
athletic field)
with sufficient resources. This has been a top
priority for CB 10 for several years.
10/21
DPR
Reconstruct or
The Ferry Point Park turf fields are in need of
upgrade a park or
repair. We ask that the NYC Parks Department
playground
include resources to address the full renovation.
11/21
NYPL
Create a new, or
City Island Branch is a widely used library. A
renovate or upgrade
second story expansion of this facility is
an existing public
warranted for this vital community resource.
library
15/21
DPR
Reconstruct or
A full upgrade and restoration of Bufano Park is
upgrade a park or
sorely needed. We ask that the City provide the
amenity (i.e.
Department of Parks & Recreation with capital
playground, outdoor
resources for this request.
athletic field)
16/21
DPR
Reconstruct or
Bruckner Playground needs an upgrade and full
upgrade a park or
restoration.
amenity (i.e.
playground, outdoor
athletic field)
20/21
DPR
Provide a new or
We ask that the parking lot at Ferry Point Park
expanded park or
be fully resurfaced this fiscal year.
amenity (i.e.
playground, outdoor
athletic field)
CS
NYPL
Create a new, or
Community Board 10 wants to ensure that the
renovate or upgrade
project is fully funded and that construction on
an existing public
the new facility finally commence.
library
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
10/27
DPR
Provide more
We have long asked for a fully functional
programs in parks or
recreation center at Owen Dolen Park.
recreational centers
Westchester Square is a thriving community
with a strengthening commercial corridor. A
recreation center is ideal for this location.
12/27
DPR
Enhance park safety
The number of Parks Enforcement Personnel or
through more
PEP officers deployed to Pelham Bay Park,
security staff (police
Orchard Beach and Ferry Point Park must be
or parks
increased. These facilities are used by hundreds
enforcement)
of people and they must be made safe.
14/27
DPR
Provide more
Provide a recreational assistant in Pearly Gates
programs in parks or
Park and Bufano Park.
recreational centers
15/27
DPR
Forestry services,
Bronx Community Board 10 is asking that the
including street tree
City allocate an additional $1 million toward
maintenance
tree pruning in the Bronx.
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority Agency Request Explanation Location
image
2/21 Other Other capital budget
request
This body of water surrounds Edgewater Park and parts of Throggs Neck. We ask that the City review the need for its dredging
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/21
DPR
Reconstruct or
The Athletic Field at Pelham Bay Park is utilized
upgrade a park or
by thousands of area residents. The field is in
amenity (i.e.
great need of maintenance. We ask that the City
playground, outdoor
provide the Department of Parks and Recreation
athletic field)
with sufficient resources. This has been a top
priority for CB 10 for several years.
2/21
Other
Other capital budget
This body of water surrounds Edgewater Park
request
and parts of Throggs Neck. We ask that the City
review the need for its dredging
3/21
DOT
Reconstruct streets
Community Board 10 requests that the NYC
DOT reconstruct Revere Avenue between Dewey
Avenue and Sampson Avenue due to the
roadway sinking.
4/21
DOT
Reconstruct streets
Middletown Road, in Pelham Bay, is sinking. The
asphalt is cracking in many areas. We ask that
the NYC DOT initiate a study for capital
reconstruction of Middletown Road from
Bruckner Boulevard to Westchester Avenue.
5/21
DOT
Reconstruct streets
Please consider Huntington Avenue between
Miles Avenue and Sampson Avenue for capital
reconstruction.
6/21
DOT
Reconstruct streets
Please consider Sampson Avenue between
Sampson
Calhoun Avenue and Quincy Avenue for capital
Avenue
reconstruction.
Calhoun
Avenue
Quincy
Avenue
7/21
DOT
Reconstruct streets
Please consider Pennyfield Avenue for a full
Pennyfield
capital reconstruction with sidewalks and curbs.
Avenue
Harding
Avenue
Mitchell Place
8/21
DOT
Other
Community Board 10 asks that the NYC DOT
transportation
and NYC EDC initiate a study for ferry service at
infrastructure
Orchard Beach.
requests
9/21
DOT
Other
Community Board 10 fully supports the in-kind
Meagher
transportation
resurfacing of the Meagher Avenue entrance
Avenue
infrastructure
into Edgewater Park. This entrance is used by
requests
hundreds of MTA Buses and has caused wear
and tear.
10/21
DPR
Reconstruct or
The Ferry Point Park turf fields are in need of
upgrade a park or
repair. We ask that the NYC Parks Department
playground
include resources to address the full renovation.
11/21
NYPL
Create a new, or
City Island Branch is a widely used library. A
renovate or upgrade
second story expansion of this facility is
an existing public
warranted for this vital community resource.
library
12/21
SCA
Renovate or
The I.S. 192 Campus located at 650 Hollywood
upgrade a middle or
Avenue in Throggs Neck requests additional
intermediate school
resources for new air conditioners throughout
the campus.
13/21
DOT
Reconstruct streets
The following streets in the Throggs Neck
section require capital reconstruction: Wenner
Place, Jay Place and Rohr Place.
14/21
NYCHA
Renovate or
At Throggs Neck Houses, there is dilapidated
upgrade public
playground equipment, units that flood and
housing
have mold, malfunctioning elevators, broken
developments
street sidewalks, broken entrance doors and
roofs that are in disrepair from deferred
maintenance. NYCHA residents, a third of whom
are seniors, need these repairs immediately. The
Board asks that the City increase funding to
NYCHA's capital plan for these projects.
15/21
DPR
Reconstruct or
A full upgrade and restoration of Bufano Park is
upgrade a park or
sorely needed. We ask that the City provide the
amenity (i.e.
Department of Parks & Recreation with capital
playground, outdoor
resources for this request.
athletic field)
16/21
DPR
Reconstruct or
Bruckner Playground needs an upgrade and full
upgrade a park or
restoration.
amenity (i.e.
playground, outdoor
athletic field)
17/21
DOT
Repair or provide
We request that the NYC DOT initiate a street
Pelham Bay
new street lights
light survey on Westchester Avenue from Castle
Taxpayer
Hill Avenue to Burr Avenue.
Association
18/21
DOT
Repair or provide
We request that the City provide additional
Westchester
new street lights
street lights on East Tremont Avenue from
Avenue East
Bruckner Boulevard to Schurz Avenue.
Tremont
Avenue Castle
Hill Avenue
19/21
NYCTA
Improve
The Board would like to see the adoption in the
accessibility of
MTA Capital Plan of elevator service for Buhre
transit
Ave and Westchester Square Stations of the IRT
infrastructure, by
6.
providing elevators,
escalators, etc.
20/21
DPR
Provide a new or
We ask that the parking lot at Ferry Point Park
expanded park or
be fully resurfaced this fiscal year.
amenity (i.e.
playground, outdoor
athletic field)
21/21
SCA
Provide technology
Bronx Community Board 10 supports P.S. 304
upgrade
PTA's request for security cameras throughout
the other schools at its location. We also
support this request for all of Bronx Community
Board 10 public schools.
CS
NYPD
Other NYPD
The office of the Mayor and the NYPD must
facilities and
remain committed to fully funding the
equipment requests
renovation and sound abatement of Rodman's
(Capital)
Neck. Additionally, additional lighting is needed
along the entrance of the property to increase
visibility.
CS
EDC
Invest in capital
We are pleased that NYC EDC initiated a study
projects to improve
for Throggs Neck ferry service. We are in hopes
access to the
that ferry service in Community Board 10
waterfront
becomes a reality in 2023.
CS
NYPL
Create a new, or
Community Board 10 wants to ensure that the
renovate or upgrade
project is fully funded and that construction on
an existing public
the new facility finally commence.
library
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/27
NYPD
Assign additional
In addition to steady Harbor Patrol throughout
community affairs
the year, a neighborhood coordination officer
officers
program should be established for the Bronx
Harbor Patrol. This will help facilitate
communication between waterfront
communities and the NYPD.
2/27
NYPD
Assign additional
The current amount of Neighborhood
community affairs
Coordination Officers is inadequate since
officers
Community Board 10 is one of the largest
geographic districts in the City. Our current
program has six. We ask that the NYPD assign
at least three (3) additional officers to the
program.
3/27
DEP
Investigate and
The City should work with state and federal
address a hazardous
partners to conduct water quality testing of
materials complaint
Eastchester Bay.
at a specific
address/location
4/27
NYPD
Other NYPD staff
Community Board 10 is largely surrounded by
resources requests
water. We ask that the NYPD provide a
dedicated Harbor Patrol Unit throughout the
year for our community. Currently, there is only
one Harbor Patrol Unit for the borough and is
not adequate.
5/27
DOE
Other educational
Community Board 10 is one of the community
programs requests
board agencies that promotes the CTE
internship programming. We ask that the City
consider expanding programs to other
industries such as law and real estate.
6/27
DOE
Other educational
Young adult programming is needed in order to
programs requests
combat substance abuse issues and to deter
young people from products like e-cigarettes.
Programming should be operated out of schools
in our community district.
7/27
DOE
Other educational
The P.S. 175 schoolyard should be opened and
programs requests
available to the community after school and on
weekends.
8/27
DYCD
Provide, expand, or
The on-site after school programming in CB 10
enhance after
are the following elementry schools: The Child
school programs for
development Center of the Mosholu Montefiore
elementary school
Community Center at PS 153, the Child
students (grades K-
Development Center of the Mosholu Montefiore
5)
Community Center at PS 160, the Directions For
Our Youth Program at PS 72, the Kips Bay
Program at PS 304, the Kips Bay Program at
Throggs Neck Community Association of NYCHA
, Sports and Arts in Schools Foundation at PS
178 and PS 175, the YMCA Program at PS 14 ,
are excellent and require additional funding.
9/27
DYCD
Provide, expand, or
The on-site after school programming at the
enhance after
following Middle Schools should receive
school programs for
increased funding: The Child Development
middle school
Center of the Mosholu Montefiore Community
students (grades 6-
Center at the Equality Charter School, Direction
8)
for Youth at IS 180 and IS 181, East Side Houses
at the (Urban Assembly Academy of Civic
Engagement), Kips Bay Boys and Girls Club at
MS101X, Sports and Arts In Schools Foundation
at Truman HS , Xposure Foundation at Mott Hall
School, New York Junior Tennis League at PS 71.
The Phipps Community Development Beacon
Program at IS 192 Piagentini-Jones School
should be fully funded.
10/27
DPR
Provide more
We have long asked for a fully functional
programs in parks or
recreation center at Owen Dolen Park.
recreational centers
Westchester Square is a thriving community
with a strengthening commercial corridor. A
recreation center is ideal for this location.
11/27
NYCTA
Expand bus service
Several years ago the MTA New York City Transit
frequency or hours
had to reconfigure the bus service within Co-op
of operation
City, because of fiscal constraints. The resultant
situation was that the northern portion of the
development saw service on the BX 26 and BX
28 truncated. A new bus known as the BX 38
was created to link up with the BX 26 and BX 28.
We ask for expanded service along these lines
as well as on the Bx29, BxM7, BxM8, BxM9.
These lines provide are a lifeline to many
commuters in CB 10.
12/27
DPR
Enhance park safety
The number of Parks Enforcement Personnel or
through more
PEP officers deployed to Pelham Bay Park,
security staff (police
Orchard Beach and Ferry Point Park must be
or parks
increased. These facilities are used by hundreds
enforcement)
of people and they must be made safe.
13/27
NYPD
Other NYPD staff
Establishments along corridors such as East
2877 Barkley
resources requests
Tremont Avenue, Westchester Avenue and
Avenue
Bartow Avenue recieve the bulk of noise
complaints in Community Board 10. We ask
that the City provide the 45th Precinct with
additional sound meters.
14/27
DPR
Provide more
Provide a recreational assistant in Pearly Gates
programs in parks or
Park and Bufano Park.
recreational centers
15/27
DPR
Forestry services,
Bronx Community Board 10 is asking that the
including street tree
City allocate an additional $1 million toward
maintenance
tree pruning in the Bronx.
16/27
DYCD
Provide, expand, or
We are encouraged by the City's commitment to
enhance the
increase funding for the summer youth
Summer Youth
employment program. We ask that the City
Employment
continue to enhance this vital program.
Program
17/27
NYPD
Provide additional
Equip the agency with large tow trucks and a
patrol cars and
facility in which impounded trucks can be stored
other vehicles
to counteract the plethora of abandoned
vehicles along our highway service roads, near
parks and in and around our residential
communities.
18/27
DOE
Other educational
CB 10 is in close proximity to Montefiore
programs requests
Hospital, Jacobi Hospital, Albert Einstein College
of Medicine and Calvary Hospital. The Board
recommends that the City establish a uniquely-
specialized high school such as one that pertains
to the field health care. An example of this
model is the High School for Medical Professions
in the borough of Brooklyn.
19/27
DOHMH
Reduce mosquito
Many of the communities in our Board service
populations
area are surrounded by water. We ask that the
NYC DOHMH work with the Board to form a
more targeted approach to mosquito praying.
20/27
DHS
Expand street
Bronx Works is a vital resource to our
outreach
community. The Board Office contacts the
agency routinely to service homeless persons.
We ask that the City continue to fund this
agency.
21/27
DSNY
Provide more on-
Bronx Community Board 10 requests more
street trash cans
receptacles on Westchester Avenue between
and recycling
East Tremont Avenue to Burr Avenue. We also
containers
request more receptacles from East Tremont
Avenue from Bruckner Boulevard to Schurz
Avenue.
22/27
DOT
Conduct traffic or
We ask that NYCDOT study how to improve
parking studies
parking in Pelham Bay. Specifically, we ask that
the City review if City parking signage may be
removed to accommodate parking. Additionally,
please enforce illegal curb cuts as it removes
vital on-street parking spaces.
23/27
DSNY
Expand disposal
This event is well-attended. Bronx Community
events for
Board 10 request two to three safe disposal
hazardous
events each year.
household waste
24/27
DSNY
Increase
Bronx Community Board 10 supports the City
enforcement of
allocating more resources toward stopping
illegal dumping laws
illegal dumping. The City of New York should
look for ways to accept video when receiving
complaints through 311 as a way to apprehend
perpetrators.
25/27
DSNY
Increase
The City of New York and New York City Council
enforcement of
must look for ways to increase civil penalties for
illegal posting laws
posting signage on utility poles and street light
fixtures.
26/27
DSNY
Increase vacant lot
New York City Department of Transportation is
cleaning
notorious for not cleaning its own property,
including along the highways. We constantly
ask the Department of Sanitation to service
these areas through its Lot Cleaning Unit. We
ask that the City provide more manpower to
DSNY so that it can clean NYCDOT's property or
that a large citywide unit be created within
NYCDOT to service and maintain NYCDOT
property.
27/27
DYCD
Provide, expand, or
Bronx Community Board 10 asks that the City
enhance
study the feasibility of a youth center in Co-op
Cornerstone and
City.
Beacon programs
(all ages, including
young adults)

