Page Type:: [[About]]
To search in Civic Roam find the search bar in the upper left hand side of the screen and type in your search terms. Note that on the civicroam.org domain you will only be able to search the page names. Full document search requires [[Advanced Search]].
