- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 4 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1Jy5cYYxgrOrNx-N78cQepmdWafeJ1OdY/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1Jy5cYYxgrOrNx-N78cQepmdWafeJ1OdY/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
4
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 4
image
Address: 46-11 104 Street, 1st Floor
Phone: (718) 760-3141
Email: qn04@cb.nyc.gov
Website: www.nyc.gov/queenscb4
Chair: Louis Walker District Manager: Christian Cassagnol
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Overview
image
Queens Community Board 4Q (CB4Q) is a culturally diverse community that encompasses the area of Corona (south of Roosevelt Avenue) and Elmhurst. The total land area of Community Board 4Q is 2.4 square miles, bounded by Roosevelt Avenue to the North, Flushing Meadow Corona Park (FMPC) to the east, the Horace Harding Expressway to the south, and New York Connecting railroad (CSX) to the West. According to the 2010 Census, at the time the population of CB4Q was 172,598 a 3.3% increase from the 2000 census.
Overdevelopment/ Dept. of Buildings
image
The ongoing problem of overdevelopment continues within CB4Q. The current levels of service and infrastructure can no longer absorb the additional housing units. In order to secure the future stability of CB4Q, careful consideration must be given to the rezoning of our community.
image
In 2018, there were 165,988 permits issued by the Buildings Department. In the first three quarters of 2019, 120,668 permits have been issued, putting us on track to meet or exceed last year’s numbers. With the rapid increase in development in the city, it is crucial that the Department of buildings has enough building inspectors and staff to adequately ensure the safety of the over 1.1 million buildings in NYC. In FY 19, the average response time for Priority B complaints was 11.4 days. While Priority B complaints aren’t life threatening, they can be indicators that something about the building is unsafe. It is very clear that the Department of Buildings needs more staff so that they can continue to decrease the response time to possible hazardous complaints. No matter what we say in an attempt to please the case for more funding for DOB, no one can say it better than former Buildings Commissioner Rick Chandler, who in a 2018 interview said “I think if we had ten times the resources …, we would still be just making a dent.” While DOB has made great strides since then, it has hardly reached the level of resources Commissioner Chandler hoped they would one day have to address all of the city’s needs.
Health Initiatives, and Health care factilities
image
For several years now, CB4Q has proudly been home to two farmers markets, (Corona Plaza, and Elmhurst Hospital). Zumba classes, and other health related initiatives geared towards providing our community with the knowledge and resources they need to stay fit are happily supported throughout our constituency. Urgent care facilities throughout the district are indeed a welcome addition as many constituents see these facilities as a cheaper, quicker alternative to the negative stigmas associated with an actual hospital. Although these facilities have gained popularity, the fact remains that the residents of the surrounding neighborhoods of Elmhurst, Corona, Maspeth, and Glendale are still in need of an actual hospital. Urgent care facilities are not made to replace hospitals, but to work in conjunction with them.
image
Within the district, we are fortunate to have the Corona Community Ambulance Corps. (CCAC), a volunteer based ambulatory organization that serves as a supplement to existing services. Over the years, the CCAC underwent financial difficulties over discrepancies due to previous mismanagement, but has since undergone a corporate restructuring that has allowed it to effectively turn itself around, and continue its service to our constituency. Despite a minimal funding stream, the corps still depends on volunteers, and continues to operate with minimal resources. Funding is not only welcome, but in fact necessary.
Senior Housing
image
Sections of the district specifically in Elmhurst are in need of affordable senior housing. Exorbitant rent, and overdevelopment throughout our community are leaving many seniors displaced with no place to turn.
Waiting lists on housing take years to move, and seniors are left with little to no choice as they wait for a spot to be available. Funding is sorely needed to identify and obtain property to construct such a facility.
Youth/Education/Family Services
image
Although New York City as a whole will experience a downward trend in school enrollment in the next ten years, the school district encompassing CB4Q (D24) will see an upward trend in enrollment. Schools cannot be built fast enough. We will continue to support the Department of Education and the School Construction Authority in their efforts to identify additional new sites for schools.
image
With the expansive growth of immigrant families with young children in our district, there is a great need for Early Childhood Services for children Birth to Three. The services that we are in need of are quality infant- toddler care and early childhood education provided by trained professionals with a culturally sensitive and linguistically sensitive focus. Currently, there are an insufficient number of Early Childhood centers in our district that service Infants and Toddlers and their parents and we are in desperate need of facilities to provide the space to render such services. According to a recent Unicef report on early childhood development, an economically disadvantaged child has the opportunity to thrive socially and academically when provided with early intervention and early childhood services.
Public Safety
image
Since 1988, the Community Board has put the renovation of the 110th Precinct at the very top of its yearly capital requests. For approximately 7 decades, this facility has seen little to no improvements to its overall infrastructure. Both within and outside the facility, structural crumbling, loose bricks, and flooding are common. As one of the busiest precincts in Queens North, with close to 250 uniformed and civilian personnel (and growing), this structure is a potential danger that is unfair to those tasked with keeping our communities safe.
image
Additionally, the community has been requesting a proper parking facility for the 15+ marked and unmarked vehicles being stored along the residential block surrounding the precinct. In a district where parking is at a premium, we should be looking to provide parking for our officers all the while returning parking spaces to the residents of the surrounding community.
image
Throughout the district there is an issue with vehicles illegally displaying “for sale” signs on them. While we continue to be at the forefront in bringing these vehicles to the attention of the agencies responsible, there simply isn’t enough manpower, and laws are far too lax. Vehicles are being blatantly parked along streets; some with plates, others without, and in many cases those who do have plates only display them in the rear of the vehicle enabling them to use the vehicle’s second plate on another one. The majority of these vehicles are being sold by local repair shops who have accepted the low summonses as the norm while they continue to sell the vehicles. The Dept. of Sanitation can ‘tag’ a vehicle with no plates, but due to the multiple day turnaround time, the vehicle is moved far before enforcement is able to impound it. The low cost of the summonses is simply not enough to deter the sales of these vehicles. Our Board is in full support of legislation such as this that will help to stop these unfair practices from continuing to manifest themselves within our neighborhoods.
Parks & Historical Preservation
image
The community of Elmhurst, Queens, is rich in cultural history with many buildings dating back to the 1700’s. One of the first religious buildings in Newtown was the old St. James Episcopal Church (Elmhurst’s oldest remaining building.) Other distinctive buildings in the community include Newtown High School, and the Elks Lodge. Not only does the community boast of architecture from the 1890s, it is rich in artifacts dating back to an African cemetery in the 1800s located on 90th Street. In the last few years, a bone fragment was found at Newtown Playground which served as a cemetery during colonial times, and a cistern was found at CC Moore Playground during a 1992 construction project.
image
Elmhurst also features the dedication of the Elmhurst History and Cemeteries & Preservation Society (EHCPS) which is a group founded by Newtown Civic working toward land marking, researching, documenting and preserving the history of a community which dates back to 1652 and is the second oldest community in Queens, behind Flushing.
image
The rich history surrounding CB4 is fascinating, and should be recognized as such. Several parks with significant historical meaning often have their history forgotten due to lack of properly displayed information. With the increase in development geared towards promoting tourism specifically around Elmhurst, historical facts can easily be forgotten. At the very least, proper signage should be implemented at key locations (parks, cemeteries) throughout the district as is done in rural Pennsylvania towns. Emphasis should be put into the multitude of parks scattered throughout our Board as a starting point as these parks are often historical pillars that tell stories of Elmhurst, Newtown and Corona. Furthermore, applications for land marks are often overlooked, and denied, a practice that will only serve to further hide the rich past that makes up CB4.
image
Our parks are also cultural spaces, a fact that is often forgotten. With Queens Parks ratings as high as they are, we should be looking to encourage visitors and tourists to enjoy our public spaces to their full capacity. Future parks schematics/ designs should all a performance space base lined into their designs since their inception. Such spaces would help to tackle health issues and promote wellness via programs such as ShapeUpNYC. Public performances would also increase, as such spaces would better accommodate and essentially promote more holiday ceremonies throughout the district celebrating the multitudes of ethnic groups that make up our district.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 4
image
The three most pressing issues facing this Community Board are:
Affordable housing
The ongoing problem of overdevelopment continues within CB4Q. It is not uncommon that older housing stock, (one and two family homes) are demolished and replaced with new buildings that house three and four family homes. The current levels of service and infrastructure can no longer absorb the additional housing units. In order to secure the future stability of CB4Q, careful consideration must be given to the zoning of our community.
Schools
The over-usage of already limited City services will only continue to have a detrimental effect on our youth population. Overcrowded schools are common ground, after school programs are overcrowded, and the libraries within our vicinity are used far beyond capacity.
Social services
The constituents of Community Board 4 require multiple needs and services. One of the most pressing issues that our district is confronted with is an information gap that exists between constituents and the services meant to benefit them. CB4 relies heavily on volunteers and our 2-3 staff members to organize events and address constituent needs. As one of the most densely populated districts in the city, our board requires additional funding to expand our organizing capacity by hiring an additional staff member. By growing our staff, we can work to close this information gap and positively impact our community by informing them on issues, resources, and opportunities for development. Boards are considered to be the City's front line of defense; we manage countless constituent issues, zoning variances, public meetings, and generation of yearly Needs Statements. Despite this heavy responsibility, staffing for many CB's is grossly inadequate for the amount of work output, causing many of them to resort to interns and volunteers as a primary source of help. For the 2nd year in a row, Community Boards have received stipends meant to empower and strengthen board and community relations. It must be emphasized however, that while upgrades to our offices are welcome, the real need remains in staffing more so since our responsibilities and outreach capabilities have increased because of this stipend.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 4
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
Homelessness and housing insecurity is a pressing issue in our district. Many of our residents are at risk for entering shelter and we are seeing an increase in individuals sleeping in our parks and on the streets.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Community Board4Q is home to Elmhurst Hospital Center, a trauma center within the heart of Queens that sees a tremendous amount of patients spanning the entire borough. While the hospital has been recipient of several upgrades and expansions over the last few years with more to come, the truth is that it is still the only trauma center within immediate reach of our communities. Urgent care facilities throughout the district are indeed a welcome addition as many constituents see these facilities as a cheaper, quicker alternative to the negative stigmas associated with an actual hospital. Although these facilities have gained popularity, the fact remains that the residents of the surrounding neighborhoods of Elmhurst, Corona, Maspeth, and Glendale are still in need of an actual hospital. Urgent care facilities are not made to replace hospitals, but to work in conjunction with them. We will continue to support public campaigns emphasizing the importance and the need for quality health insurance and preventive measures. Emphasis must be put into providing this information in multiple languages.
Needs for Older NYs
While Corona has seen new senior living facilities (HANAC) as of late, sections of the district specifically in Elmhurst are in need of affordable senior housing. Exorbitant rent, and overdevelopment throughout our community are leaving many seniors displaced with no place to turn. Waiting lists on housing take years to move, and seniors are left with little to no choice as they wait for a spot to be available. Funding is sorely needed to identify and obtain property to construct such a facility.
Needs for Homeless
With the amount of hotel shelters showing up in our communities, the general consensus within our neighborhoods is that this idea is simply not a solution. Hotels are often built in neighborhoods that are heavy on tourism and foot traffic with the intention on capitalizing on visitors to our communities, yet many of our hotels operate with 100% capacity for homeless individuals. While we fully understand that nobody should be homeless, and that it can happen to anyone, this initiative was not well thought out as several shelters have multigenerational families in them. Communities are often sneakily informed at zero hour about new hotels that have already been filled to capacity with homeless individuals. Discussions on proper solutions, are rare, and this initiative does little but fill the pockets of hotel operators with no accountability being shown by the Administration towards our communities.
Needs for Low Income NYs
No comments
image
7/41
HHC
Provide a new or
With the former St. John's Hospital now closed,
expanded health
the residents of South Elmhurst and its
care facility
surrounding vicinity are in need of a medical
facility. Elmhurst Hospital is operating beyond
capacity, and is struggling to keep up with the
demand. The need for a medical center in the
neighborhood of South Elmhurst cannot be
overlooked.
8/41
HHC
Provide a new or
Requesting a rehabilitation center within the
expanded health
confines of Community Board 4. Drug & alcohol
care facility
counseling, mental health, and physical therapy
services could be just some of the services
offered.
18/41
DFTA
Create a new senior
With the growing, aging population within CB4,
center or other
the need for an assisted living facility cannot be
facility for seniors
overlooked. While Corona does in fact have such
a facility, the area of Elmhurst does not.
Requesting that resources be allocated to obtain
property, and build such a facility to house the
senior population of South Elmhurst.
29/41
DHS
Expand street
Breaking Ground currently operates via 4
outreach
outreach teams in Queens 24/7/365 (in all
weather), as well as a case management staff
that participates in client transports to medical
appointments, housing appointments, housing
placements, etc., One of their biggest needs is
vehicles. While the agency does have a fleet,
vehicles' life spans are shorter than average
since their mileage racks up so quickly.
Requesting funding be allocated to an increase
in vehicles to continue providing this very
necessary service.
3/33
DOHMH
Reduce rat
There is a proliferation of rats being seen
populations
throughout the district. Funds are being
requested to continue programs such as Rat
Academy geared towards raising public
awareness.
4/33
DOHMH
Other programs to
Recently NYC was hit with the largest Measles
address public
outbreak in almost 30 years. Measles cases in
health issues
NYC accounted for more than half of the 1,234
requests
confirmed cases nationwide. This public health
crisis unfortunately proved how woefully
unprepared we are as a city to address
epidemics. The outbreak which lasted from
October 2018 until August 2019 cost the city
over $6 million dollars. Over 500 New York City
employees were deployed to battle the crisis.
With so many all over the city, it is obvious that
the Department of Health and Mental Hygiene
was horribly understaffed. We believe it is
imperative to the health of our city to increase
finding for DOHMH so that they can increase
staffing levels, as well as produce more
literature to address the growing anti-vaxxer
movement.
19/33
DOHMH
Other animal and
With mosquito-borne illnesses such as Zika, and
pest control
West Nile within our communities, funding
requests
request would entail more staffing, and the
continuation of public awareness campaigns to
teach prevention in multiple languages. Our
public plazas and abandoned properties are
particularly vulnerable to rats. Requesting
funding to increase awareness, and mitigation
of pests (rats and mosquitoes) throughout the
community.
20/33
DOHMH
Create or promote
The communities of Elmhurst and Corona both
programs for
see farmers' markets, and several campaigns
education and
geared towards condoning walking, and riding
awareness on
vs driving. Our communities would like to
nutrition, physical
continue to see expansions of programs (WIC at
activity, etc.
farmers' markets, bike helmet giveaways, health
insurance, etc.) Material and outreach should
be emphasized in multiple languages conducive
with the communities they are trying to reach.
image
assistance/vouchers for permanent housing
throughout the city, the need for services to get our residents out of shelters should be more heavily emphasized. Family shelters within the district currently house multi generational homeless families. The cost of housing these families in shelters/hotels far exceeds the cost of permanent housing. Funding should instead be allocated to preventative programs, and those geared towards removing people from the "system".
image
26/33 HRA Provide Metrocards
to help low-income New Yorkers get to work and around the City
With the ridership at many of our stations as high as 17 million riders per year for Roosevelt Ave., and as high as 6.8 million for Woodhaven Blvd, it is obvious that our residents are using mass transit as a means to get around. In conjunction with this, the low income cap throughout the district reflects a need for funding metro cards to low income residents throughout the areas of Corona and Elmhurst.
image
27/33 DFTA Enhance programs
for elder abuse victims
Requesting funding to expand Elder Abuse Prevention programs throughout the district.
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 4
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
Although New York City as a whole will experience a downward trend in school enrollment in the next ten years, the school district encompassing CB4Q (D24) will see an upward trend in enrollment. Schools cannot be built fast enough. We will continue to support the Department of Education and the School Construction Authority in their efforts to identify additional new sites for schools.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
The multiple benefits of providing Early Childhood Services and Parent Services to an economically disadvantaged immigrant community cannot be overlooked. The utter lack of such services in our district for these children and families is cause for concern, as such programs would contribute to the well-being of parents and children alike. The lack of after school programs throughout the board continues to be an area of difficulty for many of our residents. The need for mentoring, homework help, counseling, and overall social networking is unfortunately missing from our community. In addition to the allocation of funds for after school programming, the need for a multi-purpose community/recreational center is a request that our board has held onto for some time. Such a center would provide the youth of CB4 with the social skills required for their growth. Communal activities such as sports, arts and crafts, and after school workshops are just a few of the different programs that could be offered at such a facility, especially in a day where social media, smart phones and video games reign above all else. Our youth lacks basic social skills than can only be obtained through communal activities and physical, social contact with each other. For this reason, our constituency is asking that acquisition of land and furthermore, the construction of an intergenerational (seniors and youth under one roof) and/or after school center within our district be considered.
Needs for Youth and Child Welfare
With the expansive growth of immigrant families with young children in our district, there is a great need for Early Childhood Services for children Birth to Three. The services that we are in need of are quality infant-toddler care and early childhood education provided by trained professionals with a culturally sensitive and linguistically sensitive focus. Currently, there are an insufficient number of Early Childhood centers in our district that service Infants and Toddlers and their parents and we are in desperate need of facilities to provide the space to render such services. According to a recent Unicef report on early childhood development, an economically disadvantaged child has the opportunity to thrive socially and academically when provided with early intervention and early childhood services. In addition, the report states the following: • Brain development is most rapid in the early years of life.
When the quality of stimulation, support and nurturance is deficient, child development is seriously affected. • The effects of early disadvantage on children can be reduced. Early interventions for disadvantaged children lead to improvements in children’s survival, health, growth, and cognitive and social development. • Children who receive assistance in their early years achieve more success at school. As adults they have higher employment and earnings, better health, and lower levels of welfare dependence and crime rates than those who don’t have these early opportunities. • Efforts to improve early child development are an investment, not a cost. Available cost-benefit ratios of early intervention indicate that for every dollar spent on improving early child development, returns can be on average 4 to 5 times the amount invested, and in some cases, much higher.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation Location
19/41
SCA
Provide a new or
The lack of high schools within the district is a
expand an existing
cause for concern. With the recent influx of
high school
Elementary and Middle Schools throughout our
district, adding a new high school would help
our constituency stay closer to home and will
ease overcrowding within the SD24.
25/41
SCA
Provide technology
Many schools within our district strongly need
upgrade
tech upgrades such as whiteboards, laptops,
calculators, tablets, etc. We are aware that the
newer schools came with a lot of these tech
upgrades already, so focus should be put
towards the remaining pre-existing schools.
CS
DYCD
Provide, expand, or
The low allocation of funds within CB4 is
enhance after
surprising considering SD 24 is currently the
school programs for
most overcrowded in the city. There is a need
middle school
for after school programming for adolescents
students (grades 6-
grades 6-8 who at this stage in their lives need
8)
more aggressive mentoring and help with
school work.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
32/33
DYCD
Provide, expand, or
There is a tremendous need for after school
enhance after
programs for elementary school students
school programs for
grades k-5. At this early stage the students'
elementary school
lives, it is important to have enriching programs
students (grades K-
that are both educational and fun. Said
5)
programs will also help parents who have
limited work hours, will help the children with
social skills, and give students an advantage as
they progress in their education.
33/33 DYCD Other youth
workforce development requests
Our district would benefit greatly from having a youth center that would support our youth and their families. Educational programs, mentoring, homework help, extracurricular activities, and counseling are just some of the services that the youth within our district are in desperate need of. Seeking funding to obtain land, and construct a center within the confines of our district.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 4
image
M ost Important Issue Related to Public Safety and Emergency Services
Public safety facilities (precinct, fire houses, etc.)
Since 1988, the Community Board has put the renovation of the 110th Precinct at the very top of its yearly capital requests. For approximately 7 decades, this facility has seen little to no improvements to its overall infrastructure. Both within and outside the facility, structural crumbling, loose bricks, and flooding are common. As one of the busiest precincts in Queens North, with close to 250 uniformed and civilian personnel (and growing), this structure is a potential danger that is unfair to those tasked with keeping our communities safe. Additionally, the community has been requesting a proper parking facility for the 15+ marked and unmarked vehicles being stored along the residential block surrounding the precinct. In a district where parking is at a premium, we should be looking to provide parking for our officers all the while returning parking spaces to the residents of the surrounding community. Years back, in conjunction with Community Board 4, Congressman Crowley (CD14), State Senator Jose Peralta (SD13), and Assemblyman Francisco Moya (AD39) the issue was brought to light, and concerns were forwarded to the attention of the Governor’s and Mayor’s offices; to date however, there has been no known movement on this proposal. We are requesting that an NYPD satellite station be installed on the Western side of Elmhurst near both the Queens Center and Queens Place Malls along Queens Boulevard.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Roosevelt Avenue continues to be a point of contention, and much needed attention. The onslaught of street vendors, rampant crime, and quality of life issues along the commercial corridor are simply getting out of hand. The Community Board receives incessant calls with regards to the conditions of Roosevelt Avenue. We are seeking assistance from our lawmakers to help us find a solution to a growing problem with no clear end in sight. The potential implementation of a task force exclusive to this commercial corridor would be a welcome addition, and one that has been discussed over several conversations, but has made little headway thus far. We look forward to this continued dialogue. Throughout the district of Community Board 4 we have seen a massive increase in the amount of illegally parked cars displaying “for sale” signs on them. While we continue to be at the forefront in bringing these vehicles to the attention of the agencies responsible, there simply isn’t enough manpower, and laws are far too lax. Vehicles are being blatantly parked along streets; some with plates, others without, and in many cases those who do have plates only display them in the rear of the vehicle enabling them to use the vehicle’s second plate on another one. The majority of these vehicles are being sold by local repair shops who have accepted the low summonses as the norm while they continue to sell the vehicles. The Dept. of Sanitation can ‘tag’ a vehicle with no plates, but due to the multiple day turnaround time, the vehicle is moved far before enforcement is able to impound it. The low cost of the summonses is simply not enough to deter the sales of these vehicles. In the past year or so , we have seen the implementation of the Neighborhood Coordinating Officer (NCO) Program. While the program is welcome, a general concern is that these officers are usually "held" by local community / civic groups to handle only their specific issues, and are rarely given a chance to work with the rest of the community. CB4 has been working with the NCO's for some time, but while the program began strong, it was ultimately easier to simply reach out to the precinct directly as many of the issues are constituent issues that should be handled on a larger scale (proliferation of homeless, liquor sales to intox, etc.)
Needs for Emergency Services
With the increase of population and overdevelopment in CB4Q, all of our emergency services are being taxed. We are concerned that the current level of funding is not adequate for the maintenance/rehabilitation of our firehouses. In addition, we want to make sure that our emergency services providers have all of the equipment that they need in the case of an emergency (I.e. generators in the case of a blackout, better communication equipment to coordinate efforts, etc.). We are also concerned that the existing ERS system is being neglected. In a time when most households no longer have landlines, ERS boxes provide a crucial ability to summon emergency services in
situations where very often every second matters. The Community Board is opposed to removal of the existing boxes, and asks that the cast iron bases be retained and retrofitted to accommodate the more modern push button system onto the existing base.
image
Priority
Agency
Request
Explanation
Location
4/41
NYPD
Renovate or
The building now housing the 110 Precinct is
94-41 43rd
upgrade existing
inadequate. The precinct House is in a densely
Avenue
precinct houses
populated residential area with limited street
access and no viable parking for police vehicles.
This project was projected for funding since FY
2013, but has since made no progress.
Renovation to this facility is desperately needed.
9/41
NYPD
Provide surveillance
Several sectors within the district are in need of
cameras
added security measures, specifically the
corners spanning the entire stretch of Roosevelt
Avenue, the adjoining Junction Boulevard, and a
high-crime section of 57th Avenue between
99th Street and Junction Blvd. Requesting that
surveillance cameras be funded.
12/41
FDNY
Rehabilitate or
Continue funding for complete analyzation, and
renovate existing
reparation of firehouses within the district.
fire houses or EMS
Engine 287 Ladder 136 Battalion 46 86-53
stations
Grand Avenue Elmhurst, NY 11373
13/41
NYPD
Add NYPD parking
For years, Community Board 4Q has requested
facilities
dedicated vehicle parking for the 110 Precinct
vehicles. Currently no off street parking is
available for NYPD vehicles.
28/41
NYPD
Provide a new NYPD
Requesting that a satellite precinct/ mobile unit
facility, such as a
be considered for the western side of Elmhurst,
new precinct house
specifically the commercial corridors
or sub-precinct
surrounding the Queens Place, and Queens
Center malls.
CS
NYPD
Provide a new NYPD
Requesting that an NYPD satellite station be
facility, such as a
installed within the confines of Flushing
new precinct house
Meadows Corona Park to provide safety in this
or sub-precinct
heavily used large park. Some time last year,
with generous funding from the Queens
Borough President, makeshift trailers/ satellite
stations was installed in the park. However,
several concerns were raised specifically around
the potential lack of sufficient staffing.
Priority
Agency
Request
Explanation
Location
15/33
NYPD
Provide additional
Requesting 2 to 3 unmarked vehicles to meet
patrol cars and
current and future needs.
other vehicles
17/33
FDNY
Expand funding for
The FDNY Fire Safety Educational Unit needs
fire prevention and
additional funding to provide smoke detectors
life safety initiatives
and carbon monoxide detectors for distribution
to the public. This is a public service that will
save lives.
23/33
FDNY
Other FDNY facilities
The majority of the firehouses within our district
97-28 43rd
and equipment
already have generators in case of a power
Avenue
requests (Expense)
outage. However, Engine 289 in Corona is still
operating with an above ground, multiple unit
setup. Requesting funding to provide an in
ground generator for this heavily utilized
station.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 4
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Recycling facilities and services
Throughout the district, our constituency has seen an increase in the amount of garbage being strewn throughout our streets. Abandoned lots covered in garbage are common ground, and home owners and businesses alike tend to overlook laws regarding the cleanliness of their sidewalks. Changes to recycling laws are constant, and new programs such as electronic/textile/compost are confusing and present a change that many of our constituents have not yet grasped. Informational campaigns in multiple languages for public education on recycling, and responsibilities of property owners are a constant request heard throughout our constituency. It has also been noted that DSNY enforcement tends to be lax in some cases, and overly aggressive in others due mostly to the fact that several agents have openly stated that they themselves do not know the actual laws. Dialogue between DEP, and DSNY Enforcement must be made crystal clear to form a more cohesive plan to keep our streets clean. Funding and emphasis should be put into public informational campaigns designed to educate our constituents. These campaigns should be in multiple languages, and be a year round effort to be most effective, and not only at the inception of these programs. .
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Several corridors along CB4Q are in need of upgrades to their sewers. Basements along the commercial district of 82nd Street between Roosevelt Avenue and Baxter Avenue as well as homes along the South side of 111th Street suffer from sewer backups, and ponding issues along their streets. A general upgrade of our infrastructure should take precedence to meet current and future demand. More over, we have been undergoing an issue with the recently implemented rain garden initiative brought forth by the Dept. of Environmental Protection. When the rain garden program was unveiled in the district in 2013, it was received with trepidation as concerns were immediately brought up with regards to the accountability of rain garden maintenance. While the Community Board was in favor of the overall concept behind them, we feared that these rain gardens would quickly become garbage pits. DEP does its best to rectify the issue, but rain gardens throughout the district can go months with no cleanup on behalf of the agency. Staffing is simply not enough. A general increase to staffing specifically towards the maintenance of the gardens would be of huge benefit to our community.
Needs for Sanitation Services
NYC has suffered from several snow storms over the last few years, and while DSNY did its best to work with existing resources, ultimately a lack of manpower, and vehicle egress made snow removal a difficulty. Damaged snow plows, and detached mechanical brooms have been reported by our constituency. We ask that budget increases reflect the increase in housing units in the CB4Q area. Additional vehicles as well as increased maintenance on the existing ones should be more aggressively pursued. We are also seeking a more proactive campaign be implemented to educate our residents on the laws and rules for recycling. Too many residents in CB4Q do not understand the constantly changing rules and regulations of recycling and property maintenance, specifically with regards to electronic recycling, textile recycling, composting and rain gardens.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
40/41
DEP
Evaluate a public
Requesting more staffing for the maintenance
location or property
of the recently implemented Green
for green
Infrastructure initiative. Currently DEP staff is
infrastructure, e.g.
scheduled to maintain and clean these sites on a
rain gardens,
weekly basis, but a majority of our sites go for
stormwater
weeks, possibly months with no visits. Current
greenstreets, green
staffing is simply not enough. Requesting
playgrounds
funding to meet current and future demand.
CS
DEP
Evaluate a public
85th Street abuts MTA /LIRR property. Green
85 Street
location or property
infrastructure is sorely needed in this area. DEP
55th Road
for green
has already conducted studies to consider this
57th Road
infrastructure, e.g.
location for green infrastructure, and has in fact
rain gardens,
identified it as a potential site. Seeking
stormwater
implementation and completion of this long
greenstreets, green
awaited / approved project.
playgrounds
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
5/33
DSNY
Other cleaning
We support the ACE program that works as a
requests
supplement for existing street cleaning services.
Funding has allowed the program to effectively
canvas several commercial and residential
sectors of the district, and assist with cleanup
(sidewalk sweeping, scraping of utility poles,
garbage mitigation) Currently, the program
covers: - Diversity Plaza - 104th St. from
Roosevelt to Corona Aves. -108th Street from
Roosevelt to Corona Aves . -111th St /Roosevelt
Station - William F. Moore Park Requesting that
the Ace Program be considered for: 1. Broadway
from Cornish Ave. to Queens Blvd. 2. Queens
Blvd. E/B and W/B between Grand to Horace
Harding Expwy. 3. Corona Avenue (91st Pl. to
Queens Blvd) 4. Grand Ave from QB to Haspel
St.
14/33
DSNY
Increase enforcement of illegal posting laws
Several commercial corridors and their surrounding areas are infamous for illegal postings on utility poles, walls, and construction fences. The entire stretch of Roosevelt Avenue from 72nd Street to 114th Street and its adjacent side streets are havens for these postings. Business owners do their best to remove these flyers, but with virtually no enforcement, it is a losing and discouraging battle. Postings vary from illegal apartment rentals, to vehicle sales to fitness classes. These forms of advertisement are dangerous, unjust, and often advertise illegal services. More stringent enforcement should be implemented.
Roosevelt Ave 72nd St 114th St
22/33
DSNY
Increase enforcement of dirty sidewalk/dirty area/failure to clean area laws
Several areas of our district are seeing a substantial amount of garbage pile up, with little to no penalty to the property owners. Commercial corridors such as Queens Boulevard, Roosevelt Avenue, Junction Boulevard, Broadway, and National Street near Corona Plaza are infamously known for excessive littering, but enforcement is scarce.
More over with the ACE Program in effect at several of these locations, enforcement should be more stringent on properties who have no reason to not maintain their sidewalks including adjacent tree pits.
31/33
DSNY
Provide or expand NYC organics collection program
While neighboring districts of Rego Park, Glendale, and some parts of Jackson Heights already have the organics program, the neighborhood of Corona, and the majority of Elmhurst have yet to be a part of this successful program.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 4
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Real estate development
It is a fact that the infrastructure of CB 4Q was built mainly for low-density housing. The addition of larger housing units at double and in some cases triple the size of the preexisting structure places an undue strain on our infrastructure. Such over-development without proper planning affects CB4Q and its residents on all facets. The Dept. of Sanitation is overwhelmed with the increase in trash generated by the larger units; Police and Fire department response times are up due to the increase in traffic clogging our roads, already overused schools and hospitals are stretched beyond capacity, and reports of flooding and sewer backups are at an all-time high.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Existing one story buildings are being replaced with high density buildings at a rate too fast to be kept up with. A planned balance between residential and commercial buildings is sorely needed. For far too long, we have operated under the careless mentality of “when it is needed, we’ll deal with it.” The intricacies behind infrastructural projects combined with lack of funding and staffing has led our agencies to operate with little to no time to actually handle issues on a proactive basis. Community services and utility companies are increasing their services as the need arises, and not before. The fact is that large sections of Elmhurst and Corona were designed as a tightly woven network of 1-2 family houses whose streets are far too narrow, and simply not prepared to handle such an influx of tourism in such a short amount of time. With close to 75% of the district’s make up being residential, it is evident that people want to live here. What is a constant problem for us however, is the misconception that in order to solve the problem, more housing should be created. Throughout the year, variances are constantly being brought to Community Boards for review thus converting 2 and 3 family homes into multi dwellings of 15 or more families. The growth is blatantly evident, yet very little emphasis is being put on into actual upgrades to our streets or sewer systems. With the average median household income at $45,661, and 27% of the district’s households living below the poverty line, there should be more conversation and initiatives geared towards not only providing affordable housing, but in also taking into consideration that housing initiatives require substantial infrastructural changes especially in neighborhoods such as Corona and Elmhurst that have seen a tremendous surge in population within the last 5-10 years.
Needs for Housing
The lack of NYCHA housing within our district is a cause for concern. With the average median household income at
$45,661, and 27% of the district’s households living below the poverty line, there should be more conversation and initiatives geared towards providing affordable housing. Careful consideration must be made into the locations of such developments as substantial infrastructural upgrades are often needed. The neighborhoods of Corona and Elmhurst already suffer from lack of parking, and have seen substantial increases in traffic. While we have a tremendous need for such facilities, the inherent inconvenience of putting them wherever possible can be more detrimental than helpful. We support open dialogue in the obtaining of land, and eventual construction of such a facility within our district.
Needs for Economic Development
The eclectic nature of Elmhurst and Corona combined with the astronomical prices on rent for ‘brick and mortar’ establishments has led Community Board 4 to be a mecca for street vendors. The sheer amount of nationalities, cultures and craftsmen within the district have encouraged those seeking employment to establish themselves as successful street vendors. The concern however, is over the high amount of vendors that flood areas where commercial traffic is extremely high, and the negative impact this can have on brick and mortar businesses. Laws are in effect that help to govern the distance between street vendors and physical establishments selling similar wares, but complaints to agencies, and fights between vendors are far too numerous to log. While it is universally
understood that street vendors are in fact a legitimate tax paying business, there should be an understanding that inspections of vendors (food or otherwise) be far more stringent. Furthermore, enforcement should be conducted more often in heavily utilized commercial corridors that have been overrun by street vendors such as Corona Plaza, Roosevelt Avenue, Junction Boulevard, the Queens Center Mall, and the area within the purview of the 82nd Street Business Improvement District (82nd Street Partnership) which spans 82nd Street from 37th Avenue to Baxter Avenue.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
14/41
HPD
Provide more
Community Board 4 has seen a very steady
housing for
influx of new residents in the last few years, and
extremely low and
will only continue to grow at a steady pace. The
low income
lack of affordable housing is encouraging
households
"shacking up" in which large families are living
out of single rooms and illegally converted
basements. An Affordable Housing facility is
desperately needed for both the convenience,
and the safety of CB4's residents.
20/41
HPD
Provide more
Community Board 4 has seen a very steady
housing for medium
influx of new residents in the last few years, and
income households
will only continue to grow at a steady pace. An
emphasis throughout the district is being put
into low income housing, however, financial
burden does not pertain strictly to low income
households. Requesting funding to survey,
obtain land, and eventually build an affordable
housing facility for medium range income within
the district.
24/41
HPD
Other affordable
While the Department of Housing Preservation
housing programs
and Development (HPD) provide loan programs
requests (capital)
the increased need for such programs can not
be overlooked. Community Based Organizations
(CBO's) such as Neighborhood Housing Services
(NHS), do a great job in providing such services,
but the demand for increased programs is
exceedingly present specifically in low density
(2-3 family) homes.
27/41
HPD
Provide more
With the homeless crisis sweeping throughout
housing for special
the city, many communities have been seeing an
needs households,
increase in the number of shelters popping up
such as the formerly
within their constituencies. As these shelters
homeless
continue to increase, to avoid the homeless
crisis remaining stagnant it is important that
housing for formerly homeless as well as seniors
be provided.
36/41 EDC Build or expand
incubator or affordable work or research lab spaces
Immigrant owned small businesses are the backbone of our local economy. Studies show that immigrants have a higher rate of business ownership than non-immigrants, with roughly one out of ten immigrant workers owning a business. While our community has made significant progress supporting street vendors (through community based organizations and local elected officials supporting positive legislation), we still lack a clear pipeline for street vendors to open a small business. Our community would benefit from funding allowing us to establish a small business incubator that provides mentorship, training, and education.
Funding for this project would also allow us to
establish an incubator space.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
2/33 SBS Other expense workforce development requests
Several CBO's throughout the borough see thousands of clients on a weekly basis to assist with social services including, but not limited to courses on basic literacy, computers, ESL, etc.
Many clients however cannot afford to take relevant courses, nor afford the supplies necessary to do so. Funding should be allocated to provide clients with stipends specifically geared towards assisting the less fortunate to better themselves without allowing financial burden to be a deciding factor in doing so.
image
6/33 SBS Support development of local Storefront / Facade Improvement Program
Community Board 4 is home to several commercial corridors that don't fall under the umbrella of a Business Improvement District (BID). While many businesses are in fact thriving in these neighborhoods, emphasis should be put on uniformity, and beautification of their store fronts as a means to promote even more customers.
image
7/33
DOB
Address illegal
According to data from NYC Open Data, so far
conversions and
the Department of Buildings has received
uses of buildings
22,763 illegal conversion complaints, the top
most common complaint. The second most
common complaint is Work Without a Permit,
which was the subject of 20,852 complaints.
The third most common complaint is faulty
single-use elevators with only 8,783 complaints.
With numbers like these, it is quite obvious that
illegal conversions and work without a permit
are problems that are plaguing our city. Since
2018, illegal conversion complaints have risen
3,053, and work without a permit complaints
have increased 4,587. In order to adequately
and promptly address these issues, it is
important that DOB receive funding to hire
more code enforcement inspectors.
8/33
SBS
Assist with on-site
Community Board 4 is a mecca for street food.
business compliance
While we pride ourselves on the eclectic nature
with City regulations
of our cuisines, the divide between street
vendors and brick and mortar establishments is
very clear. Many street vendors may not fully
understand City laws. I.e.: illegal dumping of
cooking oil/debris, significance of letter grades,
proximity to stores, etc. The request is for
specific emphasis to be put into workshops,
awareness, and literature specifically geared
towards street vendor laws; above all, these
initiatives should be in multiple languages
conducive with the communities they will serve.
9/33
DCP
Study land use and
CB4Q is experiencing overdevelopment at an
zoning to better
alarming rate. Existing one and two family
match current use
homes are demolished and replaced with high
or future
density buildings that are out of character with
neighborhood
the surrounding neighborhood. The existing
needs
infrastructure was built mainly for low density
housing and the additional units place an undue
strain on our fragile infrastructure. Requesting
that DCP evaluate the current zoning in CB4Q
taking into account the current state of our
infrastructure, and identify areas where zoning
changes would improve the quality of life for
our constituency.
12/33
EDC
Expand graffiti
The district continues to see a spike in graffiti.
removal services on
Community groups in conjunction with several
private sites
City agencies are doing their best to keep up via
cleaning events and initiatives, but funding is
still needed to expand on programs geared
towards graffiti removal.
18/33 NYCHA Expand tenant
protection programs
Tenant protection services are designed to preserve affordable housing by detecting and curtailing patterns and practices of landlord fraud. With the dramatic growth seen within CB4 our constituency is in need of extensive services that would help them to preserve their quality of life. Funding is being requested for expansion of these programs.
image
28/33 DOB Assign additional
building inspectors (including expanding training programs)
In 2018, there were 165,988 permits issued by DOB, and in the first three quarters of 2019, 120,668 ,putting us on track to meet or exceed last year’s numbers. With the rapid increase in development, it is crucial that DOB has enough building inspectors and staff to adequately ensure the safety of the over 1.1 million buildings in NYC. In FY 19, the average response time for Priority B complaints was 11.4 days.
While Priority B complaints aren’t life threatening, they can be indicators that something is unsafe. No matter what we say in an attempt to please the case for more funding, no one said it better than former DOB Commissioner Rick Chandler, who in a 2018 interview said “I think if we had ten times the resources…, we would still be just making a dent.”
image
29/33 NYCHA Provide emergency
housing for households displaced by fires or City-issued vacate orders
Our catchment area is densely populated with a wide variety of various ethnic groups comprised of children, adults and seniors. Funding is needed to provide assistance with emergency displacement as a result of fires or vacate orders. The Red Cross and NYCOEM offer some assistance to those in crises by addressing immediate needs, but more is needed. In 2017, firefighters responded to a building fire in which over 100 apartments were extensively damaged. Although a temporary center for those affected was set up at a nearby school, the aftermath of the disaster lingered on for several months. CB4 is requesting an agency be formed designated with the task of relocation assistance and advisory services to minimize the impact of adversity in a more timely manner.
TRANSPORTATION
Queens Community Board 4
image
M ost Important Issue Related to Transportation and Mobility
Subway crowding and quality issues
In 2015, TIme Magazine's Lonely Planet issue featured Queens as the 1 tourist destination in the country. More over, when accessing the raw numbers at most of our train stations, it is evident that the majority of the tourism is right here in Corona and Elmhurst. With the USTA hosting close to 2 million people at the US Open, the Hall of Science's MakerFair at close to 100,00, and the countless numbers of parades and events within FMCP, it is evident that we are at the center of NYC tourism. The N line in Astoria recently underwent beautification to its stations, whereas heavily used stations such as 111th Street have seen no improvement to neither access, nor appearance. While Citifield is outside of district confines, several adjacent stations to the stadium I.e.: 103 St see an influx of riders who often get off several stops before the stadium to sample the local cuisine, and bring tourism to the area.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Due to the recent uptick of public events within the district, specifically around Flushing Meadows Corona Park, the department has put substantial resources into traffic mitigation and constituent safety. Implementation of the long awaited Queens Boulevard Traffic Safety plan has begun, and Broadway from Queens Boulevard into Jackson Heights will soon see traffic and safety improvements along the corridor. In conjunction with these improvements and Vision Zero, fatalities and injuries for pedestrians, cyclists, and motorists alike will likely continue to dwindle.
Community Board 4 however has expressed concern over the potential proliferation of bike lanes throughout the district, specifically in corridors where vehicles and cyclists have never shared roads. While it is universally understood that our streets should be safe for all, the specifics on how bike lanes are supposed to be properly used is still unclear to many of our constituents. Cyclists and motorists alike actively ignore rules of the road, i.e.: helmets are rarely worn, cell phones are actively used, and motorized vehicles (i.e. motorcycles, scooters) feel that they can freely use bike lanes as a means of travel. While NYC’s Vision Zero campaign has proactively initiated substantial educational community outreach, lawmakers should now work on a campaign geared towards holding cyclists accountable for the laws governing bicycles within the district through education. While good for revenue on a small scale, an increase in cyclist summonses since Vision Zero’s inception simply just states that cyclists themselves may not even know the laws, or worse, feel like they are above them. The solution is not simply about more summonses or lanes, but about more education for cyclists and motorists alike. The Vision Zero initiative at its most basic level should be more aggressively phased into our Elementary, Junior and High School curriculum.
Needs for Transit Services
We have included two requests related to subway service in this Needs & Budget Request. The first, our Board's highest Transportation priority, is for the rehabilitation of most of the subway stations in QCB4, and is addressed in detail above. We also consider increasing the number of accessible stations an urgent need. Woodhaven Blvd Station (M & R), which serves two major shopping malls and many bus lines should be made accessible as soon as possible; we recognize that the street configuration above the station is challenging. We urge the MTA, in considering station rehabs, to try to co-ordinate ADA construction so that inconvenience to passengers is minimized.
We have in the past pointed to the need for more and better bus service in our neighborhoods, especially in the area of the two major malls on Queens Blvd; we look forward to the upcoming Queens Bus System Redesign, and hope it will address our concerns, or that we will have the opportunity for input as the Redesign moves forward.
Finally, in past years we have strongly supported the MTA Capital Plan's budget item for the re-opening of the LIRR Elmhurst Station on the Port Washington Line. We were extremely disappointed to learn that the funds allocated to this project in the last Capital Plan had been applied elsewhere, and that the project is not now considered "alive"
by the MTA. The growth in population and commerce in the area around the station and the need for additional transportation resources in case of emergency clearly warrant the reconstruction of the station. We urge the MTA to reconstitute this project, fund it, and pursue it to completion.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
6/41
DOT
Repair or construct
Capital funding is being requested to continue
new curbs or
repairing the substantial amount of damaged
pedestrian ramps
curbs throughout the district. Requesting an
increase in funding to the NYCDOT curb
replacement program/unit.
17/41
DOT
Roadway
This stretch of road adjacent to a major
114th St 43rd
maintenance (i.e.
highway (Grand Central Parkway) is in dire need
Av Roosevelt
pothole repair,
of a reconstruction. Curb replacement/creation
Av
resurfacing, trench
should be a priority. Coordination and
restoration, etc.)
conversation with State DOT should be looked
into.
21/41
DOT
Reconstruct streets
A complete reconstruction of this very heavily
Junction
utilized corridor from Roosevelt Avenue to the
Boulevard
Horace Harding Expressway should be looked
Roosevelt Av
into. Curb cuts, traffic mitigation plans, street
Horace
resurfacing, bus pads, and curb replacements
Harding
are all sorely needed to meet current and future
Expwy
demand.
26/41
NYCTA
Improve
Comprehensive study should be conducted
accessibility of
towards upgrades and handicap accessibility to
transit
these very heavily utilized stations. Grand
infrastructure, by
Avenue, Elmhurst Avenue, 82nd, 90th/Elmhurst
providing elevators,
Avenue, 103st (Corona Plaza) and 111th Street
escalators, etc.
30/41
DOT
Install streetscape
Requesting streetscape improvements to aid in
improvements
the beautification of commercial corridors
throughout the district specifically Junction
Blvd. bet Roosevelt Ave. & 43rd Ave. and 82nd
Street bet. Roosevelt Ave. & Baxter Ave. While
the 82nd Street BID does in fact maintain the
latter section, improvements to lighting, flood
mitigation, benches, planters etc. would be a
welcome addition to both sections of road in the
hopes that local businesses would benefit from
the beautification.
32/41
DOT
Repair or provide
Elmhurst is still filled with rich examples of life
new street lights
during the beginnings of our city. From the
Horse Brook House of the 1700s, to the
discovery of the Iron Coffin Lady, our history is
on full display. Corona is also rich with history.
Corona Plaza sits on what was formerly the
Fashion Race Course, where the first baseball
games to charge admission were held in 1858.
These games are commonly recognized as the
starting point for professional baseball. In
recognition of this amazing history, our
community would benefit from having more
historical looking street lights. We are
requesting that our street lights be replaced
with Type M Luminaire & Pole, which were first
introduced in 1908 and designed to light wide
street corners.
33/41
DOT
Install streetscape
Improvements to lighting, flood mitigation
improvements
services, planters etc. would be a welcome
addition to both sections of road in the hopes
that local businesses and residents would
benefit from the beautification.
34/41
DOT
Repair or provide
The entire stretch that CB4Q covers where the
new street lights
lights are facing the sidewalk, an extension arm
is needed as dark patches exist. While we
understand that Phase 1 is completed from
111th Street to 82nd Street funding is needed to
proceed with Phase 2 which is all of Roosevelt
Avenue. Additionally, we are requesting lighting
on 108th Street from Roosevelt Avenue to 44th
Avenue as these intersections are extremely
dark for those walking or accessing the Q23
Bus.
39/41
DOT
Upgrade or create
The neighborhood of South Elmhurst does not
new plazas
currently have a plaza for community members
to congregate. Much like Diversity Plaza in
Jackson Heights, and Corona Plaza in Corona,
Elmhurst residents and businesses alike would
benefit from a plaza to increase tourism, and
hold events including the ongoing community
need for a farmer's market. Funding is being
requested for identifying, and acquiring land to
build such a plaza in this up and coming
neighborhood.
41/41
NYCTA
Repair or upgrade
Reopen a Train Station on Broadway in Queens
Broadway
subway stations or
for the MTA LIRR Due to heavy public
and Whitney
other transit
transportation needs, CB4Q is requesting the
Avenue
infrastructure
reopening of a train station on the MTA LIRR
Port Washington Line on Broadway in Queens.
CS
DOT
Reconstruct streets
Reconstruction of streets in the surrounding
41st Avenue
area of 41st Avenue and Roosevelt Avenue
Roosevelt
Avenue
CS
DOT
Roadway
The streets within this area (Grand Avenue 57th
57th Ave
maintenance (i.e.
Avenue, Queens Boulevard) are in great
Grand
pothole repair,
disrepair and many have no viable curbs or no
Avenue
resurfacing, trench
curbs at all.
Queens Blvd
restoration, etc.)
CS
DOT
Repair or construct
Some center island malls on 111th Street were
111th St
new curbs or
completely renovated, but the remaining malls
Sautell Ave
pedestrian ramps
are in need of a complete overhaul. The curbs
43rd Ave
should be raised as part of the reconstruction so
that illegal parking can be discouraged, and
trees and shrubbery should be planted to better
the quality of life for residents facing the malls.
With the new school construction at the New
York Hall of Science, traffic mitigation studies
should be considered.
CS
DOT
Upgrade or create
Renovation of Corona Plaza Funding has been
new plazas
allocated by CM Ferreras of CD21. *Continued
Support
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
10/33
DOT
Improve traffic and
Enforcement efforts/ Traffic agents at following:
pedestrian safety,
Congested corners during evening rush hour.
including traffic
Population, traffic, funding to meet current and
calming (Expense)
future demands specifically: Junction Blvd and
the Horace Harding Expressway Roosevelt
Avenue and 74th, 75th, & 104th Streets.
Additionally, this additional personnel would
help to better enforce issues with electric
scooters, illegally parked casino buses, and
misuse of bicycle lanes by unauthorized
vehicles.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 4
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
One of the more pressing issues that CB4Q faces on a day to day basis is the loss and/or lack of valuable green space. While we encourage and welcome the attention and tourism, we cannot forget that local residents, both elderly and young should be entitled to an escape in the form of green space. While we do have a number of parks within our district, many of them need to be re-sodded/ replaced with synthetic turf, have play equipment in dire need of repair/upgrade, or need to be redesigned to accurately reflect their usage and the needs of the community. As the number of Americans suffering from obesity steadily rises, it is important that the residents of CB4Q have safe, modern and fun places to go to get exercise and stay healthy. The rampant smoking and gambling within our parks is an ongoing issue that is sadly not being properly addressed by the responsible agencies. Informational campaigns to discourage such behavior with proper enforcement (PEP, CBO's, Task Forces, NYPD/ NCO's) to back it would be of a great benefit to our District.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
With the recent audit of the USTA revealing a shortchange of revenue to Flushing Meadows Corona Park, parks and their significance in our community have become even more vital. Neighborhood parks in our district serve as backyards for many and as the backdrop for athletic skills being developed, healthy living being promoted, and community being engaged. The renovations of many parks this year highlighted the dire condition the other parks are in. As CB3 fights to promote more dog friendly amenities, we at CB4 echo their sentiment with a need for additional dog runs and education to inspire responsible pet ownership.
Needs for Cultural Services
As was evidenced from our screening of The Woman in the Iron Coffin with the community, we need to educate more people about the significant history that Elmhurst and Corona contain. Several parks with significant historical meaning often have their history forgotten due to lack of properly displayed information. With the increase in development geared towards promoting tourism specifically around Elmhurst, historical facts can easily be forgotten. At the very least, proper signage should be implemented at key locations (parks and cemeteries) throughout the district as is done in Manhattan. Emphasis should be put into the multitude of parks scattered throughout our Board as a starting point as these parks are often historical pillars that tell stories of Elmhurst, Newtown and Corona. Furthermore, applications for landmarks, such as historic Judge Street are often overlooked, and denied, a practice that will only serve to further hide the rich past that makes up CB4.
Needs for Library Services
With the amount of new schools and pre kindergartens within our district, we feel that the need for a library within the confines of South Corona would be a very welcome addition to the local community. While the Corona and Lefrak branches have seen recent upgrades, the community at large would like a branch within the vicinity of PS14, the HS of Arts and Business, and several newly proposed pre k facilities all within the South Corona area.
Needs for Community Boards
Community Boards are volunteer heavy organizations widely considered to be the City's front line of defense; we manage countless constituent issues, zoning variances, public meetings, and of course Needs Statements.
Despite this heavy responsibility, staffing for many CB's is grossly inadequate for the amount of work
output, causing many of them to resort to interns as a primary source of help. Budget constraints have led many boards to maintain a maximum of 2-3 staff members, usually with only one full timer.
An increase in funding is sorely needed to increase current staffing.
For the 2nd year in a row, CB's have received City Council stipends meant to empower and strengthen Board and community relations. It must be noted however, that while upgrades to our offices are welcome, the real need remains in staffing more so since our responsibilities and outreach capabilities have increased because of this stipend.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/41
QL
Create a new, or
The population of Community Board 4Q is
Corona
renovate or upgrade
growing daily. Although the Elmhurst Library
Avenue 108th
an existing public
was recently rebuilt, both this branch and the
Street
library
Lefrak City Library will continue to be heavily
utilized. A new reference library in the vicinity of
108th Street and Corona Avenue will help
service the south east portion of CB4Q which is
currently lacking library services.
2/41
DPR
Reconstruct or
This park, close to 2 acres services students
46 Avenue,
upgrade a park or
from several local elementary schools, and
Queens, New
playground
eventually a new pre-k with a projected
York, NY
completion of 2021. During the summer
months, the Kids in Motion program is at this
location. As such, in order to enjoy the park to
its full capacity, funding should be allocated to
upgrade / repair the existing fitness equipment
which is grossly underutilized.
3/41
DPR
Reconstruct or
Residents of the community have been jogging
upgrade a park or
along the outdoor perimeter of Newtown Field
amenity (i.e.
(92nd Street and 57 Avenue) for years as no
playground, outdoor
official track exists within the area. However, a
athletic field)
mere 3 blocks away, and sitting directly on the
border of CB's 4, 5, and 6 is Hoffman Park, a
heavily used 3 acre park. The existing underused
softball field is a prime location for a proper
jogging track. Ideally, funding can also be used
to alleviate the prominent floor cracks that can
be seen throughout the basketball, handball,
and baseball field. Implementation of a dog run
would be a benefit to the local community as
minimal space exists for this. Additionally, the
area surrounding the handball courts is a dark,
dangerous, and structurally unsafe (cracks, tree
roots lifting floors, etc.)
5/41
DPR
Reconstruct or
Frank O' Connor Playground's adjacency to
7901
upgrade a parks
Elmhurst Hospital puts this park in the heart of
Broadway,
facility
a very busy corridor that sees a substantial
Queens, New
amount of foot traffic and park goers. However,
York, NY
issues are present with the comfort stations,
overall lack of shrubbery, and upgrading of the
outdated playground equipment. Additionally,
the basketball and handball courts see high
usage, and would benefit from refurbishing.
10/41
DCLA
Other cultural
The community of Elmhurst is rich in cultural
facilities and
history with many buildings dating back to the
resources requests
1700’s. One of the first religious buildings in
(Capital)
Newtown was the old St. James Episcopal
Church, and is Elmhurst’s oldest remaining
building. Other distinctive buildings in the
community include Newtown HS, and the Elks
Lodge. Not only does the community boast
architecture from the 1890s, it is rich in artifacts
dating back to an African cemetery in the 1800s
located on 90th St. We are requesting a
museum in the Elmhurst community to
showcase and preserve the past of a community
well-endowed with an abundance of historical
significance for generations to come.
11/41
DPR
Reconstruct or
At just over 3 acres, and located at the
upgrade a park or
northernmost border of Community Board 4,
amenity (i.e.
Park of the Americas is in need of refurbishing.
playground, outdoor
The very pressing issue of intoxicated visitors
athletic field)
within the park has gotten out of hand.
Measures should be taken to discourage such
activity. Security measures (benches, LED
lighting, security cameras, etc.) are all very
welcome additions to this park that is located
directly across from an elementary school.
While we understand that funding has already
been allocated to upgrading playground
equipment, and the synthetic softball field,
funding should be allocated to the remainder of
the park, specifically the heavily used basketball
courts, and seating area(s).
15/41
DPR
Reconstruct or
Requesting funding be allocated for the
90th St and
upgrade a park or
renovation of Triangle 90 (90th Street and
Roosevelt Ave
amenity (i.e.
Roosevelt Avenue) and Answer Triangle (94th
playground, outdoor
Street and Roosevelt Avenue). These two small
athletic field)
parks within very close proximity to each other
could essentially be funded as a package deal.
The commercial corridor of Roosevelt is in need
of several infrastructural upgrades, so a
superficial renovation to these two key parks
along the corridor would be a welcome addition
and an asset to local businesses and residents.
16/41
DPR
Reconstruct or
Funding is being requested to help with phase 2
upgrade a park or
of the adaptive renovation for Fountain of the
amenity (i.e.
Fairs and reflecting pools at FMCP.
playground, outdoor
athletic field)
22/41
DPR
New equipment for
Requesting funding for parks maintenance
maintenance
vehicles: 4x4 crew cab, salt spreader, and
(Capital)
powerlift gate (Ford-F 250) 4x4 single cab pick
up with plow, powerlift gate, and
"dumperdogg" attachment
23/41
DPR
Reconstruct or
Middleburgh Triangle is a small triangle located
90th Street
upgrade a park or
at the intersection of Corona Avenue, 90th
48th avenue
amenity (i.e.
Street and 48th Avenue. This triangle even
and Corona
playground, outdoor
though maintained, is a key historical location
Avenue
athletic field)
that would benefit from minor infrastructural
upgrades. Benches for the bus stop, shrubbery,
and historical signs emphasizing the
neighborhood change from Middleburgh to
Hastings to Newtown to present day Elmhurst
should be emphasized as they showcase the rich
history of our community. Additionally, Horse
brook, Aske and Libra Triangles are all sites
which tell a story of the rich history of our
community. At the very least these facts should
be included as part of the redesign of these
small parks which should include benches,
plantings/beautification, and historical facts via
proper signage.
31/41
DPR
Provide a new or
As of the 2010 Census, there were 37, 711
expanded parks
children under the age of 18 within CB4.
facility, e.g.
Childhood obesity rates have soared within the
recreation center
US over the last three decades. As a community
more needs to be done to improve the health of
our children. Studies have shown that having
recreational afterschool programs greatly
reduces childhood obesity, and improves
cardiorespiratory health in children. While our
bordering Community Boards have Lost
Battalion Hall and Al Oerter Recreation Centers,
CB4 is sorely lacking in a Parks department
operated Recreation Center. Between the
numerous athletic programs that can be
offered, to the technology and coding programs
offered in the media labs, a recreation center is
a valuable resource that can improve our
children’s minds and bodies.
37/41
DPR
Reconstruct or
Manuel de Dios Triangle has been a popular
Please search
upgrade a park or
location of our community to meet for years,
for a facility
playground
placed at a convenient intersection between
or park in
restaurants, supermarkets, and local businesses
your borough
along Roosevelt avenue. However, the
or enter an
placement of the elevated park at the center of
address
the triangle represents poor urban planning, as
manually...
it reduces the space where community members
can meet by dividing the park. Money for this
project would allow us to transform this raised
park into a communal space with additional
seating.
38/41
DPR
Reconstruct or
Lack of park upkeep of Nine Heroes Plaza has
upgrade a park or
turned what was once an enjoyable park to an
playground
often-avoided block attracting primarily
homeless community members. Nine Heroes
plaza is in desperate need of investment from
the city. An investment would allow us to make
over the space by cleaning the park and
planting additional greenery attracting new
community members to enjoy the park.
CS
DPR
Reconstruct or
William F. Moore Park is a small park in the
107-06
upgrade a park or
heart of Corona. The park, adjacent to the
Corona
amenity (i.e.
famous Parkside Restaurant and the Lemon Ice
Avenue
playground, outdoor
King of Corona is in need of renovation.
athletic field)
Improvements to the existing flag pole,
additional shrubbery/plantings, and overall
infrastructural improvements would be a
welcome addition to the surrounding
community. Upgrades to the bocce ball are
needed as well as proper drainage for the
residual clay from the court that can be seen all
throughout the park and its surrounding
sidewalk(s). The addition of a performing stage
is also needed as this park sees regular
programming
CS
DPR
Reconstruct or
While Newtown Playground recently underwent
upgrade a park or
renovation, several community concerns
amenity (i.e.
remain. The park's proximity to the Queens
playground, outdoor
Center Mall and Newtown HS ensure that the
athletic field)
park maintains a steady flow of visitors and
passersby. There are concerns regarding access
to the comfort stations. There is also a lack of
historical signage explaining the parks history.
Requesting continued support until installation
of historical signage.
CS QL Create a new, or renovate or upgrade an existing public library
While the building housing the Elmhurst library is deemed complete, the community still has concerns over the lack of green space around the facility. An outdoor sitting/community area would be a proper utilization of the existing vacant space towards the rear of the library.
image
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Clement C Moore Playground is a heavily utilized playground in the heart of Elmhurst. The design is however obsolete. Issues with smoking, gambling, gang activity, rundown bathroom facilities, homeless, and drinking are all commonplace at this park. Measures to discourage such activities (i.e.: security cameras, benches, open areas) should be considered during the next design phase of the park.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/33
OMB
Provide more
The constituents of CB4 require multiple needs
community board
and services. Additional funding is being
staff
requested to expand our organizing capacity by
hiring an additional staff member.
11/33
DPR
Forestry services,
There is a backlog of requests for tree pruning.
including street tree
The current pruning cycle is far too long.
maintenance
Funding is needed to shorten this cycle, and to
restore pruner and climber positions to the DPR.
A shorter year pruning cycle will produce
stronger, healthier, and better looking trees. A
strong maintenance program is needed to care
for existing trees and for the continuation of the
million additional trees that are to be planted in
NYC.
13/33
DPR
Forestry services,
Trees are a vital component of our environment.
including street tree
Homeowners affected by tree roots lifting
maintenance
sidewalks should not have to wait years before
repairs are completed. Although funding has
increased in the past, an additional increase in
FY 2021 is requested to help complete the
existing backlog of requests.
16/33
DPR
Provide better park
The large amount of parks within the district
maintenance
combined with the lack of proper personnel to
maintain them continues to be a problem
throughout the district. Requesting additional
parks maintenance personnel, Parks
Enforcement Police (PEP), foresters to meet
current and future needs. Police barricades
throughout the park as well as the closure of
the Queens Museum of Art (QMA) during key
events is a deterrent, and not a welcome to park
goers.
21/33
QL
Extend library hours
Community Board 4Q's catchment area of
or expand and
Corona, Corona Heights, and Elmhurst is
enhance library
densely populated with a wide variety of ethnic
programs
groups comprised of children, adults, and senior
citizens. Our library branches and programs the
libraries provide are heavily utilized. We will
continue to support six day service, look to
support 7 day service when applicable.
24/33
DCLA
Provide more public
Public art serves as a means to deter graffiti
art
within our parks. More funding should be
allocated to grants specifically geared towards
public art. Funding should effectively cover both
initial implementation as well as continued
maintenance of projects for consecutive years.
30/33
DCLA
Support nonprofit
We are fortunate to share experiences with
cultural
people of many nations. Immigrants from Asia
organizations
and Latin America have made Elmhurst the
most diverse part of Queens. Following World
War II, Elmhurst became one of the most
ethnically diverse neighborhoods as immigrants
arrived from new areas. By the 1980s, there
were people from 112 nations residing in the
district. Meanwhile, Corona in the 1950s was
predominately Italian and African American
which began to change in the late 1990s, when
immigrants from Latin America arrived. To
support the past and ever growing history of our
changing neighborhoods, CB4 is requesting
funding to help support our cultural
organizations tasked with documenting,
preserving, and promoting awareness of the
past and future development and growth of our
iconic community.
Other Capital Requests
Priority Agency Request Explanation Location
image
35/41 Other Other capital budget
request
CB4 takes in numerous complaints about unsightly, dangerous downed wires on a daily basis. Since each company maintains responsibility for its own line, it is very difficult to determine which company is responsible to service the problem. Downed lines can stay unserved indefinitely on our city streets. To the average person, there is no way to determine if a downed wire is high voltage or benign, which poses the key question of safety. Fallen wires can electrocute or cause fires. Our constituents should not be put in a position where their safety is at risk.Trained workers are needed to climb utility poles to perform maintenance Requesting access to an agency held accountable for this maintenance.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/41
QL
Create a new, or
The population of Community Board 4Q is
Corona
renovate or upgrade
growing daily. Although the Elmhurst Library
Avenue 108th
an existing public
was recently rebuilt, both this branch and the
Street
library
Lefrak City Library will continue to be heavily
utilized. A new reference library in the vicinity of
108th Street and Corona Avenue will help
service the south east portion of CB4Q which is
currently lacking library services.
2/41
DPR
Reconstruct or
This park, close to 2 acres services students
46 Avenue,
upgrade a park or
from several local elementary schools, and
Queens, New
playground
eventually a new pre-k with a projected
York, NY
completion of 2021. During the summer
months, the Kids in Motion program is at this
location. As such, in order to enjoy the park to
its full capacity, funding should be allocated to
upgrade / repair the existing fitness equipment
which is grossly underutilized.
3/41
DPR
Reconstruct or
Residents of the community have been jogging
upgrade a park or
along the outdoor perimeter of Newtown Field
amenity (i.e.
(92nd Street and 57 Avenue) for years as no
playground, outdoor
official track exists within the area. However, a
athletic field)
mere 3 blocks away, and sitting directly on the
border of CB's 4, 5, and 6 is Hoffman Park, a
heavily used 3 acre park. The existing underused
softball field is a prime location for a proper
jogging track. Ideally, funding can also be used
to alleviate the prominent floor cracks that can
be seen throughout the basketball, handball,
and baseball field. Implementation of a dog run
would be a benefit to the local community as
minimal space exists for this. Additionally, the
area surrounding the handball courts is a dark,
dangerous, and structurally unsafe (cracks, tree
roots lifting floors, etc.)
4/41
NYPD
Renovate or
The building now housing the 110 Precinct is
94-41 43rd
upgrade existing
inadequate. The precinct House is in a densely
Avenue
precinct houses
populated residential area with limited street
access and no viable parking for police vehicles.
This project was projected for funding since FY
2013, but has since made no progress.
Renovation to this facility is desperately needed.
5/41
DPR
Reconstruct or
Frank O' Connor Playground's adjacency to
7901
upgrade a parks
Elmhurst Hospital puts this park in the heart of
Broadway,
facility
a very busy corridor that sees a substantial
Queens, New
amount of foot traffic and park goers. However,
York, NY
issues are present with the comfort stations,
overall lack of shrubbery, and upgrading of the
outdated playground equipment. Additionally,
the basketball and handball courts see high
usage, and would benefit from refurbishing.
6/41
DOT
Repair or construct
Capital funding is being requested to continue
new curbs or
repairing the substantial amount of damaged
pedestrian ramps
curbs throughout the district. Requesting an
increase in funding to the NYCDOT curb
replacement program/unit.
7/41
HHC
Provide a new or
With the former St. John's Hospital now closed,
expanded health
the residents of South Elmhurst and its
care facility
surrounding vicinity are in need of a medical
facility. Elmhurst Hospital is operating beyond
capacity, and is struggling to keep up with the
demand. The need for a medical center in the
neighborhood of South Elmhurst cannot be
overlooked.
8/41
HHC
Provide a new or
Requesting a rehabilitation center within the
expanded health
confines of Community Board 4. Drug & alcohol
care facility
counseling, mental health, and physical therapy
services could be just some of the services
offered.
9/41
NYPD
Provide surveillance
Several sectors within the district are in need of
cameras
added security measures, specifically the
corners spanning the entire stretch of Roosevelt
Avenue, the adjoining Junction Boulevard, and a
high-crime section of 57th Avenue between
99th Street and Junction Blvd. Requesting that
surveillance cameras be funded.
10/41
DCLA
Other cultural
The community of Elmhurst is rich in cultural
facilities and
history with many buildings dating back to the
resources requests
1700’s. One of the first religious buildings in
(Capital)
Newtown was the old St. James Episcopal
Church, and is Elmhurst’s oldest remaining
building. Other distinctive buildings in the
community include Newtown HS, and the Elks
Lodge. Not only does the community boast
architecture from the 1890s, it is rich in artifacts
dating back to an African cemetery in the 1800s
located on 90th St. We are requesting a
museum in the Elmhurst community to
showcase and preserve the past of a community
well-endowed with an abundance of historical
significance for generations to come.
11/41
DPR
Reconstruct or
At just over 3 acres, and located at the
upgrade a park or
northernmost border of Community Board 4,
amenity (i.e.
Park of the Americas is in need of refurbishing.
playground, outdoor
The very pressing issue of intoxicated visitors
athletic field)
within the park has gotten out of hand.
Measures should be taken to discourage such
activity. Security measures (benches, LED
lighting, security cameras, etc.) are all very
welcome additions to this park that is located
directly across from an elementary school.
While we understand that funding has already
been allocated to upgrading playground
equipment, and the synthetic softball field,
funding should be allocated to the remainder of
the park, specifically the heavily used basketball
courts, and seating area(s).
12/41
FDNY
Rehabilitate or
Continue funding for complete analyzation, and
renovate existing
reparation of firehouses within the district.
fire houses or EMS
Engine 287 Ladder 136 Battalion 46 86-53
stations
Grand Avenue Elmhurst, NY 11373
13/41
NYPD
Add NYPD parking
For years, Community Board 4Q has requested
facilities
dedicated vehicle parking for the 110 Precinct
vehicles. Currently no off street parking is
available for NYPD vehicles.
14/41
HPD
Provide more
Community Board 4 has seen a very steady
housing for
influx of new residents in the last few years, and
extremely low and
will only continue to grow at a steady pace. The
low income
lack of affordable housing is encouraging
households
"shacking up" in which large families are living
out of single rooms and illegally converted
basements. An Affordable Housing facility is
desperately needed for both the convenience,
and the safety of CB4's residents.
15/41
DPR
Reconstruct or
Requesting funding be allocated for the
90th St and
upgrade a park or
renovation of Triangle 90 (90th Street and
Roosevelt Ave
amenity (i.e.
Roosevelt Avenue) and Answer Triangle (94th
playground, outdoor
Street and Roosevelt Avenue). These two small
athletic field)
parks within very close proximity to each other
could essentially be funded as a package deal.
The commercial corridor of Roosevelt is in need
of several infrastructural upgrades, so a
superficial renovation to these two key parks
along the corridor would be a welcome addition
and an asset to local businesses and residents.
16/41
DPR
Reconstruct or
Funding is being requested to help with phase 2
upgrade a park or
of the adaptive renovation for Fountain of the
amenity (i.e.
Fairs and reflecting pools at FMCP.
playground, outdoor
athletic field)
17/41
DOT
Roadway
This stretch of road adjacent to a major
114th St 43rd
maintenance (i.e.
highway (Grand Central Parkway) is in dire need
Av Roosevelt
pothole repair,
of a reconstruction. Curb replacement/creation
Av
resurfacing, trench
should be a priority. Coordination and
restoration, etc.)
conversation with State DOT should be looked
into.
18/41
DFTA
Create a new senior
With the growing, aging population within CB4,
center or other
the need for an assisted living facility cannot be
facility for seniors
overlooked. While Corona does in fact have such
a facility, the area of Elmhurst does not.
Requesting that resources be allocated to obtain
property, and build such a facility to house the
senior population of South Elmhurst.
19/41
SCA
Provide a new or
The lack of high schools within the district is a
expand an existing
cause for concern. With the recent influx of
high school
Elementary and Middle Schools throughout our
district, adding a new high school would help
our constituency stay closer to home and will
ease overcrowding within the SD24.
20/41
HPD
Provide more
Community Board 4 has seen a very steady
housing for medium
influx of new residents in the last few years, and
income households
will only continue to grow at a steady pace. An
emphasis throughout the district is being put
into low income housing, however, financial
burden does not pertain strictly to low income
households. Requesting funding to survey,
obtain land, and eventually build an affordable
housing facility for medium range income within
the district.
21/41
DOT
Reconstruct streets
A complete reconstruction of this very heavily
Junction
utilized corridor from Roosevelt Avenue to the
Boulevard
Horace Harding Expressway should be looked
Roosevelt Av
into. Curb cuts, traffic mitigation plans, street
Horace
resurfacing, bus pads, and curb replacements
Harding
are all sorely needed to meet current and future
Expwy
demand.
22/41
DPR
New equipment for
Requesting funding for parks maintenance
maintenance
vehicles: 4x4 crew cab, salt spreader, and
(Capital)
powerlift gate (Ford-F 250) 4x4 single cab pick
up with plow, powerlift gate, and
"dumperdogg" attachment
23/41
DPR
Reconstruct or
Middleburgh Triangle is a small triangle located
90th Street
upgrade a park or
at the intersection of Corona Avenue, 90th
48th avenue
amenity (i.e.
Street and 48th Avenue. This triangle even
and Corona
playground, outdoor
though maintained, is a key historical location
Avenue
athletic field)
that would benefit from minor infrastructural
upgrades. Benches for the bus stop, shrubbery,
and historical signs emphasizing the
neighborhood change from Middleburgh to
Hastings to Newtown to present day Elmhurst
should be emphasized as they showcase the rich
history of our community. Additionally, Horse
brook, Aske and Libra Triangles are all sites
which tell a story of the rich history of our
community. At the very least these facts should
be included as part of the redesign of these
small parks which should include benches,
plantings/beautification, and historical facts via
proper signage.
24/41
HPD
Other affordable
While the Department of Housing Preservation
housing programs
and Development (HPD) provide loan programs
requests (capital)
the increased need for such programs can not
be overlooked. Community Based Organizations
(CBO's) such as Neighborhood Housing Services
(NHS), do a great job in providing such services,
but the demand for increased programs is
exceedingly present specifically in low density
(2-3 family) homes.
25/41
SCA
Provide technology
Many schools within our district strongly need
upgrade
tech upgrades such as whiteboards, laptops,
calculators, tablets, etc. We are aware that the
newer schools came with a lot of these tech
upgrades already, so focus should be put
towards the remaining pre-existing schools.
26/41
NYCTA
Improve
Comprehensive study should be conducted
accessibility of
towards upgrades and handicap accessibility to
transit
these very heavily utilized stations. Grand
infrastructure, by
Avenue, Elmhurst Avenue, 82nd, 90th/Elmhurst
providing elevators,
Avenue, 103st (Corona Plaza) and 111th Street
escalators, etc.
27/41
HPD
Provide more
With the homeless crisis sweeping throughout
housing for special
the city, many communities have been seeing an
needs households,
increase in the number of shelters popping up
such as the formerly
within their constituencies. As these shelters
homeless
continue to increase, to avoid the homeless
crisis remaining stagnant it is important that
housing for formerly homeless as well as seniors
be provided.
28/41
NYPD
Provide a new NYPD
Requesting that a satellite precinct/ mobile unit
facility, such as a
be considered for the western side of Elmhurst,
new precinct house
specifically the commercial corridors
or sub-precinct
surrounding the Queens Place, and Queens
Center malls.
29/41
DHS
Expand street
Breaking Ground currently operates via 4
outreach
outreach teams in Queens 24/7/365 (in all
weather), as well as a case management staff
that participates in client transports to medical
appointments, housing appointments, housing
placements, etc., One of their biggest needs is
vehicles. While the agency does have a fleet,
vehicles' life spans are shorter than average
since their mileage racks up so quickly.
Requesting funding be allocated to an increase
in vehicles to continue providing this very
necessary service.
30/41
DOT
Install streetscape
Requesting streetscape improvements to aid in
improvements
the beautification of commercial corridors
throughout the district specifically Junction
Blvd. bet Roosevelt Ave. & 43rd Ave. and 82nd
Street bet. Roosevelt Ave. & Baxter Ave. While
the 82nd Street BID does in fact maintain the
latter section, improvements to lighting, flood
mitigation, benches, planters etc. would be a
welcome addition to both sections of road in the
hopes that local businesses would benefit from
the beautification.
31/41 DPR Provide a new or
expanded parks facility, e.g. recreation center
As of the 2010 Census, there were 37, 711 children under the age of 18 within CB4. Childhood obesity rates have soared within the US over the last three decades. As a community more needs to be done to improve the health of our children. Studies have shown that having recreational afterschool programs greatly reduces childhood obesity, and improves cardiorespiratory health in children. While our bordering Community Boards have Lost Battalion Hall and Al Oerter Recreation Centers, CB4 is sorely lacking in a Parks department operated Recreation Center. Between the numerous athletic programs that can be offered, to the technology and coding programs offered in the media labs, a recreation center is a valuable resource that can improve our children’s minds and bodies.
image
32/41 DOT Repair or provide
new street lights
Elmhurst is still filled with rich examples of life during the beginnings of our city. From the Horse Brook House of the 1700s, to the discovery of the Iron Coffin Lady, our history is on full display. Corona is also rich with history. Corona Plaza sits on what was formerly the Fashion Race Course, where the first baseball games to charge admission were held in 1858. These games are commonly recognized as the starting point for professional baseball. In recognition of this amazing history, our community would benefit from having more historical looking street lights. We are requesting that our street lights be replaced with Type M Luminaire & Pole, which were first introduced in 1908 and designed to light wide street corners.
image
33/41 DOT Install streetscape
improvements
Improvements to lighting, flood mitigation services, planters etc. would be a welcome addition to both sections of road in the hopes that local businesses and residents would benefit from the beautification.
image
34/41 DOT Repair or provide
new street lights
The entire stretch that CB4Q covers where the lights are facing the sidewalk, an extension arm is needed as dark patches exist. While we understand that Phase 1 is completed from 111th Street to 82nd Street funding is needed to proceed with Phase 2 which is all of Roosevelt Avenue. Additionally, we are requesting lighting on 108th Street from Roosevelt Avenue to 44th Avenue as these intersections are extremely dark for those walking or accessing the Q23 Bus.
image
35/41 Other Other capital budget
request
CB4 takes in numerous complaints about unsightly, dangerous downed wires on a daily basis. Since each company maintains responsibility for its own line, it is very difficult to determine which company is responsible to service the problem. Downed lines can stay unserved indefinitely on our city streets. To the average person, there is no way to determine if a downed wire is high voltage or benign, which poses the key question of safety. Fallen wires can electrocute or cause fires. Our constituents should not be put in a position where their safety is at risk.Trained workers are needed to climb utility poles to perform maintenance Requesting access to an agency held accountable for this maintenance.
image
36/41 EDC Build or expand
incubator or affordable work or research lab spaces
Immigrant owned small businesses are the backbone of our local economy. Studies show that immigrants have a higher rate of business ownership than non-immigrants, with roughly one out of ten immigrant workers owning a business. While our community has made significant progress supporting street vendors (through community based organizations and local elected officials supporting positive legislation), we still lack a clear pipeline for street vendors to open a small business. Our community would benefit from funding allowing us to establish a small business incubator that provides mentorship, training, and education.
Funding for this project would also allow us to
establish an incubator space.
image
37/41
DPR
Reconstruct or
Manuel de Dios Triangle has been a popular
Please search
upgrade a park or
location of our community to meet for years,
for a facility
playground
placed at a convenient intersection between
or park in
restaurants, supermarkets, and local businesses
your borough
along Roosevelt avenue. However, the
or enter an
placement of the elevated park at the center of
address
the triangle represents poor urban planning, as
manually...
it reduces the space where community members
can meet by dividing the park. Money for this
project would allow us to transform this raised
park into a communal space with additional
seating.
38/41
DPR
Reconstruct or
Lack of park upkeep of Nine Heroes Plaza has
upgrade a park or
turned what was once an enjoyable park to an
playground
often-avoided block attracting primarily
homeless community members. Nine Heroes
plaza is in desperate need of investment from
the city. An investment would allow us to make
over the space by cleaning the park and
planting additional greenery attracting new
community members to enjoy the park.
39/41
DOT
Upgrade or create
The neighborhood of South Elmhurst does not
new plazas
currently have a plaza for community members
to congregate. Much like Diversity Plaza in
Jackson Heights, and Corona Plaza in Corona,
Elmhurst residents and businesses alike would
benefit from a plaza to increase tourism, and
hold events including the ongoing community
need for a farmer's market. Funding is being
requested for identifying, and acquiring land to
build such a plaza in this up and coming
neighborhood.
40/41
DEP
Evaluate a public
Requesting more staffing for the maintenance
location or property
of the recently implemented Green
for green
Infrastructure initiative. Currently DEP staff is
infrastructure, e.g.
scheduled to maintain and clean these sites on a
rain gardens,
weekly basis, but a majority of our sites go for
stormwater
weeks, possibly months with no visits. Current
greenstreets, green
staffing is simply not enough. Requesting
playgrounds
funding to meet current and future demand.
41/41
NYCTA
Repair or upgrade
Reopen a Train Station on Broadway in Queens
Broadway
subway stations or
for the MTA LIRR Due to heavy public
and Whitney
other transit
transportation needs, CB4Q is requesting the
Avenue
infrastructure
reopening of a train station on the MTA LIRR
Port Washington Line on Broadway in Queens.
CS
DYCD
Provide, expand, or
The low allocation of funds within CB4 is
enhance after
surprising considering SD 24 is currently the
school programs for
most overcrowded in the city. There is a need
middle school
for after school programming for adolescents
students (grades 6-
grades 6-8 who at this stage in their lives need
8)
more aggressive mentoring and help with
school work.
CS
NYPD
Provide a new NYPD
Requesting that an NYPD satellite station be
facility, such as a
installed within the confines of Flushing
new precinct house
Meadows Corona Park to provide safety in this
or sub-precinct
heavily used large park. Some time last year,
with generous funding from the Queens
Borough President, makeshift trailers/ satellite
stations was installed in the park. However,
several concerns were raised specifically around
the potential lack of sufficient staffing.
CS
DPR
Reconstruct or
William F. Moore Park is a small park in the
107-06
upgrade a park or
heart of Corona. The park, adjacent to the
Corona
amenity (i.e.
famous Parkside Restaurant and the Lemon Ice
Avenue
playground, outdoor
King of Corona is in need of renovation.
athletic field)
Improvements to the existing flag pole,
additional shrubbery/plantings, and overall
infrastructural improvements would be a
welcome addition to the surrounding
community. Upgrades to the bocce ball are
needed as well as proper drainage for the
residual clay from the court that can be seen all
throughout the park and its surrounding
sidewalk(s). The addition of a performing stage
is also needed as this park sees regular
programming
CS
DPR
Reconstruct or
While Newtown Playground recently underwent
upgrade a park or
renovation, several community concerns
amenity (i.e.
remain. The park's proximity to the Queens
playground, outdoor
Center Mall and Newtown HS ensure that the
athletic field)
park maintains a steady flow of visitors and
passersby. There are concerns regarding access
to the comfort stations. There is also a lack of
historical signage explaining the parks history.
Requesting continued support until installation
of historical signage.
CS
DEP
Evaluate a public
85th Street abuts MTA /LIRR property. Green
85 Street
location or property
infrastructure is sorely needed in this area. DEP
55th Road
for green
has already conducted studies to consider this
57th Road
infrastructure, e.g.
location for green infrastructure, and has in fact
rain gardens,
identified it as a potential site. Seeking
stormwater
implementation and completion of this long
greenstreets, green
awaited / approved project.
playgrounds
CS
QL
Create a new, or
While the building housing the Elmhurst library
renovate or upgrade
is deemed complete, the community still has
an existing public
concerns over the lack of green space around
library
the facility. An outdoor sitting/community area
would be a proper utilization of the existing
vacant space towards the rear of the library.
CS
DOT
Reconstruct streets
Reconstruction of streets in the surrounding
41st Avenue
area of 41st Avenue and Roosevelt Avenue
Roosevelt
Avenue
CS
DPR
Reconstruct or
Clement C Moore Playground is a heavily
upgrade a park or
utilized playground in the heart of Elmhurst. The
amenity (i.e.
design is however obsolete. Issues with
playground, outdoor
smoking, gambling, gang activity, rundown
athletic field)
bathroom facilities, homeless, and drinking are
all commonplace at this park. Measures to
discourage such activities (i.e.: security
cameras, benches, open areas) should be
considered during the next design phase of the
park.
CS
DOT
Roadway
The streets within this area (Grand Avenue 57th
57th Ave
maintenance (i.e.
Avenue, Queens Boulevard) are in great
Grand
pothole repair,
disrepair and many have no viable curbs or no
Avenue
resurfacing, trench
curbs at all.
Queens Blvd
restoration, etc.)
CS
DOT
Repair or construct
Some center island malls on 111th Street were
111th St
new curbs or
completely renovated, but the remaining malls
Sautell Ave
pedestrian ramps
are in need of a complete overhaul. The curbs
43rd Ave
should be raised as part of the reconstruction so
that illegal parking can be discouraged, and
trees and shrubbery should be planted to better
the quality of life for residents facing the malls.
With the new school construction at the New
York Hall of Science, traffic mitigation studies
should be considered.
CS
DOT
Upgrade or create
Renovation of Corona Plaza Funding has been
new plazas
allocated by CM Ferreras of CD21. *Continued
Support
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/33
OMB
Provide more
The constituents of CB4 require multiple needs
community board
and services. Additional funding is being
staff
requested to expand our organizing capacity by
hiring an additional staff member.
2/33
SBS
Other expense
Several CBO's throughout the borough see
workforce
thousands of clients on a weekly basis to assist
development
with social services including, but not limited to
requests
courses on basic literacy, computers, ESL, etc.
Many clients however cannot afford to take
relevant courses, nor afford the supplies
necessary to do so. Funding should be allocated
to provide clients with stipends specifically
geared towards assisting the less fortunate to
better themselves without allowing financial
burden to be a deciding factor in doing so.
3/33
DOHMH
Reduce rat
There is a proliferation of rats being seen
populations
throughout the district. Funds are being
requested to continue programs such as Rat
Academy geared towards raising public
awareness.
4/33
DOHMH
Other programs to
Recently NYC was hit with the largest Measles
address public
outbreak in almost 30 years. Measles cases in
health issues
NYC accounted for more than half of the 1,234
requests
confirmed cases nationwide. This public health
crisis unfortunately proved how woefully
unprepared we are as a city to address
epidemics. The outbreak which lasted from
October 2018 until August 2019 cost the city
over $6 million dollars. Over 500 New York City
employees were deployed to battle the crisis.
With so many all over the city, it is obvious that
the Department of Health and Mental Hygiene
was horribly understaffed. We believe it is
imperative to the health of our city to increase
finding for DOHMH so that they can increase
staffing levels, as well as produce more
literature to address the growing anti-vaxxer
movement.
5/33
DSNY
Other cleaning
We support the ACE program that works as a
requests
supplement for existing street cleaning services.
Funding has allowed the program to effectively
canvas several commercial and residential
sectors of the district, and assist with cleanup
(sidewalk sweeping, scraping of utility poles,
garbage mitigation) Currently, the program
covers: - Diversity Plaza - 104th St. from
Roosevelt to Corona Aves. -108th Street from
Roosevelt to Corona Aves . -111th St /Roosevelt
Station - William F. Moore Park Requesting that
the Ace Program be considered for: 1. Broadway
from Cornish Ave. to Queens Blvd. 2. Queens
Blvd. E/B and W/B between Grand to Horace
Harding Expwy. 3. Corona Avenue (91st Pl. to
Queens Blvd) 4. Grand Ave from QB to Haspel
St.
6/33
SBS
Support
Community Board 4 is home to several
development of
commercial corridors that don't fall under the
local Storefront /
umbrella of a Business Improvement District
Facade
(BID). While many businesses are in fact thriving
Improvement
in these neighborhoods, emphasis should be put
Program
on uniformity, and beautification of their store
fronts as a means to promote even more
customers.
7/33
DOB
Address illegal
According to data from NYC Open Data, so far
conversions and
the Department of Buildings has received
uses of buildings
22,763 illegal conversion complaints, the top
most common complaint. The second most
common complaint is Work Without a Permit,
which was the subject of 20,852 complaints.
The third most common complaint is faulty
single-use elevators with only 8,783 complaints.
With numbers like these, it is quite obvious that
illegal conversions and work without a permit
are problems that are plaguing our city. Since
2018, illegal conversion complaints have risen
3,053, and work without a permit complaints
have increased 4,587. In order to adequately
and promptly address these issues, it is
important that DOB receive funding to hire
more code enforcement inspectors.
8/33
SBS
Assist with on-site
Community Board 4 is a mecca for street food.
business compliance
While we pride ourselves on the eclectic nature
with City regulations
of our cuisines, the divide between street
vendors and brick and mortar establishments is
very clear. Many street vendors may not fully
understand City laws. I.e.: illegal dumping of
cooking oil/debris, significance of letter grades,
proximity to stores, etc. The request is for
specific emphasis to be put into workshops,
awareness, and literature specifically geared
towards street vendor laws; above all, these
initiatives should be in multiple languages
conducive with the communities they will serve.
9/33
DCP
Study land use and
CB4Q is experiencing overdevelopment at an
zoning to better
alarming rate. Existing one and two family
match current use
homes are demolished and replaced with high
or future
density buildings that are out of character with
neighborhood
the surrounding neighborhood. The existing
needs
infrastructure was built mainly for low density
housing and the additional units place an undue
strain on our fragile infrastructure. Requesting
that DCP evaluate the current zoning in CB4Q
taking into account the current state of our
infrastructure, and identify areas where zoning
changes would improve the quality of life for
our constituency.
10/33
DOT
Improve traffic and
Enforcement efforts/ Traffic agents at following:
pedestrian safety,
Congested corners during evening rush hour.
including traffic
Population, traffic, funding to meet current and
calming (Expense)
future demands specifically: Junction Blvd and
the Horace Harding Expressway Roosevelt
Avenue and 74th, 75th, & 104th Streets.
Additionally, this additional personnel would
help to better enforce issues with electric
scooters, illegally parked casino buses, and
misuse of bicycle lanes by unauthorized
vehicles.
11/33
DPR
Forestry services,
There is a backlog of requests for tree pruning.
including street tree
The current pruning cycle is far too long.
maintenance
Funding is needed to shorten this cycle, and to
restore pruner and climber positions to the DPR.
A shorter year pruning cycle will produce
stronger, healthier, and better looking trees. A
strong maintenance program is needed to care
for existing trees and for the continuation of the
million additional trees that are to be planted in
NYC.
12/33
EDC
Expand graffiti
The district continues to see a spike in graffiti.
removal services on
Community groups in conjunction with several
private sites
City agencies are doing their best to keep up via
cleaning events and initiatives, but funding is
still needed to expand on programs geared
towards graffiti removal.
13/33
DPR
Forestry services,
Trees are a vital component of our environment.
including street tree
Homeowners affected by tree roots lifting
maintenance
sidewalks should not have to wait years before
repairs are completed. Although funding has
increased in the past, an additional increase in
FY 2021 is requested to help complete the
existing backlog of requests.
14/33
DSNY
Increase
Several commercial corridors and their
Roosevelt Ave
enforcement of
surrounding areas are infamous for illegal
72nd St 114th
illegal posting laws
postings on utility poles, walls, and construction
St
fences. The entire stretch of Roosevelt Avenue
from 72nd Street to 114th Street and its
adjacent side streets are havens for these
postings. Business owners do their best to
remove these flyers, but with virtually no
enforcement, it is a losing and discouraging
battle. Postings vary from illegal apartment
rentals, to vehicle sales to fitness classes. These
forms of advertisement are dangerous, unjust,
and often advertise illegal services. More
stringent enforcement should be implemented.
15/33
NYPD
Provide additional
Requesting 2 to 3 unmarked vehicles to meet
patrol cars and
current and future needs.
other vehicles
16/33
DPR
Provide better park
The large amount of parks within the district
maintenance
combined with the lack of proper personnel to
maintain them continues to be a problem
throughout the district. Requesting additional
parks maintenance personnel, Parks
Enforcement Police (PEP), foresters to meet
current and future needs. Police barricades
throughout the park as well as the closure of
the Queens Museum of Art (QMA) during key
events is a deterrent, and not a welcome to park
goers.
17/33
FDNY
Expand funding for
The FDNY Fire Safety Educational Unit needs
fire prevention and
additional funding to provide smoke detectors
life safety initiatives
and carbon monoxide detectors for distribution
to the public. This is a public service that will
save lives.
18/33
NYCHA
Expand tenant
Tenant protection services are designed to
protection programs
preserve affordable housing by detecting and
curtailing patterns and practices of landlord
fraud. With the dramatic growth seen within
CB4 our constituency is in need of extensive
services that would help them to preserve their
quality of life. Funding is being requested for
expansion of these programs.
19/33
DOHMH
Other animal and
With mosquito-borne illnesses such as Zika, and
pest control
West Nile within our communities, funding
requests
request would entail more staffing, and the
continuation of public awareness campaigns to
teach prevention in multiple languages. Our
public plazas and abandoned properties are
particularly vulnerable to rats. Requesting
funding to increase awareness, and mitigation
of pests (rats and mosquitoes) throughout the
community.
20/33
DOHMH
Create or promote
The communities of Elmhurst and Corona both
programs for
see farmers' markets, and several campaigns
education and
geared towards condoning walking, and riding
awareness on
vs driving. Our communities would like to
nutrition, physical
continue to see expansions of programs (WIC at
activity, etc.
farmers' markets, bike helmet giveaways, health
insurance, etc.) Material and outreach should
be emphasized in multiple languages conducive
with the communities they are trying to reach.
21/33
QL
Extend library hours
Community Board 4Q's catchment area of
or expand and
Corona, Corona Heights, and Elmhurst is
enhance library
densely populated with a wide variety of ethnic
programs
groups comprised of children, adults, and senior
citizens. Our library branches and programs the
libraries provide are heavily utilized. We will
continue to support six day service, look to
support 7 day service when applicable.
22/33
DSNY
Increase
Several areas of our district are seeing a
enforcement of
substantial amount of garbage pile up, with
dirty sidewalk/dirty
little to no penalty to the property owners.
area/failure to clean
Commercial corridors such as Queens
area laws
Boulevard, Roosevelt Avenue, Junction
Boulevard, Broadway, and National Street near
Corona Plaza are infamously known for
excessive littering, but enforcement is scarce.
More over with the ACE Program in effect at
several of these locations, enforcement should
be more stringent on properties who have no
reason to not maintain their sidewalks including
adjacent tree pits.
23/33
FDNY
Other FDNY facilities
The majority of the firehouses within our district
97-28 43rd
and equipment
already have generators in case of a power
Avenue
requests (Expense)
outage. However, Engine 289 in Corona is still
operating with an above ground, multiple unit
setup. Requesting funding to provide an in
ground generator for this heavily utilized
station.
24/33
DCLA
Provide more public
Public art serves as a means to deter graffiti
art
within our parks. More funding should be
allocated to grants specifically geared towards
public art. Funding should effectively cover both
initial implementation as well as continued
maintenance of projects for consecutive years.
25/33
DHS
Provide rental
With the proliferation of hotel shelters
assistance/vouchers
throughout the city, the need for services to get
for permanent
our residents out of shelters should be more
housing
heavily emphasized. Family shelters within the
district currently house multi generational
homeless families. The cost of housing these
families in shelters/hotels far exceeds the cost of
permanent housing. Funding should instead be
allocated to preventative programs, and those
geared towards removing people from the
"system".
26/33
HRA
Provide Metrocards
With the ridership at many of our stations as
to help low-income
high as 17 million riders per year for Roosevelt
New Yorkers get to
Ave., and as high as 6.8 million for Woodhaven
work and around
Blvd, it is obvious that our residents are using
the City
mass transit as a means to get around. In
conjunction with this, the low income cap
throughout the district reflects a need for
funding metro cards to low income residents
throughout the areas of Corona and Elmhurst.
27/33
DFTA
Enhance programs
Requesting funding to expand Elder Abuse
for elder abuse
Prevention programs throughout the district.
victims
28/33 DOB Assign additional
building inspectors (including expanding training programs)
In 2018, there were 165,988 permits issued by DOB, and in the first three quarters of 2019, 120,668 ,putting us on track to meet or exceed last year’s numbers. With the rapid increase in development, it is crucial that DOB has enough building inspectors and staff to adequately ensure the safety of the over 1.1 million buildings in NYC. In FY 19, the average response time for Priority B complaints was 11.4 days.
While Priority B complaints aren’t life threatening, they can be indicators that something is unsafe. No matter what we say in an attempt to please the case for more funding, no one said it better than former DOB Commissioner Rick Chandler, who in a 2018 interview said “I think if we had ten times the resources…, we would still be just making a dent.”
image
29/33 NYCHA Provide emergency
housing for households displaced by fires or City-issued vacate orders
Our catchment area is densely populated with a wide variety of various ethnic groups comprised of children, adults and seniors. Funding is needed to provide assistance with emergency displacement as a result of fires or vacate orders. The Red Cross and NYCOEM offer some assistance to those in crises by addressing immediate needs, but more is needed. In 2017, firefighters responded to a building fire in which over 100 apartments were extensively damaged. Although a temporary center for those affected was set up at a nearby school, the aftermath of the disaster lingered on for several months. CB4 is requesting an agency be formed designated with the task of relocation assistance and advisory services to minimize the impact of adversity in a more timely manner.
image
30/33
DCLA
Support nonprofit
cultural organizations
We are fortunate to share experiences with
people of many nations. Immigrants from Asia and Latin America have made Elmhurst the most diverse part of Queens. Following World War II, Elmhurst became one of the most ethnically diverse neighborhoods as immigrants arrived from new areas. By the 1980s, there were people from 112 nations residing in the district. Meanwhile, Corona in the 1950s was predominately Italian and African American which began to change in the late 1990s, when immigrants from Latin America arrived. To support the past and ever growing history of our changing neighborhoods, CB4 is requesting funding to help support our cultural organizations tasked with documenting, preserving, and promoting awareness of the past and future development and growth of our iconic community.
31/33
DSNY
Provide or expand NYC organics collection program
While neighboring districts of Rego Park, Glendale, and some parts of Jackson Heights already have the organics program, the neighborhood of Corona, and the majority of Elmhurst have yet to be a part of this successful program.
32/33
DYCD
Provide, expand, or enhance after school programs for elementary school students (grades K- 5)
There is a tremendous need for after school programs for elementary school students grades k-5. At this early stage the students' lives, it is important to have enriching programs that are both educational and fun. Said programs will also help parents who have limited work hours, will help the children with social skills, and give students an advantage as they progress in their education.
33/33
DYCD
Other youth workforce development requests
Our district would benefit greatly from having a youth center that would support our youth and their families. Educational programs, mentoring, homework help, extracurricular activities, and counseling are just some of the services that the youth within our district are in desperate need of. Seeking funding to obtain land, and construct a center within the confines of our district.

