- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 10 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1Vx_yolsRA_lCtBL6T7D2iOE_dH5PatgJ/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1Vx_yolsRA_lCtBL6T7D2iOE_dH5PatgJ/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
10
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 10
image
Address: 8119 5 Avenue
Phone: (718) 745-6827
Email: bk10@cb.nyc.gov
Website: www1.nyc.gov/site/brooklyncb10/index.page
Chair: Lori Willis
District Manager: Josephine Beckmann
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Brooklyn Community District Ten encompasses the three neighborhoods of Bay Ridge, Dyker Heights, and Fort Hamilton. Defining the southern and western borders of District Ten are the waters of the Verrazano Narrows. To the North, the L.I.R.R. and MTA railroad head from the shoreline at 65th Street and proceeds eastward to 62nd Street, merging with the District’s eastern border at 14th Avenue. Community District Ten is 77% residential, 16% parks, 3% manufacturing, and almost 2% commercial. Land in the District is mostly taken up by these five categories- one and two family homes (33.06%), open spaces/outdoor recreation (29.94%), public facilities/institutions (14.11%), multifamily walk ups (9.04%), and mixed residential and commercial area (5.04%). District Ten has 352.51 acres of parkland spread across 17 parks and is comprised mainly of one and two family homes. Parks within the District provide a multitude of diversified athletic and passive recreational facilities to residents and visitors throughout the year. Though mostly residential, District Ten is also home to several commercial areas including, but not limited to, Bay Ridge Avenue, 4th Avenue, 5th Avenue, and 86th Street. These areas provide the District’s growing population with essential goods, services, and employment opportunities. The NYC Department of Health’s Community District Profile report lists Community District Ten’s population in 2010 and 2015. In the span of five years, Community District Ten’s population grew from 124,500 to 140,007; a 12.5% (15,507) increase. With over 140,000 people residing in Bay Ridge, Dyker Heights, and Fort Hamilton, over 60% of the population is white, 22% is Asian, 15% is Hispanic, 1% is Black, and the remaining 2% has been identified as “Other”. An average 23.4% of residents under the age of 18 living in a particular Community District- Community Board Ten’s population is comprised of 20.7% individuals under the age of 18. Brooklyn also has the highest senior population in all five boroughs, with an average 11.9% of residents over the age of 65 living in any particular Community District. Community Board Ten’s population is comprised of 14.7% individuals over the age of 65.
Community Board Ten continues to proactively advocate preserving and strengthening our community by monitoring service related complaints and discussing budgetary needs and community requests with appropriate city agencies to ensure responsiveness and effective service delivery.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 10
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
Neighborhood Preservation The illegal conversions of one/two family homes continue to be a pressing issue within the District. There were 425 service requests made in 2015, 567 service requests made in 2016, 563 service requests made in 2017, and 516 service requests made in 2018 regarding the illegal conversion of residential and commercial buildings and/or spaces. The amount of complaints made about illegal curb cuts, driveways, and carports increased by 149% from 2015 to 2018. Additionally, there has been an increase in illegal curb cuts, construction without building permits and building code violations. In order to be responsive to these service requests, it is crucial for the district to have more building inspectors to regulate and enforce zoning laws and regulations. Community District 10 has been assigned a multi-agency task force comprised of inspectors from the New York City Buildings Department, Fire Department and HPD to respond to 311 complaints and ensure safety.
Parks
PARKS - With 16% of its land dedicated to parks, Community Board Ten prioritizes the maintenance of its parkland. Community Board Ten contains the following parks: Shore Road Park, Dyker Beach Park, John J. Carty Park, Russel Pederson Park, Owls Head Park, McKinley Park, Leif Ericson Park, and John Paul Jones Park. Many of Community Board Ten’s parks are in need of refurbishment and renovation. Issues related to parks include, but are not limited to, lack of tree pruning and maintenance, lack of parks personnel, and outdated, worn play equipment. There are 21 capital budget priorities specific to Parks within Community Board Ten. A recent tour of parks within the District revealed a great need for substantial capital investments to repair and refurbish aging equipment, infrastructure and facilities. Routine maintenance needs are often delayed due to insufficient personnel or equipment failure.
Service requests from 311 via NYC Open Data show an increase in overgrown trees, dead trees and deterioration of conditions around park paths. Also, complaints about playgrounds was significant stressing the need for additional grounds crews and equipment to maintain our beautiful parks. Forestry complaints rank among the highest 311 service delivery calls in the district. From 2014 through 2019 there were 3,236 calls for damaged trees, 1,654 for overgrown trees and 644 for dead trees. The Parks Department also has a new protocol/priority system adopted in July of 2017. This year the District Office received an increase in calls from frustrated residents about forestry related 311 responses. Residents are frustrated by the increase in response time to forestry complaints. All of NYC Parks current tree maintenance is based on risk management assessment and work is prioritized based on the likelihood of tree failure, impact, and consequences of impact. For example a mid size tree branch that is hanging from a tree that is deemed by a forester upon inspection as not likely to cause significant damage will generate a work order that may take up to 180 days to complete. The local impact is that residents are frustrated by the duration of time it takes for tree service requests. For example, a call first reported to 311 in July 2019 about a tree branch hanging on Bay Ridge Parkway 500 block will take 180 days to address. Residents find this agency response to be unacceptable. Therefore, additional funding for forestry services to reduce this lag time is crucial.
Senior services
Community Board Ten’s population is comprised of 15.3% individuals over the age of 65. Programs such as Meals on Wheels and the Supplementary Nutrition Assistance Program (SNAP) are needed to accommodate the District’s growing senior population. There are currently two senior centers within Community Board Ten (Bay Ridge Center for Older Adults and Fort Hamilton Senior Recreation Center). Over time, the program has reached a waiting list of 50 residents. The average amount of seniors on the waiting list for home meal delivery ranges from 15 to 25 people at any given time. The average duration of time residents are on the waiting list is about one to two months.
Therefore, funding for Meals On Wheels program must be maintained and additional programs/facilities suited to address the needs of the growing population of seniors require funding. Affordable senior housing has been a top request of many long-time residents in Community Board Ten as of 2018. A growing number of long time seniors who have rented in the same building are being displaced by a spike in sales of one and two family homes. These seniors cannot afford the market rate value of apartments in the District and often seek assistance from the Community Board District Office. The Bay Ridge Age Friendly Committee is a committee associated with the
Community Board Ten office that meets bi-weekly to identify initiatives for seniors and consider how best to serve and benefit the growing senior population in Bay Ridge/Dyker Heights and Fort Hamilton. In April 2019, Community Board Ten organized its first ever Senior Resource Fair at the Fort Hamilton Senior Center with participation from local seniors and members of the Bay Ridge Center. The goal was to provide seniors with resources from government agencies, elected officials and local businesses. Also, at the Senior Resource Fair, Community Board Ten Senior Issues, Housing, Health and Welfare Committee distributed a comprehensive senior resource guide which provides a list of businesses and community partners that offer senior discounts or age friendly services. Seniors continue to advocate for technology classes, recreational programs and affordable health insurance. The Bay Ridge Age Friendly Committee hopes to review the NYC Department of Health Community Profile that identified 1,876 reported fall related hospitalizations in Community District 10. Falls are very often preventable for seniors.
Community Board Ten’s Senior Issues and Housing, Health and Welfare Committee will continue to advocate for a state of the art, new, multi-purpose senior center to meet the changing needs of the local senior population.
Community Board Ten will also continue to advocate for affordable housing and all funding that supports the needs of seniors within the District.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 10
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
As was previously mentioned, Community Board Ten’s population is comprised of 15.3% individuals over the age of
65. Members of Community Board Ten continue advocating for community based funding for necessary services to help our senior population age in place. Programs such as Meals on Wheels and the Supplementary Nutrition Assistance Program (SNAP) are needed to accommodate the District’s growing senior population There are currently two senior centers within Community Board Ten (i.e. Bay Ridge Center for Older Adults and Fort Hamilton Senior Recreation Center).The Bay Ridge Center is one of two Meals on Wheels service providers in Community Board Ten. As of the summer of 2018, the Center had a reported waiting list of 50 residents seeking to receive Meals on Wheels service. More programs and facilities suited to the Board’s larger population of seniors should be incorporated in Community Board Ten.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Local neighboring emergency rooms at Maimonides Medical Center and NYU Langone Hospital serve the needs of 140,000 Community Board Ten residents. New York City Department of Health Profile 2018 reports there has been a notable increase in the number of fall related hospitalizations in older adults. There were 1876 in Bay Ridge and Dyker Heights.. compared to 1526 per 100,000 Borough-wide and 1604 per 100,000 for New York City. Avoidable hospitalizations among adults in Bay Ridge/Dyker Heights there were 798 as compared to all of Brooklyn where there were 1,420 and in New York City there were 1,033 for New York City. The overdose death rate in the Bensonhurst-Bay Ridge area is 20.9 of 100,000; the second highest in all of Brooklyn. Continued support for opioid awareness, education and related services. Community Board Ten advocates for continued education of Narcan training a lifesaving drug that can reverse the effects of opioid overdose.
Needs for Older NYs
The following outlines for main senior groups: 1. Newly retired 60+ seniors who are active and still working and/or volunteering. 2. The established and healthy older person who is fully enjoying retirement and interested in leisure activities. 3. The “aging in place” elder in need of care service and support to remain independent. 4. The home bound and impaired elderly individual in need of daily home and personal care services. Community Board Ten recognizes the diverse needs of the elderly population which spans several subgroups. The Bay Ridge Age Friendly Committee and the Bay Ridge Center provide services to these four main senior groups in Community Board Ten. The Bay Ridge Age Friendly Committee continues to meet regularly to identify initiatives for seniors and consider how best to serve and benefit the growing senior population of Bay Ridge. In June 2018, Community Board Ten partnered with the Bay Ridge Senior Center to host a Senior Tech event at Brooklyn Borough Hall. The event showcased vendors who informed over 350 participating seniors about recent technological innovations and how this new technology can be utilized to improve quality of life. Community Board Ten is working alongside the Bay Ridge Center and local business leaders to assist with the expansion of Age Friendly NYC goals by reaching out to city government agencies involved in the Age Friendly effort. In 2017, local residents advocated for the development of senior housing at the former site of the Angel Guardian Home. The Community Board District Office received over 200 letters from residents expressing need for the development of affordable senior housing.
Community Board Ten’s Senior Issues and Housing, Health and Welfare Committee will continue to advocate for multi-purpose senior centers to meet the changing needs of the senior population. The District will also continue to advocate for funding that supports the needs of seniors within the District.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/33
DFTA
Renovate or
Capital Funding for the relocation of Bay Ridge
411 Ovington
upgrade a senior
Center for Older Adults Senior Center. The Bay
Avenue
center
Ridge Center for Older Adults is in need of a new
ADA compliant senior center for the over 1,000
seniors who attend and obtain a multitude of
services provided by the center. Its current
location is not adequate for its service delivery
needs.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
5/23
DFTA
Increase home
The number of seniors receiving home delivered
delivered meals
meals continues to rise in Community District
capacity
10. In 2018 there is a waiting list of 50
applicants.
9/23
DOHMH
Reduce mosquito
Increase staffing levels for mosquito control
populations
efforts. This is needed in areas of high mosquito
concentration to curtail spread of West Nile
Virus.
14/23
DOHMH
Reduce rat
Increase staffing levels for inspection and
populations
baiting services for rodent control. Proliferating
problems created by rodent infestation along
lots and highway properties and other pest
related problems must be addressed by
enhancing the workforce for pest control.
19/23 DOHMH Other animal and
pest control requests
To provide and implement a long term plan to eradicate bed bugs. Bed bug infestation is a growing citywide problem. In Community District 10 area residents are concerned about the growing problem of bed bug infestation, specifically new infestations in the subways. We are also concerned about the economic toll it places on local families who are struggling to make ends meet. Extermination of an average two bedroom apartment can cost over $1,000 with additional cost to replace mattresses, furniture and clothing. Members would like to see a citywide forum with a goal of providing and implementing a long term plan to deal with bedbugs.
image
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 10
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
The following information is derived from the New York City Council’s March 2018 Planning to Learn report. Overcrowding has well documented negative effects on educational opportunity and retention. District 20, located in Community Board Ten, is the most overcrowded school district in all of New York City. There are currently 35,710 students enrolled in School District 20. This exceeds the District’s capacity of 29,480 by 6,230 students, thus resulting in a utilization rate of 121%. There is current identified need of 10,322 seats; a 29% identified need as % enrollment. In Community Board Ten’s section of District 20, there are 7,984 identified seats needed, with 3,957 funded seats and 4,027 unfunded seats. There are three proposed new school buildings in Community School District 20 that are in the very preliminary planning stages which will bring in additional seats to help ease overcrowding. However, we do not yet know the total number of added seats.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Community District Needs Related to Educational Facilities and Programs
There is funding in the School Construction Capital Plan for 4,869 additional seats in District 20. Current additional projects include: PS127 (extension of 330 seats) and a new K to 5 building at 60th Street and 4th Avenue. There will also be a new public grammar school at 6301 14th Avenue, Block 5741/Lot 5, the former site of St. Rosalia Church with 380 seats, located just one block outside of Community District Ten’s jurisdiction, within Community School District 20. The School Construction Authority is also looking at the former site of the Angel Guardian Home 6301 12 Avenue as a K to 5 school site in Community District10. Additional sites are needed to fulfill the funded allotment. In 2019 the School Construction Authority acquired property of 650 86th Street. Planning for a new middle school is underway. The total property is approximately 20,000 square feet and is expected to serve 500 students.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 10
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
Traffic violations and enforcement Illegal parking, blocked driveways, blocked fire hydrants, derelict vehicles and traffic service requests were noted as top quality of life 311 service requests. In addition, truck traffic on non-truck routes, improper U-turns and speeding vehicles are top concerns raised to the District Office of Community Board Ten. Community Board Ten has supported New York State Legislation to increase the number of speed cameras near schools and other locations where excessive speed is a top complaint. In 2019, the Community Board Ten created the Street and Safety Committee. The purpose of this committee is to make recommendations and discuss the issues of street safety and traffic in the district. It met for the first time in January of 2019. At this time recommendations were made to recommend placing a traffic light to improve traffic control at the “T” intersection at 90th Street and 3rd Avenue. Another recommendation was placing louvers on the traffic light at 4th Avenue and 101st Street so that when the light is green, drivers will have to be closer to see that the light is green. Finally, the last recommendation that the committee made was to request a safety study of the corridor of 10th Avenue from 76th Street to 86th Street with the intention that this thoroughfare would be made safer with additional traffic control devices at appropriate intersections. From 2014 to 2018, there was a 64% increase in blocked driveway service requests, a 138% increase in illegal parking service requests, 1,125% increase in traffic service requests, and a 253% increase in blocked hydrants reported to 311 within Community Board Ten. Also, in 2018 there was a 36% increase in derelict vehicles from 2015. As a result, the rise in service requests to 311 reflected in the NYC Open Data portal from 2014 to 2018 directed to the NYPD for enforcement strains already limited police resources. The number of illegal parking service requests directed to the 68th precinct far outnumbers the available personnel to address such service requests. Community Board Ten has identified additional NYPD resources to address all enforcement needs including the necessary equipment and training required for speed enforcement. Recently, the Department of Transportation School Safety team redesigned a section of 9th Avenue from 62nd Street to 66th Street located near P.S. 69 as parent and faculty requested assistance. The area is a mixed use commercial, manufacturing and residential district. The one-way street redesign created a head on situation at 64th Street which was clear to motorists as DOT implemented signage, bollards and planters to driver traffic. However, the need for consistent enforcement is paramount to the roadway redesign's success and has not been successful due to lack of personnel.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Community District Needs Related to Policing and Crime
The attached data contains all complaint types made to the NYPD on OpenData’s 311 Service Requests list. The attached chart shows a large increase in the following complaints: Blocked Driveways (64%) Illegal Parking (138%), Traffic (1,125.5%), Blocked Hydrants (253%). Please note the parenthesized percentages are the percent increases from 2014-2018. Also, noise complaints rank high in quality of life service requests in Community District Ten. 311 NYC Open Data noise complaints rose from 3,514 service requests in 2015 to 4,081 service request in 2018. A large service request associated with noise is banging and pounding in the District. In 2017 there was 763 service request and in 2018 it increased to 1,138 service requests, a 56% increase in the past year. Also, utilities often perform non- emergency loud construction work on the overnight shift at various locations throughout this very residential district.
The rise in service requests made to 311 from 2014 to 2018 points toward strained police resources in the District’s only police precinct and an increase in population/residential housing within Community Board Ten. Brooklyn Community Board Ten has only 108 police officers assigned to its 68th precinct to ensure law enforcement in Bay
Ridge, Dyker Heights, and Fort Hamilton - which is the lowest in Patrol Borough Brooklyn South. Community Board Ten is also requesting to increase our allotment of School Crossing Guards to 40. Currently, Community Board Ten has 34 School Crossing Guards assigned to the 68 Precinct.
Needs for Emergency Services
Battalion 40 and 42 which serve CB10 have a combined strength of 360 officers and personnel as well as 19 vehicles. In the 2017-18 District Resource Statement there were 586 fires reported in CB10. Community Board Ten has listed the need to maintain personnel numbers for firefighters and EMS workers as a top priority.
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
CS NYPD Provide surveillance cameras
Several new surveillance cameras were installed due to funding from the New York City Council. Resident requests for additional surveillance cameras along commercial corridors and problematic locations is warranted.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
2/23
NYPD
Assign additional
Increase patrol strength at 68th Police Precinct
uniformed officers
as well as civilian personnel levels.
3/23
FDNY
Provide more
Maintain personnel funding levels for
firefighters or EMS
firefighting personnel. Funding levels must be
workers
sustained to maintain effective firefighting and
prevention services and to overcome attrition.
6/23
NYPD
Assign additional
Additional school crossing guards needed within
crossing guards
Community District Ten. CB10 is requesting to
increase our allotment to 40.
18/23
NYPD
Assign additional
In keeping with the Mayor's Vision Zero
traffic enforcement
initiative, additional traffic control agents are
officers
needed at high crash and heavily travelled
commercial corridors. These include near
entrance of Brooklyn Queens Expressway and to
handle Verrazano Narrows Bridge traffic
disruptions and summer volume. 86th Street at
4th Avenue and 5th Avenue 65th Street at 6th,
7th and 8th Avenues and Fort Hamilton
Parkway Additional agents needed to handle
Verrazano Narrows Bridge traffic disruptions at
92nd Street corridor; 86th Street at Gatling
Place
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 10
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Other
Aging Water / Combined Sewer System The top service requests relating to Department of Environmental Protection include: Water Systems, Sewers, Noise and Lead. The water system infrastructure of Community Board 10 is causing issues such as sewer backups and clogged catch basins on the streets. This causes flooding and odor in the streets and sidewalks. From 2017 to 2018 there was a 109% increase in clogged catch basins service requests in the areas of Fort Hamilton Parkway from 65th Street to Bay Ridge Parkway and 14th Avenue from 79th Street to 86th Street. From 2015 to 2018 there was a 49% increase in sewer backups and the areas that are concentrated with sewer backups are along 68th Street to Bay Ridge Parkway between 5th Avenue and Shore Road, and 92nd Street to 101 Street from 4th Avenue to Ridge Blvd. From NYC Open Data, Community Board Ten saw an increase in possible water main breaks. From 2015 to 2018 there was a 77% increase in possible water main breaks. A water main break can cause cave-ins, sewer backups, flooded catch basins, odor, and low water pressure in buildings and residential homes. NYC has one of the cleanest water systems in the world, but lead in the water system can be very harmful to residents. From 2015 to 2018 there was a 190% increase in Lead Kit Requests in Community Board Ten. Also, dirty water service requests have increased to 75% from 2015 to 2018. There are two sections of the district that lodged 311 calls for dirty water. Those areas are Shore Road to 4th Avenue from 87th Street to Shore Road and 79th Street to 65th Street from Shore Road to 6th Avenue. Also, According to the Mayor’s Management Report of 2018, there was a 43% increase in water main breaks per 100 miles in the last 12 months.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
A proactive capital plan is needed for upgrades of an aged sewer and water main infrastructure in Community Board Ten. CB10 is home to the Owl’s Head Wastewater Treatment Plant, which treats up to 120 million gallons of wastewater per day for the 758,007 New Yorkers it serves. Complaints regarding odor emanating from the Plant and upgrades to ensure odor control are top priorities for Board 10.
Needs for Sanitation Services
Cleaning and collection personnel deals with the collection of refuse from City residences and the cleaning of City streets on a regular schedule in Brooklyn Community Board Ten. The attached images showcase the numbers of DSNY personnel and vehicles within the District. From 2014 to 2016, there has been a 57.6% increase in the occurrence of illegal dumping. In 2017, the number of illegal dumping complaints is greater than that of 2014/2015. While there has been a 9.6% decrease of illegal dumping between 2016 and 2017, the problem still persists as evidenced by this image of Poly Place taken during the July of 2017. Conditions resulting from Illegal Dumping are not only unsightly, but also unsanitary. There is a notable cluster of illegal dumping complaints made to 311 along 5th Avenue between 76th and 84th Streets. This area is mainly residential and close to heavily populated commercial streets such as 86th Street. At a DSNY meeting on August 22nd, 2018, it was reported that Brooklyn Community Board Ten is the second heaviest bulk pickup location in NYC. An appointment system was designed to help the DSNY more efficiently collect non-recyclable bulk items in 2017. . The attached graph shows missed bulk collections, prior to this implementation in 2017, from 2012-2017. The rate by which bulk items were not picked up continued to increase throughout a five year period from 2012 to 2017. In 2012, there were 58 missed pickups, whereas in 2017, there were 664 missed pickups. Residents are now able to book an appointment by calling 311 or placing their bulk out for collection on their non-recycling collection day. The Department also has a system put into place for the pickup of recyclable organic materials. Organics collection was originally implemented as a pilot voluntary program. Collection of organics was rolled out with curbside bi-weekly collection. In August 2018 Organics collection was scaled back to only once per week. It is important to note that the commencement of organics collection resulted in a reduction of Motorized Litter Patrol personnel in CD10 which greatly impacted the district's cleanliness. It also prompted the sudden change in collection policy on 4 private streets in CD10. These streets
include Wogan Terrace, Barwell Terrace, Hamilton Walk, and Lafayette Walk. Routine collection were performed by MLP staff at these four locations due to their unique design of these streets. MLP staff would walk down to collect their refuse and recycling. The members of Community Board Ten fully support the merits of the Organics Recycling Program and all efforts to maximize diversion rates from landfills in addition to the restoration of prior service to the four aforementioned ally streets and to bi-weekly MLP service throughout the District.
image
Priority Agency Request Explanation Location
image
4/33 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
Requests to initiate design for new and larger sewers with greater capacity including new catch basins to address flooding issues on Narrows Avenue and Colonial Road from Bay Ridge Parkway to 85th Street. A new catch basin was installed at Narrows Avenue at 79th Street in FY19 but further study is needed.
Narrows Avenue/Colonial Road Bay
Ridge Parkway 85 Street
image
7/33 DEP Inspect water main
on specific street segment and repair or replace as needed (Capital)
The Department of Ennvironmental Protection does not have a proactive capital plan in Brooklyn. Mounting complaints about recurring depressions/sewer back ups - aging sewer system require further study at several locations within Community District 10. 12th Avenue from Bay Ridge Avenue to 74th Street;3rd Avenue from 68th to 78th Streets; 11th Avenue from 62 to 72 Streets; 13th Avenue from Bay Ridge Avenue to 79th Street; Bay Ridge Avenue from Shore Road to 7th Avenue
image
17/33 DEP Evaluate a public
location or property for green infrastructure, e.g. rain gardens, stormwater greenstreets, green playgrounds
Provide funding to establish an Oyster Garden alongside shoreline adjacent to Owls Head Wastewater Treatment Facility.
image
18/33 DEP Investigate odor
complaints about a wastewater facility and address/repair or make equipment improvements as needed (Capital)
Owls Head Wastewater Treatment Plant - requires a complete modernization to ensure that odors are kept under control.
Repair/replace sludge barge dock.
6700 Shore Road
image
27/33 DEP Investigate odor
complaints about a wastewater facility and address/repair or make equipment improvements as needed (Capital)
Request to initiate study of Combined Sewer Outfalls (CSOs) Infrastructure inspection along the Shore Road Promenade from the 69th Street Pier to Bay 8th Street to determine if upgrades are needed in wake of Superstorm Sandy AND sinkholes that have developed along the Shore Road Promenade. Functionality of these CSOs is critical to the maintenance of the Shore Road Promenade and the adjacent Belt Parkway.
Shore Road Promenade Bay Ridge Avenue Bay 8th Street
Priority
Agency
Request
Explanation
Location
7/23
DSNY
Provide more
Request to provide sufficient funding to
frequent litter
maintain additional basket collection trucks in
basket collection
commercial corridors within CD10. Commercial
sectors generate excessive loads. Sunday
cleaning and collection services are needed to
remove heavy weekend overflow. Also, a critical
need exists to expand MLP staffing
11/23
DSNY
Increase
CD10 has recurring illegal dumping on
enforcement of
commercial corridors and at corner baskets.
illegal dumping laws
There is also illegal dumping along the
sidewalks adjacent to the MTA 62nd railroad
tracks.
21/23
DSNY
Increase
Frequent complaints are received by the District
enforcement of
Office regarding canine waste. It is a quality of
canine waste laws
life issue that frustrates residents concerned
about street cleanliness.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 10
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
The illegal conversions of one/two family homes continues to be a pressing issue within the District and it is one of Community Board Ten’s top priorities. There were 425 service requests made in 2015, 567 service requests made in 2016, 563 service requests in 2017, and 516 service requests in 2018. As a result, the DOB should have better access to residential areas where illegal conversions are suspected to be occurring and/or where a large number of complaints have been filed. A lack of access correlates with a lack of violations issued which perpetuates serious safety risks to all affected residents. The Residential Streetscape Preservation text amendment addressed community concerns about inappropriate curb cuts and front yard parking spaces in residential districts when it was implemented in 2010. Planning seeks to clarify parking requirements and preserve and enhance residential streetscapes. The amount of complaints made about illegal curb cuts, driveways, and carports increased from 2015 to 2018 to 149%. In 2018 there were 122 service requests relating to illegal curb cutting in the district. According to the map given, illegal curb cuts can be found throughout the district with a greater concentration in Dyker Heights. Additionally, there has been a decrease in the rate officials were granted access to suspected areas and a decrease in work without a permit complaints where access was obtained and violations were written. In July 2019, Community Board 10 topped 152 service requests for construction work performed without building permits. Also, the number of building code violations issued increased. In 2018 there were 1,265 Class C violations and 2015 Class I violations, a 242% increase in Class I violations. The attached document is a map of all illegal curb cuts, driveway, carport, and conversion complaints made to the DOB, graphs of building codes violations and no building permits.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Additional staffing including inspectors is needed to address enforcement of illegal conversions of one and two family homes in Community District Ten as well as conversions of commercial properties to non-conforming uses.
Needs for Housing
No comments
Needs for Economic Development
There are two Business Improvement Districts within Community District 10. They are the 86th BID and the 5th Avenue BID. There are current plans to from 2 new BIDs; a 13th Avenue and 3rd Avenue BID. The Community Board supports merchants organizing and BID formation
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
4/23 DOB Address illegal
conversions and uses of buildings
Inspectors are needed to address the growing number of complaints from area residents. Since 2010 the number of complaints from area residents of single and two-family homes being converted and occupied as SROs and transient housing is on the rise.
TRANSPORTATION
Brooklyn Community Board 10
image
M ost Important Issue Related to Transportation and Mobility
Other
Street Safety, Mass Transit, and Roadway Conditions Community Board Ten has been working on three important transportation issues including street safety, mass transit, and roadway maintenance MASS TRANSIT: The following outlines the train and bus service in Community District Ten. The average Brooklyn resident spends 42 minutes commuting to work, community members in District Ten spend 44 minutes commuting to work. Here is a list of major buses and trains within CB10 as of November 2017: B1 - S53 - B4 - S79 - B8 - X17 - B9 - X27 - B16 - X28 - B37 - X37 - B63 - X38 - B70 - R/N Train: 86th Street between 4th and 5th Avenues in Community Board Ten continues to be a heavily trafficked area. Four buses (B1, B16, S53, and S93) pick up riders on this street. There are only two trains connecting Community Board 10 to other parts of the subway system. In Community Board 10, the N train stops between 8thAvenue and Fort Hamilton Parkway. The R train makes the following stops in CB10: Bay Ridge Avenue/4th Avenue, 77th Street/4th Avenue, 86th Street/4th Avenue, and 95th Street/4th Avenue. The attached graph shows the average amount of riders utilizing MTA service at the N and R stops in Community Board Ten. There has recently been construction at the 86th Street /4th Avenue station to improve core infrastructure and accessibility. This will be the only ADA accessible station on the R line in Community District Ten. It was one of 20 Key Stations and is expected to be completed in 2020. Community Board Ten expects that a roadway redesign and possible bus stop will be needed due to the placement of the elevator at the Southeast corner of 4th Avenue at 86th Street. Community Board Ten objected to the placement of the elevator at this location stating that the 85th Street entrance was more suitable for safety reasons. Delays on the R line continue to be a source of frustration for local riders who continue to advocate for improvements and an audit to determine the causes for the delays.
Residents have petitioned the MTA together with all our local elected officials for improved R line service. The rehabilitation of the N train stations at both 8th Avenue and Fort Hamilton Parkway are near completion. The elevator for the Manhattan bound platform at 8th Avenue is set to open later this year and a separate contract will handle the Coney Island bound platform. The N express service resumed between 59th Street and 36th Street. Also in 2019, New York City Transit will be providing a significant addition to the B63. With this addition, the bus service will increase from every nine minutes to every seven minutes during the morning; from ten to nine minutes during the peak of the afternoon; and from twenty to fifteen minutes in the evening.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Community Board Ten Traffic and Transportation committee annually reviews the condition of local roadways and reports its findings to the New York City Department of Transportation. It recently submitted a list of locations of infrastructure concerns where the roadbed cave-ins and depressions reoccur. Following the elimination of the DEP Trench Restoration contract, many street beds in CD 10 need to be studied to determine if they require capital infrastructure improvements. In recent years, street resurfacing is on a yearly cycle but only thirty percent of requested roadways in Community District Ten are expected to be paved during the next cycle. The following locations are pending review for trench restoration: 13 Avenue between Bay Ridge Parkway and 76 Street, 96 Street between Shore Road and Marine Avenue, 87 Street between 3rd and 4th Avenue, 12th Avenue at Bay Ridge Avenue. Funding must be allocated for there to be a curb replacement project.
Needs for Transit Services
Improving public transportation is a top priority within Community District 10. From 2011 through 2016, the R line that runs along 4th Avenue has seen ridership increases from Bay Ridge Avenue (3.32%); 77th Street (10.39%); 86th Street (8.9%); and 95th Street (4.72%). Expanding service on both the R and N lines is a top priority. The modernization and rehabilitation of the R lines is needed. Handicapped accessibility of the 86th street Station is being planned. Although this is a significant step, the location selected to place the handicapped accessible elevator is a safety concern to the members of CB10. R Train maintenance, improved service, cleanliness and safety is of
importance at all local stations which include Bay Ridge Avenue, 77th Street, 86th Street and 95th Street within Community District 10. The N lines at both 8th Avenue and Fort Hamilton Parkway had service reductions affecting service and no longer provide express service in Manhattan. Local residents continue to advocate for the permanent restoration of N Express service in Manhattan. Both N stations, located within Community District 10 at 8th Avenue and Fort Hamilton Parkway, are in the final phase of the renovation project expected to be completed in 2019.The N line at 8th Avenue will also receive an ADA elevator, a change from the originally proposed ADA ramp entrance.
From 2011 through 2016 the N line stations in CD 10 have seen ridership increase at 8th Avenue (31.6%) and from 2011 through 2015 Fort Hamilton Parkway (3.2%). Additionally, members of Community Board Ten have urged NYC Transit to reopen the 7th Avenue entrance to better serve commuters at the heavily traveled 8th Avenue station.
From 2011 through 2016, ridership increases can also be seen on several bus lines including the B1 (5.52%); B64 (3.33%); S79 (25%); and S93 (123%). Current service is at capacity and surveys to extend service into portions of Dyker Heights, Bay Ridge and Fort Hamilton should be reviewed. Growing demand to the College of Staten Island, Staten Island Mall and Staten Island commuters affected by rising toll costs has resulted in the expansion of Staten Island bus service lines. The expansion of bus stops at the intermodal connection point along 4th Avenue at 86th to 88th Streets is affecting both pedestrian and traffic impacts along this area located within the busy 86th Street Business Improvement District. A restoration of Express Bus Service X27/28 and X37/38 was made to assist weekend commuters. Express Bus Weekend Service, specifically the X- 27 and X-28 remains a valuable form of transportation to scores of commuters including the disabled, seniors, students, and local residents.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/33
DOT
Repair or build new
Initiate immediate study of Belt Parkway
seawalls or
Infrastructure to address possible undermining
bulkheads
caused by breaches along nearby Shore Road
Promenade and bicycle path.
5/33
DOT
Reconstruct streets
There are 2 identified street locations in Dyker
Heights that may be in need of trench
restoration or capital improvement due to
recurring street cave-ins and depressions. Bay
Ridge Avenue at 12th Avenue and 13th Avenue
between Bay Ridge Parkway and 76th Street.
6/33
DOT
Reconstruct streets
There are 3 identified street locations within
Community District Ten that may be in need of
trench restoration or capital improvement due
to recurring street cave-ins and depressions
96th Street between Shore Road and Marine
Avenue and 87th Street between 3rd and 4th
Avenue.
13/33
DOT
Repair or build new
Request complete restoration of 76th Street
76 Street
step streets
Step Street at Colonial Road including
Colonial Road
landscaping and drainage. This Step Street is in
Ridge Blvd.
poor condition with broken steps and
inadequate/broken railing. Minor repairs were
made but complete restoration is needed. The
steps overflow during heavy rains making the
step street unsafe to traverse.
33/33
DOT
Roadway
Support the need to increase contract funding
maintenance (i.e.
appropriations for expansion of milling,
pothole repair,
resurfacing and repaving programs to improve
resurfacing, trench
local streets and throughways. There are
restoration, etc.)
several roadways in need of resurfacing within
Community District Ten.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 10
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
The quality of parks and park facilities is of paramount concern to the residents of Community District Ten. A significant amenity for our community’s urban environment is provided by the quality and viability of our district’s parklands. The parks within our district have an advantageous geographic proximity to magnificent natural vistas and offer the availability of numerous athletic and recreational facilities, which provide local families and provide residents great enjoyment. As these parklands are among the most highly utilized in our city, the ever-increasing demand for the use of these facilities is commensurable to the increasing need for their expeditious restoration and maintenance.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Our concerns for the restoration and preservation of our parks are annually emphasized through the high capital improvement priorities we award to park projects. These indicators of our concerns have initiated funding for major restoration of several playgrounds and athletic facilities. However, restoration projects to many of our playgrounds and parklands have been deferred because of lack of funding. While the citizens of our community have endeavored to address the need for improvements in our parks through their efforts to organize volunteer clean-up programs and ambitious fundraising campaigns; these initiatives cannot replace the urgent need to enhance the ongoing daily maintenance service in our parks. The provisions of the needed resources will improve the maintenance operations and productivity levels to restore the parks to their former viability. This past summer season, Community Board 10 received an increase in the number of service request for the removal of illegally discarded/household garbage at local parks, These include Dyker Beach Park, Owls Head Park, Shore Road Park at 79th street & 95th street, JJ Carty Park, Leif Erickson Park, and McKinley Park. In part this new quality of life problem stems from illegal dumping and misuse of parks receptacles. It also reflects a need for additional pickups which may require more staffing and vehicles to pick up the increase in refuse that is produced during the summer. Community District 10 Parks have seen an increase in use of local parks for special events both small and large. This increase also requires additional resources to address maintenance and refuse pick up. Maintenance operations is critical to preserving refurbished parks in the Community District 10 area. Recreational programs expansion is needed and recreational staffing levels as well as security staffing levels must be increased to provide for the needs of youngsters, adults, and senior citizens. The provisions of security personnel for the Parks Enforcement Patrols is needed to deter vandalism and criminal activity so that our capital investments are protected. CB 10 has identified the increasing number of cave- ins along the Shore-Road Promenade and Bicycle Path as our top Parks concern. There are over forty potholes that need funding to make the area safe. The new concession bicycle path was well received; however, the recurring potholes and sinkholes is a safety concern. Forty-eight sinkholes were repaired in an emergency contract in 2015.
Only 8 years prior a full restoration was completed at a cost of $20 million. Sadly, following coastal storms including Super-storm Sandy and Hurricane Irene breaches along the entire Shore Road Promenade's sea wall threaten its stability as well as that of the adjacent Belt Parkway. The interior paths inside Shore Road Park are crumbling and in dire need of refurbishment. McKinley Park, John Paul Jones Park, Dyker Beach park, JJ Carty Park, Vinland Playground, and Dyker Beach Park Asphalt Playground are all recommended for capital funding projects.
Needs for Cultural Services
Community Board Ten supports expanded arts programming throughout the district. Additional funding is needed whether it be at local schools, supporting community beautification mural projects or local art based initiatives.
Needs for Library Services
In addition to special programs, libraries provide a myriad of educational, cultural, recreational, business, and social needs for citizens. It is therefore imperative that the Board’s library system be supported and enhanced by
maintaining staffing levels, expanding computerization, and programming restoration to assure that the Brooklyn Public Library receives its fair share of citywide allocation funds
Needs for Community Boards
The role of Community Boards has broadened in recent years. Community Boards have greater responsibilities and serve as an essential advisory component of city government proposals, land use developments and municipal service delivery requests. Combined with their charter-mandated responsibilities, Community Boards act as a catalyst between agencies and the community. The need for technology upgrades and CMR software to improve service delivery data and efficiency must be funded. CB 10 supports additional funding allocated in FY 2019 by the NYC Council and requests that it be baseline in 2020 and out years to support broader outreach, address technological needs, and professional planning expertise.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/33
DPR
Reconstruct or
Request: Initiate Immediate Engineering Study
upgrade a park or
of Shore Road Promenade/Bicycle Path
amenity (i.e.
Infrastructure/ to address serious recurring
playground, outdoor
cave- ins threatening public safety. This study
athletic field)
must include complete investigation of the
infrastructure of the adjacent Combined Sewer
Outfalls to determine source of water breaches.
Explanation: There are currently 30 recurring
cave-ins along the Shore Road
Promenade/Bicycle Path within the confines of
Community District 10. The source of the
undermining needs to be examined and a
resiliency redesign be put into place. The
recurring cave-ins pose an immediate safety risk
to bicyclists and pedestrians. The engineering
study needs to protect this vital waterfront
recreational space as well as protect adjacent
Belt Parkway.
8/33
DPR
Reconstruct or
Rehabilitate Owls Head Park Lower Path Erosion
upgrade a park or
with full Landscaping Plan and Drainage System
amenity (i.e.
Explanation: Owls Head Park located at 68th
playground, outdoor
Street at Shore Road is in dire need of
athletic field)
rehabilitation of its lower path. It is at a critical
state as dirt is drifting onto the sidewalk along
68th Street and clogging catch basins. All park
refurbishments to be compliant with ADA
specifications. The clogged catch basins impact
the Owls Head Sewage Treatment Plant.
9/33
DPR
Reconstruct or
Reconstruct path and benches. The park is
4th Avenue at
upgrade a park or
enjoyed by young and old. The path and
Shore Road
amenity (i.e.
benches have deteriorated and are need in
playground, outdoor
replacement. Also, water service needs to be
athletic field)
repaired. There are no operating water
fountains. Refurbish to ADA Specifications.
10/33
DPR
Reconstruct or
Renovation of Shore Road Park. Restoration of
upgrade a park or
Shore Road perimeter and drainage by sections
amenity (i.e.
of blocks to include Department of
playground, outdoor
Environmental Protection and Department of
athletic field)
Transportation. Reconstruct and rehabilitate
Shore Road Park adjacent to Shore Road from
72nd Street to 84th Street and on 86th Street to
97th Street. Missing hexagon pavement blocks
creating hazardous pedestrian conditions.
Untended brush and foliage has proliferated to
such an extent that only restoration of the
landscaping can restore the area.
11/33
BPL
Create a new, or
Capital Funds for needed improvement to
renovate or upgrade
library buildings and infrastructure in
an existing public
Community Board Ten including Bay Ridge -
library
Heating and Cooling system improvements
identified by Brooklyn Public Library.
12/33
BPL
Create a new, or
Capital funding needed improvements to library
renovate or upgrade
building at Dyker Heights branch including
an existing public
interior renovation, heating/cooling and exterior
library
windows. McKinley Park Branch needs new roof,
windows and interior renovation.
14/33
DPR
Reconstruct or
Request: McKinley Park- Repairs to Comfort
upgrade a park or
Station Provide Handicap Accessible.
amenity (i.e.
Explanation: The comfort station is in need of
playground, outdoor
upgrades. Refurbish to ADA specifications.
athletic field)
15/33
DPR
Reconstruct or
Provide wheelchair accessible play equipment
upgrade a park or
and landscaping on 7th Avenue portion of park.
playground
16/33
DPR
Reconstruct or
Request: Rehabilitation of the interior path
upgrade a park or
inside Shore Road Park from 79 Street to 95th
amenity (i.e.
Street Explanation: The interior path is in dire
playground, outdoor
need of restoration with crumbling pathways.
athletic field)
Additionally, there are erosions alongside the
paths. It is very dangerous and difficult to walk
on this path
19/33
DPR
Reconstruct or
Request: Rehabilitate 3 remaining ball fields at
upgrade a park or
Dyker Beach Park. Explanation: Our baseball
amenity (i.e.
fields in this district need to be rehabilitated.
playground, outdoor
The fields are in total disrepair. Refurbish to ADA
athletic field)
specifications.
20/33
DPR
Reconstruct or
Request: Complete rehabilitation of Shore Road
upgrade a park or
Park Ball field at 74th Street. Explanation: This
amenity (i.e.
heavily utilized field needs drainage system and
playground, outdoor
new dugouts that are able to be secured from
athletic field)
vandalism in PM hours. Refurbish to ADA
specifications.
21/33
DPR
Reconstruct or
Complete Rehabilitation of Shore Road Park
upgrade a park or
Field 4
amenity (i.e.
playground, outdoor
athletic field)
22/33
DPR
Reconstruct or
Request: Complete Renovation of Shore Road
upgrade a park or
Park at 3rd Avenue. Explanation: Refurbish to
amenity (i.e.
ADA Specifications. There is a small gated
playground, outdoor
unused area of parkland that needs to be
athletic field)
developed for community use.
23/33
DPR
Reconstruct or
Request: Dyker Beach Park Asphalt Field
upgrade a park or
Refurbish Explanation: Refurbish to ADA
amenity (i.e.
specifications. This asphalt field is underutilized.
playground, outdoor
This request is for the development of a multi-
athletic field)
use recreational field.
24/33
DPR
Reconstruct or
Refurbish Russell Pederson Playground - Russell
upgrade a park or
Pederson Playground is in need of restoration
amenity (i.e.
work including new play equipment and spray
playground, outdoor
showers. Separate adult exercise area from
athletic field)
children play equipment. Refurbish to ADA
specifications.
25/33
DPR
Reconstruct or
Refurbish Leif Ericson Park Ball fields 67th Street
upgrade a park or
at 6th Avenue. Synthetic turf. Explanation: The
amenity (i.e.
ball fields at Leif Ericson Park are in poor
playground, outdoor
condition. The Fields are well utilized by local
athletic field)
leagues and in dire need of refurbishment to
ADA specifications.
26/33
DPR
Reconstruct or
Request: Tennis Courts need to be refurbished in
upgrade a park or
Bay 8th Street; Leif Ericson Park; and Shore
amenity (i.e.
Road Park. Explanation: Local Junior High
playground, outdoor
Schools and High Schools utilize these tennis
athletic field)
courts that are in need of refurbishment. All
refurbishments to be ADA compliant.
28/33
DPR
Provide a new, or
Initiate Engineering Study for Placement for a
new expansion to, a
comfort station on the Shore Road Promenade.
building in a park
Residents especially seniors have requested an
accessible comfort station along the Shore Road
Promenade. An engineering feasibility study is
being asked to determine if a comfort station
could be installed along the bicycle path or
promenade.
29/33
DPR
Reconstruct or
Complete Rehabilitation of Shore Road Park
upgrade a park or
Field 3
amenity (i.e.
playground, outdoor
athletic field)
30/33
DPR
Reconstruct or
Complete Refurbishment of Dyker Beach Park
upgrade a park or
Playground including play equipment, water
amenity (i.e.
fountains, sprinklers and infrastructure.
playground, outdoor
Refurbish to ADA specifications.
athletic field)
31/33
DPR
Reconstruct or
The perimeter of Dyker Beach Park/Golf Course
upgrade a park or
is heavily utilized by pedestrians and cyclists as
amenity (i.e.
a form of recreational exercise. A track with
playground, outdoor
divided lanes for pedestrians and cyclists with
athletic field)
distance markings would be beneficial to
residents. Capital Project to create a
walking/cycling track around the perimeter of
Dyker Beach Park/Golf Course or inside the
asphalt ball field at Dyker Beach Park.
32/33
DPR
Reconstruct or
Complete refurbishment of Leif Ericson Park
upgrade a park or
including play equipment, water fountains and
playground
infrastructure to ADA specifications.
CS
DPR
Reconstruct or
Request: JJ Carty Park Refurbishment of
upgrade a park or
Basketball Courts. Explanation: The basketball
amenity (i.e.
courts are in dire need of reconstruction.
playground, outdoor
Refurbishments to meet ADA compliance.
athletic field)
CS
DPR
Reconstruct or
JJ Carty Park Refurbishment of Playground- The
upgrade a park or
playground is in dire need of restoration and
amenity (i.e.
new play equipment. Refurbish to meet ADA
playground, outdoor
compliance.
athletic field)
CS
DPR
Reconstruct or
Request: Owls Head Park Basketball Court
upgrade a park or
Explanation: Basketball Court is in poor
amenity (i.e.
condition and in need of refurbishment.
playground, outdoor
Refurbish to ADA specifications.
athletic field)
CS
DPR
Reconstruct or
Request: Reconstruction of Vinland Playground
7420 Shore
upgrade a park or
located at Shore Road and 95th Street.
Rd
amenity (i.e.
Explanation: This playground is in poor
playground, outdoor
condition and needs to be refurbished. Refurbish
athletic field)
to ADA specifications.
CS
DPR
Reconstruct or
Request: Fort Hamilton Senior Center Expansion
9941 Fort
upgrade a building
Including parking lot repaving Explanation: Fort
Hamilton
in a park
Hamilton Senior Center has grown in recent
Parkway
years and an expansion of the building can
address growing programmatic needs. This
should include repaving of its parking lot which
is filled with large pot holes and depressions.
Refurbish to ADA specifications.
CS
DPR
Reconstruct or
Request: Russell Pederson Basketball Court
upgrade a park or
Explanation: Basketball Court utilized by Fort
amenity (i.e.
Hamilton High School and local residents are in
playground, outdoor
poor condition and dire need of restoration
athletic field)
work. Refurbish to ADA specifications.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/23
OMB
Other community
Maintain/Enhance funding to Community
board facilities and
Boards - additional funding allocated in FY 2020
staff requests
must be baselined to support broader outreach,
address technological needs, and professional
planning expertise.
8/23
DPR
Forestry services,
Restore forestry contract appropriations for tree
including street tree
pruning, removal and maintenance including
maintenance
stump removal. Restored allocations for
forestry's tree maintenance contracts are
needed. Years of deferred maintenance of street
and park trees have created a severe back log of
much needed attention. Stump removal is of
great concern as larger stumps can take up to
three years for removal.
10/23
BPL
Extend library hours
Increase funding to keep library branches open
or expand and
additional hours within the boundaries of
enhance library
Community District 10 and purchase additional
programs
computers and books. Working people and
students need access to libraries when the
work/school day ends. Weekend hours are
essential
12/23
DPR
Other park
maintenance and safety requests
Increase personnel to keep park restrooms open
beyond 3pm. Many parents and children utilize the parks after 3:00pm. Facilities need to be available for use.
13/23
DPR
Provide more
Funds to support five playground associates
programs in parks or
who will provide maintenance and recreational
recreational centers
programs at McKinley Park; Dyker Beach Park;
Shore Road Park at 79 Street; JJ Carty Park,
Owls Head Skate Park and Leif Ericson Park
15/23
DPR
Other park
Increase funding to hire additional gardeners
maintenance and
and grass cutting crews. All parks within
safety requests
Community Board Ten need year round grass
cutting and field maintenance. Currently, these
are seasonal positions which is not adequate for
our year round needs.
16/23
DPR
Forestry services,
Increased funding for forestry inspectors.
including street tree
Current inspection times have increased due to
maintenance
growing tree population. The average response
time for tree inspection request is 10 days which
is not adequate especially in cases of immediate
need.
17/23
DPR
Other park
Increase PS funding allocations to hire
maintenance and
additional maintenance operation staff to do
safety requests
rodent abatement. Additional personnel is
needed to address the neglected parkland in the
district due to the deferred maintenance in
recent years. At least ten additional
maintenance personnel are needed within
Community District 10.
20/23
DPR
Provide better park
Erosion control and maintenance of local parks.
maintenance
Funding for erosion control of local parks needs
to be increased as the erosion problem at some
of our local parks puts them in jeopardy of
losing trees and valuable landscaping.
22/23
DPR
Enhance park safety
Increase PS Funding allocations to expand parks
through more
enforcement patrols and security services.
security staff (police
Additional parks enforcement personnel are
or parks
needed to patrol the numerous parks
enforcement)
throughout District 10 for vandalism, traffic
violations, dog litter violations, barbequing in
non designated areas, illegal vending, using
permitted fields without a permit and related
violations to parks regulations.
23/23 DCLA Provide more public
art
Murals and art work add to public spaces. Recently mural work at Russell Pederson Playground and the overpass at Fort Hamilton Parkway and 62nd Street promise to deter graffiti and beautify both areas. Funding is needed to expand such efforts.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority Agency Request Explanation Location
image
1/33 DOT Repair or build new
seawalls or bulkheads
Initiate immediate study of Belt Parkway Infrastructure to address possible undermining caused by breaches along nearby Shore Road Promenade and bicycle path.
image
2/33 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
Request: Initiate Immediate Engineering Study of Shore Road Promenade/Bicycle Path Infrastructure/ to address serious recurring cave- ins threatening public safety. This study must include complete investigation of the infrastructure of the adjacent Combined Sewer Outfalls to determine source of water breaches. Explanation: There are currently 30 recurring cave-ins along the Shore Road Promenade/Bicycle Path within the confines of Community District 10. The source of the undermining needs to be examined and a resiliency redesign be put into place. The recurring cave-ins pose an immediate safety risk to bicyclists and pedestrians. The engineering study needs to protect this vital waterfront recreational space as well as protect adjacent Belt Parkway.
image
3/33 DFTA Renovate or
upgrade a senior center
Capital Funding for the relocation of Bay Ridge Center for Older Adults Senior Center. The Bay Ridge Center for Older Adults is in need of a new ADA compliant senior center for the over 1,000 seniors who attend and obtain a multitude of services provided by the center. Its current location is not adequate for its service delivery needs.
411 Ovington Avenue
image
4/33 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
Requests to initiate design for new and larger sewers with greater capacity including new catch basins to address flooding issues on Narrows Avenue and Colonial Road from Bay Ridge Parkway to 85th Street. A new catch basin was installed at Narrows Avenue at 79th Street in FY19 but further study is needed.
Narrows Avenue/Colonial Road Bay
Ridge Parkway 85 Street
image
5/33
DOT
Reconstruct streets
There are 2 identified street locations in Dyker
Heights that may be in need of trench
restoration or capital improvement due to
recurring street cave-ins and depressions. Bay
Ridge Avenue at 12th Avenue and 13th Avenue
between Bay Ridge Parkway and 76th Street.
6/33
DOT
Reconstruct streets
There are 3 identified street locations within
Community District Ten that may be in need of
trench restoration or capital improvement due
to recurring street cave-ins and depressions
96th Street between Shore Road and Marine
Avenue and 87th Street between 3rd and 4th
Avenue.
7/33
DEP
Inspect water main
The Department of Ennvironmental Protection
on specific street
does not have a proactive capital plan in
segment and repair
Brooklyn. Mounting complaints about recurring
or replace as
depressions/sewer back ups - aging sewer
needed (Capital)
system require further study at several locations
within Community District 10. 12th Avenue from
Bay Ridge Avenue to 74th Street;3rd Avenue
from 68th to 78th Streets; 11th Avenue from 62
to 72 Streets; 13th Avenue from Bay Ridge
Avenue to 79th Street; Bay Ridge Avenue from
Shore Road to 7th Avenue
8/33
DPR
Reconstruct or
Rehabilitate Owls Head Park Lower Path Erosion
upgrade a park or
with full Landscaping Plan and Drainage System
amenity (i.e.
Explanation: Owls Head Park located at 68th
playground, outdoor
Street at Shore Road is in dire need of
athletic field)
rehabilitation of its lower path. It is at a critical
state as dirt is drifting onto the sidewalk along
68th Street and clogging catch basins. All park
refurbishments to be compliant with ADA
specifications. The clogged catch basins impact
the Owls Head Sewage Treatment Plant.
9/33
DPR
Reconstruct or
Reconstruct path and benches. The park is
4th Avenue at
upgrade a park or
enjoyed by young and old. The path and
Shore Road
amenity (i.e.
benches have deteriorated and are need in
playground, outdoor
replacement. Also, water service needs to be
athletic field)
repaired. There are no operating water
fountains. Refurbish to ADA Specifications.
10/33
DPR
Reconstruct or
Renovation of Shore Road Park. Restoration of
upgrade a park or
Shore Road perimeter and drainage by sections
amenity (i.e.
of blocks to include Department of
playground, outdoor
Environmental Protection and Department of
athletic field)
Transportation. Reconstruct and rehabilitate
Shore Road Park adjacent to Shore Road from
72nd Street to 84th Street and on 86th Street to
97th Street. Missing hexagon pavement blocks
creating hazardous pedestrian conditions.
Untended brush and foliage has proliferated to
such an extent that only restoration of the
landscaping can restore the area.
11/33
BPL
Create a new, or
Capital Funds for needed improvement to
renovate or upgrade
library buildings and infrastructure in
an existing public
Community Board Ten including Bay Ridge -
library
Heating and Cooling system improvements
identified by Brooklyn Public Library.
12/33
BPL
Create a new, or
Capital funding needed improvements to library
renovate or upgrade
building at Dyker Heights branch including
an existing public
interior renovation, heating/cooling and exterior
library
windows. McKinley Park Branch needs new roof,
windows and interior renovation.
13/33
DOT
Repair or build new
Request complete restoration of 76th Street
76 Street
step streets
Step Street at Colonial Road including
Colonial Road
landscaping and drainage. This Step Street is in
Ridge Blvd.
poor condition with broken steps and
inadequate/broken railing. Minor repairs were
made but complete restoration is needed. The
steps overflow during heavy rains making the
step street unsafe to traverse.
14/33
DPR
Reconstruct or
Request: McKinley Park- Repairs to Comfort
upgrade a park or
Station Provide Handicap Accessible.
amenity (i.e.
Explanation: The comfort station is in need of
playground, outdoor
upgrades. Refurbish to ADA specifications.
athletic field)
15/33
DPR
Reconstruct or
Provide wheelchair accessible play equipment
upgrade a park or
and landscaping on 7th Avenue portion of park.
playground
16/33
DPR
Reconstruct or
Request: Rehabilitation of the interior path
upgrade a park or
inside Shore Road Park from 79 Street to 95th
amenity (i.e.
Street Explanation: The interior path is in dire
playground, outdoor
need of restoration with crumbling pathways.
athletic field)
Additionally, there are erosions alongside the
paths. It is very dangerous and difficult to walk
on this path
17/33
DEP
Evaluate a public
Provide funding to establish an Oyster Garden
location or property
alongside shoreline adjacent to Owls Head
for green
Wastewater Treatment Facility.
infrastructure, e.g.
rain gardens,
stormwater
greenstreets, green
playgrounds
18/33
DEP
Investigate odor
Owls Head Wastewater Treatment Plant -
6700 Shore
complaints about a
requires a complete modernization to ensure
Road
wastewater facility
that odors are kept under control.
and address/repair
Repair/replace sludge barge dock.
or make equipment
improvements as
needed (Capital)
19/33
DPR
Reconstruct or
Request: Rehabilitate 3 remaining ball fields at
upgrade a park or
Dyker Beach Park. Explanation: Our baseball
amenity (i.e.
fields in this district need to be rehabilitated.
playground, outdoor
The fields are in total disrepair. Refurbish to ADA
athletic field)
specifications.
20/33
DPR
Reconstruct or
Request: Complete rehabilitation of Shore Road
upgrade a park or
Park Ball field at 74th Street. Explanation: This
amenity (i.e.
heavily utilized field needs drainage system and
playground, outdoor
new dugouts that are able to be secured from
athletic field)
vandalism in PM hours. Refurbish to ADA
specifications.
21/33
DPR
Reconstruct or
Complete Rehabilitation of Shore Road Park
upgrade a park or
Field 4
amenity (i.e.
playground, outdoor
athletic field)
22/33
DPR
Reconstruct or
Request: Complete Renovation of Shore Road
upgrade a park or
Park at 3rd Avenue. Explanation: Refurbish to
amenity (i.e.
ADA Specifications. There is a small gated
playground, outdoor
unused area of parkland that needs to be
athletic field)
developed for community use.
23/33
DPR
Reconstruct or
Request: Dyker Beach Park Asphalt Field
upgrade a park or
Refurbish Explanation: Refurbish to ADA
amenity (i.e.
specifications. This asphalt field is underutilized.
playground, outdoor
This request is for the development of a multi-
athletic field)
use recreational field.
24/33
DPR
Reconstruct or
Refurbish Russell Pederson Playground - Russell
upgrade a park or
Pederson Playground is in need of restoration
amenity (i.e.
work including new play equipment and spray
playground, outdoor
showers. Separate adult exercise area from
athletic field)
children play equipment. Refurbish to ADA
specifications.
25/33
DPR
Reconstruct or
Refurbish Leif Ericson Park Ball fields 67th Street
upgrade a park or
at 6th Avenue. Synthetic turf. Explanation: The
amenity (i.e.
ball fields at Leif Ericson Park are in poor
playground, outdoor
condition. The Fields are well utilized by local
athletic field)
leagues and in dire need of refurbishment to
ADA specifications.
26/33
DPR
Reconstruct or
Request: Tennis Courts need to be refurbished in
upgrade a park or
Bay 8th Street; Leif Ericson Park; and Shore
amenity (i.e.
Road Park. Explanation: Local Junior High
playground, outdoor
Schools and High Schools utilize these tennis
athletic field)
courts that are in need of refurbishment. All
refurbishments to be ADA compliant.
27/33
DEP
Investigate odor
Request to initiate study of Combined Sewer
Shore Road
complaints about a
Outfalls (CSOs) Infrastructure inspection along
Promenade
wastewater facility
the Shore Road Promenade from the 69th Street
Bay Ridge
and address/repair
Pier to Bay 8th Street to determine if upgrades
Avenue Bay
or make equipment
are needed in wake of Superstorm Sandy AND
8th Street
improvements as
sinkholes that have developed along the Shore
needed (Capital)
Road Promenade. Functionality of these CSOs is
critical to the maintenance of the Shore Road
Promenade and the adjacent Belt Parkway.
28/33
DPR
Provide a new, or
Initiate Engineering Study for Placement for a
new expansion to, a
comfort station on the Shore Road Promenade.
building in a park
Residents especially seniors have requested an
accessible comfort station along the Shore Road
Promenade. An engineering feasibility study is
being asked to determine if a comfort station
could be installed along the bicycle path or
promenade.
29/33
DPR
Reconstruct or
Complete Rehabilitation of Shore Road Park
upgrade a park or
Field 3
amenity (i.e.
playground, outdoor
athletic field)
30/33
DPR
Reconstruct or
Complete Refurbishment of Dyker Beach Park
upgrade a park or
Playground including play equipment, water
amenity (i.e.
fountains, sprinklers and infrastructure.
playground, outdoor
Refurbish to ADA specifications.
athletic field)
31/33
DPR
Reconstruct or
The perimeter of Dyker Beach Park/Golf Course
upgrade a park or
is heavily utilized by pedestrians and cyclists as
amenity (i.e.
a form of recreational exercise. A track with
playground, outdoor
divided lanes for pedestrians and cyclists with
athletic field)
distance markings would be beneficial to
residents. Capital Project to create a
walking/cycling track around the perimeter of
Dyker Beach Park/Golf Course or inside the
asphalt ball field at Dyker Beach Park.
32/33
DPR
Reconstruct or
Complete refurbishment of Leif Ericson Park
upgrade a park or
including play equipment, water fountains and
playground
infrastructure to ADA specifications.
33/33
DOT
Roadway
Support the need to increase contract funding
maintenance (i.e.
appropriations for expansion of milling,
pothole repair,
resurfacing and repaving programs to improve
resurfacing, trench
local streets and throughways. There are
restoration, etc.)
several roadways in need of resurfacing within
Community District Ten.
CS
NYPD
Provide surveillance
Several new surveillance cameras were installed
cameras
due to funding from the New York City Council.
Resident requests for additional surveillance
cameras along commercial corridors and
problematic locations is warranted.
CS
DPR
Reconstruct or
Request: JJ Carty Park Refurbishment of
upgrade a park or
Basketball Courts. Explanation: The basketball
amenity (i.e.
courts are in dire need of reconstruction.
playground, outdoor
Refurbishments to meet ADA compliance.
athletic field)
CS
DPR
Reconstruct or
JJ Carty Park Refurbishment of Playground- The
upgrade a park or
playground is in dire need of restoration and
amenity (i.e.
new play equipment. Refurbish to meet ADA
playground, outdoor
compliance.
athletic field)
CS
DPR
Reconstruct or
Request: Owls Head Park Basketball Court
upgrade a park or
Explanation: Basketball Court is in poor
amenity (i.e.
condition and in need of refurbishment.
playground, outdoor
Refurbish to ADA specifications.
athletic field)
CS
DPR
Reconstruct or
Request: Reconstruction of Vinland Playground
7420 Shore
upgrade a park or
located at Shore Road and 95th Street.
Rd
amenity (i.e.
Explanation: This playground is in poor
playground, outdoor
condition and needs to be refurbished. Refurbish
athletic field)
to ADA specifications.
CS
DPR
Reconstruct or
upgrade a building in a park
Request: Fort Hamilton Senior Center Expansion
Including parking lot repaving Explanation: Fort Hamilton Senior Center has grown in recent years and an expansion of the building can address growing programmatic needs. This should include repaving of its parking lot which is filled with large pot holes and depressions.
Refurbish to ADA specifications.
9941 Fort
Hamilton Parkway
CS
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Request: Russell Pederson Basketball Court Explanation: Basketball Court utilized by Fort Hamilton High School and local residents are in poor condition and dire need of restoration work. Refurbish to ADA specifications.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/23
OMB
Other community
Maintain/Enhance funding to Community
board facilities and
Boards - additional funding allocated in FY 2020
staff requests
must be baselined to support broader outreach,
address technological needs, and professional
planning expertise.
2/23
NYPD
Assign additional
Increase patrol strength at 68th Police Precinct
uniformed officers
as well as civilian personnel levels.
3/23
FDNY
Provide more
Maintain personnel funding levels for
firefighters or EMS
firefighting personnel. Funding levels must be
workers
sustained to maintain effective firefighting and
prevention services and to overcome attrition.
4/23
DOB
Address illegal
Inspectors are needed to address the growing
conversions and
number of complaints from area residents. Since
uses of buildings
2010 the number of complaints from area
residents of single and two-family homes being
converted and occupied as SROs and transient
housing is on the rise.
5/23
DFTA
Increase home
The number of seniors receiving home delivered
delivered meals
meals continues to rise in Community District
capacity
10. In 2018 there is a waiting list of 50
applicants.
6/23
NYPD
Assign additional
Additional school crossing guards needed within
crossing guards
Community District Ten. CB10 is requesting to
increase our allotment to 40.
7/23
DSNY
Provide more
Request to provide sufficient funding to
frequent litter
maintain additional basket collection trucks in
basket collection
commercial corridors within CD10. Commercial
sectors generate excessive loads. Sunday
cleaning and collection services are needed to
remove heavy weekend overflow. Also, a critical
need exists to expand MLP staffing
8/23
DPR
Forestry services,
Restore forestry contract appropriations for tree
including street tree
pruning, removal and maintenance including
maintenance
stump removal. Restored allocations for
forestry's tree maintenance contracts are
needed. Years of deferred maintenance of street
and park trees have created a severe back log of
much needed attention. Stump removal is of
great concern as larger stumps can take up to
three years for removal.
9/23
DOHMH
Reduce mosquito
populations
Increase staffing levels for mosquito control
efforts. This is needed in areas of high mosquito concentration to curtail spread of West Nile Virus.
10/23
BPL
Extend library hours
Increase funding to keep library branches open
or expand and
additional hours within the boundaries of
enhance library
Community District 10 and purchase additional
programs
computers and books. Working people and
students need access to libraries when the
work/school day ends. Weekend hours are
essential
11/23
DSNY
Increase
CD10 has recurring illegal dumping on
enforcement of
commercial corridors and at corner baskets.
illegal dumping laws
There is also illegal dumping along the
sidewalks adjacent to the MTA 62nd railroad
tracks.
12/23
DPR
Other park
Increase personnel to keep park restrooms open
maintenance and
beyond 3pm. Many parents and children utilize
safety requests
the parks after 3:00pm. Facilities need to be
available for use.
13/23
DPR
Provide more
Funds to support five playground associates
programs in parks or
who will provide maintenance and recreational
recreational centers
programs at McKinley Park; Dyker Beach Park;
Shore Road Park at 79 Street; JJ Carty Park,
Owls Head Skate Park and Leif Ericson Park
14/23
DOHMH
Reduce rat
Increase staffing levels for inspection and
populations
baiting services for rodent control. Proliferating
problems created by rodent infestation along
lots and highway properties and other pest
related problems must be addressed by
enhancing the workforce for pest control.
15/23
DPR
Other park
Increase funding to hire additional gardeners
maintenance and
and grass cutting crews. All parks within
safety requests
Community Board Ten need year round grass
cutting and field maintenance. Currently, these
are seasonal positions which is not adequate for
our year round needs.
16/23
DPR
Forestry services,
Increased funding for forestry inspectors.
including street tree
Current inspection times have increased due to
maintenance
growing tree population. The average response
time for tree inspection request is 10 days which
is not adequate especially in cases of immediate
need.
17/23
DPR
Other park
Increase PS funding allocations to hire
maintenance and
additional maintenance operation staff to do
safety requests
rodent abatement. Additional personnel is
needed to address the neglected parkland in the
district due to the deferred maintenance in
recent years. At least ten additional
maintenance personnel are needed within
Community District 10.
18/23
NYPD
Assign additional
In keeping with the Mayor's Vision Zero
traffic enforcement
initiative, additional traffic control agents are
officers
needed at high crash and heavily travelled
commercial corridors. These include near
entrance of Brooklyn Queens Expressway and to
handle Verrazano Narrows Bridge traffic
disruptions and summer volume. 86th Street at
4th Avenue and 5th Avenue 65th Street at 6th,
7th and 8th Avenues and Fort Hamilton
Parkway Additional agents needed to handle
Verrazano Narrows Bridge traffic disruptions at
92nd Street corridor; 86th Street at Gatling
Place
19/23
DOHMH
Other animal and
To provide and implement a long term plan to
pest control
eradicate bed bugs. Bed bug infestation is a
requests
growing citywide problem. In Community
District 10 area residents are concerned about
the growing problem of bed bug infestation,
specifically new infestations in the subways. We
are also concerned about the economic toll it
places on local families who are struggling to
make ends meet. Extermination of an average
two bedroom apartment can cost over $1,000
with additional cost to replace mattresses,
furniture and clothing. Members would like to
see a citywide forum with a goal of providing
and implementing a long term plan to deal with
bedbugs.
20/23
DPR
Provide better park
Erosion control and maintenance of local parks.
maintenance
Funding for erosion control of local parks needs
to be increased as the erosion problem at some
of our local parks puts them in jeopardy of
losing trees and valuable landscaping.
21/23
DSNY
Increase
Frequent complaints are received by the District
enforcement of
Office regarding canine waste. It is a quality of
canine waste laws
life issue that frustrates residents concerned
about street cleanliness.
22/23 DPR Enhance park safety
through more security staff (police or parks enforcement)
Increase PS Funding allocations to expand parks enforcement patrols and security services.
Additional parks enforcement personnel are needed to patrol the numerous parks throughout District 10 for vandalism, traffic violations, dog litter violations, barbequing in non designated areas, illegal vending, using permitted fields without a permit and related violations to parks regulations.
image
23/23 DCLA Provide more public
art
Murals and art work add to public spaces. Recently mural work at Russell Pederson Playground and the overpass at Fort Hamilton Parkway and 62nd Street promise to deter graffiti and beautify both areas. Funding is needed to expand such efforts.

