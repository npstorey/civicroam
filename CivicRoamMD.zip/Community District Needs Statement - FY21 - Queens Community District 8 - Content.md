- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 8 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1rdLIj3vRN3hSwRJlwJa8aiO2t8pPYPO_/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1rdLIj3vRN3hSwRJlwJa8aiO2t8pPYPO_/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
8
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 8
image
Address: 197-15 Hillside Avenue Phone: (718) 264-7895
Email: qn08@cb.nyc.gov
Website: www.nyc.gov/queenscb8
Chair: Martha Taylor District Manager: Marie Adam-Ovide
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 8, Queens is bounded by the Long Island Expressway to the north, Hillside Avenue to the south, Van Wyck Expressway to the west and the Clearview Expressway to the east. It includes the communities of Briarwood, Flushing Suburban, Flushing Heights, Fresh Meadows, Hillcrest, Hillcrest Estates, Holliswood, Jamaica Estates, Jamaica Hills, Kew Gardens Hills, Utopia and West Cunningham Park. It also includes parts of Hollis and Queens Village (north of Hillside Avenue). These communities are overwhelmingly residential with several commercial strips. There are over 150,000 residents of Community Board 8. There has been a moderate but steady increase in population. Our residents are mostly middle income, multi-ethnic, multi-racial individuals who own their own homes, condos and co-ops or are rentors. The residences consist of one and two-family homes, garden apartments, large apartment buildings such as the Fresh Meadows Development, co-ops such as Electchester, Hilltop Village and Parkway Village. Our district also houses the New York City Housing Authority complex - Pomonok. It is important to understand that our population, as counted by the Census, does not accurately represent the need for services in our district. Queens College, CUNY Law School, St. John’s University and Lander College for Men are located within our borders. Thousands of students who are not counted by the US Census reside in our community while attending college/university from the months of August through May. The services that we receive should reflect the needs of these individuals along with those of our permanent residents.
Community Board 8 residents are concerned with quality of life issues, upgrading the infrastructure, personal safety and security, education and maintaining their fair share of City services. TRANSPORTATION - Many of our roads are in poor condition. We continue to request an increase in asphalt allocation for street resurfacing. Some of our roads are sinking and need to be reconstructed. To this end, we are asking for increased funding for trench restoration.
We request stand-alone funding for curb installation and replacement. There has been a backlog of curb repair and curb installation for over a decade. Currently, DOT replaces curbs only when the adjoining sidewalk is repaired.
Instead of repairing their own sidewalks within 45 days of receiving the notice of violation, homeowners choose to wait for DOT contractors to do the work. This is the only way to ensure that DOT replaces broken curbing. As a result, sidewalks remain damaged for a longer period of time and the danger to pedestrians is also prolonged. In addition, this will cost the City additional funds in case of lawsuits due to negligence. BUILDINGS - Much of Community Board 8’s housing stock is residentia with many one-family and two-family dwellings. Additional Buildings Department inspectors are necessary to enforce existing regulations and address quality of life violations. DOB introduced the Development Challenge Process initiative a many years ago. Additional plan examiners are needed to review and respond to these challenges and the many requests that we receive for audits. In addition, more plan examiners would eliminate the self-certification by architects and engineers. We receive our share of illegal conversion and illegal occupancy complaints. The lack of affordable, regulated housing is the root cause of the prevalence of illegal apartments. There are very few rent stabilized apartments within Community District 8.
SANITATION - Although Community Board 8 has relatively clean streets, we have issues that need attention. With the steady increase in population, our superintendent must receive the support necessary to address our sanitation issues: • The paved center malls require year-round cleaning and more frequent seasonal weed-control. • Retain the five day-a-week pick-ups at public schools and extra pick-ups at Pomonok Houses. • Sanitation Police are needed for night patrol to discourage illegal dumping, especially on abandoned properties. • Additional agents for Sanitation Code Enforcement are needed to address the quality of life complaints that we receive. While the enforcement issues for residential properties are addressed, we noticed that enforcement of our commercial establishments is insufficient. While we do not want to stifle business by fining our small business owners, some of them are repeat offenders who show a total disregard for the community. The issuance of a violation is the only way to receive cooperation. • Unlike some other community boards, CB8 has no dedicated pick-up truck for litter baskets in our commercial areas. This must be provided to ensure the cleanliness of our commercial strips. The Adopt-a-Basket program must be better promoted to encourage public and private sector partnerships. This should be promoted through public service announcement on television and radio.
SENIORS/YOUTH/EDUCATION/LIBRARIES - A civilization is best judged by the way it treats its most vulnerable members (seniors and youth). There has been a marked increase in the youth and senior population from 2000 to the present and such an increase demands additional services. Increased funding for aftershool programs, summer
youth employment, senior transportation and NORCs are needed. Our schools must have the necessary equipment (smart boards, computers, etc.) for our students to compete. In today's world, our libraries have become multimedia centers that provide access to computers and the internet for adults and children. They serve thousands of New Americans who do not have access to home computers and/or the internet. It is vital that additional funds be provided to our libraries so that they may be open seven days a week and have up to date software and hardware for our residents.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 8
image
The three most pressing issues facing this Community Board are:
Parks
PARKS - The most attractive characteristic of Community Board 8 is its suburban nature. Our residents value the many parks and playgrounds that we have within our borders. All of them are heavily used and, as such, they must be well maintained. Our parks sponsor many events throughout the year such as concerts, Shakespeare presentations, family fun days and movies that attract thousands of residents of CD8 and the surrounding areas.
Street conditions (roadway maintenance)
STREET CONDITION - Many of our roads are in need of trench restoration. Each passing car, delivery truck and New York City bus add pressure to the roads and undermine the street. We asked for funding for trench restoration for several locations which have been on our list for many years. Several of our bus routes have broken bus pads that require replacement. These items have also been on our list for many years.
Street flooding
Community Board 8 is its suburban nature. Our residents value the many parks and playgrounds that we have within our borders. All of them are heavily used and, as such, they must be well maintained. Our parks sponsor many events throughout the year such as concerts, Shakespeare presentations, family fun days and movies that attract thousands of residents of CD8 and the surrounding areas. FLOODING - The residents of Fresh Meadows, Utopia Estates, Hillcrest and Kew Gardens Hills are very concerned with the water table rising and inadequate sewer systems. In recent years, there have been many water main installations and upgrades; however, there have been very few sewer projects. We have requested installation of new sewer lines along Hillside Avenue for many years.
Hillside Avenue is a low lying area bordering Holliswood, Jamaica Estates, Jamaica Hill, Hollis and Briarwood. The F train, which is the only subway line that services our district, has been flooded many times after rainstorms. Many residents have no other means of getting into and home from Manhattan. This also affects businesses along Hillside Avenue. Hillside Avenue from 195th Street to 197th Street is flooded with water after each rainfall and the street deteriorates, as a result. There is just nowhere for the water to go. STREET CONDITION - Many of our roads are in need of trench restoration. Each passing car, delivery truck and New York City bus add pressure to the roads and undermine the street. We asked for funding for trench restoration for several locations which have been on our list for many years.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 8
image
M ost Important Issue Related to Health Care and Human Services
Chronic diseases (diabetes, heart disease, etc.)
Community District 8 has an aging population with the majority of residents are older than 25 years old. Our residents have a 14% rate of adults diagnosed with diabetes. This is higher than Queens as a whole and the City of New York as per the NYC Community Health Profiles of 2018. In addition, 20% of our population suffers from obesity. About a quarter of of our population suffers from hyper-tensity.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Community Board 8 Queens supports funding for the expansion of access to primary healthcare services for those within CD8. We endorse the new paradigm of healthcare, not just sick care, which must include the traditional care provided by physicians and midlevel health providers plus efforts to encourage healthy living. Some examples would be: nutritional education, programs for smoking cessation, exercise as part of one’s routine and many others.
Special emphasis must be placed on managing chronic diseases. Care Managers should be utilized to ensure that individuals receive transdisciplinary health care with a goal toward controlling chronic disease, prevention of acute incidents, emergency room visits, hospitalization and optimizing independence.
Needs for Older NYs
According to the US Census of 2010, there were over 20,000 individuals within our district who were 62 years old and over. This is a significant increase from the previous census taken in 2000. There are many benefits to seniors aging in place: 1) Keeping a familiar environment 2) Fostering Community Continuity 3) Maintaining their social networks 4) Strengthening of family ties 5) Fostering both their physical and mental wellbeing We do not have any NORCs for our residents who reside in apartment buildings nor NORCs (WOW) for our 1-2 family residences within our district. We want our seniors to remain in their neighborhoods and the NORCs facilitate the desire of many seniors to age in place. These are done through the multi-faceted services that they provide.
Needs for Homeless
Community Board 8 has one family shelter in Briarwood and it is in need of air conditioning. Briarwood shelter, when built was considered the model shelter for the City of New York. Unfortunately, this model shelter has air conditioning only in the areas where the staff works. There is no air conditioning where the residents sleep. We have asked for many years that air conditioning be provided for these families with children. The response received in FY 2016 was that DHS provides a cooling room in every shelter. When not available, the residents are given the location of other cooling rooms. How does that help the families with young children who cannot sleep at night due to the heat? The last two fiscal years the responses given were that further study was necessary. Keep in mind that when we originally requested this in Fiscal Year 2010, the response was that this was being studied. How long does it take to study this before action is taken? This shelter has been waiting a long time for this much needed accommodation and we look forward to a plan of action this fiscal year.
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
4/35
DHS
Other request for
Air conditioning is needed for the Briarwood
80-20 134th
services for the
Family Shelter. This can be achieved by
Street
homeless
upgrading the electrical system to facilitate
window units. Cooling rooms are not sufficient.
The residents should be afforded the same
treatment as the staff who work in temperature
controlled rooms.
7/35
HHC
Renovate or
Funds needed for fit-out/interior construction of
82-68 164th
upgrade an existing
the 8,000 sq. ft. of community space within the
Street
health care facility
T-Building at the Queens Hospital Center. Dunn
Development is renovating the T-Building and
has agreed to set aside this space for a
community center that will provide services for
all ages. This building will also comprise 206
housing units including: regular rental units,
special needs units, middle income units and
low income units.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
13/24
DFTA
Enhance NORC
Provide funding to create NORCs in Community
programs and
Board 8.
health services
15/24
DFTA
Increase
We have a multi-ethnic population. In recent
transportation
years, we have seen an increase in people who
services capacity
identify as Asian. As such, the services provided
for seniors need to meet that change. When
services are not readily available for one ethnic
group, transportation to neighboring centers
that do is desirable. While the population is not
necessarily homebound but the frail senior
population does have issues with using mass
transit. For those that are homebound, they
need to interact with people from the outside
world. This could possibly mean using
technology to help them stay connected. They
can participate in senior activities remotely (i.e.
through Skype).
17/24 DFTA Other senior center
program requests
Enhance funding for senior services. Funds are needed to meet the demands for services. (408202018E)
image
24/24 DOHMH Provide more
tuberculosis information and services
Community Board 8 supports tuberculosis vans for new immigrants and funds for sexual health. We understand that these funds may have been reduced by the Federal Government and we want to curtail the spread of these diseases through prevention and education.
image
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 8
image
M ost Important Issue Related to Youth, Education and Child Welfare
Childcare services
In today's world it is often vital that both parents have jobs to make ends meet. The two major problems that arise are access to affordable preschool child care and enough after-school programs to meet the needs of these parents. One in five youth in Community District 8 from Kindergarten through 8th grade is obese. It is vital to provide athletic opportunities both in and out of schools to lower this outrageous number.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
11/35
SCA
Provide a new or
Upgrade the sound system for the auditorium of
expand an existing
P.S. 26. Upgrade the electrical wiring for P.S.26Q
elementary school
for the installation of air conditioning in the
auditorium, gymnasium and cafeteria. The
school is used in the summer to house the P.S.
224 students who are developmentally disabled.
They require temperature controlled
environments as per the mandate for ADA
compliance.
14/35
SCA
Provide technology
Upgrade electrical wiring to 220 to support
upgrade
electrical needs of smart boards and air
conditioners for P.S. 173.
22/35
SCA
Renovate or
Convert former teacher's cafeteria into a
upgrade a middle or
classroom.
intermediate school
23/35
SCA
Renovate or
Replace tables in cafeteria; replace auditorium
upgrade an
seats; install auditorium wall padding and
elementary school
renovate outdoor wooded area.
24/35
SCA
Renovate or
Upgrade electrical system, upgrade library and
upgrade an
science lab at P.S. 173Q - The Fresh Meadow
elementary school
School.
26/35
SCA
Renovate or
Upgrade school technology to use parent
upgrade a middle or
coordinator's office as a web-based resource at
intermediate school
P.S. 178Q.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
5/24 DYCD Provide, expand, or
enhance the Summer Youth Employment Program
Increase funding for summer youth employment programs. Every year the percentage of funds allocated to meet the needs for the program has been diminished. The number of youth (in the age group of 14 to 24 years old) that qualify for summer youth employment has increased.
The yearly funding to meet that need has fallen short.
image
14/24 DYCD Provide, expand, or
enhance Cornerstone and Beacon programs (all ages, including young adults)
Increase funding for Beacon Programs and any other after school programs in CD8. Funds need to increase to meet the growing need in the community.
image
23/24 DOE Other educational
programs requests
Upgrade musical instruments at P.S. 178 to expand the music program and include a band ($10,000 needed).
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 8
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
Additional Equipment and Vehicle Maintenance About 20% of individuals in Community District 8 are obese; hence, we must have the proper equipment to address their needs. Additional equipment such as two bariatric ambulances with lifts and special wheelchairs are necessary. We would also greatly benefit from a mobile emergency response vehicle (MERV), a rapid response vehicle and a mobile command vehicle for the borough. The MERV is to be used to shelter and treat individuals in one place in case of a disaster. The rapid response vehicle is needed to respond ahead with a liaison to coordinate during emergencies. The ability to enhance or reestablish communication and coordination during emergency incidents is a must. It is best to be prepared by having the right equipment, as we do not know when emergencies or disasters will occur.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
5/35
FDNY
Other FDNY facilities
Provide the funds to complete all work orders
and equipment
from the fire houses within Community District
requests (Capital)
8 and add cameras. Install security
cameras/system at every fire house in
Community District 8 to prevent vandalism and
theft. Engine 298 - Ladder 127 - 153-11 Hillside
Avenue Engine 299 - Ladder 152 - 61-20 Utopia
Parkway Engine 315 - Ladder 125 - 159-06
Union Turnpike. It has come to our attention
that our fire houses have been vandalized and
electronics were stolen.
13/35
NYPD
Provide surveillance
Argus cameras are needed to assist in solving
cameras
crime.
32/35
FDNY
Provide new
Vehicle is designed with lifts and special
emergency vehicles,
wheelchairs to be used for individuals over 500
such as fire trucks or
lbs.
ambulances
33/35
FDNY
Provide new
This is vehicle is used for disasters and treat
emergency vehicles,
individuals in one place.
such as fire trucks or
ambulances
34/35
FDNY
Other FDNY facilities
A rapid response vehicle (Sierra Pick-up Truck) is
and equipment
needed to respond ahead with a liaison. This is
requests (Capital)
used for coordination purposes..
35/35
FDNY
Other FDNY facilities
A mobile command vehicle is needed for the
and equipment
Borough of Queens.
requests (Capital)
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/24
NYPD
Other NYPD programs requests
Traffic Safety programs for afterschool program participants.
158-40 76th
Road
18/24
FDNY
Expand funding for fire prevention and life safety initiatives
Increase funding for CPR Training Program and for the Fire & Life Safety Education Outreach
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 8
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water runoff and flooding
Community Board 8Q's Sanitation & DEP Committee, in conjunction with the Area Chairs, have identified water runoff and flooding as the most important Core Infrastructure and City Services needed for CB8Q. In recent years, we have seen a surge of storms that have placed a great burden on our sewer system resulting in flooded streets. We have experienced serious flooding to our resident's and commercial establishment's basements and ponding of water on our streets throughout the Community District. Some storms have created flooding where residents had to abandon their cars and take refuge on the roofs of their vehicles. Flooding is a threat to both human life and property. Ponding is increasingly a public health concern given the West Nile Virus and the possibility of future transmission of the Zika Virus. Given the trend toward warming climates, other mosquito transmitted viruses currently found further south may be an issue a few decades in the future. We chose water runoff and flooding as our most important issue; however, these are interrelated challenges that contribute to the city's capacity to handle increased rainfall.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Kevin will provide statement on capacity ,.
Needs for Sanitation Services
While most of our streets are kept clean and CD8 score cards are better than many other districts, there is room for improvement. This is especially true of our commercial strips (Hillside Avenue and Queens Boulevard). We are asking for more bins (i.e. the new trio of garbage, paper and bottle recycling bins) for the district. Keep in mind that people come from all over, including Nassau County, to get to the Jamaica Estates 179th Street/Hillside Avenue subway station by many bus lines to board the F train to Manhattan. It is a transportation hub. Our bins fill up quickly with coffee cups in the morning and all sorts of litter throughout the day. When they overflow our streets are littered. We have asked the Department to provide a dedicated basket truck for many years. We are pleased that we are getting seven-day basket collection service this year. We continue to support funding for this service for future years. We continue to support enforcement of our commercial strips and would appreciate extending the enforcement hours past 5 p.m. The shopkeepers along Hillside Avenue have gotten wise to the fact that sanitation enforcement officers are not on duty in the evening. During that time they block their sidewalks with merchandise leaving a narrow path for pedestrians. Individuals with wheelchairs or baby carriages are often forced onto the street.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
25/35 DSNY Provide new or
increase number of sanitation trucks and other equipment
Purchase additional garbage trucks to ensure enough capacity for organics recycling.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/24
DEP
Clean catch basins
Increase personnel for the maintenance of catch
basins, sewers and water mains in CD8.
7/24
DSNY
Provide more
Dedicated basket trucks are needed to empty
frequent litter
street bins more frequently. This would improve
basket collection
the cleanliness of our streets. Hillside Avenue
(Francis Lewis Boulevard to Queens Boulevard)
Queens Boulevard (Hillside Avenue to Main
Street) and Main Street. Routine center mall
cleaning is also needed throughout the seasons.
Additional funds should be allocated to ensure
that all commercial areas receive the same
frequency of service.
16/24
DSNY
Other enforcement
Increase personnel for Sanitation Police to
requests
increase sanitation inspection in all categories
and throughout the district.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 8
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
To facilitate the demands of the District, the Building/Housing Committee is recommending Building Code Enforcement as a priority since it will protect homeowners, coop/condo owners and renters alike. To further support the request for Building Code Enforcement, the borough of Queens has the second most number of requests for code enforcement in the City.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
There is a need for affordable housing in Community District 8. There is a significant percentage of renters within our district who are rent burdened. According to the NYU Furman's Annual "State of the City's Housing and Neighborhoods," our median monthly rent in 2014 was $1353. In addition, there was an increase in the rent burden for all renters from 17.4% in 2000 to 31.7% in 2014. There was an even more drastic change for those renters who have low incomes. It changed from 35.4% in 2000 to 58.5% in 2014. Community Board 8 had a change in zoning along Hillside Avenue that will facilitate larger developments. We welcome a certain number of affordable units set aside to address the great number of rent burdened residents.
Needs for Economic Development
Our commercial strips could use a facelift by improving cleanliness, adding streetscape and changing the façade of the businesses. We welcome the establishment of Business Improvement Districts to help revitalize our commercial strips.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
4/24
DOB
Assign additional
Hire a dedicated inspector for Queens
120-55
building inspectors
Community Boards' half day inspections. The
Queens
(including
number of requests sent to the Queens Borough
Boulevard,
expanding training
Office is much greater than any other office in
Queens, New
programs)
the five boroughs. The Queens' Office had a
York, NY
part-time inspector that used to accompany the
District Managers on site visits on a monthly
basis. Unfortunately, this person went on sick
leave and was never replaced. We are
requesting that a new full-time inspector be
hired as a replacement. (408202008E)
12/24
SBS
Support
Hillside Avenue could use a facelift to make it
Hillside
development of
more appealing for people that patron the
Avenue 179th
local Storefront /
diverse businesses. Improving cleanliness,
Street
Facade
maintenance of the storefronts and
Queens
Improvement
beautification through streetscape.
Boulevard
Program
TRANSPORTATION
Queens Community Board 8
image
M ost Important Issue Related to Transportation and Mobility
Roadway maintenance
In looking at the traffic and transportation infrastructure in CB8, the Transportation Committee recognizes that street maintenance is our highest priority. Our roadways are deteriorating. Many have become hazardous to motorists and pedestrians. Many of our streets have serious potholes, sinkholes and depressions caused by inadequate repairs after street excavations. Patchwork repairs are the norm where what is needed is a comprehensive plan to improve and maintain our streets and roadways. In addition, damage caused by over-sized trucks and heavy vehicles on non-commercial streets have resulted in significant deterioration to the roadbeds and their substructure. The results of this have been the breaking of subterranean pipes which cause street collapses. In our district, resurfacing has raised roadbeds and reduced curbs on streets, center islands and malls. This deterioration causes surface water, during heavy storms, to overflow the sidewalks which results in serious flooding conditions and damage to the streets, curbs and properties in our community. Our City should focus on improving the streets and roads in Queens and stop deferring their maintenance. These improvements are sorely needed and can be visible proof to the residents of Queens that our tax dollars are being used to improve our infrastructure and their quality of life.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
In addition to the stated needs below for street resurfacing, sidewalk construction and street reconstruction, there has not been any funds allocated for separate curb repair in over a decade. When curbs are broken, this condition creates a trip hazard. This makes the City liable for tort claims. In addition, water collects where there are missing curbs and ultimately damages sidewalks. Pedestrian and traffic safety are items of concern, as well. We request adequate funding for the installation of stop signs, traffic lights, and traffic signs.
Needs for Transit Services
Our community needs additional buses to service the growing population (i.e. Q76, Q30, Q20). The residents of Kew Gardens Hills would welcome the return of the Q74 bus to Vleigh Place. The private bus lines were added to the Transit Authority fleet and still have no posted schedules (i.e. Q25, Q24 and Q65). This is a necessity for our seniors who are not technology savvy and cannot use the MTA Bus Time App. We urge that the City explores the possibility of increasing service capacity along the F subway line. The trains are often at capacity when they reach the 169th Street station. The commuters at the subsequent subway stops are unable to board the train.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/35
DOT
Reconstruct streets
Reconstruction/trench restoration is needed to
address street depression and sinkholes. 75th
Avenue (186th St. to 188th St.) Avon Road
(Chevy Chase St. to 188th St.) 181st Street (67th
Ave. & 69th Ave.)
2/35
DOT
Repair or construct
Installation of new sidewalk and curbs: A) 170th
new curbs or
Street (Goethals Ave and Union Turnpike) B)
pedestrian ramps
171st Street (65th Avenue and 67th Avenue) C)
Utopia Parkway (73rd Avenue to Horace
Harding Expressway including center medians
D) East side of 185th Street (64th Avenue to
67th Avenue)
3/35
DOT
Repair or construct
Install and/or repair bus pads. CB8 requested
new curbs or
replacement of the cracked and broken bus
pedestrian ramps
pads since 2005. A) 188th Street & Union
Turnpike B) 188th Street from Union Turnpike to
73rd Avenue C) Hillside Avenue (westbound
lane) from Francis Lewis Boulevard to 205th
Street. Hillside Avenue is the route for about 10
bus lines. The lack of bus pads makes it
necessary for numerous requests for repairs of
hummocks each year. Hillside Avenue was
resurfaced a few years ago. Install bus pads to
prevent the newly resurfaced street from
deteriorating.
12/35
DOT
Reconstruct streets
Goethals Ave is partially built. As one travels
Goethals Hall
eastbound along Goethals Avenue, the road
168 Street
narrows. It was not not built to its fully mapped
170 Street
width and a portion of the street has vegetation
instead of asphalt.
16/35
DOT
Repair or construct
Repair and/or create new concrete medians on
Utopia
new medians or bus
Utopia Parkway. The medians are broken and
Parkway 69th
pads
many are at the same level as the roadway.
Avenue
Horace
Harding
Expressway
18/35
DOT
Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Replace and/or repair the cobblestones that make up the street at Clover Hill Place. The road is very steep. The cobblestones are needed to provide traction for DSNY vehicles to remove snow in the winter. The road is very steep and this is needed to ensure that residents and emergency vehicles can reach the top of the hill if necessary.
Clover Hill Place Clover Hill Road Dead End
20/35
DOT
Repair or construct new curbs or pedestrian ramps
New sidewalk is needed on north side of Goethals Avenue from 168th Street to 170th Street. Area abuts NYC property. Sidewalk is needed for pedestrian safety.
Goethals Avenue 168th Street 170th Street
CS
DOT
Reconstruct streets
Reconstruction/trench restoration is needed to address street depression and sinkholes on 186th Street [Part of last year's Tracking Code 408202001C. Request has already been funded and requires continued support].
186th Street 73 Avenue 75 Avenue
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
19/24
DOT
Other expense
Increase arterial highway forces for cleaning
traffic
areas adjacent to highways and assign
improvements
additional personnel for maintenance.
requests
Community District 8 is boarded by several
arterial highways (LIE, GCP, Van Wyck and
Clearview Expressway). These areas are often
full of litter. They are only cleaned by DOT every
three or four weeks. Cleaning is needed at least
on a weekly basis.
21/24
NYCTA
Expand bus service
Our community needs additional buses to
frequency or hours
service the growing population (i.e. Q76, Q30,
of operation
Q20, Q88 - Express/Limited). The residents of
Kew Gardens Hills would welcome the return of
the Q74 to Vleigh Place. The private bus lines
were added to the Transit Authority fleet and
still have no posted schedules (i.e. Q25, Q24 and
Q65). This is a necessity for our seniors who are
not technology savvy and cannot use the MTA
Bus Time App.
22/24 NYCTA Expand subway
service frequency or hours of operations
We urge that the City explores the possibility of increasing service capacity along the F subway line. The trains are often at capacity when they reach the 169th Street station. The commuters at the subsequent subway stops are unable to board the train.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 8
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
The quality of parks and park facilities is one of the most important issues facing our district. Community District 8 is fortunate to be home to many parks and numerous playgrounds. This is in addition to over 50 greenstreets. All of these park facilities require regular maintenance. There is always a need for new irrigation systems, updated playground equipment and safety resurfacing on a rolling basis. Our major parks: Captain Tilly Park, Cunningham Park, Flushing Meadow Corona Park are used by thousands of our residents and those of neighboring districts. Our parks host major events such as Philharmonic Orchestra concert attended by thousands of people coming from far and wide. For many, our parks and playgrounds are the destination for families with children who have staycations. Some of our smaller parks/playgrounds such as Hoover/Manton Playground, Utopia Playground, Vleigh Playground, Briarwood Playground and Albert Mauro Playground are in need of upgraded play equipment and/or safety resurfacing. We must keep our parks well maintained and safe havens for all our residents. To this end, funding for parks and park facilities is a must.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The most attractive characteristic of Community Board 8 is its suburban nature. Our residents value the many parks and playgrounds that we have within our borders. All of them are heavily used and as such they must be maintained. The Community Board would like to see the reinstatement of playground associates to provide programs for children in the parks. In addition, the Brinkerhoff Cemetery has been designated a historic landmark and is under the jurisdiction of the Department of Parks and Recreation. This site needs maintenance to restore the damage done by years of neglect. While this is not the most important issue for Parks and Recreation, the maintenance of our existing street trees (i.e. pruning, dead tree and stump removal) is also a very important need in CD8. We have mature trees in all our neighborhoods (i.e. Briarwood, Fresh Meadows, Holliswood and Jamaica Estates that require routine maintenance. During extended periods of very hot weather, our greenstreets and street trees need to be irrigated to remain green. Water trucks are needed for that purpose.
Needs for Cultural Services
No comments
Needs for Library Services
All Community Board 8 branch libraries meet the current spatial requirements as published by the Queens Public Library. The Briarwood Branch Library must to be able to meet the needs of its residents. The Pomonok Branch Library is in dire need of a new sign. All the libraries could benefit from additional computers, books and bandwidth. ESL program for all the libraries due to the increase in our immigrant population. This would assist in their desire and ability to speak and write English.
Needs for Community Boards
We are requesting that the Office of Management and Budget maintain the current Community Board funding to facilitate merit raises, keeping our technology current and maintaining staffing levels. Having trained and experienced staff is necessary for the smooth operation of our Community Boards. In the past, the Community Boards have seen their budgets decreased. When budgets fluctuate and the staff believes that they do not have job security, they look for other opportunities. Once new staff is hired, this means that many staff hours are now devoted to training. These hours could be better spent by working to address the community's concerns.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/35
QL
Create a new, or
Create an annex for the Queens Public Library at
renovate or upgrade
Queens Hospital Center - 82-68 164th Street,
an existing public
Jamaica NY 11432
library
8/35
DPR
Provide new type
State of Good Repair Program - This program
and/or specific type
will help renovate park sites with persistent
of program
paved surfaces, sidewalks, lawns and other
horticultural amenities.
9/35
DPR
Reconstruct or
Add a new aerator system at Captain Tilly Park
165th Street
upgrade a park or
for the goose pond. [Part of last year's tracking
Highland
playground
code 408202009C]
Avenue
Chapin
Parkway
10/35
DPR
Reconstruct or
Rehabilitate Flushing Meadow Corona Park and
upgrade a park or
rebuild bridge over Flushing Creek at the south
amenity (i.e.
end of Willow Lake.
playground, outdoor
athletic field)
15/35
BPL
Provide more or
Funds are needed for computers and smart
187-05 Union
better equipment to
boards for the conference rooms of the Queens
Turnpike.
a library
Public Library at Hillcrest. [Part of last year's
tracking code 408202018C]
17/35
DPR
Reconstruct or
Convert Hoover Playground's concrete athletic
upgrade a building
field near 83rd Avenue to a baseball field.
in a park
21/35
DPR
Provide a new or
Build an environmental center in Flushing
expanded park or
Meadow Corona Park. This center is needed to
amenity (i.e.
provide a variety of programs for the
playground, outdoor
community.
athletic field)
27/35
DPR
Reconstruct or
Redesign, address drainage and electrical issues
upgrade a park or
at Briarwood Playground (JHS 217). Eliminate
amenity (i.e.
one basketball court and create a tennis court.
playground, outdoor
athletic field)
28/35
QL
Create a new, or
Provide funds for the Hillcrest Library 's interior
187-05 Union
renovate or upgrade
and exterior renovations. Partly funded by
Turnpike
an existing public
Councilman Rory Lancman more funds are
library
needed.
29/35
DPR
Reconstruct or
Renovate Vleigh Playground. The asphalt needs
upgrade a park or
to be replaced. Additional lighting is needed.
amenity (i.e.
This park has not been upgraded for many
playground, outdoor
years.
athletic field)
30/35
DPR
New equipment for
Six-yard packer truck needed for Parks in District
maintenance
8.
(Capital)
31/35
DPR
Other park facilities
Funds needed for the acquisition of the Klein
and access requests
Farm for use as an agricultural and/or
horticultural center.
CS
QL
Provide more or
Funds are needed for computers and smart
better equipment to
boards for the conference rooms. Pomonok
a library
Branch - 158-21 Jewel Avenue [State Senator
Toby Stavisky will fund this technology
upgrade].
CS
DPR
Reconstruct or
Resurface Hoover/Manton Playground's
upgrade a park or
basketball courts.
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Replace play equipment at Freedom Square
upgrade a park or
Playground including swings. Equipment is old
amenity (i.e.
and needs to be replaced.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Renovate the Hoover/Manton Playground. The
upgrade a building
project should include renovation of the
in a park
playground and handball courts.
CS
DPR
Reconstruct or
Additional seating in the Utopia Playground for
upgrade a park or
Children, parents and spectators, especially
amenity (i.e.
inthe basketball court area.
playground, outdoor
athletic field)
CS
QL
Create a new, or
The Briarwood Library needs to be expanded
renovate or upgrade
and renovated to meet with the increase in
an existing public
demand.
library
CS
QL
Create a new, or
We continue to support funding for the
renovate or upgrade
rehabilitation of the Hollis Branch Library. Funds
an existing public
are also needed for upgrading equipment,
library
increasing bandwidth to accommodate
additional computers and for additional books.
CS
DPR
Reconstruct or
Renovate Albert Mauro Playground (Park Drive
upgrade a park or
East) Playgrounds need rehabilitation, as it has
amenity (i.e.
not been done in many years. New play
playground, outdoor
equipment and new surfaces are needed.
athletic field)
CS
DPR
Reconstruct or
Renovate comfort station at Captain Tilly.
upgrade a building
in a park
CS
DPR
Reconstruct or
Rehabilitate Cunningham Park's Redwood
upgrade a park or
Playground and 210th Street Playground.
amenity (i.e.
Create a third basketball court on 193rd Street
playground, outdoor
at Cunningham Park
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/24
DPR
Other park
Fund /purchase of potable water trucks to
maintenance and
water Million Trees NYC newly planted trees and
safety requests
Green Street gardens planted throughout CD8.
Fund a Green Streets beautification program for
(69th Avenue, 67th Avenue and 64th Avenue)
center island malls in Fresh Meadows. In
addition. The Department must consult on
annual basis with the community about their
plans.
6/24
DPR
Forestry services,
Assign additional personnel to Parks and
including street tree
Forestry for street tree maintenance. Much
maintenance
funding has gone to planting new trees. With
new trees the need for maintenance increases.
It takes too long to have tree stumps removed.
They pose a trip hazard to residents and liability
for the City.
9/24
DPR
Other park
Horticultural Maintenance Program - Funding
maintenance and
for this program will provide staffing to
safety requests
maintain park landscapes, gardens, lawns and
other horticultural amenities.
10/24
DPR
Other park programming requests
Increase funding for DPR's enforcement personnel. Community Board 8 has many parks, playgrounds and sitting areas. Maintaining the safety of these areas of refuge for our residents is paramount. Personnel is needed to enforce infractions in the parks (i.e. dog walkers in restricted areas, smokers, etc...)
11/24
DPR
Other park programming requests
Funding and maintenance of Brinkerhoff Memorial Cemetery. DCAS and DPR are in the process of acquiring this site for preservation through ULURP Application: C180241 PCQ.
69-65 182nd
Street
20/24
DPR
Other park maintenance and safety requests
Provide an irrigation source for landscaped areas in Freedom Park.
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority Agency Request Explanation Location
image
19/35 Other Other capital budget
request
DPR - Provide mobile/temporary bathrooms near ball fields in southern section of Flushing Meadows Corona Park. Needed for the youth and adults who use the Park, especially during large events. (408202024C)
Other Expense Requests
Priority
Agency
Request
Explanation
Location
8/24
Other
Other expense budget request
DOT - Increase yearly asphalt allocation of highway resurfacing for Community District 8. (408202009E)
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/35
DOT
Reconstruct streets
Reconstruction/trench restoration is needed to
address street depression and sinkholes. 75th
Avenue (186th St. to 188th St.) Avon Road
(Chevy Chase St. to 188th St.) 181st Street (67th
Ave. & 69th Ave.)
2/35
DOT
Repair or construct
Installation of new sidewalk and curbs: A) 170th
new curbs or
Street (Goethals Ave and Union Turnpike) B)
pedestrian ramps
171st Street (65th Avenue and 67th Avenue) C)
Utopia Parkway (73rd Avenue to Horace
Harding Expressway including center medians
D) East side of 185th Street (64th Avenue to
67th Avenue)
3/35
DOT
Repair or construct
Install and/or repair bus pads. CB8 requested
new curbs or
replacement of the cracked and broken bus
pedestrian ramps
pads since 2005. A) 188th Street & Union
Turnpike B) 188th Street from Union Turnpike to
73rd Avenue C) Hillside Avenue (westbound
lane) from Francis Lewis Boulevard to 205th
Street. Hillside Avenue is the route for about 10
bus lines. The lack of bus pads makes it
necessary for numerous requests for repairs of
hummocks each year. Hillside Avenue was
resurfaced a few years ago. Install bus pads to
prevent the newly resurfaced street from
deteriorating.
4/35
DHS
Other request for
Air conditioning is needed for the Briarwood
80-20 134th
services for the
Family Shelter. This can be achieved by
Street
homeless
upgrading the electrical system to facilitate
window units. Cooling rooms are not sufficient.
The residents should be afforded the same
treatment as the staff who work in temperature
controlled rooms.
5/35
FDNY
Other FDNY facilities
Provide the funds to complete all work orders
and equipment
from the fire houses within Community District
requests (Capital)
8 and add cameras. Install security
cameras/system at every fire house in
Community District 8 to prevent vandalism and
theft. Engine 298 - Ladder 127 - 153-11 Hillside
Avenue Engine 299 - Ladder 152 - 61-20 Utopia
Parkway Engine 315 - Ladder 125 - 159-06
Union Turnpike. It has come to our attention
that our fire houses have been vandalized and
electronics were stolen.
6/35
QL
Create a new, or
Create an annex for the Queens Public Library at
renovate or upgrade
Queens Hospital Center - 82-68 164th Street,
an existing public
Jamaica NY 11432
library
7/35
HHC
Renovate or
Funds needed for fit-out/interior construction of
82-68 164th
upgrade an existing
the 8,000 sq. ft. of community space within the
Street
health care facility
T-Building at the Queens Hospital Center. Dunn
Development is renovating the T-Building and
has agreed to set aside this space for a
community center that will provide services for
all ages. This building will also comprise 206
housing units including: regular rental units,
special needs units, middle income units and
low income units.
8/35
DPR
Provide new type
State of Good Repair Program - This program
and/or specific type
will help renovate park sites with persistent
of program
paved surfaces, sidewalks, lawns and other
horticultural amenities.
9/35
DPR
Reconstruct or
Add a new aerator system at Captain Tilly Park
165th Street
upgrade a park or
for the goose pond. [Part of last year's tracking
Highland
playground
code 408202009C]
Avenue
Chapin
Parkway
10/35
DPR
Reconstruct or
Rehabilitate Flushing Meadow Corona Park and
upgrade a park or
rebuild bridge over Flushing Creek at the south
amenity (i.e.
end of Willow Lake.
playground, outdoor
athletic field)
11/35
SCA
Provide a new or
Upgrade the sound system for the auditorium of
expand an existing
P.S. 26. Upgrade the electrical wiring for P.S.26Q
elementary school
for the installation of air conditioning in the
auditorium, gymnasium and cafeteria. The
school is used in the summer to house the P.S.
224 students who are developmentally disabled.
They require temperature controlled
environments as per the mandate for ADA
compliance.
12/35
DOT
Reconstruct streets
Goethals Ave is partially built. As one travels
Goethals Hall
eastbound along Goethals Avenue, the road
168 Street
narrows. It was not not built to its fully mapped
170 Street
width and a portion of the street has vegetation
instead of asphalt.
13/35
NYPD
Provide surveillance
Argus cameras are needed to assist in solving
cameras
crime.
14/35
SCA
Provide technology
Upgrade electrical wiring to 220 to support
upgrade
electrical needs of smart boards and air
conditioners for P.S. 173.
15/35
BPL
Provide more or
Funds are needed for computers and smart
187-05 Union
better equipment to
boards for the conference rooms of the Queens
Turnpike.
a library
Public Library at Hillcrest. [Part of last year's
tracking code 408202018C]
16/35
DOT
Repair or construct
Repair and/or create new concrete medians on
Utopia
new medians or bus
Utopia Parkway. The medians are broken and
Parkway 69th
pads
many are at the same level as the roadway.
Avenue
Horace
Harding
Expressway
17/35
DPR
Reconstruct or
Convert Hoover Playground's concrete athletic
upgrade a building
field near 83rd Avenue to a baseball field.
in a park
18/35
DOT
Roadway
Replace and/or repair the cobblestones that
Clover Hill
maintenance (i.e.
make up the street at Clover Hill Place. The road
Place Clover
pothole repair,
is very steep. The cobblestones are needed to
Hill Road
resurfacing, trench
provide traction for DSNY vehicles to remove
Dead End
restoration, etc.)
snow in the winter. The road is very steep and
this is needed to ensure that residents and
emergency vehicles can reach the top of the hill
if necessary.
19/35
Other
Other capital budget request
DPR - Provide mobile/temporary bathrooms near ball fields in southern section of Flushing Meadows Corona Park. Needed for the youth and adults who use the Park, especially during
large events. (408202024C)
20/35
DOT
Repair or construct
New sidewalk is needed on north side of
Goethals
new curbs or
Goethals Avenue from 168th Street to 170th
Avenue 168th
pedestrian ramps
Street. Area abuts NYC property. Sidewalk is
Street 170th
needed for pedestrian safety.
Street
21/35
DPR
Provide a new or
Build an environmental center in Flushing
expanded park or
Meadow Corona Park. This center is needed to
amenity (i.e.
provide a variety of programs for the
playground, outdoor
community.
athletic field)
22/35
SCA
Renovate or
Convert former teacher's cafeteria into a
upgrade a middle or
classroom.
intermediate school
23/35
SCA
Renovate or
Replace tables in cafeteria; replace auditorium
upgrade an
seats; install auditorium wall padding and
elementary school
renovate outdoor wooded area.
24/35
SCA
Renovate or
Upgrade electrical system, upgrade library and
upgrade an
science lab at P.S. 173Q - The Fresh Meadow
elementary school
School.
25/35
DSNY
Provide new or
Purchase additional garbage trucks to ensure
increase number of
enough capacity for organics recycling.
sanitation trucks
and other
equipment
26/35
SCA
Renovate or
Upgrade school technology to use parent
upgrade a middle or
coordinator's office as a web-based resource at
intermediate school
P.S. 178Q.
27/35
DPR
Reconstruct or
Redesign, address drainage and electrical issues
upgrade a park or
at Briarwood Playground (JHS 217). Eliminate
amenity (i.e.
one basketball court and create a tennis court.
playground, outdoor
athletic field)
28/35
QL
Create a new, or
Provide funds for the Hillcrest Library 's interior
187-05 Union
renovate or upgrade
and exterior renovations. Partly funded by
Turnpike
an existing public
Councilman Rory Lancman more funds are
library
needed.
29/35
DPR
Reconstruct or
Renovate Vleigh Playground. The asphalt needs
upgrade a park or
to be replaced. Additional lighting is needed.
amenity (i.e.
This park has not been upgraded for many
playground, outdoor
years.
athletic field)
30/35
DPR
New equipment for
Six-yard packer truck needed for Parks in District
maintenance
8.
(Capital)
31/35
DPR
Other park facilities
Funds needed for the acquisition of the Klein
and access requests
Farm for use as an agricultural and/or
horticultural center.
32/35
FDNY
Provide new
Vehicle is designed with lifts and special
emergency vehicles,
wheelchairs to be used for individuals over 500
such as fire trucks or
lbs.
ambulances
33/35
FDNY
Provide new
This is vehicle is used for disasters and treat
emergency vehicles,
individuals in one place.
such as fire trucks or
ambulances
34/35
FDNY
Other FDNY facilities
A rapid response vehicle (Sierra Pick-up Truck) is
and equipment
needed to respond ahead with a liaison. This is
requests (Capital)
used for coordination purposes..
35/35
FDNY
Other FDNY facilities
A mobile command vehicle is needed for the
and equipment
Borough of Queens.
requests (Capital)
CS
DOT
Reconstruct streets
Reconstruction/trench restoration is needed to
186th Street
address street depression and sinkholes on
73 Avenue 75
186th Street [Part of last year's Tracking Code
Avenue
408202001C. Request has already been funded
and requires continued support].
CS
QL
Provide more or
Funds are needed for computers and smart
better equipment to
boards for the conference rooms. Pomonok
a library
Branch - 158-21 Jewel Avenue [State Senator
Toby Stavisky will fund this technology
upgrade].
CS
DPR
Reconstruct or
Resurface Hoover/Manton Playground's
upgrade a park or
basketball courts.
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Replace play equipment at Freedom Square
upgrade a park or
Playground including swings. Equipment is old
amenity (i.e.
and needs to be replaced.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Renovate the Hoover/Manton Playground. The
upgrade a building
project should include renovation of the
in a park
playground and handball courts.
CS
DPR
Reconstruct or
Additional seating in the Utopia Playground for
upgrade a park or
Children, parents and spectators, especially
amenity (i.e.
inthe basketball court area.
playground, outdoor
athletic field)
CS
QL
Create a new, or
The Briarwood Library needs to be expanded
renovate or upgrade
and renovated to meet with the increase in
an existing public
demand.
library
CS
QL
Create a new, or
We continue to support funding for the
renovate or upgrade
rehabilitation of the Hollis Branch Library. Funds
an existing public
are also needed for upgrading equipment,
library
increasing bandwidth to accommodate
additional computers and for additional books.
CS
DPR
Reconstruct or
Renovate Albert Mauro Playground (Park Drive
upgrade a park or
East) Playgrounds need rehabilitation, as it has
amenity (i.e.
not been done in many years. New play
playground, outdoor
equipment and new surfaces are needed.
athletic field)
CS
DPR
Reconstruct or
Renovate comfort station at Captain Tilly.
upgrade a building
in a park
CS
DPR
Reconstruct or
Rehabilitate Cunningham Park's Redwood
upgrade a park or
Playground and 210th Street Playground.
amenity (i.e.
Create a third basketball court on 193rd Street
playground, outdoor
at Cunningham Park
athletic field)
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/24
NYPD
Other NYPD
Traffic Safety programs for afterschool program
158-40 76th
programs requests
participants.
Road
2/24
DEP
Clean catch basins
Increase personnel for the maintenance of catch
basins, sewers and water mains in CD8.
3/24
DPR
Other park
Fund /purchase of potable water trucks to
maintenance and
water Million Trees NYC newly planted trees and
safety requests
Green Street gardens planted throughout CD8.
Fund a Green Streets beautification program for
(69th Avenue, 67th Avenue and 64th Avenue)
center island malls in Fresh Meadows. In
addition. The Department must consult on
annual basis with the community about their
plans.
4/24
DOB
Assign additional
Hire a dedicated inspector for Queens
120-55
building inspectors
Community Boards' half day inspections. The
Queens
(including
number of requests sent to the Queens Borough
Boulevard,
expanding training
Office is much greater than any other office in
Queens, New
programs)
the five boroughs. The Queens' Office had a
York, NY
part-time inspector that used to accompany the
District Managers on site visits on a monthly
basis. Unfortunately, this person went on sick
leave and was never replaced. We are
requesting that a new full-time inspector be
hired as a replacement. (408202008E)
5/24
DYCD
Provide, expand, or
Increase funding for summer youth employment
enhance the
programs. Every year the percentage of funds
Summer Youth
allocated to meet the needs for the program
Employment
has been diminished. The number of youth (in
Program
the age group of 14 to 24 years old) that qualify
for summer youth employment has increased.
The yearly funding to meet that need has fallen
short.
6/24
DPR
Forestry services,
Assign additional personnel to Parks and
including street tree
Forestry for street tree maintenance. Much
maintenance
funding has gone to planting new trees. With
new trees the need for maintenance increases.
It takes too long to have tree stumps removed.
They pose a trip hazard to residents and liability
for the City.
7/24
DSNY
Provide more
Dedicated basket trucks are needed to empty
frequent litter
street bins more frequently. This would improve
basket collection
the cleanliness of our streets. Hillside Avenue
(Francis Lewis Boulevard to Queens Boulevard)
Queens Boulevard (Hillside Avenue to Main
Street) and Main Street. Routine center mall
cleaning is also needed throughout the seasons.
Additional funds should be allocated to ensure
that all commercial areas receive the same
frequency of service.
8/24
Other
Other expense
DOT - Increase yearly asphalt allocation of
budget request
highway resurfacing for Community District 8.
(408202009E)
9/24
DPR
Other park
Horticultural Maintenance Program - Funding
maintenance and
for this program will provide staffing to
safety requests
maintain park landscapes, gardens, lawns and
other horticultural amenities.
10/24
DPR
Other park
Increase funding for DPR's enforcement
programming
personnel. Community Board 8 has many parks,
requests
playgrounds and sitting areas. Maintaining the
safety of these areas of refuge for our residents
is paramount. Personnel is needed to enforce
infractions in the parks (i.e. dog walkers in
restricted areas, smokers, etc...)
11/24
DPR
Other park
Funding and maintenance of Brinkerhoff
69-65 182nd
programming
Memorial Cemetery. DCAS and DPR are in the
Street
requests
process of acquiring this site for preservation
through ULURP Application: C180241 PCQ.
12/24
SBS
Support
Hillside Avenue could use a facelift to make it
Hillside
development of
more appealing for people that patron the
Avenue 179th
local Storefront /
diverse businesses. Improving cleanliness,
Street
Facade
maintenance of the storefronts and
Queens
Improvement
beautification through streetscape.
Boulevard
Program
13/24
DFTA
Enhance NORC
Provide funding to create NORCs in Community
programs and
Board 8.
health services
14/24
DYCD
Provide, expand, or
Increase funding for Beacon Programs and any
enhance
other after school programs in CD8. Funds need
Cornerstone and
to increase to meet the growing need in the
Beacon programs
community.
(all ages, including
young adults)
15/24
DFTA
Increase
We have a multi-ethnic population. In recent
transportation
years, we have seen an increase in people who
services capacity
identify as Asian. As such, the services provided
for seniors need to meet that change. When
services are not readily available for one ethnic
group, transportation to neighboring centers
that do is desirable. While the population is not
necessarily homebound but the frail senior
population does have issues with using mass
transit. For those that are homebound, they
need to interact with people from the outside
world. This could possibly mean using
technology to help them stay connected. They
can participate in senior activities remotely (i.e.
through Skype).
16/24
DSNY
Other enforcement
Increase personnel for Sanitation Police to
requests
increase sanitation inspection in all categories
and throughout the district.
17/24
DFTA
Other senior center
Enhance funding for senior services. Funds are
program requests
needed to meet the demands for services.
(408202018E)
18/24
FDNY
Expand funding for
Increase funding for CPR Training Program and
fire prevention and
for the Fire & Life Safety Education Outreach
life safety initiatives
19/24
DOT
Other expense
Increase arterial highway forces for cleaning
traffic
areas adjacent to highways and assign
improvements
additional personnel for maintenance.
requests
Community District 8 is boarded by several
arterial highways (LIE, GCP, Van Wyck and
Clearview Expressway). These areas are often
full of litter. They are only cleaned by DOT every
three or four weeks. Cleaning is needed at least
on a weekly basis.
20/24
DPR
Other park
Provide an irrigation source for landscaped
maintenance and
areas in Freedom Park.
safety requests
21/24
NYCTA
Expand bus service
Our community needs additional buses to
frequency or hours
service the growing population (i.e. Q76, Q30,
of operation
Q20, Q88 - Express/Limited). The residents of
Kew Gardens Hills would welcome the return of
the Q74 to Vleigh Place. The private bus lines
were added to the Transit Authority fleet and
still have no posted schedules (i.e. Q25, Q24 and
Q65). This is a necessity for our seniors who are
not technology savvy and cannot use the MTA
Bus Time App.
22/24 NYCTA Expand subway
service frequency or hours of operations
We urge that the City explores the possibility of increasing service capacity along the F subway line. The trains are often at capacity when they reach the 169th Street station. The commuters at the subsequent subway stops are unable to board the train.
image
23/24 DOE Other educational
programs requests
Upgrade musical instruments at P.S. 178 to expand the music program and include a band ($10,000 needed).
image
24/24 DOHMH Provide more
tuberculosis information and services
Community Board 8 supports tuberculosis vans for new immigrants and funds for sexual health. We understand that these funds may have been reduced by the Federal Government and we want to curtail the spread of these diseases through prevention and education.
image

