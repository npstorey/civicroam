- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 5 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1SFju4bVEo-HjKEgVDJAk4_NK3hBVrgpD/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1SFju4bVEo-HjKEgVDJAk4_NK3hBVrgpD/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
5
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 5
image
Address: 2155 University Avenue, Gould Hall 200 Phone: (718) 364-2030
Email: bx05@cb.nyc.gov
Website: www.nyc.gov/bronxcb5
Chair: Dr. Bola Omotosho District Manager: Ken Brown
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Bronx Community District 5, known as the West Tremont area, is located in the mid-West Bronx with a total land area of 1.4 square miles. It is bounded by the Harlem River to the West, in the Cross Bronx Expressway on the South, Webster Avenue on the East, and the northern boundary extends from Hall of Fame Terrace at Bronx Community College to Dr. Martin Luther King, Jr. Blvd. and 183rd Street, East to Jerome Avenue and North to Fordham Road. The major streets running East to West are Fordham Road, Burnside and Tremont Avenues. The major streets running North and South are Jerome Avenue, Grand Concourse, Bainbridge, and 3rd Avenue. The Grand Concourse is a major North/South corridor. Our district overlaps with City Council districts 14, 15, and 16. Bronx Community District 5 is comprised of the following four neighborhoods: South Fordham, University Heights, Morris Heights, and Mount Hope. The overall population count in this district was 131,879 in 2012, the last year the data was made available, and its population density (1,000 persons per square mile) was 87.4. There was a 2.8 percent increase in the population from the year 2010. The racial diversity of our residents is rich and the majority of the population is Hispanic and Black/African American. According to the 2010-2012 American Community Survey (ACS) estimates, 68.6 percent of the population in this district is of Hispanic origin; 33.7 percent of the residents are Black/African American; 1.1 percent of the residents are Asian or Pacific Islander; 12.9 percent of the residents are White; 0.8 percent of the residents are American Indian or Alaska Native. The ACS estimated that of the Hispanic/ Latino group, 6.4 percent of the residents are Mexican; 18.3 percent of the residents are Puerto Rican; 0.5 percent of the residents are Cuban; 43.5 percent of the residents identify themselves as part of another Hispanic or Latino group. There are also a significant proportion of residents that is foreign born. The population of foreign-born residents increased from 34.8 percent in 2000 to 43.4 percent in 2012. The ACS 2008-2012 data breaks down the region of birth of the foreign born population in our district: 12 percent of the foreign born population is African of which 11 percent is West African; 85 percent of the foreign born population is Latin American; 2 percent of the population is Asian; 1 percent of the population is European. The growth of our foreign born population and the large population of Hispanic or Latino residents has potentially impacted the primary languages represented in our district. Of the residents living in our district for five years and more, 70.2 percent speak a language other than English and Spanish speakers make up 62.3 percent of this group. In addition to race, the age groups contribute to the diversity of the residents living in this area. The population of residents in the 65 and older age group increased from 5 percent in 2000 to 8.2 percent in 2012. The households with children under 18 years old decreased from
55.4 percent to 43.9 percent from 2000 to 2012. Although there is a range in the socioeconomic makeup of the residents in the district, the percent of households living near the poverty line and who are considered to be low- income is high. The proportion of residents with a household income below $20,000 increased from about 35 percent to about 46 percent from 2000 to 2012. The poverty rate also increased from 40.6 percent to 42.3 percent from 2000 to 2012. It was ranked as one of the community districts with the highest number of households with the total income below the poverty level. For the year 2012, the median household income was $21,959 which is significantly less when compared to the Bronx overall ($33,006) and New York City ($51,750). It was ranked as one of the community districts with the lowest median household income levels. The percent unemployed is about 20.9 percent. The proportion of residents who used supplemental security income was 18.3 percent. The proportion of residents who needed cash public assistance income was 12.3 percent. The proportion of residents requiring food stamps/SNAP benefits was significant at 50.6 percent. Morris Heights is the lowest density area in District 5. Morris Heights is along the western ridge of the district, covering the area from Jerome Avenue valley to the Harlem River Valley. Here, the zoning ranges from R5 (typically 2 and 3-family row houses and small apartment buildings). In addition to the low density development, several high-rise developments including Sedgwick Houses, a NYC Housing Authority Development complex and several large private apartment towers along the Undercliff and Sedgwick Avenues, as well as River Park Towers along the Harlem River. University Heights is part of the same rock ridge that characterizes most of Morris Heights, and is similar, architecturally. One of the key landmarks in this area is the beautiful Bronx Community College Campus, which gives the neighborhood its name. This public facility is the highest geographic point in New York City. University Heights is the least dense area of the district and benefits
from a large proportion of 1-4 family housing stock. The area East of Jerome Avenue and Fordham Road encompasses two neighborhoods: South Fordham, North of Burnside to Fordham Road, and Mount Hope, South of Burnside Avenue to the Cross Bronx Expressway. Both extend east to Webster Avenue. The Mount Hope/South Fordham neighborhoods are densely populated mostly with five and six-story housing. At the eastern edge of these neighborhoods is a large residential development known as Twin Parks West, consisting of four residential towers. At the northern portion of this area is the Fordham Road Shopping District, the third largest generator retail sales in the City of New York. Fordham Road has approximately 1-million square feet of retail space.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 5
image
The three most pressing issues facing this Community Board are:
Affordable housing
Community Board 5 has an old housing stock with over half our housing built before 1930, and it is defined as a primarily a multi-dwelling bedroom community. The home ownership rate in our district is categorized as having the lowest rates in the New York City community districts. It has a homeownership rate of 2.8 percent. Also, our district is ranked as having the highest number of renter households whose gross rent was more than 50 percent of their pre-tax income. Other issues affecting housing quality are increasing utility costs for landlords and homeowners; the percentage of housing with five or more maintenance deficiencies has increased over 35 percent; a lack of code enforcement (this district ranks in the top 20 in serious housing code violations throughout the City); an increase in building debts due to over-financing. Approximately 44.4 percent of the rental housing units considered overcrowded (our district ranks 6th overall in the City).
Schools
There is a dearth of available school seats in our district, especially in elementary school seats. Community Board 5 encompasses School Districts 9 and 10. In CSD 9 the elementary school utilization rate is 118.23% In CSD 10 the rate is 122.06% (Jerome Avenue Rezoning EIS; p. 4-13).
Unemployment
Community Board 5 has an old housing stock with over half our housing built before 1930, and it is defined as a primarily a multi-dwelling bedroom community. The home ownership rate in our district is categorized as having the lowest rates in the New York City community districts. It has a homeownership rate of 2.8 percent. Also, our district is ranked as having the highest number of renter households whose gross rent was more than 50 percent of their pre-tax income. Other issues affecting housing quality are increasing utility costs for landlords and homeowners; the percentage of housing with five or more maintenance deficiencies has increased over 35 percent; a lack of code enforcement (this district ranks in the top 20 in serious housing code violations throughout the City); an increase in building debts due to over-financing. Approximately 44.4 percent of the rental housing units considered overcrowded (our district ranks 6th overall in the City). Community Board 5 currently has an unemployment of 18% compared to the Bronx overall unemployment rate of 8%. We have more than 10,000 households on cash assistance and 34, 000 cases for the SNAP. Which has impacted our median income of $24, 000 which ranks us as one of the five lowest within in the city according to the NYU Furman Center report.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 5
image
M ost Important Issue Related to Health Care and Human Services
Chronic diseases (diabetes, heart disease, etc.)
Our community has a high incidence for asthma and diabetes. Among adults the rate of hospitalizations for asthma are 571 per 100,000 adults. For the Bronx this rate is 508 and the average city-wide is 249. For children the rate for hospitalization is 55 in our community per 10,000 children between the ages of 5-14 years old. The rate for such children throughout the Bronx is 72 and for New York City the rate is 36. In regards to diabetes hospitalizations for adults, our community ranks as the sixth highest in the city. Per 10,000 adults we have a hospitalization rate of 616. For the Bronx the corresponding rate is 503. The rate of hospitalizations for New York City is 312. Among the leading causes of death in Community Board 5 diabetes related causes ranks 5th (26.7 per 100,000 adults). The rate of infant mortality and premature death (before the age of 65) is higher than city-wide. The infant mortality rate in Community Board 5 is 5.4 per 1,000 live births. For the Bronx his rate is 5.7. The New York City this rate is 4.7. By comparison the rate of infant mortality in the Upper East Side is 1.0. In our community the rate of premature death is 266.2 per 100,000 adults. The rate for the Bronx is 238.9 and the City is 198.4.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Within the Bronx, the infant mortality rate (IMR) remains extremely high for black women (including African American, African immigrants, and non-Hispanic Afro-Caribbean women) compared to the average IMR in the borough at the community level. This statistic is relevant for Community Board 5, since 33.7 percent of our residents are Black/African American. From 2007 to 2009, the IMR surpassed 10 deaths per 1,000 live births for black women under the age of 20 in the University/Morris Heights neighborhood. We urge the Department of Health Services to increase funding to address this health issue in our district. Also, Bronx Community Board 5 has the 4th highest number of asthma hospitalization in the City. Our district requests the DHS to increase funding for asthma treatment. Our other requests are an increase of funding for the expansion of the Pest Control Unit to add additional personnel and field inspectors/Exterminators, and to improve the teen pregnancy obesity programs in our district.
Needs for Older NYs
The elderly population in our district continues to increase. The proportion of the population group of 65 and older has increased from 5 percent to 8.2 percent from 2000 to 2012. We are requesting that the city provides for the special needs of our seniors especially for the recent seniors which require services that will keep them active.
Community Board 5 is requesting that long range planning include housing, health and mental health care, home care and senior centers. With this approach, Community Board 5 feels we can improve their quality of life and prevent the isolation which many of our elderly are at risk for. Our priorities include: · Increase funding for the improvement of senior citizens’ facilities in Community Board 5. · Increase funding for senior housing · Increase funding for innovative senior programs in Community Board District 5, such as a Naturally Occurring Retirement Community.
Needs for Homeless
bh
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
2/29
DOHMH
Other animal and
Expand Pest & Animal Control Units to also
pest control
include Animal Inspectors; additional Personnel
requests
Needed. CD5 is experiencing a major rat
infestation. With major redevelopment, new
construction and a growing population, rats are
multiplying and moving into buildings/homes.
Rats pose a health and safety danger with
diseases they carry, especially to children.
5/29
HRA
Other request for
Requesting Funding for Special Needs Services
services for
for Immigrants. For example, citizenship
vulnerable New
applications, residency, employment
Yorkers
applications, spousal waivers, accessing
resources and other legal documents. The
foreign born are more than one-third of the
population in Community Board 5. By
addressing these immigrant specific concerns
will ultimately enable the foreign born to
contribute even more to the economic vitality of
the community.
6/29
HRA
Provide, expand, or
Provide Independent Living Skills Programs for
enhance
Single Mothers. Community Board 5 is in dire
educational
need of funding for he Independent Skills
programs for adults
Services program in our district. This program
will provide a solid support system to singe
mothers who are working to make he transition
from public dependency to self sufficiency.
16/29
DFTA
Enhance
Community Board 5 is Requesting funding for
educational and
Stay Well exercising programs for seniors who
recreational
are fit and for those with disabilities. Seniors are
programs
in dire need of Aerobic exercise as well as
routines designed to enhance balance, build
muscle strength and aid in the performance o
task associated with daily living.
17/29 DFTA Other senior center
program requests
Requesting funding for computer labs and training. This will assist seniors to navigate computer and complex systems. The elderly have been an integral part of this community for generations. Seniors today live longer and despite some disabilities generally live better overall than their counterparts of previous generations. Many older adults are isolated, frail, homebound, vulnerable to fraud and intimidation.
image
18/29 DFTA Increase transportation services capacity
There is a dearth of access to the number 4 elevated train in our district. Through the length of Jerome Avenue in our district there is no access to the train for those with mobility impairments. We seek additional funding so that providers of services for the elderly can expand transportation services.
image
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 5
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
A large proportion of our residents fall under the youth category. The 2010 U.S. Census showed that about 42 percent of our population is under the age of 18. Also, Community Board 5 is ranked as the district with the 4th highest number of households with children under 18 years old. Students are performing at the lower levels of the city wide average scores in reading and math subjects; only 14.4 percent of the students were performing at grade level in math and only 12.3 percent of the students were performing at grade level in reading. Thus, it is very important for the Department of Education to assist our district to provide adequate services intended for this age group. We are requesting that as housing developments occur in our district, there are sufficient funds available for the needs of the youth.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
There is a dearth of programming for youth of all ages. We need further resoourcesd for anti-gang/violence programms, especailly trying to combat youth against the elderly crime prevention.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
33/41
SCA
Renovate exterior
Community Board 5 requests that the
120 East
building component
schoolyard of MS 459X be renovated for use by
184th Street
the school community, as well as programs
sponsored by Good Shepherd Services and
B.R.A.G. The schoolyard includes basketball
courts, handball courts and a play area and is
need of rehabilitation and new fixtures and play
equipment.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
1/29
DYCD
Provide, expand, or
Provide additional funds for CD 5 area youth
enhance
programs: Fair Share Delinquency prevention,
Cornerstone and
specialized programs and a Beacon School.
Beacon programs
Youth programs remain at funding levels of ten
(all ages, including
years ago. Youngsters make up approximately
young adults)
40% of population. Needs far outweigh ability
to provide services/programs.
21/29
DYCD
Provide, expand, or
The mission of the Featherbed Lane
enhance
Improvement Assoc. two-fold: 1) to reduce the
Cornerstone and
risk of alcohol, tobacco and other drug use /
Beacon programs
abuse, and 2) to assist socially and economically
(all ages, including
disadvantaged youth and young adults in
young adults)
attaining the skills, knowledge and motivation
to become responsible self-sufficient citizens.
The end result is stronger families and a better
community. FLIA also utilizes evidence based
program curriculums designed to help students
develop self-control, communication skills, and
acquire resources to help them resist drug use,
improve decision making strategies, and
develop the motivation not use drugs. The
philosophy is to help children and families grow
physically, healthy, emotionally strong, socially
involved, educationally prepared, and more
culturally aware.
22/29 DYCD Provide, expand, or
enhance adolescent literacy programs and services
Community Board 5 requests that DYCD establish a Computer Coding Program in the district for residents, (Youth and Young Adults and senior citizens) to learn computer coding. This is a very important skill which leads to quality job opportunities and assists in their educational development.
image
28/29 DYCD Provide, expand, or
enhance after school programs for all grade levels
There is a dearth of programming for youth of all ages. We need further resources for anti- gang/violence programs, especially trying to combat youth against the elderly crime prevention.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 5
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
Community residents feel that the 46th police pct physical appearance and chaotic parking, sanitation, are contributing to the quality life of local residents, like the broken window theory.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Safety in our community is a major concern, and we believe more investment and efforts should be dedicated to strengthening the capacity of the police force in our district since District 5 still has some of the highest crime rates in the City. Also another primary objective is to expedite the process of acquiring and constructing a new 46th Precinct with parking facilities. This will definitely improve police department services and consequently improve the quality of life of our residents. In addition, we request that the local police precinct increase funding for the Operation Clean Hallways program. It should work with the City’s Housing Preservation and Development (HPD) agency to stop indoor drug dealing and loitering. This has been a quality of life and public safety issue for our community. In order to maintain security and enhance livability in our community, we require that there be more attention focused on the indoor drug dealing issue in our district. Our priorities for the NYC Police Department in our district include: · Allocate funding to build a new front entrance ramp to make the existing 46th Police Precinct ADA accessible · Increase funding for 911 emergency dispatchers to improve response time · Increase funding to purchase noise meter devices and fire hydrant wrenches · Increase funding for Narcotics’ Enforcement · Increase funding for School Crossing Guards to assist students to navigate the wide street crossing corridors such as the Grand Concourse, University Avenue, and W. Tremont Avenue. · Conduct a pilot initiative on Community Policing to enhance safety in our neighborhoods . Install security cameras along selected streets.
Needs for Emergency Services
Our priority for the NYC Fire Department is to increase funding for 911 dispatchers Emergency Response Time for Ambulance Services. The average response time from the 2013 Mayor’s Management Report for the city was 4:06 for structural fires, and the response time in the Bronx was 4:12. We believe it is necessary to improve the capacity of our Fire Department to maintain the safety of our residents. We also request additional funding for carbon monoxide detectors, and medical kits for: each of our Engine Company and Juvenile fire setters program.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/41
NYPD
Provide a new NYPD
Construct New 46th Precinct Facility. The 46th
facility, such as a
Precinct is in need of a new facility. The current
new precinct house
facility is old, dilapidated, archaic and most of
or sub-precinct
the furniture is old & broken. There is no space
for parking, causing the streets to be congested
with very little space for pedestrians. This
situation must be improved not only for the
working police officers, but also for the
surrounding community.
5/41
NYPD
Renovate or
Handicap Accessibility in Front of the 46th
upgrade existing
Precinct. Seniors and physically challenged
precinct houses
residents are requesting a ramp and hadrails to
the entrance of he 46th Precinct to make it ADA
accessible.
17/41
FDNY
Rehabilitate or
Fund Firehouse Renovations/Upgrades. Funding
renovate existing
is needed for firehouse renovations and
fire houses or EMS
upgrades in CD5 such as new roof
stations
(waterproofing), apparatus floor replacements,
emergency generators, window replacements,
pointing, electrical as well as kitchen and
bathroom. Engine Company 42, Engine
Company 43 and Engine Company 48
22/41
NYPD
Provide surveillance
New York Police Department Surveillance
Burnside
cameras
Cameras along Burnside Avenue Shopping
Avenue
District from Grand Concourse to Harrison
Grand
Avenue. Burnside Avenue Shopping district is
Concourse
Vibrant. Merchants and shoppers have concerns
Harrison
about public safety. Surveillance cameras would
Avenue
enhance public safety and would serve as
deterrent.
27/41
NYPD
Provide surveillance
Aqueduct Homeowners Request Surveillance
West 181st
cameras
Camera's for Grand Avenue, Davidson Avenue
Street Grand
and West 181st Street. Homeowners have public
Avenue
safety concerns. Surveillance camera's would
Davidson
enhance public safety and quality life. Cameras
Avenue
will serve as a deterrent.
35/41
NYPD
Provide surveillance
Security cameras are needed along Burnside
Burside
cameras
Avenue between University Avenue and
Avenue
Sedgewick Avenue. This extension of security
University
cameras would effectively extend our request
Avenue
for cameras along Burnside Avenue to our
Sedgewick
eastern most shopping hub.
Avenue
40/41 NYPD Add NYPD parking
facilities
Parking near the 46th precinct is very constrained. Officers, precinct vehicles, residents and commercial vehicles all compete for constrained space. A means to alleviate this is to build parking decks on the lots operated and owned by NYPD at 2069 and 2119 Valentine Avenue.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
9/29
NYPD
Other NYPD
Feasibility Study for the Expansion of the
facilities and
Existing 46th Precinct. Increase in personnel has
equipment requests
made it extremely crowded in this old
(Expense)
dilapidated and archaic building. This situation
must be improved not only for the working
police officers, but also for the surrounding
community.
12/29
NYPD
Other NYPD staff
Hire Additional Clerical Workers for the 46th
resources requests
Precinct. The addition of 100 new officers to the
46th Precinct over the next 24 months will
require additional support staff to process paper
work and service community
requests/complaints.
15/29
FDNY
Expand funding for
Funding fire safety education outreach. The fire
fire prevention and
department needs to purchase smoke detectors
life safety initiatives
and carbon monoxide detectors for distributing
to the public.
24/29
NYPD
Other NYPD
Community Board 5 requests that the city
programs requests
establish a Victim Support Services Program in
the district which would deal with the victims of
crimes or the families of victims of crime. The
program would assist these victims and their
family's with funeral arrangements, counseling,
financial support and other needs of these
residents.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 5
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
Community Board 5 has been a lock down community board with custodial hydrant locks since the early nineties. For the past ten years we have been top three in complaints. In the past four years we have been chosen for the HEAP Initiative. Community Board 5 welcomes this initiative but with changes for example: 1. the initiative is not operational until July, we would like to see it implemented earlier either late April or early May. 2. DEP should incorporate a speakers bureau to consist of DEP, FDNY, NYPD personnel and Community Boards in order to speak on the impact full running hydrants have on public safety property damage and the exorbitant cost of the city. 3. CB 5 recommends DEP change its policy on what agency is issued hydrant wrenches e.g. DSNY hydrants can be shut during am hours.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
Although sanitation has improved in the district, it still has the lowest sanitation score card rating in the borough related to sidewalk and street cleanliness. Sanitation has continued to be an important priority for Community Board 5 to improve the quality of life and economic stability and growth within our district. Therefore, we are requesting an increase of funding for cleaning personnel for our six commercial districts on Fordham Road, South Grand Concourse (Fordham Road), Burnside Avenue, West 183rd Street, West Tremont Avenue and University Avenue, and Featherbed Lane. Also, we request funding for our Canine Unit, additional personnel for the 13 Step Streets, cleaning personnel for Grand Concourse and University Malls, sanitation equipment (for cleaning the Grand Concourse and the University Malls, tree pruning, and weed whackers), and for personnel to service garbage baskets in our district (especially in commercial areas).
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
8/29 DSNY Other cleaning
requests
Create a Step Street Task Force to Clean the City's 128 Step Streets. Until the recent use of Work Experience Program (WEP) workers for cleaning step streets, DOS had abandoned its responsibility for these public streets. CD5 has 12 step streets which are mad unsightly and dangerous by litter.
image
13/29 DSNY Increase
enforcement of illegal dumping laws
Increase Illegal Dumping Task Force from Current Low Level. Sanitation police personnel cannot serve the ire need of our district. Must improve ability of Department to conduct surveillance and apprehend illegal dumpers. his is a major quality of life concern in CD5.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 5
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing preservation
Community Board 5 has an old housing stock with over half our housing built before 1930, and it is defined as a primarily a multi-dwelling bedroom community. The home ownership rate in our district is categorized as having the lowest rates in the New York City community districts. It has a homeownership rate of 2.8 percent. Also, our district is ranked as having the highest number of renter households whose gross rent was more than 50 percent of their pre-tax income. Other issues affecting housing quality are increasing utility costs for landlords and homeowners; the percentage of housing with five or more maintenance deficiencies has increased over 35 percent; a lack of code enforcement (this district ranks in the top 20 in serious housing code violations throughout the City); an increase in building debts due to over-financing. Approximately 44.4 percent of the rental housing units considered overcrowded (our district ranks 6th overall in the City).
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Jerome Avenue Neighborhood Study: Jerome Avenue is a major street in our district running North and South, and the section we wish to focus on is an auto-body corridor from the Burnside Avenue to the Cross Bronx Expressway. The physical appearance of this corridor has a negative impact on the residents’ quality of life. Even though this corridor provides some employment opportunities (but not necessarily to residents in our community), we believe that the businesses should be relocated to another location. The objective is to change the existing C8 zoning along Jerome Avenue with the support of stakeholders and community members. We believe this is an opportunity area for mixed-use development, and request for a zoning change to residential with a commercial overlay. This is also an opportunity for affordable housing on Jerome Avenue, and the establishment of an Inclusionary Housing Program can be a tool to incentivize this type of housing development along the corridor. Many community stakeholders have suggested that Jerome Avenue be revitalized to meet existing area needs and plan for the future. Through the planning process, City Planning and sister agencies will seek to address the needs of local residents, businesses, and institutions. The study and resulting community plan will evaluate and identify opportunities to promote a range of elements to support community vitality: affordable housing, job growth and training, economic development, cultural activities, pedestrian safety, parks, schools and daycare, retail and services. The study and plan will promote coordinated investments in infrastructure and services to shape a resilient, sustainable community. The study and plan will include land use and zoning changes and the application of a mandatory Inclusionary Housing program within the area to promote affordable housing. Bronx Community Board 5 is waiting for the Department of City Planning zoning and planning framework for Jerome Avenue Neighborhood Study.
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
15/41 HPD Expand loan programs to rehabilitate multiple dwelling buildings
Increase Funds to 8A Loan Program for Upgrading and Ongoing Maintenance Needs in Rehabilitated Buildings. New focus is to preserve existing housing of what has been rehabilitated. HPD indicates the fund is drying up.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
23/29
EDC
Expand programs to
Community Board 5 requests that a business
support local
incubator be established in the district to assist
businesses and
local business and Entrepreneurs to grow the
entrepreneurs
businesses or establish new business ventures in
technology, health care and retail areas, etc..
Possibly using Bronx Community College as a
location for such an incubator.
TRANSPORTATION
Bronx Community Board 5
image
M ost Important Issue Related to Transportation and Mobility
Bus crowding and quality issues
A large proportion of our residents, about 68.2 percent, use public transportation to commute to work. Other popular modes of commuting to work include driving to work alone (11.5 percent) or carpooling (5.8 percent), or walking (9.6 percent). The objective of Bronx Community Board 5 is to improve the existing transportation infrastructure. The resurfacing of our most important street, the Grand Concourse from 175th to Fordham Road, is an important priority for our district. The objective is to initiate a greening project which would be vital for enhancing the beautification and improving economic development in the area. Also, due to the heavily utilized major thoroughfares in our district (including Grand Concourse, Fordham Road, University Avenue, and Tremont Avenue), traffic mitigation efforts are of paramount importance. Sep street maintenance is important as the district's 13 step streets are a feature of significant aesthetic and pedestrian circulation value.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
2/41
NYCTA
Improve
Install an Elevator/Escalator at the IRT 4
accessibility of
Burnside Avenue Station. The IRT 4 Burnside
transit
Avenue Station is heavily used in Bronx
infrastructure, by
Community Board 5. It is highly elevated facility
providing elevators,
having three sets of stairs before a passenger
escalators, etc.
arrives at the mezzanine level. Disabled
individuals, people with carriages/strollers and
seniors have a difficult time getting to the
platform of this station serves as a main
gateway to Bronx Community College, Roberto
Clemente State Park and other institutions in
our district. The community has signed a
petition with over 1000 signatures for an
elevator/escalator at this station.
4/41
DOT
Repair or build new
Reconstruct Step Streets from Palisades Place to
Palisades
step streets
Sedgwick Avenue. Step Streets are important
Place
access points. These are in extremely dangerous
Sedgwick
condition which must be addressed promptly.
Avenue
13/41
DOT
Repair or provide
Install Higher Intensity Lighting along Jerome
Jerome
new street lights
Avenue, form the Cross Bronx Expressway to
Avenue Cross
Fordham Road. Special lighting is needed for
Bronx
streets with elevated rail lines. Presently,
Expressway
Jerome Avenue is dark and unsafe because of
Fordham
improper lighting. This is a public safety
Road
measure.
14/41
DOT
Rehabilitate bridges
Reconstruct Grand Concourse Bridge over 175th
Street-Walls over 175th Street/ Part of Subway
System. Walls on east and west side of Grand
Concourse over 175th Street have been
damaged by years of leaking water. he
community youth mural project is on hold as a
result.
21/41
DOT
Install streetscape
The Placement One-for-One of regular COBRA-
University
improvements
Head Street lights with "M" Pole-Type
Avenue East
Distinctive Lamp Posts is an appropriate design
Burnside
that would be most compatible with the Vision
Avenue
for Residential, Burnside Avenue Shopping
Valentine
District from East Burnside Avenue & Valentine
Avenue
Avenue to University Avenue & Burnside
Avenue. The "M" Pole-type of street lights is the
preferred street amenities and streetscape
enhancements in our neighborhood.
23/41
DOT
Repair or build new
Rehabilitate Step Street at Davidson Avenue
Davidson
step streets
between Featherbed Lane and Davidson Avenue
Avenue
Proper is seriously deteriorated. Many steps are
Featherbed
loose and pose a danger to pedestrian access to
Lane
the subway station. Heavy pedestrian traffic,
vandalism and weather have caused severe
deterioration of the step street. Include hand
railings and better lighting.
28/41
DOT
Repair or build new
Reconstruct Step Street from Sedgwick Avenue
Sedgwick
step streets
to Cedar avenue. Step Streets are important
Avenue Cedar
access points. This particular step street
Avenue
provides access form Sedgwick Avenue to Cedar
Avenue which is the gateway to Roberto
Clemente State Park. This location is in
extremely poor condition and must be
addressed promptly.
30/41
DOT
Repair or build new
Reconstruct Step Street from Marion Avenue to
Marion
step streets
187th Street. The Step Street has been seriously
Avenue 187th
deteriorated. There is heavy pedestrian traffic
Street
e.g. students, patrons and residents. Request
additional lighting.
31/41
DOT
Repair or build new
Create Step Street at Kingsland Place (between
Kingsland
step streets
West Tremont Avenue and Harrison Avenue)
Place West
This location is in poor condition. DOT has paved
Tremont
and resurfaced this location in the prior fiscal
Avenue
year, however it remains unsafe and is heavily
Harrison
usedby pedestrians and children. Creating a
Avenue
step street would improve pedestrian mobility.
Access now is dangerous for those that are
mobility impaired. Repaving/reconstruction
should make the step street ADA-compliant.
36/41
DOT
Repair or provide
Community Board members voiced concern
Webster
new street lights
about the lack of adequate lighting along
Avenue
Webster Avenue. A PAL is located at this corner
182nd Street
so improved lighting would add to the security
183rd Street
of youth and enhance the attraction of this
youth recreation facility.
39/41
DOT
Repair or provide
The replacement of lighting from conventional
Sedgewick
new street lights
lighting to LED will enhance the illumination of
Avenue Cedar
the street and increase the durability and
Avenue
service-life of such lights. An improvement in
UNdercliff
illumination will enhance this area as a
Avenue
commercial node.
41/41 DOT Repair or provide
new street lights
Burnside Avenue is a primary commercial and pedestrian corridor for our community.
Adequate street lighting is vital for both safety and business concerns.
Burnside Avenue Walton Avenue University Avenue
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
10/29
NYCTA
Other transit service
Create a NYC Transit Authority Clean Team. A
requests
special team is needed to clean and paint
elevated subway line stations, fight graffiti and
work with communities on anti-litter/ant-graffiti
activities.
14/29
DOT
Other expense
Increase Staff in Bureau of Highways
traffic
Maintenance Division: Additional Staff Persons
improvements
Needed. With an increase in the need to repair
requests
streets as well as sidewalks and radways, there
is a serious need for additional manpower in the
Bronx Highways Maintenance Division. One
gang is not sufficient to address the street
repair needs in the borough.
20/29
DOT
Conduct traffic or
On Street Parking Study for Community Board 5
parking studies
Area. On Street Parking is a priority Quality of
Life issue for district 5. CB 5 is highly dense
bedroom community. In addition, we have 7
Commercial Shopping Districts (Fordham Road,
Webster Avenue, South Grand Concourse,
Burnside Avenue, West 183rd Street, University
Avenue/West Tremont Avenue and Featherbed
Lane) and street parking is vital for our
Community Board area.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 5
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Library facilities and access
The two libraries that serve our community, Francis Martin and Sedgwick Branch libraries are vital components of the cultural and educational resources in our community. The ongoing physical, programming and aesthetic accessibility of these branches are of vital concern. These libraries are hubs for community activity. They have also developed innovative programming through the 'Summer Reading in the park' program. Sunday/expanded hours would be of great benefit.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
Immigration: The foreign born comprises more than one-third of the population within Community Board 5. In order to serve our immigrant residents a increase in funding is needed to enable our immigrant population to integrate into the social and economic fabric of Community Board 5.
Needs for Library Services
Community Board 5 (Bronx) has two branches of the New York Public Library (NYPL) system: Francis Martin and Sedgwick. These are vital resources for our community. • Based on a 2015 report from the Center for an Urban Future, libraries in the Bronx saw the biggest increase in program attendance and circulation out of the five boroughs. The Bronx has seen a 225 percent increase in program attendance and a 35 percent increase in circulation. Data shows that these statistics will continue to increase throughout the New York public Library system.
The libraries are especially important to low and moderate income residents who depend on the libraries for access to books, internet access, job search and film and as the only quiet place to read or do homework or other work. • Residents who have laptop computers but cannot afford internet fees use the library for internet access. • The arts and cultural programming along with English for Speakers of Other Languages and Out-of School Time programs in the neighborhood are extremely important to many residents, particularly families with children and seniors, who cannot otherwise afford access to commercial alternatives. An initiative that is being explored is to bring the library to local parks during the summer school break. We are exploring how the library at Francis Martin (to begin with) may bring materials and dedicate staff to a ‘reading in the park’ initiative. • The NYPL libraries within CB 5 (Bronx) are used extensively. The community relies on them to provide essential library services, as well as educational programs and community space. Many of the library locations are in need of critical upgrades, including mechanical systems, bathrooms, roofs, facades and ADA upgrades. While other locations are in need of a complete renovation • The NYPL will continue to work with the Mayor, Speaker, City Council and local elected officials to increase capital funding.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/41
DPR
Reconstruct or
Request Funding for Lighting Via Flood lights
upgrade a park or
from the Light Post for the Steps of the park.
amenity (i.e.
Also funding Stage/Presentation/Community
playground, outdoor
area at the top of the park. Restoration of walls,
athletic field)
railings and update the fencing. To shift the
current physical conditions and negative
community perceptions of University Woods
and help other communities use their parks to
improve the conditions of the surrounding
neighborhoods.
7/41
NYPL
Create a new, or
The Library is seeking much-needed capital
2150
renovate or upgrade
funding to ensure that our branches can
University
an existing public
continue to meeting the growing needs of our
Ave
library
communities. Anticipated projects range from
major renovations to targeted upgrades,
including: -Heating and cooling system updates
New roof, windows and doors -Fire alarm,
security and technology upgrades -ADA
compliance -Elevator replacement -ADA
Bathroom renovations
8/41
DPR
Reconstruct or
Improve & Develop the Environment Walk at
upgrade a building
Aqueduct Land from Morton Place to Burnside
in a park
Avenue. Build a Pedestrian Bridge, ADA
Compliance Step Street or Ramp. Aqueduct
Walk is adjacent to the newly constructed
Morton Playground & Morton Place
Homeowners Association. Walkway is in dire
need of improvement.
9/41
NYPL
Create a new, or
Partial Renovation of Francis Martin Library
2150
renovate or upgrade
Branch. Francis Martin Library Branch needs the
University
an existing public
front faade rehabilitated, HVAC replaced
Ave
library
additional units), electrical system upgraded, PC
Refresh and VoIP Technology, 1st floor and
lower level, (including ADA compliance),
including elevator and bathrooms upgraded.
10/41
Other
Other capital budget
EDC - Requesting Phase II of Mount Hope
request
Housing Inc. Project to Construct Indoor
Gymnasium, Parking Facility as Well as a
Useable Pavilion Roof top on City Owned Land.
The Mount Hope Housing project has just
completed phase I a state of the art Community
Center. In order to make this facility viable it
needs parking facilities to accommodate
conference hall and gymnasium participants.
11/41
DPR
Reconstruct or
Increase Funds to Parks Department for
upgrade a building
Miscellaneous Park Repairs. (P-245) Contract is
in a park
Needed for Replacing Play Equipment-$150k Per
Borough. This funding is used for a variety of
basic renovation efforts such as paving, fencing
and benches. This line is primarily used to stress
rehabilitation, rather than new construction.
12/41
DPR
Reconstruct or
Replace Lighting in Aqueduct Park from Morton
upgrade a building
Place to Burnside Avenue. During the
in a park
rehabilitation of this park the lighting was not
replaced and subsequent vandalism has
incapacitated all of the lights. It is necessary to
replace all of the park lights in Aqueduct Park
form Morton Place to Burnside Avenue.
13/41
DOT
Repair or provide
Install Higher Intensity Lighting along Jerome
Jerome
new street lights
Avenue, form the Cross Bronx Expressway to
Avenue Cross
Fordham Road. Special lighting is needed for
Bronx
streets with elevated rail lines. Presently,
Expressway
Jerome Avenue is dark and unsafe because of
Fordham
improper lighting. This is a public safety
Road
measure.
14/41
DOT
Rehabilitate bridges
Reconstruct Grand Concourse Bridge over 175th
Street-Walls over 175th Street/ Part of Subway
System. Walls on east and west side of Grand
Concourse over 175th Street have been
damaged by years of leaking water. he
community youth mural project is on hold as a
result.
15/41
HPD
Expand loan
Increase Funds to 8A Loan Program for
programs to
Upgrading and Ongoing Maintenance Needs in
rehabilitate multiple
Rehabilitated Buildings. New focus is to preserve
dwelling buildings
existing housing of what has been rehabilitated.
HPD indicates the fund is drying up.
16/41
DPR
Reconstruct or
Acquire Block 3194, Lot 27 to Extend Existing
upgrade a park or
Parks Managed Property/ West 181st Street &
amenity (i.e.
Grand Avenue. Additional Funding to repair
playground, outdoor
retaining wall. The retaining wall is crumbling
athletic field)
and created dangerous conditions in the
playground.
17/41
FDNY
Rehabilitate or
Fund Firehouse Renovations/Upgrades. Funding
renovate existing
is needed for firehouse renovations and
fire houses or EMS
upgrades in CD5 such as new roof
stations
(waterproofing), apparatus floor replacements,
emergency generators, window replacements,
pointing, electrical as well as kitchen and
bathroom. Engine Company 42, Engine
Company 43 and Engine Company 48
18/41
DPR
Improve access to a
Acquire & Develop Empty Lot Block 2877, Lot
park or amenity (i.e.
531 on Montgomery Avenue corner of Popham
playground, outdoor
Avenue. This lot has been neglected for many
athletic field)
years. The development of a tot lot at this
location will enhance the quality of life for the
children of our community.
19/41
DPR
Reconstruct or
Community Board 5 is Requesting the Redesign
University
upgrade a park or
of the University Avenue Park Malls. University
Avenue West
amenity (i.e.
Avenue from West Tremont Avenue to 175th
Tremont
playground, outdoor
Street. Community Board 5 is requesting that
Avenue 175th
athletic field)
these malls be redesigned to accommodate
Street
some benches as well as some additional spaces
for tree pits.
20/41
DPR
Enhance park safety
The Redesign and Expansion of existing Green
University
through design
Street Median on University Avenue, 174th
Avenue 174th
interventions, e.g.
Street and Cross Bronx Expressway. Community
Street Cross
better lighting
Board 5 feels that the existing median is to
Bronx
(Capital)
narrow, the location would be enhanced if
Expressway
medians were redesigned and expanded as a
traffic calming device as well as provide a
beautiful Green Street which will enhance the
South West gateway presences of Community
Board 5.
21/41
DOT
Install streetscape
The Placement One-for-One of regular COBRA-
University
improvements
Head Street lights with "M" Pole-Type
Avenue East
Distinctive Lamp Posts is an appropriate design
Burnside
that would be most compatible with the Vision
Avenue
for Residential, Burnside Avenue Shopping
Valentine
District from East Burnside Avenue & Valentine
Avenue
Avenue to University Avenue & Burnside
Avenue. The "M" Pole-type of street lights is the
preferred street amenities and streetscape
enhancements in our neighborhood.
22/41
NYPD
Provide surveillance
New York Police Department Surveillance
Burnside
cameras
Cameras along Burnside Avenue Shopping
Avenue
District from Grand Concourse to Harrison
Grand
Avenue. Burnside Avenue Shopping district is
Concourse
Vibrant. Merchants and shoppers have concerns
Harrison
about public safety. Surveillance cameras would
Avenue
enhance public safety and would serve as
deterrent.
23/41
DOT
Repair or build new
Rehabilitate Step Street at Davidson Avenue
Davidson
step streets
between Featherbed Lane and Davidson Avenue
Avenue
Proper is seriously deteriorated. Many steps are
Featherbed
loose and pose a danger to pedestrian access to
Lane
the subway station. Heavy pedestrian traffic,
vandalism and weather have caused severe
deterioration of the step street. Include hand
railings and better lighting.
24/41
DPR
Reconstruct or
Phase II Construction for University Woods Park
upgrade a park or
to Develop the Plaza/Stage area of the park.
amenity (i.e.
University Woods Park construction
playground, outdoor
improvements will enhance public safety
athletic field)
perception and will increase environmental and
recreational programming activities within the
park.
25/41
DPR
Reconstruct or
Renovation of Galileo Playground. Galileo
upgrade a park or
Playground is an outdoor science playground
amenity (i.e.
classroom with play equipment that stimulates
playground, outdoor
children's imagination. It focuses on the Solar
athletic field)
System and the individual planets. This
playground is in disrepair and in need of capital
improvement.
26/41
DPR
Reconstruct or
Funding for Capital Reconstruction of Echo Park.
upgrade a park or
Echo Park is in poor physical condition. We are
amenity (i.e.
requesting the following enhancements
playground, outdoor
basketball courts, playground area, park house
athletic field)
and construct an amphitheater. In addition
improve parks natural landscaping, plant new
shrubs and trees.
27/41
NYPD
Provide surveillance
Aqueduct Homeowners Request Surveillance
West 181st
cameras
Camera's for Grand Avenue, Davidson Avenue
Street Grand
and West 181st Street. Homeowners have public
Avenue
safety concerns. Surveillance camera's would
Davidson
enhance public safety and quality life. Cameras
Avenue
will serve as a deterrent.
28/41
DOT
Repair or build new
Reconstruct Step Street from Sedgwick Avenue
Sedgwick
step streets
to Cedar avenue. Step Streets are important
Avenue Cedar
access points. This particular step street
Avenue
provides access form Sedgwick Avenue to Cedar
Avenue which is the gateway to Roberto
Clemente State Park. This location is in
extremely poor condition and must be
addressed promptly.
29/41
DCLA
Other cultural
Site Acquisition of 1800-1808 Grand Concourse.
1800-1808
facilities and
1800-1808 Grand Concourse is an art-deco
Grand
resources requests
property known as the United Pilgrim Church.
Concourse
(Capital)
This building has numerous outstanding
violations. The Community Board has identified
this site for the Mount Hope Center for the Arts.
Currently, not one cultural arts center exists
within the community board five area.
30/41
DOT
Repair or build new
Reconstruct Step Street from Marion Avenue to
Marion
step streets
187th Street. The Step Street has been seriously
Avenue 187th
deteriorated. There is heavy pedestrian traffic
Street
e.g. students, patrons and residents. Request
additional lighting.
31/41
DOT
Repair or build new
Create Step Street at Kingsland Place (between
Kingsland
step streets
West Tremont Avenue and Harrison Avenue)
Place West
This location is in poor condition. DOT has paved
Tremont
and resurfaced this location in the prior fiscal
Avenue
year, however it remains unsafe and is heavily
Harrison
usedby pedestrians and children. Creating a
Avenue
step street would improve pedestrian mobility.
Access now is dangerous for those that are
mobility impaired. Repaving/reconstruction
should make the step street ADA-compliant.
32/41
DPR
Provide a new or
Transfer & Develop the Greenthumb Property at
Townsend
expanded park or
Townsend Avenue & East 175th Street to the
Avenue East
amenity (i.e.
Department of Parks & Recreation. This
175th Street
playground, outdoor
Greenthumb, maintained by the Mount Hope
athletic field)
Housing Company, is a beautiful resource with
the potential of becoming a playground for
neighborhood children.
33/41
SCA
Renovate exterior
Community Board 5 requests that the
120 East
building component
schoolyard of MS 459X be renovated for use by
184th Street
the school community, as well as programs
sponsored by Good Shepherd Services and
B.R.A.G. The schoolyard includes basketball
courts, handball courts and a play area and is
need of rehabilitation and new fixtures and play
equipment.
34/41
Other
Other capital budget
Request for 1801-1805 Davidson Avenue
1801-1805
request
Property transferred from ACS to DCAS then be
Davidson
transferred to NYC Department of Parks and
Avenue
Recreation. 1801-1805 Davidson Avenue is
extremely deteriorated, dangerous and eyesore
in he community. Community Board 5 is in
desperate need of open space
35/41
NYPD
Provide surveillance
Security cameras are needed along Burnside
Burside
cameras
Avenue between University Avenue and
Avenue
Sedgewick Avenue. This extension of security
University
cameras would effectively extend our request
Avenue
for cameras along Burnside Avenue to our
Sedgewick
eastern most shopping hub.
Avenue
36/41
DOT
Repair or provide
Community Board members voiced concern
Webster
new street lights
about the lack of adequate lighting along
Avenue
Webster Avenue. A PAL is located at this corner
182nd Street
so improved lighting would add to the security
183rd Street
of youth and enhance the attraction of this
youth recreation facility.
37/41
DPR
Reconstruct or
Morris Community Garden is dilapidated and
2116 Morris
upgrade a park or
needs to be overhauled and maintained.
Avenue
amenity (i.e.
playground, outdoor
athletic field)
38/41
DPR
Reconstruct or
The gardens at Twin Park Southwest is
2000
upgrade a park or
dilapidated and needs renovation.
Valentine
amenity (i.e.
Avenue
playground, outdoor
athletic field)
39/41
DOT
Repair or provide
The replacement of lighting from conventional
Sedgewick
new street lights
lighting to LED will enhance the illumination of
Avenue Cedar
the street and increase the durability and
Avenue
service-life of such lights. An improvement in
UNdercliff
illumination will enhance this area as a
Avenue
commercial node.
40/41
NYPD
Add NYPD parking
Parking near the 46th precinct is very
facilities
constrained. Officers, precinct vehicles, residents
and commercial vehicles all compete for
constrained space. A means to alleviate this is
to build parking decks on the lots operated and
owned by NYPD at 2069 and 2119 Valentine
Avenue.
41/41 DOT Repair or provide
new street lights
Burnside Avenue is a primary commercial and pedestrian corridor for our community.
Adequate street lighting is vital for both safety and business concerns.
Burnside Avenue Walton Avenue University Avenue
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/29
DYCD
Provide, expand, or
Provide additional funds for CD 5 area youth
enhance
programs: Fair Share Delinquency prevention,
Cornerstone and
specialized programs and a Beacon School.
Beacon programs
Youth programs remain at funding levels of ten
(all ages, including
years ago. Youngsters make up approximately
young adults)
40% of population. Needs far outweigh ability
to provide services/programs.
2/29
DOHMH
Other animal and
Expand Pest & Animal Control Units to also
pest control
include Animal Inspectors; additional Personnel
requests
Needed. CD5 is experiencing a major rat
infestation. With major redevelopment, new
construction and a growing population, rats are
multiplying and moving into buildings/homes.
Rats pose a health and safety danger with
diseases they carry, especially to children.
3/29
NYPL
Extend library hours
New York Public Library Request the City Restore
or expand and
Funding. The New York Public Library requests
enhance library
that the City restore funding to provide robust
programs
six day service including increased hours,
diverse programming, strong collections and
sufficient staff to support these functions. in
these challenging economic times, the services
provided through the Library are needed by
New Yorkers more than ever.
4/29
DPR
Enhance park safety
Hire Parks Enforcement Police Officers for Bronx
through more
Parks. Our parks are becoming increasingly
security staff (police
dangerous and are often unattended/un-
or parks
patrolled by NYPD. Many parks are becoming
enforcement)
havens for drug dealers.
5/29
HRA
Other request for
Requesting Funding for Special Needs Services
services for
for Immigrants. For example, citizenship
vulnerable New
applications, residency, employment
Yorkers
applications, spousal waivers, accessing
resources and other legal documents. The
foreign born are more than one-third of the
population in Community Board 5. By
addressing these immigrant specific concerns
will ultimately enable the foreign born to
contribute even more to the economic vitality of
the community.
6/29
HRA
Provide, expand, or
Provide Independent Living Skills Programs for
enhance
Single Mothers. Community Board 5 is in dire
educational
need of funding for he Independent Skills
programs for adults
Services program in our district. This program
will provide a solid support system to singe
mothers who are working to make he transition
from public dependency to self sufficiency.
7/29
DPR
Improve the
Hire Parks Recreation Specialist-Consider
quality/staffing of
Seasonal Hires for Cost Containment. Our parks
existing programs
and playgrounds are in dire need of adequate
offered in parks or
staff with which to provide recreational
recreational centers
activities for the tens of thousands of young
people using our parks. We presently have only
one recreation staff person for all our parks and
playgrounds.
8/29
DSNY
Other cleaning
Create a Step Street Task Force to Clean the
requests
City's 128 Step Streets. Until the recent use of
Work Experience Program (WEP) workers for
cleaning step streets, DOS had abandoned its
responsibility for these public streets. CD5 has
12 step streets which are mad unsightly and
dangerous by litter.
9/29
NYPD
Other NYPD
Feasibility Study for the Expansion of the
facilities and
Existing 46th Precinct. Increase in personnel has
equipment requests
made it extremely crowded in this old
(Expense)
dilapidated and archaic building. This situation
must be improved not only for the working
police officers, but also for the surrounding
community.
10/29
NYCTA
Other transit service
Create a NYC Transit Authority Clean Team. A
requests
special team is needed to clean and paint
elevated subway line stations, fight graffiti and
work with communities on anti-litter/ant-graffiti
activities.
11/29
Other
Other expense
DEP - Hire additional Inspectors for the
budget request
Department of Environmental Protection.
Personnel Inspectors to Monitor Fire Hydrants
(Opening and Closing). Community District 5, for
the last three years, has experienced the highest
rate of hydrant openings in the borough of the
Bronx. Ranking in the top three citywide.
12/29
NYPD
Other NYPD staff
Hire Additional Clerical Workers for the 46th
resources requests
Precinct. The addition of 100 new officers to the
46th Precinct over the next 24 months will
require additional support staff to process paper
work and service community
requests/complaints.
13/29
DSNY
Increase
Increase Illegal Dumping Task Force from
enforcement of
Current Low Level. Sanitation police personnel
illegal dumping laws
cannot serve the ire need of our district. Must
improve ability of Department to conduct
surveillance and apprehend illegal dumpers. his
is a major quality of life concern in CD5.
14/29
DOT
Other expense
Increase Staff in Bureau of Highways
traffic
Maintenance Division: Additional Staff Persons
improvements
Needed. With an increase in the need to repair
requests
streets as well as sidewalks and radways, there
is a serious need for additional manpower in the
Bronx Highways Maintenance Division. One
gang is not sufficient to address the street
repair needs in the borough.
15/29
FDNY
Expand funding for
Funding fire safety education outreach. The fire
fire prevention and
department needs to purchase smoke detectors
life safety initiatives
and carbon monoxide detectors for distributing
to the public.
16/29
DFTA
Enhance
Community Board 5 is Requesting funding for
educational and
Stay Well exercising programs for seniors who
recreational
are fit and for those with disabilities. Seniors are
programs
in dire need of Aerobic exercise as well as
routines designed to enhance balance, build
muscle strength and aid in the performance o
task associated with daily living.
17/29
DFTA
Other senior center
Requesting funding for computer labs and
program requests
training. This will assist seniors to navigate
computer and complex systems. The elderly
have been an integral part of this community
for generations. Seniors today live longer and
despite some disabilities generally live better
overall than their counterparts of previous
generations. Many older adults are isolated,
frail, homebound, vulnerable to fraud and
intimidation.
18/29
DFTA
Increase
There is a dearth of access to the number 4
transportation
elevated train in our district. Through the length
services capacity
of Jerome Avenue in our district there is no
access to the train for those with mobility
impairments. We seek additional funding so
that providers of services for the elderly can
expand transportation services.
19/29
DPR
Other park
Restore Parks Maintenance Employees (to
maintenance and
include the Division of Forestry and a
safety requests
Greenthumb Crew). Bronx Community District
5 has several playgrounds and parks which
need to be properly maintained. Essential
increases in maintenance staff are needed.
20/29
DOT
Conduct traffic or
On Street Parking Study for Community Board 5
parking studies
Area. On Street Parking is a priority Quality of
Life issue for district 5. CB 5 is highly dense
bedroom community. In addition, we have 7
Commercial Shopping Districts (Fordham Road,
Webster Avenue, South Grand Concourse,
Burnside Avenue, West 183rd Street, University
Avenue/West Tremont Avenue and Featherbed
Lane) and street parking is vital for our
Community Board area.
21/29
DYCD
Provide, expand, or
The mission of the Featherbed Lane
enhance
Improvement Assoc. two-fold: 1) to reduce the
Cornerstone and
risk of alcohol, tobacco and other drug use /
Beacon programs
abuse, and 2) to assist socially and economically
(all ages, including
disadvantaged youth and young adults in
young adults)
attaining the skills, knowledge and motivation
to become responsible self-sufficient citizens.
The end result is stronger families and a better
community. FLIA also utilizes evidence based
program curriculums designed to help students
develop self-control, communication skills, and
acquire resources to help them resist drug use,
improve decision making strategies, and
develop the motivation not use drugs. The
philosophy is to help children and families grow
physically, healthy, emotionally strong, socially
involved, educationally prepared, and more
culturally aware.
22/29
DYCD
Provide, expand, or
Community Board 5 requests that DYCD
enhance adolescent
establish a Computer Coding Program in the
literacy programs
district for residents, (Youth and Young Adults
and services
and senior citizens) to learn computer coding.
This is a very important skill which leads to
quality job opportunities and assists in their
educational development.
23/29
EDC
Expand programs to
Community Board 5 requests that a business
support local
incubator be established in the district to assist
businesses and
local business and Entrepreneurs to grow the
entrepreneurs
businesses or establish new business ventures in
technology, health care and retail areas, etc..
Possibly using Bronx Community College as a
location for such an incubator.
24/29
NYPD
Other NYPD
Community Board 5 requests that the city
programs requests
establish a Victim Support Services Program in
the district which would deal with the victims of
crimes or the families of victims of crime. The
program would assist these victims and their
family's with funeral arrangements, counseling,
financial support and other needs of these
residents.
25/29
DPR
Plant new street
We are requesting tree plantings for the
Sedgewick
trees
intersection of Sedgwick Avenue, Roberto
Ave R
Clement State park bridge and West Tremont
CLEMENTE
Avenues. There are few plantings ta this
STATE PARK
location and there are residencies at this
BRDG West
location. Tree plantings would also aesthetically
Tremont Ave
link the park with the nearby community.
26/29
NYPL
Extend library hours
We are requesting monies so that staff may be
2150
or expand and
allocated to provide services outside the Francis
University
enhance library
Martin Library branch. The proposed project will
Avenue
programs
provide one library staffer to supervise reading
of library materials in the park abutting the
Francis Martin library during summer hours.
27/29
NYPL
Extend library hours
Extend the library's programming so that it may
1701 Martin
or expand and
be open 6 days per week.
Luther King
enhance library
Blvd.
programs
28/29
DYCD
Provide, expand, or
There is a dearth of programming for youth of
enhance after
all ages. We need further resources for anti-
school programs for
gang/violence programs, especially trying to
all grade levels
combat youth against the elderly crime
prevention.
29/29
NYPL
Extend library hours
To extend the Francis Martin branch hours to 6
2150
or expand and
days per week.
University
enhance library
Avenue
programs

