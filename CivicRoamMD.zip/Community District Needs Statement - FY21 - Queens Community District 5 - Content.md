- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 5 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1EQvDI1pwMr29pMzN1Oqs3qL_0Vlax2Xv/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1EQvDI1pwMr29pMzN1Oqs3qL_0Vlax2Xv/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
5
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 5
image
Address: 6123 Myrtle Avenue, Ground Floor Phone: (718) 366-1834
Email: qn05@cb.nyc.gov
Website: www.nyc.gov/queenscb5
Chair: Vincent Arcuri, Jr. District Manager: Gary Giordano
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
We are a community of people who have roots in many nations and places throughout the world. Regardless of where our forefathers and foremothers originally lived, the great majority came to our country for a better life. The overwhelming majority of New Yorkers and Americans have some simple requests: to live in peace, in a safe community, with good public resources and services. Families and individuals continue to risk their lives to make it to a place like America. Whether to escape violence, hunger, economic instability and oppressive governments we should be honored to live in a country that continues to feed the dreams of immigrants everywhere. In Queens, there are known to be more than two and a half million residents with ancestry from well over 100 countries. This has and will increase demands on us nationally and in our communities. This, combined with the pressure on our environment, will demand that we work together cooperatively and intelligently. We have our faults as individuals and as a nation, but we are a nation of the people, by the people, for the people, united under the belief in the Dream of a better life for ourselves,our loved ones and for future generations. Our Community Board 5 area is comprised primarily of the Ridgewood, Maspeth, Middle Village and Glendale communities. We are also responsible for a few blocks of Woodside, Rego Park and Elmhurst.
Our geographic boundaries are Maurice Avenue into Calamus Avenue to the north; the Brooklyn border with Bushwick on the south (Cypress Avenue ,Wyckoff Avenue and Irving Avenue); Woodhaven Boulevard and the CSX Freight Rail Line in the east and the Brooklyn County line with our Williamsburg and Bushwick neighbors in the west. Like many communities in Queens, development of homes and non-farm businesses began at the turn of the 20th century and continued quite industriously through the 1950’s. By the time of America’s first moon landing, our neighborhoods were overwhelmingly constructed. The 2010 Census indicates that there are approximately 170,000 residents living within District 5, Queens, but, like many communities in our City, we know the number of people really living here is significantly greater, considering under-counting and far too many illegal apartments. Locally, our population on paper has risen from 150,000 residents in 1990.
We have had some new housing constructed in the past two decades, essentially where one-family homes with large lots have been replaced by two-family homes or multiple dwellings. The housing stock in our communities is mainly comprised of attached homes, ranging from one to six-family residences. Our most pressing problems include illegal apartments, primarily in basements; large increases in vehicular traffic and too many drivers speeding, running traffic signals and stop signs; a significant reduction in the number of police officers assigned to the 104th Police Precinct since 1995; a growing number of sewer system breaks that are causing dangerous roadway conditions; illegal dumping and abuse of city litter baskets; a shortage of Parks maintenance workers to keep playgrounds and ball fields in good repair; and very crowded schools. There is a likely correlation between the increases in illegal apartments and the overcrowded schools conditions. The need for many services historically provided by City agencies is growing for numerous reasons. It is due mainly to the age of specific communities’ roadways, sewer lines, bridges and parks. These important assets must be well maintained or they will fall into serious disrepair, necessitating greater capital expenditures, sooner. In an era when many City services had been cut back due to a declining tax base, volunteers have become the backbone of our community. Thank heavens for volunteers who serve diligently on Community Boards, not-for-profit organizations' boards of directors, civic organizations and block associations. Thanks to volunteers in the communities served by Community Board 5, Queens, children and teenagers are engaged in many sports and recreational activities, local parks are cleaner than they would be otherwise, and graffiti has been removed from many buildings.
Many of the area needs that we have worked to accomplish for years seem much less consequential, after the September 11, 2001 disaster at the World Trade Center. Many families need psychological and financial assistance. Our world, in a devastating half-hour, is forever changed. The Police Department, who have done so much to reduce crime, will now be working increasingly with the FBI to greatly reduce the possibility of future terrorist disasters.
After the Trade Center disaster, our wars in Iraq and Afghanistan have caused additional heartache throughout the country. Considering the severe economic recession that hit our country in 2008, and threats of severe federal budget cuts in too many important funding categories, every effort must be made to ensure that government expenditures are prudent, that waste be reduced and that Medicaid, Medicare and other fraud be eliminated.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 5
image
The three most pressing issues facing this Community Board are:
Emergency response
It is very difficult to state that there are 3 definite most important issues facing the communities that many of us have worked for decades to stabilize and improve. There is probably nothing more important to safeguard and improve than the air we share and the water we drink, since life is not possible without these essential resources. Sanitation services, removal and treatment of sewage, stormwater removal , health services and basic medicines are critical in preventing unhealthy conditions and disease. Police are essential, as are Firefighters and EMS workers, to safeguard the people and for response to emergencies. People need to earn a living in order to pay for housing, to buy food and pay for essential services provided by the municipal government. A quality business environment is important so that the people are gainfully employed and earning enough income to at least meet their essential needs. Since the great majority of us do not have the luxury of walking to our place of employment, reliable, safe public transportation and stable, smooth roads, bridges and tunnels are vital for us to get where we need to go.
Children, teens, young adults and all of us need to be increasingly educated and skilled to propel a civilized society in an ever more competitive, more global environment. Few of us are willing to live in tents, therefore quality, affordable housing is essential. Since living in a city presents fairly crowded conditions, where the great majority of us don't have our own private outdoor space, safe public parks provide important "outdoor" recreational space and, like cultural spaces, a place for people of all ages to communicate, socialize and rejuvinate. All of the societal categories listed above are very important, so the questions are where is our city most in need at the current time, to our far from complete knowledge. Emergency response is almost always the most important issue facing our community Board area. Having at least 20 additional Police Officers assigned to the 104th Police Precinct is our 1 expense budget priority. The number of Police Officers assigned to the 104th Police Precinct has declined by almost 30% in the past 25 years. This reduction forces officers and supervisors to hold more 911 calls, and too often has put our precinct in backlog and alert status, and forces police to too often take one 911 call after another.
Street flooding
It is very difficult to state that there are 3 definite most important issues facing the communities that many of us have worked for decades to stabilize and improve. There is probably nothing more important to safeguard and improve than the air we share and the water we drink, since life is not possible without these essential resources. Sanitation services, removal and treatment of sewage, stormwater removal , health services and basic medicines are critical in preventing unhealthy conditions and disease. Police are essential, as are Firefighters and EMS workers, to safeguard the people and for response to emergencies. People need to earn a living in order to pay for housing, to buy food and pay for essential services provided by the municipal government. A quality business environment is important so that the people are gainfully employed and earning enough income to at least meet their essential needs. Since the great majority of us do not have the luxury of walking to our place of employment, reliable, safe public transportation and stable, smooth roads, bridges and tunnels are vital for us to get where we need to go.
Children, teens, young adults and all of us need to be increasingly educated and skilled to propel a civilized society in an ever more competitive, more global environment. Few of us are willing to live in tents, therefore quality, affordable housing is essential. Since living in a city presents fairly crowded conditions, where the great majority of us don't have our own private outdoor space, safe public parks provide important "outdoor" recreational space and, like cultural spaces, a place for people of all ages to communicate, socialize and rejuvinate. All of the societal categories listed above are very important, so the questions are where is our city most in need at the current time, to our far from complete knowledge. Street flooding is an ongoing pressing issue in Community District 5, Queens. Solutions still need to be found to reduce flooding during heavy rains in the Glendale community. This includes the area of 77 Avenue and 78 Avenue, from 76 Street to 88 Street, and along Cooper Avenue from 74 Street to 78 Street. Sewers capital projects will need to be funded to solve these flooding problems. We have succeeded in obtaining funding from the N.Y. City Dept. of Environmental Protection budget for capital projects, to increase sewers capacity in the Penelope Avenue/74 Street area of Middle Village and in the Calamus Avenue/69 Street area on the Maspeth/Woodside border.
Traffic
It is very difficult to state that there are 3 definite most important issues facing the communities that many of us have worked for decades to stabilize and improve. There is probably nothing more important to safeguard and improve than the air we share and the water we drink, since life is not possible without these essential resources. Sanitation services, removal and treatment of sewage, stormwater removal , health services and basic medicines are critical in preventing unhealthy conditions and disease. Police are essential, as are Firefighters and EMS workers, to safeguard the people and for response to emergencies. People need to earn a living in order to pay for housing, to buy food and pay for essential services provided by the municipal government. A quality business environment is important so that the people are gainfully employed and earning enough income to at least meet their essential needs. Since the great majority of us do not have the luxury of walking to our place of employment, reliable, safe public transportation and stable, smooth roads, bridges and tunnels are vital for us to get where we need to go.
Children, teens, young adults and all of us need to be increasingly educated and skilled to propel a civilized society in an ever more competitive, more global environment. Few of us are willing to live in tents, therefore quality, affordable housing is essential. Since living in a city presents fairly crowded conditions, where the great majority of us don't have our own private outdoor space, safe public parks provide important "outdoor" recreational space and, like cultural spaces, a place for people of all ages to communicate, socialize and rejuvinate. All of the societal categories listed above are very important, so the questions are where is our city most in need at the current time, to our far from complete knowledge. Traffic gridlock conditions are worsening by the month. Too many drivers speed throughout our communities and our city, too many do not obey traffic signals and stop signs , and too many impatient, disrespectful drivers do not give pedestrians the right of way. We receive regular requests from community residents for traffic calming measures at corners and on residential blocks.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 5
image
M ost Important Issue Related to Health Care and Human Services
Services for domestic violence victims
All of the above listed issues are important, but Domestic Violence is the issue that is likely the most pressing, as this problem results in many 911 responses by Police. Mental Health Issues and substance abuse are also very important to address, as these problems are the cause of much domestic violence and criminal activity. The USA has been too violent for far too long, especially when one considers that violent crime rates in the great majority of other "industrialized countries" are much lower. Too often violence , meanness and the degradation of women is almost glorified in music, movies, video games and other entertainment. There are too many negative vs. positive influences afflicting society. Respect for others ,especially men for women, is essential to reduce abuse & domestic violence. A significant concern is that, according to the last N.Y. City Community Health Survey in 2012, approximately 239,000 adults living in N.Y. City have problems with Serious Mental Illness, but only about 60% of these people in need have received mental health treatment in the past year. There seems to be a large gap between the number of people needing mental health treatment and the availability of this important treatment.
There are reportedly also critical affordability issues for many people in need of mental health treatment, either because they are not adequately insured or because they haven't the necessary insurance or funds to pay for treatment that is often critically needed.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Ridgewood Medical Center,now renamed Gotham Health/Cumberland, located at 769 Onderdonk Avenue in Ridgewood, is a NYC Health and Hospitals Corporation facility that now serves residents of all ages. This Center is needed for poor and low-income residents of Ridgewood and neighboring communities. Once known as the Maspeth Child Health Station, and then Ridgewood Communicare Health Center, thousands of children, ages newborn to six, received health services here for decades. The fact that residents of all ages can now receive health care at this neighborhood site is very important, especially for school-age children who might not see a doctor otherwise. Additional hours of operation should be added, especially on evenings and Saturdays, to meet increased demand and parent working hours. Elmhurst Hospital, an HHC facility located outside of the CB5Q area, has a very good reputation for a City Hospital. This standing is even more impressive when one considers the diverse ethnic make-up of the people served at this hospital. Quality care and renovations at Elmhurst Hospital are very important to all of Queens. While Wyckoff Heights Medical Center and St. John's Hospital had been the primary health sites for CB5Q area residents, we are in Elmhurst Hospital's catchment area and are dependent upon this hospital's emergency room in critical times. The closures in 2009 of both St. John’s Queens Hospital and Mary Immaculate Hospital could severely hurt health care in Queens. Every effort should be made to replace these hospitals with medical facilities, if doing so as hospitals is cost-prohibitive. Bureau of Pest Control inspection and extermination services are an important priority. With as many or more rats in the City as people, it is very short-sighted and potentially dangerous to fund this arm of the Health Department at inadequate levels.
Needs for Older NYs
The neighborhoods of Community District 5, Queens have a very large senior citizen population and many of these seniors are living into their late seventies and eighties. As a result, there is more of a need than ever for "Meals on Wheels", transportation and other services for the frail elderly. Congregate meals programs continue to be important, so that seniors get to socialize, exercise and receive good hot meals. Caregiver Programs that give comfort and free time to family members who care for frail seniors are also very important, especially considering how these family members have saved government so much cost of nursing homes and other types of formal care.
Alzheimer's Programs and other mental health services are a critical need, as many seniors are living well into their eighties. Housing for seniors is another important need. Well-supervised nursing homes, where background checks are done to prevent abuse of senior citizen residents, is essential.
Needs for Homeless
The homeless population in New York City and the lack of affordable housing for many New Yorkers is a serious concern. Yet, any plans to build large facilities to warehouse the homeless or to pack homeless people into hotels is unwise. There are still a large number of vacant buildings and lots, where residents without homes can have a place to live. This requires renovation and new construction. Why not hire professionals to teach people who are without a stable place to live to renovate and/or build housing for themselves? This would provide more housing at lower cost while teaching people a skill at the same time. Providing rent subsidies through thoughtful, carefully run programs to those who are at risk of becoming homeless, or those individuals already struggling to live in the homeless shelter system, is likely one of the best solutions to housing the homeless and those at risk of homelessness. Rent subsidies need to be combined with quality counseling, education, employment, substance abuse prevention/intervention services, domestic violence services and mental health services if those at risk are to be really helped now and for the longer term. The provision of professional legal services for people being harassed by landlords and/or in danger of eviction from their apartment is an important need in an effort to prevent homelessness. Some of the good news, according to the N.Y. Dept. of Homeless Services, is that evictions are down 27% in the past year, and family homelessness has been reduced in the past year, for the first time in a decade.
Needs for Low Income NYs
Responsible provisions for those in need is important in a civilized, overly competitive society. While the number of people in NYC receiving public assistance has been reduced in recent years, the societal safety net is important. Too many people are unemployed, under employed and lack education levels and skills necessary to obtain a job in which they earn enough to pay for food, and housing, medical insurance, doctor visits, clothing, utilities and other basic needs. The loss of manufacturing jobs in the USA has meant that opportunities are lacking, in too many situations, Jobs have been transferred by USA companies to other countries, where work environments are unhealthy, unsafe, and where workers, some as young as teens are earning $1. an hour, working 16 hours a day ( I.E. Apple Products made at Foxcon) and sleeping in barracks like conditions. It would be better for the people of the USA, and cities like New York if companies and their stockholders were much less greedy. Manufacturing jobs should at long last be brought back to the USA, so that our citizens can be gainfully employed and people paid a living wage for their efforts. In the great majority of cases, crime , despair , substance abuse and mental health problems are highest in those communities where unemployment and underemployment is all too much the norm. The bottom line is that, for too long, increased corporate profits may have meant more income for some but has reduced opportunities for the great majority of our people. This is becoming more and more of a national security issue. Food stamps, housing subsidies and medicaid are essential for far too many, and need to be provided for those truly in need. This need would be greatly diminished if manufacturing employment was brought back to the USA. Another problem is that in too many cases skilled jobs may be available (i.e. construction, plumbing, electrical), but there are not enough people with the necessary skills to fill these employment opportunities.
Employment training, with a priority in marketable fields, is very important. A 4 year college diploma is certainly not the only path to a good living and teaching people trade skills should be a priority. For instance, recent news reports state that more than 50,000 new truck drivers will be needed each year for at least a decade, to transport food and goods in a timely manner. Sadly, many of the most vulnerable residents are senior citizens, who are faced with soaring housing expenses, and too often have to chose between paying for essential medicines instead of healthy food and other necessities. Safeguarding at-risk elderly citizens is vital in a civilized society.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
7/25
DFTA
Other services for
Provide Needed Services for Senior Citizens.
homebound older
Community District 5, Queens has a very large
adults programs
senior citizen population, many of whom are
frail, without adequate care and living alone.
The following are necessary programs to meet
some of the needs of senior citizens: 1) Provide
adequate funding for Meals-on-Wheels
programs; 2) Provide adequate funding for
congregate meals programs; 3) Provide funding
for senior transportation programs; 4) Fund
Health Care Programs for the Elderly and Senior
Home Care; 5) Fund Emergency Food Programs
for Seniors.
15/25
DHS,
Provide, expand, or
Consistent, adequate funding is needed for
HRA
enhance rental
programs such as the Living in Communities
assistance programs
Rental Assistance Program (LINC), to prevent
people from becoming homeless, and to move
people from shelters to more permanent
housing.
18/25
DOHMH
Reduce rat
Hire Additional Personnel for Pest Control to
populations
Combat the Enormous Rat Population in our
City. The Borough of Queens has too few staff to
adequately address the rodent infestation
problem, which has increased with the growth
of dump-out locations and vacant properties. A
minimum of 4 additional inspectors and 4
additional staff to bait are needed for Queens.
19/25 HHC Other health care
facilities requests
Continue Funding of the Ridgewood Medical Center, now renamed Gotham Health/Cumberland. The Ridgewood Medical Center (formerly known as the Maspeth Child Health Station and Ridgewood Communicare Health Center) provides important health services to many children, families and senior citizens. Ridgewood and neighboring communities have seen an increase in the number of people struggling economically. The need to expand services beyond the hours of Mon. to Fri., 8:30am to 4:30pm, should be seriously considered to serve workers and workers with children.
769
Onderdonk Avenue
image
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 5
image
M ost Important Issue Related to Youth, Education and Child Welfare
Educational attainment
Far too many children and teens are performing below grade level in too many schools. What kind of a future will they have if they are not reasonably well educated, and at least secure a high school diploma? Not everyone is academically inclined, and many are much more interested in learning a skill (i.e. Electrical, plumbing, carpentry), but without at least a high school diploma obtaining any employment paying a living wage is very difficult. Young people need to prize learning more,but many of their influences are negative like music, movies and television that promote entertainment and disrespect instead of learning. After school tutoring programs have been one of the best services that help children and teens to learn in a smaller setting &. boost their confidence.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Overcrowding in our local schools has become a great concern throughout Community School District 24, of which the communities of CB5 Queens are a major part. Historically, Community School District 24 has been among the most overcrowded in the City. While this is not true in all neighborhoods, it has certainly been a problem in the Ridgewood community. In the past 3 years, we have seen the completion of two new public schools in Ridgewood, one on Metropolitan Avenue at Tonsor Street, P.S. 290; and another one on Seneca Avenue at DeKalb Avenue, P.S.
320. In the past 9 years we have also seen the completion of two new schools at PS 128 and another at PS 305, as well as school additions at I.S. 77, P.S. 49, P.S. 87 and P.S. 113. A new high school opened on Metropolitan Avenue, east of Woodhaven Boulevard, in September, 2010. Because of the need for additional space for high school students, construction of a new high school on 74 Street at 57 Avenue, in Maspeth, for 1,100 students, was completed in September 2012. Considering the need for high school education locally, CB5Q requests that a new high school be constructed in Queens. The Department of Education plans to construct new schools, mini-schools and school additions are much needed, considering current and projected classroom overcrowding. The education of children, pre-teens and teenagers is suffering as attempts are made to teach in gyms and auditoriums. Plans for new schools should consider adjacent residential and business communities. In general, the Mayor, elected officials and the NYC Department of Education must strategically prioritize the provision of adequate learning space and the ongoing, regular repair and maintenance of educational facilities.
Needs for Youth and Child Welfare
There are few issues in life that are more upsetting and more alarming than children being abused, especially by their parents or a family member. The fact that there are 55,000 cases of child abuse or neglect annually in N.Y. City indicates the enormous pressure on the Administration for Children's Services to intervene, to safeguard the well- being and life of children and teenagers. The immediate priority is that there are enough competent case workers and supervisors to respond to reports of abuse or neglect and to provide ongoing case monitoring. Education in parenting is lacking and an important need to fulfill, especially related to the responsibilities of fatherhood.
Recruiting and securing commitments from caring foster care parents is very important. Some good news is that, according to the N.Y. City Administration for Children's Services, they have improved their ratio of Child Protective Specialists/Case Workers to better than 1:12 for family cases in N.Y. City and in some situations, where cases are more critical, the ratio of Child Protective Specialists to families is as low as 1:8 or 1:4.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
8/33
SCA
Provide a new or
Construct New School Space, Where Needed, in
expand an existing
the Community Board 5, Queens Area, Including
high school
a New High School in Queens. Construction of
additional classroom space for children and
teenagers, residing in the CB5Q area, has been
essential to relieve school overcrowding. The
CB5Q area is part of Community School District
24, which is often the most overcrowded school
district in N.Y. City. There are a shortage of
opportunities in our area and in Queens to
attend a good high school.
29/33
SCA
Renovate or
Provide a New Elevator for the I.S. 93-Q Main
66-56 Forest
upgrade a middle or
School Building, located at 66-56 Forest Avenue
Avenue
intermediate school
in Ridgewood. There is no elevator in the main
building of I.S. 93-Q. The building is 5 stories
high. There are reportedly 125 documented
cases of students with asthma in attendance at
this school. There is no access for students, or
their guardians, who are physically challenged.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
5/25
DYCD
Provide, expand, or
Provide Funding for Educational and
enhance after
Recreational Programs, for Children and Teens.
school programs for
Funding for after school, evening and weekend
middle school
delinquency prevention programs should be
students (grades 6-
maintained locally. This is especially critical at a
8)
time when far too many children and teenagers
are unsupervised by parents or guardians after
the school day ends and on weekends. These
programs are very critical as they increase self-
esteem levels of participants, thereby
preventing substance abuse and delinquent
behavior. While Beacon Programs are welcome,
it is vital that funding for other quality "local"
education and recreation programs be a
priority. Thankfully, Mayor de Blasio and City
Council Members have increased youth
program funding substantially.
23/25 ACS Other foster care
and child welfare requests
Fund Bureau of Child Welfare (B.C.W.) Satellite Office in Queens. There is a need for a Bureau of Child Welfare satellite office, especially during the 6 p.m. to 8 a.m. hours, to operate weekdays and weekends. Many children in CBQ 5 have sought sanctuary from abusive parents, relatives and other individuals. With B.C.W. staff hours limited, the abuse of children is too often unattended and the problem situation continues.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 5
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
While crime has been reduced greatly in NYC during the past 2 decades, our 104th Police Precinct officers and supervisors are very busy answering 911 calls on the 4pm-Midnights Tour and the Midnights to 8am Tour. We must be careful not to get too comfortable with crime being reduced, since matters can change all too soon. One serious concern is that there are currently only 156 Police Officers& Detectives, exclusive of Supervisors, working in the 104 Police Precinct. A serious concern, which is not one of the 7 major crime categories unless a situation escalates to a crime,, is how often Police need to respond to situations related to the possibility of domestic violence. Other problems, which Police often can't give sufficient attention to, include too many drivers speeding and not giving pedestrians respect; and illegal truck traffic. Physical conditions at the 104th Police Precinct need to be improved ongoing. Some of the needs include: - At the Top Floor (Roof Level) the flagpole needs to be replaced, as it is severely rusted. The ceiling light fixture at the roof door is overdue for replacement. - On the 3rd Floor the locker room floor tiles are in very poor condition and need replacement, the male restroom toilets need to be replaced or seriously repaired, and the window blinds need to be replaced. - On the 2nd Floor the entire ceiling or portions of it need replacement, as there are large holes in the ceiling. - On the main floor a new desk is needed for the Desk Officer. - In the Basement the floors and walls need to be at least repainted - The Precinct Garage needs to be upgraded and at least painted.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Some capital improvements have been performed at the 104th Police Precinct, including: a new roof, boiler replacement, plumbing system upgrades, renovation of locker rooms, bathrooms and a new assembly room. Additional improvements needed are: painting the entire precinct, consideration for ongoing plumbing and electrical upgrades, replacement of the flag pole and light fixture at the roof level, replacement of locker room tiles on the 3rd floor and replacement of toilets on the 3rd floor, and replacement of portions of the ceiling on the 2nd floor. Crime may be down on paper, but violent crime, robbery and quality of life remain the first concern of most New Yorkers. Our communities of Ridgewood, Maspeth, Middle Village and Glendale had witnessed much more lawless behavior until recent years. Efforts to win the crime war have included, acquiring the Robbery Identification Unit at the 104th Precinct, advocacy for more police officers and communities working with those police officers, removal of a great deal of graffiti from buildings, and providing after school and weekend education, sports and recreation programs. Once known as the "country club", the 104th Precinct, by 1991, awoke to the facts of 1,000 robberies and more than 4,000 auto thefts per annum. And we live in some of the more stable city neighborhoods. The residents of the Community Board 5, Queens area need the following resources and the police cooperation to effectively fight crime in the areas served by the 104th Precinct: • 170 Police Officers; 24 Sergeants; 7 Lieutenants; 2 Captains • Robbery ID Unit, considering Bushwick border and commercial areas • A well run Precinct Detective Unit
Sufficient, well conditioned cars, scooters, bicycles, 4-wheel drive vehicles and vans for Police to effectively patrol.
Better attentiveness to juvenile crime • Stiff prison sentences for the most violent criminals and more structured detention for auto thieves, pickpockets and substance abusers • Long-term prison sentences for those convicted of dealing in quantities of heroin, crack and other hard drugs • Attention to the physical condition of the 104th Police Precinct and the morale of the officers, who do not work in the most enviable conditions Illegal truck traffic continues to create havoc throughout our city. This problem needs more attention from the NYPD, DOT and other responsible agencies.
Needs for Emergency Services
The condition of buildings that serve Fire Department Engine Companies and Ladder Companies is critical. An example of problems that can arise from lack of capital improvement to fire houses has been seen most recently when the fire companies located at the house on Grand Avenue, just west of Queens Boulevard in Elmhurst, had to
be relocated. It is imperative that capital improvements to the structures and apparatus floors of all fire houses be performed expeditiously, based on problems reported by engine and ladder companies and inspections done by qualified engineers. Regular ongoing replacement of Engine Company and Ladder Company fire fighting vehicles must be a City priority. To our knowledge, funding was available to provide Fire Department apparatus with exhaust connections that are state of the art, to provide minimal danger to firefighters' health in the fire houses. It is critical that these new exhaust connections be installed, and maintained, in all fire houses. Professional fire protection is absolutely essential in urban areas. The risk of reduced services in the Fire Department can be disastrous. Those living in Ridgewood and adjacent communities remember well when the nearby Bushwick, Brooklyn community was devastated by fire in the 1970's. Fire Prevention is an important concern. With the growing number of illegal occupancies in residential buildings, it is more important that the Fire Department play a greater role in curbing this problem. Often times a Building Department or Housing inspector cannot gain access to a building that has one or more illegal apartments, but access will less likely be refused to firefighters. There are also serious concerns about reductions in the number of firefighters that go out on each run to a fire scene, both planned and reductions that have already occurred (roster manning). This can endanger the public as well as the firefighters. Emergency Medical Services (Ambulances) are a top priority of the members of Community Board 5, Queens. The time that it takes for an ambulance to get a person to the emergency room of a hospital can be the difference in life and death. Well trained EMS workers and properly maintained ambulances are of the utmost importance. We have been most fortunate to have the Ridgewood, Middle Village and Glendale Volunteer Ambulance Corps working in cooperation with EMS
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
27/33
NYPD
Renovate or
Rehabilitate the 104th Police Precinct Station
64-02 Catalpa
upgrade existing
House Interior and Exterior The 104th Police
Avenue
precinct houses
Precinct station house is an old building and
improvements needed include: painting the
entire precinct, possible roof upgrades as the
roof may be 10 years old,replacement of the
flagpole and light fixture at the roof level,
replacement of the 3rd floor locker room floor
tiles and restroom toilets, and ceiling
replacement in parts of the 2nd Floor. Ongoing
plumbing and electrical upgrades are also likely
needed.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/25
NYPD
Assign additional
Assign Additional Personnel for the 104th Police
uniformed officers
Precinct Patrol Force. Within the last 6 years,
the patrol strength of the 104th Pct. has
dropped under 130 officers. In 1995, there were
approx. 200 officers, exclusive of sergeants &
lieutenants for Ridgewood, Maspeth, Middle
Village, and Glendale. At least 170 officers are
needed for the 104th Pct., plus supervisors, to
cope with robbery, burglary, violent crime,
domestic violence threats, inadequate response
times, speeding, auto theft and rowdy youth
conditions often caused by substance abuse. The
new Atlas Park Shopping Development, which
opened in Spring 2006, has put additional
pressure on our already overloaded precinct.
6/25
FDNY
Provide more
Provide Funding for Fire Department Services.
firefighters or EMS
Funding is needed for the following essential
workers
Fire Department Services: maintain engine
companies and ladder companies at current
staffing levels; provide funding for the
Department's Building Unit; ensure adequate
staffing for excellent maintenance of FDNY
apparatus and other vehicles; and provide
sufficient funding for the Fire Safety Education
Unit.
17/25 NYPD Other NYPD staff
resources requests
Hire Traffic Control Agents, School Crossing Guards and Additional School Safety Officers. The City should earmark funding to hire additional traffic control agents: (Traffic Enforcement Agents-Level II), so that heavily travelled Queens intersections can be staffed. This will diminish the need to assign police officers, who are paid more. In consideration of dangerous traffic conditions, funding is needed to hire at least 5 additional school crossing guards for District 5, Queens schools. Most elementary schools have only 1 or 2 School Safety Officers; intermediate schools only have 3 officers, which in many schools is very insufficient.
image
22/25 FDNY Other FDNY facilities
and equipment requests (Expense)
Provide Funds for: Tools and Equipment for Local Fire Department Personnel and for Fire Prevention Program Supplies. Hurst Tools, Rabbit Tools, defibrillators, power saws, first aid equipment, etc., are needed to ensure the safety of local residents. Funding for Fire Fighters' face pieces is also an important need. Funding is also requested to purchase 10,000 smoke detectors, at a total cost of approximately $100,000, and 10,000 carbon monoxide detectors, at a cost of
$200,000 for distribution to the public throughout the year. Funding is requested to purchase 10,000 new CPR kits for public training and distribution.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 5
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Sewer capacity
There has been extensive street and basements flooding in portions of District 5, Queens, during heavy rains. Considering ongoing environmental pressures globally and in the USA, where we have witnessed more violent weather in recent years, infrastructure upgrades are vital. On 8/8/2007, for instance, we had 4 plus inches of rain locally in 45 minutes. On 8/15/2012, we were flooded with 3 inches of storm water in just 30 minutes. More recently, on 8/7/2018, heavy rains caused extensive street and basement flooding in our communities. As a result, significant parts of Maspeth, Middle Village & Glendale were overwhelmed by flooding. With forecasts of continued global warming, we better be well prepared. Solutions to flooding problems during moderate to heavy rainstorms are especially needed in the Glendale community, along 77 Avenue and 78 Avenue from 76 Street to 88 Street.
During the past year we have had 2 major sewers projects under construction in District 5, Queens, to eliminate or greatly reduce flooding conditions by providing greater sewers capacity. One of these current sewers projects is in the Penelope Avenue/74 Street area of Middle Village, where during heavy rains many home basements have been flooded with more than a foot of storm water. The other significant sewers construction project is in the Calamus Avenue/69 Street area of Maspeth and Woodside, and this project was recently completed.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Every effort must be made to maintain the high quality of the drinking water available to NY City residents. Travelling to other localities, City residents can take pride in the fact that they can still "turn on the tap" and pour an excellent glass of drinking water. Completion of the Third Water Tunnel and the system that will bring water from this tunnel to residents and businesses is very important. Many of us were fearful of plans for hydrofracking in New York State, which could have disastrous effects on our prized drinking water and environment. The effects of this high volume deep drilling for energy sources has ruined the environment severely in other states. Hydrofracking plans may pose one of the greatest threats to our environment in our lifetime. Thank goodness fracking is now banned in N.Y. State. While the water system in our City is quite good, the sewer system is another matter entirely. Cave-in conditions on local streets and main arteries are very often caused by sewer line breaks or problems with manhole structures. Sunken and broken corner catch basins can go unrepaired for months at a time. The Community Board consistently reports clogged catch basins and sewer lines that need to be cleaned and flushed.
The City must make the repair of broken sewer lines, fire hydrants and catch basins a significant priority, and catch basin cleaning needs to be performed expeditiously. Personnel to perform this work must be hired. Efforts to get the public and businesses to stop littering and dumping into catch basins are important. Air pollution and noise pollution are important concerns as well. Part of the solution is enforcement. Street tree plantings are a great means to reduce air pollution. An excellent public transit system is another important means of reducing air pollution, especially train service. Ongoing efforts are needed for building owners to upgrade to less polluting heating systems. We also need to have stringent regulations for truck emissions, as we do for our motor vehicles.
Needs for Sanitation Services
Illegal dumping has become a terrible problem in our communities , and probably one of the primary reasons that businesses, especially manufacturers and distributors, have left the City for so called greener pastures. Thankfully, the Queens District 5 Sanitation force has done a great deal to get dumping locations cleaned as expeditiously as possible, given fairly limited resources. Sanitation Police ‘stake-outs’ of dumping sites must be a priority. Littering has also become a growing menace, as has the preponderance of residents who feel free to dump their household trash in and around the City litter baskets. The reason that Community Boards are consistently requesting that catch basins be cleaned and sewer lines flushed, in so many locations, is the degree of littering done in the catch basin and on the street. For the most part, refuse and recycling collection is consistent and respectful in QW5. Snow removal had been quite efficient during the storms of recent years, but there were potentially serious snow
accumulations that went unaddressed for days during the winter of 2015/2016. Mechanical broom sweeping of Ridgewood, parts of Maspeth and Glendale, along with the help of caring residents, keeps the area reasonably clean except where illegal dumping and litter occurs. Collection of sanitation litter baskets,on our busy commercial strips, needs to be performed 7 days a week. Recycling at schools is where many problems are caused in the community.
Bagged food cans and other recyclables can't be stored in schools, so custodial staff put the bags on the sidewalks adjacent to the schools, causing an eyesore and encouraging illegal dumping. The Sanitation Department needs to schedule pick-ups for recyclables at many schools daily. Five-Day-A-Week School Garbage Collection is a top priority for District 5, in Queens. The QW5 area is still plagued with illegal dumping, primarily in out of the way areas (adjacent to the LIRR/CSX, and where industry must flourish). The Sanitation Department has successfully worked to diminish this once overwhelming scourge, but too often QW5 staff must return time after time to clean-out dump sites. Too many of the people living in New York are abusing our city and this needs to change. Sanitation Police must give more priority to ‘staking-out’ dumping sites (especially between 10pm and 6am), seizing vehicles, incarcerating dumpers, and publicizing the names of those convicted in major media.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
1/33
DEP
Inspect sanitary
Redesign and Reconstruct Sewer System in
sewer on specific
Portions of the CB5Q Area. After heavy rains,
street segment and
CB5Q has received complaints of extensive
repair or replace as
street flooding and basement sewer backups in
needed (Capital)
parts of our communities. Aged sewer lines
likely need to be replaced, enlarged or realigned
to reduce flooding and resulting property
damage, especially along 77 Avenue and 78
Avenue from 76 Street to 88 Street, in Glendale.
2/33
DEP
Inspect sanitary
Reconstruct Deteriorated Catch Basins and
sewer on specific
Construct New Catch Basins. There is an
street segment and
increasing need to replace deteriorated brick
repair or replace as
catch basins with pre-cast concrete structures.
needed (Capital)
We have had many catch basins with adjacent
cave-in conditions, and/or where the structure is
sunken. There is an ongoing need for new catch
basins to reduce street flooding during
rainstorms.
16/33
DEP
Inspect sanitary
Continue a Comprehensive Study of the Sewer
sewer on specific
System in the Community Board 5Q Area and
street segment and
Throughout Queens County, Considering
repair or replace as
Flooding Problems and Anticipated Future
needed (Capital)
Growth. A thorough sewer system study,
including analysis of flow patterns to treatment
plants, needs to proceed and be accomplished in
the very near future so that street flooding and
basement sewer backups can be greatly
reduced. The sewer system links our
communities with those of other community
districts throughout Queens. Solutions to
flooding are especially needed in the area of
Cooper Avenue (btw 74 St and 78 St), and along
77 Avenue and 78 Avenue (btw 80 St and 88 St).
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/25
DEP
Inspect sanitary
Provide Field Workers for Bureau of Water and
sewer on specific
Sewer Operations. Field workers in sufficient
street segment and
numbers are needed to ensure that City water
repair or replace as
remains excellent; that catch basins are cleaned
needed (Expense)
and repaired and sewer lines are flushed in a
reasonable amount of time; that sewer backups
and leaks are corrected expeditiously and that
sewer repairs and fire hydrant repairs are
performed in a timely manner. Currently, cave-in
conditions in the road and adjacent to catch
basins too often go unrepaired for months,
presenting dangerous conditions.
4/25
DSNY
Provide more
Provide Sanitation Department Cleaning
frequent litter
Personnel, to Clean Illegal Dumping and for
basket collection
Litter Basket Collections. Illegal dumping and
garbage drop-off locations are a consistent
problem in District 5, Queens. In order to
alleviate these very problematic conditions,
which are potential health hazards and hamper
business investment: 1. Restore Clean Team
personnel to clean dump-out and drop-off
locations on a regular basis, 2. Provide
adequate personnel to empty litter baskets 7
days a week.
8/25
DSNY
Provide more
Continue 5 Times Per Week Garbage Collection
frequent garbage or
and Begin 5 Day a Week Recycling Collection for
recycling pick-up for
Schools. The reduction to 2 days per week
schools and
garbage collection caused unsanitary conditions
institutions
around many local schools. School collection, 5
days per week, is critical during the school year
and during the Summer. It is also important that
recycling collection at schools be increased. Five
times a week recycling collection is needed for
many public schools, as the current conditions
result in recyclables crowding school sidewalks.
image
13/25 DSNY Other enforcement
requests
Increase the Number of Sanitation Police and Enforcement Agents, Especially in Plain Clothes, to Significantly Reduce Excessive Abuse of Litter Baskets and Illegal Dumping. Because of previous lay-offs, there are now fewer Sanitation Police citywide for illegal dumping. Sanitation Police positions should be greatly increased for illegal dumping, especially since they are revenue producing, and dumping is severely hurting communities. One SEA agent is needed daily in Q5. Severe fines, vehicle impoundments and more publicity, such as frequent press releases to TV and radio stations and major newspapers, are needed to make an example of dumpers and curtail illegal dumping. The abuse of litter baskets on commercial strips has become deplorable, and needs to be better addressed.
image
20/25 DEP Investigate odor
complaints about a wastewater facility and address/repair or make equipment improvements as needed (Expense)
Hire Operations Staff- Bureau of Wastewater Pollution Control. Sufficient Staffing is needed to perform odor and water pollution control monitoring at wastewater treatment facilities in New York City. Odors from wastewater treatment facilities pose health hazards, will likely casue residents to move and could severely hamper business investment. Locally, we are most concerned about the Newtown Creek Water Pollution Control Plant.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 5
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
Building code enforcement continues to be one of our most important Expense Budget Priorities, since there are far too many residents living in illegal apartments and ongoing issues regarding construction without proper permits. In the past 4 years, the Ridgewood community has seen buildings purchased by speculators who have pushed tenants out or bought them out, so that they can obtain much higher rents. Affordable housing, especially for those renting, is a growing problem, most recently in Ridgewood where "runners" have reportedly gotten landlords to sell primarily 6 family houses, so that renovations can be made and rents can too often be doubled unfairly. Tenants, who have lived in these multiple dwellings for years, often decades, are being pushed out of their apartments. It is probably no small coincidence that there are approximately 250 people in the NYC homeless Shelter system, who give their last address as somewhere in the Community Board 5, Queens area. The scenario seems to be that people get pushed out of their apartments, which were in today's times affordable, by speculators under questionable corporate disguises, and city taxpayers have to pay exorbitant costs to shelter more and more families and individuals.. There is much that is terribly wrong, and possibly very corrupt with this story. This is all compounded by the fact that the Dept. of City Planning has achieved a M1 Hotels and Motels Zoning Text Amendment, which contains a provision for the use of properties zoned for manufacturing, for the so called public good. Community Board 5, Queens has submitted a Proposed Rezoning of Ridgewood, Queens to the N.Y. City Dept. of City Planning, in an effort to better safeguard this pressured community from overdevelopment and development that is out- of- character with the surrounding community. Many of us thought that we had protected the community when Ridgewood was approved for contextual zoning changes back in 2000. But, with the housing market as hot as it is, some recent property owners are getting permits to add height to buildings in portions of Ridgewood that are part of the Ridgewood State and Federal Historic District, but have still not received protective
N.Y. City Landmarks Status. Much more of Ridgewood should receive N.Y. City Landmarks Designation. Employment is essential, if adults are to be capable of paying for food, housing, clothing, utilities and other essentials, and, of course, the development of quality businesses is vital so that those who are not the entrepreneurs have a place to earn a living. Efforts to give teens and young adults learning and skill opportunities, so that they can be gainfully employed, is critical. A good college education is important for most in our increasingly complex, competitive world, but college is not the best choice for everyone.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
One of biggest risks locally has become large party venues trying to open in buildings zoned for manufacturing. At 52-19 Flushing Av., in Maspeth, the property owner had applied for a cabaret liquor license to serve up to 5,000 patrons, at a large site that provided manufacturing employment for many years. Preliminary plans by the City Council and Mayor to safeguard manufacturing districts from these party place assaults need to become law. We have worked diligently with civic leaders and the Dept. of City Planning, during the past 15 years, to safeguard the character of the Ridgewood, Maspeth, Middle Village and Glendale communities. Our communities needed protection from overdevelopment, which we thought was accomplished. The great majority of the Community Board 5, Queens area has obtained contextural zoning designations , but there are new overdevelopment pressures in our neighborhoods. While many areas of our Community Board area have been rezoned since 2000, more needs to be done to safeguard our communities from overdevelopment, and development that is out of character with the surrounding community. CB5Q has submitted proposals to the N.Y. City Dept. of City Planning to better safeguard the Myrtle Avenue and Fresh Pond Road commercial corridors, in Ridgewood, residential areas in Ridgewood and manufacturing areas. We have met with Dept. of City Planning representatives regarding our rezoning proposals and are hopeful that they will help us safeguard neighborhood character.
Needs for Housing
Affordable housing is more at risk than anytime in decades,especially in the Ridgewood, Queens community. There is a growing, greedy trend for the price of 6 family houses and multiple dwellings generally to be bid up by speculators. "Runners", representing clandestine investors, are reportedly getting more and more property owners to sell buildings, at inflated prices , by forcing long-time tenants out and/or buying them out. Once the apartments can be renovated, our knowledge is that the property owner can recoup their investment in just 40 months and the tenant's rent can rise deploringly from $1,000. monthly to more than double that amount. The Ridgewood community was known for affordable housing, especially in 6 family multiple dwelling buildings, but that was before speculators, operating under very questionable corporate disguises, pushed tenants out of their apartments.
Greatly increased legal, legislative and enforcement efforts are needed to prevent landlords from harassing tenants, to increase penalties against landlords who stop providing essential services or who abuse tenants, and to provide legal services to tenants being harassed by greedy landlords or tenants at risk of losing their apartments.
Needs for Economic Development
Probably the major reason that New York City has had significant problems balancing a budget revolves around the fact that manufacturing and non-service employment has declined astronomically during the past several decades. With this decline in manufacturing and non-service employment related jobs, the number of residents receiving public assistance had risen to alarming heights. The current administration should focus on job development and bring manufacturing back to our City. All too often, we hear about how the City has virtually given-up on the manufacturing sector to boost employment and the tax-base. This effort will no doubt require a great deal of cooperation with Federal and State government, but must be done. Community Board 5, Queens, in July, 2013 , overwhelmingly voted in favor of a Proposed Industrial Business Zone (IBZ) in the Ridgewood area, South of Myrtle Avenue, that is zoned M1-4 and M1-4D. This IBZ has been approved, and implementation of this IBZ designation should help to stabilize and increase manufacturing locally, with good marketing and coordination. In District 5, Queens, we once had one of the largest concentrations of knitting mills in the United States. The knitting industry has historically been associated with the Ridgewood community. Locally, this very important industry has declined, but with the proper support, the garment manufacturing business in Ridgewood and other communities can flourish once again. The West Maspeth Industrial Area is also very important to the community and our City.
Retention of industry in this section of our community has always been a priority of Community Board 5. We have shown our commitment by consistently pushing for improved roadway and sewer conditions in this section of the community. There are four major commercial streets in the Community Board 5, Queens area. Myrtle Avenue in Ridgewood and Glendale stretches from the Brooklyn border all the way to Cooper Avenue. Myrtle Avenue has seen a resurgence in recent years, thanks in large part to the efforts of the Ridgewood Local Development Corporation and the establishment of the Myrtle Avenue Business Improvement District, from Wyckoff Avenue to Fresh Pond Road, in Ridgewood. Grand Avenue in Maspeth, Fresh Pond Road in Ridgewood and Metropolitan Avenue in Middle Village are also important commercial strips. Community Board 5, Queens has important capital budget priorities, requesting capital budget funding for the Reconstruction of Sidewalks, Curbs and Pedestrian Ramps Along Myrtle Avenue, from Fresh Pond Road to Wyckoff Avenue; to Reconstruct Fresh Pond Road from Myrtle Avenue to Eliot Avenue; and to Improve the Myrtle Avenue Commercial Strip in Glendale. These budget priorities are listed in the Transportation Section (Section 8) of this Statement of Community District Needs and Community Board Budget Requests.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
3/25 DOB Assign additional
building inspectors (including expanding training programs)
Hire Inspectors and Plan Examiners, in Sufficient Numbers, to Cope with Illegal Uses of Property and Questionable Construction. A separate afternoon/evening and weekend inspection team of 10 inspectors for Queens is critical because inspectors very often can't gain access in the daytime during the work-week.
Communities throughout Queens have been plagued with illegal apartments posing dangerous conditions, school overcrowding and more pressure on limited City services.
Construction inspectors and plan examiners in adequate numbers are needed to curtail contractors building homes larger than the zoning permits. Currently to our knowledge, Queens has 37 plan examiners and 15 construction inspectors usually working in the borough.
image
16/25 NYCHA Expand programs
for housing inspections to correct code violations
Allocate Funding for Dept. of Housing Preservation & Development Programs. Adequate funding must be appropriated to cope with illegal residential property uses
,deteriorating housing stock, and harassment of tenants by greedy landlords. The needs include HPD Code Enforcement Inspectors; funding for housing rehabilitation loan programs; substantial funding for tenant legal services, and for demolition and seal up operations in Queens. Currently, to our knowledge, only 15 Inspectors are assigned to Queens of 314 Inspectors working in N.Y. City.
image
25/25 NYCHA Other housing
oversight and emergency programs
Increase Funding for Community Consultant Contracts. In Q5, there are many multiple dwellings owned by landlords who need technical assistance related to leases, paperwork and tenant matters. Tenants are often in need of advice and assistance related to lease matters and landlords who do not upkeep property. In Q5, the Greater Ridgewood Restoration Corp. has a history of helping landlords and tenants . This organization has also prevented hundreds of properties from being taken from owners in lien sales through excellent outreach to owners.
image
TRANSPORTATION
Queens Community Board 5
image
M ost Important Issue Related to Transportation and Mobility
Traffic safety
In a society where moving large numbers of people is so vital, public transportation, roads, bridges and traffic safety must be priorities. Traffic safety applies to each of these priorities in a broad sense, and, specifically related to the motor vehicle, our Community Board must consistently request traffic and pedestrian safety studies to safeguard pedestrians and attempt to calm motor vehicle and truck operators. Our community board has successfully led the effort to reconstruct or substantially renovate the train stations in the area we cover, and we have pushed for roadway resurfacing and reconstruction, even along Grand Avenue and Myrtle Avenue overnight; and we were very successful in the acquisition of new natural gas buses locally, but our most pressing matters are requests for traffic and pedestrian safety improvements. Traffic congestion seems to be growing by the month. We are seeing the backups more than ever. The most difficult and dangerous intersections in District 5, Queens include Woodhaven Boulevard at Union Turnpike, Metropolitan Avenue at Fresh Pond Road, Myrtle Avenue at Wyckoff Avenue, Grand Avenue at 69 Street and both 69 Street and Grand Avenue at the Long Island Expressway Eastbound and Westbound Service Roads. The Eastbound Long Island Expressway is backed up until past 7pm many evenings. As a result of too many drivers selfishly speeding and not giving pedestrians their right-of-way, our Community Board submits dozens of requests each year, asking the NYC Dept. of Transportation to study streets to improve traffic and pedestrian safety. Traffic is named first, primarily due to the growing number of large and smaller motor vehicles traveling far exceeding the number of walkers during most of each hectic day. Having pushed for traffic signals and "All Way Stops" to better safeguard pedestrians and drivers, and succeeded in working with NYCDoT to see needs met, we have almost exhausted locations for these control devices. So, in more recent months, we are evaluating many more requests and study results for "Speed Bumps". Not many years ago, speed bumps were almost only installed in NY City on school blocks. Too many residents are fearful of more vehicles speeding along their residential blocks.
Children playing in the street is an unfortunate distant memory.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The following are or should be priorities of the NYC/DOT: • Allocate adequate resources for Traffic Safety Studies, installation of All-Way Stops, One-Ways, Warning Signage ,Traffic Signals, and Speed Bumps. • Doubling from one to two daily, the number of crews Queens Division of Road Repair sends out to repair serious roadway defects and pot holes. • Having Arterial Highways free of dangerous conditions and cleaned more frequently. • Make Roadway Resurfacing an on-going priority so as to greatly reduce the roads "rated 7 or worse". • Improve Bridge Maintenance so that costly replacement does not become imminent, and Replace Deteriorated Bridge Structures (i.e. Grand Street Bridge Over Newtown Creek). • Provide adequate numbers of Traffic Control Agents (NYPD) assigned to bridge entry points and other congested areas (especially major construction detour routes). • Reducing truck traffic problems throughout our City.
Needs for Transit Services
Ongoing Rehabilitation of our public transit system is critical to the health and vitality of the City of New York. If not for our extensive subway and elevated train line service, air pollution would be much worse and street traffic even more hazardous and gridlocked. Track beds, rails, signal systems, elevated line supports, platforms and stations must be upgraded, rehabilitated and maintained on an ongoing basis. The BMT-M elevated train line, the BMT-L and IND lines are the trains that primarily serve residents of the CB5 area. Specific capital improvement needs include: • Reconstruct DeKalb Avenue, Halsey Street and Jefferson Street Train Stations (BMT-L Line). Only the Halsey Street Train Station is in Queens, but many of our Ridgewood residents either use these stations, or would use them, if they were not so deteriorated and if they were more inviting. An elevator is needed at the busy DeKalb Avenue station. • Improve Myrtle/Wyckoff Transit Hub (to include overdue painting of the M Train Structure to prevent deterioration). There had been a great need for extensive Reconstruction of the BMT-L and BMT-M Train Transit Hub
at Myrtle and Wyckoff Avenues, which had not been improved in decades. The long-awaited station reconstruction project finally began in 2005, and was completed in 2008. Unfortunately, nothing has been done to paint the elevated M Train structure, which is needed to prevent further deterioration and to enhance the M Line and station aesthetics. We have also seen the completion of a project for increased street lighting, a canopy for waiting bus riders and other improvements along Palmetto Street between Myrtle Avenue and St. Nicholas Avenue. This Intermodal Project is 95% complete. This section of Palmetto Street is an integral part of the Myrtle/Wyckoff Transit Hub, where many City buses pick up and drop off commuters, as their first and last stop on the bus route. Other important needs regarding public transportation include: • Replace air-polluting diesel engine buses with new cleaner fuel and/or hybrid buses. • Ongoing upgrades to train tracks, signal systems and switching systems.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/33
DOT
Repair or construct
Reconstruct Sidewalks, Curbs and Pedestrian
Myrtle
new curbs or
Ramps Along Myrtle Avenue, from Fresh Pond
Avenue Fresh
pedestrian ramps
Road to Wyckoff Avenue. Sidewalks, with brick
Pond Road
pavers, along Myrtle Avenue in Ridgewood have
Wyckoff
deteriorated causing tripping hazards. One of
Avenue
the main problems has been tree roots lifting
the bricks and the sidewalk flags. The last major
improvement was in 1984/1985. This section of
Myrtle Avenue receives extensive pedestrian
traffic with people from Ridgewood and nearby
communities shopping on Myrtle Avenue.
4/33
DOT
Rehabilitate bridges
Replace Existing Bridge at Grand Avenue/Grand
Grand Street
Street over Newtown Creek in Maspeth. Due to
47 Street
the deteriorated conditions of this 2-lane bridge,
Gardner
which only worsened in the aftermath of Super
Avenue
Storm Sandy in 2012, and the increased
vehicular traffic over this important bridge,
replacement of the existing bridge over
Newtown Creek in the Maspeth Industrial Area
is needed. The Grand Street Bridge is too
narrow to accommodate trucks and buses in
opposite directions. Truckers and bus drivers
have to wait for traffic to pass in the opposite
direction, posing dangerous conditions and
traffic delays. This vital bridge is deteriorating to
the point where it is closed for repairs
consistently.
5/33
DOT
Improve traffic and
Make Capital Improvements to Improve
Grand Ave
pedestrian safety,
Pedestrian and Vehicle Safety on Grand Avenue
69th Street
including traffic
at 69 Street, at the Grand Ave/LIE Eastbound
LIE Eastbound
calming (Capital)
Service Road, and at the 69 Street/LIE Service
Service Road
Road Intersections in Maspeth. Studies have
been conducted but physical safety
improvements have not been performed to
improve pedestrian and vehicular safety at
several Maspeth intersections. Funding is
needed to physically improve safety conditions
at these critical intersections. Pedestrians are
especially at risk. We look forward to NYC DOT
taking a leadership role to enhance pedestrian
and motorist safety in the Grand Avenue/69
Street area of Maspeth, especially considering
the Mayor's emphasis to greatly reduce traffic
fatalities and serious injury.
11/33
DOT
Reconstruct streets
Extend Street/Roadway Widening Along the
Metropolitan
South Side of Metropolitan Avenue, from
Avenue
Woodhaven Boulevard to Aubrey Avenue in
Aubrey
Glendale. Some roadway widening was done,
Avenue
just west of Woodhaven Boulevard, when Home
Woodhaven
Depot opened on the east side of the Boulevard.
Boulevard
But more needs to be done to reduce the traffic
back-ups, especially considering the commercial
development at nearby Atlas Terminals. The
need is even greater now that several large
chain stores have opened and are prospering on
Metropolitan Avenue, east of Woodhaven Blvd.
In addition, the Metropolitan High School and
an adjacent intermediate school have been in
session for 6 years.
13/33
DOT
Reconstruct streets
Reconstruct South Middle Village Streets (HWQ
708). This long awaited project had been
scheduled for FY 2013, but has been pushed
back to 2022. We must continue to advocate for
the project to be moved up. As a short term
measure, 73rd Place was resurfaced from
Metropolitan Ave to 70 Ave., as were several
other area roadways. This areawide project will
include replacement of water mains, sewer
lines, sidewalks, curbs, street lighting and
roadway reconstruction of all streets in area
bordered by Metropolitan Ave to the north, the
LIRR and Cooper Ave. No. Service Rd to the
South, 80 Street to the east and 73 Place on the
west, not including Metropolitan Ave & 80
Street.
15/33
DOT
Other
Improve the Myrtle Avenue Commercial Strip
Myrtle
transportation
(Fresh Pond Road to 82 Street) in Glendale
Avenue Fresh
infrastructure
Improvements needed include: replacement of
Pond Road 82
requests
damaged curbs and sidewalks, including traffic
Street
facilitation and pedestrian safety upgrades.
17/33
DOT
Reconstruct streets
Reconstruct Wyckoff Avenue, from Flushing
Wyckoff
Avenue to Cooper Avenue in Ridgewood
Avenue
(Queens and Brooklyn) - HWK 876. Wyckoff
Flushing
Avenue, on the Brooklyn-Queens border, is an
Avenue
important neighborhood artery with significant
Cooper
commercial development. This request is for
Avenue
reconstruction of the deteriorated roadway and
sidewalks, installation of new sewer lines and
water mains from Flushing Avenue to Cooper
Avenue in Ridgewood. Part of Wyckoff Avenue is
in the CB5Q area, and much of it is in Brooklyn
Community District 4.
18/33
NYCTA
Other transit
The use of freight rail locally has increased
infrastructure
significantly in recent years, but the
requests
communities of Glendale, Middle Village,
Ridgewood and Maspeth have suffered as a
result. Conditions are compounded considering
that the amount of N.Y. City municipal waste
scheduled for freight transport with the
expansion of the Review Avenue Transfer
Facility in the CB2Q area. This request is for the
replacement or repowering of old locomotives
leased by N.Y. and Atlantic Railway from
MTA/LIRR, which are polluting many
communities. N.Y. State Capital funding has
been allocated to the MTA/LIRR to replace 5
freight hauling locomotives this far, and
additional capital funding is needed to replace
an additional 5 freight locomotives.
19/33
DOT
Reconstruct streets
Reconstruct Fresh Pond Road from Myrtle
Fresh Pond
Avenue to Eliot Avenue, and Provide Traffic
Road Eliot
Facilitation Improvements. Fresh Pond Road is a
Avenue
major north/south artery in the CB5Q area. This
Myrtle
request includes planning/implementation of
Avenue
better traffic facilitation, by cutting into curb
areas ( where possible) to enable trucks and
buses to get to the curb. For the short term, we
had Fresh Pond Road resurfaced this year
thanks to Bureau of Highways/Queens Street
Maintenance efforts.
20/33
DOT
Reconstruct streets
Reconstruct Palmetto Street From St. Nicholas
Palmetto
Avenue to Seneca Avenue, and from Onderdonk
Street Saint
Avenue to Forest Avenue, in Ridgewood.
Nicholas
Palmetto Street serves as an important local
Avenue
artery, especially for numerous bus lines that
Forest
take passengers to and from the Myrtle and
Avenue
Wyckoff Avenues Transit Hub. Engineered
resurfacing at a minimum is needed along
Palmetto Street, from St. Nicholas Avenue to
Seneca Avenue, as the roadway is in disrepair.
Street conditions are complicated by the fact
that the pillars supporting the elevated "M"
Train are located in the bed of the roadway. As
a short term measure, NYC DOT Bureau of
Highways crews strip paved portions of
Palmetto Street during Autumn, 2012.
21/33
NYCTA
Repair or upgrade
Evaluate the Structural Condition of the
M line
subway stations or
Elevated Portions of the "M" Train Line in the
Wyckoff Ave
other transit
CB5Q Area, Perform Repairs, Abate Lead, etc.,
Metropolitan
infrastructure
and Paint the Structure The elevated "M" Train
Avenue
structure is unsightly in our Community Board 5
area, from Wyckoff Avenue to Metropolitan
Avenue. The structure itself needs to be
evaluated for necessary repairs and must be
painted, to prevent physical deterioration and to
reduce the appearance of decay. The "M" train
is our backbone in the NYC public transit system.
This project has begun.
22/33
NYCTA
Other transit
Reconstruct the DeKalb Avenue, Halsey Street
infrastructure
and Jefferson Street Train Stations (BMT- L Line).
requests
Only the Halsey Street Train Station is in
Queens, but many of our Ridgewood residents
either use these stations, or would use them, if
they were not so deteriorated and if they were
more inviting. An elevator is needed at the busy
DeKalb Avenue station. There is significant
development along the Brooklyn/Queens
border, which has brought an increase in train
ridership to these stations. We are informed
that, in 2012, the Halsey St. station had the
largest percentage growth in passengers of any
"L" train stations.
23/33
DOT
Rehabilitate bridges
Reconstruct and Widen the East Sidewalk of
80 street
80th Street, on the 80th Street Bridge, Over the
Cooper
LIRR in Glendale. Pedestrians have to walk a
Avenue 78
narrow sidewalk to get to and from the new
Avenue
Atlas Park Shopping Center. The roadway over
the 80th Street Bridge in Glendale should be
wide enough to allow sidewalk expansion, and
reduce dangerous conditions for pedestrians.
26/33
DOT
Rehabilitate bridges
Reconstruct the LIRR and 71st Avenue Bridge
Cooper
Abutments Above the Cooper Avenue
Avenue
Underpass; and Paint the LIRR Bridge -
Reconstruction of the Cooper Avenue Underpass
Retaining Walls has been completed (RWQ005),
at a cost of more than $6 million. Unfortunately,
this retaining wall project did not include
reconstruction of the bridge abutment,or
painting the LIRR bridge. There is a city
vehicular bridge and an LIRR Montauk Line
Bridge above Cooper Avenue, in the area of 76
Street, in Glendale. The LIRR bridge is an
eyesore and needs to be repainted.
28/33
DOT
Reconstruct streets
Reconstruct 75th Street from Eliot Avenue to
Juniper Boulevard North, in Middle Village. Although the bureau of Highways crews have resurfaced 75th Street in the past 9 years, it is quite evident that this street needs reconstruction. Due to extensive roadway and sidewalk settlement, resurfacing is but a short- term solution.The portion of the roadway adjacent to the Learning Tree Day Care Center is higher then the sidewalk, causing unhealthy water accumulation.
75th Street
Eliot Avenue Juniper Boulevard North
32/33
DOT
Other transportation infrastructure requests
Provide Decorative Street Lighting and Restore Deteriorated Curbing Along Fred Haller's Union Turnpike Mall, (Myrtle Avenue to Woodhaven Boulevard). Union Turnpike is a wide residential roadway, and is one of the gateways into CB5Q. Improvements needed include new curbing, tree root pruning, and new decorative street lighting. This project has been partially funded, and new pavement has been installed along the center median.
Union Turnpike Woodhaven Boulevard Myrtle Avenue
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
10/25
DOT
Other expense
Provide Sufficient Personnel for Traffic Safety
traffic
Inspections, Sign Installations, Pavement
improvements
Markings and Sign Manufacturing. Because of
requests
increasingly dangerous local traffic conditions,
there has been a need during the past 10 years
for more traffic safety studies, traffic signals, All
Way Stop installations, Speed Bump
installations, One Way Conversions, and No
Parking designations to daylight intersections.
Additional traffic device maintenance crews are
needed for signage installation, pavement
markings and sign manufacturing. Vehicles in
good repair, including utility trucks, are needed
to support current and projected staffing levels.
11/25 DOT Other expense
traffic improvements requests
Fund Additional Street Maintenance for Queens Roadways and Curbs In order to have roadways along commercial strips and in residential communities repaired before dangerous conditions arise, the following requests need to be funded: provide one crew for cave-in repair; 2 crews for pothole repairs; 1 crew for concrete repair; 2 crews for curb replacement; and 1 crew for miscellaneous maintenance (ponding conditions, etc.) daily for Queens. Lawsuits against the City might be greatly reduced if repairs could be done more promptly.
image
24/25 DOT Other expense
traffic improvements requests
Improve Arterial Highway Cleaning and Maintenance. The conditions of arterial highways and their cleanliness should be a priority for the City and State of New York. Maintenance workers citywide are needed to repair and resurface roadbeds, repair and replace dividers, clean litter & debris, attend to growth, and eliminate graffiti in a timely manner.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 5
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
In an increasingly crowded city, where the great majority of those less affluent or economically struggling do not have access to much outdoor space, it is very important to have public parks that are in good physical condition, that are well maintained, inviting and that are respected by users. In the Community Board 5, Queens area, the Queens portion of Highland Park and Juniper Valley Park are our largest parks. The Ridgewood Reservoir, which is actually located in Glendale, is a beautiful natural oasis within Highland Park. The reservoir, which is no longer operating to provide drinking water, is more than 50 acres in size, and the closest space to a nature preserve that we have had anytime recently. Brooklyn Community Board 5, where approximately 20% of the Ridgewood Reservoir is located, have been very supportive of this beautiful site becoming the equivalent of a nature preserve.
Community Board 5, Queens has been avidly advocating for the Ridgewood Reservoir to receive Wetlands Status, which was accomplished in 2019. Juniper Valley Park, located in Middle Village, is more than 50 acres in size. This beautiful park contains 7 baseball fields (some of which are also used for softball play), 2 playgrounds, a large soccer field/football field surrounded by a running track, a roller hockey rink, bocce courts, basketball courts, a very active handball courts area, an asphalt softball field and beautiful green space. Juniper Park is utilized by youth and residents of Middle Village and numerous other communities. Francis J. Principe Park (formerly Maurice Park), Reiff Park and Frontera Park are the city parks primarily serving Maspeth residents. Ridgewood Parks include a portion of Mafera Park, Grover Cleveland Park, Rosemary's Playground, Benninger Park and Starr Playground. Glendale Parks include a portion of Mafera Park, Evergreen Park, Vito Maranzano's Glendale Playground, Dry Harbor Playground and Pinnocchio Playground. In addition to Juniper Valley Park, the Middle Village Community also contains Middle Village Playground. We are very supportive of important capital projects for parks, and realize that parks safety and good parks maintenance are critically important for promoting healthy recreational activity, relaxation and community civility. Maintenance requires adequate personnel, and equipment that is in excellent condition. The following are important needs related to parks maintenance in Community District 5, Queens: - Having substantially more than 9 maintenance staff, including supervisors for all of the parks in Q5. - A gator, with a plow attachment and ball field grooming attachments (meeting this need is long overdue) - A new Crew Cab is needed (double cabin pick-up truck), with plow attachment and motorized lift gate - A new Packer (Garbage Truck) is needed, as Q5 is a large district and the existing packer is too often in for repairs and is shared with Q6 Parks.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The condition of community parks and respect for parks and playgrounds is a vital need in a crowded city, where so many do not have access to outdoor space. In recent years, more parks are being reconstructed or upgraded, but many parks improvements have been capital budget priorities for many years prior to physical improvements beginning. Ongoing park reconstruction and renovation projects are needed to address deteriorated conditions, and to make parks more inviting to good residents. Parks are especially important to the positive development of children and teenagers physically, and, at least as important socially and psychologically. Street tree plantings are needed to reduce air pollution, street heat and greatly beautify city streets and parks properties. Good trees maintenance is vital to prevent dangerous conditions, and to keep trees healthy. Maintenance of N.Y. City Parks should be more of a priority. Maintenance includes personnel and equipment. We need substantially more than 10 Parks Dept. Workers, including supervisors, to care for the many parks in Q5. Q5 Parks do not even have a gator. A new Crew Cab is needed and a new Packer/Garbage Truck is long overdue for parks in District 5, Queens.
Needs for Cultural Services
Although in District 5, Queens, we have few cultural facilities other than the Onderdonk House on Flushing Avenue, in Ridgewood, the great majority of us realize the importance of quality culture in an age when there are so many negative influences in music, movies and other so called modern culture mediums.
Needs for Library Services
Local libraries are an excellent source of learning and provide important information on a extensive range of subjects. Every effort should be made to upgrade libraries physically, to market the good that libraries have to offer (especially for children and teens), and to promote learning and research outside of the often regular, boring school day setting. As a society, we need to make learning much more cool or hot with young people, since there are too many entertainment distractions. These local libraries, more formally known as branch libraries, are important for providing access to the gift of reading related to many interesting subjects, and are also the scene for many good programs for children, youth and adults. Computers at libraries are well used by many who can not afford to have a computer at home. Having branch libraries open at least 6 days a week is a priority. There are 4 branch libraries located within the boundaries of Community District 5, Queens. The Ridgewood Library is located on Forest Avenue at Madison Street. The Maspeth Library is located on Grand Avenue, along the main shopping strip. The Middle Village Library is located on Metropolitan Avenue, just west of the main shopping strip. The Glendale Library, which is funded for extensive capital renovations, is located on 73 Place at Myrtle Avenue. Community Board 5, Queens has a long history of successfully advocating for library improvements.
Needs for Community Boards
Staff members at Community Boards, with the possible exception of District Managers, are often struggling economically. Many of them have worked diligently for more than a decade toward the stabilization of communities throughout NY City. I would like to see community boards receive a budget increase to give well deserved merit increases to deserving Board staff, many of who earn less than $50,000. for full time work and then some. Regular funding increases are needed to enable Community Board to purchase newer computers, photocopiers, printers, and supplies. We are grateful that City Council Speaker Corey Johnson, with the support of other council members, has successfully pushed for an increase of more than $42,000. in the budget of each Community Board for FY 2020.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/33
DPR
Reconstruct or
Improve the Children's Play Area, and
upgrade a park or
Reconstruct Softball Field Area at Rosemary's
amenity (i.e.
Playground, in Ridgewood. The asphalt softball
playground, outdoor
field in Rosemary's Playground, located on
athletic field)
Fairview Avenue between Woodbine Street and
Madison Street, has not been resurfaced in
many years. Funding is requested to resurface
the asphalt softball field area, considering the
possibility of safe synthetic surface installation
to accommodate several sports. The children's
play area is somewhat deteriorated, but
reconstruction is underway.This important park
property is across the street from IS 93.
7/33
DPR
Reconstruct or
Rehabilitate Ridgewood Reservoir - Phase II -
upgrade a park or
and the Surrounding Area, including Portions of
amenity (i.e.
Highland Park. This request is for the
playground, outdoor
rehabilitation of the old pump house or gate
athletic field)
house, or construction of a new building to
serve as an Environmental Center with
bathrooms at the Ridgewood Reservoir site. This
reservoir is the closest place to a nature
preserve anywhere near the Board 5 Queens
area. We are also requesting that funding be
allocated to reconstruct ball fields in Highland
Park, as Board 5 Queens has opposed
development of reservoir basins for ball fields or
other active recreational uses. Under the Phase
1 Project, new lighting, fencing and pathways
around the Reservoir were completed. Residents
are now enjoying this gem of nature, after
decades of decay.
9/33
DPR
Plant new street
Provide New Street Tree Plantings and Provide
trees
Funding for Stump Removals, Planting of
Replacement Trees, and Street Tree Removals.
The tornado that devasted portions of the CB5Q
area on 9/16/2010 resulted in the loss of several
hundred trees. Ongoing funding is needed for
new street tree plantings, for the replacement
of dead trees and the removal of street tree
stumps. Hurricane Irene uprooted many
additional trees. CB5Q has, for decades, pushed
for new street tree plantings. Street trees
reduce air pollution, asthma and other
respiratory problems, and beautify city streets.
10/33
DPR
Reconstruct or
Provide Replacement of the Synthetic Turf
upgrade a park or
Soccer & Football Field, and the Running Track,
amenity (i.e.
at the West End of Juniper Valley Park in Middle
playground, outdoor
Village. Both the turf soccer/football field and
athletic field)
the running track at the west end of Juniper
Valley Park are past their 10 year useful life, and
need to be replaced. The turf field is more
deteriorated than the running track, and both
the field and the running track get extensive use
by residents from numerous communities.
Soccer has become extremely popular with
children, teens and young adults. The Blau
Weiss Gottscheer Soccer group, and others,
need a new playing surface for safer play.
12/33
DPR
Provide a new, or
Construct an Athletic Field at the Planned NYC
58-26 47
new expansion to, a
DEP Newtown Creek Aeration Facility Property.
Street
building in a park
The NYC DEP has had an aeration facility built at
58-26 47 Street, in Maspeth, Queens, to
improve Newtown Creek water quality. Local
soccer advocates request that the land owned
by N.Y. City, adjacent to the planned aeration
facility, be developed as an athletic field
because there is a shortage of sites where
soccer can be safely played.
14/33
DPR
Reconstruct or
Reconstruct Dry Harbor Playground - Phase II, to
upgrade a park or
Also Include Nearby Tunnel and Pathways Into
amenity (i.e.
Forest Park. This City park is located on Myrtle
playground, outdoor
Avenue at 80 Street, and is the only park-
athletic field)
playground for eastern Glendale. This Phase II
request is for the rehabilitation of the asphalt
softball field, including possible provision of
recreational lighting; the park house/
bathrooms rehabilitation;and improved fencing
around the children's playground. The
reconstruction of the children's playground was
completed in Phase I. Funding is also needed to
rehabilitate the tunnel and bicycle path under
the Jackie Robinson Parkway and the
connecting bicycle/golf cart pathway to its
easterly connecting point of Forest Park Drive,
including drainage, signage and lighting
improvements.
24/33
DPR
Provide a new, or
Establish a Community/Recreation Center at a
new expansion to, a
Site in Maspeth. The communities comprising
building in a park
District 5, Queens do not have a large public
space, other than schools, for recreation and
community activities. This request is to build a
new facility in Maspeth, preferably on a vacant
parcel of land.
25/33
DPR
Reconstruct or
Reconstruct Evergreen Park-Playground in
Saint Felix
upgrade a park or
Glendale-Phase III. Located on St. Felix Avenue,
Avenue
amenity (i.e.
between 60 Place and 60 Street in Glendale,
playground, outdoor
construction has been completed for the portion
athletic field)
of the children's playground that has not been
improved in decades. A Phase III project is
needed to rehabilitate the asphalt softball field,
and consideration should be seriously given to
upgrading the ball field with a safe synthetic
surface, which could be used for several sports.
Soccer has become extremely popular, and
organizations like the Blau Weiss Gottscheer
Soccer group have numerous teams that have
to travel far to play outdoor soccer. This park is
located adjacent to P.S. 68.
30/33
DPR
Reconstruct or
Provide Funding for the Establishment of a Dog
upgrade a park or
Run in District 5, Queens. Residents have
amenity (i.e.
advocated for the establishment of a more
playground, outdoor
permanent dog run in Juniper Valley Park in
athletic field)
Middle Village. Recent cost estimates are
projected to be somewhere in the range of
$750,000. It is questionable whether there is
sufficient open space to accommodate a dog
run inside Juniper Valley Park since there are so
many competing uses there including seven (7)
ball fields, a running track, two (2) children's
playgrounds, a football/soccer field, bocce,
tennis and basketball courts, and a roller hockey
rink, in addition to landscaped areas. The CB5Q
Parks Committee has looked at possibilities for a
dog run in this park and at other locations.
31/33
DPR
Provide a new, or
Provide Toilet Facility in Area of Juniper Valley
new expansion to, a
Park Bordered by 80th St, Dry Harbor Rd,
building in a park
Juniper Blvd South and Juniper Blvd North This
request would primarily benefit older people,
who have difficulty walking quickly to the
comfort station further west in this large park,
when they need to use a restroom.
33/33
DCLA
Renovate or
Provide Funding for the Historic Restoration of
upgrade an existing
St. Saviour's Church. Thanks to the efforts of
cultural facility
community activists and elected officials, St.
Savior's Church has been carefully taken apart
and placed in storage. Funding is requested to
reassemble this church at a new location,
possibly on the grounds of All Faiths Cemetery
in Middle Village, so that it can serve as a
community cultural center.
CS QL Create a new, or renovate or upgrade an existing public library
Rehabilitate the Glendale Branch Library. This local library project includes the need for an elevator or other means of handicapped access; new windows, new boiler and air conditioning system, new doors, faade restoration including pointing of bricks, reconfiguration of the adult and teen reading rooms on the first floor and mezzanine, and restoration of the Tuscan garden and outdoor reading room. A Phase I project is funded to install an elevator, provide some other upgrades to the front entry area on 73 Place, and for renovating the main floor section of the library. This Phase I Project has finally begun. A Phase II project is requested to point the brick building and for other needed improvements not covered under Phase I.
78-60 73
Place
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
9/25 DPR Forestry services,
including street tree maintenance
Allocate Funds for the Operation and Enhancement of the Division of Forestry in Queens. There are extensive needs for pruning of trees on city streets and in city parks, which are too numerous for the Division of Forestry to keep up with. There are currently more than 10,000 street tree stumps that need to be removed in Queens. The following budget allocations are needed to address these conditions, and the need to remove dead trees and limbs on an emergency basis: $4.5 Million for county-wide pruning contract; $3.5 Million for removal of tree stumps in Queens; $2 million for removal of dead trees and limbs. Trees are aging, and risks of falling limbs and dead trees pose dangerous conditions.
image
12/25 QL Extend library hours or expand and enhance library programs
Provide Six-Day-a-Week Service at Local Libraries. Increased educational demands on students, the fact that many families cannot afford the internet or up-to-date computers and increasing immigrant populations necessitate that the great majority of local/branch libraries be open 6-days a week. Having Libraries open on Saturdays is especially important to all our residents!
14/25 DPR Provide better park
maintenance
Assign More Personnel and Equipment for Maintenance of Parks in District 5, Queens. More park workers are needed to meet work requirements for the cleaning and maintenance of the 229.7 acres of parks in CD5Q. Currently, there are only 10 Parks Dept. maintenance staff, including supervisors, assigned for this massive parkland. Skilled maintenance workers (there are only 2 for all of Queens Districts 5, 9, 10 & Forest Park) should be funded year-round.
Reseeding, aerating and fertilizing ball fields and grassy areas need to be priorities so that large capital expenditures are not wasted.
Funding is also needed to hire more seasonal workers. Long standing equipment needs include a new Gator, a new Crew Cab and a new Packer.
image
21/25 DPR Forestry services,
including street tree maintenance
Hire Forestry Personnel. With previous cuts, the Forestry Division had been decimated. At one point, there were only 4 climbers and pruners to care for more than 327,000 street trees in Queens. Queens needs at least 55 climbers and pruners to remove and prune trees posing dangerous conditions.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/33
DEP
Inspect sanitary
Redesign and Reconstruct Sewer System in
sewer on specific
Portions of the CB5Q Area. After heavy rains,
street segment and
CB5Q has received complaints of extensive
repair or replace as
street flooding and basement sewer backups in
needed (Capital)
parts of our communities. Aged sewer lines
likely need to be replaced, enlarged or realigned
to reduce flooding and resulting property
damage, especially along 77 Avenue and 78
Avenue from 76 Street to 88 Street, in Glendale.
2/33
DEP
Inspect sanitary
Reconstruct Deteriorated Catch Basins and
sewer on specific
Construct New Catch Basins. There is an
street segment and
increasing need to replace deteriorated brick
repair or replace as
catch basins with pre-cast concrete structures.
needed (Capital)
We have had many catch basins with adjacent
cave-in conditions, and/or where the structure is
sunken. There is an ongoing need for new catch
basins to reduce street flooding during
rainstorms.
3/33
DOT
Repair or construct
Reconstruct Sidewalks, Curbs and Pedestrian
Myrtle
new curbs or
Ramps Along Myrtle Avenue, from Fresh Pond
Avenue Fresh
pedestrian ramps
Road to Wyckoff Avenue. Sidewalks, with brick
Pond Road
pavers, along Myrtle Avenue in Ridgewood have
Wyckoff
deteriorated causing tripping hazards. One of
Avenue
the main problems has been tree roots lifting
the bricks and the sidewalk flags. The last major
improvement was in 1984/1985. This section of
Myrtle Avenue receives extensive pedestrian
traffic with people from Ridgewood and nearby
communities shopping on Myrtle Avenue.
4/33
DOT
Rehabilitate bridges
Replace Existing Bridge at Grand Avenue/Grand
Grand Street
Street over Newtown Creek in Maspeth. Due to
47 Street
the deteriorated conditions of this 2-lane bridge,
Gardner
which only worsened in the aftermath of Super
Avenue
Storm Sandy in 2012, and the increased
vehicular traffic over this important bridge,
replacement of the existing bridge over
Newtown Creek in the Maspeth Industrial Area
is needed. The Grand Street Bridge is too
narrow to accommodate trucks and buses in
opposite directions. Truckers and bus drivers
have to wait for traffic to pass in the opposite
direction, posing dangerous conditions and
traffic delays. This vital bridge is deteriorating to
the point where it is closed for repairs
consistently.
5/33
DOT
Improve traffic and
Make Capital Improvements to Improve
Grand Ave
pedestrian safety,
Pedestrian and Vehicle Safety on Grand Avenue
69th Street
including traffic
at 69 Street, at the Grand Ave/LIE Eastbound
LIE Eastbound
calming (Capital)
Service Road, and at the 69 Street/LIE Service
Service Road
Road Intersections in Maspeth. Studies have
been conducted but physical safety
improvements have not been performed to
improve pedestrian and vehicular safety at
several Maspeth intersections. Funding is
needed to physically improve safety conditions
at these critical intersections. Pedestrians are
especially at risk. We look forward to NYC DOT
taking a leadership role to enhance pedestrian
and motorist safety in the Grand Avenue/69
Street area of Maspeth, especially considering
the Mayor's emphasis to greatly reduce traffic
fatalities and serious injury.
6/33
DPR
Reconstruct or
Improve the Children's Play Area, and
upgrade a park or
Reconstruct Softball Field Area at Rosemary's
amenity (i.e.
Playground, in Ridgewood. The asphalt softball
playground, outdoor
field in Rosemary's Playground, located on
athletic field)
Fairview Avenue between Woodbine Street and
Madison Street, has not been resurfaced in
many years. Funding is requested to resurface
the asphalt softball field area, considering the
possibility of safe synthetic surface installation
to accommodate several sports. The children's
play area is somewhat deteriorated, but
reconstruction is underway.This important park
property is across the street from IS 93.
7/33 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
Rehabilitate Ridgewood Reservoir - Phase II - and the Surrounding Area, including Portions of Highland Park. This request is for the rehabilitation of the old pump house or gate house, or construction of a new building to serve as an Environmental Center with bathrooms at the Ridgewood Reservoir site. This reservoir is the closest place to a nature preserve anywhere near the Board 5 Queens area. We are also requesting that funding be allocated to reconstruct ball fields in Highland Park, as Board 5 Queens has opposed development of reservoir basins for ball fields or other active recreational uses. Under the Phase 1 Project, new lighting, fencing and pathways around the Reservoir were completed. Residents are now enjoying this gem of nature, after decades of decay.
image
8/33 SCA Provide a new or
expand an existing high school
Construct New School Space, Where Needed, in the Community Board 5, Queens Area, Including a New High School in Queens. Construction of additional classroom space for children and teenagers, residing in the CB5Q area, has been essential to relieve school overcrowding. The CB5Q area is part of Community School District 24, which is often the most overcrowded school district in N.Y. City. There are a shortage of opportunities in our area and in Queens to attend a good high school.
image
9/33 DPR Plant new street
trees
Provide New Street Tree Plantings and Provide Funding for Stump Removals, Planting of Replacement Trees, and Street Tree Removals. The tornado that devasted portions of the CB5Q area on 9/16/2010 resulted in the loss of several hundred trees. Ongoing funding is needed for new street tree plantings, for the replacement of dead trees and the removal of street tree stumps. Hurricane Irene uprooted many additional trees. CB5Q has, for decades, pushed for new street tree plantings. Street trees reduce air pollution, asthma and other respiratory problems, and beautify city streets.
image
10/33
DPR
Reconstruct or
Provide Replacement of the Synthetic Turf
upgrade a park or
Soccer & Football Field, and the Running Track,
amenity (i.e.
at the West End of Juniper Valley Park in Middle
playground, outdoor
Village. Both the turf soccer/football field and
athletic field)
the running track at the west end of Juniper
Valley Park are past their 10 year useful life, and
need to be replaced. The turf field is more
deteriorated than the running track, and both
the field and the running track get extensive use
by residents from numerous communities.
Soccer has become extremely popular with
children, teens and young adults. The Blau
Weiss Gottscheer Soccer group, and others,
need a new playing surface for safer play.
11/33
DOT
Reconstruct streets
Extend Street/Roadway Widening Along the
Metropolitan
South Side of Metropolitan Avenue, from
Avenue
Woodhaven Boulevard to Aubrey Avenue in
Aubrey
Glendale. Some roadway widening was done,
Avenue
just west of Woodhaven Boulevard, when Home
Woodhaven
Depot opened on the east side of the Boulevard.
Boulevard
But more needs to be done to reduce the traffic
back-ups, especially considering the commercial
development at nearby Atlas Terminals. The
need is even greater now that several large
chain stores have opened and are prospering on
Metropolitan Avenue, east of Woodhaven Blvd.
In addition, the Metropolitan High School and
an adjacent intermediate school have been in
session for 6 years.
12/33
DPR
Provide a new, or
Construct an Athletic Field at the Planned NYC
58-26 47
new expansion to, a
DEP Newtown Creek Aeration Facility Property.
Street
building in a park
The NYC DEP has had an aeration facility built at
58-26 47 Street, in Maspeth, Queens, to
improve Newtown Creek water quality. Local
soccer advocates request that the land owned
by N.Y. City, adjacent to the planned aeration
facility, be developed as an athletic field
because there is a shortage of sites where
soccer can be safely played.
13/33
DOT
Reconstruct streets
Reconstruct South Middle Village Streets (HWQ
708). This long awaited project had been
scheduled for FY 2013, but has been pushed
back to 2022. We must continue to advocate for
the project to be moved up. As a short term
measure, 73rd Place was resurfaced from
Metropolitan Ave to 70 Ave., as were several
other area roadways. This areawide project will
include replacement of water mains, sewer
lines, sidewalks, curbs, street lighting and
roadway reconstruction of all streets in area
bordered by Metropolitan Ave to the north, the
LIRR and Cooper Ave. No. Service Rd to the
South, 80 Street to the east and 73 Place on the
west, not including Metropolitan Ave & 80
Street.
14/33
DPR
Reconstruct or
Reconstruct Dry Harbor Playground - Phase II, to
upgrade a park or
Also Include Nearby Tunnel and Pathways Into
amenity (i.e.
Forest Park. This City park is located on Myrtle
playground, outdoor
Avenue at 80 Street, and is the only park-
athletic field)
playground for eastern Glendale. This Phase II
request is for the rehabilitation of the asphalt
softball field, including possible provision of
recreational lighting; the park house/
bathrooms rehabilitation;and improved fencing
around the children's playground. The
reconstruction of the children's playground was
completed in Phase I. Funding is also needed to
rehabilitate the tunnel and bicycle path under
the Jackie Robinson Parkway and the
connecting bicycle/golf cart pathway to its
easterly connecting point of Forest Park Drive,
including drainage, signage and lighting
improvements.
15/33
DOT
Other
Improve the Myrtle Avenue Commercial Strip
Myrtle
transportation
(Fresh Pond Road to 82 Street) in Glendale
Avenue Fresh
infrastructure
Improvements needed include: replacement of
Pond Road 82
requests
damaged curbs and sidewalks, including traffic
Street
facilitation and pedestrian safety upgrades.
16/33
DEP
Inspect sanitary
Continue a Comprehensive Study of the Sewer
sewer on specific
System in the Community Board 5Q Area and
street segment and
Throughout Queens County, Considering
repair or replace as
Flooding Problems and Anticipated Future
needed (Capital)
Growth. A thorough sewer system study,
including analysis of flow patterns to treatment
plants, needs to proceed and be accomplished in
the very near future so that street flooding and
basement sewer backups can be greatly
reduced. The sewer system links our
communities with those of other community
districts throughout Queens. Solutions to
flooding are especially needed in the area of
Cooper Avenue (btw 74 St and 78 St), and along
77 Avenue and 78 Avenue (btw 80 St and 88 St).
17/33
DOT
Reconstruct streets
Reconstruct Wyckoff Avenue, from Flushing
Wyckoff
Avenue to Cooper Avenue in Ridgewood
Avenue
(Queens and Brooklyn) - HWK 876. Wyckoff
Flushing
Avenue, on the Brooklyn-Queens border, is an
Avenue
important neighborhood artery with significant
Cooper
commercial development. This request is for
Avenue
reconstruction of the deteriorated roadway and
sidewalks, installation of new sewer lines and
water mains from Flushing Avenue to Cooper
Avenue in Ridgewood. Part of Wyckoff Avenue is
in the CB5Q area, and much of it is in Brooklyn
Community District 4.
18/33
NYCTA
Other transit
The use of freight rail locally has increased
infrastructure
significantly in recent years, but the
requests
communities of Glendale, Middle Village,
Ridgewood and Maspeth have suffered as a
result. Conditions are compounded considering
that the amount of N.Y. City municipal waste
scheduled for freight transport with the
expansion of the Review Avenue Transfer
Facility in the CB2Q area. This request is for the
replacement or repowering of old locomotives
leased by N.Y. and Atlantic Railway from
MTA/LIRR, which are polluting many
communities. N.Y. State Capital funding has
been allocated to the MTA/LIRR to replace 5
freight hauling locomotives this far, and
additional capital funding is needed to replace
an additional 5 freight locomotives.
19/33
DOT
Reconstruct streets
Reconstruct Fresh Pond Road from Myrtle
Fresh Pond
Avenue to Eliot Avenue, and Provide Traffic
Road Eliot
Facilitation Improvements. Fresh Pond Road is a
Avenue
major north/south artery in the CB5Q area. This
Myrtle
request includes planning/implementation of
Avenue
better traffic facilitation, by cutting into curb
areas ( where possible) to enable trucks and
buses to get to the curb. For the short term, we
had Fresh Pond Road resurfaced this year
thanks to Bureau of Highways/Queens Street
Maintenance efforts.
20/33
DOT
Reconstruct streets
Reconstruct Palmetto Street From St. Nicholas
Palmetto
Avenue to Seneca Avenue, and from Onderdonk
Street Saint
Avenue to Forest Avenue, in Ridgewood.
Nicholas
Palmetto Street serves as an important local
Avenue
artery, especially for numerous bus lines that
Forest
take passengers to and from the Myrtle and
Avenue
Wyckoff Avenues Transit Hub. Engineered
resurfacing at a minimum is needed along
Palmetto Street, from St. Nicholas Avenue to
Seneca Avenue, as the roadway is in disrepair.
Street conditions are complicated by the fact
that the pillars supporting the elevated "M"
Train are located in the bed of the roadway. As
a short term measure, NYC DOT Bureau of
Highways crews strip paved portions of
Palmetto Street during Autumn, 2012.
21/33
NYCTA
Repair or upgrade
Evaluate the Structural Condition of the
M line
subway stations or
Elevated Portions of the "M" Train Line in the
Wyckoff Ave
other transit
CB5Q Area, Perform Repairs, Abate Lead, etc.,
Metropolitan
infrastructure
and Paint the Structure The elevated "M" Train
Avenue
structure is unsightly in our Community Board 5
area, from Wyckoff Avenue to Metropolitan
Avenue. The structure itself needs to be
evaluated for necessary repairs and must be
painted, to prevent physical deterioration and to
reduce the appearance of decay. The "M" train
is our backbone in the NYC public transit system.
This project has begun.
22/33
NYCTA
Other transit
Reconstruct the DeKalb Avenue, Halsey Street
infrastructure
and Jefferson Street Train Stations (BMT- L Line).
requests
Only the Halsey Street Train Station is in
Queens, but many of our Ridgewood residents
either use these stations, or would use them, if
they were not so deteriorated and if they were
more inviting. An elevator is needed at the busy
DeKalb Avenue station. There is significant
development along the Brooklyn/Queens
border, which has brought an increase in train
ridership to these stations. We are informed
that, in 2012, the Halsey St. station had the
largest percentage growth in passengers of any
"L" train stations.
23/33
DOT
Rehabilitate bridges
Reconstruct and Widen the East Sidewalk of
80 street
80th Street, on the 80th Street Bridge, Over the
Cooper
LIRR in Glendale. Pedestrians have to walk a
Avenue 78
narrow sidewalk to get to and from the new
Avenue
Atlas Park Shopping Center. The roadway over
the 80th Street Bridge in Glendale should be
wide enough to allow sidewalk expansion, and
reduce dangerous conditions for pedestrians.
24/33
DPR
Provide a new, or
Establish a Community/Recreation Center at a
new expansion to, a
Site in Maspeth. The communities comprising
building in a park
District 5, Queens do not have a large public
space, other than schools, for recreation and
community activities. This request is to build a
new facility in Maspeth, preferably on a vacant
parcel of land.
25/33
DPR
Reconstruct or
Reconstruct Evergreen Park-Playground in
Saint Felix
upgrade a park or
Glendale-Phase III. Located on St. Felix Avenue,
Avenue
amenity (i.e.
between 60 Place and 60 Street in Glendale,
playground, outdoor
construction has been completed for the portion
athletic field)
of the children's playground that has not been
improved in decades. A Phase III project is
needed to rehabilitate the asphalt softball field,
and consideration should be seriously given to
upgrading the ball field with a safe synthetic
surface, which could be used for several sports.
Soccer has become extremely popular, and
organizations like the Blau Weiss Gottscheer
Soccer group have numerous teams that have
to travel far to play outdoor soccer. This park is
located adjacent to P.S. 68.
26/33
DOT
Rehabilitate bridges
Reconstruct the LIRR and 71st Avenue Bridge
Cooper
Abutments Above the Cooper Avenue
Avenue
Underpass; and Paint the LIRR Bridge -
Reconstruction of the Cooper Avenue Underpass
Retaining Walls has been completed (RWQ005),
at a cost of more than $6 million. Unfortunately,
this retaining wall project did not include
reconstruction of the bridge abutment,or
painting the LIRR bridge. There is a city
vehicular bridge and an LIRR Montauk Line
Bridge above Cooper Avenue, in the area of 76
Street, in Glendale. The LIRR bridge is an
eyesore and needs to be repainted.
27/33
NYPD
Renovate or
Rehabilitate the 104th Police Precinct Station
64-02 Catalpa
upgrade existing
House Interior and Exterior The 104th Police
Avenue
precinct houses
Precinct station house is an old building and
improvements needed include: painting the
entire precinct, possible roof upgrades as the
roof may be 10 years old,replacement of the
flagpole and light fixture at the roof level,
replacement of the 3rd floor locker room floor
tiles and restroom toilets, and ceiling
replacement in parts of the 2nd Floor. Ongoing
plumbing and electrical upgrades are also likely
needed.
28/33
DOT
Reconstruct streets
Reconstruct 75th Street from Eliot Avenue to
75th Street
Juniper Boulevard North, in Middle Village.
Eliot Avenue
Although the bureau of Highways crews have
Juniper
resurfaced 75th Street in the past 9 years, it is
Boulevard
quite evident that this street needs
North
reconstruction. Due to extensive roadway and
sidewalk settlement, resurfacing is but a short-
term solution.The portion of the roadway
adjacent to the Learning Tree Day Care Center is
higher then the sidewalk, causing unhealthy
water accumulation.
29/33
SCA
Renovate or
Provide a New Elevator for the I.S. 93-Q Main
66-56 Forest
upgrade a middle or
School Building, located at 66-56 Forest Avenue
Avenue
intermediate school
in Ridgewood. There is no elevator in the main
building of I.S. 93-Q. The building is 5 stories
high. There are reportedly 125 documented
cases of students with asthma in attendance at
this school. There is no access for students, or
their guardians, who are physically challenged.
30/33
DPR
Reconstruct or
Provide Funding for the Establishment of a Dog
upgrade a park or
Run in District 5, Queens. Residents have
amenity (i.e.
advocated for the establishment of a more
playground, outdoor
permanent dog run in Juniper Valley Park in
athletic field)
Middle Village. Recent cost estimates are
projected to be somewhere in the range of
$750,000. It is questionable whether there is
sufficient open space to accommodate a dog
run inside Juniper Valley Park since there are so
many competing uses there including seven (7)
ball fields, a running track, two (2) children's
playgrounds, a football/soccer field, bocce,
tennis and basketball courts, and a roller hockey
rink, in addition to landscaped areas. The CB5Q
Parks Committee has looked at possibilities for a
dog run in this park and at other locations.
31/33
DPR
Provide a new, or
Provide Toilet Facility in Area of Juniper Valley
new expansion to, a
Park Bordered by 80th St, Dry Harbor Rd,
building in a park
Juniper Blvd South and Juniper Blvd North This
request would primarily benefit older people,
who have difficulty walking quickly to the
comfort station further west in this large park,
when they need to use a restroom.
32/33
DOT
Other
Provide Decorative Street Lighting and Restore
Union
transportation
Deteriorated Curbing Along Fred Haller's Union
Turnpike
infrastructure
Turnpike Mall, (Myrtle Avenue to Woodhaven
Woodhaven
requests
Boulevard). Union Turnpike is a wide residential
Boulevard
roadway, and is one of the gateways into CB5Q.
Myrtle
Improvements needed include new curbing, tree
Avenue
root pruning, and new decorative street
lighting. This project has been partially funded,
and new pavement has been installed along the
center median.
33/33
DCLA
Renovate or
Provide Funding for the Historic Restoration of
upgrade an existing
St. Saviour's Church. Thanks to the efforts of
cultural facility
community activists and elected officials, St.
Savior's Church has been carefully taken apart
and placed in storage. Funding is requested to
reassemble this church at a new location,
possibly on the grounds of All Faiths Cemetery
in Middle Village, so that it can serve as a
community cultural center.
CS QL Create a new, or renovate or upgrade an existing public library
Rehabilitate the Glendale Branch Library. This local library project includes the need for an elevator or other means of handicapped access; new windows, new boiler and air conditioning system, new doors, faade restoration including pointing of bricks, reconfiguration of the adult and teen reading rooms on the first floor and mezzanine, and restoration of the Tuscan garden and outdoor reading room. A Phase I project is funded to install an elevator, provide some other upgrades to the front entry area on 73 Place, and for renovating the main floor section of the library. This Phase I Project has finally begun. A Phase II project is requested to point the brick building and for other needed improvements not covered under Phase I.
78-60 73
Place
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
NYPD
Assign additional
Assign Additional Personnel for the 104th Police
uniformed officers
Precinct Patrol Force. Within the last 6 years,
the patrol strength of the 104th Pct. has
dropped under 130 officers. In 1995, there were
approx. 200 officers, exclusive of sergeants &
lieutenants for Ridgewood, Maspeth, Middle
Village, and Glendale. At least 170 officers are
needed for the 104th Pct., plus supervisors, to
cope with robbery, burglary, violent crime,
domestic violence threats, inadequate response
times, speeding, auto theft and rowdy youth
conditions often caused by substance abuse. The
new Atlas Park Shopping Development, which
opened in Spring 2006, has put additional
pressure on our already overloaded precinct.
2/25
DEP
Inspect sanitary
Provide Field Workers for Bureau of Water and
sewer on specific
Sewer Operations. Field workers in sufficient
street segment and
numbers are needed to ensure that City water
repair or replace as
remains excellent; that catch basins are cleaned
needed (Expense)
and repaired and sewer lines are flushed in a
reasonable amount of time; that sewer backups
and leaks are corrected expeditiously and that
sewer repairs and fire hydrant repairs are
performed in a timely manner. Currently, cave-in
conditions in the road and adjacent to catch
basins too often go unrepaired for months,
presenting dangerous conditions.
3/25
DOB
Assign additional
Hire Inspectors and Plan Examiners, in Sufficient
building inspectors
Numbers, to Cope with Illegal Uses of Property
(including
and Questionable Construction. A separate
expanding training
afternoon/evening and weekend inspection
programs)
team of 10 inspectors for Queens is critical
because inspectors very often can't gain access
in the daytime during the work-week.
Communities throughout Queens have been
plagued with illegal apartments posing
dangerous conditions, school overcrowding and
more pressure on limited City services.
Construction inspectors and plan examiners in
adequate numbers are needed to curtail
contractors building homes larger than the
zoning permits. Currently to our knowledge,
Queens has 37 plan examiners and 15
construction inspectors usually working in the
borough.
4/25 DSNY Provide more
frequent litter basket collection
Provide Sanitation Department Cleaning Personnel, to Clean Illegal Dumping and for Litter Basket Collections. Illegal dumping and garbage drop-off locations are a consistent problem in District 5, Queens. In order to alleviate these very problematic conditions, which are potential health hazards and hamper business investment: 1. Restore Clean Team personnel to clean dump-out and drop-off locations on a regular basis, 2. Provide adequate personnel to empty litter baskets 7 days a week.
image
5/25 DYCD Provide, expand, or
enhance after school programs for middle school students (grades 6-
8)
Provide Funding for Educational and Recreational Programs, for Children and Teens. Funding for after school, evening and weekend delinquency prevention programs should be maintained locally. This is especially critical at a time when far too many children and teenagers are unsupervised by parents or guardians after the school day ends and on weekends. These programs are very critical as they increase self- esteem levels of participants, thereby preventing substance abuse and delinquent behavior. While Beacon Programs are welcome, it is vital that funding for other quality "local" education and recreation programs be a priority. Thankfully, Mayor de Blasio and City Council Members have increased youth program funding substantially.
image
6/25 FDNY Provide more
firefighters or EMS workers
Provide Funding for Fire Department Services. Funding is needed for the following essential Fire Department Services: maintain engine companies and ladder companies at current staffing levels; provide funding for the Department's Building Unit; ensure adequate staffing for excellent maintenance of FDNY apparatus and other vehicles; and provide sufficient funding for the Fire Safety Education Unit.
image
7/25 DFTA Other services for
homebound older adults programs
Provide Needed Services for Senior Citizens. Community District 5, Queens has a very large senior citizen population, many of whom are frail, without adequate care and living alone. The following are necessary programs to meet some of the needs of senior citizens: 1) Provide adequate funding for Meals-on-Wheels programs; 2) Provide adequate funding for congregate meals programs; 3) Provide funding for senior transportation programs; 4) Fund Health Care Programs for the Elderly and Senior Home Care; 5) Fund Emergency Food Programs for Seniors.
image
8/25 DSNY Provide more
frequent garbage or recycling pick-up for schools and institutions
Continue 5 Times Per Week Garbage Collection and Begin 5 Day a Week Recycling Collection for Schools. The reduction to 2 days per week garbage collection caused unsanitary conditions around many local schools. School collection, 5 days per week, is critical during the school year and during the Summer. It is also important that recycling collection at schools be increased. Five times a week recycling collection is needed for many public schools, as the current conditions result in recyclables crowding school sidewalks.
image
9/25 DPR Forestry services,
including street tree maintenance
Allocate Funds for the Operation and Enhancement of the Division of Forestry in Queens. There are extensive needs for pruning of trees on city streets and in city parks, which are too numerous for the Division of Forestry to keep up with. There are currently more than 10,000 street tree stumps that need to be removed in Queens. The following budget allocations are needed to address these conditions, and the need to remove dead trees and limbs on an emergency basis: $4.5 Million for county-wide pruning contract; $3.5 Million for removal of tree stumps in Queens; $2 million for removal of dead trees and limbs. Trees are aging, and risks of falling limbs and dead trees pose dangerous conditions.
image
10/25 DOT Other expense
traffic improvements requests
Provide Sufficient Personnel for Traffic Safety Inspections, Sign Installations, Pavement Markings and Sign Manufacturing. Because of increasingly dangerous local traffic conditions, there has been a need during the past 10 years for more traffic safety studies, traffic signals, All Way Stop installations, Speed Bump installations, One Way Conversions, and No Parking designations to daylight intersections. Additional traffic device maintenance crews are needed for signage installation, pavement markings and sign manufacturing. Vehicles in good repair, including utility trucks, are needed to support current and projected staffing levels.
image
11/25 DOT Other expense
traffic improvements requests
Fund Additional Street Maintenance for Queens Roadways and Curbs In order to have roadways along commercial strips and in residential communities repaired before dangerous conditions arise, the following requests need to be funded: provide one crew for cave-in repair; 2 crews for pothole repairs; 1 crew for concrete repair; 2 crews for curb replacement; and 1 crew for miscellaneous maintenance (ponding conditions, etc.) daily for Queens. Lawsuits against the City might be greatly reduced if repairs could be done more promptly.
image
12/25 QL Extend library hours or expand and enhance library programs
Provide Six-Day-a-Week Service at Local Libraries. Increased educational demands on students, the fact that many families cannot afford the internet or up-to-date computers and increasing immigrant populations necessitate that the great majority of local/branch libraries be open 6-days a week. Having Libraries open on Saturdays is especially important to all our residents!
image
13/25 DSNY Other enforcement
requests
Increase the Number of Sanitation Police and Enforcement Agents, Especially in Plain Clothes, to Significantly Reduce Excessive Abuse of Litter Baskets and Illegal Dumping. Because of previous lay-offs, there are now fewer Sanitation Police citywide for illegal dumping. Sanitation Police positions should be greatly increased for illegal dumping, especially since they are revenue producing, and dumping is severely hurting communities. One SEA agent is needed daily in Q5. Severe fines, vehicle impoundments and more publicity, such as frequent press releases to TV and radio stations and major newspapers, are needed to make an example of dumpers and curtail illegal dumping. The abuse of litter baskets on commercial strips has become deplorable, and needs to be better addressed.
image
14/25 DPR Provide better park
maintenance
Assign More Personnel and Equipment for Maintenance of Parks in District 5, Queens. More park workers are needed to meet work requirements for the cleaning and maintenance of the 229.7 acres of parks in CD5Q. Currently, there are only 10 Parks Dept. maintenance staff, including supervisors, assigned for this massive parkland. Skilled maintenance workers (there are only 2 for all of Queens Districts 5, 9, 10 & Forest Park) should be funded year-round.
Reseeding, aerating and fertilizing ball fields and grassy areas need to be priorities so that large capital expenditures are not wasted.
Funding is also needed to hire more seasonal workers. Long standing equipment needs include a new Gator, a new Crew Cab and a new Packer.
image
15/25 DHS, HRA
Provide, expand, or enhance rental assistance programs
Consistent, adequate funding is needed for programs such as the Living in Communities Rental Assistance Program (LINC), to prevent people from becoming homeless, and to move people from shelters to more permanent housing.
image
16/25 NYCHA Expand programs
for housing inspections to correct code violations
Allocate Funding for Dept. of Housing Preservation & Development Programs. Adequate funding must be appropriated to cope with illegal residential property uses
,deteriorating housing stock, and harassment of tenants by greedy landlords. The needs include HPD Code Enforcement Inspectors; funding for housing rehabilitation loan programs; substantial funding for tenant legal services, and for demolition and seal up operations in Queens. Currently, to our knowledge, only 15 Inspectors are assigned to Queens of 314 Inspectors working in N.Y. City.
image
17/25 NYPD Other NYPD staff
resources requests
Hire Traffic Control Agents, School Crossing Guards and Additional School Safety Officers. The City should earmark funding to hire additional traffic control agents: (Traffic Enforcement Agents-Level II), so that heavily travelled Queens intersections can be staffed. This will diminish the need to assign police officers, who are paid more. In consideration of dangerous traffic conditions, funding is needed to hire at least 5 additional school crossing guards for District 5, Queens schools. Most elementary schools have only 1 or 2 School Safety Officers; intermediate schools only have 3 officers, which in many schools is very insufficient.
image
18/25 DOHMH Reduce rat
populations
Hire Additional Personnel for Pest Control to Combat the Enormous Rat Population in our City. The Borough of Queens has too few staff to adequately address the rodent infestation problem, which has increased with the growth of dump-out locations and vacant properties. A minimum of 4 additional inspectors and 4 additional staff to bait are needed for Queens.
image
19/25
HHC
Other health care
Continue Funding of the Ridgewood Medical
769
facilities requests
Center, now renamed Gotham
Onderdonk
Health/Cumberland. The Ridgewood Medical
Avenue
Center (formerly known as the Maspeth Child
Health Station and Ridgewood Communicare
Health Center) provides important health
services to many children, families and senior
citizens. Ridgewood and neighboring
communities have seen an increase in the
number of people struggling economically. The
need to expand services beyond the hours of
Mon. to Fri., 8:30am to 4:30pm, should be
seriously considered to serve workers and
workers with children.
20/25
DEP
Investigate odor
Hire Operations Staff- Bureau of Wastewater
complaints about a
Pollution Control. Sufficient Staffing is needed to
wastewater facility
perform odor and water pollution control
and address/repair
monitoring at wastewater treatment facilities in
or make equipment
New York City. Odors from wastewater
improvements as
treatment facilities pose health hazards, will
needed (Expense)
likely casue residents to move and could
severely hamper business investment. Locally,
we are most concerned about the Newtown
Creek Water Pollution Control Plant.
21/25
DPR
Forestry services,
Hire Forestry Personnel. With previous cuts, the
including street tree
Forestry Division had been decimated. At one
maintenance
point, there were only 4 climbers and pruners to
care for more than 327,000 street trees in
Queens. Queens needs at least 55 climbers and
pruners to remove and prune trees posing
dangerous conditions.
22/25
FDNY
Other FDNY facilities
Provide Funds for: Tools and Equipment for
and equipment
Local Fire Department Personnel and for Fire
requests (Expense)
Prevention Program Supplies. Hurst Tools,
Rabbit Tools, defibrillators, power saws, first aid
equipment, etc., are needed to ensure the safety
of local residents. Funding for Fire Fighters' face
pieces is also an important need. Funding is also
requested to purchase 10,000 smoke detectors,
at a total cost of approximately $100,000, and
10,000 carbon monoxide detectors, at a cost of
$200,000 for distribution to the public
throughout the year. Funding is requested to
purchase 10,000 new CPR kits for public training
and distribution.
23/25 ACS Other foster care
and child welfare requests
Fund Bureau of Child Welfare (B.C.W.) Satellite Office in Queens. There is a need for a Bureau of Child Welfare satellite office, especially during the 6 p.m. to 8 a.m. hours, to operate weekdays and weekends. Many children in CBQ 5 have sought sanctuary from abusive parents, relatives and other individuals. With B.C.W. staff hours limited, the abuse of children is too often unattended and the problem situation continues.
image
24/25 DOT Other expense
traffic improvements requests
Improve Arterial Highway Cleaning and Maintenance. The conditions of arterial highways and their cleanliness should be a priority for the City and State of New York. Maintenance workers citywide are needed to repair and resurface roadbeds, repair and replace dividers, clean litter & debris, attend to growth, and eliminate graffiti in a timely manner.
image
25/25 NYCHA Other housing
oversight and emergency programs
Increase Funding for Community Consultant Contracts. In Q5, there are many multiple dwellings owned by landlords who need technical assistance related to leases, paperwork and tenant matters. Tenants are often in need of advice and assistance related to lease matters and landlords who do not upkeep property. In Q5, the Greater Ridgewood Restoration Corp. has a history of helping landlords and tenants . This organization has also prevented hundreds of properties from being taken from owners in lien sales through excellent outreach to owners.

