- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 7 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1aKKT0pwpypEWPmuKzo6mGbzXwMeDu2Xc/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1aKKT0pwpypEWPmuKzo6mGbzXwMeDu2Xc/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
7
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 7
image
Address: 133-32 41st Road, 3-B Phone: (718) 359-2800
Email: qn07@cb.nyc.gov
Website: www.nyc.gov/html/qnscb7/
Chair: Eugene T. Kelty District Manager: Marilyn McAndrews
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 7 is the largest in population and 5th largest citywide in acreage of all 59 Community Boards. It is comprised of eight towns, Bay Terrace, Beechhurst, College Point, most of Flushing, Malba, Queensborough Hill, Whitestone, and, Willets Point, making up 12.7 square miles and 285 miles of city streets. We are an extremely diverse community consisting of one and two family homes, suburban/urban high rise apartments, 64 park locations, 30 greenstreets, an intermodal transportation hub with 26 bus lines, the 7 train, and the L.I.R.R. In addition, we are the 4th busiest retail area in the city, the second largest industrial area in the borough because of the College Point Corporate Park, and, the 2nd busiest downtown behind Herald Square. Our board has the largest waterfront area running from Flushing Bay to Fort Totten. Our diversity presents us with many challenges and problems, which we must address and resolve, if we are to maintain the level of our past accomplishments, and improve our quality of life in the 21st century. These can be summarized along the following issues: zoning, parking, the environment, transportation, traffic, service delivery, waterfront development, in addition to maintaining the economic growth in downtown Flushing, College Point, Bay Terrace and Whitestone. We are concerned about meeting the needs of our senior citizens, the proliferation of houses of worship, maintaining the viability of our parks, as well as our historic heritage. Our most immediate emphasis is concentrating on managing new developments within our board area, and the potential of its impact on traffic, service delivery, and schools for our youngsters. Evidence shows that our board has experienced enormous building growth in both commercial and residential areas. For example within only a four block radius of downtown Flushing, the housing stock in the past 25 years has grown, and projects presently on the drawing board will bring in additional units of housing within the next several years. Flushing Commons is doing a mixed use development on the old Municipal Parking lot 1, the Hyatt Place hotel opened on Prince Street as part of the Fulton 1 mixed use development, and the anticipated Fulton 11, also a mixed used "as of right" development, is on the drawing board directly across the street on 39th Avenue between Prince Street and College Point Boulevard. With the completion of the 2010 census, our population was estimated to be approximately 256,000 documented persons, making us the largest population wise of all 59 boards. Many census tracts in and around downtown Flushing have experienced substantial population growth. This data confirms that the trend of substantial growth in our area has continued adding to the demand for new market rate and affordable housing, senior housing, classroom space, and city services.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 7
image
The three most pressing issues facing this Community Board are:
Street conditions (roadway maintenance)
Federal, State and City funding is insufficient to meet the needs of our capital projects, which are necessary to provide desperately needed infrastructure improvements. The majority of our capital priorities has been and will remain, transportation requests. Capital construction needs to be accelerated to accommodate the increased volume of traffic, and deteriorated condition of our streets. We need to see Linden Place phase 2, connecting to 20th Avenue accelerated since this street will be needed for the reconstruction of Ulmer Street between the Whitestone Expressway Service road and 25th Avenue, as well as 28th Avenue between College Point Boulevard and Linden Place. Both Ulmer Street and 28th Avenue will have to be closed for several years because of the necessity to do surcharging. The city recently resurfaced 20th Avenue, however, with its heavy utilization by cars, buses, and trucks - many of which are 18 wheelers, the roadbed will not be able to be sustained, and will eventually begin collapsing. The agency took a Band-Aid approach to a hemorrhage. The condition of our streets are terrible,, with a myriad of potholes and ruts it is difficult to navigate resulting in many drivers have sustained damage to their cars. The agency needs to accelerate some of its basic maintenance issues, such as repainting of street markers indicating "Stop Ahead", "Speed Bumps", school crossing signs, and re-installation of street name and stop ahead signs. These delays generate many community complaints.
Street flooding
The agency must seriously look at accelerating our number one capital budget request for the reconstruction of 20th Avenue from the Whitestone Expressway service road to College Point Boulevard, as well as 127th Street between 14th and 22nd Avenues. This major roadway connects the communities of Whitestone to College Point. The roadbed which is heavily utilized is uneven, has many ruts, as well as a serious drainage problem.
Traffic
The commercial areas of Flushing, College Point, and Whitestone generate a tremendous amount of car, bus and truck traffic. This puts an incredible strain on the streets and highways of these communities.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 7
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
Community Board 7 being the largest population wise, have approximately 110,000 seniors living in our district. We have seen a younger, more vibrant senior whom want innovative and exciting programs. We are happy to see that the Department for the Aging has created more innovative centers. They have expanded the hours, their programs are more diverse, and have expanded programming by introducing technology, cultural arts, weekends, and addressing the needs of our multi-cultural community. They have realized that by keeping their minds active, they remain younger. In addition DFTA has seen the need to introduce Virtual Senior Centers programs, and has also implemented a tele-health kiosk to measure and track health outcomes for their members on an ongoing basis.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
Our concern is that 1/3 of our population are seniors, and growing. There is a need for additional services for better access to "Access A Ride" or perhaps a voucher program for transportation as "Access A Ride" has a poor track record. and, centers that would accommodate the active to frail senior with programs to meet their needs, as well as affordable housing. In additional with regard to the frail senior, these centers must actively pursue the idea of an ongoing intergenerational program connecting seniors with high school and college students who can either be companions, or assist them with simple chores.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
22/28 DFTA Create a new senior
center or other facility for seniors
Funding must be obtained to allow the Department for the Aging to develop additional sites within CB7-Qns. Our District has a senior population with close to 90,000, & with the lack of upgraded facilities this goal is hard to accomplish. These sites must be developed keeping in mind that our seniors are more active & involved. In addition provide voucher program for senior transportation.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
7/25
DFTA
Other senior center
As mention in the Capital Priority, the need of
program requests
Senior Centers is now at a status Quo, what is
needed is continued funding for the existing
Senior Centers as well as increasing the funding
to maintain the amount of seniors that are
using these facilities.
24/25
HRA
Provide, expand, or
Provide, expand or enhance food assistance,
enhance food
such as Food Stamps/ SNAP as well as other
assistance, such as
programs such as Transportation Vouchers
Food Stamps / SNAP
Board 7 has a very high population of Senior
Citizens, immigrant adults an low income
Families. Any funding to assist in these areas is
recommended. Agency's response is that SNAP
is a Federal program however other programs
are not and fund should be provided to assist
them.
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 7
image
M ost Important Issue Related to Youth, Education and Child Welfare
Youth workforce development and summer youth employment
Beacon programs are effective programs that offer positive youth development through educational, cultural and literacy programs. Currently we have two Beacon sites that serve the needs of approximately 47,000 youth.
Preventative programs are necessary to keep youngsters active and engaged in constructive programs , and should include educational and career choice counseling, as well as high school drop out prevention. Youth employment programs should be expanded to address youth employment, develop jobs, and job training programs. In order to make certain that we are doing the best for our youth, the Dept. of Youth and Community Development, must engage in cooperative planning, ensure the most effective use of current youth programs, as well as the development of additional pro
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Construction of a middle school for College Point is essential. With the increase in population, and the only middle school that closed decades ago, these children need to travel to the communities of either Flushing or Whitestone. In additional anytime the board votes on a large scale development, one of the criteria for approval is that the developer must look at placing a school within the site to accommodate the children in the area. In downtown Flushing, due the school over-crowding, P.S. 107, which is located at 167-02 45th Avenue, for the next two years will be accepting the kindergarten children from P.S. 24, which is located at 141-11 Holly Avenue.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
20/25 DOE Other educational
programs requests
Joint Education Programs between Board of Education and Parks Dept. It was felt that Parks is funding a lot of the playgrounds and in most cases they can't and refer back to the Community Boards to get funding from the Borough President's Office and Local Elected Officials. It is requested that the Board of Education provide fund on joint playgrounds.
The board has seen improvements but continue supporting joint funding by both Agencies.
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 7
image
M ost Important Issue Related to Public Safety and Emergency Services
Emergency service delivery (including rapid response)
With both Police and Fire, our residents are concerned with the effect of quality of life issues. Due to the increased urbanization, and new high rise development, which is increasing the population, resulting in a heavier workload with our Public Safety agencies. The present geographical boundary, and the influx of new Americans within our district has been burdened with the demand to service the community properly. The ability to maneuver through the district with an emergency vehicle becomes a challenge. Thus delaying the response time to either a fire or police incident.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Recently due to the needs of this community, the local precinct (109th) has received an additional 60 officers, and, within the next several months, an additional 30 officers will be assigned to the precinct. In addition, we are now involved in a program which allows for a total of 6 NCO's . The district is broken up into four sectors that are covered by two NCO's , and our NYCHA housing projects are covered by two additional NCO teams. This is in addition to the usual police coverage. The residents living in these specific areas, if they request, are given the cell phone numbers of the NCO's covering their specific area. it is a program that allows for almost instant police coverage/communication in that specific area. It is a hands on program that the residents of our district are very happy to have received.
Needs for Emergency Services
As there has been an increase within the Asian community, our community desperately needs more Korean and Chinese personnel. Our board has over 800 establishments selling alcohol, karaoke bars, internet cafes to name a few. Several buildings within our district have these types of establishments under one roof. This does create a problem for emergency services, since the information that we are able to obtain from the Dept. of Buildings, may indicate several serious issues/violations which SLA pays no attention. Doors can be blocked, they have not built according to plans, no emergency lighting, sprinklers or secondary means of egress. In case of a real emergency the lives of the patron as well as the service provider will be in jeopardy. All agencies must be on the same page. SLA must listen to the Community Board as well as both fire and police departments as it pertains to the laws on the books.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation Location
13/28
FDNY
Rehabilitate or
Rehabilitate or renovate existing Fire Houses &
renovate existing
EMS Stations. Due to growth in the number of
fire houses or EMS
housing units in CB7-Qns. upgrading the
stations
firehouse is of the utmost importance which
includes electrical system, plumbing, painting
throughout , and back-up diesel generators
(E295 & E297). Relates to four Engine
companies 274, 273, 297 & 295
21/28
FDNY
Upgrade
Complete & Upgrade of E.R.S. boxes will cut
communication
down on false alarms and provide better
equipment to
services in times of real emergencies. Will
improve emergency
eliminate wear and tear and waste of diesel fuel
response
on the rigs.
24/28
NYPD
Provide a new NYPD
Over the years crime has increased in Flushing
facility, such as a
Meadows Corona Park. The Precincts
new precinct house
surrounding the park are too busy to assist with
or sub-precinct
regard to park security. If an incident was to
occur within the park the response time would
be significantly improved with the
establishment of a satellite precinct. Safety
must be our number one priority for the myriad
of families utilizing the park on a daily basis
28/28
NYPD
Other NYPD
At present locker room are old and must be
facilities and
updated to accommodate the female officers
equipment requests
and new hirers.
(Capital)
CS
NYPD
Provide a new NYPD
Community Board 7 having the largest
facility, such as a
population of the 59 Community Boards, and
new precinct house
one of the largest in geographic area, there is a
or sub-precinct
need for an additional police precinct in our
district. According to information the 109th
precinct is 4th in the overall index crime
complaints in the city, and first in Queens for
radio runs ( approximately 6,000 per month).
The fair share allocation for manpower has to
take into consideration the quality of life issues
that the precinct has to deal with. This requires
time and manpower of which our precinct is
being stretched far beyond their limit.
CS FDNY Other FDNY facilities and equipment requests (Capital)
There is a need to develop a multi agency civic learning center to teach youngsters about safety issues as it pertains to fire, buildings, environmental protection, health, police and sanitation departments. In addition, these site could be used for seniors as a refresher center.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
8/25
NYPD
Assign additional
Support funding for additional personnel to
uniformed officers
address quality of life complaints, maintain the
DARE program (workshop on drug education for
school children). Additional civilian personnel to
relieve officers assigned to the 109th precinct,
school crossing guards. Additional traffic
enforcement agents are needed to intensify
enforcement coverage. In addition, the K9 unit
dogs are capable of sniffing out drugs and
bombs.
10/25
NYPD
Other NYPD
Need funds for order boots for commercial
facilities and
trucks that park overnight in residential areas as
equipment requests
well a heavy duty tow truck for 18 wheelers.
(Expense)
Additional equipment Plate Readers, GLA
Trackers and Argus Cameras
14/25
FDNY
Expand funding for
Funds for Fire Department personnel and
fire prevention and
Training, Restoration of Fire salvage Unit Fire
life safety initiatives
Safety Education Unit Marine Units, Haz-Mat
Units as well as additional training in counter
terrorism
15/25
FDNY
Expand funding for
Provide funding for Fire House to upgrade them
fire prevention and
with backup generators, GPS for their
life safety initiatives
Apparatus,. Funding for Smoke and Carbon
Monoxide Detectors and CPR Kits for their Fire
Safety Education Unit.
19/25
FDNY
Expand funding for
Fire Marshals are the detectives for the Fire
fire prevention and
Department and are on the scene of a fire to
life safety initiatives
determine if arson is the cause. The evidence
must not be destroyed, and with the projected
opening of the base in Queens the backload of
open cases and arson fires will be reduced.
Request funding for Fire Marshal Personnel and
programs ie. the Juvenile Fire Setters
Intervention and the arson task force.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 7
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
While they are all important, it is very difficult to just narrow it down. Our residents are constantly calling our office with regard to dump outs, improper garbage disposal, and persons going through the trash looking for bottles/cans for recycling. Because of the importance of this issue, the formation of a BID was established in the downtown Flushing area to help alleviate the debri left on the sidewalks, the overflowing baskets, as well as the greasy sidewalks. In addition the Councilperson in Whitestone has funded a twice a weekly BID operation to make sure that the Village is kept clean. With regard to Whitestone, we are working with the Dept. of Transportation to change the parking regulations in order to assist.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Since 1984 our board has included in their capital and expense budget submissions the need to construct both sanitary and storm water systems within the district. We have seen a major increase due to the aging sewer systems which have resulted in major flooding problems especially in the areas of north Flushing, College Point as well as Whitestone. One of our major projects is SE809 which goes from along the N/B Whitestone Expressway Service Road from College Point Boulevard to 25th Road, and Union Street on the eastern portion. It entailed water mains, sanitary sewers, a storm system and chambers, and later this year we will see the start of SE807 which will cover the western portion of College Point, and, followed by SE810/811 which will be east of SE809. All of these projects have always received special attention when doing our budget due to the severity of the flooding that occurs, impacting not only homes, but, major roadbeds.
Needs for Sanitation Services
Litter, especially in the downtown shopping areas, is a never ending problem even with the Flushing BID in place. Multi-language educational efforts are required to explain the various sanitation laws in the District's citizens and businesses. Enforcement is needed, but it must be fair and reasonable. We request that emphasis be placed on ticketing the litterbugs instead of where their litter falls. This will reduce litter now, and in the future as this will also be an educational effort for those ticketed. Community Board 7 supports the various recycling programs, and the outreach and educational efforts must continue, and be increased to encourage vigorous participation by all citizens and businesses. Weekly recycling must continue, and we are happy to see new materials targeted for recycling, such as textiles and food wastes. Multi language educational efforts must target those areas with lower capture and diversion rates. The towing of cars from snow emergency streets during snowstorms must initiated to allow for better snow removal. Snow removal efforts have improved since the agency added the trucking of snow out of the congested areas, and where possible, the melting of snow to reduce the mounds of plowed snow. With the recent opening of the North Shore Marine transfer station, efforts must be in place to ensure that sanitation drivers from other community districts use only the approved truck routes coming and going from the MTS. Local streets are not through streets, and should not be used.
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
8/28 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
The construction and reconstruction of sanitary, storm and combined sewers Mitchell Linden area will help lessen the incidents of sewer back-ups and will assist in the draining of storm
and sanitary water. Problem sites 138th St. from cross section at 31st Rd to 29th Rd. Also, 137th St. from 31st Rd. at cross section to 32nd St. along the Whitestone Expwy Service Rd. going north betw Linden Place and 141st St.The modernization of interlocker catch basins and granite head catch basins will facilitate maintenance within board 7 (1984-project)
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
3/25
DEP
Investigate noise
Money must be allocated to purchase noise
complaints at
mitigation equipment for the Agency to
specific location
measure the sound levels of pile driving & jack
hammering. With the accelerated new
construction going on in our district we have
been receiving an increase in complaints from
area residents regarding noise which presently
is been monitored & enforced by DEP.
Investigating noise complaints at specific
locations is needed. Tickets issued in 2018 - 93
and in 2019 - 92. Other agencies also issued
tickets ie: NYPD
5/25
DEP
Clean catch basins
Additional maintenance staff is needed to
handle the increase number of street collapses
and to perform odor control monitoring at
water plants & staff to handle repairs for the
general cleaning and repairing of catch basins.
6/25 DSNY Other enforcement
requests
Additional personnel are needed to handle basket pick-ups on Saturday, Sunday & Holidays on commercial strips. Maintain 5-day school collection & twice weekly recycling collection & sweepers. Plus household bulk must be opened during the week to accommodate homeowners who need access to the dump. If the household dump is not accessible illegal dumping will increase.
image
16/25 DSNY Provide more
frequent garbage or recycling pick-up
Maintaining the weekly recycling program is a necessity with the increasing population, building growth and new products-i.e.: all plastics, clothing and food waste. It's extremely important to have weekly collections in order to accommodate the anticipated growth of the agency/population. Quota numbers need to be increased.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 7
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
To facilitate the demands of the District, the Building/Housing Committee is recommending Building Code Enforcement as a priority since it will protect homeowners, coop/condo owners and renters alike. To further support the request for Building Code Enforcement, the borough of Queens receives more requests for code enforcement than any other borough.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Our board has been working with the elected officials as well as City Planning on the development of Flushing West which goes from Roosevelt Avenue to Northern Boulevard from Prince Street to the water. We have had quite a few meetings with all affected parties, however, just recently City Planning, at the request of our Councilman have put the brakes on this project. We are concerned with regard to the need of an additional CSO tank which presently is not on the drawing board. What DEP wants to do is chlorinate the water, which is environmentally not safe for marine life. In addition, developers are having major problems with MIH due to the fact that the banks will not give them financing. Three major development projects are moving along - Sky Vu park; Fulton II and Flushing Commons is nearing completion of Phase I. All of these developments will be putting a major burden on city services.
Downtown Flushing is presently congested, the 7 train platforms are overcrowded and unsafe, in addition to other city services. While development is good for any neighborhood, we have found that the Environmental Impact Statements do not correctly detail the needs for the development, and/or the community. Any new large scale development does have an impact on city services, that must be addressed.
Needs for Housing
No comments
Needs for Economic Development
In working with the Flushing BID and Chamber, we have been having meetings regarding the 360 Grant for the Downtown Flushing Commercial District Needs Assessment. What the agency really needs to address is the hiring of a bilingual person who is knowledgeable in city rules and regulations, and, must be a liaison between businesses and city agencies. This person needs to be able to interface with the Community Board, BID and Chamber. The city needs to make this investment in order for the business community to survive. Rather than violate, they must educate. This investment will maintain the present business growth in Flushing. Our existing Flushing BID has been a very effective and positive influence for our bustling commercial strip...they have worked on graffiti removal programs, sanitation issues, security cameras, a restaurant guide, hanging banners as well as flower baskets. The Executive Director along with his board, are always coming up with new ideas to help improve the commercial atmosphere in the area. Presently the BID is awaiting approval for its expansion.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
CS EDC Make infrastructure investments that will support growth in local business districts
Improve and develop Flushing Airport site to be utilized for soft recreational uses which would include using an aviation theme. site should include uses such as a driving range, miniature golf, water park to enhance the wetlands, etc. CB7-Qns. does not want to see heavy trucking uses such as a manufacturing or a retail component. (1980-project)
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/25
DOB
Assign additional
Due to the increase of construction in CB 7,
building inspectors
there is a need to increase the number of
(including
qualified inspectors to expand the
expanding training
administrative tribunal to deal with the volume
programs)
of violations and to increase the number of
inside personnel to assist CB staff 8 additional
support staff, additional administrative staff and
additional inspectors are needed.
22/25
EDC
Expand programs to
Funding is needed for the Local Businesses to
support local
assist them with the current rising cost business.
businesses and
entrepreneurs
23/25
NYCHA
Expand programs
Expand programs for Housing Inspections to
for housing
Correct Code Violations. Funding for Staff
inspections to
Attorney's to handle the backload of cases.
correct code
Cases are increasing each year by 7-8 per cent.
violations
TRANSPORTATION
Queens Community Board 7
image
M ost Important Issue Related to Transportation and Mobility
Sidewalk and curb construction
While we are only given the opportunity to select one, each of the above plays a very important role as to how our residents feel about the flow of traffic, accessibility to mass transit, the ability to safely navigate a congested sidewalk. In addition, their is a lack of properly maintaining our roadways and the maintenance of our bridges.
Many of our complaints coming from our residents deal with the condition of the sidewalks, curbs, pedestrian pads as well as the many deteriorated bus pads. Each of these creates a major tripping problem, especially for seniors and the handicapped. Sidewalks and curbs seem to be an issue with Contractors not doing a good job and residence complaining.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
We are constantly receiving complaints from residents living in our district about the 7 train line. The station is filthy, the escalators are constantly in repair, the staircases are extremely narrow, the platforms during rush hour are jammed, and with the increase in population, we are concerned that this station will not be able to handle the crowds that will be utilizing this station. In addition, the L.I.R.R. is a nightmare in downtown Flushing. The staircases, are extremely steep and even able bodied individuals have a difficult time navigating these staircases onto the platform. The construction of the elevator must be accelerated.
Needs for Transit Services
With the increased populations, and approximately 100,000 persons passing through downtown Flushing every day, we have requested that the 7 line platform be expanded west of Main Street, and that the subway line be extended east to the other neighborhoods of Flushing and Bayside. Thus relieving some of the congestion in the downtown area. We are an intra-modal transportation hub with 24 bus lines converging in downtown Flushing area. MTA has introduced SBS which is having a tremendous negative impact in downtown Flushing. This is having a negative impact on the small business community, making it more difficult to receive deliveries, and parking close to the stores has become more difficult to find. Downtown Flushing is the 2nd most congested area in the city, and by introducing the SBS, they have narrowed down Main Street to one lane in each direction. This has resulted in traffic at times coming to a crawl due to the lack of street capacity. In addition, the LIRR station at Willets Point must be in operation on a yearly basis. The only time that this station operates is for the Mets home games, as well as the USTA. If it were to operate full time, then drivers could utilize the abutting parking fields, thus relieving some of the congestion in downtown Flushing.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/28
DOT
Reconstruct streets
Reconstruction of 20th Avenue from the
Whitestone Expressway service to College Point
Boulevard, and 127th Street from 14th to 23rd
Avenues. This heavily utilized main artery within
our district connects the communities of
Whitestone and College Point, and also serves a
large shopping mall between these two areas.
The road has extensive flooding problems, and
existing roadbed is sinking. Major road
construction and sewer work is necessary in
order to bring these streets up to grade.
3/28
DOT
Reconstruct streets
Reconstruction of Union Street from Northern
Boulevard to 26th Ave. and from 26th Ave. to
Parsons Blvd.. This is a heavily used major
artery serving the southern end of Whitestone
into Downtown Flushing, utilized by trucks and
busses. The road, bus pads and pedestrian
ramps are badly deteriorated.
4/28
DOT
Reconstruct streets
Willets Point Phase II - This area has been
neglected by the city of New York and needs a
total Capital reconstruction to include
sidewalks, roadbed, sewers, and street lighting.
This area has extensive flooding problems and
the roadbed has sunk making it impossible for
drivers to navigate the area. Funding not
available is unacceptable as this project should
be funded by the city department's of DOT &
DEC
6/28
DOT
Reconstruct streets
Reconstruction of Ulmer Street from the
Whitestone Expressway S.R to 25th Avenue. This
street which is a main access road into College
Point is collapsing causing drivers to lose
control. The roadbed must be surcharged, and
the sewers placed on piles in order for the street
to not collapse again.
7/28
DOT
Reconstruct streets
Reconstruction of 28th Avenue from Linden
Place to College Point Boulevard. This street is
an access road into College Point as well as the
Corporate park. The roadbed is collapsing and
possibly causing drivers to lose control. The
roadbed must be surcharged. and the sewers
need to be placed on piles in order for the street
not to collapse again.
10/28
DOT
Improve traffic and
Implement recommendations of traffic study for
pedestrian safety,
College Point Corporate Park. Park rapidly
including traffic
developing and must move forward. It houses
calming (Capital)
the new Police Academy, two Sanitation
garages, the reconstructed Marine transfer
station, plus the myriad of buildings, and retail
components which adds to the present traffic
congestion. With the development, the traffic
study has focused on 1800 to 2000 coming to
the site, the back-up of traffic along 20th
Avenue extends into the community of
Whitestone. 1998-project
14/28
DOT
Other
Muni Lot II located at 38th Avenue between
transportation
Main & Prince plays an integral role in the
infrastructure
economic development of the Flushing
requests
community. Rapid development has outpaced
Flushing's infrastructure. In order to meet the
demands & growth of the Flushing community a
multipurpose multilevel parking lot is required.
16/28
DOT
Reconstruct streets
Implement Main Street redesign Phase IV.
Downtown Flushing street improvements,
sewer/water main replacement, curbs,
sidewalks, lights, and landscape. This area is to
include King Street,36th Ave, 36th Rd, 37th Ave,
and 39th Ave to College Point Boulevard.
18/28
DOT
Reconstruct streets
Construct College Point Boulevard between 14th
and 23rd Avenues. This location is the main
artery for the business district of College Point.
The road has extensive flooding problems, in
addition to street and sidewalk deterioration.
This road reconstruction is necessary to bring
this area up to grade.
25/28
NYCTA
Improve
Expand mezzanine portion of 7 line to Prince
39-07 Prince
accessibility of
Street to include an exit into 39-07 Prince Street.
St
transit
Board 7 passed a zoning change that in the
infrastructure, by
near future, downtown Flushing will see an
providing elevators,
insurgence of new development west of Main
escalators, etc.
Street. Recently a developer made a
commitment that if the mezzanine were
extended west they would allow and
entrance/exit into this building.
CS
DOT
Other
Reconstruct and Correct Drainage systems at
transportation
Casey Stengel Bus Depot located at 40-15 126th
infrastructure
Street, Flushing(1980-project) MTA is
requests
responsible not DOT
CS
DOT
Reconstruct streets
Expansion & upgrading of Flushing Airport
(FA308), realignment of Linden Place required
drainage retention pond. grade/curvature
adjustments necessary due to location of
drainage retention pond. Project abutted by
Flushing Airport, College Pt., Sports Complex &
Corp. Park. Roadways involves cracked, uneven,
& deteriorating. Linden Place has severe water
ponding condition w/non-existent curbs. There's
a need for marginal road to get traffic off the
southbound Whitestone Expwy. Svcs. Rd. (1998-
projuct)
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/25
DOT
Other expense
Fund a curb replacement program. Additional
traffic
funding is needed to continue and accelerate a
improvements
curb replacement contract in conjunction with
requests
the Highways IFA resurfacing program to
include three crews which would include cement
masons and A.C.H.R's crew personnel. (1993-
project) There are quite a number of locations
within CB7s District that are missing curbs or
substandard ones. This program will help the
homeowners
11/25
DOT
Other expense
Support replacement contracts for deteriorated
traffic
bus pads. Community Board 7 with its 13 miles
improvements
of streets and 24 bus lines, many of the bus
requests
pads in the area are deteriorated - they have
either sunk or crumbled. The replacement
program must be accelerated in order not to
create a major liability for the city.
12/25
DOT
Conduct traffic or
Support additional Transportation personnel for
parking studies
field studies, crews for handling replacement of
missing and worn traffic signs, lane marking,
bridge maintenance milling and resurfacing.
13/25
DOT
Other expense
Fund Additional equipment for DOT vehicles for
traffic
inspections, field studies, utility trucks, bucket
improvements
trucks and machine counters. Additional
requests
vehicles for Arterial highways back up trucks,
rack trucks to handle trees pruning on the
highways.
25/25 DOT Improve parking
operations
Improve Parking Operations. The need for Muni- meters and Commercial Muni-meters will assist in the Shopping areas and allow for a turn around for both deliveries and shoppers. Muni- meters allow for more parking spots and the commercial muni-meters provide a turn aroundfordelivers and well as the City now receives revenue from the deliveries.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 7
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Forestry services, including street tree maintenance
Community Board 7 has 64 park locations, over 30 greenstreets, as well as a portion of Flushing Meadows Corona Park. Our residents are always concerned about the maintenance and care of their parks, as well as the care of the trees within each of these parks. Unfortunately the maintenance of the trees within Kissena Park resulted in the death of a pregnant woman. Our residents are always calling us to discuss the conditions of the equipment that their children use within the playgrounds, and many of our seniors call with regard to the tennis courts. Due to the fact that we have a lot of park properties, the leagues are always concerned about the maintenance of the ballfields, soccer and football fields.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
In each of our parks, where there is a parkhouse, the residents are always requesting that the park have a full time park person over seeing the cleanliness of the building, as well as the balance of the park. As part of our budget we have always supported the needed for supplies that are for the park funded daycare programs. Within our expense budget priorities we have always supported an increase in regular as well as seasonal personnel in order to handle the ongoing maintenance of our tennis courts, proper tree maintenance, pruning and removals, We have quite a few Joint operated parks that need constant maintenance since they abut the local schools, and unfortunately the custodians of the schools do not assist. The JOP's must be maintained by both the parks and the Department of Education. With the tremendous amount of parkland, our district has a full time gardener and two part time gardeners to deal with the upkeep of the grass and flower beds within each of our parks. The sidewalk tree program time must be accelerated. Residents do not want to wait several years to have the roots trimmed on a city sidewalk tree that is uplifting their sidewalks causing tripping hazards and a liability to the homeowner. Since we have a tremendous amount of parkland, many of our capital and expense budget submission are for the parks department either through upgrading of a specific park, or additional resources for the agency.
Needs for Cultural Services
Flushing being the home of religious freedom, we house a myriad of cultural institutions that play a vital part for our communities. We have Flushing Council on Culture and the Arts housed in Flushing Town Hall, Queens Botanical Gardens, Poppenhusen Institute, Kingsland House, the Louis Latimer House, and Volker Orth House. Each of these buildings have played a very important role in the history of Queens, and we must constantly support their survival These facilities provide music, art, and historical programs that our communities have requested, and they depend on financial help in order to address these requests. During a difficult budget year, their much needed funding has always been cut. Unfortunately these cuts result in an increase in monies that the patrons have to allocate. These institutions even though they are housed in our community, they serve the borough with programs of interest for all age groups, as well as ethnic populations.
Needs for Library Services
No comments
Needs for Community Boards
Community Board 7 is the largest population wise of all 59 community boards, in addition to being the most diverse world wide. In some instances our board serves over 150,000 more people than some Community Boards within the city. Even though we are a city agency, and we do appreciate the city picking up the cost of our rent, we still must pay for various service contracts in order for our agency to operate on a daily basis. In addition, the work load is tremendous due to the increase in population, development within the community - large scale developments - shopping malls and commercials establishments, we are working with 3 1/2 people including the District Manager. With a recorded population of over 250,000 documented people, and perhaps over 300,00 with
the undocumented, of which 1/3 are seniors, and 1/3 new Americans, many of which many do not have a command of the English language. This all takes more time, and while all boards receive the same budget, we feel this has a tremendous impact on our dedicated staff that works extremely hard to make sure that the needs of our residents are met.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/28
DPR
Reconstruct or
Reconstruction of Kissena Corridor Park. There is
upgrade a park or
a need to reconstruct the ballfield at Colden
amenity (i.e.
Street and Elder Avenue, in addition to the Little
playground, outdoor
league baseball/soccer field. In addition a
athletic field)
sidewalk must be installed on the 56th Avenue
side of the park. The park also needs addiional
benches, light poles, security and a designated
walkway from 56th Avenue to Colden Street
5/28
DPR
Reconstruct or
Reconstruction for MacNeil Park is needed to
upgrade a park or
include: (1) paths, (2) playground, (3)
amenity (i.e.
installation of sidewalk abutting the
playground, outdoor
Poppenhusen Avenue side of the park. (1993-
athletic field)
project)
9/28
DPR
Reconstruct or
Reconstruction of comfort station/park house
upgrade a park or
for Flushing Memorial Field. The existing
amenity (i.e.
parkhouse houses not only the pre-school office,
playground, outdoor
but their maintenance facility . This building is
athletic field)
necessary to support the existing sports facilities
within the park. (1984-project)
11/28
DPR
Reconstruct or
Reconstruct Frank Golden Park. This
upgrade a park or
reconstruction is necessary in order to
amenity (i.e.
rehabilitate and correct serious drainage
playground, outdoor
problems. After a heavy rainstorm, this athletic
athletic field)
field cannot be utilized for several days.
Continued funding is needed for the drainage
and Natural Turf Field renovations. Concern that
a private entity Shannon Gales was thought
than an infusion of money by them would help
with some of its problems however, they
maintained their own soccer field.
12/28
DPR
Reconstruct or
Reconstruct Kissena Park Phase III . Design and
upgrade a park or
rehabilitate the parkhouse abutting Kissena
amenity (i.e.
Lake. This parkhouse is utilized the pre-school
playground, outdoor
program. Phase IV is for the upgrade of the
athletic field)
paths and landscaping throughout the park.
Phase V is for the rehabilitation of outdated and
unsafe playgrounds throughout the park.
Specifically the playgrounds at 164th,160th, and
Booth Memorial Avenue. Phase VI is for the
construction of a comfort station in close
proximity to the Veledrome.
15/28
DPR
Reconstruct or
An architectural & structural assessment needs
upgrade a building
to be done in order to stabilize the building,
in a park
salvage the remaining details that dated to its
original 1829 construction. The Willets Farm
House will continue to be an important
contributing resource in the Fort Totten Historic
District & testament to the early development of
the borough.
17/28
DPR
Reconstruct or
Upgrade paths, lighting and proper signage for
upgrade a park or
Flushing Meadows Corona Park and Joe
amenity (i.e.
Michael's Mile. These two parks located within
playground, outdoor
our board area, need extensive path and
athletic field)
lighting rehabilitation since they are utilized by
our residents. The agency must seriously look at
these two locations to eliminate a potential
liability to the city.
19/28
DCLA
Renovate or
Increase funding for Poppenhusen Institute in
upgrade an existing
College Point to preserve its historic structure.
cultural facility
The building has sustained damage and needs
the installation of a handicapped service
elevator, including upgrading of electric, a
facsimile of a gas lighting system, safety
upgrades for a second means of egress to
include raised handrails. This Landmark facility
should be funded by the city and not individual
organizations as Poppenhusen falls under the
Department of Cultural Affairs.
20/28
DCLA
Renovate or
Continue upgrade of Queens Botanical Garden.
43-50 Main
upgrade an existing
Repairs are needed for additional service
Street
cultural facility
buildings as well as upgrading their
greenhouses to include emergency heating
systems. Additional bathrooms as well as
handicapped facilities are needed when these
service buildings are either upgraded or
replaced. Upgrades should be funded by the
NYC Department of Cultural Affairs. (1984
project)
23/28
DPR
Provide a new or
There is a need for a Nature/Environmental
expanded park or
Center to be located by the South West Corner
amenity (i.e.
of Meadow Lake in FMCP. This Center would
playground, outdoor
provide various groups i.e. birdwatchers, Boy &
athletic field)
Girl Scouts and students to utilize the Park in a
more organized environmental atmosphere.
This building which would need renovation was
originally utilized the boat storage.
26/28
DPR
Reconstruct or
Reconstruction and upgrade of College Point
upgrade a park or
Sport Park on Ulmer. Construction is to include a
amenity (i.e.
parking lot, sports lighting (night time) as well
playground, outdoor
as athletic Fields (track & football).
athletic field)
27/28
DPR
Improve access to a
Improve access to George Hugh Harvey Park at
park or amenity (i.e.
20th Ave. Provide Sidewalk installation on
playground, outdoor
Northern Blvd. service road & 20th Ave. for
athletic field)
safety & security of park patrons. Park is heavily
utilized by youth playing various sports or
utilization of playground and without sidewalks
both parents and youngsters end up walking in
the roadbed in order to use the park, thus
creating a very dangerous situation fro both
pedestrians & drivers.
CS
DPR
Reconstruct or
Reconstruct Little Bay Park. This includes several
upgrade a park or
phases - (1) rehabilitation of soccer/baseball
amenity (i.e.
fields, (2) installation of additional lighting
playground, outdoor
along the paths, (3) construction of a fitness
athletic field)
track. (1982-project)
CS
DPR
Reconstruct or
Meditation Garden at 56th Ave. & Colden Street
upgrade a park or
to be completed by the end of December 2019
playground
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
2/25 DPR Provide better park
maintenance
CB7-Qns supports an increase in regular, & seasonal personnel in order to maintain park locations, tennis courts, proper tree maintenance which include pruning & removal, Joint Operated Parks, PEP Workers, Green street location & playgrounds. A tremendous amount of parkland in CB7 seasonal workers and 21 POP workers will eliminate the full time and part time gardeners. Additional monies needed for sidewalk tree programs, maintenance & recreational staff & an operator for Parks Dept. Tram.
image
9/25 DPR Other park programming requests
Increase supplies and equipment for Parks. Items and programs for arts and crafts. As well as tools and equipment in order to maintain our parks, ie mowers, Bobcats vehicles, weed whackers, hand held blowers zero turn mowers.
17/25
DCLA
Support nonprofit
cultural organizations
Support Nonprofit Cultural Organizations -
Flushing Council on Culture and the Arts, Lewis Latimer House, Queens Botanical Garden, Poppenhusen Institute Bowne House and the Kingsland House. Request MORE funding for these institutes, In the City-Wide picture, Queens receives the least amountto ourCultural institutions than any of the other 4 Boroughs.
Queens should be getting it fair share.
18/25
QL
Extend library hours or expand and enhance library programs
CB7 is one of the most ethnically diverse communities in the city. It is necessary for our Libraries to have book and electronic equipment not only in English, but in the languages familiar to our newly arrived population.
21/25
OMB
Provide more community board staff
Agency response is that Community Board budgets are being increased. Recommend continue support
133-32 41st
Road Suite 3- B
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/28
DOT
Reconstruct streets
Reconstruction of 20th Avenue from the
Whitestone Expressway service to College Point
Boulevard, and 127th Street from 14th to 23rd
Avenues. This heavily utilized main artery within
our district connects the communities of
Whitestone and College Point, and also serves a
large shopping mall between these two areas.
The road has extensive flooding problems, and
existing roadbed is sinking. Major road
construction and sewer work is necessary in
order to bring these streets up to grade.
2/28
DPR
Reconstruct or
Reconstruction of Kissena Corridor Park. There is
upgrade a park or
a need to reconstruct the ballfield at Colden
amenity (i.e.
Street and Elder Avenue, in addition to the Little
playground, outdoor
league baseball/soccer field. In addition a
athletic field)
sidewalk must be installed on the 56th Avenue
side of the park. The park also needs addiional
benches, light poles, security and a designated
walkway from 56th Avenue to Colden Street
3/28
DOT
Reconstruct streets
Reconstruction of Union Street from Northern
Boulevard to 26th Ave. and from 26th Ave. to
Parsons Blvd.. This is a heavily used major
artery serving the southern end of Whitestone
into Downtown Flushing, utilized by trucks and
busses. The road, bus pads and pedestrian
ramps are badly deteriorated.
4/28
DOT
Reconstruct streets
Willets Point Phase II - This area has been
neglected by the city of New York and needs a
total Capital reconstruction to include
sidewalks, roadbed, sewers, and street lighting.
This area has extensive flooding problems and
the roadbed has sunk making it impossible for
drivers to navigate the area. Funding not
available is unacceptable as this project should
be funded by the city department's of DOT &
DEC
5/28
DPR
Reconstruct or
Reconstruction for MacNeil Park is needed to
upgrade a park or
include: (1) paths, (2) playground, (3)
amenity (i.e.
installation of sidewalk abutting the
playground, outdoor
Poppenhusen Avenue side of the park. (1993-
athletic field)
project)
6/28
DOT
Reconstruct streets
Reconstruction of Ulmer Street from the
Whitestone Expressway S.R to 25th Avenue. This
street which is a main access road into College
Point is collapsing causing drivers to lose
control. The roadbed must be surcharged, and
the sewers placed on piles in order for the street
to not collapse again.
7/28
DOT
Reconstruct streets
Reconstruction of 28th Avenue from Linden
Place to College Point Boulevard. This street is
an access road into College Point as well as the
Corporate park. The roadbed is collapsing and
possibly causing drivers to lose control. The
roadbed must be surcharged. and the sewers
need to be placed on piles in order for the street
not to collapse again.
8/28
DEP
Inspect sanitary
The construction and reconstruction of sanitary,
sewer on specific
storm and combined sewers Mitchell Linden
street segment and
area will help lessen the incidents of sewer
repair or replace as
back-ups and will assist in the draining of storm
needed (Capital)
and sanitary water. Problem sites 138th St. from
cross section at 31st Rd to 29th Rd. Also, 137th
St. from 31st Rd. at cross section to 32nd St.
along the Whitestone Expwy Service Rd. going
north betw Linden Place and 141st St.The
modernization of interlocker catch basins and
granite head catch basins will facilitate
maintenance within board 7 (1984-project)
9/28
DPR
Reconstruct or
Reconstruction of comfort station/park house
upgrade a park or
for Flushing Memorial Field. The existing
amenity (i.e.
parkhouse houses not only the pre-school office,
playground, outdoor
but their maintenance facility . This building is
athletic field)
necessary to support the existing sports facilities
within the park. (1984-project)
10/28
DOT
Improve traffic and
Implement recommendations of traffic study for
pedestrian safety,
College Point Corporate Park. Park rapidly
including traffic
developing and must move forward. It houses
calming (Capital)
the new Police Academy, two Sanitation
garages, the reconstructed Marine transfer
station, plus the myriad of buildings, and retail
components which adds to the present traffic
congestion. With the development, the traffic
study has focused on 1800 to 2000 coming to
the site, the back-up of traffic along 20th
Avenue extends into the community of
Whitestone. 1998-project
11/28
DPR
Reconstruct or
Reconstruct Frank Golden Park. This
upgrade a park or
reconstruction is necessary in order to
amenity (i.e.
rehabilitate and correct serious drainage
playground, outdoor
problems. After a heavy rainstorm, this athletic
athletic field)
field cannot be utilized for several days.
Continued funding is needed for the drainage
and Natural Turf Field renovations. Concern that
a private entity Shannon Gales was thought
than an infusion of money by them would help
with some of its problems however, they
maintained their own soccer field.
12/28
DPR
Reconstruct or
Reconstruct Kissena Park Phase III . Design and
upgrade a park or
rehabilitate the parkhouse abutting Kissena
amenity (i.e.
Lake. This parkhouse is utilized the pre-school
playground, outdoor
program. Phase IV is for the upgrade of the
athletic field)
paths and landscaping throughout the park.
Phase V is for the rehabilitation of outdated and
unsafe playgrounds throughout the park.
Specifically the playgrounds at 164th,160th, and
Booth Memorial Avenue. Phase VI is for the
construction of a comfort station in close
proximity to the Veledrome.
13/28
FDNY
Rehabilitate or
Rehabilitate or renovate existing Fire Houses &
renovate existing
EMS Stations. Due to growth in the number of
fire houses or EMS
housing units in CB7-Qns. upgrading the
stations
firehouse is of the utmost importance which
includes electrical system, plumbing, painting
throughout , and back-up diesel generators
(E295 & E297). Relates to four Engine
companies 274, 273, 297 & 295
14/28
DOT
Other
Muni Lot II located at 38th Avenue between
transportation
Main & Prince plays an integral role in the
infrastructure
economic development of the Flushing
requests
community. Rapid development has outpaced
Flushing's infrastructure. In order to meet the
demands & growth of the Flushing community a
multipurpose multilevel parking lot is required.
15/28
DPR
Reconstruct or
An architectural & structural assessment needs
upgrade a building
to be done in order to stabilize the building,
in a park
salvage the remaining details that dated to its
original 1829 construction. The Willets Farm
House will continue to be an important
contributing resource in the Fort Totten Historic
District & testament to the early development of
the borough.
16/28
DOT
Reconstruct streets
Implement Main Street redesign Phase IV.
Downtown Flushing street improvements,
sewer/water main replacement, curbs,
sidewalks, lights, and landscape. This area is to
include King Street,36th Ave, 36th Rd, 37th Ave,
and 39th Ave to College Point Boulevard.
17/28
DPR
Reconstruct or
Upgrade paths, lighting and proper signage for
upgrade a park or
Flushing Meadows Corona Park and Joe
amenity (i.e.
Michael's Mile. These two parks located within
playground, outdoor
our board area, need extensive path and
athletic field)
lighting rehabilitation since they are utilized by
our residents. The agency must seriously look at
these two locations to eliminate a potential
liability to the city.
18/28
DOT
Reconstruct streets
Construct College Point Boulevard between 14th
and 23rd Avenues. This location is the main
artery for the business district of College Point.
The road has extensive flooding problems, in
addition to street and sidewalk deterioration.
This road reconstruction is necessary to bring
this area up to grade.
19/28
DCLA
Renovate or
Increase funding for Poppenhusen Institute in
upgrade an existing
College Point to preserve its historic structure.
cultural facility
The building has sustained damage and needs
the installation of a handicapped service
elevator, including upgrading of electric, a
facsimile of a gas lighting system, safety
upgrades for a second means of egress to
include raised handrails. This Landmark facility
should be funded by the city and not individual
organizations as Poppenhusen falls under the
Department of Cultural Affairs.
20/28
DCLA
Renovate or
Continue upgrade of Queens Botanical Garden.
43-50 Main
upgrade an existing
Repairs are needed for additional service
Street
cultural facility
buildings as well as upgrading their
greenhouses to include emergency heating
systems. Additional bathrooms as well as
handicapped facilities are needed when these
service buildings are either upgraded or
replaced. Upgrades should be funded by the
NYC Department of Cultural Affairs. (1984
project)
21/28
FDNY
Upgrade
Complete & Upgrade of E.R.S. boxes will cut
communication
down on false alarms and provide better
equipment to
services in times of real emergencies. Will
improve emergency
eliminate wear and tear and waste of diesel fuel
response
on the rigs.
22/28
DFTA
Create a new senior
Funding must be obtained to allow the
center or other
Department for the Aging to develop additional
facility for seniors
sites within CB7-Qns. Our District has a senior
population with close to 90,000, & with the lack
of upgraded facilities this goal is hard to
accomplish. These sites must be developed
keeping in mind that our seniors are more active
& involved. In addition provide voucher program
for senior transportation.
23/28
DPR
Provide a new or
There is a need for a Nature/Environmental
expanded park or
Center to be located by the South West Corner
amenity (i.e.
of Meadow Lake in FMCP. This Center would
playground, outdoor
provide various groups i.e. birdwatchers, Boy &
athletic field)
Girl Scouts and students to utilize the Park in a
more organized environmental atmosphere.
This building which would need renovation was
originally utilized the boat storage.
24/28
NYPD
Provide a new NYPD
Over the years crime has increased in Flushing
facility, such as a
Meadows Corona Park. The Precincts
new precinct house
surrounding the park are too busy to assist with
or sub-precinct
regard to park security. If an incident was to
occur within the park the response time would
be significantly improved with the
establishment of a satellite precinct. Safety
must be our number one priority for the myriad
of families utilizing the park on a daily basis
25/28
NYCTA
Improve
Expand mezzanine portion of 7 line to Prince
39-07 Prince
accessibility of
Street to include an exit into 39-07 Prince Street.
St
transit
Board 7 passed a zoning change that in the
infrastructure, by
near future, downtown Flushing will see an
providing elevators,
insurgence of new development west of Main
escalators, etc.
Street. Recently a developer made a
commitment that if the mezzanine were
extended west they would allow and
entrance/exit into this building.
26/28
DPR
Reconstruct or
Reconstruction and upgrade of College Point
upgrade a park or
Sport Park on Ulmer. Construction is to include a
amenity (i.e.
parking lot, sports lighting (night time) as well
playground, outdoor
as athletic Fields (track & football).
athletic field)
27/28
DPR
Improve access to a
Improve access to George Hugh Harvey Park at
park or amenity (i.e.
20th Ave. Provide Sidewalk installation on
playground, outdoor
Northern Blvd. service road & 20th Ave. for
athletic field)
safety & security of park patrons. Park is heavily
utilized by youth playing various sports or
utilization of playground and without sidewalks
both parents and youngsters end up walking in
the roadbed in order to use the park, thus
creating a very dangerous situation fro both
pedestrians & drivers.
28/28
NYPD
Other NYPD
At present locker room are old and must be
facilities and
updated to accommodate the female officers
equipment requests
and new hirers.
(Capital)
CS
EDC
Make infrastructure
Improve and develop Flushing Airport site to be
investments that
utilized for soft recreational uses which would
will support growth
include using an aviation theme. site should
in local business
include uses such as a driving range, miniature
districts
golf, water park to enhance the wetlands, etc.
CB7-Qns. does not want to see heavy trucking
uses such as a manufacturing or a retail
component. (1980-project)
CS
DOT
Other
Reconstruct and Correct Drainage systems at
transportation
Casey Stengel Bus Depot located at 40-15 126th
infrastructure
Street, Flushing(1980-project) MTA is
requests
responsible not DOT
CS
DOT
Reconstruct streets
Expansion & upgrading of Flushing Airport
(FA308), realignment of Linden Place required
drainage retention pond. grade/curvature
adjustments necessary due to location of
drainage retention pond. Project abutted by
Flushing Airport, College Pt., Sports Complex &
Corp. Park. Roadways involves cracked, uneven,
& deteriorating. Linden Place has severe water
ponding condition w/non-existent curbs. There's
a need for marginal road to get traffic off the
southbound Whitestone Expwy. Svcs. Rd. (1998-
projuct)
CS
DPR
Reconstruct or
Reconstruct Little Bay Park. This includes several
upgrade a park or
phases - (1) rehabilitation of soccer/baseball
amenity (i.e.
fields, (2) installation of additional lighting
playground, outdoor
along the paths, (3) construction of a fitness
athletic field)
track. (1982-project)
CS NYPD Provide a new NYPD facility, such as a new precinct house or sub-precinct
Community Board 7 having the largest population of the 59 Community Boards, and one of the largest in geographic area, there is a need for an additional police precinct in our district. According to information the 109th precinct is 4th in the overall index crime complaints in the city, and first in Queens for radio runs ( approximately 6,000 per month).
The fair share allocation for manpower has to take into consideration the quality of life issues that the precinct has to deal with. This requires time and manpower of which our precinct is being stretched far beyond their limit.
image
CS DPR Reconstruct or upgrade a park or playground
Meditation Garden at 56th Ave. & Colden Street to be completed by the end of December 2019
image
CS FDNY Other FDNY facilities and equipment requests (Capital)
There is a need to develop a multi agency civic learning center to teach youngsters about safety issues as it pertains to fire, buildings, environmental protection, health, police and sanitation departments. In addition, these site could be used for seniors as a refresher center.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
DOB
Assign additional
Due to the increase of construction in CB 7,
building inspectors
there is a need to increase the number of
(including
qualified inspectors to expand the
expanding training
administrative tribunal to deal with the volume
programs)
of violations and to increase the number of
inside personnel to assist CB staff 8 additional
support staff, additional administrative staff and
additional inspectors are needed.
2/25
DPR
Provide better park
CB7-Qns supports an increase in regular, &
maintenance
seasonal personnel in order to maintain park
locations, tennis courts, proper tree
maintenance which include pruning & removal,
Joint Operated Parks, PEP Workers, Green street
location & playgrounds. A tremendous amount
of parkland in CB7 seasonal workers and 21
POP workers will eliminate the full time and
part time gardeners. Additional monies needed
for sidewalk tree programs, maintenance &
recreational staff & an operator for Parks Dept.
Tram.
3/25
DEP
Investigate noise
Money must be allocated to purchase noise
complaints at
mitigation equipment for the Agency to
specific location
measure the sound levels of pile driving & jack
hammering. With the accelerated new
construction going on in our district we have
been receiving an increase in complaints from
area residents regarding noise which presently
is been monitored & enforced by DEP.
Investigating noise complaints at specific
locations is needed. Tickets issued in 2018 - 93
and in 2019 - 92. Other agencies also issued
tickets ie: NYPD
4/25
DOT
Other expense
Fund a curb replacement program. Additional
traffic
funding is needed to continue and accelerate a
improvements
curb replacement contract in conjunction with
requests
the Highways IFA resurfacing program to
include three crews which would include cement
masons and A.C.H.R's crew personnel. (1993-
project) There are quite a number of locations
within CB7s District that are missing curbs or
substandard ones. This program will help the
homeowners
5/25
DEP
Clean catch basins
Additional maintenance staff is needed to
handle the increase number of street collapses
and to perform odor control monitoring at
water plants & staff to handle repairs for the
general cleaning and repairing of catch basins.
6/25
DSNY
Other enforcement
Additional personnel are needed to handle
requests
basket pick-ups on Saturday, Sunday & Holidays
on commercial strips. Maintain 5-day school
collection & twice weekly recycling collection &
sweepers. Plus household bulk must be opened
during the week to accommodate homeowners
who need access to the dump. If the household
dump is not accessible illegal dumping will
increase.
7/25
DFTA
Other senior center
As mention in the Capital Priority, the need of
program requests
Senior Centers is now at a status Quo, what is
needed is continued funding for the existing
Senior Centers as well as increasing the funding
to maintain the amount of seniors that are
using these facilities.
8/25
NYPD
Assign additional
Support funding for additional personnel to
uniformed officers
address quality of life complaints, maintain the
DARE program (workshop on drug education for
school children). Additional civilian personnel to
relieve officers assigned to the 109th precinct,
school crossing guards. Additional traffic
enforcement agents are needed to intensify
enforcement coverage. In addition, the K9 unit
dogs are capable of sniffing out drugs and
bombs.
9/25
DPR
Other park
Increase supplies and equipment for Parks.
programming
Items and programs for arts and crafts. As well
requests
as tools and equipment in order to maintain our
parks, ie mowers, Bobcats vehicles, weed
whackers, hand held blowers zero turn mowers.
10/25
NYPD
Other NYPD
Need funds for order boots for commercial
facilities and
trucks that park overnight in residential areas as
equipment requests
well a heavy duty tow truck for 18 wheelers.
(Expense)
Additional equipment Plate Readers, GLA
Trackers and Argus Cameras
11/25
DOT
Other expense
Support replacement contracts for deteriorated
traffic
bus pads. Community Board 7 with its 13 miles
improvements
of streets and 24 bus lines, many of the bus
requests
pads in the area are deteriorated - they have
either sunk or crumbled. The replacement
program must be accelerated in order not to
create a major liability for the city.
12/25
DOT
Conduct traffic or
Support additional Transportation personnel for
parking studies
field studies, crews for handling replacement of
missing and worn traffic signs, lane marking,
bridge maintenance milling and resurfacing.
13/25
DOT
Other expense
Fund Additional equipment for DOT vehicles for
traffic
inspections, field studies, utility trucks, bucket
improvements
trucks and machine counters. Additional
requests
vehicles for Arterial highways back up trucks,
rack trucks to handle trees pruning on the
highways.
14/25
FDNY
Expand funding for
Funds for Fire Department personnel and
fire prevention and
Training, Restoration of Fire salvage Unit Fire
life safety initiatives
Safety Education Unit Marine Units, Haz-Mat
Units as well as additional training in counter
terrorism
15/25
FDNY
Expand funding for
Provide funding for Fire House to upgrade them
fire prevention and
with backup generators, GPS for their
life safety initiatives
Apparatus,. Funding for Smoke and Carbon
Monoxide Detectors and CPR Kits for their Fire
Safety Education Unit.
16/25
DSNY
Provide more
Maintaining the weekly recycling program is a
frequent garbage or
necessity with the increasing population,
recycling pick-up
building growth and new products-i.e.: all
plastics, clothing and food waste. It's extremely
important to have weekly collections in order to
accommodate the anticipated growth of the
agency/population. Quota numbers need to be
increased.
17/25
DCLA
Support nonprofit
Support Nonprofit Cultural Organizations -
cultural
Flushing Council on Culture and the Arts, Lewis
organizations
Latimer House, Queens Botanical Garden,
Poppenhusen Institute Bowne House and the
Kingsland House. Request MORE funding for
these institutes, In the City-Wide picture,
Queens receives the least amountto ourCultural
institutions than any of the other 4 Boroughs.
Queens should be getting it fair share.
18/25
QL
Extend library hours
CB7 is one of the most ethnically diverse
or expand and
communities in the city. It is necessary for our
enhance library
Libraries to have book and electronic equipment
programs
not only in English, but in the languages familiar
to our newly arrived population.
19/25
FDNY
Expand funding for
Fire Marshals are the detectives for the Fire
fire prevention and
Department and are on the scene of a fire to
life safety initiatives
determine if arson is the cause. The evidence
must not be destroyed, and with the projected
opening of the base in Queens the backload of
open cases and arson fires will be reduced.
Request funding for Fire Marshal Personnel and
programs ie. the Juvenile Fire Setters
Intervention and the arson task force.
20/25
DOE
Other educational
Joint Education Programs between Board of
programs requests
Education and Parks Dept. It was felt that Parks
is funding a lot of the playgrounds and in most
cases they can't and refer back to the
Community Boards to get funding from the
Borough President's Office and Local Elected
Officials. It is requested that the Board of
Education provide fund on joint playgrounds.
The board has seen improvements but continue
supporting joint funding by both Agencies.
21/25
OMB
Provide more
Agency response is that Community Board
133-32 41st
community board
budgets are being increased. Recommend
Road Suite 3-
staff
continue support
B
22/25
EDC
Expand programs to
Funding is needed for the Local Businesses to
support local
assist them with the current rising cost business.
businesses and
entrepreneurs
23/25
NYCHA
Expand programs
Expand programs for Housing Inspections to
for housing
Correct Code Violations. Funding for Staff
inspections to
Attorney's to handle the backload of cases.
correct code
Cases are increasing each year by 7-8 per cent.
violations
24/25
HRA
Provide, expand, or
Provide, expand or enhance food assistance,
enhance food
such as Food Stamps/ SNAP as well as other
assistance, such as
programs such as Transportation Vouchers
Food Stamps / SNAP
Board 7 has a very high population of Senior
Citizens, immigrant adults an low income
Families. Any funding to assist in these areas is
recommended. Agency's response is that SNAP
is a Federal program however other programs
are not and fund should be provided to assist
them.
25/25 DOT Improve parking
operations
Improve Parking Operations. The need for Muni- meters and Commercial Muni-meters will assist in the Shopping areas and allow for a turn around for both deliveries and shoppers. Muni- meters allow for more parking spots and the commercial muni-meters provide a turn aroundfordelivers and well as the City now receives revenue from the deliveries.

