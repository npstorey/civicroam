- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 13 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1u9ZFtpN6Tq4wGo3rnidT1I303JCRaz-w/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1u9ZFtpN6Tq4wGo3rnidT1I303JCRaz-w/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
13
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 13
image
Address: 1201 Surf Avenue, 3rd Floor Phone: (718) 266-3001
Email: edmark@cb.nyc.gov
Website: www1.nyc.gov/site/brooklyncb13/index.page
Chair: Joann Weiss District Manager: Eddie Mark
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 13 is composed of Coney Island, Brighton Beach, Sea Gate and Gravesend, we are surrounded by water. We are a growing community with residential, commercial and amusement developments. We have a NORC population that has needs to be addressed, with a large immigrant community that also has special needs.
The Russian immigrants are moving into the NYCHA projects and high rise developments in Coney Island changing the needs of the area. There has been an increase of Pakistani and Mexicans immigrants moving into Brighton Beach. Also with our seasonal amusement area, the residents are forced to cope with increased traffic congestion and severely dwindling number of parking spaces. There has been many challenges with the rebuilding the infrastructure since Superstorm Sandy. Streets are torn up and the residents are not aware of the traffic delays. The community is not prepared for another Superstorm Sandy.
After Superstorm Sandy, we realized that the need to protect our shoreline must be our first priority. We need to have both short term and long term goals to fix the shoreline. Since the last Community District Needs request, the EDC, DDC and Parks Dept has made some improvements to the infrastructure. EDC finished their work on Coney Island Phase 3B on Neptune, Mermaid and Surf Avenues in upgrading the water main lines and the sewer lines.
This year, Coney Island Phase 2B continues to work on Neptune, Stillwell and Surf Avenues intersections and expected to be finish by next year. Other developments Coney Island Phase 2A will start later in 2019 and finish within two years on West 16th Street between Hart Place and Surf Avenue. The Parks Dept has continues to protect the shoreline by planting 5,000 sea grass along West 5th Street location. We hope they will continue this for the next couple of years to help with the entire shoreline. The long term solution, we need Army Corps of Engineers and the federal government and ORR to fund the project necessary to protect us if another disaster occurs with the installation of sea wall/float gates, etc.
According to City Planning, our Community District Profile indicates we have the largest senior population in NYC with 22.4% of the Community Board 13 being seniors. Their growing seniors, which must be address including additional senior housing, additional senior center and the needs for additional health care facilities, specifically geared to the senior population. The NORCs have more time on hand and the work experiences, we need to tap into this resource and expand on any intergenerational programs and mentorship with the seniors.
With the growing immigrant population in Community Board 13, we need to address ESOL services, immigration rights, DACA raids, ICE raids, etc. Community Board 13 has been working with city and local agencies and the Brooklyn Public library to bring attention to the issues in the immigrant communities. According to the NYC Planning Community District Profiles, we are in the top three in Limited English Proficiency. To combat this, we need more ESOL and conversation classes so that our residents can become more proficient in the English language. Since the 2020 Census is coming out next year, Community Board 13 will be encouraging people to be counted to get a better representation.
Currently, we have several new developments being built in the area. Four known development sites, each bringing in between 200-500 units per development will surely overtax the infrastructure with more cars, causing increased congestion and parking problems. More units mean more children and seniors coming into the area.
The existing schools and senior centers cannot handle the new population. These needs must be address before they move in. Upgrading the infrastructure includes the sanitary sewer lines that need to be able to handle the new developments. Two developments (Ocean Dreams and Surf Vets Apartments) will be opening in early 2020. As we are writing this report, the homeless shelter is being built in Coney Island. Residents are concerned with this project since they feel that their needs are not being addressed and the community will now be working with the new needs of homeless families.
We are also concerned about the increase in the flood insurance rate. We know it will increase dramatically and will affect the small homeowners, renters and businesses in the area. Build It Back is working on getting the elevation certificates to lower the insurance and hopes this option will help the insurance adjuster isolate the actual flood level for each building so the people will only have to pay for their proper flood level. Also, GOSR (Governor’s Office of Storm Recovery) has announced the back flow prevention project for homeowners to have installed to prevent water from coming into the homes through the sewer lines, this program has yet to be implemented. The FEMA still hasn’t release the flood insurance rate maps for the area.
The flood insurance rate increase will affect the high rise developments, too. Building management will have to pass the increased costs on to the renters through their monthly rents and maintenance fees. The NORC in these high rise developments are on a fixed income and will find it hard to pay the increase. With these increasing rates, the people will be forced out of their homes. We would call this insurance gentrification, where the neighborhood would change because of the increase of flood insurance rates.
The traffic problem in the area has gotten worse with the new developments. The City has chosen Coney Island as the next phase for the ferry system. What is unknown at this time is the location where the pier is to be built (either West 33rd Street/Bayview Avenue or Kaiser Park fishing pier). We still think it is better to put the pier along West 21st – West 23rd Street and Neptune Avenue. This will alleviate some of the traffic coming and going into Coney Island. We also accomplished in getting the F Express Train to commute into the city. We need to concentrate on making our subway stations ADA compliant with elevators such as F Train - Neptune Avenue, Q Train
– Ocean Parkway, etc. These stations are located near NORC population in our community.
We need to look at all the future developments and it impacts the traffic and parking in the area. After the infrastructure projects are completed, we need to see how all these developments effect the community.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 13
image
The three most pressing issues facing this Community Board are:
Infrastructure resiliency
Sandy Recovery and Future Resiliency: High-rise structures, notably those of the City's Housing Authority, evidence of the storm’s devastation – the presence of mold, the shuttered community centers, abandoned homes, empty stores and civic facilities. Emergency generators, brought in after Sandy, are still in place at some NYCHA buildings, and they cannot provide the need for residents when temperatures fall below 40-degrees. Homes need to be elevated to avoid the next flooding. The shoreline is our other concern. Nothing has been done to protect us from the next superstorm. We need short term solutions such as planting beach sea grass and putting in dunes along the shoreline. Long term projects, will have to deal with the Army Corp of Engineers to build a sea wall in the Rockaway Inlet.
Street conditions (roadway maintenance)
Improve Infrastructure: Currently, there are plans to construct 6 large residential developments in our community. Each development has between 200-500 units. We need to upgrade our infrastructure to sustain the new developments. The sewer lines need to handle the new load of people moving into the neighborhood. As mentioned below with traffic, these developments do not provide adequate parking and therefore the new residents will be forced to find street parking. The school system must accommodate the new families coming into the area which means building new schools or expanded ones already here either alternative will take time and money. Additional senior centers catering to the expanding NORC population needs to be built.
Traffic
Traffic is one of the overwhelming problems in the peninsula. Motorists coming in and out of Coney Island, Brighton Beach, Sea Gate and Gravesend find themselves trapped in become clogged with vehicles looking for few empty parking spots. There is limited amount of parking spaces and parking lots once they are filled up the streets. The motorists circle around the area looking for spots when there are none, causes a traffic nightmare. In addition, emergency vehicles of Fire, Police, ambulances, EMS may have difficulties as well. One solution is to implement the ferry system to Coney Island. This would partial alleviate the congestion coming into the area, and would give people an alternate route of getting out of the area.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 13
image
M ost Important Issue Related to Health Care and Human Services
Other
C1 Trauma Unit for Coney Island Hospital
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Community Board 13 needs a C1 Trauma Center in Coney Island Hospital. Our hospital needs to address the growing population in the area. Time is of essence when a trauma patient is taken away from the area. If there was a C1 Trauma Center incorporated into Coney Island Hospital would cut down in time for helping the patient. We understand that this is not a City Budget item but we need to make this aware to the city, state and federal government, that this is a priority for the neighborhood. There is a growing immigration population. They are either unaware or afraid to enter a hospital because of a language barrier or afraid of deportation. The neighborhood health facilities has to conform to the neighborhood and outreach to the immigrant in their native language or the patient will not come. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: - Funding is needed for Coney Island Hospital to handle the growing population and has to keep up with the medical needs in the area, such as obesity awareness, diabetes prevention program, cancer awareness, high blood pressure reduction program, living with asthma, improving pediatric care, preventing heart disease, etc. - With a growing population, Coney Island Hospital has to meet up with the demand. Funding must continue to keep up with medical needs and expand the hospital wherever it is possible. - We need to promote quit smoking programs for the immigrant community. The program must be translated into other languages to reach the target audience.
Needs for Older NYs
Community Board 13 is a growing Naturally Occurring Retirement Communities (NORC). Community Board 13 has the largest senior population in NYC! With an aging community, we have to address the needs to this growing population. We find the older residents tend to live independently with their services nearby. As household size decreases and income is fixed, the residents downsize their apartments and remain in the area. Health care providers are needed to check in to see if everything is okay. Senior centers have grown giving the residents something to do during the day. With new housing developments coming into the neighborhood, there will be some senior residents occupying the new units. The new seniors will need additional senior services and overtax the existing senior services. The City has to build new senior centers or combine them with recreation center to create an intergeneration recreation center to bring the generation gap closer together. There is a large Asian population that uses the JCCGCI center on West 37th Street where the clients come from all over the borough. Their needs are different in culture and traditions and would great to integrate with the rest of the community. A multicultural center would be able to address the growing Asian senior population. More senior services are needed in the neighborhood.
Needs for Homeless
There has been an increasing amount of seasonal homelessness in our community. Homeless people come down during the warmer months but never seem to leave until the weather becomes brutally cold. We need to address this problem year round. We DO NOT need a homeless shelter to address this problem because the community already has SEVEN (7) NYCHA developments in a half mile radius. Coney Island has been the dumping ground for low income families and we do not need to oversaturate the area with a homeless shelter. We are slated for affordable housing in our area and a veteran housing development. We do not saturate the area with more low
income developments. The City needs to address the existing problems in the neighborhood before receiving a new shelter. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: More rental assistance program is needed to help the homeless people in the community. We need anti-eviction legal services to prevent people from becoming homeless. We continued to support increase personnel Dept. of Homeless Services/Breaking Ground. More personnel is needed due to the increase of homeless people in the community. We need to expand street outreach to handle the seasonal homeless during the summer months.
Needs for Low Income NYs
We need to help the low-income and vulnerable people in our community by providing job training, placement support, food assistance such as Food Stamps, improve delivery of emergency food and shelter in case of disaster. We also need to provide social services to domestic violence survivors and provide case management for persons living with HIV or AIDS. With seven NYCHA developments, there are not enough programming to address the issues. We DO NOT need a homeless shelter, it would burden the area with more problems. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: We need to expand our job training for the community. We have Workforce1 for Sandy victims, but we need to make it a permanent program. We need to have a training/vocational center to teach the people a skill. We need to expand our job search and placement support for the community. We have Workforce1 for Sandy victims, but we need to make it a permanent program. It is vital to make the people job ready and to keep the job with placement support. In our low-income neighborhood, we need to expand food assistance for getting healthy choices to the people.
There is a need to provide social services for domestic violence survivors. The community needs more information for the victims to know their rights. We need to provide case management, cash assistance and social services for people living with clinically symptomatic HIV or AIDS. With no community based organization dealing with the HIV/AIDS issue we need funding for community.
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
10/34
HHC
Other health care
A C1 Trauma Center is needed in Coney Island
2601 Ocean
facilities requests
Hospital. With the increasing population due to
Parkway
new housing development and the influx of
tourists during the summer time, we need a C1
Trauma Center in the neighborhood. We
understand that this is not a City Budget item
but we need to make this aware to the city,
state and federal government, that this is a
priority for the neighborhood.
19/34
DFTA
Create a new senior
With the growing senior population in the
center or other
district, we need more senior centers. Public
facility for seniors
land is limited in the area. A multi-use facility
must be built as a multicultural,
intergenerational, recreational center on City
owned land. There is park land/city owned land
that can be develop by Mark Twain JHS
(pumping station/handball courts/park circle,
etc.) into this needed facility.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
5/48
DOHMH
Reduce rat
Increase personnel for Rat Abatement. There
populations
has been a large increase of rats being displace
by the new construction, they are running into
existing buildings and causing problems to the
neighborhood. We need to do a district wide
abatement to tackle the rodent problem.
8/48
DFTA
Enhance NORC
We need to address NORC programs and health
programs and
services to assist the aging population.
health services
10/48
DOHMH
Other programs to
We need to address air quality issues in the
address public
NYCHA developments in Coney Island. We
health issues
realized that the properties did not properly
requests
eliminate molds from their buildings. People
who are sensitive to molds are become sick and
we need to test the air quality at these
locations.
11/48
DOHMH
Create or promote
We need to emphasize on more educational
programs for
programs dealing with obesity, healthy eating,
education and
nutrition, etc.
awareness on
nutrition, physical
activity, etc.
18/48
DOHMH
Other programs to
We need to address teen pregnancy for our
address public
community. More programs in schools and in
health issues
the community to bring attention to the issue.
requests
Are each JHS and HS in our district equipped to
handle teen pregnancy issues?
19/48
DFTA
Other services for
Increase personnel for Home Bound programs
homebound older
for disabled seniors. Due to the increasing NORC
adults programs
population, home bound programs for seniors
are needed.
27/48
DOHMH
Other programs to
Continued to support to promote flu shots,
address public
measles shots and other immunization for the
health issues
immigrant community. The outreach must be
requests
translated into other languages to reach the
target audience. It must be explain to them that
it is essential to vaccinate the family in order
not get sick or die. There are growing Asian,
Pakistan, Hispanic and Russian community that
needs translation for immunization programs.
31/48
DOHMH
Other programs to
Continue Support - There needs to be a drug
address public
prescription awareness campaign for the
health issues
community. Families need to know if there is
requests
any CBO to address this problem.
44/48
DFTA
Increase
Fund Jewish Community Council of Greater
transportation
Coney Island Senior Citizen Transportation
services capacity
(Project Ride) and other access a ride services
for the Frail Elderly population. Traveling for
seniors are limited due to their limited mobility.
More funding are needed to address this in a
growing NORC area.
45/48
DOHMH
Reduce mosquito
With the Nile virus and the Zika virus we are
populations
surrounded by the bodies of water in our
community. We would like to reduce the
mosquito populations and also inform the public
about the hazard of standing water. This year,
our zip code s(11224, 11235) were not covered
in the spraying of the area, our surrounding
neighbors were sprayed but not our area.
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 13
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
After Superstorm Sandy, our community centers and other community facilities were destroyed. Our youth had no place to go for after school programs or community centers to keep them occupied. With that there were no place for youth to go to, there are no place for a workforce development. We have a Workforce1 for Sandy Victims but we need more with training center for the youth in the area.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Our biggest concern in our neighborhood is reopening our community center that was destroyed by Superstorm Sandy. After four years, some community centers are still closed and need to reopen soon. The youth have no where to go and limited resources out here to occupy them during the year. Wokforce1 has helped the young adults but the community centers are need for the children. Safe community centers need to be rebuild and made resilient to address the needs of the area. A long term solution is to build a recreational center to address this need that would be intergenerational, multicultural, educational, multi-use recreational facility. This could be tied into the ferry system along the Coney Island Creek making it a ferry terminal and a boathouse to do water activities. There are programs that have been funded in the current year. We would like these funding to continue until completed with the following requests: A full library are needed in our schools. The current library are not well stock and being under utilized. With the school giving healthier choices to students during meal times, it is need to explain to them that it is a life choice to make. Giving the youth nutritional program to educate them on what is healthy and what is junk food is greatly need. Also, we would like to look into the greenhouse garden to have the youth understand where the food is coming from and how they can prepare healthy for that they have grew will give them an idea where the healthy foods come from.
Needs for Youth and Child Welfare
The early stages of child development is very important and we need quality childcare services in our daycare and head start centers. We need to rebuild childcare centers and improve on their service. After Superstorm Sandy, childcare and head starts center were destroyed and had to be rebuilt. Some are still not rebuilt and the void needs to be filled. The centers are either doubled up or ceased to exist. We have to rebuild or build new centers to have quality childcare services. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: We need to expand options for kinship foster care services to help family integrate the child into their new environment. We need juvenile justice programs and preventive services in our neighborhood. Since Superstorm Sandy, our juvenile justice programs in our neighborhood has been reduced due to the fact that the church was hit by Sandy no longer can host the program. Another location or until the church fixes their building, we need more programs. We need to expand preventive services to avoid future delinquents in the community. All child care centers were affected by Superstorm Sandy needs to be renovated and upgrade to avoid future disaster. Continued support to Increase personnel for monitoring of day care centers The community needs adequate funding for preventative and child protection services. In low-income neighborhood, child protection services generally gets overlooked. We need to provide funding for youth program for 18 to 21 year olds who have aged out or been discharged from foster care services because at that age, the young adult has not been fully adapted to their new environment and without an education, they are likely not to get a high paying job. They will become the new homeless in our community.
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
7/48
DOE
Improve school
There is a need to improve school safety with
safety
security guards and crossing guards around the
schools. With the increase violence in the
neighborhood and children bring in weapons,
there has to be better school safety for the
schools. We have to educate the youth to
respect each other and not resort to violence.
There should be a program dealing with anti-
violence, anti-bullying and cyber-bullying for the
children. We need to get the elected officials
and the D.A. office involve with this problems.
15/48
DYCD
Provide, expand, or
We need to provide adolescent literacy
enhance adolescent
programs and services for our young adults. We
literacy programs
need to give them a chance to get a GED
and services
diploma to get to the next level.
16/48
DYCD
Provide, expand, or
Community Board 13 has a growing
enhance English for
population of immigrants. We need to address
speakers of other
their concern and issues. English as a second
languages (ESOL)
language services are needed.
services
17/48
DOE
Assign more
With the overdevelopment of our community
teaching staff
and the overcrowding in classrooms, there is a
need for more qualified teaching staff. We
cannot justified overcrowded classrooms and
not have enough teachers for the classes. We
need to expand the budget for hiring teachers.
21/48
DYCD
Provide, expand, or
We need to expand the skill training and
enhance skills
employment services for high school students at
training and
risk of dropping out. We have an alternate high
employment
school that is filled and need to be expanded
services for high
and enhanced.
school students at
risk of dropping out
22/48
DYCD
Provide, expand, or
We do not have a fatherhood programs for non-
enhance fatherhood
custodial fathers. Our nearest program is in
programs for non-
Kingsborough Community College. We would
custodial fathers,
like to have one in our community
e.g. parenting skills
training
24/48
DOE
Other educational
We realized that the performing and cultural
programs requests
arts have been cut out from the curriculum. The
children have no place to express themselves
except through academic and sports. Their
creative learning has been cut off and it is
desperately needed.
41/48
ACS
Provide, expand, or
We need to enhance housing assistance for
enhance housing
youth that are leaving foster care. We
assistance for youth
understand that at the age of 18 the young
that are leaving
adult does not have a secure job to afford an
foster care
apartment, or some type of housing assistance
is needed or supplemented to the rent.
48/48
ACS
Provide, expand, or
There is a need to provide funding for higher
enhance funding to
education and/or workforce development
support higher
opportunities for youth who are leaving foster
education and/or
care. We see youth without a college degree or
workforce
trade skills to compete for a job. We feel at least
development
a CTE (certified technical education) degree
opportunities for
would offer them a skill once completing.
youth who are
leaving foster care
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 13
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
In our district, we are number one in crime reduction in NYC. With youth crime and gun violence are down in our neighborhood, we now can concentrate on the quality of life issues such as traffic congestions and parking problems. We still need to address the youth crime due to the lack of community center destroyed by Superstorm Sandy. Youth are hanging out on street corners with no place to go need a safe place to play. With the hot summer days or big events in the area, we have traffic problems in getting people in and out of the area. People are held hostage trying to leave the area and cannot find parking when they returned home. We need to address this as a safety concern when emergency vehicles cannot move through the neighborhood without being stop by traffic.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
A summer detail is made available for the 60th Precinct, but growing crowds indicate that added personnel is needed. We additional uniformed officers to keep law and order in community that has summer crowds in the thousands. The community is neglected when the officers are diverted to control the crowds. We need traffic enforcement officers to help direct traffic coming and going out of the area. We need them to keep the traffic flowing and ticket motorist from double parking and illegally blocking traffic in the area. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: - Continue support for additional staff to address specific crimes such as drug, gang-related issues. - We need to continue to support resources to train officers in NCO to help with better relationships with the community. - We requesting to have heavy duty equipment such as heavy duty helmets and vest. With huge crowds in the summer time, we feel that it is an easy target to terrorist attacks and we should be equipment to handle the situation.
Needs for Emergency Services
Our community stress highly on emergency/disaster services needs. Ever since Superstorm Sandy, we have found ourselves vulnerable to the environment and the increasing developments around the area. We need to be prepared for any situation whether it be another Superstorm Sandy, or a blizzard or even a blackout we have to protect our community. We need to have a local emergency center for emergency/disaster.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
6/34
NYPD
Provide surveillance
We need surveillance cameras to help our
cameras
precinct to monitor high crime area.
9/34
NYPD
Renovate or
We need to renovate the 60th Precinct station
upgrade existing
and make it ADA compliance and expand the
precinct houses
area. People cannot get to the second floor
without an elevator and there isn't one
available. Also there is need to expand the
community meeting room on the second floor.
21/34
FDNY
Upgrade
We need to upgrade communication equipment
communication
to improve emergency response such as
equipment to
digital/wifi towers.
improve emergency
response
23/34
NYPD
Other NYPD
We need to purchase heavy duty bicycles for our
facilities and
Auxiliary Police Officers to help patrol the area.
equipment requests
(Capital)
24/34
NYPD
Other NYPD
We a growing population heading to the beach,
facilities and
we need a harbor patrol to handle jet skiers
equipment requests
from coming too close to the shoreline. Also
(Capital)
needed are safety buoys to delineate the 500
feet zone from the beach so jet skiers will know
not to approach the shoreline.
CS
FDNY
Rehabilitate or
Repair buildings in Battalion 43
renovate existing
fire houses or EMS
stations
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
33/48 NYPD Assign additional
school safety officers
We need to assign additional school safety officers to the community to teach the children about safety in the street.
image
34/48
NYPD
Assign additional crossing guards
We need assign additional funding to hire full time crossing guards for the school to keep the children safe.
35/48
NYPD
Assign additional
Added traffic-control personnel to move
Neptune
traffic enforcement
motorists eastward to Ocean Parkway
Avenue
officers
entrances to Belt; To curtail bumper-to-bumper
Ocean
traffic on Neptune Ave. to Cropsey Ave. during
Parkway
busy hours. Also, we need to address Brighton
Cropsey
Beach Avenue and Coney Island Avenue and
Avenue
Surf Avenue, too.
37/48
NYPD
Assign additional
We need more traffic enforcement officers and
traffic enforcement
traffic officers to direct the traffic flow in the
officers
area.
38/48
NYPD
Assign additional
We need additional uniformed officers for our
uniformed officers
community. With the growing developments,
are facing a population boom. We need
additional uniformed officers to help keep down
crime.
39/48
NYPD
Increase resources
We need to increase resources for youth crime
for youth crime
prevention programs such as Explorers
prevention
Program. We need to offer the youth more
programs
positive activities and not to fear law
enforcement officers.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 13
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Protective Infrastructure (sea walls, flood walls, etc.)
After Superstorm Sandy, the community realized that our shorelines were not protected and we must protect our infrastructures. Short terms goals such as sand dunes, are needed for immediate protection. Long term goals such as living breakwaters will take time to implement and construction. We need to proceed with a definitive plan for the area, so that another hurricane season doesn't pass by without preventive measures in place.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Our biggest issue to protect our shoreline from the next disaster. After Superstorm Sandy, we realized how vulnerable our shoreline are during a hurricane. We need to upgrade and maintain our sewer lines. Currently, DDC is upgrading our sewer line from West 15 Street to West 24 Street, we need to continue this throughout the whole community. We found out the City does not have funds to relocate our sanitation garage to the National Grid property by the Coney Island Creek. We have been waiting since 1983 to move this garage which will house two sanitation district. We will put this in as a top proirity for the area. There are programs that have been funded in the current year. We continue support to clean our catch basins throughout our community. We realized when Superstorm Sandy inundated the area with water, the catch basins backed up because they were never properly cleaned. We need to continue to expand the noise abatement programs and enforcement programs in the community. With our amusement area, there tends to have vendors who blast their music into the community. We need to have enforcement come out to fine these vendors who do not comply.
Needs for Sanitation Services
Construction of Sanitation Garage for Community Board 13 has been promised to the community since 1980. The current is site is on West 21 Street and the trucks are situated behind people's backyards. We heard earlier this year that the funding was not available for the garage. We are still interested in moving the sanitation garage to the new location. It will house two garages (BK13 and BK15) at the new site. We need the City to put the funding back into the relocation of the garage. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: We need to continue to clean up the vacant lots that are privately and city owned lots. We need to have the lots cleaned to show the community that we are not here to be dumped on. Continue to support Sanitation Police Illegal Dumping Task Force We continue to support enforcement of dirty sidewalk, dirty area, and failure to clean area laws. Property owners and commercial owners need to know they are responsible to keeping their area clean. We need enforcement officers to keep on top of the litter. We need to increase enforcement of illegal posting laws. We need to educate groups that it is illegal to do posting on certain poles. Also, we need to fine the distributors so they understand where they can post. We would like to continue support for NYC organics collection programs for our neighborhood. We understand that composting organic items will be keep the environment cleaner. We need to provide more frequent organics and recycling collection service for schools and institutions. With the collection of the organic items, they tend to decompose quickly and the smell cannot be housed in the location for too long before it becomes a health hazard. We need to improve snow removal by purchasing snow equipment to clear the streets.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/34
DSNY
Provide new or
Construction of Sanitation Garage for
2012
upgrade existing
Community Board 13 has been promised to the
Neptune
sanitation garages
community since 1980s. The current site on
Avenue
or other sanitation
West 21 Street and Neptune Avenue, are
infrastructure
situated behind people's backyards. Since
Superstorm Sandy Community Board 15
garage had been damaged, too and was to
merge the two garages together. Earlier this
year we heard the funds for the relocation was
stopped. We need to move this back into the
Capital Budget and make it a high priority to
fund this project.
4/34
DEP
Inspect sanitary
We need to repair and expand our sanitary
sewer on specific
sewer lines. Since Superstorm Sandy, our
street segment and
sanitary sewer lines were not able to handle the
repair or replace as
water levels of a hurricane. The older sanitary
needed (Capital)
sewer lines need to be expanded/replaced
throughout the community.
8/34
DEP
Evaluate a public
We need to provide new green infrastructure
location or property
such as stormwater green streets and green
for green
playgrounds along the shoreline. We realize
infrastructure, e.g.
that short term solutions are needed until the
rain gardens,
long term plans are approved and financed.
stormwater
greenstreets, green
playgrounds
11/34
DEP
Develop a capital
Coney Island infrastructure is currently being
project for specific
upgraded from West 12th Street to West 21st
street segments
Street. We need to continue to upgrade the
currently lacking
remain sewer lines to West 37th Street.
sanitary sewers
12/34
DEP
Develop a capital
Brighton Beach area needs to repair and replace
project for specific
the old sanitary sewer lines. The targeted area
street segments
is from Ocean Parkway to Corbin Place, from
currently lacking
the Belt Parkway to the boardwalk.
sanitary sewers
CS DEP Evaluate a public location or property for green infrastructure, e.g. rain gardens, stormwater greenstreets, green playgrounds
We need green infrastructure projects throughout the community. Since Superstorm Sandy, we realized that our infrastructure could not handle the overflow of water on the sewer lines and we need to fix it. One project is to have green street gardens to handle the excess rain water. Strategically placed green street gardens will be able to assist and handle the onslaught of water.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
12/48
DEP
Investigate and
We Need more DEP Inspectors for industrial
address water
waste and water lines. Since the illegal dumping
quality complaints
from Beach Haven Apartments, the community
at an address or on
is concern about future dumping from other
specific street
developments and industrial businesses. For our
segments
water quality of the creek, we need to find the
illegal connections to the creek and have them
closed off or repaired.
23/48
DSNY
Increase
We need to increase enforcement of canine
enforcement of
waste laws to catch the dog owners in the act of
canine waste laws
littering the street. People need to be fined
enough times to make them understand that
they have to curb their dogs.
32/48
DSNY
Provide or expand
We need to get the information to the high rise
community
buildings for composting programs for our
composting
neighborhood. There seems to be some
programs
resistance among the management companies
in complying with organic composting program.
36/48
DSNY
Expand disposal
We need to expand disposal events for
events for
hazardous household waste. We would like to
hazardous
have the event locally so people do not have to
household waste
travel half way across Brooklyn to dispose
hazardous items.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 13
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Commercial district revitalization
Commercial district revitalization is important in our neighborhood. We lack the basic stores for the local residents. They have to travel outside of the area to do their shopping needs. New developments are being built, trying to incorporate retail store on the ground level and residential unit on the upper levels. The commercial district revitalization is needed to boost up the neighborhood and keep the business at bay. We need to look into a BID for the area to handle the commercial issues in retaining them and entice new businesses to come into the area.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
We need to have more building inspectors to enforce the building codes in the neighborhood. Illegal conversions of buildings are being subdivided and are not up to code. It is a health and safety concern dealing with unlivable conditions and fire hazard with overloading the existing utilities. We need to do a land use study to see what is present and available and what is needed for the future. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: Increase compliance division – Dept. of Buildings - We continue to support the need to assign additional building inspectors for code enforcements because property owners are constructing illegal conversions in the area and needs to be fined and stopped. We continued to support the need to address illegal conversions and uses of buildings. We get complaints from the neighborhood, and it needs to be resolved.
Needs for Housing
Our concern in our community board for housing is our area is being overdevelop with apartments. Property owners are building apartments on a small parcel of property. We are oversaturated with large developments that our infrastructures made not handle the increase. Our concern is with traffic flow and parking. With new developments, there isn't enough adequate parking space to accommodate the renters. We need to continue to address the housing issues in the area by support our local housing groups. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: - Continue support for Home Improvement program, Article 8A and PLP Loans - We need to expand programs for housing inspections to correct code violations in the high rise building. Management needs to correct violations in a timely manner or receive hefty fines for not being in compliance. - Continued support to expand tenant protection programs letting tenants know their rights. We need to support our existing housing groups and expand their services to the tenants.
We need to renovate and upgrade public housing developments. Since Superstorm Sandy, there are items still not fix, such as boiler system, community centers and other basic needs. - We need our community centers in NYCHA developments to be repaired and opened. Since Superstorm Sandy, our community centers have been closed and our youth have no where to play. - We need to improve public housing maintenance and cleanliness throughout the NYCHA developments. The lobby area needs to be kept clean and the grounds need to be tidy. - We need to work with management with the office hours. We have renters who cannot meet during business hours without taking a day off. Extended nights and weekend shifts should be accommodating to the developments. Also, translation on notices are needed for people to read in their native language.
Needs for Economic Development
We need economic development to the area to stimulate the community. With economic development comes jobs for the community. It will help the local economy and bring new business into the area. With the development of residential and commercial projects, we have to remember of the traffic problems, limited parking spaces and other infrastructure issues. We cannot develop without looking at the existing infrastructure and how it will impact on our limited services. There are programs that have been funded in the current year. We would like these funding to
continue with the following requests: We need to improve our streetscapes in business district to attract and encourage commercial activities. We also need to make the street lights and tree beds more resilient to future storms. We would like to have the street light run on solar panels so they are not dependent on the power lines. The tree beds can be made into bio swales to collect the run off water before hitting the main sewers. We need to expand access to low cost financing to help neighborhood businesses construct or improve space. We know it is hard to obtain business loans for store improvements, we need to make it easier to apply and approve them. We need to support non-profit organizational development and capacity building for improving the commercial strip. After Superstorm Sandy, we need to provide business recovery assistance after an emergency. The community realize that we were not prepared to help our businesses after an emergency. We have youth that have not graduated from high school and can't get into college without job skills or job training. Workforce1 helps youth and adults in employment services but we also need to provide them with skills. Support for Job Training programs in
C.B. 13. We need to expand occupational skills training programs to help our local residents. We need to support recruitment and hiring of employees in our neighborhood. We need to continue to support Workforce1 . We need to improve disaster preparation for small businesses. After Superstorm Sandy, businesses were not prepared to handle a disaster. We need to programs to support local businesses and entrepreneurs. After Superstorm Sandy part of the neighborhood had a hard time re-opening their businesses and decided to close their stores. Since then, it has been a hardship to repair their stores and attract new businesses to the area. We need to address these issues. We need to support immigrant, minority, veteran and women-owned, as well as local and new businesses. We understand the minority are the hardest to work through the system, whether it be discrimination or a language barrier, we need to fix it. We need to provide assistance for minority women-owned businesses and small businesses in responding to bids and request for proposal. The businesses have to understand the process of working with the system to bid on proposals.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation Location
13/34
NYCHA
Install security
We need to install security cameras in the
cameras or make
NYCHA developments. We have gun violence in
other safety
the developments, we need extra eyes on the
upgrades (Capital)
buildings to make the area safer.
22/34
EDC
Make infrastructure
With the rise of smartphones and other
investments that
portable electronic devices, we need to improve
will support growth
the availability speed and cost of broadcast
in local business
access to local businesses and residents.
districts
28/34
EDC
Build or expand
We need to build an incubator/research lab
incubator or
spaces to entice small businesses to grow. We
affordable work or
increasing rental space price and huge overhead
research lab spaces
cost to start a business, an incubator can
address these issues.
CS
EDC
Invest in capital
We need a ferry study for Coney Island. We need
projects to improve
to invest in our piers and other capital project to
access to the
improve access to the waterfront. We realized
waterfront
that if there is a problem with traffic and
parking, one solution is to use our waterfront.
We would like to build a ferry terminal along the
Coney Island creek at West 23rd Street. This
would address local commuters to use the ferry
to get to Manhattan for the price of a
Metrocard. During the summer, this would be
an alternate way of getting into Coney Island
without using a vehicle.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
4/48
DCP
Study land use and
We need to study land use and zoning to better
zoning to better
match current use or future neighborhood
match current use
needs. With all the residential and commercial
or future
development, the community needs to know
neighborhood
what its plans are coming into the area and
needs
have an input is needed.
9/48
SBS
Conduct BID
We currently have a BID in Brighton Beach and
Feasibility Analysis
it is successful in the area. We are looking to
or support BID
form a BID in Coney Island to handle the
Formation Planning
commercial and amusement area.
for a selected
commercial district
13/48
SBS
Support
We need to support storefront/facade
development of
improvements for the area. After Superstorm
local Storefront /
Sandy, businesses had to clean up the damages
Facade
and had no monies for storefront
Improvement
improvements.
Program
14/48
EDC
Improve public
We need to improve our public markets. We
markets
currently have two location and need to bring
more to the area.
20/48
EDC
Expand tax incentive
We need to expand tax incentive programs to
programs to help
help neighborhood businesses construct or
neighborhood
improve space. This would help entice
businesses construct
businesses to come into the area.
or improve space
26/48
SBS
Support local CBOs
We continue to support the need to provide
efforts to provide or
retail attraction and retention assistance to
expand retail
revitalize the commercial strip in the area.
attraction and
retention assistance
28/48
NYCHA
Provide emergency
We continue to support emergency housing for
housing for
households displaced by fires or City-issued
households
vacate orders. Tenants need to be house in
displaced by fires or
other locations while repairs are made.
City-issued vacate
orders
40/48
SBS
Other expense
We need to expand financial incentives for job
workforce
creation and retention to have local businesses
development
hire local residents.
requests
42/48
HPD
Provide, expand, or
We need to continue support to provide
enhance community
community outreach on HPD programs and
outreach on HPD
services i.e. CCC program. Our housing groups
programs and
are in need of funding for the area to help the
services
tenants, homeowners and landlords.
TRANSPORTATION
Brooklyn Community Board 13
image
M ost Important Issue Related to Transportation and Mobility
Other
We need to protect our shoreline from future storms. After Superstorm Sandy, we realized that we were vulnerable to future storms and need to build it up. We need to look at short term and long term solutions to enhance our shoreline. On the short term solution, we need to create sand dunes and plant sea grass for the beaches, creek and bayside. They will protect us from tidal surges and sand erosion. Long term solutions have not been determined yet. Community input and federal funding will dictate how the long term solution will look like.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
As mentioned before, traffic congestion and limited parking spaces are a major issue in the area during the summer time. We need to do a traffic survey to alleviate the congestion issue and figure out what can be done. One idea is to build multi-deck parking lots to accommodate the increasing cars coming into the community. The MTA needs to provide express service to Coney Island so people can travel to and from the area in less than a hour. There are programs that have been funded in the current year. We would like these funding to continue with the following requests: Reconstruction streets, sidewalks, amusement district. We need to install streetscape improvements for our area. After Superstorm Sandy, we need to provide new resilient street lights. Our power was off for two weeks and everything was completely dark after sundown. If we had solar panel street lights, we would have been partly in the dark and would have felt more secured.
Needs for Transit Services
The city, borough, and community all urge people to use public transportation, and, in the case of summertime Coney Island and Brighton Beach, it is the wisest move, but Transit uses weekend hours to fix its subway lines for needed rail and station work. The resultant shifts in movement of F, Q, and other lines prove delays and confusion. The result: people may use cars. We need to improve on the bus service coming into the area. We need to have express bus service over the weekend and SBS B82 ending in Coney Island rather than stopping at Cropsey Avenue and 25th Avenue. Also the electronic kiosks to notify the public how long until the bus arrives at the stop.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/34
DOT
Repair or build new
We need to upgrade our seawalls and
seawalls or
bulkheads. After Superstorm Sandy, our
bulkheads
seawalls and bulkheads could not hold back the
tides. We have to upgrade them before the next
storm comes.
14/34
DOT
Other capital traffic
We need to address the parking situation and
improvements
the traffic flow for the area. We realize during
requests
the summer time when tourists and beachgoers
come to the area, they are searching for free
parking. They fight for the same spot as the
local residents does. When they leave at night,
there is a mass exodus from the area and
causes a gridlock throughout the streets. This
causes a safety concern for emergency vehicles
that cannot move if the traffic is backed up.
20/34
NYCTA
Improve
We need to make the F train at Neptune Avenue
accessibility of
station handicapped accessible. There is a
transit
growing NORC population in the area and the
infrastructure, by
nearest ADA station is two stops away.
providing elevators,
escalators, etc.
29/34
NYCTA
Repair or upgrade
We need to upgrade the subway stations to
subway stations or
handle the tourist crowd. There is a blank spot
other transit
over the Lifeguard Jobs available, can we get a
infrastructure
community wall mural painted up there?
30/34
DOT
Other
We need a study to see if an on/off ramp can be
transportation
constructed at Stillwell Avenue and Shore
infrastructure
Parkway to alleviate traffic in the area.
requests
33/34
DOT
Repair or provide
Brighton Beach Avenue is exceptionally wide,
new street lights
and the existing street lighting does not extend
to adequately bathe pedestrians in light. This is
especially true on the southside of Brighton
Beach Avenue adjacent to the public park at the
Oceana where the lush trees obscure the
sidewalk and keep it in darkness. Pedestrian-
level lighting in the form of (what are called by
DOT) B-pole lights would greatly enhance
visibility and remove the element of
vulnerability which is currently the pedestrian
experience.
34/34 DOT Improve traffic and
pedestrian safety, including traffic calming (Capital)
Traffic safety is a very real concern. When motorists, bicyclists and pedestrians don’t follow the rules of the road, public safety is endangered. Neckdowns provide safe refuges for pedestrians to wait to cross the street. They shorten the effective crossing distance for pedestrians. And they do not take away parking spaces. They should be in place at every intersection in every commercial corridor in Southern Brooklyn.
image
CS DOT Repair or construct new curbs or pedestrian ramps
We need to repair some sidewalks, curbs and pedestrian ramps since some were destroyed during Superstorm Sandy.
image
CS DOT Repair or construct new medians or bus pads
We need to repair medians and bus pads and surrounding area around bus stops. Since Superstorm Sandy, there were sections that were damaged and needs to be repaired.
image
CS DOT Reconstruct streets We need to reconstruct Brighton Beach Avenue. Brighton
Beach Avenue West 5th Street Corbin Place
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/48
DOT
Provide new traffic
We need new traffic and pedestrian signals to
or pedestrian
coordinate with traffic flow coming and going
signals
out of the area.
2/48
DOT
Address traffic
We need a study to address traffic congestion
congestion
and the parking situation in our neighborhood.
We have new developments, both commercial
and residential projects, we would like to see
how this would impact on an existing problem
in the area.
3/48
DOT
Improve parking
We need to improve parking operations by
operations
leasing City owned properties for off-site
parking. The parking site should have a shuttle
for people to travel to and from the area.
46/48 NYCTA Expand bus service
frequency or hours of operation
SBS B82 Bus that makes ends at Cropsey Avenue
it should continue to Stillwell Avenue especially during the summer time and on weekends.
image
47/48 NYCTA Other transit service
requests
We would like to have a study to construct a Maglev train system to move people around the area from venue to venue to parking lots. This would help us offset the excess cars coming into the area.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 13
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
With the new landmark status for the boardwalk, the Community Board would like it to be fixed so it can be preserved as a landmark. We know there are challenges in getting the boardwalk fixed but now it has gotten to the point where it is unsafe in certain area and need to be address. We understand there are limits with the carpenters and the actual time to work on the boardwalk during the off season but there has to be a better way to fix the boardwalk before it become a safety hazard and lawsuits to follow with people tripping over loose planks and screws. We hope this can be address since this is our number priority in our capital budget.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
As mention before, we need to protect our shoreline from the next major storm. We have to secure the shoreline or all will be washed away with the next major storm. In addition, we need to repair and maintain our boardwalk. With part of the boardwalk falling apart will lead to lawsuit against the City. We need to fix the bathrooms and rebuild the ones on the west end of Coney Island. We need a New recreational center in Kaiser Park. The community needs an affordable recreational center that will be intergeneration, multicultural, educational, nature conservatory, ice skating rink, adult vocational training center, emergency center, greenhouse, boathouse, ferry terminal, sport related activities, indoor skate board park, boxing ring, etc. This center would be located behind Mark Twain JHS which would wrap around to West 23rd Street to West 25th Street. This would also include parking space/garage for people using the ferry for their daily commute. We would like to model the recreational center like Ocean Breeze Complex in Staten Island. There are programs that have been funded in the current year. We would like these funding to continue until completed with the following requests: - Reconfiguring work on Asser Levy Park – infrastructure improvements to halt flooding; landscaping; etc. Upgrade Scarangella Park with comfort station and other amenity. We need more mobi-mats for accessibility to the beach. We need PEP officers at Asser Levy Park for illegal vendors selling to the public. Phases 2 and 3 for development of Calvert Vaux Park e.g. maintenance shop. - Increase funds to keep Boardwalk bathrooms open to later hours. Continued support to increase personnel for Parks. Add light-weight vehicles for work on Boardwalk and beach; maintenance of vehicles to ensure ready use of light-weight vehicles. Tree Removal and Replacement: We continued to support the street tree maintenance throughout the community. We need to have public programming and activation of public spaces on City-owned sites. During the season, people are drawn to free activities and something different for the family. Our boardwalk, beaches and public parks are under utilized during the off season.
Needs for Cultural Services
We need a New recreational center in Kaiser Park. The community needs an affordable recreational center that will be intergeneration, multicultural, educational, nature conservatory, adult vocational training center, emergency center, greenhouse, boathouse, ferry terminal, sport related activities, ice skating rink, indoor skate board park, boxing ring, etc. This center would be located behind Mark Twain JHS which would wrap around to West 23rd Street to West 25th Street. This would also include parking space/garage for people using the ferry for their daily commute. We would like to model the recreational center like Ocean Breeze Complex in Staten Island.
Needs for Library Services
We need to upgrade our library facilities with more computers and innovative ideas to attract readers and the community. We need to expand the library hours and have weekend services, too. We also need more diverse variety of books in other language for the immigrant population.
Needs for Community Boards
We need to continue increase our presence in the area for people to use the community board as the central agency to handle local and community wide issues. We need to expand the staff and hire consultants to address the issues and solve current issues. We also need to relocate the board office to the ground floor to be closer to the public. This will give us the presence in the neighborhood.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/34
DPR
Improve access to a
Rehabilitation of Coney Island Boardwalk entire
building in a park
length
3/34
DPR
Other requests for
Shoreline protection entire shorefront. This task
park, building, or
requires multi-agencies to address this issue.
access
The Army Corp of Engineers, Office of Resiliency
improvements
and Recovery, Department of Environmental
Protection, Parks Department, and other
agencies needs to have short term and long
term plans to handle the next storm. This is a
long process that needs immediate attention
and funding. Plans include but not limited to
planting sea grass, green street gardens (bio
swedes), back flow prevention valves, sea walls,
etc.
7/34
DPR
Provide a new, or
We need a New recreational center in Kaiser
new expansion to, a
Park. The community needs an affordable
building in a park
recreational center that will be intergeneration,
multicultural, educational, nature conservatory,
adult vocational training center, emergency
center, greenhouse, boathouse, ferry terminal,
sport related activities, indoor skate board park,
boxing ring, etc. This center would be located
behind Mark Twain JHS which would wrap
around to West 23rd Street to West 25th Street.
This would also include parking space/garage
for people using the ferry for their daily
commute. We would like to model the
recreational center like Ocean Breeze Complex
in Staten Island.
15/34
DPR
Enhance park safety
Community Garden W. 29 Street & Surf Avenue
through design
leveling of land for better use of planting plots
interventions, e.g.
by local residents; storage house; fencing; other
better lighting
needs.
(Capital)
16/34
DPR
Other requests for
Construct bathrooms on Boardwalk, on the west
park, building, or
end of peninsula; Add drinking fountains and
access
boardwalk showers.
improvements
17/34
DPR
Reconstruct or
Continued work at Kaiser Park handball court
upgrade a park or
restoration and the circle area adjacent to Mark
amenity (i.e.
Twain school.
playground, outdoor
athletic field)
18/34
DPR
Other requests for
Construct a Bikeway parallel to the entire beach
Reigelmann
park, building, or
length, Bike riders need a separate path for
Boardwalk
access
aside from the Boardwalk. Presently, they
Brighton 15th
improvements
create dangers for pedestrians, businesses,
Street West
bathers, etc. This can also be used as a sea wall,
37th Street
protecting the boardwalk and the community.
25/34
DPR
Reconstruct or
We need to reconstruct the Park Maintenance
3026 W 25th
upgrade a building
building on West 25th Street
St
in a park
26/34
DPR
Reconstruct or
Reconstruct Luna Park playground
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
27/34
DPR
Provide a new or
We would like to put some type of recreational
expanded park or
activities in lieu of the bandshell at Asser Levy
amenity (i.e.
Park.
playground, outdoor
athletic field)
31/34
DPR
Provide a new or
We need a dog run at Asser Levy Park.
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
32/34
DCLA
Other cultural
There is a lack of cultural facility for the area.
facilities and
We need to give the community choices other
resources requests
than sport facilities. We need a performing arts
(Capital)
facility that will attract Southern Brooklyn
people to the area.
CS
DCAS
Renovate, upgrade
We need to move the Community Board office
or provide new
to the ground level. Currently, we are located on
community board
the 3rd floor, above two bars and a gentlemen's
facilities and
club. Our entrance is located in the back of the
equipment
building through a dark alley. We need to move.
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Signage on the Boardwalk entire length No Bike Riding on the Boardwalk, after 10am, Street names, etc.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/48
DPR
Other park
We need operating funds to maintain and
maintenance and
operate specifically the Coney Island - Brighton
safety requests
Beach Boardwalk.
25/48
DCLA
Provide more public
We need to expand the use of public art for the
art
people.
29/48
OMB
Other community
Continue support to increase funding for
board facilities and
Community Board operations.
staff requests
30/48
OMB
Provide more
We continue to support to hire consultants to
community board
address the issues in the area. We would hire
staff
consultants to survey the area that needed to
be done.
43/48
BPL
Extend library hours
We use to have the Coney Island Learning
or expand and
Center before Superstorm Sandy destroyed the
enhance library
Coney Island Library. After the library reopened,
programs
the Learning Center didn't returned. We need to
get back our Learning Center to help the adults
with ESL classes and other adult literacy
programs.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/34
DPR
Improve access to a
Rehabilitation of Coney Island Boardwalk entire
building in a park
length
2/34
DSNY
Provide new or
Construction of Sanitation Garage for
2012
upgrade existing
Community Board 13 has been promised to the
Neptune
sanitation garages
community since 1980s. The current site on
Avenue
or other sanitation
West 21 Street and Neptune Avenue, are
infrastructure
situated behind people's backyards. Since
Superstorm Sandy Community Board 15
garage had been damaged, too and was to
merge the two garages together. Earlier this
year we heard the funds for the relocation was
stopped. We need to move this back into the
Capital Budget and make it a high priority to
fund this project.
3/34
DPR
Other requests for
Shoreline protection entire shorefront. This task
park, building, or
requires multi-agencies to address this issue.
access
The Army Corp of Engineers, Office of Resiliency
improvements
and Recovery, Department of Environmental
Protection, Parks Department, and other
agencies needs to have short term and long
term plans to handle the next storm. This is a
long process that needs immediate attention
and funding. Plans include but not limited to
planting sea grass, green street gardens (bio
swedes), back flow prevention valves, sea walls,
etc.
4/34
DEP
Inspect sanitary
We need to repair and expand our sanitary
sewer on specific
sewer lines. Since Superstorm Sandy, our
street segment and
sanitary sewer lines were not able to handle the
repair or replace as
water levels of a hurricane. The older sanitary
needed (Capital)
sewer lines need to be expanded/replaced
throughout the community.
5/34
DOT
Repair or build new
We need to upgrade our seawalls and
seawalls or
bulkheads. After Superstorm Sandy, our
bulkheads
seawalls and bulkheads could not hold back the
tides. We have to upgrade them before the next
storm comes.
6/34
NYPD
Provide surveillance
We need surveillance cameras to help our
cameras
precinct to monitor high crime area.
7/34
DPR
Provide a new, or
We need a New recreational center in Kaiser
new expansion to, a
Park. The community needs an affordable
building in a park
recreational center that will be intergeneration,
multicultural, educational, nature conservatory,
adult vocational training center, emergency
center, greenhouse, boathouse, ferry terminal,
sport related activities, indoor skate board park,
boxing ring, etc. This center would be located
behind Mark Twain JHS which would wrap
around to West 23rd Street to West 25th Street.
This would also include parking space/garage
for people using the ferry for their daily
commute. We would like to model the
recreational center like Ocean Breeze Complex
in Staten Island.
8/34
DEP
Evaluate a public
We need to provide new green infrastructure
location or property
such as stormwater green streets and green
for green
playgrounds along the shoreline. We realize
infrastructure, e.g.
that short term solutions are needed until the
rain gardens,
long term plans are approved and financed.
stormwater
greenstreets, green
playgrounds
9/34
NYPD
Renovate or
We need to renovate the 60th Precinct station
upgrade existing
and make it ADA compliance and expand the
precinct houses
area. People cannot get to the second floor
without an elevator and there isn't one
available. Also there is need to expand the
community meeting room on the second floor.
10/34
HHC
Other health care
A C1 Trauma Center is needed in Coney Island
2601 Ocean
facilities requests
Hospital. With the increasing population due to
Parkway
new housing development and the influx of
tourists during the summer time, we need a C1
Trauma Center in the neighborhood. We
understand that this is not a City Budget item
but we need to make this aware to the city,
state and federal government, that this is a
priority for the neighborhood.
11/34
DEP
Develop a capital
Coney Island infrastructure is currently being
project for specific
upgraded from West 12th Street to West 21st
street segments
Street. We need to continue to upgrade the
currently lacking
remain sewer lines to West 37th Street.
sanitary sewers
12/34
DEP
Develop a capital
Brighton Beach area needs to repair and replace
project for specific
the old sanitary sewer lines. The targeted area
street segments
is from Ocean Parkway to Corbin Place, from
currently lacking
the Belt Parkway to the boardwalk.
sanitary sewers
13/34
NYCHA
Install security
We need to install security cameras in the
cameras or make
NYCHA developments. We have gun violence in
other safety
the developments, we need extra eyes on the
upgrades (Capital)
buildings to make the area safer.
14/34
DOT
Other capital traffic
We need to address the parking situation and
improvements
the traffic flow for the area. We realize during
requests
the summer time when tourists and beachgoers
come to the area, they are searching for free
parking. They fight for the same spot as the
local residents does. When they leave at night,
there is a mass exodus from the area and
causes a gridlock throughout the streets. This
causes a safety concern for emergency vehicles
that cannot move if the traffic is backed up.
15/34
DPR
Enhance park safety
Community Garden W. 29 Street & Surf Avenue
through design
leveling of land for better use of planting plots
interventions, e.g.
by local residents; storage house; fencing; other
better lighting
needs.
(Capital)
16/34
DPR
Other requests for
Construct bathrooms on Boardwalk, on the west
park, building, or
end of peninsula; Add drinking fountains and
access
boardwalk showers.
improvements
17/34
DPR
Reconstruct or
Continued work at Kaiser Park handball court
upgrade a park or
restoration and the circle area adjacent to Mark
amenity (i.e.
Twain school.
playground, outdoor
athletic field)
18/34
DPR
Other requests for
Construct a Bikeway parallel to the entire beach
Reigelmann
park, building, or
length, Bike riders need a separate path for
Boardwalk
access
aside from the Boardwalk. Presently, they
Brighton 15th
improvements
create dangers for pedestrians, businesses,
Street West
bathers, etc. This can also be used as a sea wall,
37th Street
protecting the boardwalk and the community.
19/34
DFTA
Create a new senior
With the growing senior population in the
center or other
district, we need more senior centers. Public
facility for seniors
land is limited in the area. A multi-use facility
must be built as a multicultural,
intergenerational, recreational center on City
owned land. There is park land/city owned land
that can be develop by Mark Twain JHS
(pumping station/handball courts/park circle,
etc.) into this needed facility.
20/34
NYCTA
Improve
We need to make the F train at Neptune Avenue
accessibility of
station handicapped accessible. There is a
transit
growing NORC population in the area and the
infrastructure, by
nearest ADA station is two stops away.
providing elevators,
escalators, etc.
21/34
FDNY
Upgrade
We need to upgrade communication equipment
communication
to improve emergency response such as
equipment to
digital/wifi towers.
improve emergency
response
22/34
EDC
Make infrastructure
With the rise of smartphones and other
investments that
portable electronic devices, we need to improve
will support growth
the availability speed and cost of broadcast
in local business
access to local businesses and residents.
districts
23/34
NYPD
Other NYPD
We need to purchase heavy duty bicycles for our
facilities and
Auxiliary Police Officers to help patrol the area.
equipment requests
(Capital)
24/34
NYPD
Other NYPD
We a growing population heading to the beach,
facilities and
we need a harbor patrol to handle jet skiers
equipment requests
from coming too close to the shoreline. Also
(Capital)
needed are safety buoys to delineate the 500
feet zone from the beach so jet skiers will know
not to approach the shoreline.
25/34
DPR
Reconstruct or
We need to reconstruct the Park Maintenance
3026 W 25th
upgrade a building
building on West 25th Street
St
in a park
26/34
DPR
Reconstruct or
Reconstruct Luna Park playground
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
27/34
DPR
Provide a new or
We would like to put some type of recreational
expanded park or
activities in lieu of the bandshell at Asser Levy
amenity (i.e.
Park.
playground, outdoor
athletic field)
28/34
EDC
Build or expand
We need to build an incubator/research lab
incubator or
spaces to entice small businesses to grow. We
affordable work or
increasing rental space price and huge overhead
research lab spaces
cost to start a business, an incubator can
address these issues.
29/34
NYCTA
Repair or upgrade
We need to upgrade the subway stations to
subway stations or
handle the tourist crowd. There is a blank spot
other transit
over the Lifeguard Jobs available, can we get a
infrastructure
community wall mural painted up there?
30/34
DOT
Other
We need a study to see if an on/off ramp can be
transportation
constructed at Stillwell Avenue and Shore
infrastructure
Parkway to alleviate traffic in the area.
requests
31/34
DPR
Provide a new or
We need a dog run at Asser Levy Park.
expanded park or
amenity (i.e.
playground, outdoor
athletic field)
32/34
DCLA
Other cultural
There is a lack of cultural facility for the area.
facilities and
We need to give the community choices other
resources requests
than sport facilities. We need a performing arts
(Capital)
facility that will attract Southern Brooklyn
people to the area.
33/34
DOT
Repair or provide
Brighton Beach Avenue is exceptionally wide,
new street lights
and the existing street lighting does not extend
to adequately bathe pedestrians in light. This is
especially true on the southside of Brighton
Beach Avenue adjacent to the public park at the
Oceana where the lush trees obscure the
sidewalk and keep it in darkness. Pedestrian-
level lighting in the form of (what are called by
DOT) B-pole lights would greatly enhance
visibility and remove the element of
vulnerability which is currently the pedestrian
experience.
34/34
DOT
Improve traffic and
Traffic safety is a very real concern. When
pedestrian safety,
motorists, bicyclists and pedestrians don’t
including traffic
follow the rules of the road, public safety is
calming (Capital)
endangered. Neckdowns provide safe refuges
for pedestrians to wait to cross the street. They
shorten the effective crossing distance for
pedestrians. And they do not take away parking
spaces. They should be in place at every
intersection in every commercial corridor in
Southern Brooklyn.
CS
DEP
Evaluate a public
We need green infrastructure projects
location or property
throughout the community. Since Superstorm
for green
Sandy, we realized that our infrastructure could
infrastructure, e.g.
not handle the overflow of water on the sewer
rain gardens,
lines and we need to fix it. One project is to have
stormwater
green street gardens to handle the excess rain
greenstreets, green
water. Strategically placed green street gardens
playgrounds
will be able to assist and handle the onslaught
of water.
CS
FDNY
Rehabilitate or
Repair buildings in Battalion 43
renovate existing
fire houses or EMS
stations
CS
EDC
Invest in capital
We need a ferry study for Coney Island. We need
projects to improve
to invest in our piers and other capital project to
access to the
improve access to the waterfront. We realized
waterfront
that if there is a problem with traffic and
parking, one solution is to use our waterfront.
We would like to build a ferry terminal along the
Coney Island creek at West 23rd Street. This
would address local commuters to use the ferry
to get to Manhattan for the price of a
Metrocard. During the summer, this would be
an alternate way of getting into Coney Island
without using a vehicle.
CS
DCAS
Renovate, upgrade
We need to move the Community Board office
or provide new
to the ground level. Currently, we are located on
community board
the 3rd floor, above two bars and a gentlemen's
facilities and
club. Our entrance is located in the back of the
equipment
building through a dark alley. We need to move.
CS
DPR
Reconstruct or
Signage on the Boardwalk entire length No Bike
upgrade a park or
Riding on the Boardwalk, after 10am, Street
amenity (i.e.
names, etc.
playground, outdoor
athletic field)
CS DOT Repair or construct new curbs or pedestrian ramps
We need to repair some sidewalks, curbs and pedestrian ramps since some were destroyed during Superstorm Sandy.
image
CS DOT Repair or construct new medians or bus pads
We need to repair medians and bus pads and surrounding area around bus stops. Since Superstorm Sandy, there were sections that were damaged and needs to be repaired.
image
CS DOT Reconstruct streets We need to reconstruct Brighton Beach Avenue. Brighton
Beach Avenue West 5th Street Corbin Place
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/48
DOT
Provide new traffic
We need new traffic and pedestrian signals to
or pedestrian
coordinate with traffic flow coming and going
signals
out of the area.
2/48
DOT
Address traffic
We need a study to address traffic congestion
congestion
and the parking situation in our neighborhood.
We have new developments, both commercial
and residential projects, we would like to see
how this would impact on an existing problem
in the area.
3/48
DOT
Improve parking
We need to improve parking operations by
operations
leasing City owned properties for off-site
parking. The parking site should have a shuttle
for people to travel to and from the area.
4/48
DCP
Study land use and
We need to study land use and zoning to better
zoning to better
match current use or future neighborhood
match current use
needs. With all the residential and commercial
or future
development, the community needs to know
neighborhood
what its plans are coming into the area and
needs
have an input is needed.
5/48
DOHMH
Reduce rat
Increase personnel for Rat Abatement. There
populations
has been a large increase of rats being displace
by the new construction, they are running into
existing buildings and causing problems to the
neighborhood. We need to do a district wide
abatement to tackle the rodent problem.
6/48
DPR
Other park
We need operating funds to maintain and
maintenance and
operate specifically the Coney Island - Brighton
safety requests
Beach Boardwalk.
7/48
DOE
Improve school
There is a need to improve school safety with
safety
security guards and crossing guards around the
schools. With the increase violence in the
neighborhood and children bring in weapons,
there has to be better school safety for the
schools. We have to educate the youth to
respect each other and not resort to violence.
There should be a program dealing with anti-
violence, anti-bullying and cyber-bullying for the
children. We need to get the elected officials
and the D.A. office involve with this problems.
8/48
DFTA
Enhance NORC
programs and health services
We need to address NORC programs and health
services to assist the aging population.
9/48
SBS
Conduct BID
We currently have a BID in Brighton Beach and
Feasibility Analysis
it is successful in the area. We are looking to
or support BID
form a BID in Coney Island to handle the
Formation Planning
commercial and amusement area.
for a selected
commercial district
10/48
DOHMH
Other programs to
We need to address air quality issues in the
address public
NYCHA developments in Coney Island. We
health issues
realized that the properties did not properly
requests
eliminate molds from their buildings. People
who are sensitive to molds are become sick and
we need to test the air quality at these
locations.
11/48
DOHMH
Create or promote
We need to emphasize on more educational
programs for
programs dealing with obesity, healthy eating,
education and
nutrition, etc.
awareness on
nutrition, physical
activity, etc.
12/48
DEP
Investigate and
We Need more DEP Inspectors for industrial
address water
waste and water lines. Since the illegal dumping
quality complaints
from Beach Haven Apartments, the community
at an address or on
is concern about future dumping from other
specific street
developments and industrial businesses. For our
segments
water quality of the creek, we need to find the
illegal connections to the creek and have them
closed off or repaired.
13/48
SBS
Support
We need to support storefront/facade
development of
improvements for the area. After Superstorm
local Storefront /
Sandy, businesses had to clean up the damages
Facade
and had no monies for storefront
Improvement
improvements.
Program
14/48
EDC
Improve public
We need to improve our public markets. We
markets
currently have two location and need to bring
more to the area.
15/48
DYCD
Provide, expand, or
We need to provide adolescent literacy
enhance adolescent
programs and services for our young adults. We
literacy programs
need to give them a chance to get a GED
and services
diploma to get to the next level.
16/48
DYCD
Provide, expand, or
Community Board 13 has a growing
enhance English for
population of immigrants. We need to address
speakers of other
their concern and issues. English as a second
languages (ESOL)
language services are needed.
services
17/48
DOE
Assign more
With the overdevelopment of our community
teaching staff
and the overcrowding in classrooms, there is a
need for more qualified teaching staff. We
cannot justified overcrowded classrooms and
not have enough teachers for the classes. We
need to expand the budget for hiring teachers.
18/48
DOHMH
Other programs to
We need to address teen pregnancy for our
address public
community. More programs in schools and in
health issues
the community to bring attention to the issue.
requests
Are each JHS and HS in our district equipped to
handle teen pregnancy issues?
19/48
DFTA
Other services for
Increase personnel for Home Bound programs
homebound older
for disabled seniors. Due to the increasing NORC
adults programs
population, home bound programs for seniors
are needed.
20/48
EDC
Expand tax incentive
We need to expand tax incentive programs to
programs to help
help neighborhood businesses construct or
neighborhood
improve space. This would help entice
businesses construct
businesses to come into the area.
or improve space
21/48
DYCD
Provide, expand, or
We need to expand the skill training and
enhance skills
employment services for high school students at
training and
risk of dropping out. We have an alternate high
employment
school that is filled and need to be expanded
services for high
and enhanced.
school students at
risk of dropping out
22/48
DYCD
Provide, expand, or
We do not have a fatherhood programs for non-
enhance fatherhood
custodial fathers. Our nearest program is in
programs for non-
Kingsborough Community College. We would
custodial fathers,
like to have one in our community
e.g. parenting skills
training
23/48
DSNY
Increase
We need to increase enforcement of canine
enforcement of
waste laws to catch the dog owners in the act of
canine waste laws
littering the street. People need to be fined
enough times to make them understand that
they have to curb their dogs.
24/48
DOE
Other educational
We realized that the performing and cultural
programs requests
arts have been cut out from the curriculum. The
children have no place to express themselves
except through academic and sports. Their
creative learning has been cut off and it is
desperately needed.
25/48
DCLA
Provide more public
We need to expand the use of public art for the
art
people.
26/48
SBS
Support local CBOs
We continue to support the need to provide
efforts to provide or
retail attraction and retention assistance to
expand retail
revitalize the commercial strip in the area.
attraction and
retention assistance
27/48
DOHMH
Other programs to
Continued to support to promote flu shots,
address public
measles shots and other immunization for the
health issues
immigrant community. The outreach must be
requests
translated into other languages to reach the
target audience. It must be explain to them that
it is essential to vaccinate the family in order
not get sick or die. There are growing Asian,
Pakistan, Hispanic and Russian community that
needs translation for immunization programs.
28/48
NYCHA
Provide emergency
We continue to support emergency housing for
housing for
households displaced by fires or City-issued
households
vacate orders. Tenants need to be house in
displaced by fires or
other locations while repairs are made.
City-issued vacate
orders
29/48
OMB
Other community
Continue support to increase funding for
board facilities and
Community Board operations.
staff requests
30/48
OMB
Provide more
We continue to support to hire consultants to
community board
address the issues in the area. We would hire
staff
consultants to survey the area that needed to
be done.
31/48
DOHMH
Other programs to
Continue Support - There needs to be a drug
address public
prescription awareness campaign for the
health issues
community. Families need to know if there is
requests
any CBO to address this problem.
32/48
DSNY
Provide or expand
We need to get the information to the high rise
community
buildings for composting programs for our
composting
neighborhood. There seems to be some
programs
resistance among the management companies
in complying with organic composting program.
33/48
NYPD
Assign additional
We need to assign additional school safety
school safety
officers to the community to teach the children
officers
about safety in the street.
34/48
NYPD
Assign additional
We need assign additional funding to hire full
crossing guards
time crossing guards for the school to keep the
children safe.
35/48
NYPD
Assign additional
Added traffic-control personnel to move
Neptune
traffic enforcement
motorists eastward to Ocean Parkway
Avenue
officers
entrances to Belt; To curtail bumper-to-bumper
Ocean
traffic on Neptune Ave. to Cropsey Ave. during
Parkway
busy hours. Also, we need to address Brighton
Cropsey
Beach Avenue and Coney Island Avenue and
Avenue
Surf Avenue, too.
36/48
DSNY
Expand disposal
We need to expand disposal events for
events for
hazardous household waste. We would like to
hazardous
have the event locally so people do not have to
household waste
travel half way across Brooklyn to dispose
hazardous items.
37/48
NYPD
Assign additional
We need more traffic enforcement officers and
traffic enforcement
traffic officers to direct the traffic flow in the
officers
area.
38/48
NYPD
Assign additional
We need additional uniformed officers for our
uniformed officers
community. With the growing developments,
are facing a population boom. We need
additional uniformed officers to help keep down
crime.
39/48
NYPD
Increase resources
We need to increase resources for youth crime
for youth crime
prevention programs such as Explorers
prevention
Program. We need to offer the youth more
programs
positive activities and not to fear law
enforcement officers.
40/48
SBS
Other expense
We need to expand financial incentives for job
workforce
creation and retention to have local businesses
development
hire local residents.
requests
41/48
ACS
Provide, expand, or
We need to enhance housing assistance for
enhance housing
youth that are leaving foster care. We
assistance for youth
understand that at the age of 18 the young
that are leaving
adult does not have a secure job to afford an
foster care
apartment, or some type of housing assistance
is needed or supplemented to the rent.
42/48
HPD
Provide, expand, or
We need to continue support to provide
enhance community
community outreach on HPD programs and
outreach on HPD
services i.e. CCC program. Our housing groups
programs and
are in need of funding for the area to help the
services
tenants, homeowners and landlords.
43/48
BPL
Extend library hours
We use to have the Coney Island Learning
or expand and
Center before Superstorm Sandy destroyed the
enhance library
Coney Island Library. After the library reopened,
programs
the Learning Center didn't returned. We need to
get back our Learning Center to help the adults
with ESL classes and other adult literacy
programs.
44/48
DFTA
Increase
Fund Jewish Community Council of Greater
transportation
Coney Island Senior Citizen Transportation
services capacity
(Project Ride) and other access a ride services
for the Frail Elderly population. Traveling for
seniors are limited due to their limited mobility.
More funding are needed to address this in a
growing NORC area.
45/48
DOHMH
Reduce mosquito
With the Nile virus and the Zika virus we are
populations
surrounded by the bodies of water in our
community. We would like to reduce the
mosquito populations and also inform the public
about the hazard of standing water. This year,
our zip code s(11224, 11235) were not covered
in the spraying of the area, our surrounding
neighbors were sprayed but not our area.
46/48
NYCTA
Expand bus service
SBS B82 Bus that makes ends at Cropsey Avenue
frequency or hours
it should continue to Stillwell Avenue especially
of operation
during the summer time and on weekends.
47/48
NYCTA
Other transit service
We would like to have a study to construct a
requests
Maglev train system to move people around the
area from venue to venue to parking lots. This
would help us offset the excess cars coming into
the area.
48/48 ACS Provide, expand, or
enhance funding to support higher education and/or workforce development opportunities for youth who are leaving foster care
There is a need to provide funding for higher education and/or workforce development opportunities for youth who are leaving foster care. We see youth without a college degree or trade skills to compete for a job. We feel at least a CTE (certified technical education) degree would offer them a skill once completing.

