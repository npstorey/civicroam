- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 11 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1ne4HxOth3bNOqh_3LLTOvRJd7-BXViCs/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1ne4HxOth3bNOqh_3LLTOvRJd7-BXViCs/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
11
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 11
image
Address: 46-21 Little Neck Parkway, Ground Floor Phone: (718) 225-1054
Email: qn11@cb.nyc.gov
Website: www.nyc.gov/queenscb11
Chair: Eileen Miller District Manager: Joseph Marziliano
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 11, a suburban like community in northeast Queens, is home to approximately 121,000 people. It is a thriving upper, middle income community with a median household income of almost $81,000. The District has a mixed white, non-Hispanic (52%) and a growing Asian (43%) population. The population has a substantial elderly (over 65) population, at 18%. Over 29% of our households have children under 18 years of age. New homes continue to be built in the district along with the enlargement of existing homes to accommodate an increasing population of families attracted by the educational opportunities in the district. Elderly homeowners are selling their homes to relocate, often to the garden apartment complexes in the area. Many of the new homes are much larger than the existing housing stock and is changing the character of the neighborhoods. In areas that are zoned for multiple families, homes are being renovated to reflect that zoning. Our community is becoming denser as the population continues to grow. We are, in turn, experiencing increases in traffic and an increased concern about transportation needs and safety. There are many new, larger commercial developments along the commercial overlay zones. Small commercial strips have been replaced by larger retail stores, offices, and community facilities. Many sites accommodate multiethnic businesses in response to the needs of the growing Asian population in the district. Hotels are being built in the district for the first time. Marriott is building two hotels due to the close proximity of Queens to the airports, Citi Field, the USTA stadium, and transportation to Manhattan while being more affordable than a hotel room in Manhattan. The number of health care facilities has increased throughout the district, both newly constructed buildings and conversions of private homes.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 11
image
The three most pressing issues facing this Community Board are:
Parks
CB 11 residents love their parks and trees. This district has several large parks and tree-lined streets. Street and park tree maintenance, renovation of ball fields, and park improvements are all important to the residents of CB 11, as they add to the attractiveness of the neighborhoods and the quality of life the residents enjoy. The preservation of the wetland areas and protection from development is of paramount importance in the north end of the district which borders Little Neck Bay.
Quality of life issues (noise, graffiti, petty crime, etc.)
The goal of neighborhood preservation in Community Board 11 is to preserve the special qualities that have made lower density, suburban-style neighborhoods in northeast Queens attractive. There are also two landmarked districts in CB 11. As the City has grown, so have concerns about how much development is good for the community. The Board supported rezoning to prevent out-of-character over-development. However, there are still concerns with zoning and building violations and how the City responds to these complaints.
Street conditions (roadway maintenance)
Street conditions and traffic issues have become a growing problem. We have seen increased traffic and roadway complaints such as poor road conditions and potholes and need for pavement markings. Four highways intersect through the district adding to the traffic on local streets. There has also been increased demands for speed bumps and other traffic calming devices as traffic has increased with our growing population.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 11
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
With a large senior population, the community has had only one full service DFTA funded senior center: the Bayside Senior Center. Through advocacy for more senior services, the Samuel Field Y is now funded to operate a center at their Little Neck facility. The Y also operates the Deepdale NORC at one of the district's co-op garden apartment complexes. Services Now for Adult Persons (SNAP) provides casework management for all of CB 11. We have participated with our the local councilman, the NY Academy of Medicine and DFTA to make sure that the district is more age-friendly. Transportation for seniors for health visits and shopping is sorely lacking in the district especially since the residents are dependent exclusively on cars and buses. We also have an increasing elderly Asian population in need of services addressing their language and cultural needs. Each of these agencies have had to address those needs.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
Our district has one of the highest senior populations in NYC, at 18% of the population. We have only one DFTA funded senior center, the Bayside Senior Center, located in the district. We have advocated for increased services and DFTA did provide additional funding for the Samuel Field Y to run a full service center in the eastern section of the district. We still advocate for more senior services in the western part of the district, in the Auburndale area.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/29
DFTA
Create a new senior
Fund a senior center in western part of the
center or other
district, in Auburndale. Bayside Senior Center is
facility for seniors
in the center of the district and the Samuel Field
Y serves the eastern end of the district.
4/29
DFTA
Increase case
Additional funding is needed to reduce social
80-45
management
worker caseloads currently about 65 cases per
Winchester
capacity
worker. Reductions in caseload will improve
Blvd
service delivery to the elderly. SNAP serves
Community Boards 8, 11, and 13.
12/29
DFTA
Increase
The senior centers in the district provide
transportation
transportation for seniors to go to the centers,
services capacity
get to doctors and hospitals as well as for
shopping. The centers need additional funding
to provide these services for all who need it.
19/29
DOHMH
Other programs to
Provide adequate, comprehensive and effective
address public
funding for epidemiology and control of air-
health issues
borne, water-borne, and vector (mosquito)
requests
diseases.
22/29
DFTA
Enhance NORC
Funds are needed from the Federal, State and
programs and
City government to establish additional NORC's.
health services
There is one existing NORC's in the district. It is
Deepdale Cares at the Deepdale Gardens
complex operated by the Samuel Field Y. There
are other developments in CB 11 that may
qualify as NORCs and its residents would benefit
from these services. These programs help keep
seniors in their homes and prevents
institutionalization.
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 11
image
M ost Important Issue Related to Youth, Education and Child Welfare
Schools and educational facilities (Maintenance)
Education Partnering with Community Education Council Districts 27, 28 and 29 has been our priority for many years and we are proud to continue to stand with the staff, parents and students within these districts for education quality and equity. The years of Mayoral control by the previous administration caused our CDE Councils to take a considerable beating. It was extremely difficult to manage all of the issues brought by the Bloomberg administration, yet we persevered in dealing with issues such as: the effectiveness of the ATR (Absent Teacher Reserve) pool, the “Blue Book” – a document that did not provide trusted, definitive school space utilization information, “Testing to the Test”, the premature roll out of Common Core Standards, school closures, and persisting co-locations of multiple schools within one building. On numerous occasions, the Education Committee of Community Board 12 expressed our disapproval of the premise of co-location. Districts 27,28 an 29, were part of a detrimental co-location landscape that the Bloomberg administration was determined to carry out prior to his leaving office. Thus we were faced with multiple co-location proposals aimed at our elementary, middle and high schools. Under the guise of "under-utilization," educators were notified that their schools must make way for other schools deemed "high quality" by the DOE. The term was unproven in most case and highly offensive to those associated with the incumbent schools. Proposals for Southeast Queens included three (3) co-located schools with elementary and intermediate schools in existing co-location environments; a sixth (6th) co-located high school at Campus Magnet High School, and of most notable concern to us was a proposal to co-locate Success Charter Academy Elementary School (kindergarten through 4th grade) within August Martin High School, a co-located high school of three (3) schools - one of which, Voyages Preparatory High School, integrates adult-aged students up to the age of 21. Community Board 12 voiced opposition to this irresponsible proposal in our testimony to the NYC Department of Education and SUNY Charter Schools Institute. The proposal was not approved. In addition, Community Board 12 opposed the co-location of Q312 with PS 40; the co-location of Q332 with IS 72 and P.S. 993; and the co-location of Success Charter Academy Elementary School with IS 59 and P.S. 176. Most recently, we provided testimony to oppose the inclusion of New Visions Charter School within August Martin High School, joining the myriad of other schools co-located in the building. Although we were unsuccessful in that effort, we will continue to be adamant regarding our position on school co-location within our districts. Increasing class enrollment for preschool through high school-aged children persists as the population in our CDEC districts continues to rise. The need for the School Construction Authority to expand building plans in Community Board 12 continues as does the need for decreasing class size at every grade level. Additional after school programming and recreational community centers for middle and high school-aged children is essential to Community Education Council Districts 27, 28 and 29. We also request the implementation of effective school safety zones, traffic lights and speed bumps in the vicinity of every school and learning center in our CDEC districts.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
Community Board 11 consists of School District 26, which is both high achieving and over-crowded. More programmatic funding us needed to adequately serve our students.
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
13/29 DYCD Provide, expand, or
enhance after school programs for elementary school students (grades K- 5)
There is only one after-school programming site in this district. The Mayor aimed to provide free after-school programs for all schools.
image
14/29 DYCD Provide, expand, or
enhance after school programs for middle school students (grades 6-
8)
Provide, expand, or enhance after school programs for middle school students. There is only one after-school program in CB 11
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 11
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
Fortunately, crime statistics for the major felony crimes in this district are low. It is our property crimes that cause the most concern.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Felony crimes are low in the 111th Police Precinct. Burglary and Grand Larceny and Petit Larceny account for the majority of our reported crimes. The burglaries include home break-ins and car breaks-ins. Auto theft has decreased dramatically but still accounts for overall crimes in the district. Another concern is the increase of mail fishing cases.
Needs for Emergency Services
Generally CB 11 is pleased with the services received from our police, fire, and emergency service workers. We want to enhance their abilities to service the public.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
7/28
FDNY
Other FDNY facilities
Provide generators in all fire houses.
and equipment
411201009C - Only the Battalion headquarters
requests (Capital)
has its own generator. FDNY is installing them in
firehouses and we support the continued
funding in order for all of our houses to have
one. The three fire houses in CB 11 are E-306, E-
313 and E-320. The FDNY priority is for E-313.
20/28
NYPD
Provide surveillance
Between September 23, 2018 and September
Horace
cameras
26, 2018 there were over 23 reported incidents
Harding
of burglary, theft, and robbery. The location
Expressway
suggested is a choke-point for traffic of both the
254th Street
west-bound Long Island Expressway and north-
255th Street
bound Cross Island Expressway. A surveillance
camera at this location would help deter crime.
27/28
NYPD
Provide surveillance
There is a chronic condition of after-school
Union
cameras
fights and assaults at this location. In the recent
Turnpike and
past, the occurrences have become more violent
Springfield
and brazen. The community believes this would
Boulevard,
be the ideal location for a surveillance camera.
Queens
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
11/29
NYPD
Assign additional
Due to an increase in the number of high school
school safety
students and the need to better protect students
officers
and monitor all entrances to the schools, there
is a need for additional school safety officers.
There are three overcrowded high schools in CB
11: Cardozo, Francis Lewis, and Bayside. All
could use additional officers.
16/29
NYPD
Other NYPD staff
411199901E - Increase the number of Civilian
45-06 215
resources requests
Personnel at the 111th Precinct. In order to
Street
maintain the security we have obtained, the
precinct must be staffed adequately. Adding
civilian personnel will allow more uniformed
officers on the street.
23/29 NYPD Assign additional
crossing guards
There is a high demand for school crossing guards at all school intersections in the district. Some school locations are near major highway overpasses, such as MS 74, MS 67 and PS 159. It is imperative that crossing guards are available for those locations.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 11
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water pollution control
CB 11 borders Little Neck Bay and there are kettle ponds, lakes, and ravines within the parklands. Residents want to ensure that the waterways are clean and that we control and reduce pollution into the bay. The Board has worked with DEP on their Long Term Control Plans to reduce pollution. The District also will benefit from the installation of green gardens in the coming year in areas where there are combined sewer systems.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
The north end of the district borders Little Neck Bay on the Long Island Sound. This board has worked with the NYSDEC and the Dept. of Parks to preserve and protect the area's wetlands and improve the quality of water in the bay. Some areas are in the hurricane zones and there is concern that intensive storms could flood areas around the bay. There are many old seepage basins in the area and many no longer function properly. They need to be removed and replaced with a storm sewer system. We also have a large area of combined sewer lines. There have been several projects recently in CB 11 to install catch basins and sewer lines and replace old water mains. The repair of our DEP infrastructure is important to maintain our streets and water services. Bioswales are also being installed in the district to capture storm water before going into the combined sewer system and the bay.
Needs for Sanitation Services
CB 11 is fortunate to be rated very high on clean streets and sidewalks because residents take pride in the neighborhood and work to keep it clean. We do not receive daily litter basket collection and broom sweeping. The need for these services has grown with an increasing population and traffic.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
15/28
DEP
Inspect water main
Replace water mains in Little Neck. Due to
Leith Road
on specific street
topography of area and age of pipes water
Browvale
segment and repair
periodically is brown coming out of the taps.
Lane Brattle
or replace as
Ave
needed (Capital)
21/28
DEP
Evaluate a public
There are two seepage basins at 194th Street
194th Street
location or property
and 46th Avenue. A permanent storm drain
and 46th
for green
should be installed in its place.
Avenue,
infrastructure, e.g.
Queens
rain gardens,
stormwater
greenstreets, green
playgrounds
22/28
DEP
Evaluate a public
The intersections on West Drive from Park Lane
West Drive
location or property
to Bayview Road puddle and pond after rain
Park Lane
for green
storms. The existing Shore Road storm drain
Bayview Road
infrastructure, e.g.
should be extended up the side streets and
rain gardens,
include catch basins on all eastern corners.
stormwater
greenstreets, green
playgrounds
23/28
DEP
Evaluate a public
The entirety of Richmond Road ponds during
Richmond
location or property
and after rain storms which frequently overflow
Road Shore
for green
into neighboring yards. The high water table
Road Douglas
infrastructure, e.g.
adds a constant flow of water that keeps
Road
rain gardens,
portions of Richmond and Douglas Roads
stormwater
flooded. Storm drains and catch basins are
greenstreets, green
needed.
playgrounds
CS
DSNY
Provide new or
411201601C - The QN11 DSNY garage is funded
upgrade existing
for renovations due to its inability to handle the
sanitation garages
load of the collection trucks. We add our
or other sanitation
continued support to ensure that the project
infrastructure
starts.
CS DEP Evaluate a public location or property for green infrastructure, e.g. rain gardens, stormwater greenstreets, green playgrounds
411201602C - The neighborhood of Doug-Bay is on the shore of Little Neck Bay. Doug-Bay is in hurricane evacuation zones 1-6. During Superstorm Sandy, the area flooded. Residents, concerned with the event of future storms and soil depletion, have asked for flood mitigation along Little Neck Bay. In the 1997, the Port Authority enhanced the existing marsh habitat, removed phragmites, and redesigned the tidal inlets with berms. It was not to abate existing flood problems and the berms would not offer resistance. Due to the increase in severe storms and the vulnerability of the area, it is requested that a flood mitigation and soil depletion project be considered for this area.
233 St 38 Dr
41 Ave
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
17/29
DEP
Clean catch basins
411201202E - Fund additional crews to clean
and maintain catch basins to alleviate backlog
of service repair requests.
18/29
DSNY
Expand disposal
Hazardous waste events have been very
events for
popular, creating long lines for drop-off. Holding
hazardous
the events more frequently will assist residents
household waste
in the area.
21/29
DEP
Evaluate a street
34th Avenue between 211th Street and 213th
34th Avenue
segment or
Street frequently floods onto adjacent private
211th Street
intersection for
properties when it rains. This is due to improper
213th Street
green infrastructure,
street grading and a lack of storm sewers on
e.g. rain gardens,
this stretch. Storm drains are needed.
stormwater
greenstreets, and
plan for
construction if
feasible
24/29
DEP
Inspect storm sewer
411200703C - Reconstruct Streets and Install
223 St 37 Ave
on specific street
Drainage System on 223 Street between 37
41 Ave
segment and
Avenue and 41 Avenue. Drainage from storm
service, repair or
water in the street is served by a gully running
replace as needed
along the side curb line. Flooding is problematic.
The system must be constructed to drain water
from the surrounding streets. Placed on ten year
plan, funding is needed to proceed.
image
25/29 DEP Inspect storm sewer
on specific street segment and service, repair or replace as needed
Marathon Pkwy, Commonwealth Blvd., and 64 Avenue- This location is flooded due to non- functioning seepage basins in the area and has no connection to a storm sewer. The location was removed from a recent storm sewer project. Therefore, a capital project to install the storm sewer is necessary.
Marathon Parkway Commonwealth Blvd 64 Ave
image
26/29 DEP Inspect storm sewer
on specific street segment and service, repair or replace as needed
411201301C - Non-functioning seepage basins must be replaced with new sewer systems to relieve flooding North of Union Turnpike.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 11
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Rezoning started in our Bayside community and, since 2004, all of the district was rezoned to reflect more accurately the development in the various neighborhoods. Ensuring zoning compliance and building code enforcement has been a great concern to our residents. There has been a great deal of home construction and an increase in illegal conversions and illegal uses of property. There is a concern with the loss of green space with the increase in development.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
The Department of City Planning (DCP) rezoned 350 blocks of Bayside in 2004, 135 blocks of Douglaston and Little Neck in 2006, 50 blocks of North Flushing/Auburndale in 2009, and 418 blocks of Auburndale, Hollis Hills, and Oakland Gardens in 2010. The goal of rezoning was to curtail overdevelopment and maintain the low density nature of the district. New zoning designations were also introduced for single family homes, R2A and R1-2A, to limit the size of homes. Ensuring compliance is important to residents to maintain the suburban-like feel of the neighborhoods in CB 11. There has been an increase in complaints to the Dept. of Buildings for illegal commercial use in a residential zone, illegal conversions, and illegal occupancy. Residents are still frustrated by the perceived inability of the Buildings Department to stop illegal construction, violation of zoning laws, and illegal occupancy.
DOB must continue to be funded to maintain an adequate number of plan examiners and inspectors. Many times, inspectors do not obtain access to the premises they must inspect. Access warrants are difficult to obtain in the courts, and the complainants feel that nothing is being done to stop illegal conditions. Unfortunately, in many cases this may be true, but balancing private property rights with government enforcement continues to be problematic.
Needs for Housing
No comments
Needs for Economic Development
This district has several thriving commercial strips along its main avenues. Bell Boulevard, between Northern Boulevard and 35 Avenue, is a Business Improvement District (BID). The BID helps fund improvements along the Bell Boulevard commercial strip. The Economic Development Corporation, working with the BID, has plans for a streetscape project on Bell Boulevard. The BID also sponsors events to attract new businesses and shoppers to the boulevard. This strip is known for the diversity of ethnic restaurants and nightlife in its various bars and restaurants. A concern of the residents is the continued closure of small businesses on Bell Boulevard being replaced by only bars and restaurants. The scarcity of parking spaces is also an issue that has been raised since it is necessary to attract customers. The BID is advocating the construction of a parking structure. Adjacent to the Douglaston LIRR Station, on the north side of the tracks, many businesses closed. The Douglaston Local Development Corporation, formed by local residents, is working to revitalize the area. The LDC maintains the DOT Public Plaza on the north side of the LIRR station and sponsors public events. Along Northern Boulevard, several new commercial retail stores are being developed. While many of the stores have been leased, there seems to be a lot of turnover and many stores remain vacant. In the meantime, businesses are also closing in the older storefronts along these commercial strips. Two hotels are under construction on Horace Harding Expressway and Utopia Parkway. This is a major change in the neighborhood. In Little Neck, in the one M1-1 district in the board, a new business, a watch assembly plant, has taken over an old business that moved and another new building will be constructed to house a Northwell Health Core Laboratory for NYC Health + Hospitals and Northwell Health System.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
1/29 DOB Address illegal
conversions and uses of buildings
411199602E - Increase the number of support staff for plan examiners, inspectors, and community affairs to improve service delivery.
TRANSPORTATION
Queens Community Board 11
image
M ost Important Issue Related to Transportation and Mobility
Traffic safety
The Community Board office is receiving an increasing number of complaints and concerns about traffic safety due to the increase of bicycle lane miles in the district, mainly along Northern Boulevard between Douglaston Parkway and 223rd Street. There are numerous Parkway entrances, curb cuts and bus stops which make this bicycle lane safety-reducing and congestion-creating. Also, there are many requests for traffic calming devises such as speed bumps, speed cameras, four-way stops, turn signals, and redesign of roads in order to make the roads in Community Board 11 safer for drivers and pedestrians.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Four major expressways and service roads intersect CB 11: the Long Island Expressway, the Grand Central Parkway, the Clearview Expressway, and the Cross Island Expressway. Resurfacing and maintenance of roads is a priority to the Board. Comptroller Stringer ClaimStat Alert cited the Grand Central Pkwy and the Long Island Expressway as the thoroughfares generating some of the highest number of pothole claims. This district has one of the highest rates of car ownership. There is no rapid transit; there are express and local buses and the Port Washington branch of the Long Island Railroad.
Needs for Transit Services
The residents of CB 11 are totally dependent on buses, car services, personal cars and the Long Island Railroad for their transportation needs. This Board also has one of the highest percentages of families with cars. Express buses and the Port Washington Branch of the LIRR are the most efficient methods of travel to Manhattan. Otherwise, bus service to subway lines in Flushing, Kew Gardens or Jamaica is necessary. Concerns with frequency of service has often been a concern to residents.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/28
DOT
Install streetscape
Provide a shared pedestrian / bicycle lane on
Northern Blvd
improvements
the North sidewalk of Northern Boulevard from
223rd St
Douglaston Parkway to 223rd Street. From the
Douglaston
Cross Island Parkway to Douglaston Parkway
Pkwy
occupies NYCDOT's 15 foot wide sidewalk. The
work requires removing 2,500 +/- feet of
existing sidewalk and building an 11 +/- foot
wide pedestrian/bicycle lane with existing 4 +/-
foot curb strip as a traffic buffer. Bridge
widening is not recommended. Use cautionary
signs at bridge and all driveways and
obstructions. Remove and replace fences,
shrubs, scrub trees, fill and grade and relocate
two lighting standards. No major trees are
affected.
2/28
DOT
Roadway
For many years, the City of New York has not
maintenance (i.e.
had a curb repair project. Community Board 11
pothole repair,
is inundated with new and old sidewalks on
resurfacing, trench
public and private properties which are not
restoration, etc.)
protected by curbs.
3/28
DOT
Repair or construct
Replace median curbs and pedestrian ramps on
42 Ave
new curbs or
42 Avenue from Francis Lewis Blvd to 213
Francis Lewis
pedestrian ramps
Street. Curbs are worn away and/or destroyed
Blvd 213 St
during resurfacing.
8/28
DOT
Other
Noise and fumes from the Long Island
Long Island
transportation
Expressway causes a detriment to the quality of
Expressway
infrastructure
life for Bayside residents living nearest the
210th Street
requests
highway. The construction of sound pads along
Springfield
the service road has been partially done and
Boulevard
should be completed in Community Board 11 to
Fresh Meadow Lane.
9/28
DOT
Reconstruct streets
Streets in Douglas Manor and Douglaston Hill
require a capital project to reconstruct the
streets because they have no concrete base and
cannot be milled and paved.
18/28
NYCTA
Improve
The lack of handicap accessibility at the
41st Avenue
accessibility of
Douglaston Rail Road Station is a serious
transit
concern. Elevator service will help disabled
infrastructure, by
residents and allow the site to conform to the
providing elevators,
Federal Americans with Disabilities Act.
escalators, etc.
19/28
DOT
Install streetscape
This triangle adjacent to city property does not
Commonwealth
improvements
have a sidewalk installed. Sidewalk installation
Boulevard
would allow pedestrians to better traverse the
Grand Central
neighborhood.
Parkway
Cullman
Avenue
24/28
DOT
Repair or build new
The staircase at the south side of the
235th Street
step streets
Douglaston Train Station begins at 235th Street
and Poplar
and goes to Poplar Street. It requires
Street,
reconstruction as it is uneven, in general
Douglaston
disrepair and needs a proper banister.
25/28
DOT
Repair or construct
The curbs are crumbling and broken on Horace
new curbs or
Harding Expressway from Utopia Parkway to
pedestrian ramps
Underhill Avenue. They are a trip hazard and
damage parked automobiles.
28/28
DOT
Reconstruct streets
244th Street between 43rd Avenue and 44th
244 Street 43
Avenue has deteriorated potholes and
Avenue 44
deteriorated pavement. DOT is already looking
Avenue
into this location as a site for capital
improvement.
CS
DOT
Other
411200703C - Reconstruct Streets on 223 Street
223 St 37 Ave
transportation
between 37 Avenue and 41 Avenue in
41 Ave
infrastructure
conjunction with DEP to install proper storm
requests
sewers. The street is sinking, bumpy, and
uneven. Drainage of water along a gully must
be replaced with storm sewers and the street
must be totally reconstructed.
CS
DOT
Roadway
Increase funding for pothole repair. Comptroller
maintenance (i.e.
Stringer's ClaimStat report indicated the
pothole repair,
increase in claims due to potholes. The severe
resurfacing, trench
winters and the damage from road salt causes
restoration, etc.)
more potholes.
CS
DOT
Repair or construct
Fund curb repair / replacement contract to
Union Tpke
new curbs or
address substantial work needed throughout
Hollis Hills
pedestrian ramps
the CB 11 district. Priority locations are center
Terrace
island malls: Union Turnpike Mall between
Springfield
Springfield Blvd. and Hollis Hills Terrace
Blvd
CS
DOT
Install streetscape
411201401C- Fund Phase 2 of the Bayside
Bell Blvd
improvements
Village BID Bell Boulevard Streetscape
Northern Blvd
Improvement Project. Phase 1 of the
35 Ave
Streetscape Improvement Project has funds for
the planned construction and funding for design
work for Phase 2 ($1,000,000) is needed to
complete the project.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
2/29
DOT
Conduct traffic or
411201401E - Due to the increase in traffic,
parking studies
there are many more requests for traffic studies
for signals, stop signs, and speed bumps. Traffic
studies are very backlogged and the Board
requests increased funding for the hiring of
additional traffic engineers to conduct studies.
10/29
DOT
Other expense
411198904E - Increase arterial highway
traffic
maintenance personnel and scheduled times for
improvements
cleaning; LIE, Cross Island Parkway, Clearview
requests
Expy., Grand Central Pkwy.
15/29
NYCTA
Expand bus service
CB 11 and all of northeast Queens is totally
frequency or hours
dependent on bus service. Several lines are
of operation
always crowded with riders, many students
going to and from schools along the line. Q88
would benefit from Limited Service buses. This
route runs from Bayside to Elmhurst, a very long
route that would help riders reach their
destinations in a more timely manner. Q12 on
Northern Blvd. runs from the City Line to
Flushing and would benefit from Limited Service
buses. The Q36 Serves Floral Park, Little Neck
and Jamaica, and the district would benefit
from evening and weekend service.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 11
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Forestry services, including street tree maintenance
This district has three large parks and the streets are lined with street trees. The maintenance and care of the trees has been a major concern of our residents especially following property and personal damage from storms in recent years. Comptroller Stringer, in his report "CompStat", cited the Parks Dept. claims as one of the highest. The longer a tree pruning cycle is, the higher the number of claims.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Parks and trees are the gems of this district. There are approximately 900 acres of parkland in CB 11. There are three large parks, three smaller park areas, lakes, a golf course, a golf driving range, a marina, many GreenStreets and streets that are lined with trees. CB 11 is on the North Shore of Queens overlooking Little Neck Bay and has extensive wetlands. Alley Pond Environmental Center sits on parkland at the edge of the wetlands. Conservation and preservation of our green spaces is a high priority in CB 11.
Needs for Cultural Services
No comments
Needs for Library Services
Libraries in CB 11 are used extensively, but some of our facilities are small and cannot accommodate the level of activity.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
4/28
DPR
Provide a new or
411200306C - Acquire the remaining lots in
Udalls Cove
expanded park or
Udall's Cove which is necessary to preserve
Northern Blvd
amenity (i.e.
wetlands from development.
42 Ave
playground, outdoor
athletic field)
5/28
DPR
Provide a new or
411200008C - Block 8112 Lots 184, 170, 70 The
expanded park or
acquisition of these lots is crucial for the
amenity (i.e.
protection of freshwater wetlands and the
playground, outdoor
preservation of natural habitats of wildlife.
athletic field)
These lots are in jeopardy of being developed.
6/28
QL
Create a new, or
411201104C- Expansion of Bayside Branch
renovate or upgrade
Library. Bayside Library is inadequate to
an existing public
continue providing quality services. The building
library
is only 10,300 Sq ft. In contrast, a standard new
library is now up to 18,000 sq. ft. Windows and
doors need replacement
10/28
DPR
Reconstruct or
411200902C - PS 130's playground is in poor
upgrade a park or
condition. The asphalt is broken, the safety
amenity (i.e.
surface is lifting up, and ball court lines are
playground, outdoor
faded. The broken surfaces are hazardous for
athletic field)
children's use.
11/28
DPR
Reconstruct or
411201203C - The Underhill Park basketball
upgrade a park or
court on Peck Avenue and 189 Street needs
amenity (i.e.
renovation. Baseball fields 4 & 5 located from
playground, outdoor
189 Street to 192 Street require regrading of the
athletic field)
surface. The Basketball courts flood and needs
renovation.
12/28
DPR
Provide a new or
411200906C - Transfer an HPD owned property
expanded park or
located at 234th Street and the corner of 39th
amenity (i.e.
Avenue (Block 8082 Lot 55) to the Parks Dept.
playground, outdoor
Currently, this lot is owned by HPD and cannot
athletic field)
be developed for affordable housing due to
zoning designation. HPD has to dispose of the
land. The community would like the Department
of Parks and Recreation to acquire and develop
the land for a community park.
13/28
DPR
Provide a new or
411201302C - Acquire vacant land, Block 8099
expanded park or
Lot 135 on 235 St. (south of LIRR station)
amenity (i.e.
Acquisition is requested to preserve vacant land
playground, outdoor
from development. Part of this lot was
athletic field)
purchased by the Parks Dept. in 2001 to become
part of Old Oak Pond, Alley Park Addition.
14/28
DPR
Other requests for
Improve and repair various greenstreets and
park, building, or
malls within the district. Glenwood Landing
access
needs landscaping improvements and repairs to
improvements
stairways and walls that are deteriorating.
Nassau Mall needs landscaping, repair of
walkways, and bench repair. Alameda Mall
curbs are eroded causing damage from flooding
16/28
DPR
Reconstruct or
John Golden Park- repave paths, repair catch
upgrade a park or
basins, create overlook seating for Little Neck
amenity (i.e.
Bay view, add fencing.
playground, outdoor
athletic field)
17/28
DPR
Reconstruct or
411200704C - Rehabilitate Potomagetten Pond
upgrade a park or
located north of the Grand Central Pkwy
amenity (i.e.
between Bell Blvd. and Springfield Blvd. This
playground, outdoor
park area had once been an active park with a
athletic field)
pond and sitting areas. It has since deteriorated
and is unusable. It needs restoration in order to
be used as a neighborhood park. Parks Dept.
recommended that project is ideal for DEP
Bluebelt.
26/28
DPR
Improve access to a
The center malls on 46th Avenue between 193rd
46 Avenue
park or playground
Street and 195th Street contain broken curbs.
193 Street
They should be repaired with steel curbs. This is
195 Street
also the case with the malls at 188th Street
from 47th Avenue to 48th Avenue.
CS
DPR
Other requests for
Rehabilitation of the Bayside Hills Malls.
Bell Blvd
park, building, or
Replacement of curbs, restoration of cupolas
Horace
access
and landscaping. Funded project, currently in
Harding
improvements
final design.
Expwy 48 Ave
CS
DPR
Improve access to a
411201604C - Resurface and improve the
park or amenity (i.e.
Vanderbilt Motor Parkway walking/bike path
playground, outdoor
with benches and lighting.
athletic field)
CS
DPR
Provide a new, or
411200903C - Alley Pond Environmental Center
new expansion to, a
Building Budget estimates for the building
building in a park
exceed the funded amount. More funds are
needed for the new building.
CS QL Create a new, or renovate or upgrade an existing public library
411200806C- New Little Neck/Douglaston library branch building. The current building is only 10,200 square feet. There is no room for programming events and shelf space is very limited. New libraries are built with about 18,000 sq. ft. A second story addition will double the size to 20,400 square feet.
image
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
411200502C - PS 811 , Challenge Playground , is adjacent to the school for handicapped children and serves the community of Deepdale Gardens Apartments. It still has an old cement wading pool which must be replaced with a modernized spray shower. This old pool is dangerous.
image
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
411200304C - Renovate Dermody Square at 216th Street and 48th Avenue; including new benches, footpath, and landscaping. There are NYS funds allotted for the project
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
5/29
DPR
Forestry services,
411199002E - Street tree pruning must be
including street tree
maintained at a 7-year cycle. Otherwise, the risk
maintenance
of dead limbs and falling trees will cause
personal and property damage. The
Comptroller's report shows that if the pruning
cycle is expanded the number of claims
increase.
6/29
DPR
Forestry services,
411198703E - There are about 1,000 tree
including street tree
stumps that still must be removed. They are
maintenance
hazarous obstructions on public property and a
standalone citywide stump removal contract is
needed.
7/29
DPR
Forestry services,
411201301E - Park tree pruning in Alley Pond,
including street tree
Crocheron, John Golden, Udalls Cove, Vanderbilt
maintenance
Motor Parkway, and Old Oak Pond.
image
8/29 DPR Other street trees
and forestry services requests
411200702E - Tree and Sidewalk Program funding increase. Due to the large number of old city street trees in our district, many sidewalks are lifted by the tree roots. This program has helped to repair these sidewalks and make them safe. A priority system is used and many locations are still not reached with the limit on funds available.
image
9/29 DPR Provide better park
maintenance
411200601E - Provide more park maintenance crews in area parks.
image
20/29 DPR Plant new street
trees
411201201E - The CB supports the planting of new street trees to increase the tree canopy for all the value it produces for the environment.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
27/29
Other
Other expense
DFTA - In order to stay in their homes and
budget request
maintain them seniors need a referral program
for discounted or free reliable minor home
repair service. There is currently only one such
program citywide. Seniors are afraid of being
victims of scams or unscrupulous repair services.
28/29
Other
Other expense
DFTA - As people age they tend to need various
budget request
legal services to protect themselves and
maintain the assets they do have. In Queens,
there is only one program that provides legal
services to the elderly. More discounted or free
services are needed.
29/29
Other
Other expense
The Bayside Historical Society has been
215-15 42nd
budget request
overseeing the Lawrence Cemetery since 1967
Ave, Bayside,
and has requested that the City maintain the
NY
grounds there. Tours are regularly given there
for the community including school groups.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/28
DOT
Install streetscape
Provide a shared pedestrian / bicycle lane on
Northern Blvd
improvements
the North sidewalk of Northern Boulevard from
223rd St
Douglaston Parkway to 223rd Street. From the
Douglaston
Cross Island Parkway to Douglaston Parkway
Pkwy
occupies NYCDOT's 15 foot wide sidewalk. The
work requires removing 2,500 +/- feet of
existing sidewalk and building an 11 +/- foot
wide pedestrian/bicycle lane with existing 4 +/-
foot curb strip as a traffic buffer. Bridge
widening is not recommended. Use cautionary
signs at bridge and all driveways and
obstructions. Remove and replace fences,
shrubs, scrub trees, fill and grade and relocate
two lighting standards. No major trees are
affected.
2/28
DOT
Roadway
For many years, the City of New York has not
maintenance (i.e.
had a curb repair project. Community Board 11
pothole repair,
is inundated with new and old sidewalks on
resurfacing, trench
public and private properties which are not
restoration, etc.)
protected by curbs.
3/28
DOT
Repair or construct
Replace median curbs and pedestrian ramps on
42 Ave
new curbs or
42 Avenue from Francis Lewis Blvd to 213
Francis Lewis
pedestrian ramps
Street. Curbs are worn away and/or destroyed
Blvd 213 St
during resurfacing.
4/28
DPR
Provide a new or
411200306C - Acquire the remaining lots in
Udalls Cove
expanded park or
Udall's Cove which is necessary to preserve
Northern Blvd
amenity (i.e.
wetlands from development.
42 Ave
playground, outdoor
athletic field)
5/28
DPR
Provide a new or
411200008C - Block 8112 Lots 184, 170, 70 The
expanded park or
acquisition of these lots is crucial for the
amenity (i.e.
protection of freshwater wetlands and the
playground, outdoor
preservation of natural habitats of wildlife.
athletic field)
These lots are in jeopardy of being developed.
6/28
QL
Create a new, or
411201104C- Expansion of Bayside Branch
renovate or upgrade
Library. Bayside Library is inadequate to
an existing public
continue providing quality services. The building
library
is only 10,300 Sq ft. In contrast, a standard new
library is now up to 18,000 sq. ft. Windows and
doors need replacement
7/28
FDNY
Other FDNY facilities
Provide generators in all fire houses.
and equipment
411201009C - Only the Battalion headquarters
requests (Capital)
has its own generator. FDNY is installing them in
firehouses and we support the continued
funding in order for all of our houses to have
one. The three fire houses in CB 11 are E-306, E-
313 and E-320. The FDNY priority is for E-313.
8/28
DOT
Other
Noise and fumes from the Long Island
Long Island
transportation
Expressway causes a detriment to the quality of
Expressway
infrastructure
life for Bayside residents living nearest the
210th Street
requests
highway. The construction of sound pads along
Springfield
the service road has been partially done and
Boulevard
should be completed in Community Board 11 to
Fresh Meadow Lane.
9/28
DOT
Reconstruct streets
Streets in Douglas Manor and Douglaston Hill
require a capital project to reconstruct the
streets because they have no concrete base and
cannot be milled and paved.
10/28
DPR
Reconstruct or
411200902C - PS 130's playground is in poor
upgrade a park or
condition. The asphalt is broken, the safety
amenity (i.e.
surface is lifting up, and ball court lines are
playground, outdoor
faded. The broken surfaces are hazardous for
athletic field)
children's use.
11/28
DPR
Reconstruct or
411201203C - The Underhill Park basketball
upgrade a park or
court on Peck Avenue and 189 Street needs
amenity (i.e.
renovation. Baseball fields 4 & 5 located from
playground, outdoor
189 Street to 192 Street require regrading of the
athletic field)
surface. The Basketball courts flood and needs
renovation.
12/28
DPR
Provide a new or
411200906C - Transfer an HPD owned property
expanded park or
located at 234th Street and the corner of 39th
amenity (i.e.
Avenue (Block 8082 Lot 55) to the Parks Dept.
playground, outdoor
Currently, this lot is owned by HPD and cannot
athletic field)
be developed for affordable housing due to
zoning designation. HPD has to dispose of the
land. The community would like the Department
of Parks and Recreation to acquire and develop
the land for a community park.
13/28
DPR
Provide a new or
411201302C - Acquire vacant land, Block 8099
expanded park or
Lot 135 on 235 St. (south of LIRR station)
amenity (i.e.
Acquisition is requested to preserve vacant land
playground, outdoor
from development. Part of this lot was
athletic field)
purchased by the Parks Dept. in 2001 to become
part of Old Oak Pond, Alley Park Addition.
14/28
DPR
Other requests for
Improve and repair various greenstreets and
park, building, or
malls within the district. Glenwood Landing
access
needs landscaping improvements and repairs to
improvements
stairways and walls that are deteriorating.
Nassau Mall needs landscaping, repair of
walkways, and bench repair. Alameda Mall
curbs are eroded causing damage from flooding
15/28
DEP
Inspect water main
Replace water mains in Little Neck. Due to
Leith Road
on specific street
topography of area and age of pipes water
Browvale
segment and repair
periodically is brown coming out of the taps.
Lane Brattle
or replace as
Ave
needed (Capital)
16/28
DPR
Reconstruct or
John Golden Park- repave paths, repair catch
upgrade a park or
basins, create overlook seating for Little Neck
amenity (i.e.
Bay view, add fencing.
playground, outdoor
athletic field)
17/28
DPR
Reconstruct or
411200704C - Rehabilitate Potomagetten Pond
upgrade a park or
located north of the Grand Central Pkwy
amenity (i.e.
between Bell Blvd. and Springfield Blvd. This
playground, outdoor
park area had once been an active park with a
athletic field)
pond and sitting areas. It has since deteriorated
and is unusable. It needs restoration in order to
be used as a neighborhood park. Parks Dept.
recommended that project is ideal for DEP
Bluebelt.
18/28
NYCTA
Improve
The lack of handicap accessibility at the
41st Avenue
accessibility of
Douglaston Rail Road Station is a serious
transit
concern. Elevator service will help disabled
infrastructure, by
residents and allow the site to conform to the
providing elevators,
Federal Americans with Disabilities Act.
escalators, etc.
19/28
DOT
Install streetscape
This triangle adjacent to city property does not
Commonwealth
improvements
have a sidewalk installed. Sidewalk installation
Boulevard
would allow pedestrians to better traverse the
Grand Central
neighborhood.
Parkway
Cullman
Avenue
20/28
NYPD
Provide surveillance
Between September 23, 2018 and September
Horace
cameras
26, 2018 there were over 23 reported incidents
Harding
of burglary, theft, and robbery. The location
Expressway
suggested is a choke-point for traffic of both the
254th Street
west-bound Long Island Expressway and north-
255th Street
bound Cross Island Expressway. A surveillance
camera at this location would help deter crime.
21/28
DEP
Evaluate a public
There are two seepage basins at 194th Street
194th Street
location or property
and 46th Avenue. A permanent storm drain
and 46th
for green
should be installed in its place.
Avenue,
infrastructure, e.g.
Queens
rain gardens,
stormwater
greenstreets, green
playgrounds
22/28
DEP
Evaluate a public
The intersections on West Drive from Park Lane
West Drive
location or property
to Bayview Road puddle and pond after rain
Park Lane
for green
storms. The existing Shore Road storm drain
Bayview Road
infrastructure, e.g.
should be extended up the side streets and
rain gardens,
include catch basins on all eastern corners.
stormwater
greenstreets, green
playgrounds
23/28
DEP
Evaluate a public
The entirety of Richmond Road ponds during
Richmond
location or property
and after rain storms which frequently overflow
Road Shore
for green
into neighboring yards. The high water table
Road Douglas
infrastructure, e.g.
adds a constant flow of water that keeps
Road
rain gardens,
portions of Richmond and Douglas Roads
stormwater
flooded. Storm drains and catch basins are
greenstreets, green
needed.
playgrounds
24/28
DOT
Repair or build new
The staircase at the south side of the
235th Street
step streets
Douglaston Train Station begins at 235th Street
and Poplar
and goes to Poplar Street. It requires
Street,
reconstruction as it is uneven, in general
Douglaston
disrepair and needs a proper banister.
25/28
DOT
Repair or construct
The curbs are crumbling and broken on Horace
new curbs or
Harding Expressway from Utopia Parkway to
pedestrian ramps
Underhill Avenue. They are a trip hazard and
damage parked automobiles.
26/28
DPR
Improve access to a
The center malls on 46th Avenue between 193rd
46 Avenue
park or playground
Street and 195th Street contain broken curbs.
193 Street
They should be repaired with steel curbs. This is
195 Street
also the case with the malls at 188th Street
from 47th Avenue to 48th Avenue.
27/28
NYPD
Provide surveillance
There is a chronic condition of after-school
Union
cameras
fights and assaults at this location. In the recent
Turnpike and
past, the occurrences have become more violent
Springfield
and brazen. The community believes this would
Boulevard,
be the ideal location for a surveillance camera.
Queens
28/28
DOT
Reconstruct streets
244th Street between 43rd Avenue and 44th
244 Street 43
Avenue has deteriorated potholes and
Avenue 44
deteriorated pavement. DOT is already looking
Avenue
into this location as a site for capital
improvement.
CS
DSNY
Provide new or
411201601C - The QN11 DSNY garage is funded
upgrade existing
for renovations due to its inability to handle the
sanitation garages
load of the collection trucks. We add our
or other sanitation
continued support to ensure that the project
infrastructure
starts.
CS
DEP
Evaluate a public
411201602C - The neighborhood of Doug-Bay is
233 St 38 Dr
location or property
on the shore of Little Neck Bay. Doug-Bay is in
41 Ave
for green
hurricane evacuation zones 1-6. During
infrastructure, e.g.
Superstorm Sandy, the area flooded. Residents,
rain gardens,
concerned with the event of future storms and
stormwater
soil depletion, have asked for flood mitigation
greenstreets, green
along Little Neck Bay. In the 1997, the Port
playgrounds
Authority enhanced the existing marsh habitat,
removed phragmites, and redesigned the tidal
inlets with berms. It was not to abate existing
flood problems and the berms would not offer
resistance. Due to the increase in severe storms
and the vulnerability of the area, it is requested
that a flood mitigation and soil depletion
project be considered for this area.
CS
DPR
Other requests for
Rehabilitation of the Bayside Hills Malls.
Bell Blvd
park, building, or
Replacement of curbs, restoration of cupolas
Horace
access
and landscaping. Funded project, currently in
Harding
improvements
final design.
Expwy 48 Ave
CS
DPR
Improve access to a
411201604C - Resurface and improve the
park or amenity (i.e.
Vanderbilt Motor Parkway walking/bike path
playground, outdoor
with benches and lighting.
athletic field)
CS
DOT
Other
411200703C - Reconstruct Streets on 223 Street
223 St 37 Ave
transportation
between 37 Avenue and 41 Avenue in
41 Ave
infrastructure
conjunction with DEP to install proper storm
requests
sewers. The street is sinking, bumpy, and
uneven. Drainage of water along a gully must
be replaced with storm sewers and the street
must be totally reconstructed.
CS
DPR
Provide a new, or
411200903C - Alley Pond Environmental Center
new expansion to, a
Building Budget estimates for the building
building in a park
exceed the funded amount. More funds are
needed for the new building.
CS
DOT
Roadway
Increase funding for pothole repair. Comptroller
maintenance (i.e.
Stringer's ClaimStat report indicated the
pothole repair,
increase in claims due to potholes. The severe
resurfacing, trench
winters and the damage from road salt causes
restoration, etc.)
more potholes.
CS
QL
Create a new, or
411200806C- New Little Neck/Douglaston
renovate or upgrade
library branch building. The current building is
an existing public
only 10,200 square feet. There is no room for
library
programming events and shelf space is very
limited. New libraries are built with about
18,000 sq. ft. A second story addition will double
the size to 20,400 square feet.
CS
DOT
Repair or construct
Fund curb repair / replacement contract to
Union Tpke
new curbs or
address substantial work needed throughout
Hollis Hills
pedestrian ramps
the CB 11 district. Priority locations are center
Terrace
island malls: Union Turnpike Mall between
Springfield
Springfield Blvd. and Hollis Hills Terrace
Blvd
CS
DPR
Reconstruct or
411200502C - PS 811 , Challenge Playground , is
upgrade a park or
adjacent to the school for handicapped children
amenity (i.e.
and serves the community of Deepdale Gardens
playground, outdoor
Apartments. It still has an old cement wading
athletic field)
pool which must be replaced with a modernized
spray shower. This old pool is dangerous.
CS
DOT
Install streetscape
411201401C- Fund Phase 2 of the Bayside
Bell Blvd
improvements
Village BID Bell Boulevard Streetscape
Northern Blvd
Improvement Project. Phase 1 of the
35 Ave
Streetscape Improvement Project has funds for
the planned construction and funding for design
work for Phase 2 ($1,000,000) is needed to
complete the project.
CS
DPR
Reconstruct or
411200304C - Renovate Dermody Square at
upgrade a park or
216th Street and 48th Avenue; including new
amenity (i.e.
benches, footpath, and landscaping. There are
playground, outdoor
NYS funds allotted for the project
athletic field)
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/29
DOB
Address illegal
411199602E - Increase the number of support
conversions and
staff for plan examiners, inspectors, and
uses of buildings
community affairs to improve service delivery.
2/29
DOT
Conduct traffic or
411201401E - Due to the increase in traffic,
parking studies
there are many more requests for traffic studies
for signals, stop signs, and speed bumps. Traffic
studies are very backlogged and the Board
requests increased funding for the hiring of
additional traffic engineers to conduct studies.
3/29
DFTA
Create a new senior
Fund a senior center in western part of the
center or other
district, in Auburndale. Bayside Senior Center is
facility for seniors
in the center of the district and the Samuel Field
Y serves the eastern end of the district.
4/29
DFTA
Increase case
Additional funding is needed to reduce social
80-45
management
worker caseloads currently about 65 cases per
Winchester
capacity
worker. Reductions in caseload will improve
Blvd
service delivery to the elderly. SNAP serves
Community Boards 8, 11, and 13.
5/29
DPR
Forestry services,
411199002E - Street tree pruning must be
including street tree
maintained at a 7-year cycle. Otherwise, the risk
maintenance
of dead limbs and falling trees will cause
personal and property damage. The
Comptroller's report shows that if the pruning
cycle is expanded the number of claims
increase.
6/29
DPR
Forestry services,
411198703E - There are about 1,000 tree
including street tree
stumps that still must be removed. They are
maintenance
hazarous obstructions on public property and a
standalone citywide stump removal contract is
needed.
7/29
DPR
Forestry services,
411201301E - Park tree pruning in Alley Pond,
including street tree
Crocheron, John Golden, Udalls Cove, Vanderbilt
maintenance
Motor Parkway, and Old Oak Pond.
8/29
DPR
Other street trees
411200702E - Tree and Sidewalk Program
and forestry
funding increase. Due to the large number of
services requests
old city street trees in our district, many
sidewalks are lifted by the tree roots. This
program has helped to repair these sidewalks
and make them safe. A priority system is used
and many locations are still not reached with
the limit on funds available.
9/29
DPR
Provide better park
411200601E - Provide more park maintenance
maintenance
crews in area parks.
10/29
DOT
Other expense
411198904E - Increase arterial highway
traffic
maintenance personnel and scheduled times for
improvements
cleaning; LIE, Cross Island Parkway, Clearview
requests
Expy., Grand Central Pkwy.
11/29
NYPD
Assign additional
Due to an increase in the number of high school
school safety
students and the need to better protect students
officers
and monitor all entrances to the schools, there
is a need for additional school safety officers.
There are three overcrowded high schools in CB
11: Cardozo, Francis Lewis, and Bayside. All
could use additional officers.
12/29
DFTA
Increase
The senior centers in the district provide
transportation
transportation for seniors to go to the centers,
services capacity
get to doctors and hospitals as well as for
shopping. The centers need additional funding
to provide these services for all who need it.
13/29
DYCD
Provide, expand, or
There is only one after-school programming site
enhance after
in this district. The Mayor aimed to provide free
school programs for
after-school programs for all schools.
elementary school
students (grades K-
5)
14/29
DYCD
Provide, expand, or
Provide, expand, or enhance after school
enhance after
programs for middle school students. There is
school programs for
only one after-school program in CB 11
middle school
students (grades 6-
8)
15/29
NYCTA
Expand bus service
CB 11 and all of northeast Queens is totally
frequency or hours
dependent on bus service. Several lines are
of operation
always crowded with riders, many students
going to and from schools along the line. Q88
would benefit from Limited Service buses. This
route runs from Bayside to Elmhurst, a very long
route that would help riders reach their
destinations in a more timely manner. Q12 on
Northern Blvd. runs from the City Line to
Flushing and would benefit from Limited Service
buses. The Q36 Serves Floral Park, Little Neck
and Jamaica, and the district would benefit
from evening and weekend service.
16/29
NYPD
Other NYPD staff
411199901E - Increase the number of Civilian
45-06 215
resources requests
Personnel at the 111th Precinct. In order to
Street
maintain the security we have obtained, the
precinct must be staffed adequately. Adding
civilian personnel will allow more uniformed
officers on the street.
17/29
DEP
Clean catch basins
411201202E - Fund additional crews to clean
and maintain catch basins to alleviate backlog
of service repair requests.
18/29
DSNY
Expand disposal
Hazardous waste events have been very
events for
popular, creating long lines for drop-off. Holding
hazardous
the events more frequently will assist residents
household waste
in the area.
19/29
DOHMH
Other programs to
Provide adequate, comprehensive and effective
address public
funding for epidemiology and control of air-
health issues
borne, water-borne, and vector (mosquito)
requests
diseases.
20/29
DPR
Plant new street
411201201E - The CB supports the planting of
trees
new street trees to increase the tree canopy for
all the value it produces for the environment.
21/29
DEP
Evaluate a street
34th Avenue between 211th Street and 213th
34th Avenue
segment or
Street frequently floods onto adjacent private
211th Street
intersection for
properties when it rains. This is due to improper
213th Street
green infrastructure,
street grading and a lack of storm sewers on
e.g. rain gardens,
this stretch. Storm drains are needed.
stormwater
greenstreets, and
plan for
construction if
feasible
22/29
DFTA
Enhance NORC
Funds are needed from the Federal, State and
programs and
City government to establish additional NORC's.
health services
There is one existing NORC's in the district. It is
Deepdale Cares at the Deepdale Gardens
complex operated by the Samuel Field Y. There
are other developments in CB 11 that may
qualify as NORCs and its residents would benefit
from these services. These programs help keep
seniors in their homes and prevents
institutionalization.
23/29
NYPD
Assign additional
There is a high demand for school crossing
crossing guards
guards at all school intersections in the district.
Some school locations are near major highway
overpasses, such as MS 74, MS 67 and PS 159. It
is imperative that crossing guards are available
for those locations.
24/29
DEP
Inspect storm sewer
411200703C - Reconstruct Streets and Install
223 St 37 Ave
on specific street
Drainage System on 223 Street between 37
41 Ave
segment and
Avenue and 41 Avenue. Drainage from storm
service, repair or
water in the street is served by a gully running
replace as needed
along the side curb line. Flooding is problematic.
The system must be constructed to drain water
from the surrounding streets. Placed on ten year
plan, funding is needed to proceed.
25/29
DEP
Inspect storm sewer
Marathon Pkwy, Commonwealth Blvd., and 64
Marathon
on specific street
Avenue- This location is flooded due to non-
Parkway
segment and
functioning seepage basins in the area and has
Commonwealth
service, repair or
no connection to a storm sewer. The location
Blvd 64 Ave
replace as needed
was removed from a recent storm sewer
project. Therefore, a capital project to install the
storm sewer is necessary.
26/29
DEP
Inspect storm sewer
411201301C - Non-functioning seepage basins
on specific street
must be replaced with new sewer systems to
segment and
relieve flooding North of Union Turnpike.
service, repair or
replace as needed
27/29
Other
Other expense
DFTA - In order to stay in their homes and
budget request
maintain them seniors need a referral program
for discounted or free reliable minor home
repair service. There is currently only one such
program citywide. Seniors are afraid of being
victims of scams or unscrupulous repair services.
28/29
Other
Other expense budget request
DFTA - As people age they tend to need various legal services to protect themselves and maintain the assets they do have. In Queens, there is only one program that provides legal services to the elderly. More discounted or free services are needed.
29/29
Other
Other expense budget request
The Bayside Historical Society has been overseeing the Lawrence Cemetery since 1967 and has requested that the City maintain the grounds there. Tours are regularly given there for the community including school groups.
215-15 42nd
Ave, Bayside, NY

