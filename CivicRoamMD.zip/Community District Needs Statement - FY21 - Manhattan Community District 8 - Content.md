- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 8 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1fTpBm3cXyemPY_R6MR1RpGIiek5U9Xl7/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1fTpBm3cXyemPY_R6MR1RpGIiek5U9Xl7/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
8
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 8
image
Address: 505 Park Avenue, Suite 620
Phone: (212) 758-4340
Email: info@cb8m.com
Website: www.cb8m.com
Chair: Alida Camp District Manager: Will Brightbill
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Roosevelt Island and the Upper East Side of Manhattan, from the north side of East 59th Street to the south side of East 96th Street between Fifth Avenue and the East River, comprise Manhattan Community District 8. In addition to our diverse population, we are home to dozens of diplomatic residences, world famous hospitals, medical research centers, and world-renowned museums.
According to the 2010 census, 229,688 people live on the Upper East Side of Manhattan, a 6.0% increase from 1990. Prosperous economic times and a major building boom that began during the 1990’s have added thousands of new dwelling units to the district. Today, the district continues to grow at an amazing pace. The 1999 median household income for the District was $74,134. Based on data from the 2000 census 6.5% of the individuals in the district live below the poverty level.
There is also a large segment of the population with special needs. More than 14% of CD8’s residents are senior citizens, with a high number of frail elderly. There is also a number of working poor living in the district. With affordable housing becoming increasingly scarce, commercial rent escalating, and the prices of goods and services dramatically rising, our middle class residents are struggling to meet their budgets. The influx of new residents, shoppers, and tourists have strained the delivery of municipal service.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 8
image
The three most pressing issues facing this Community Board are:
Affordable housing
Affordable housing-In response to New York City’s (NYC) and the district’s lack of sufficient affordable housing units; the Board has voiced its overall support of retaining and increasing affordable housing in the district. Additionally, the Board recommends rescinding the NYC Administrative Code §26-511, C, 9 of the NYC Rent Stabilization Law of 1969, a law that has increased institutional expansion within the district.
Parks
Parks-The aging East River Esplanade in the CD8 has been crumbling, creating a dangerous situation for its many users. Repairing it is an urgent necessity. And by implementing the existing, proposed designs for the Esplanade's repairs and improvements, the City can create a vital and long-lasting public amenity.
Schools
Schools-We need Pre-K, elementary, middle and high school seats because our district is woefully lacking in these now, and we are being overwhelmed with new high-rise construction featuring 3,4, and 5 bedrooms, thus encouraging families to purchase. The increase in the number of school children in our district will further overwhelm the system and the crowding in the existing schools will diminish the quality of the education for everyone. Also, a good school system keeps families from moving out of the city, and these families form our tax base which is desperately needed so as to provide the other services that the city requires. School funding is a necessity in our district and will determine the fate of the city.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 8
image
M ost Important Issue Related to Health Care and Human Services
Other
All of the above. Community Board 8 Manhattan remains strongly in favor of continued support for homeless services, mental health and substance abuse services, environmental health issues, senior services, domestic violence and elder abuse victims, and supports public and private sector efforts to assist the diverse population in our community. We are particularly concerned that with the city's homeless population at record setting levels, the Department for Homeless Services saw fit to promulgate, and persists in its attempts to implement, new shelter eligibility rules deemed likely to further swell the numbers of homeless single individuals. CB8M continues to support strongly the services and programs aimed at aiding those of our community who are in need.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
The main programs for seniors are offered by Lenox Hill Neighborhood House (partially funded by the New York City Housing Authority (NYCHA), Stanley M. Isaacs Neighborhood Center (a NYCHA facility), Carter Burden Center for the Aging, Roosevelt Island Senior Center, and Search and Care. CB8M has advocated for maintaining NYCHA social service programs, including the NYCHA senior centers at Lenox Hill and Stanley Isaacs, congregate meal programs, and the youth, family, and after school programs.
CB8M remains strongly in favor of continued support for homeless services and supports public and private sector efforts to assist the diverse homeless population in our community. A top capital priority is increased funding for permanent affordable housing for homeless individuals and families.
We support the efforts of the faith-based organizations to maintain their homeless shelter beds and of the food pantries in and out of our district to continue their work of feeding our hungry.
Overall, the area of homeless services continues to be one of loss and insufficiency. There is an urgent need for additional programs that address the root causes of homelessness.
Needs for Older NYs
The population of our district includes the largest percentage of older adults, 60+, in Manhattan (20.8%). A significant percentage of these (21.5%) live below the poverty level, or are frail, or both. Contrary to popular perception, it also includes a varying but seemingly growing number of individuals without shelter. In addition, soup kitchens, food pantries, and other food programs are seeing growing numbers of people.
A primary and consistent concern for our board is protecting the senior centers and programs that provide services to seniors regardless of income. These centers and programs provide older members of the community with social interaction and nutrition, two elements vital to maintaining their long-term health and well-being. It is imperative that senior center budgets be included in the Mayor’s budget, and we urge that in the future critical senior programs such as case management and elder abuse prevention be treated as essential budget items.
The main programs for seniors are offered by Lenox Hill Neighborhood House (partially funded by the New York City Housing Authority (NYCHA), Stanley M. Isaacs Neighborhood Center (a NYCHA facility), Carter Burden Center for the Aging, Roosevelt Island Senior Center, and Search and Care. CB8M has advocated for maintaining NYCHA social service programs, including the NYCHA senior centers at Lenox Hill and Stanley Isaacs.
Needs for Homeless
We are particularly concerned that with the city's homeless population at record setting levels, the Department for Homeless Services saw fit to promulgate, and persists in its attempts to implement, new shelter eligibility rules deemed likely to further swell the numbers of homeless single individuals.
Needs for Low Income NYs
CB8M continues to support strongly the services and programs aimed at aiding those of our community who are in need; they remain critically important. CB8M urges the City to respond strongly to this growing segment of our city’s population.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
1/14 DHS Other request for
services for the homeless
DHS should work closely with HPD to fund much needed housing for the most vulnerable of our residents. We ask that this request be given the necessary funding and highest priority in the Five-Year Plan.
image
10/14 DHS Upgrade existing
facilities for the homeless
Provide funding for air conditioning in all homeless shelters.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
4/26
DOHMH
Other animal and
Increase funding for rodent extermination on
pest control
city streets
requests
8/26
DFTA
Enhance home care
Increase funding for services to Older Adults
services
including Personal and Home Care,
Transportation Services, Meals-On-Wheels,
Senior Congregate Care Meal Programs and
Case Managers
10/26
DHS
Expand street
Increase funding for Homeless Services
outreach
Outreach personnel, especially during the
overnight hours and provide DHS with updated
information Technology equipment.
11/26
DOHMH
Other programs to
Increase funding for the Department of Health
address public
Enforcement of all food vendor rules and
health issues
regulations.
requests
17/26
DOHMH
Increase health
Provide funding for inspectors and enforcement
inspections, e.g. for
personnel in agencies dealing with restaurants
restaurants
and food trucks.
18/26
DFTA
Enhance programs
Provide funding for Eviction Prevention Services
for elder abuse
for At-Risk Senior Citizens.
victims
25/26 DHS, HRA
Provide, expand, or enhance rental assistance programs
Further increase funding for more permanent housing for homeless people.
image
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 8
image
M ost Important Issue Related to Youth, Education and Child Welfare
Other
All of the above. Community Board 8 Manhattan would like to see more school seats including Pre-K seats in all schools within the district, after school programming, youth workforce development and summer employment, adolescent substance abuse, child welfare, adoption and foster care, mental health services for youth, etc.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
CB8M is extremely concerned about the cutback in capital and expense funding which results in: overcrowding in our community district; conversion of cluster rooms to regular classrooms and a lack of specialty teachers for art, music, etc. for the schools in our district.
The Board and CD8 residents feel there is a great need for more Middle School seats in Community District 8, and supports increasing seats from 3-K to High School.
Youth and Community Services and Programs:
The Board also recognizes the importance of providing adequate day care and after school facilities for our children. There are many CD8 residents, especially single working parents, who need affordable day care and after school programs, but whose income slightly surpasses eligibility requirements. Additional affordable programs are essential. We continue to request increased funding for childcare and after-school programs, including infant care.
Needs for Youth and Child Welfare
The Board also recognizes the importance of providing adequate day care and after school facilities for our children. There are many CD8 residents, especially single working parents, who need affordable day care and after school programs, but whose income slightly surpasses eligibility requirements. Additional affordable programs are essential. We continue to request increased funding for childcare and after-school programs, including infant care.
An important issue yet to be adequately addressed is the need for programs to prevent abuse and neglect. CB8M feels that there is a need for strong evidence-based programs to provide intensive support to at-risk families. Such therapies will increase family functioning while reducing the need for unnecessary and costly out of home care.
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
1/26
DOE
Other educational
Fund 3-K and Pre-K seats in CB8
programs requests
2/26
DYCD
Provide, expand, or
Fund Out of School Time and DayCare programs
enhance after
for all children who go to school in CB8 or who
school programs for
have parents that work in CB8.
elementary school
students (grades K-
5)
3/26
DYCD
Other youth
Increase funding for youth programs in CB8.
workforce
development
requests
14/26
ACS
Provide, expand, or
Provide additional funding for Children Services,
enhance preventive
especially programs to prevent abuse and
services and
neglect.
community based
alternatives for
youth
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 8
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
All of the above. Community Board 8 Manhattan maintains a close working relationship with the 19th Precinct, Manhattan North, the Central Park Precinct, and the 114th Precinct, which serves Roosevelt Island from Queens. CB8M continues to be concerned about bike enforcement and the number of scams and fraud against the elderly and vulnerable as well as Grand Larceny and Pedestrian Safety cases. The Board is concerned about the rise of violent crimes in the district.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
CB8M supports full funding for all fire and emergency medical services in our district and citywide. CB8M is particularly concerned about the loss of fire marshals in recent years, and we have requested the restoration of funding for these personnel.
Needs for Emergency Services
CB8M supports the maintenance of emergency response capacity. The Board supports provision of ambulances with a mobile stroke treatment units.
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
15/26 NYPD Assign additional
traffic enforcement officers
Provide funding to increase the current number of Traffic Control agents.
image
16/26 NYPD Assign additional
traffic enforcement officers
Provide additional funding to expand the Truck Traffic Enforcement Unit.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 8
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Other
All the above. Community Board 8 Manhattan is responsive to residents’ concerns about sanitation and the environment. We receive numerous complaints and are trying to be responsive to our residents and businesses about sanitation and the environment. We continue to be concerned about the lack of corner baskets and request additional baskets which should be emptied on a more frequent basis. We strongly urge additional enforcement of commercial property owners who fail to clean their sidewalk and 18 inches from the curb into the street with emphasis on East 86th Street between Lexington and Second Avenues. We also need more garbage collections and street cleanings in an integrated approach to a cleaner community. We support more frequent sanitation inspections and efforts to consistently maintain presentable clean-swept sidewalks and streets.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
With regards to drinking water, CB8M passed a resolution in February 2012 in favor of DEP’s proposal to build a bypass tunnel to facilitate repair of the Delaware Aqueduct in order to ensure that DEP can continue to deliver high quality drinking water every day to NYC, and further resolved that this support is contingent upon DEP minimizing and mitigating potential environmental impacts in the areas where the work is to be performed, and upon DEP having an adequate plan in place to supplement the water supply with high-quality drinking water during the shut- down phase of up to 6 to 15 months of the Delaware Aqueduct.
CB8M supports additional inspections for flooding complaints, storm catch basins, and sewers. The Board supports additional resources for cleaning and maintenance of sewers and catch basins.
Needs for Sanitation Services
CB8M is responsive to residents’ concerns about sanitation and the environment. The cleanliness of our streets and neighborhoods is of great importance to our community and is related to successful business operations, to our well-being, and to the quality of life. In an integrated approach to a cleaner community, we support frequent sanitation inspections and efforts to consistently maintain presentable clean-swept sidewalks and streets. We support the Adopt-a-Basket program, and additional resources for education related to this program.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
8/14 DSNY Provide new or
increase number of sanitation trucks and other equipment
Fund the NYC Department of Sanitation for the placement of "rat-proof" garbage containers with lids in CD8, preferably solar powered compactor baskets. We ask the agency work closely with neighborhood groups and local BIDs to find funding for this request.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
20/26
DSNY
Other garbage collection and recycling requests
Increase recycling program including solid waste.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 8
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Other
All of the above. Community Board 8 Manhattan opposes the taking of any public space for private development, while we recognize the need for additional affordable housing in our district.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Zoning changes including R8-B enacted within the past fifteen years to protect the midblock from massive structures and R10-A governing use of the plaza bonus and towers on a base for avenues and cross-town streets have only slightly moderated development. New tall story buildings on some avenues, which currently are allowed, strain the infrastructure and municipal services, and reduce access to light and air. The Board supports a height limitation of 210 feet for new developments on Third, Second, First and York Avenues.
CB8M and local civic groups have urged the Department of City Planning to review the Community Facility provisions of the Zoning Resolution. CD8 is the only district where community facilities are entitled to a 5.1 FAR in the R8B mid-blocks. CB8M has proposed modifications to the Department of City Planning to change the current community facility in R8B areas from a 5.1 to a 4.0 FAR.
CB8M seeks to preserve the Upper East Side’s residential character. The C1 and C2 zoning (Local Retail Use) control commercial signage in the District. CB8M seeks to maintain a careful balance to prevent new buildings from detracting from CD8’s historic districts. CB8M believes that new and more effective regulations, coupled with increased enforcement, would ease this problem.
Roosevelt Island is undergoing major change with the addition of the Cornell Tech graduate center. The campus will occupy most of the southern part of the island. The graduate center benefits the community and city, but the quality of life of the residents must be protected while the island undergoes major construction for the years to come.
Needs for Housing
Community District 8 has a larger percentage of renters (37.5%) compared to rest of Manhattan (23%) and New York City (32%). Residents of Community District 8 pay more for rent than the rest of Manhattan and New York, indeed, median rent in CD8 was $2,290/month in 2016, the 3rd highest of all community districts in New York City -
$1,380/month. Conversely, median “asking rent” in Community District 8 was lower ($2,799) than in Manhattan ($3,195) or the City ($2,800). However, the difference between “asking rents” and “median rents” was closer in Community District 8 ($509) than the rest of Manhattan ($1,505) or New York City ($1,420). The percentage of rent- burdened residents (i.e., paying more than 30% of income for rent) was lower in Community District 8 (41.5%) than either Manhattan (45.9%) or New York City (53.5%) – although 19.5% of the district’s residents were paying over 50% of their income on rent. The district also has a smaller share of affordable units to low-income households than Manhattan or the City. Specifically, 12.5% of available units were affordable to households earning 80% of AMI, 4.7% for households earning 50% of AMI and 2.1% for households at 30% of AMI. In terms of rent regulated units, Community District 8 has a smaller share (33%) of units than Manhattan (44%) or the City (45%). Community District 8 has a higher median income ($119,261) than Manhattan ($79,077) or the City ($60,008) and a lower share of “low-income” (below 80% AMI) residents (27%) than Manhattan (47%) or the City (61%). The District also has a smaller share of residents living in poverty (6.5%) than Manhattan (17.3%) or New York City (18.9%). It does however, have a larger share of seniors (18.1%) than Manhattan (14.9%) or the City as a whole (13.5%). Overall, the district offers disproportionately few housing opportunities for low-income New Yorkers and needs much more affordable housing developments to meet the City’s affordable housing need and fair housing obligations.
Needs for Economic Development
CB8M works with the Madison Avenue Business Improvement District, the East Midtown Partnership and the DOE Fund on a range of issues. CB8M’s efforts on traffic and quality of life are critical to our local businesses. We support city programs that promote the retention and growth of local businesses.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
14/14 HPD Other affordable
housing programs requests (capital)
Provide more affordable housing for all income low and middle income New Yorkers.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
13/26
DOB
Address illegal
Hire additional DOB inspectors for compliance
conversions and
and code enforcement, and hire auditors for
uses of buildings
applications
21/26
EDC
Other public
Increase funding to ensure all NYCHA
housing
community and senior centers remain open.
maintenance,
Maintain all current open space.
staffing and
management
requests
23/26
EDC
Improve public
Provide more health and building inspectors for
housing
NYCHA facilities
maintenance and
cleanliness
TRANSPORTATION
Manhattan Community Board 8
image
M ost Important Issue Related to Transportation and Mobility
Other
All of the above. Our streets are unsafe in their present condition for pedestrians, motorists, and cyclists due to potholes and poorly paved streets.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Community Board 8 Manhattan has consistently ranked funding for street repair and maintenance high on its list of priorities, and we applaud the NYC Department of Transportation’s Manhattan Highway Maintenance Division on the job they do managing this substantial task, especially in light of its need for an additional pothole gang, that the Board strongly supports.
Traffic Congestion has become an increasing problem in Community District 8 and will get worse with the additional hospital construction projects and the Marine Transfer Station. We request that the proposed traffic study for the full length of York Avenue (paid for by CUNY MSK) be carried out as soon as possible.
Large numbers of residents, daily workers and visitors contribute to traffic congestion, for hire vehicles, noise, pollution, and crowded streets and sidewalks. Even with a second subway line traveling the East Side, public transit continues to be overwhelmed. The MTA/NYC Transit must work with commuters and the Board to address service issues such as punctuality, bus bunching and dwell times.
Needs for Transit Services
We support the need of more buses servicing bus lines in our district. The 4,5,6, and Q lines need additional service. We support full funding of the Fast Forward program, including enhanced technology to improve service.
image
Capital Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
5/14 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Provide Funding to NYC DOT for necessary materials and personnel to repair potholes and repave avenues curb to curb and major crosstown streets more frequently than every 10 years within CD8.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
7/26
DOT
Provide new traffic
Increase funding for audible accessible crossing
or pedestrian
signals for intersections in CD8
signals
12/26
DOT
Other expense
Increase the number of workers to inspect,
traffic
repair, and preserve the DOT's infrastructure --
improvements
both bridges and roads.
requests
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 8
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
All of the above. The aging East River Esplanade in Community District 8 has been crumbling, creating a dangerous situation for its many users. Repairing it is an urgent necessity. By implementing the existing proposed designs for the Esplanade, the city can create a vital and long-lasting public amenity. CD8 has among the least amount of parkland of any district in NYC. Preserving and enhancing our vital parks and open space is a critical priority. CD8 needs additional funding to redesign some of our most used parks, including Ruppert, John Jay, and phase 3 of Andrew Haswell Green. Additionally, we must protect other public space that is currently being taken for private use. Community Board 8 Manhattan passed a resolution strongly urging the City to return the Queensboro Oval Park to the public full-time and in conjunction with the Upper East Side community, has identified uses for a deprivatized Oval that would benefit a large portion of the public.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The population density of CD8 makes our parks and greenery a precious commodity. Although our district is adjacent to Central Park, open space in CD8 is woefully inadequate. According to results of a survey by the organization, New Yorkers for Parks, Manhattan’s Upper East Side has among the least amount of open space of any New York City district.
CB8M’s Parks Committee has been working to protect and expand the community’s limited parkland. Its on-going major projects include its Open Space initiative, launched in 2013 with a public forum on the Need for Open Space on Manhattan’s Upper East Side, and its East River Esplanade project, to renovate and beautify the Esplanade.
Needs for Cultural Services
We support cultural programming and the use community facilities to enhance the quality of life in our district.
Needs for Library Services
For more than a century, the New York Public Library has provided quality service to all New Yorkers. The branch libraries are an important public resource for local residents, especially senior citizens and students.
The library budget must be maintained. CB8M urges the Mayor and the City Council to maintain funding for the operating costs to allow the continuation of 7 day a week service at all branches. We also urge increased funding for infrastructure, technological improvements and library materials, particularly increased funding for books, periodicals, and other information resources in all our branch libraries.
Funding should be found to allow libraries to operate at full hours (i.e. 10-5 Monday through Sunday) and expanded evening hours at least twice a week.
As sources of information have evolved, the Library has kept pace, offering one of the only free points of access to the internet in New York City. CB8M believes that all New Yorkers should have free opportunities to use electronic resources. We support the restoration and enhancement of libraries in their use as a community facility.
Needs for Community Boards
We support strengthening the ability of community boards to provide vital services and information to our districts.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/14
NYPL
Create a new, or
Provide funding for a ramp or other means of
renovate or upgrade
accessibility at the Yorkville Branch Library.
an existing public
library
3/14
DPR
Other requests for
Provide funding to repair, restore, and design
park, building, or
the entire Esplanade including the piling on the
access
lower level between 60th and 125th Streets,
improvements
and install below ground infrastructure to
expand water access along the entire
Esplanade.
4/14
NYPL
Create a new, or
Providing funding for a new HVAC system at the
renovate or upgrade
Webster and Yorkville Branch Libraries.
an existing public
library
6/14
DPR
Reconstruct or
Provide funding to redesign and renovate
upgrade a park or
Ruppert as a whole, including the installation of
amenity (i.e.
new irrigation to improve and expand planting
playground, outdoor
areas.
athletic field)
7/14
DPR
Reconstruct or
Provide funding to redesign and renovate John
upgrade a park or
Jay Park as a whole.
amenity (i.e.
playground, outdoor
athletic field)
9/14
DPR
Other street trees
Install tree guards where missing from or when
and forestry
new trees go in and extend the tree pit where
services requests
needed.
11/14
NYPL
Create a new, or
Upgrade electrical system at Webster Branch
renovate or upgrade
Library.
an existing public
library
12/14
DPR
Other requests for
Fund a fully built Park along the East River
East River
park, building, or
between 60th and 63rd Streets on the
Esplanade
access
Esplanade including future phases 2B & 3 of
60th St 63rd
improvements
Andrew Haswell Green Park.
St
13/14
DPR
Other requests for
Fund the return of the Queensboro Oval to the
York Ave 59th
park, building, or
community for year round public use.
St 60th St
access
improvements
CS
NYPL
Create a new, or renovate or upgrade an existing public library
Provide funding for rooftop repairs for the East 67th Street Library.
CS
NYPL
Create a new, or
Provide funding for new HVAC systems at the
renovate or upgrade
67th Street Branch Library.
an existing public
library
CS
NYPL
Create a new, or
Fund exterior rehabilitation of windows and
renovate or upgrade
replace where needed at the 96th Street Branch
an existing public
Library.
library
CS
NYPL
Create a new, or
Fund the expansion of the Roosevelt Island
renovate or upgrade
Branch of the NYC Public Library.
an existing public
library
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
5/26
DPR
Other park
Preserve funding for year round workers and
maintenance and
Associate Parks and Recreation Workers
safety requests
(APSWs) at NYC Parks and Recreation.
6/26
DPR
Improve trash
Provide funding for exterminators in all Parks
removal and
within CB8.
cleanliness
9/26
DPR
Other park
Increase funding for additional roving Park
maintenance and
maintenance staff, tree pruners and tree
safety requests
climbers.
19/26
NYPL
Extend library hours
Restore Sunday Service to one library in CB8
or expand and
without cutting weekday hours.
enhance library
programs
24/26
DPR
Enhance park safety
Fund additional PEP officers to enforce parks
through more
rules in all CB8 parks..
security staff (police
or parks
enforcement)
26/26 DPR Plant new street
trees
Install new trees where missing in CD8.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority Agency Request Explanation Location
image
22/26 Other Other expense
budget request
Fund additional DCA inspectors for sidewalk cafes and compliance permits regulation enforcement.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/14
DHS
Other request for
DHS should work closely with HPD to fund much
services for the
needed housing for the most vulnerable of our
homeless
residents. We ask that this request be given the
necessary funding and highest priority in the
Five-Year Plan.
2/14
NYPL
Create a new, or
Provide funding for a ramp or other means of
renovate or upgrade
accessibility at the Yorkville Branch Library.
an existing public
library
3/14
DPR
Other requests for
Provide funding to repair, restore, and design
park, building, or
the entire Esplanade including the piling on the
access
lower level between 60th and 125th Streets,
improvements
and install below ground infrastructure to
expand water access along the entire
Esplanade.
4/14
NYPL
Create a new, or
Providing funding for a new HVAC system at the
renovate or upgrade
Webster and Yorkville Branch Libraries.
an existing public
library
5/14
DOT
Roadway
Provide Funding to NYC DOT for necessary
maintenance (i.e.
materials and personnel to repair potholes and
pothole repair,
repave avenues curb to curb and major
resurfacing, trench
crosstown streets more frequently than every 10
restoration, etc.)
years within CD8.
6/14
DPR
Reconstruct or
Provide funding to redesign and renovate
upgrade a park or
Ruppert as a whole, including the installation of
amenity (i.e.
new irrigation to improve and expand planting
playground, outdoor
areas.
athletic field)
7/14
DPR
Reconstruct or
Provide funding to redesign and renovate John
upgrade a park or
Jay Park as a whole.
amenity (i.e.
playground, outdoor
athletic field)
8/14
DSNY
Provide new or
Fund the NYC Department of Sanitation for the
increase number of
placement of "rat-proof" garbage containers
sanitation trucks
with lids in CD8, preferably solar powered
and other
compactor baskets. We ask the agency work
equipment
closely with neighborhood groups and local BIDs
to find funding for this request.
9/14
DPR
Other street trees
Install tree guards where missing from or when
and forestry
new trees go in and extend the tree pit where
services requests
needed.
10/14
DHS
Upgrade existing
Provide funding for air conditioning in all
facilities for the
homeless shelters.
homeless
11/14
NYPL
Create a new, or
Upgrade electrical system at Webster Branch
renovate or upgrade
Library.
an existing public
library
12/14
DPR
Other requests for
Fund a fully built Park along the East River
East River
park, building, or
between 60th and 63rd Streets on the
Esplanade
access
Esplanade including future phases 2B & 3 of
60th St 63rd
improvements
Andrew Haswell Green Park.
St
13/14
DPR
Other requests for
Fund the return of the Queensboro Oval to the
York Ave 59th
park, building, or
community for year round public use.
St 60th St
access
improvements
14/14
HPD
Other affordable
Provide more affordable housing for all income
housing programs
low and middle income New Yorkers.
requests (capital)
CS
NYPL
Create a new, or
Provide funding for rooftop repairs for the East
renovate or upgrade
67th Street Library.
an existing public
library
CS
NYPL
Create a new, or
Provide funding for new HVAC systems at the
renovate or upgrade
67th Street Branch Library.
an existing public
library
CS
NYPL
Create a new, or
Fund exterior rehabilitation of windows and
renovate or upgrade
replace where needed at the 96th Street Branch
an existing public
Library.
library
CS NYPL Create a new, or renovate or upgrade an existing public library
Fund the expansion of the Roosevelt Island Branch of the NYC Public Library.
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/26
DOE
Other educational
Fund 3-K and Pre-K seats in CB8
programs requests
2/26
DYCD
Provide, expand, or
Fund Out of School Time and DayCare programs
enhance after
for all children who go to school in CB8 or who
school programs for
have parents that work in CB8.
elementary school
students (grades K-
5)
3/26
DYCD
Other youth
Increase funding for youth programs in CB8.
workforce
development
requests
4/26
DOHMH
Other animal and
Increase funding for rodent extermination on
pest control
city streets
requests
5/26
DPR
Other park
Preserve funding for year round workers and
maintenance and
Associate Parks and Recreation Workers
safety requests
(APSWs) at NYC Parks and Recreation.
6/26
DPR
Improve trash
Provide funding for exterminators in all Parks
removal and
within CB8.
cleanliness
7/26
DOT
Provide new traffic
Increase funding for audible accessible crossing
or pedestrian
signals for intersections in CD8
signals
8/26
DFTA
Enhance home care
Increase funding for services to Older Adults
services
including Personal and Home Care,
Transportation Services, Meals-On-Wheels,
Senior Congregate Care Meal Programs and
Case Managers
9/26
DPR
Other park
Increase funding for additional roving Park
maintenance and
maintenance staff, tree pruners and tree
safety requests
climbers.
10/26
DHS
Expand street
Increase funding for Homeless Services
outreach
Outreach personnel, especially during the
overnight hours and provide DHS with updated
information Technology equipment.
11/26
DOHMH
Other programs to address public health issues requests
Increase funding for the Department of Health Enforcement of all food vendor rules and regulations.
12/26
DOT
Other expense
Increase the number of workers to inspect,
traffic
repair, and preserve the DOT's infrastructure --
improvements
both bridges and roads.
requests
13/26
DOB
Address illegal
Hire additional DOB inspectors for compliance
conversions and
and code enforcement, and hire auditors for
uses of buildings
applications
14/26
ACS
Provide, expand, or
Provide additional funding for Children Services,
enhance preventive
especially programs to prevent abuse and
services and
neglect.
community based
alternatives for
youth
15/26
NYPD
Assign additional
Provide funding to increase the current number
traffic enforcement
of Traffic Control agents.
officers
16/26
NYPD
Assign additional
Provide additional funding to expand the Truck
traffic enforcement
Traffic Enforcement Unit.
officers
17/26
DOHMH
Increase health
Provide funding for inspectors and enforcement
inspections, e.g. for
personnel in agencies dealing with restaurants
restaurants
and food trucks.
18/26
DFTA
Enhance programs
Provide funding for Eviction Prevention Services
for elder abuse
for At-Risk Senior Citizens.
victims
19/26
NYPL
Extend library hours
Restore Sunday Service to one library in CB8
or expand and
without cutting weekday hours.
enhance library
programs
20/26
DSNY
Other garbage
Increase recycling program including solid
collection and
waste.
recycling requests
21/26
EDC
Other public housing maintenance, staffing and management requests
Increase funding to ensure all NYCHA community and senior centers remain open. Maintain all current open space.
22/26
Other
Other expense budget request
Fund additional DCA inspectors for sidewalk cafes and compliance permits regulation enforcement.
23/26
EDC
Improve public housing maintenance and cleanliness
Provide more health and building inspectors for NYCHA facilities
24/26
DPR
Enhance park safety through more security staff (police or parks enforcement)
Fund additional PEP officers to enforce parks rules in all CB8 parks..
25/26
DHS, HRA
Provide, expand, or enhance rental assistance programs
Further increase funding for more permanent housing for homeless people.
26/26
DPR
Plant new street trees
Install new trees where missing in CD8.

