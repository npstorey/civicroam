- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 15 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/105Vd0akAI-pnh15N4pkBTlJ9BoYRpQ7X/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/105Vd0akAI-pnh15N4pkBTlJ9BoYRpQ7X/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
15
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 15
image
Address: 2001 Oriental Boulevard, C124 Phone: (718) 332-3008
Email: Bklcb15@verizon.net
Website: www1.nyc.gov/site/brooklyncb15/index.page
Chair: Theresa Scavo District Manager: Laura Singer
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 15 is a vibrant mixed-use community. The District is bordered to the North by the large commercial strip of Kings Highway, to the West by the industrial area of McDonald Avenue, to the South by the beachfront community of Manhattan Beach and to the East by the year round recreational community of Gerritsen Beach, other residential areas include Gravesend, Homecrest, Madison, Midwood and Plumb Beach. It is the policy of Community Board 15 to see to the needs of the local residents it serves and ensure they are given not only a voice, but also receive timely, quality and efficient delivery of city services to the District. Open communication between residents and the Community Board is an essential part of maintaining public safety, development and prosperity for all. According to the Department of City Planning (current), the total land area of Community Board 15 is 4.7 square miles, 53.9% persons per acre. The population statistics supplied by New York City Planning's FactFinder from the American Community Survey conducted from 2013-2017, stated the overall population of Community Board 15 (Brooklyn) is 172,268. Population aged 65+ 18.0%, median age is 40.1, households with children under 18 years old 22.0%, Hispanic Population 10.3%, White 65.5%, Black or African American 3.7% , and Asian 18.2%. The median household income for 2017 is $56,487, and 30% of the population graduate college. The District includes: 68,670 housing units, with 41.5% having 20 or more units, units authorized by new residential building permits 268, units issued new certificates of occupancy 229, homeownership rates are at 46.7%, rental vacancy rate 2.7%, median asking rent $1800, median sales price per unit, (2-4 unit building projected 2018)
is $440,000 and housing choice vouchers 5.7%.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 15
image
The three most pressing issues facing this Community Board are:
Traffic
Traffic: Every single one of our Commercial areas Sheepshead Bay Road - from East 14th Street to Emmons Avenue, Avenue U from Gerritsen Avenue to McDonald Avenue are congested with double parking, truck deliveries and illegal parking. Coney Island Avenue from Avenue P through Guider Avenue, is inundated with double parked cars and people making illegal U-Turns. Most of these Avenues are also major transit hubs causing illegal TLC parking.
We need better Traffic Enforcement, improved policing and DOT input on how to keep the traffic flowing through these congested areas. Because parking is at a premium, the biggest 311 complaints in the district are, blocked driveways with people desperate to park and illegal parking. Response times are high because they are not deemed emergencies, so we need a dedicated unit to focus on these quality of life traffic issues. Lastly, there is an issue throughout the community with people selling multiple cars on our streets taking up valuable parking spaces, in Sheesphead Bay - on Jerome Avenue and Avenue Z and along McDonald Avenue from Avenue V to Avenue X these pop up street car dealers can be found utilizing our much needed parking spaces.
Transit (buses & subways)
Transit: In recent years, our transit system has been failing. The infrastructure isn't being properly maintained and very often our train lines B, Q, F and N have been faltering with electrical problems, derailments and being put out of service for long periods of time. We are in a remote area, the southern most terminus of Brooklyn and our community relies heavily on our mass transportation system to get to and from work. Many of our train lines are elevated and because our community has one of the largest concentration of seniors, most of our stations are not ADA compliant. We need transit to take a look into correcting this by making more stations accessible. In particular, we would like to see the Sheepshead Bay station at Sheepshead Bay Road and East 15th Street equipped with an elevator.
Trash removal & cleanliness
Trash: Our bustling commercial corridors don't have the maintenance or enforcement they require to keep the areas thriving, vital, clean and healthy for our constituents. Sheepshead Bay Road, from East 14th Street to Emmons Avenue, Avenue U from Ocean Avenue to Ocean Parkway, Coney Island Avenue from Avenue Z to Avenue P on any given day will have baskets overflowing from household trash and illegal dumping of construction materials as well as trash strewn along the streets. Our office is inundated with calls on a daily basis complaining how filthy and uninviting these shopping corridors are. We also have a problem with illegal dumping under the underpasses of our elevated B & Q train lines on East 16th Street and F train line on McDonald Avenue, as well as our service road Shore Parkway which runs parallel to the Belt Parkway.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 15
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
We have seen an influx of homeless people throughout our district, they can be found by our elevated train lines the Q and B begging for money. They can be found by the following train stations Sheepshead Bay, Avenue U and Kings Highway. Our underpass at Ocean Avenue and Shore Parkway, our municipal parking lot on East 17th Street and Avenue Z. By our movie theater on Knapp Street. Pan handling along our roadways, like Ocean Parkway between Avenue U and Brighton Beach Avenue. We need more assistance and resources to help provide them affordable housing, access to the necessary medications they need, treatment programs and any other social services we can provide them.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Coney Island Hospital, after Super Storm Sandy, has come back to its previous state. But, funding has been allocated by FEMA to construct a new tower which would be flood resistant. During Hurricane Irene, Coney Island Hospital was evacuated putting many lives in danger. During the height of Sandy, patients were being moved from the flooding main tower to an alternate location. This new tower would make Coney Island Hospital a state of the art health care facility. That is the reason to implement a Level 1 Trauma Center at this time. Valuable time is wasted transporting patients to other trauma centers when we could have one in our community now. Planning this at this time is imperative.
Needs for Older NYs
No comments
Needs for Homeless
New York City is facing a homeless epidemic. With affordable housing becoming more of a rarity in the city many are priced out of their homes. Community Board 15 has seen an influx of homeless in the community and believes there should be more outreach from the Department of Homeless Services, to actively seek to permanently shelter the displaced and bring them the social programs they need, such as drug rehabilitation, mental illness counseling and job skills training with placement. We have a concentration of people under the train station at Sheepshead Bay Road and East 15th Street, Voorhies Avenue and East 16th Street (right next to the Municipal Parking Lot), Ocean Avenue & Shore Parkway underpass, the Municipal Parking lot on East 17th Street and Avenue Z, Kings Highway and Ocean Avenue in the green street parks.
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/28
HHC
Renovate or
Coney Island Hospital located at 2601 Ocean
2601 Ocean
upgrade an existing
Parkway is the closest Hospital to our district, it
Parkway,
health care facility
is near every major road artery in the
Brooklyn,
community, the Belt Parkway and Ocean
New York, NY
Parkway. Severely affected by Super Storm
Sandy, the hospital is currently under
renovations and is in the process of constructing
a new flood-proof tower. With the new tower
underway, Coney Island Hospital should be
given the additional funding it needs to become
a Level 1 Trauma Center, they currently don't
have the equipment needed to designate them
as such. Community Board 15 would like to see
them properly funded to achieve this trauma
care designation.
3/28
HHC
Other health care
Purchase FibroScan System for GI - $198,000.
2601 Ocean
facilities requests
Lenstar Optical System - $35,999.00. Replace
Parkway,
existing 2D mammographic unit with Pristina
Brooklyn,
3D unit - $497,629.00. Stryker Laparoscopic and
New York, NY
Arthoscopic towers and cameras - $199,562.00
Leica Neurology Microscope $172,057.00 Total
Needed $1,103, 247.00
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/34
DHS
Provide rental
Living in New York has become a costly affair.
assistance/vouchers
Rents are rising each year and the cost of living
for permanent
increases exponentially. Salaries don't appear to
housing
keep up with the rent demands. Our seniors and
disabled are on fixed incomes and struggle to
pay rent. We need a way to keep our lower
income residents safely in their homes and off
the streets with some sort of voucher system to
aide them. Hotels and shelters aren't
permanent housing, they often prove to be a
temporary fix and in the long run are not cost
efficient. The existing rental assistance
programs,such as section 8, which need better
policing are over saturated and closed.
16/34 DHS Expand street
outreach
Community Board 15 has seen a major increase of homeless people on our streets, underpasses, parks and train stations. We would like to see more money allocated to do community outreach and get these people the help and services they need and return these public areas back to the community. We have a concentration of people under the train station at Sheepshead Bay Road and East 15th Street, Voorhies Avenue and East 16th Street -(Near the Municipal Parking Lot), Ocean Avenue & Shore Parkway under the overpass of the Belt Parkway and in our green street parks located on Ocean Avenue and Kings Highway.
image
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 15
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
Brooklyn is facing a boom with more development and people moving to the area our schools have not kept up with the demand. Overcrowded classrooms do not provide the best education. We need to look into our local schools to see what schools need to be expanded and how we can best achieve this, so that our classrooms remain manageable and our children get the attention they need and deserve.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Community Board 15 has several schools in our district with an overcrowding problem. Overcrowded classrooms are not beneficial to our children receiving an excellent education. We need to create additional classrooms or develop new schools to provide our students with the best education available, so they will one day have the tools to competently compete in tomorrow's job markets. PS 254, PS 153 and PS 206 are prime examples of schools over capacity.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
13/28
SCA
Renovate exterior
The school's playground floods following every
1925 Stuart
building component
rain event. Heavy rains cause mini-lakes,
Street,
attracting mosquitoes during the warmer
Brooklyn,
months and ice hazards during the winter. We
New York, NY
would appreciate funding for remediation to
return the playground safely to the community's
children, who use it.
CS
SCA
Provide a new or
Brooklyn has grown in population at an
2200
expand an existing
alarming rate and our school systems have not
Gravesend
elementary school
caught up with the demands. We have several
Neck Road,
schools in the district that are overcrowded and
Brooklyn,
resources are stretched to the seams. We need
New York, NY
to take a good hard look at these schools and
seek solutions to either expand classrooms
when possible or create a new school to
accommodate these very real and growing
needs. Our children are our future and they
deserve the best education possible and
overcrowded classrooms can not provide that.
PS 254, PS 153 and PS 206 are prime examples
of schools at capacity.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
13/34
DYCD
Provide, expand, or
After school programs provide a safe, social and
1970
enhance after
educational experience for our children giving
Homecrest
school programs for
them the ability to learn and grow into
Avenue
elementary school
successful adults.
students (grades K-
5)
14/34
DYCD
Provide, expand, or
After school programs provide a safe, social and
1401
enhance after
educational experience for our children giving
Emmons
school programs for
them the ability to learn and grow into
Avenue
middle school
successful adults.
students (grades 6-
8)
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 15
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
Increase in Row Tow Capabilities by adding automobile lifts at existing facility to handle more vehicles.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
With the District being almost 5 square miles in size there is an immediate need for additional Police Officers to adequately patrol the District. The 61st Precinct is under staffed and at times many of our Officers are reassigned to work the beach patrol, at the 60th Precinct, or larger events throughout the City. Community Board 15 has received numerous complaints from residents on how low-priority crimes, such as car break-ins or traffic accidents are taking hours for a police response. Along with low priority crimes our community is plagued with blocked driveways, from people losing patience to looking for a legal parking spot, choosing to park in a way that prohibits a homeowner from accessing their driveway. We have cars that don't move for alternate side and cars that are either abandoned or being sold on our streets taking up valuable parking real estate. Row tow capabilities are limited in that they have no real place to store the vehicles outside of one tow pound cross town in north brooklyn and the time it takes to tow across town limits how many cars they can capture in a day. Either fines need to be increased each time a person's vehicle is caught disobeying the law or a new facility be created in southern Brooklyn to house violators or expand the capacity of the exisiting north facility with car lifts.
Needs for Emergency Services
All Firehouses in the District are aging and in need of electrical upgrades. These firehouses should also be outfitted with emergency back-up generators in the event of a power outage. .
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
4/28
NYPD
Add NYPD parking
Currently Brooklyn has only one police tow
facilities
pound in Northern Brooklyn and it's almost at
full capacity. Southern Brooklyn needs a tow
pound to expedite the row-tow needs of our
communities. The current pound being so far
away allows for limited ability to remove
illegally parked or abandoned cars in any given
day from southern Brooklyn because of long
travel times. This is a growing problem in our
community. Additional automobile lifts at the
existing facility would increase capacity until a
new pound can be located and created.
5/28
FDNY
Rehabilitate or
We are requesting any additional funding
2600-2698
renovate existing
necessary in the rebuilding of a EMS station in
East 6th
fire houses or EMS
our neighboring area by Coney Island Hospital.
Street
stations
9/28
NYPD
Other NYPD
Currently, Brooklyn does not have the capability
facilities and
to tow a heavy vehicle such as a semi-truck. We
equipment requests
have to wait and rely on a tow truck being sent
(Capital)
from Manhattan. We would like Brooklyn to
have its own designated heavy load tow truck.
CS
FDNY
Rehabilitate or
Engine 276/Ladder 156/Battalion 33 : 1635 East
renovate existing
14th Street New Commercial Dishwasher, a
fire houses or EMS
Washing Machine and a Clothes Dryer (Gas)
stations
Engine 254/Ladder 153 901 Avenue U New
Intercom system in firehouse Back-up Generator
1 inch yellow forestry hose to help at brush fire
operations Forcible entry training door Low
profile floor jack Metal studs and plywood to
build a search training course in the basement.
Engine 321: 2165 Gerritsen Avenue New
Apparatus (Truck Room) Floor Dishwasher
Engine 246/Ladder 169 2731 East 11th Street
Electrical Upgrades to Firehouse including Back-
up Generator New Refrigerator Commercial
range hood for outdoor grill
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
1/34
NYPD
Assign additional
Community Board 15 is in need of additional
2575 Coney
uniformed officers
police officers at our 61st Precinct, located at
Island Avenue
2575 Coney Island Avenue. Although our crime
rates are low, issues such as minor traffic
accidents, car break- ins and mischief in our
school yards and parks can go hours before an
officer is able to respond because the
department is currently spread too thin
handling more urgent calls.
2/34
NYPD
Provide additional
We would like to see additional cars purchased
2575 Coney
patrol cars and
for our precinct. Often cars are in the shop. We
Island
other vehicles
would also like funds to be allocated for repairs
Avenue,
of these vehicles.
Brooklyn,
New York, NY
9/34
NYPD
Assign additional
All the schools in the District are in need of
crossing guards
additional crossing guards. With the severe
traffic around schools at dismissal, crossing
guards are imperative. Currently when a
crossing guard is out sick, a uniformed officer is
pulled away to take their place, taking an officer
away from other critical policing work.
10/34
FDNY
Provide more
Currently Kingsborough Community College at
2001 Oriental
firefighters or EMS
2001 Oriental Blvd, during the Summer Months
Blvd
workers
from May through October houses an FDNY
fireboat. This fireboat is currently not manned
24/7 and we believe it would be in the best
interest of the community if it could be. With a
dry season, brush fires seem to have been more
prevalent this year. Being a beach and boating
community, rescues on the water are another
challenge that a 24/7 fireboat would be well
equipped to assist in. Pulling a boat from further
away can be critical when time is of the essence.
Being that this is a strategic location, we feel
keeping it staffed and accessible 24/7 during the
summer months would be a true asset to saving
our residents and visitors lives.
11/34
NYPD
Assign additional
All of our commercial corridors are backed up
traffic enforcement
with traffic due to illegal double parking.
officers
Additional traffic enforcement is needed along
Coney Island Avenue from Avenue P to Avenue
Z, on Avenue U from McDonald Avenue to
Nostrand Avenue, on Sheepshead Bay Road
from East 14th Street to Emmons Avenue and
on Kings Highway from McDonald Avenue to
Ocean Avenue.
12/34
FDNY
Provide more firefighters or EMS workers
Brush Fire Unit 6 in Gerritsen Beach, Brooklyn, NY needs additional manpower during brush fire season.
52 Seba Ave
26/34
NYPD
Other NYPD
There is a fee of $24.00 a year an Explorer
programs requests
wanting to participate in the police program
must come up with to be a part of this
worthwhile group. We would like to see that fee
paid for or waived by the city of New York.
28/34
NYPD
Other NYPD
The stations along the B and Q train lines are
programs requests
inundated with illegal merchants outside the
train stations. Whether Sheepshead Bay Road,
Avenue U or Kings Highway, illegal vendors
block the station entrances causing safety issues
as well as sanitation problems.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 15
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water pollution control
Community Board 15's District as a Waterfront Community has two major waterways that have been severally impacted by run-off from the Coney Island Treatment Plant located at 3002 Knapp Street, Brooklyn, NY 11235. The system has had some major breakdowns this year, releasing a horrible stench into the air which lingered for weeks. Our main concern is how the runoff from this plant is negatively impacting on our waters in both Gerritsen Beach and Sheepshead Bay. After Superstorm Sandy when the electricity was cut off stopping any safeguards that were in place, the amount of toxins released from our overflowing sewage system has never been fully addressed. We are still feeling its affects. The stench of both Gerritsen Creek (located on Knapp Street across from the plant) and Sheepshead Bay Outfall on Ocean Avenue and Emmons Avenue, during high tides is unbearable. An environmental impact study should be conducted on these bodies of water and work should be done to restore these once thriving waterways back to the people of the community to safely enjoy for recreation. Many of our storm drains are heavily impacted with sludge or are backed up with debris having never been properly cleaned and don't flow the way they should causing major flooding on our roadways. These aging storm sewers do not seem capable of handling the impact of heavy rain storms and often back up causing flooding on our streets. This is most evident along our low- lying areas Shore Boulevard in Manhattan Beach between Ocean Avenue and Irwin Street and all along Gerristen Avenue in Gerritsen Beach and along many of the streets in the old section of Gerritsen Beach.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Community Board 15 is advocating for additional funding required to create an entirely new sewer system in low- lying Gerritsen Beach which was severely compromised by Super Storm Sandy back in 2012. The Coney Island Water Treatment Plant located at 3002 Knapp Street is in need of a 15% increase in overall plant budget for on-going maintenance of the water treatment plant. We need funding for force main repair and additional funding for odor control equipment for repairs and improvements. We would also like a dedicated skimmer vessel for Sheepshead Bay due to the CSO containment site.
Needs for Sanitation Services
Our main concern is that our Brooklyn 15 Sanitation garage has been operating out of a temporary location on Knapp Street in trailers for over a decade. Recently, we have learned due to an emergency the secondary lot used by Sanitation for equipment has been taken back by DEP, who owns the land for their equipment. We would like to see them permanently housed in the district or a proposed joint Sanitation garage for Community Board 13 and 15 expeditiously come together.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
12/28
DSNY
Provide new or
Sanitation 15 is currently in temporary housing
2501 Knapp
upgrade existing
on Knapp Street in trailers. They require
Street
sanitation garages
additional trailers to better serve the staff they
or other sanitation
currently have.
infrastructure
20/28
DEP
Investigate odor
The Coney Island Water Treatment Plant located
3002 Knapp
complaints about a
at 3002 Knapp Street is in need of a 15%
Street
wastewater facility
increase in overall plant budget for on-going
and address/repair
maintenance of the water treatment plant. We
or make equipment
need funding for force main repair and
improvements as
additional funding for odor control equipment
needed (Capital)
for repairs and improvements.
25/28
DSNY
Provide new or
Sanitation 15 requires a 4 X 4 truck to get its
2501 Knapp
increase number of
personnel out and about to assess snow
Street
sanitation trucks
conditions.
and other
equipment
CS
DSNY
Provide new or
Community Board 15's Sanitation garage is a
upgrade existing
temporary structure of trailers located on Knapp
sanitation garages
Street. We are requesting a permanent location
or other sanitation
to house Sanitation 15, Brooklyn.
infrastructure
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
5/34
DEP
Inspect sanitary
Community Board 15 is requesting the
sewer on specific
installation of back-flow preventors throughout
street segment and
the district. This community experienced many
repair or replace as
sewer back up issues after Sandy and these
needed (Expense)
preventors would help with the back-ups. The
neighborhoods of Manhattan Beach,
Sheepshead Bay and Gerritsen Beach are the
areas most affected. On Avenue Y from
Mcdonald Avenue to Ocean Avenue going south
the area was inundated with sewer back-ups
and back-flow preventers would prevent that
from happening again.
6/34
DEP
Clean catch basins
Community Board 15 is prone to flooding during
rain events. Periodical cleaning of our storm
sewers is desperately needed. Specifically Shore
Blvd., between Pembroke and West End Avenue.
Oriental Avenue between Oxford and West End
Avenue. On Gerritsen Avenue from Channel
Avenue to Seba Avenue.
7/34
DEP
Investigate and
In both Sheepshead Bay and Gerritsen Creek we
address water
are asking for periodic maintenance to remove
quality complaints
all floatables in the Bay and in the Creek. This
at an address or on
pollution is a severe health hazard, as well as
specific street
making these heavily visited locations
segments
undesirable and unsightly for the community to
fully enjoy.
18/34
DSNY
Increase
Our community is inundated with illegal
enforcement of
advertising on every upright structure. Signs for
illegal posting laws
moving men and lately "Cash for Cars" signs
have appeared everywhere. There must be
severe penalties for such acts. These illegal
postings are defacing our entire community.
23/34
DSNY
Increase
Our underpasses which are dimly lit attract
East 16th
enforcement of
chronic illegal dumpers. If cameras could be
Street Avenue
illegal dumping laws
placed at these locations to catch them in the
U Avenue Z
act, we would deter this illegal activity from
occurring. East 16th Street from Avenues U thru
Z, contain, tires, furniture, e-waste, construction
materials and household trash strewn about
each week by illegal dumpers. We need to stop
this.
25/34
DSNY
Other cleaning
To keep up with the demands of our district, like
Emmons
requests
many we need more manpower. The Malls
Avenue
along Emmons Avenue are constantly collecting
Ocean
debris.
Avenue
Knapp Street
29/34
DSNY
Other garbage
Sanitation 15 requires additional manpower for
2501 Knapp
collection and
their derelict vehicle unit. Our area in inundated
Street
recycling
with calls about abandoned cars and having the
infrastructure
additional manpower would decrease response
requests (Expense)
times in removing these vehicles.
30/34
DSNY
Increase
We need more officers along Avenue U to
Avenue U
enforcement of
enforce these commercial businesses to keep
Coney Island
dirty sidewalk/dirty
the areas in front of their businesses clean. Over
Avenue
area/failure to clean
grown tree pits, illegal dumping and filthy
Ocean
area laws
sidewalks exist all along this corridor.
Avenue
32/34
DSNY
Increase vacant lot cleaning
The sidewalk and property abutting the B & Q train line by Homecrest Avenue, between Shore Parkway and Neptune Avenue has become overgrown and utilized as an illegal dumping ground.
Homecrest Avenue Shore Parkway Neptune Avenue
33/34
DSNY
Increase enforcement of dirty sidewalk/dirty area/failure to clean area laws
Sheepshead Bay Road a once thriving retail corridor has become a neighborhood eyesore. Very few merchants maintain in front of their stores. We receive numerous complaints from residents who walk along that road.
Sheepshead Bay Road East 14th Street Emmons Avenue
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 15
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
With a growing aging population our seniors can not afford to maintain or stay in their homes and rentals are just not affordable on their fixed incomes.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Throughout Community Board 15 there are many stop work orders that are being violated. Many homes are being converted illegally from 1-2 family dwellings to multi-family dwellings without the proper permits. It is our hope that with additional inspectors, inspections can be done in a more timely fashion. Many of the violations we have reported have been backlogged for months helping illegal construction to be completed.
Needs for Housing
We have been receiving an influx of calls emanating from The Sheepshead / Nostrand Houses located in our district because of long waits for repairs, from broken front doors, broken ovens, other broken appliances, plumbing issues and unsanitary living conditions. One particular resident from 3004 Avenue V has been waiting over a month to be able to use her refrigerator. The maintenance system in public housing is broken, the prolonged waits are unacceptable and perhaps additional maintenance crews are need to expedite the warrant of habitability.
Needs for Economic Development
We have a large number of small commercial areas in our district, Avenue U, Sheepshead Bay Road, Avenue P, Gravesend Neck Road and Avenue X with rents escalating to ludicrous heights, these storefronts either turn over rapidly, or sit vacant not enticing or attracting anyone to invest in opening a new business. Empty store fronts don't entice consumers. The City needs to offer Small Business owners more incentives and assistance in creating businesses, or offer store owners some incentives to attract and retain businesses. Outrageous rents are keeping many of our small commercial areas bleak and depressed.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
8/28 HPD Provide more
housing for medium income households
Our seniors can no longer afford to maintain their properties and stay in their homes and rentals are too expensive on fixed incomes. With a growing aging population we need to create affordable senior communities. New York City is way behind in that area. Our middle class has extremely diminished. Real Estate prices have sky-rocketed in our community and it's becoming impossible for people who grew up here or raised a family here to remain in our community. Home ownership is now a pipe dream, only affordable for the very wealthy.
Rents are becoming so high, that families are
taken up residence in illegally created apartments.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
4/34
DOB
Assign additional
Response times have improved but complaints
building inspectors
deemed, non hazardous and rated a C still take
(including
months to evaluate. We would like to see all
expanding training
complaints across the board be investigated in a
programs)
timely manner.
20/34
EDC
Expand access to
We have commercial areas, such as Sheepshead
low cost financing to
Bay, Avenue X, Avenue U with empty storefronts
help neighborhood
causing a blight on the community. Barren
businesses construct
storefronts don't entice consumers. Our
or improve space
commercial districts are deteriorating. Rents are
high and mom and pop shops can't compete
with large online retailers. We need incentives
to encourage and assist would be shop keepers
to invest in our neighborhoods.
21/34 EDC Improve public
housing maintenance and cleanliness
We have been receiving an influx of calls emanating from The Sheepshead / Nostrand Houses located in our district because of long waits for repairs, from broken front doors, broken appliances, plumbing issues and unsanitary living conditions. One particular resident from 3004 Avenue V has been waiting over a month to be able to use her refrigerator. The maintenance system in public housing is broken, the prolonged waits are unacceptable and perhaps additional maintenance crews are need to be added to expedite the warrant of habitability.
3004 Avenue V
image
TRANSPORTATION
Brooklyn Community Board 15
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
Our community is growing in leaps and bounds and with the amount of new construction, the parking has not kept up with the development or demand. Where one house stood, now several apartments stand with families owning several cars. Because of the lack of parking, people park illegally, they double park and cause congestion throughout the community especially near our commercials districts, such as Sheepshead Bay Road, Avenue U, Kings Highway and Coney Island Avenue. Every school is inundated with parents waiting to pick up their children causing gridlock throughout the community. We need to develop traffic plans to alleviate the congestion or mandate more parking be provided when new construction plans are being developed in the community.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The old section of Gerritsen Beach is plagued with flooding after a minor rain event. The streets must be repaved with the proper drainage. The DOT must assign an additional speed hump installation crew to expedite installation of speed humps, two years is too long to wait for the installations.
Needs for Transit Services
Due to Community Board 15's large senior population we would like to see an elevator constructed at the Sheepshead Bay Station. Sheepshead Bay station is a large transit hub and seniors find navigating the large amount of steps to reach the elevated train line very difficult. Also, our stations are filthy!! They smell like urinals, the staircases are lined with debris and graffiti is everywhere both inside and outside the stations.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
10/28
DOT
Repair or build new
The Bulkheads along Manhattan Beach from
Oriental Blvd
seawalls or
Corbin Place to Ocean Avenue have been
and Ocean
bulkheads
compromised due to years of erosion. In case of
Avenue
another major storm, such as a Sandy, there are
no resiliency measures in place to protect the
community.
19/28
DOT
Other
The waiting list to put in a requested and
transportation
approved speed hump is very excessive. With
infrastructure
the hiring of additional crews to perform this
requests
necessary task we can expedite the time of
installation and save lives.
26/28
DOT
Repair or provide
Throughout Community Board 15, we would like
new street lights
to see the addition of solar lighting on street
lights and traffic signals in case of storm related
outages.
CS
DOT
Reconstruct streets
Gerritsen Beach was a heavily damaged area
Gerritsen
during Super Storm Sandy. Flooding and
Avenue
Ponding have been an issue in the old section of
Bartlett
Gerristen, (South of Bartlett Avenue), for many
Avenue
years, during the aftermath of Sandy it is critical
Plumb Beach
these upgrades be made. We are requesting a
Avenue
new sewer system to be installed and in doing
so it is imperative that DOT works hand in hand
with DEP to reconstruct the streets of this
community with each installation of a new
sewer system.
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
15/34 DOT Address traffic
congestion
We need to take another look at Sheepshead Bay Road and develop a plan that will alleviate the heavy flow of traffic on Emmons Avenue from Ocean Avenue to Shore Boulevard (west bound) and along Sheepshead Bay Road from Emmons Avenue to Voorhies Avenue (both north and south bound). The area is too congested and the city buses can barely get through. Our commercial area doesn't flow correctly. We also find Bay Academy JHS on Emmons Avenue and East 14th Street causes snarls at drop-off and dismissal times with parents adding to the congestion.So a study should be conducted when school is in session.
image
19/34 NYCTA Improve bus
cleanliness, safety or maintenance
Transit should have a designated maintenance crew responsible for cleaning the exterior entrances of all transit stations. Our underpass at Sheepshead Bay is a chronic mess, as is Avenue U and Kings Highway. Avenue X and McDonald Avenue is extremely filthy.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 15
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Forestry services, including street tree maintenance
The biggest complaints we receive are from residents complaining about city trees. We need funding for additional staff in the forestry division to improve pruning, replanting and removal of stumps. Waiting times have tremendously increased in tree maintenance throughout the district.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
The Parks in Community Board 15 are in desperate need of maintenance and upgrades. Parks needs to hire additional staff to meet the maintenance needs these parks require on a daily basis. Whether, its trimming the weeds, trimming the trees, collecting garbage or making sure play equipment is safe and functioning. In addition, when planning a park or making upgrades to an existing park, comfort stations need to be made a priority, not an after thought. Homecrest Park located at Williams Court bet. E. 12 St. and Homecrest Avenue desperately needs a comfort station. It's a well utilized park for both the very young and old and bathroom facilities need to be addressed. In the planning of Brigham Park, located on Emmons Avenue by Brigham Street and Knapp Street, a rather remote area, a comfort station should be included. Bill Brown Park on Bedford Avenue by Avenue X to Avenue Y has its park building upgrade in limbo for several years, due to the contractor defaulting. However, its the residents who suffer and calls to our office to complain they need the comfort station replaced and as soon as possible. McDonald Park located at McDonald Avenue and Avenue S is in need of having it's main ball field repaved.
Needs for Cultural Services
Our community is vibrant and alive yet we are lacking in the arts. Our children need to travel to other communities to enjoy the fine arts. We need traveling art shows to enhance the waterfront of Emmons Avenue. We need our area parks to host science fairs and allow our young to experience hands on projects.
Needs for Library Services
Our community (BPL) has seen an increase in library use whether for reading or for the many programs these libraries offer. Many children attend the after school programs offered and seniors avail themselves to the many senior programs available. In recent times library access has become more important than ever before.
Needs for Community Boards
Community Board 15 is in need of an upgraded internet service. We are still working with a antiquated DSL line, which we are told will no longer be supported and the service will cease to exist by the end of the year.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/28
DPR
Provide a new, or
Brigham Park, a new park being constructed in
Emmons
new expansion to, a
the next year, located on Emmons Avenue and
Avenue
building in a park
Brigham Street does not have adequate funding
Brigham
to provide a comfort station. Given it's remote
Street
location, for seniors and children in our
community a comfort station would be a
necessity.
6/28
DPR
Other park facilities
Mellet Park is in need of an overall drainage
Avenue V,
and access requests
repair. Ponding is major problem in this park,
Brooklyn,
leaving murky water dangerously lingering
New York, NY
around the area where children play.
7/28
DPR
Reconstruct or
Homecrest Park is in need of a comfort station,
Williams
upgrade a park or
it serves a large community of both children and
Court
amenity (i.e.
seniors, and public urination at that park has
playground, outdoor
become a health hazard.
athletic field)
11/28
DPR
Reconstruct or
Pat Parlato playground is in poor condition and
Falmouth St
upgrade a park or
in need of a total upgrade in recreational
and Oriental
amenity (i.e.
equipment.
Blvd
playground, outdoor
athletic field)
14/28
DPR
Enhance park safety
Many of our Parks are dimly lit and require
Belt Pkwy.,
through design
additional lighting. Perhaps solar lighting is
Williams
interventions, e.g.
something that can be funded to efficiently and
Court bet. E.
better lighting
inexpensively light our parks.
12 St. and
(Capital)
Homecrest
Ave Brooklyn
15/28
DPR
Reconstruct or
Kelly Park and Kelly Playground are poorly laid
Avenue S and
upgrade a park or
out and in bad condition. It is need of total
East 17th
amenity (i.e.
reconstruction and updates in its equipment.
Street
playground, outdoor
The basketball courts, paddleball courts and
athletic field)
tennis courts are in desperate need of
refurbishing.
16/28
DPR
Reconstruct or
McDonald Park is in need of Astro Turf in the
McDonald
upgrade a park or
main ball field with running and walking paths.
Avenue and
amenity (i.e.
Basketball courts, handball and tennis courts all
Avenue S
playground, outdoor
need resurfacing.
athletic field)
17/28
DPR
Enhance park safety
Many of our Parks are dimly lit and require
Avenue V,
through design
additional lighting. Perhaps solar lighting is
Brooklyn,
interventions, e.g.
something that can be funded to efficiently and
New York, NY
better lighting
inexpensively light our parks.
(Capital)
18/28
DPR
Reconstruct or
Manhattan Beach Park need its' baseball field
Falmouth
upgrade a park or
and tennis ball courts upgraded.
Street and
amenity (i.e.
Oriental
playground, outdoor
athletic field)
21/28
BPL
Create a new, or
Kings Bay Library - Safety & Security
3650
renovate or upgrade
Enhancements $250,000, Exterior & Windows
Nostrand
an existing public
$1,800,000., and Heating & Cooling $3,000,00.
Avenue,
library
Brooklyn,
New York, NY
22/28
BPL
Create a new, or
Gravesend Library needs: Safety and Security
303 Avenue X
renovate or upgrade
Enhancements $200,000, interior renovation
an existing public
$2,000, 000, initial outfitting / FF &E 500,000,
library
Heating and Cooling 2,000,000.
23/28
BPL
Create a new, or
Homecrest Library needs are as follows, Leased
2525 Coney
renovate or upgrade
Branch, $3,000,000.00, Safety & Security
Island Avenue
an existing public
Enhancements 200,000, Heating and Cooling,
library
$2,000,000. and a roof $850,000.
24/28
BPL
Create a new, or
Sheepshead Bay Leased Branch, $2,000,000,
2636 East
renovate or upgrade
ADA Compliance - entire branch $1,000,000,
14th Street
an existing public
Safety & Security Enhancements 200,000,
library
Exterior work $750,000, Site Drainage
$400,000, Interior Renovation, $3,000,000.,
Initial Outfitting FF/& E $600,000., Heating and
Cooling $2,000,000 and a Roof $850,000.
27/28
DPR
Other requests for
Pritchard Mall Green Space located on Corbin
Corbin Place
park, building, or
Place between Brighton Beach Avenue and
btw BBA &
access
Oriental Boulevard, has become a broken up,
Ortl Blvd
improvements
hazardous looking eye sore. Crumbling cement
surrounds the entire area and needs to be
restored.
28/28
DPR
Reconstruct or
The Manhattan Beach Bath House harks back to
Oriental Blvd
upgrade a building
the days of yesteryear. Yet is sits there a shell of
and Falmouth
in a park
itself, an empty relic of a time gone by. The
Stree
community would love to see it restored, and
once again, providing changing facilities,
showers and lockers for the beach going
community.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
8/34
DPR
Forestry services,
Community Board 15 receives numerous
including street tree
complaints about trees not being pruned,
maintenance
maintained or planted in a timely fashion. More
money needs to be allocated to provide better
forestry services to our community, waiting 4 or
5 years is a ridiculously long time to have a tree
planted and tree pruning can take 7 - 10 years,
allowing it to become a hazard. We need to
expedite this procedure, so adequately funding
this division with additional trained staff and
equipment would help to streamline this too
long a process.
17/34
DPR
Enhance park safety
Manhattan Beach Park is a remote location in a
Oriental Blvd
through more
quiet residential area often trespassed upon
and Ocean
security staff (police
after hours by young people who can be
Avenue
or parks
mischievous. We have had fires, loud music and
enforcement)
noise complaints emulating from the park late
at night and would like to see more regular
patrols of this area to discourage this behavior.
22/34
DPR
Provide better park
Our parks need more personnel to maintain
maintenance
them on a daily basis.
24/34
DPR
Other street trees
We have many sidewalk flags in our community
and forestry
in need of major repairs due to city trees
services requests
uprooting them. The current funding is not
adequate enough to get to all the sidewalks in
need of repair, we are requesting additional
funding to combat this growing sidewalk
hazard.
27/34
BPL
Extend library hours
The library offers programs for both young and
Coney Island
or expand and
old but, the hours of operation must support the
Avenue
enhance library
community. The branches must be open when it
programs
is convenient to the community. The Homecrest
branch needs to service a religious community
that needs Sunday hours while the Gravesend
branch needs later hours for all the working
families in the area.
31/34
DPR
New equipment for
We are requesting additional front end loaders
maintenance
to assist in cleaning.
(Expense)
34/34 DPR New equipment for
maintenance (Expense)
We are requesting funding for packers for garbage removal.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/28
HHC
Renovate or
Coney Island Hospital located at 2601 Ocean
2601 Ocean
upgrade an existing
Parkway is the closest Hospital to our district, it
Parkway,
health care facility
is near every major road artery in the
Brooklyn,
community, the Belt Parkway and Ocean
New York, NY
Parkway. Severely affected by Super Storm
Sandy, the hospital is currently under
renovations and is in the process of constructing
a new flood-proof tower. With the new tower
underway, Coney Island Hospital should be
given the additional funding it needs to become
a Level 1 Trauma Center, they currently don't
have the equipment needed to designate them
as such. Community Board 15 would like to see
them properly funded to achieve this trauma
care designation.
2/28
DPR
Provide a new, or
Brigham Park, a new park being constructed in
Emmons
new expansion to, a
the next year, located on Emmons Avenue and
Avenue
building in a park
Brigham Street does not have adequate funding
Brigham
to provide a comfort station. Given it's remote
Street
location, for seniors and children in our
community a comfort station would be a
necessity.
3/28
HHC
Other health care
Purchase FibroScan System for GI - $198,000.
2601 Ocean
facilities requests
Lenstar Optical System - $35,999.00. Replace
Parkway,
existing 2D mammographic unit with Pristina
Brooklyn,
3D unit - $497,629.00. Stryker Laparoscopic and
New York, NY
Arthoscopic towers and cameras - $199,562.00
Leica Neurology Microscope $172,057.00 Total
Needed $1,103, 247.00
4/28
NYPD
Add NYPD parking
Currently Brooklyn has only one police tow
facilities
pound in Northern Brooklyn and it's almost at
full capacity. Southern Brooklyn needs a tow
pound to expedite the row-tow needs of our
communities. The current pound being so far
away allows for limited ability to remove
illegally parked or abandoned cars in any given
day from southern Brooklyn because of long
travel times. This is a growing problem in our
community. Additional automobile lifts at the
existing facility would increase capacity until a
new pound can be located and created.
5/28
FDNY
Rehabilitate or renovate existing fire houses or EMS stations
We are requesting any additional funding necessary in the rebuilding of a EMS station in our neighboring area by Coney Island Hospital.
2600-2698
East 6th Street
6/28
DPR
Other park facilities
Mellet Park is in need of an overall drainage
Avenue V,
and access requests
repair. Ponding is major problem in this park,
Brooklyn,
leaving murky water dangerously lingering
New York, NY
around the area where children play.
7/28
DPR
Reconstruct or
Homecrest Park is in need of a comfort station,
Williams
upgrade a park or
it serves a large community of both children and
Court
amenity (i.e.
seniors, and public urination at that park has
playground, outdoor
become a health hazard.
athletic field)
8/28
HPD
Provide more
Our seniors can no longer afford to maintain
housing for medium
their properties and stay in their homes and
income households
rentals are too expensive on fixed incomes. With
a growing aging population we need to create
affordable senior communities. New York City is
way behind in that area. Our middle class has
extremely diminished. Real Estate prices have
sky-rocketed in our community and it's
becoming impossible for people who grew up
here or raised a family here to remain in our
community. Home ownership is now a pipe
dream, only affordable for the very wealthy.
Rents are becoming so high, that families are
taken up residence in illegally created
apartments.
9/28
NYPD
Other NYPD
Currently, Brooklyn does not have the capability
facilities and
to tow a heavy vehicle such as a semi-truck. We
equipment requests
have to wait and rely on a tow truck being sent
(Capital)
from Manhattan. We would like Brooklyn to
have its own designated heavy load tow truck.
10/28
DOT
Repair or build new
The Bulkheads along Manhattan Beach from
Oriental Blvd
seawalls or
Corbin Place to Ocean Avenue have been
and Ocean
bulkheads
compromised due to years of erosion. In case of
Avenue
another major storm, such as a Sandy, there are
no resiliency measures in place to protect the
community.
11/28
DPR
Reconstruct or
Pat Parlato playground is in poor condition and
Falmouth St
upgrade a park or
in need of a total upgrade in recreational
and Oriental
amenity (i.e.
equipment.
Blvd
playground, outdoor
athletic field)
12/28
DSNY
Provide new or
Sanitation 15 is currently in temporary housing
2501 Knapp
upgrade existing
on Knapp Street in trailers. They require
Street
sanitation garages
additional trailers to better serve the staff they
or other sanitation
currently have.
infrastructure
13/28
SCA
Renovate exterior
The school's playground floods following every
1925 Stuart
building component
rain event. Heavy rains cause mini-lakes,
Street,
attracting mosquitoes during the warmer
Brooklyn,
months and ice hazards during the winter. We
New York, NY
would appreciate funding for remediation to
return the playground safely to the community's
children, who use it.
14/28
DPR
Enhance park safety
Many of our Parks are dimly lit and require
Belt Pkwy.,
through design
additional lighting. Perhaps solar lighting is
Williams
interventions, e.g.
something that can be funded to efficiently and
Court bet. E.
better lighting
inexpensively light our parks.
12 St. and
(Capital)
Homecrest
Ave Brooklyn
15/28
DPR
Reconstruct or
Kelly Park and Kelly Playground are poorly laid
Avenue S and
upgrade a park or
out and in bad condition. It is need of total
East 17th
amenity (i.e.
reconstruction and updates in its equipment.
Street
playground, outdoor
The basketball courts, paddleball courts and
athletic field)
tennis courts are in desperate need of
refurbishing.
16/28
DPR
Reconstruct or
McDonald Park is in need of Astro Turf in the
McDonald
upgrade a park or
main ball field with running and walking paths.
Avenue and
amenity (i.e.
Basketball courts, handball and tennis courts all
Avenue S
playground, outdoor
need resurfacing.
athletic field)
17/28
DPR
Enhance park safety
Many of our Parks are dimly lit and require
Avenue V,
through design
additional lighting. Perhaps solar lighting is
Brooklyn,
interventions, e.g.
something that can be funded to efficiently and
New York, NY
better lighting
inexpensively light our parks.
(Capital)
18/28
DPR
Reconstruct or
Manhattan Beach Park need its' baseball field
Falmouth
upgrade a park or
and tennis ball courts upgraded.
Street and
amenity (i.e.
Oriental
playground, outdoor
athletic field)
19/28
DOT
Other
The waiting list to put in a requested and
transportation
approved speed hump is very excessive. With
infrastructure
the hiring of additional crews to perform this
requests
necessary task we can expedite the time of
installation and save lives.
20/28
DEP
Investigate odor
The Coney Island Water Treatment Plant located
3002 Knapp
complaints about a
at 3002 Knapp Street is in need of a 15%
Street
wastewater facility
increase in overall plant budget for on-going
and address/repair
maintenance of the water treatment plant. We
or make equipment
need funding for force main repair and
improvements as
additional funding for odor control equipment
needed (Capital)
for repairs and improvements.
21/28
BPL
Create a new, or
Kings Bay Library - Safety & Security
3650
renovate or upgrade
Enhancements $250,000, Exterior & Windows
Nostrand
an existing public
$1,800,000., and Heating & Cooling $3,000,00.
Avenue,
library
Brooklyn,
New York, NY
22/28
BPL
Create a new, or
Gravesend Library needs: Safety and Security
303 Avenue X
renovate or upgrade
Enhancements $200,000, interior renovation
an existing public
$2,000, 000, initial outfitting / FF &E 500,000,
library
Heating and Cooling 2,000,000.
23/28
BPL
Create a new, or
Homecrest Library needs are as follows, Leased
2525 Coney
renovate or upgrade
Branch, $3,000,000.00, Safety & Security
Island Avenue
an existing public
Enhancements 200,000, Heating and Cooling,
library
$2,000,000. and a roof $850,000.
24/28
BPL
Create a new, or
Sheepshead Bay Leased Branch, $2,000,000,
2636 East
renovate or upgrade
ADA Compliance - entire branch $1,000,000,
14th Street
an existing public
Safety & Security Enhancements 200,000,
library
Exterior work $750,000, Site Drainage
$400,000, Interior Renovation, $3,000,000.,
Initial Outfitting FF/& E $600,000., Heating and
Cooling $2,000,000 and a Roof $850,000.
25/28
DSNY
Provide new or
Sanitation 15 requires a 4 X 4 truck to get its
2501 Knapp
increase number of
personnel out and about to assess snow
Street
sanitation trucks
conditions.
and other
equipment
26/28
DOT
Repair or provide
Throughout Community Board 15, we would like
new street lights
to see the addition of solar lighting on street
lights and traffic signals in case of storm related
outages.
27/28
DPR
Other requests for
Pritchard Mall Green Space located on Corbin
Corbin Place
park, building, or
Place between Brighton Beach Avenue and
btw BBA &
access
Oriental Boulevard, has become a broken up,
Ortl Blvd
improvements
hazardous looking eye sore. Crumbling cement
surrounds the entire area and needs to be
restored.
28/28
DPR
Reconstruct or
The Manhattan Beach Bath House harks back to
Oriental Blvd
upgrade a building
the days of yesteryear. Yet is sits there a shell of
and Falmouth
in a park
itself, an empty relic of a time gone by. The
Stree
community would love to see it restored, and
once again, providing changing facilities,
showers and lockers for the beach going
community.
CS
FDNY
Rehabilitate or
Engine 276/Ladder 156/Battalion 33 : 1635 East
renovate existing
14th Street New Commercial Dishwasher, a
fire houses or EMS
Washing Machine and a Clothes Dryer (Gas)
stations
Engine 254/Ladder 153 901 Avenue U New
Intercom system in firehouse Back-up Generator
1 inch yellow forestry hose to help at brush fire
operations Forcible entry training door Low
profile floor jack Metal studs and plywood to
build a search training course in the basement.
Engine 321: 2165 Gerritsen Avenue New
Apparatus (Truck Room) Floor Dishwasher
Engine 246/Ladder 169 2731 East 11th Street
Electrical Upgrades to Firehouse including Back-
up Generator New Refrigerator Commercial
range hood for outdoor grill
CS
SCA
Provide a new or
Brooklyn has grown in population at an
2200
expand an existing
alarming rate and our school systems have not
Gravesend
elementary school
caught up with the demands. We have several
Neck Road,
schools in the district that are overcrowded and
Brooklyn,
resources are stretched to the seams. We need
New York, NY
to take a good hard look at these schools and
seek solutions to either expand classrooms
when possible or create a new school to
accommodate these very real and growing
needs. Our children are our future and they
deserve the best education possible and
overcrowded classrooms can not provide that.
PS 254, PS 153 and PS 206 are prime examples
of schools at capacity.
CS
DSNY
Provide new or
Community Board 15's Sanitation garage is a
upgrade existing
temporary structure of trailers located on Knapp
sanitation garages
Street. We are requesting a permanent location
or other sanitation
to house Sanitation 15, Brooklyn.
infrastructure
CS DOT Reconstruct streets Gerritsen Beach was a heavily damaged area
during Super Storm Sandy. Flooding and Ponding have been an issue in the old section of Gerristen, (South of Bartlett Avenue), for many years, during the aftermath of Sandy it is critical these upgrades be made. We are requesting a new sewer system to be installed and in doing so it is imperative that DOT works hand in hand with DEP to reconstruct the streets of this community with each installation of a new sewer system.
Gerritsen Avenue Bartlett Avenue Plumb Beach Avenue
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/34
NYPD
Assign additional
Community Board 15 is in need of additional
2575 Coney
uniformed officers
police officers at our 61st Precinct, located at
Island Avenue
2575 Coney Island Avenue. Although our crime
rates are low, issues such as minor traffic
accidents, car break- ins and mischief in our
school yards and parks can go hours before an
officer is able to respond because the
department is currently spread too thin
handling more urgent calls.
2/34
NYPD
Provide additional
We would like to see additional cars purchased
2575 Coney
patrol cars and
for our precinct. Often cars are in the shop. We
Island
other vehicles
would also like funds to be allocated for repairs
Avenue,
of these vehicles.
Brooklyn,
New York, NY
3/34
DHS
Provide rental
Living in New York has become a costly affair.
assistance/vouchers
Rents are rising each year and the cost of living
for permanent
increases exponentially. Salaries don't appear to
housing
keep up with the rent demands. Our seniors and
disabled are on fixed incomes and struggle to
pay rent. We need a way to keep our lower
income residents safely in their homes and off
the streets with some sort of voucher system to
aide them. Hotels and shelters aren't
permanent housing, they often prove to be a
temporary fix and in the long run are not cost
efficient. The existing rental assistance
programs,such as section 8, which need better
policing are over saturated and closed.
4/34
DOB
Assign additional
Response times have improved but complaints
building inspectors
deemed, non hazardous and rated a C still take
(including
months to evaluate. We would like to see all
expanding training
complaints across the board be investigated in a
programs)
timely manner.
5/34
DEP
Inspect sanitary
Community Board 15 is requesting the
sewer on specific
installation of back-flow preventors throughout
street segment and
the district. This community experienced many
repair or replace as
sewer back up issues after Sandy and these
needed (Expense)
preventors would help with the back-ups. The
neighborhoods of Manhattan Beach,
Sheepshead Bay and Gerritsen Beach are the
areas most affected. On Avenue Y from
Mcdonald Avenue to Ocean Avenue going south
the area was inundated with sewer back-ups
and back-flow preventers would prevent that
from happening again.
6/34
DEP
Clean catch basins
Community Board 15 is prone to flooding during
rain events. Periodical cleaning of our storm
sewers is desperately needed. Specifically Shore
Blvd., between Pembroke and West End Avenue.
Oriental Avenue between Oxford and West End
Avenue. On Gerritsen Avenue from Channel
Avenue to Seba Avenue.
7/34
DEP
Investigate and
In both Sheepshead Bay and Gerritsen Creek we
address water
are asking for periodic maintenance to remove
quality complaints
all floatables in the Bay and in the Creek. This
at an address or on
pollution is a severe health hazard, as well as
specific street
making these heavily visited locations
segments
undesirable and unsightly for the community to
fully enjoy.
8/34
DPR
Forestry services,
Community Board 15 receives numerous
including street tree
complaints about trees not being pruned,
maintenance
maintained or planted in a timely fashion. More
money needs to be allocated to provide better
forestry services to our community, waiting 4 or
5 years is a ridiculously long time to have a tree
planted and tree pruning can take 7 - 10 years,
allowing it to become a hazard. We need to
expedite this procedure, so adequately funding
this division with additional trained staff and
equipment would help to streamline this too
long a process.
9/34
NYPD
Assign additional
All the schools in the District are in need of
crossing guards
additional crossing guards. With the severe
traffic around schools at dismissal, crossing
guards are imperative. Currently when a
crossing guard is out sick, a uniformed officer is
pulled away to take their place, taking an officer
away from other critical policing work.
10/34
FDNY
Provide more firefighters or EMS workers
Currently Kingsborough Community College at 2001 Oriental Blvd, during the Summer Months from May through October houses an FDNY fireboat. This fireboat is currently not manned 24/7 and we believe it would be in the best interest of the community if it could be. With a dry season, brush fires seem to have been more prevalent this year. Being a beach and boating community, rescues on the water are another challenge that a 24/7 fireboat would be well equipped to assist in. Pulling a boat from further away can be critical when time is of the essence. Being that this is a strategic location, we feel keeping it staffed and accessible 24/7 during the summer months would be a true asset to saving our residents and visitors lives.
2001 Oriental Blvd
11/34
NYPD
Assign additional traffic enforcement officers
All of our commercial corridors are backed up with traffic due to illegal double parking.
Additional traffic enforcement is needed along Coney Island Avenue from Avenue P to Avenue Z, on Avenue U from McDonald Avenue to Nostrand Avenue, on Sheepshead Bay Road from East 14th Street to Emmons Avenue and on Kings Highway from McDonald Avenue to Ocean Avenue.
12/34
FDNY
Provide more firefighters or EMS workers
Brush Fire Unit 6 in Gerritsen Beach, Brooklyn, NY needs additional manpower during brush fire season.
52 Seba Ave
13/34
DYCD
Provide, expand, or enhance after school programs for elementary school students (grades K- 5)
After school programs provide a safe, social and educational experience for our children giving them the ability to learn and grow into successful adults.
1970
Homecrest Avenue
14/34
DYCD
Provide, expand, or enhance after school programs for middle school students (grades 6-
8)
After school programs provide a safe, social and educational experience for our children giving them the ability to learn and grow into successful adults.
1401
Emmons Avenue
15/34
DOT
Address traffic
We need to take another look at Sheepshead
congestion
Bay Road and develop a plan that will alleviate
the heavy flow of traffic on Emmons Avenue
from Ocean Avenue to Shore Boulevard (west
bound) and along Sheepshead Bay Road from
Emmons Avenue to Voorhies Avenue (both north
and south bound). The area is too congested
and the city buses can barely get through. Our
commercial area doesn't flow correctly. We also
find Bay Academy JHS on Emmons Avenue and
East 14th Street causes snarls at drop-off and
dismissal times with parents adding to the
congestion.So a study should be conducted
when school is in session.
16/34
DHS
Expand street
Community Board 15 has seen a major increase
outreach
of homeless people on our streets, underpasses,
parks and train stations. We would like to see
more money allocated to do community
outreach and get these people the help and
services they need and return these public areas
back to the community. We have a
concentration of people under the train station
at Sheepshead Bay Road and East 15th Street,
Voorhies Avenue and East 16th Street -(Near the
Municipal Parking Lot), Ocean Avenue & Shore
Parkway under the overpass of the Belt Parkway
and in our green street parks located on Ocean
Avenue and Kings Highway.
17/34
DPR
Enhance park safety
Manhattan Beach Park is a remote location in a
Oriental Blvd
through more
quiet residential area often trespassed upon
and Ocean
security staff (police
after hours by young people who can be
Avenue
or parks
mischievous. We have had fires, loud music and
enforcement)
noise complaints emulating from the park late
at night and would like to see more regular
patrols of this area to discourage this behavior.
18/34
DSNY
Increase
Our community is inundated with illegal
enforcement of
advertising on every upright structure. Signs for
illegal posting laws
moving men and lately "Cash for Cars" signs
have appeared everywhere. There must be
severe penalties for such acts. These illegal
postings are defacing our entire community.
19/34
NYCTA
Improve bus
Transit should have a designated maintenance
cleanliness, safety
crew responsible for cleaning the exterior
or maintenance
entrances of all transit stations. Our underpass
at Sheepshead Bay is a chronic mess, as is
Avenue U and Kings Highway. Avenue X and
McDonald Avenue is extremely filthy.
20/34
EDC
Expand access to
We have commercial areas, such as Sheepshead
low cost financing to
Bay, Avenue X, Avenue U with empty storefronts
help neighborhood
causing a blight on the community. Barren
businesses construct
storefronts don't entice consumers. Our
or improve space
commercial districts are deteriorating. Rents are
high and mom and pop shops can't compete
with large online retailers. We need incentives
to encourage and assist would be shop keepers
to invest in our neighborhoods.
21/34
EDC
Improve public
We have been receiving an influx of calls
3004 Avenue
housing
emanating from The Sheepshead / Nostrand
V
maintenance and
Houses located in our district because of long
cleanliness
waits for repairs, from broken front doors,
broken appliances, plumbing issues and
unsanitary living conditions. One particular
resident from 3004 Avenue V has been waiting
over a month to be able to use her refrigerator.
The maintenance system in public housing is
broken, the prolonged waits are unacceptable
and perhaps additional maintenance crews are
need to be added to expedite the warrant of
habitability.
22/34
DPR
Provide better park
Our parks need more personnel to maintain
maintenance
them on a daily basis.
23/34
DSNY
Increase
Our underpasses which are dimly lit attract
East 16th
enforcement of
chronic illegal dumpers. If cameras could be
Street Avenue
illegal dumping laws
placed at these locations to catch them in the
U Avenue Z
act, we would deter this illegal activity from
occurring. East 16th Street from Avenues U thru
Z, contain, tires, furniture, e-waste, construction
materials and household trash strewn about
each week by illegal dumpers. We need to stop
this.
24/34
DPR
Other street trees
We have many sidewalk flags in our community
and forestry
in need of major repairs due to city trees
services requests
uprooting them. The current funding is not
adequate enough to get to all the sidewalks in
need of repair, we are requesting additional
funding to combat this growing sidewalk
hazard.
25/34
DSNY
Other cleaning
To keep up with the demands of our district, like
Emmons
requests
many we need more manpower. The Malls
Avenue
along Emmons Avenue are constantly collecting
Ocean
debris.
Avenue
Knapp Street
26/34
NYPD
Other NYPD
There is a fee of $24.00 a year an Explorer
programs requests
wanting to participate in the police program
must come up with to be a part of this
worthwhile group. We would like to see that fee
paid for or waived by the city of New York.
27/34
BPL
Extend library hours
The library offers programs for both young and
Coney Island
or expand and
old but, the hours of operation must support the
Avenue
enhance library
community. The branches must be open when it
programs
is convenient to the community. The Homecrest
branch needs to service a religious community
that needs Sunday hours while the Gravesend
branch needs later hours for all the working
families in the area.
28/34
NYPD
Other NYPD
The stations along the B and Q train lines are
programs requests
inundated with illegal merchants outside the
train stations. Whether Sheepshead Bay Road,
Avenue U or Kings Highway, illegal vendors
block the station entrances causing safety issues
as well as sanitation problems.
29/34
DSNY
Other garbage
Sanitation 15 requires additional manpower for
2501 Knapp
collection and
their derelict vehicle unit. Our area in inundated
Street
recycling
with calls about abandoned cars and having the
infrastructure
additional manpower would decrease response
requests (Expense)
times in removing these vehicles.
30/34
DSNY
Increase
We need more officers along Avenue U to
Avenue U
enforcement of
enforce these commercial businesses to keep
Coney Island
dirty sidewalk/dirty
the areas in front of their businesses clean. Over
Avenue
area/failure to clean
grown tree pits, illegal dumping and filthy
Ocean
area laws
sidewalks exist all along this corridor.
Avenue
31/34
DPR
New equipment for
We are requesting additional front end loaders
maintenance
to assist in cleaning.
(Expense)
32/34
DSNY
Increase vacant lot
The sidewalk and property abutting the B & Q
Homecrest
cleaning
train line by Homecrest Avenue, between Shore
Avenue Shore
Parkway and Neptune Avenue has become
Parkway
overgrown and utilized as an illegal dumping
Neptune
ground.
Avenue
33/34
DSNY
Increase
Sheepshead Bay Road a once thriving retail
Sheepshead
enforcement of
corridor has become a neighborhood eyesore.
Bay Road East
dirty sidewalk/dirty
Very few merchants maintain in front of their
14th Street
area/failure to clean
stores. We receive numerous complaints from
Emmons
area laws
residents who walk along that road.
Avenue
34/34 DPR New equipment for
maintenance (Expense)
We are requesting funding for packers for garbage removal.
image

