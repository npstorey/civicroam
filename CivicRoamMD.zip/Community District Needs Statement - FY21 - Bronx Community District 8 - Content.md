- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 8 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1uytU88kccJ6j2cdKH6YtKZ5S94LsFv68/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1uytU88kccJ6j2cdKH6YtKZ5S94LsFv68/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
8
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 8
image
Address: 5676 Riverdale Avenue, 100
Phone: (718) 884-3959
Email: bx08@cb.nyc.gov
Website: www.nyc.gov/bronxcb8
Chair: Rosemary Ginty District Manager: Ciara Gannon
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Bronx Community Board 8 (BxCB8) includes the neighborhoods of Fieldston, Kingsbridge, Kingsbridge Heights, Marble Hill, Riverdale, Spuyten Duyvil and Van Cortlandt Village. The majority of residents are between the ages of 18 and 64. There are, however, a significant number of children and senior citizens in BxCB8. BxCB8 has various types of housing including cooperative apartments, condominium units, one family houses, 2-4 family houses and multi-family apartment buildings. Board 8 has three New York City Housing Authority Developments: Marble Hill, Fort Independence and Bailey Houses. Our community has 68 park sites, with two of the most prominent being Van Cortlandt Park and Wave Hill. The NYCHA Developments are in need of major refurbishments for necessary work required on mechanical systems, including repair, maintenance, and replacement of heat and hot water systems and elevators. Funding for necessary exterior work, including repair, maintenance, and replacement of roofs and windows is also required. In addition, we request funding to maintain sufficient personnel for full staffing of all caretaker positions at Marble Hill, Fort Independence and Bailey Houses, and to hire additional skilled trade workers to service Marble Hill, Fort Independence and Bailey Houses. Our senior citizens are very important to us, and we support independent, healthy living for seniors. It is our determination to ensure that all of their concerns are addressed. Accordingly, we request funding: - to address the unique mental health issues in the geriatric community, including dementia care - to monitor home care firms - to fund administrative costs of outreach and home visiting programs for frail home-bound adults - to educate community on home safety design and modifications in order to allow older adults to safely remain in their homes - to increase count-down and audible crossing signals, and longer traffic light/walk changes on wide streets - to fund community based mental health services for older adults in centers and home settings. School aged children comprise a significant component of our population. Our children deserve a safe and supportive learning environment, and services to promote their development. We request funding for: - upgrade of playground surfaces and classroom Smart Boards, and - an upgrade of security to the many parks and playgrounds in our community. Our parks engage people of all ages, from all around the City, in healthy outdoor activities. However, many of our parks are in need of maintenance, reconstruction, and repair. We request funding for: - construction and related plumbing repairs in Fort Four Park, (hazardous condition in) Bailey Avenue playground, - a rest room at West 251st Street in Van Cortlandt Park adjacent to the parade grounds - construction of a pond wall at Spuyten Duyvil Park - erosion control measures in Ewen Park - reconstruction of the steps of the historic south side entrance to the Van Cortlandt House Museum - renovation of Van Cortlandt Park Stadium - renovation of the Strong Street playground, and - sufficient maintenance personnel in our parks. Our libraries are an invaluable cultural and educational resource. We request funding for: - Riverdale Branch: HVAC unit replacement, ADA upgrade – ADA bathrooms, full interior renovation; - Spuyten Duyvil Branch: expansion, boiler & HVAC unit replacements, ADA upgrade, general interior renovation. BxCB8 recognizes the need for programs to deal with food waste and collection of refuse in our community. We request funding for: - the NYC organic composting project - expansion of organic recycling - increase of Sanitation Enforcement’s staffing for enforcement of illegal dumping and pooper-scooper laws - an SUV to transport WEP workers with equipment to wider areas in the community requiring maintenance. We request funding for Department of Environmental Protection to: - increase resources for sewer inspections, cleaning and repair of curb drains, catch basins and sewer lines to alleviate flooding, - daylighting of Tibbets Brook both inside and outside Van Cortlandt Park to divert and prevent billions of gallons of water from overwhelming our combined sewer. BxCB8 is dedicated to the promotion of public safety. We request funding for additional Argus cameras for the 50th Precinct. BxCB8 recognizes the need to maintain safe streets in good condition, to promote the efficient flow of traffic and transportation throughout our community. We request funding for: - an increase in resurfacing to fifteen lane-miles - full reconstruction of the crumbling step street at Summit Place between Heath and Bailey Avenues, and - restoration to full Bx10 & Bx20 bus service to level prior to 2011 cuts. Finally, we request funding to enhance and promote the commercial areas in BxCB8 for: - a beautification project at Broadway West 225th Street up to West 242nd Street - benches and bike racks in commercial corridors, and - planning funds for community merchant organizations. Thank you for your consideration.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 8
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
Preservation of our Special Natural Area District (SNAD), in order to save the thriving green, bucolic nature of our neighborhoods is paramount to both their history and sustainability. Our commitment is unshakeable!
Parks
Parks: Our parks have proven to be more and more popular, and their upkeep and facilities have not kept pace. While we possess the largest natural park (Van Cortlandt) and one of the cultural/botanical/architectural gems (Wave Hill) with-in the five boroughs which attract their own attention, we must assure that the residents have adequate green facilities within the City's 10-minute walk commitment that will enable all residents to keep healthy.
Senior services
Senior Services: We are committed to the care and the improvement of the quality of life for our senior citizens. As our population ages, more services must be provided to respond to the unique needs of our seniors. We are determined to support community-based geriatric mental health services, home care, home safety, and innovative programs at our senior centers. The elderly have spent their lives providing for us, and we have an obligation to respect them and care for their particular needs in a timely manner.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 8
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
There is a pressing need for Dementia Care programs owing to the fact that Bronx Community Board 8 has a high population of seniors, and there is a need for outreach programs to educate family caregivers on dementia, person- centered caregiver support, and expansion of tuition assistance to allow eligible middle class participants to attend accredited social day services, facilitating their remaining in the community they helped build.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Funding for Innovative Services for Seniors (ISS) geriatric mental health program, meal services for seniors, and safe crossings. DFTA liaison for BxCB8.
Needs for Older NYs
The following programs and services are critical for Bronx Community Board 8's Aged population: -Dementia Care, - Homecare, -Home Safety -Safe Crossings, -Innovative Programming, -Geriatric Mental Health services.
Needs for Homeless
BXCB8 does have some homeless individuals sleeping on sidewalk and park benches. They also pan handle at shopping plazas and other public areas in BXCB8. Counselors are needed to assist them with shelter resources.
Needs for Low Income NYs
Increase Division of Housing Community Base and Centers; Increase Common Space for Youth and Senior Citizens (Fort Independence & Marble Hill)
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
5/29
DFTA
Enhance home care
Non-subsidized social adult day programs have
services
closed, leaving only one non-profit SADC in
Bronx CB8. The need for dementia care is
increasing. Expand tuition assistance for non-
profit programs to allow more eligible seniors to
afford SADC and fund outreach programs to
educate family caregivers on dementia, safety
issues and caregiver support opportunities.
12/29
DFTA
Increase
Senior Center Transportation: Transportation
transportation
service funding in Senior Center contracts.
services capacity
Walkability in many sections of our community
board is difficult – having steep hills, step streets
and long blocks. Regular bus service provides
limited North-South routes and even fewer East-
West routes. Frail/disabled residents continue to
experience difficulties with Access-A-Ride and
delayed taxi fare reimbursements
14/29
DFTA
Other senior center
Bronx CB8 has a large concentration of older
program requests
adults. The cost of operating and staffing senior
centers is growing and cash flow is difficult.
Continue to increase administrative funding to
ensure qualified professional staff and increase
outreach to lessen isolation and potential
abuse. Continue to shorten time to release
funding
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 8
image
M ost Important Issue Related to Youth, Education and Child Welfare
Schools and educational facilities (Maintenance)
Each student deserves a seat in our schools to ensure the optimum environment to provide a good education. However, the reality is that our schools increase capacity to the maximum at the expense of lunch rooms, auditoria, and gymnasia to house students. Our physical school capacity must increase to meet the student population which requires it. The provision and maintenance of air conditioning units, as well as 'smart boards,' in our schools are needed to improve the children's learning environments. Library upgrades provide support for curriculum, instruction and specialized efforts geared to improve student literacy.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Each student deserves a seat in our schools to ensure the optimum environment to provide a good education. However, the reality is that our schools increase capacity to the maximum at the expense of lunch rooms, auditoria, and gymnasia to house students. Our physical school capacity must increase to meet the student population which requires it. The provision and maintenance of air conditioning units in our schools are needed to improve the children's learning environments. Library upgrades provide support for curriculum, instruction and specialized efforts geared to improve student literacy.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
7/26
SCA
Renovate interior building component
Install security measures at PS81- Emergency automatic locks & bullet proof glass on all classroom doors
9/26
SCA
Renovate exterior building component
Upgrade blacktop recess yard to safe pavement and add play equipment
13/26
SCA
Renovate interior building component
PS 81 Air Conditioning for Auditorium
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
8/29
DOE
Other educational
Bronx Theater High School funds to support
programs requests
Performance Arts in the Black Box Theater
Programs go from September through June
21/29
DOE
Provide more funds
Industrial-size copy machine w/toner & service
for teaching
resources such as
classroom material
23/29
DOE
Improve school
Renovation of Main Office- Flooring, furniture,
safety
etc
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 8
image
M ost Important Issue Related to Public Safety and Emergency Services
Crime prevention programs
Anti crime focus -In response to reports of robberies, we support the installation of Argus cameras in designated areas of our community to deter criminal activity, and to create a documentary record of any crimes or conditions in said areas.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
In response to reports of robberies, and in consideration of the many school aged children travelling through our community, the Argus project, installing cameras at designated sites, will hopefully serve as a deterrent to crime, and also provide law enforcement with a tool to document the commission of any criminal activity, to assist them in the investigation of such activity.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
12/26 NYPD Provide surveillance
cameras
Argus Cameras for high priority areas: Broadway & West 225th Street including the area of West 225th Street to Exterior Street & Broadway to 230th Street; Kingsbridge & University Avenues, Webb Avenue & Eames Place, Claflin Avenue & West 197th Street; Broadway & West 242nd Street west & Manhattan College Parkway; Johnson & Riverdale Avenues from West 230th to West 232nd Street; Sedgwick Avenue, Reservoir Avenue to Fort Independence Street; Independence Street at West 239th Street including south to West 235th Street; Sedgwick Avenue, Van Cortlandt Avenue West; Orloff Avenue to Saxon Avenue; Bailey Avenue, Summit Place to West 234th Street; Riverdale Avenue, West 236th to West 238th Streets
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
4/29
NYPD
Other NYPD programs requests
At the intersection of Sedgwick Ave and Hillman Ave. There are two schools at this location: PS 95 and AmPark
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 8
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water runoff and flooding
Increase sewer inspections, cleaning and repair of curb drains, catch basins and sewer lines to alleviate serious local flooding problems. In addition, we need to divert millions of gallons of water from overwhelming our sewer system by construction for daylighting of Tibbets Brook both inside and outside of Van Cortlandt Park.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Funding for the completion of the Tibbett Brooks daylighting research; Restore Mosholu Golf Course & Driving Range (part of Croton Water Treatment Plant agreement)
Needs for Sanitation Services
Organic Recycling Expansion: Increase funding to expand Education and Outreach staff in order to maximize participation in Organic Recycling Program and support organic recycling drop-off centers in CB8.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
8/26
DEP
Evaluate a public
Support expenditure of DEP funds under the
location or property
Open Waters/City-Wide Long Term Control Plan
for green
(LTCP) in CD8 in accordance with 2014 NYS DEC
infrastructure, e.g.
requirements for green infrastructure coverage
rain gardens,
and expenditures and 2018 Bronx CB 8
stormwater
Resolution calling for it as the "primary focus" of
greenstreets, green
the LTCP, in consultation with CB8 E&S
playgrounds
Committee 30
10/26
DEP
Evaluate a public
Funds necessary to daylight freshwater wetland
location or property
known as Tibbetts Brook, which currently
for green
discharges into the Van Cortlandt Lake Weir and
infrastructure, e.g.
the Broadway sewer, and reconnect it to the
rain gardens,
Harlem River to reduce combined sewer
stormwater
overflow.
greenstreets, green
playgrounds
20/26
DSNY
Provide new or
Purchase an additional Haulster for snow
increase number of
season mobility
sanitation trucks
and other
equipment
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
9/29
DSNY
Other cleaning
Personnel funding adequate to operate 5
requests
Motorized Litter Patrol vehicles (MLP) for DSNY
to clean hard to get to areas (e.g., step streets)
13/29
DEP
Clean catch basins
Weir & Chamber Maintenance: Interagency
Tibbetts Brook weir maintenance plan that uses
best practices to mitigate flooding in Van
Cortlandt Lake, VCP, and Broadway sewer
16/29
DSNY
Increase
Enforcement of dog waste removal laws by
enforcement of
posting signs and increasing ticketing
canine waste laws
18/29 DSNY Provide or expand
NYC organics collection program
Organic Recycling Expansion: Increase funding to expand Education and Outreach staff in order to maximize participation in Organic Recycling Program and support organic recycling drop-off centers in CB8.
image
24/29 DEP Investigate air quality complaints at specific location
Air, asbestos and Noise Inspectors: Increase funds for more inspectors to alleviate enforcement issues due to construction boom and uptick in noise complaints in CB8.
image
25/29 DSNY Provide more
frequent litter basket collection
Overfilled Street Baskets: more frequent basket pick-up service to alleviate overfilled baskets, particularly in heavily trafficked commercial areas, and alleviate illegal dumping.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 8
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Preservation of our Special Natural Area District (SNAD), in order to save the thriving green, bucolic nature of our neighborhoods is paramount to both their history and sustainability.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Separate Riverdale [NA2] and Staten Island [NA1] Special Natural Districts (SNAD) from each other to concentrate on the distinct differences for planning and development in Riverdale. Building "as of right" limits the community's ability to preserve the character and architectural heritage which they established and/or intentionally moved into.. The community should have some say on development within the context of existing buildings, parks, schools, and other immediate amenities.
Needs for Housing
Maintain full staffing of all caretaker positions at NYCHA Marble Hill, Fort Independence and Bailey Avenue, and Houses complexes. Hire additional skilled trade workers to service these sites. Funding for roof maintenance and roof replacement at Fort Independence Houses. These have been severe and long-standing issues for the residents.
Needs for Economic Development
A Small Business Services (SBS) business area beautification
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/26
NYCHA
Renovate or
Replacement of Boilers at Marble Hill ($12.6m)
upgrade public
and Fort Indep. ($6.3m)
housing
developments
11/26
NYCHA
Renovate or
Apartment Kitchen Renovations- 8.37 M; Floor
upgrade NYCHA
& Doors0 $9.96 M; Radiator/ Convector/
community facilities
Baseboard $1.86 M.
or open space
26/26
NYCHA
Renovate or
Restroom Accommodations for elderly and
upgrade public
disabled tenants (grab bar installation)
housing
developments
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
3/29
NYCHA
Other housing
Rodent control
support requests
15/29
SBS
Conduct BID
Placement of SBS Neighborhood 360 Fellow in
Feasibility Analysis
CB8 to assist in merchant association
or support BID
organization
Formation Planning
for a selected
commercial district
19/29
SBS
Other expense
Benches and/or Street Seats in commercial
commercial district
zones to help transform our commercial districts
revitalization
into vibrant social spaces
requests
22/29
HPD
Provide or enhance
Affordable Housing Serving Older District
rental subsidies
Residents: To reduce homelessness and allow
programs
older residents with low/moderate income to
continue to age in their familiar communities,
fund housing subsidies for current residents to
avail themselves of neighborhood preferences in
new and existing affordable senior housing
buildings and to prevent financial-driven
evictions from current units
27/29 SBS Support non-profit
organizational development and capacity building
In order to bring business services to business owners in CB8
image
TRANSPORTATION
Bronx Community Board 8
image
M ost Important Issue Related to Transportation and Mobility
Subway service (frequency and access)
BxCB8 office is located at the far end of our district, making it inaccessible to residents for constituent services, as well as participation in CB meetings and access to and from train and subway service.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Construction of a contiguous side walk on north side of West 254th Street from Netherland Avenue to MTA Railroad Terrace (at the Riverdale MetroNorth Rail Road station). The many local residents are forced to walk on West 254 St, exposing themselves to catastrophic vehicular danger. The very hilly nature of this district requires many high- maintenance step streets. Reconstruction and maintenance of the step streets is sorely needed. BxCB8 has generally good subway and MNRR train service to the West Bronx and Manhattan, but needs elevator access to the 1 IRT subway terminus at West 242nd Street - a key access point to Van Cortlandt Park for millions of NYC residents, It also has inadequate bus service in the district connecting to the subways, minimizing their utility to local residents. Bx10 and Bx20 bus lines had been severely curtailed in 2011 and need to be restored to full service.
Needs for Transit Services
Increase Bx10 and restore full BX 20 service to level prior to 2011 cuts. These cuts have caused a tremendous issue with overcrowding, and reduction of subway ridership.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/26
NYCTA
Improve
Install elevator at 242 St. 1 subway terminus
accessibility of
for handicap access to subway, Van Cortlandt
transit
Park, etc.
infrastructure, by
providing elevators,
escalators, etc.
14/26
DOT
Repair or build new
Rehabilitate step street at Summit Place
step streets
between Heath Avenue & Bailey Avenue
19/26
DOT
Other capital traffic
CSX: Supplement funding from the Croton
improvements
Filtration Monitoring Committee to purchase
requests
the land known as the former Putnam Right-of-
Way alongside the Major Deegan Expressway
from West 230th St to Van Cortlandt Park South
from CSX Railroad to create a greenway.
21/26
DOT
Improve traffic and
Create a sidewalk on the north side of W. 254th
pedestrian safety,
Street from Riverdale Avenue to Palisade
including traffic
Avenue to rehabilitate the infrastructure on the
calming (Capital)
street to provide for adequate drainage
23/26
DOT
Improve traffic and
Build a sidewalk staircase connecting
pedestrian safety,
Independence Ave from 5900 Arlington Ave to
including traffic
West 261st Street
calming (Capital)
25/26
DOT
Other capital traffic
Increase the resurfacing of streets in
improvements
Community Board 8 to fifteen lane miles
requests
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
7/29 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
AGING - Safe Crossings Inspect and maintain pavement at cross-walks throughout the district to mitigate falls that often lead to health decline and death and refresh cross-walk lines striping to increase driver and pedestrian visibility.
Install Accessory Pedestrian Signals (auditory, chirping signals). Lengthen pedestrian walk signals and add audible crossing signals near large senior populations and shopping areas
image
11/29
DOT
Provide new traffic or pedestrian signals
Install countdown pedestrian traffic signals throughout CB8
26/29
NYCTA
Expand bus service
Restore full Bx20 service: to level prior to 2011
frequency or hours
service cuts
of operation
28/29
DOT
Improve traffic and
Increase funding for school crossing guards
pedestrian safety,
throughout CB 8
including traffic
calming (Expense)
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 8
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Community board resources (offices, staff and equipment)
BxCB8 office is located at the far end of our district, making it inaccessible to residents for constituent services, as well as participation in CB meetings. It is a windowless, inhospitable environment for City employees and residents alike. DCAS should work hand-in-hand with our office and leadership to facilitate a workable solution promptly. Our parks are not being properly maintained due to lack of staff, and projects that are needed are not being done, such as: - Fort Four Park restroom reconstruction - Bailey Avenue playground redesign and reconstruction - Spuyten Duyvil Park pond wall construction - Ewen Park erosion control measures - Strong Street playground renovation. In addition, Van Cortlandt Park awaits the construction of a restroom at Broadway and West 251st Street (next to the Parade Grounds), renovation of the steps on the historic south side entrance to the VCP Museum, and renovation of the VCP stadium which should otherwise be condemned.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Bronx Community Board 8 has a longstanding request for construction of a new restroom and related plumbing repairs in Fort Four Park, a heavily used park. Partial funding has been provided by elected officials, but more is needed. At the community's request, we strongly urge that the remaining funds needed to complete this project be granted in a timely manner to carry this project forward. We continue to request implementation of the Bailey Avenue playground redesign and reconstruction, Spuyten Duyvil Park pond wall construction, Ewen Park erosion control measures, Strong Street playground renovation, and in Van Cortlandt Park the construction of a restroom at Broadway and West 251st Street (next to the parade grounds), as well as renovation of the steps on the historic south side entrance to the VCP Museum, and renovation of the VCP stadium.
Needs for Cultural Services
No comments
Needs for Library Services
Bronx Community Board 8's five branch libraries - Jerome Park, Kingsbridge, Riverdale, Spuyten Duyvil and Van Cortlandt - are heavily used resource and programming centers. The libraries are home to all from seniors to students and toddlers. Funding the requests of the libraries is essential to ensure full purpose operation. BxCB8 supports the following requests for critical upgrades: -Riverdale - HVAC replacement, ADA upgrade, and full interior renovation; -Spuyten Duyvil - HVAC and boiler replacement, including ADA upgrade, with general interior renovation, -Van Cortlandt - relocation funding. In addition, WiFi service should be provided to all branches, and expansion of 6-day-a-week branch opening.
Needs for Community Boards
Building "as of right" limits the community's ability to preserve the character and architectural heritage which they established and/or intentionally moved into. The community should have some say on development within the context of existing buildings, parks, schools, and other immediate amenities. BxCB8 office is located at the far end of our district, making it inaccessible to residents for constituent services, as well as participation in CB meetings. It is also a windowless, inhospitable environment for City employees and residents alike. DCAS should work hand-in- hand with our office and leadership to facilitate a workable solution promptly.
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/26
DPR
Provide a new, or
PARKS & RECREATION - Restroom Construction
Broadway &
new expansion to, a
at Broadway and West 251st Street in Van
West 251st
building in a park
Cortlandt Park adjacent to the Parade Grounds.
Street
The lack of the facility in a very high use area for
local residents creates a sanitary health and
safety risk.
3/26
DPR
Reconstruct or
Redesign and reconstruction of Bailey Avenue
upgrade a park or
playground. Drains at southeast end of
amenity (i.e.
playground require immediate repair to
playground, outdoor
eliminate pools of standing water, which are a
athletic field)
health hazard.
5/26
DPR
Reconstruct or
Renovation of Van Cortlandt Mansion: in VCP to
upgrade a building
bring into code compliance, provide
in a park
handicapped accessibility, and do repairs
associated with waterproofing the structure,
paint exterior fence, and repair deteriorated
stairs on the historic southside entrance.
6/26
NYPL
Create a new, or
Exterior upgrade which will beautify the exterior
renovate or upgrade
to complete the patron’s experience
an existing public
library
15/26
DPR
Reconstruct or
PARKS & RECREATION - Erosion control
upgrade a building
measures in Ewen Park to prevent runoff
in a park
downhill toward Riverdale Avenue. It was noted
that the slope is used for sledding in the winter
and that this should be considered if and when
erosion-control measures are undertaken.
16/26
BPL
Create a new, or
Funds to ensure our branches can continue to
renovate or upgrade
meet the growing need in our community.
an existing public
library
17/26
DPR
Reconstruct or
PARKS & RECREATION - Reconstruction of the
upgrade a park or
Pond Wall at Spuyten Duyvil Park to prevent
amenity (i.e.
water run off onto the roadway in the parking
playground, outdoor
lot of the Metro North station.
athletic field)
18/26
DPR
Reconstruct or
Repair of the "birding (foot)bridge" over
upgrade a park or
Tibbetts Brook outside the fence around the golf
amenity (i.e.
course in Van Cortlandt Park [Committee notes
playground, outdoor
that project is partially funded]
athletic field)
22/26
DPR
Reconstruct or
Roof replacement, replacement of leaky
upgrade a building
windows & exterior doors, renovation of sinking
in a park
floors & bathrooms including upgrading to ADA
compliance, and repair or replacement of
stoves, refrigerators, cooling handlers, and
HVAC control panel [It is a DPR facility].
24/26
DPR
Reconstruct or
PARKS & RECREATION Renovation of Van
upgrade a park or
Cortlandt Park Stadium
amenity (i.e.
playground, outdoor
athletic field)
CS
NYPL
Create a new, or
LIBRARIES funding for relocation of branch,
3874
renovate or upgrade
including furniture, equipment and ADA
Sedgwick
an existing public
compliance.
Avenue
library
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/29
DPR
Enhance park safety
Parks Maintenance Personnel and Enforcement
through more
DRP Personnel for Lawns and Landscaped
security staff (police
areas and Enforcement: PARKS & RECREATION -
or parks
Gardeners and other personnel sufficient for
enforcement)
maintenance, especially of lawns and
landscaped areas, and enforcement in CB8
parks, especially on weekends and times of high
use.
2/29
DPR
Enhance park safety
PEP personnel to alleviate the chronic double
through more
parking on Broadway at Van Cortlandt Park,
security staff (police
whether through issuance of summonses or
or parks
other means
enforcement)
10/29
DPR
New equipment for
Purchase replacement tractor and
maintenance
accompanying trailer and a lawnmower to aid
(Expense)
in maintenance of CB8 parks.
17/29 DPR Improve trash
removal and cleanliness
Purchase of a mini-packer garbage truck for CB8 parks
image
20/29 DPR New equipment for
maintenance (Expense)
Purchase of New Crew-cab Pick-up Trucks with a lift-gate to replace aging vehicles in CB8 neighborhood parks.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority Agency Request Explanation Location
image
6/29 Other Other expense
budget request
DEP staff to protect & maintain DEP property in and around Jerome Park Reservoir; supervise public access to CB8 residents
image
29/29 Other Other expense
budget request
Increase in funding for the Crime Victims Unit of the DA’s Office
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/26
NYCHA
Renovate or
Replacement of Boilers at Marble Hill ($12.6m)
upgrade public
and Fort Indep. ($6.3m)
housing
developments
2/26
DPR
Provide a new, or
PARKS & RECREATION - Restroom Construction
Broadway &
new expansion to, a
at Broadway and West 251st Street in Van
West 251st
building in a park
Cortlandt Park adjacent to the Parade Grounds.
Street
The lack of the facility in a very high use area for
local residents creates a sanitary health and
safety risk.
3/26
DPR
Reconstruct or
Redesign and reconstruction of Bailey Avenue
upgrade a park or
playground. Drains at southeast end of
amenity (i.e.
playground require immediate repair to
playground, outdoor
eliminate pools of standing water, which are a
athletic field)
health hazard.
4/26
NYCTA
Improve
Install elevator at 242 St. 1 subway terminus
accessibility of
for handicap access to subway, Van Cortlandt
transit
Park, etc.
infrastructure, by
providing elevators,
escalators, etc.
5/26
DPR
Reconstruct or
Renovation of Van Cortlandt Mansion: in VCP to
upgrade a building
bring into code compliance, provide
in a park
handicapped accessibility, and do repairs
associated with waterproofing the structure,
paint exterior fence, and repair deteriorated
stairs on the historic southside entrance.
6/26
NYPL
Create a new, or
Exterior upgrade which will beautify the exterior
renovate or upgrade
to complete the patron’s experience
an existing public
library
7/26
SCA
Renovate interior
Install security measures at PS81- Emergency
building component
automatic locks & bullet proof glass on all
classroom doors
8/26
DEP
Evaluate a public location or property
Support expenditure of DEP funds under the Open Waters/City-Wide Long Term Control Plan
for green
(LTCP) in CD8 in accordance with 2014 NYS DEC
infrastructure, e.g.
requirements for green infrastructure coverage
rain gardens,
and expenditures and 2018 Bronx CB 8
stormwater
Resolution calling for it as the "primary focus" of
greenstreets, green
the LTCP, in consultation with CB8 E&S
playgrounds
Committee 30
9/26
SCA
Renovate exterior
Upgrade blacktop recess yard to safe pavement
building component
and add play equipment
10/26
DEP
Evaluate a public
Funds necessary to daylight freshwater wetland
location or property
known as Tibbetts Brook, which currently
for green
discharges into the Van Cortlandt Lake Weir and
infrastructure, e.g.
the Broadway sewer, and reconnect it to the
rain gardens,
Harlem River to reduce combined sewer
stormwater
overflow.
greenstreets, green
playgrounds
11/26
NYCHA
Renovate or
Apartment Kitchen Renovations- 8.37 M; Floor
upgrade NYCHA
& Doors0 $9.96 M; Radiator/ Convector/
community facilities
Baseboard $1.86 M.
or open space
12/26
NYPD
Provide surveillance
Argus Cameras for high priority areas:
cameras
Broadway & West 225th Street including the
area of West 225th Street to Exterior Street &
Broadway to 230th Street; Kingsbridge &
University Avenues, Webb Avenue & Eames
Place, Claflin Avenue & West 197th Street;
Broadway & West 242nd Street west &
Manhattan College Parkway; Johnson &
Riverdale Avenues from West 230th to West
232nd Street; Sedgwick Avenue, Reservoir
Avenue to Fort Independence Street;
Independence Street at West 239th Street
including south to West 235th Street; Sedgwick
Avenue, Van Cortlandt Avenue West; Orloff
Avenue to Saxon Avenue; Bailey Avenue,
Summit Place to West 234th Street; Riverdale
Avenue, West 236th to West 238th Streets
13/26
SCA
Renovate interior
PS 81 Air Conditioning for Auditorium
building component
14/26
DOT
Repair or build new
Rehabilitate step street at Summit Place
step streets
between Heath Avenue & Bailey Avenue
15/26
DPR
Reconstruct or
PARKS & RECREATION - Erosion control
upgrade a building
measures in Ewen Park to prevent runoff
in a park
downhill toward Riverdale Avenue. It was noted
that the slope is used for sledding in the winter
and that this should be considered if and when
erosion-control measures are undertaken.
16/26
BPL
Create a new, or
Funds to ensure our branches can continue to
renovate or upgrade
meet the growing need in our community.
an existing public
library
17/26
DPR
Reconstruct or
PARKS & RECREATION - Reconstruction of the
upgrade a park or
Pond Wall at Spuyten Duyvil Park to prevent
amenity (i.e.
water run off onto the roadway in the parking
playground, outdoor
lot of the Metro North station.
athletic field)
18/26
DPR
Reconstruct or
Repair of the "birding (foot)bridge" over
upgrade a park or
Tibbetts Brook outside the fence around the golf
amenity (i.e.
course in Van Cortlandt Park [Committee notes
playground, outdoor
that project is partially funded]
athletic field)
19/26
DOT
Other capital traffic
CSX: Supplement funding from the Croton
improvements
Filtration Monitoring Committee to purchase
requests
the land known as the former Putnam Right-of-
Way alongside the Major Deegan Expressway
from West 230th St to Van Cortlandt Park South
from CSX Railroad to create a greenway.
20/26
DSNY
Provide new or
Purchase an additional Haulster for snow
increase number of
season mobility
sanitation trucks
and other
equipment
21/26
DOT
Improve traffic and
Create a sidewalk on the north side of W. 254th
pedestrian safety,
Street from Riverdale Avenue to Palisade
including traffic
Avenue to rehabilitate the infrastructure on the
calming (Capital)
street to provide for adequate drainage
22/26
DPR
Reconstruct or
Roof replacement, replacement of leaky
upgrade a building
windows & exterior doors, renovation of sinking
in a park
floors & bathrooms including upgrading to ADA
compliance, and repair or replacement of
stoves, refrigerators, cooling handlers, and
HVAC control panel [It is a DPR facility].
23/26
DOT
Improve traffic and pedestrian safety, including traffic calming (Capital)
Build a sidewalk staircase connecting Independence Ave from 5900 Arlington Ave to West 261st Street
24/26
DPR
Reconstruct or
PARKS & RECREATION Renovation of Van
upgrade a park or
Cortlandt Park Stadium
amenity (i.e.
playground, outdoor
athletic field)
25/26
DOT
Other capital traffic
Increase the resurfacing of streets in
improvements
Community Board 8 to fifteen lane miles
requests
26/26
NYCHA
Renovate or
Restroom Accommodations for elderly and
upgrade public
disabled tenants (grab bar installation)
housing
developments
CS
NYPL
Create a new, or
LIBRARIES funding for relocation of branch,
3874
renovate or upgrade
including furniture, equipment and ADA
Sedgwick
an existing public
compliance.
Avenue
library
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/29
DPR
Enhance park safety
Parks Maintenance Personnel and Enforcement
through more
DRP Personnel for Lawns and Landscaped
security staff (police
areas and Enforcement: PARKS & RECREATION -
or parks
Gardeners and other personnel sufficient for
enforcement)
maintenance, especially of lawns and
landscaped areas, and enforcement in CB8
parks, especially on weekends and times of high
use.
2/29
DPR
Enhance park safety
PEP personnel to alleviate the chronic double
through more
parking on Broadway at Van Cortlandt Park,
security staff (police
whether through issuance of summonses or
or parks
other means
enforcement)
3/29
NYCHA
Other housing
Rodent control
support requests
4/29
NYPD
Other NYPD
At the intersection of Sedgwick Ave and Hillman
programs requests
Ave. There are two schools at this location: PS
95 and AmPark
5/29
DFTA
Enhance home care
Non-subsidized social adult day programs have
services
closed, leaving only one non-profit SADC in
Bronx CB8. The need for dementia care is
increasing. Expand tuition assistance for non-
profit programs to allow more eligible seniors to
afford SADC and fund outreach programs to
educate family caregivers on dementia, safety
issues and caregiver support opportunities.
6/29
Other
Other expense
DEP staff to protect & maintain DEP property in
budget request
and around Jerome Park Reservoir; supervise
public access to CB8 residents
7/29
DOT
Improve traffic and
AGING - Safe Crossings Inspect and maintain
pedestrian safety,
pavement at cross-walks throughout the district
including traffic
to mitigate falls that often lead to health decline
calming (Expense)
and death and refresh cross-walk lines striping
to increase driver and pedestrian visibility.
Install Accessory Pedestrian Signals (auditory,
chirping signals). Lengthen pedestrian walk
signals and add audible crossing signals near
large senior populations and shopping areas
8/29
DOE
Other educational programs requests
Bronx Theater High School funds to support Performance Arts in the Black Box Theater Programs go from September through June
9/29
DSNY
Other cleaning
Personnel funding adequate to operate 5
requests
Motorized Litter Patrol vehicles (MLP) for DSNY
to clean hard to get to areas (e.g., step streets)
10/29
DPR
New equipment for
Purchase replacement tractor and
maintenance
accompanying trailer and a lawnmower to aid
(Expense)
in maintenance of CB8 parks.
11/29
DOT
Provide new traffic
Install countdown pedestrian traffic signals
or pedestrian
throughout CB8
signals
12/29
DFTA
Increase
Senior Center Transportation: Transportation
transportation
service funding in Senior Center contracts.
services capacity
Walkability in many sections of our community
board is difficult – having steep hills, step streets
and long blocks. Regular bus service provides
limited North-South routes and even fewer East-
West routes. Frail/disabled residents continue to
experience difficulties with Access-A-Ride and
delayed taxi fare reimbursements
13/29
DEP
Clean catch basins
Weir & Chamber Maintenance: Interagency
Tibbetts Brook weir maintenance plan that uses
best practices to mitigate flooding in Van
Cortlandt Lake, VCP, and Broadway sewer
14/29
DFTA
Other senior center
Bronx CB8 has a large concentration of older
program requests
adults. The cost of operating and staffing senior
centers is growing and cash flow is difficult.
Continue to increase administrative funding to
ensure qualified professional staff and increase
outreach to lessen isolation and potential
abuse. Continue to shorten time to release
funding
15/29
SBS
Conduct BID
Placement of SBS Neighborhood 360 Fellow in
Feasibility Analysis
CB8 to assist in merchant association
or support BID
organization
Formation Planning
for a selected
commercial district
16/29
DSNY
Increase
Enforcement of dog waste removal laws by
enforcement of
posting signs and increasing ticketing
canine waste laws
17/29
DPR
Improve trash removal and cleanliness
Purchase of a mini-packer garbage truck for CB8 parks
18/29
DSNY
Provide or expand
Organic Recycling Expansion: Increase funding
NYC organics
to expand Education and Outreach staff in order
collection program
to maximize participation in Organic Recycling
Program and support organic recycling drop-off
centers in CB8.
19/29
SBS
Other expense
Benches and/or Street Seats in commercial
commercial district
zones to help transform our commercial districts
revitalization
into vibrant social spaces
requests
20/29
DPR
New equipment for
Purchase of New Crew-cab Pick-up Trucks with a
maintenance
lift-gate to replace aging vehicles in CB8
(Expense)
neighborhood parks.
21/29
DOE
Provide more funds
Industrial-size copy machine w/toner & service
for teaching
resources such as
classroom material
22/29
HPD
Provide or enhance
Affordable Housing Serving Older District
rental subsidies
Residents: To reduce homelessness and allow
programs
older residents with low/moderate income to
continue to age in their familiar communities,
fund housing subsidies for current residents to
avail themselves of neighborhood preferences in
new and existing affordable senior housing
buildings and to prevent financial-driven
evictions from current units
23/29
DOE
Improve school
Renovation of Main Office- Flooring, furniture,
safety
etc
24/29
DEP
Investigate air
Air, asbestos and Noise Inspectors: Increase
quality complaints
funds for more inspectors to alleviate
at specific location
enforcement issues due to construction boom
and uptick in noise complaints in CB8.
25/29
DSNY
Provide more
Overfilled Street Baskets: more frequent basket
frequent litter
pick-up service to alleviate overfilled baskets,
basket collection
particularly in heavily trafficked commercial
areas, and alleviate illegal dumping.
26/29
NYCTA
Expand bus service
Restore full Bx20 service: to level prior to 2011
frequency or hours
service cuts
of operation
27/29
SBS
Support non-profit organizational development and capacity building
In order to bring business services to business owners in CB8
28/29
DOT
Improve traffic and pedestrian safety, including traffic calming (Expense)
Increase funding for school crossing guards throughout CB 8
29/29
Other
Other expense budget request
Increase in funding for the Crime Victims Unit of the DA’s Office

