- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Staten Island Community District 3 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1gGTzXrlrPy2uOLhb6HjVaJ_3Pab_iG8d/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1gGTzXrlrPy2uOLhb6HjVaJ_3Pab_iG8d/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Staten Island Community District
3
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Staten Island Community Board 3
image
Address: 9876543210 Woodrow Road, 2nd Floor Phone: (718) 356-7900
Email: sicb3@cb.nyc.gov
Website: www.nyc.gov/sicb3
Chair: Frank Murano District Manager: Charlene Wagner
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 3 Staten Island aka "the south shore" is comprised of the towns of Annadale - Arden Heights - Bay Terrace - Charleston - Eltingville - Great Kills - Greenridge - Huguenot - New Dorp - Oakwood - Pleasant Plains - Prince's Bay - Richmond Valley - Richmondtown - Rossville - Tottenville - Woodrow. CB3 is primarily low-density residential communities, with small town business districts serving residents. In recent years we have seen an increase in large retail development such as Bricktown and the Charleston Retail Center. We also look forward to several new economic development projects planned for Richmond Valley, Charleston and Rossville. Zoning has preserved our low-density neighborhoods. Low density residential growth is decreed, due to our deficiencies in sanitary and storm systems, our poor road infrastructure, and the lack a true mass transportation system.
4. TOP THREE PRESSING ISSUES OVERALL
Staten Island Community Board 3
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
Preserve neighborhoods and continue to oppose residential over density. Due to our lack of sanitary and storm water infrastructure, poor roads, and absence of mass transit we can not overburden our basic services without extensive improvements to support population increases.
Street conditions (roadway maintenance)
The entire of borough of Staten Island suffers from poor road conditions. Even with DOT’s constant repair efforts our roads are aged and most are in need of total road reconstruction. This statement is repetitive, but the truth is most of our roads are literally “paved cow paths.” The reasons for road failure are complex. Borough-wide resurfacing using the same disappointing materials, resurfacing roads with substandard road bases, street flooding, and utility cuts contribute to our failing roads. Unless NYC adopts new construction techniques and upgrades resurfacing materials NYC will never improve the overall life expectancy of our roads and we will continue the unending cycle of road repair. Street flooding requires capital projects for storm water systems and utility cuts must be controlled by cooperative planning for upgrades by utility companies.
Traffic
Staten Island residents depend on their vehicles for daily living. Work, school, visiting family, doctor's appointments, children's extra activities etc. Our growth has overburdened our roads with increased traffic. The few main arterials we rely on are not sufficient and are in need of road reconstruction. Our secondary roads do not have the proper structure to handle the amount of traffic they endure which is the cause of premature road failure conditions. The Staten Island Expressway and West Shore Expressway are a commuters worst nightmare. Any event that causes vehicles to stop for a brief period leads to backups that last for hours after the triggering incident has been cleared. And those incidents always lead to spillover tie-ups on surrounding streets. Our only rail transit consists of the Staten Island Railway, a single direct line from St. George to Tottenville. If you don't live within walking distance to a railway station, you must drive and use a Park & Ride. Express Bus commuters have been complaining for a decade about the service on the south shore. Currently there has been a demand for an MTA study of Staten Island Express buses. NYC needs to explore other modes of transportation like a light rail. Lastly, re-configuring road markings for the sole reason to incorporate bike lanes is not welcomed. We need improvements to lessen our traffic nightmares in order to survive our daily routines. Bike lanes are not essential for commuters.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Staten Island Community Board 3
image
M ost Important Issue Related to Health Care and Human Services
Mental health and substance abuse treatment and prevention programs
Develop programs to support rehabilitation and education for drug abuse. Perhaps the bigger question we should be addressing is why people believe their life so difficult that they search for relief and comfort from drugs. Mental health and drug abuse co-occur; we need to address emotional and psychological health issues that lead to drug abuse. Secondary, our seniors would benefit greatly by increasing the number of programs and services available on the south shore. Most of our seniors lead active productive lives, have family and friends nearby, and participate in their community. For seniors who may need assistance, we should have easy access to programs that support their health needs, we should increase the number of senior centers to be of service in more neighborhoods, and most importantly, we should have programs that will give them the ability to live independently at home in their own community.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
3/5 DFTA Allocate funds for
outreach services to homebound older adults and for programs that allow the elderly to age in place
Services on the south shore are limited, expand existing and support new programs to keep seniors in their homes.
YOUTH, EDUCATION AND CHILD WELFARE
Staten Island Community Board 3
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
Due to population growth on the south shore there is a need for an additional education complex.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
12/19 SCA Provide a new or
expand an existing high school
Allocate construction funds for a new school in the Charleston Retail Center. The potential for an additional learning complex was created when the Charleston Retail Center was developed. The south shore needs additional schools, especially a high school which would benefit all of Staten Island. This would also be a great site to develop a technical or specialized high school to provide students with alternative further education. Refer to 503199701C
Expense Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
PUBLIC SAFETY AND EMERGENCY SERVICES
Staten Island Community Board 3
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
Speeding and disregard for traffic controls is a major safety issue. We have experienced an increase in complaints from constituents regarding pedestrian safety and motorists that ignore traffic signs and signals.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
Community Board 3 gives it's full support and advocates for all requests that will strengthen FDNY services to the Staten Island Community.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
4/19
FDNY
Provide new
We request that NYC designate space for a
57 Cleveland
facilities such as a
FDNY satellite training facility to support
Place, Staten
firehouse or EMS
ongoing training for EMTs and paramedics. NYC
Island, New
station
recently acquired a 7 acre property (former St.
York, NY
John Villa Academy) in Staten Island earmarked
for the Department of Education. In addition to
being used as a training facility it would serve
the Staten Island community as classroom space
for community residents to take the Free FDNY
CPR training courses.
5/19
FDNY
Provide new
The purchase of an MARR vehicle will allow
emergency vehicles,
mutual aid rapid response in the event of a
such as fire trucks or
mutual aid activation. The FDNY holds mutual
ambulances
aid agreements in the event of any emergency,
catastrophic event or disaster. FDNY EMS
Operations serves as the primary coordinator
for all mutual aid activations provided under
agreements by Volunteer, Voluntary Hospitals,
NYS Mobilization Plan, Nassau County, New
Jersey, Suffolk County and the REMSCO Regional
Plan. The purchase of an MARR supports several
goals and objectives in the FDNY related to
enhancing regional capabilities, EMS service
tiered response, coordination, mutual aid,
public health readiness and enhancing incident
management and response capabilities.
6/19
NYPD
Add NYPD parking
The 123 Precinct on Main Street continues to
116 Main
facilities
have a serious lack of parking, both for POs,
Street, Staten
staff and visitors to Precinct. Block 8028 Lot 75
Island, New
on Main Street and Block 8028 Lot 10 are
York, NY
vacant. The owners are willing to make space
available for NYPD parking but are having
difficulty with the Department of Buildings. NYC
should intercede to fast-track an agreement.
7/19 FDNY Provide new
emergency vehicles, such as fire trucks or ambulances
Bariatic ambulances are in service in the boroughs of Brooklyn and Queens. Significant population of medical calls in addition to Brooklyn and Queens requiring bariatric response and transport are in Manhattan and the Bronx. In order to provide timely bariatric ambulance response the FDNY needs additional bariatric ambulances apparatus to the boroughs of Manhattan and the Bronx.
Additional bariatric ambulances will support FDNY goals and objectives related to challenges bariatric patients pose for pre-hospital care and transport directly affecting patient outcomes.
Expense Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Staten Island Community Board 3
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Other
Need Sanitary and Storm sewers to replace septic systems and catch basins. Also, existing older systems require upgrades.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Our budget requests repeatedly asks for sewer projects in specific neighborhoods where we receive the most complaints. It should also be noted that Staten Island has only two Sewer Treatment Plants that run at full capacity. During storm events these treatment plants are often unable to handle the capacity and untreated water released into our tributaries. Our future development, whether commercial or residential, compels us to plan for an additional treatment plant on the south shore.
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
10/19
DEP
Develop a capital
Allocate funding for a Pump Station in the
project for specific
Charleston/Richmond Valley area. With the
street segments
south shore experiencing rapid commercial
currently lacking
growth it is crucial to the future of our economic
sanitary sewers
development to have a sewer infrastructure.
Refer to 503199708C
13/19
DEP
Evaluate a public
Develop a project that will eliminate storm
Hylan Blvd
location or property
water flooding on all streets south of Hylan
Richard
for green
Blvd. between Richard Avenue and Swinnerton
Avenue
infrastructure, e.g.
Ave. The natural geographical properties
Swinnerton
rain gardens,
including small ponds and streams in this area
Avenue
stormwater
make it suitable to expand and develop the
greenstreets, green
Greenbelt to alleviate storm water flooding for
playgrounds
residents in the area. Residents have endured
storm water flooding for too long and flooding
repairs have put unfair financial burdens on
homeowners. Specifically Manhattan Street is
storm water flood prone even with an inch or
less of rain. Complaints date back for years.
14/19
DEP
Inspect sanitary
Allocate funding for the design and construction
sewer on specific
of sanitary and storm sewers in Kreischer Street,
street segment and
Androvette Street, Winant Place, etc. Existing
repair or replace as
cesspools and septic tanks continue to fail. This
needed (Capital)
community has a mixed use zoning of
residential and manufacturing. Current
conditions, as well as current interest and plans
for the future of this area justifies the need.
Refer to 503200210C
15/19
DEP
Inspect sanitary
Allocate funding for the design and construction
sewer on specific
of sanitary and storm sewers in Sharrotts Road,
street segment and
Storer Avenue, Carlin Avenue, etc. This mixed
repair or replace as
use zoning has many thriving business entities
needed (Capital)
as well as residences. The adjacent Clay Pit
Ponds State Park Preserve offers bride paths,
hiking trails and a visitor center. This is an
overlooked older community that is forced to
depend on failing septic systems. Also, the lack
of storm water management contributes to the
premature deterioration of Arthur Kill Road.
Refer to 503200211C
16/19 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
Manila Ave at dead end (i/f/o 176 Manila Ave) has a flooding problem for years. The street termination abuts Parks Department property. Neither DOT or PARKS has a solution.
image
17/19 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
Intersection of Albourne and Lenevar Avenue do not have storm sewers or catch basins. Storm water ponds and floods at this location
image
CS DEP Inspect sanitary sewer on specific street segment and repair or replace as needed (Capital)
Fund SER200258 Sanitary & Storm Sewers West Castor Place. Homeowners have been waiting 30 years for sewers, their septic systems are failing. The lack of storm sewers prematurely deteriorates our roads and causing ponding conditions at intersections which are icy in the winter months. 503201304C
Expense Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Staten Island Community Board 3
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Zoning review is complex and we understand it is expending valuable time for City Planning examiners. However, with more and more applications that test the limits of our zoning laws we need City Planning to ensure that our zoning laws are upheld. Also, during the pre-application process, it would be constructive if City Planning and NYC Economic Development would confidentially communicate with Community Board officials to make us aware of pending applications that impact our community.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Land use planning for growth on the south shore is a top priority. Residents want to protect the character of their neighborhoods, they do not want growth without infrastrure. Rapid population growth presents many challenges. Most important is to provide infrastructure that can cope with the strain on services caused by substantial development.
Infrastructure needs to continue to meet the needs and improve living standards, not add a burden to residents.
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
1/5 DCP Other zoning and
land use requests
DCP must develop an expeditious process to map streets or surrender property for a mapped street widening. When an applicant is cooperative and agrees to part with property there should be a quick means to relinquish streets that will not delay an application. Staten Island has a major problem caused by applicant's interpretation of GCL35 and GCL36. Unmapped roads and private roads are being used to bolster density without acceptable infrastructure.
TRANSPORTATION
Staten Island Community Board 3
image
M ost Important Issue Related to Transportation and Mobility
Other
We do not have a legitimate mass transit system, therefore, Staten Islanders are motor vehicle dependent. MTA buses rely on our roads, and even commuters who use are railway via Park and Ride rely on our roads, it’s inescapable. Bridge Operation - Outerbridge Crossing is inadequate; Bus Service - Express Bus service is problematic; Ferries - commuters need a fast ferry option; Freight movement - infrastructure unable to handle truck volume; Roadway maintenance - additional funding for resurfacing to keep up with failing roads; Sidewalk and Curb
City improvement projects should incorporate curbs on all NYC property within projects; Traffic Safety - additional left turn signals.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Traffic and transportation is the 1 complaint in our community. Our increased density and commercial growth has magnified infrastructure problems. Our essential needs are road reconstruction, updated traffic signals that include left turn signals, and improved bus service on the south shore. A new Ferry service on the south shore, and expanded Park & Ride facilities would also greatly reduce our traffic congestion. Community Board 3 also
lacks sidewalks for pedestrians. Overgrowth flowing onto our sidewalks and roadways is a constant issue.
Needs for Transit Services
The South Shore of Staten Island has a desperate need for a fast ferry. South Shore residents face some of the longest commute times in our country; they should have an alternative, and not have to rely on the MTA’s inadequate express bus service, or the SIRR which is unreliable.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
1/19
DOT
Other
Fund HWR00510 for the Construction of the
Woodrow
transportation
unbuilt portion of Woodrow Road from
Road
infrastructure
Bloomingdale Road to Veteran's Road East. This
Bloomingdale
requests
is the only available east -west connection that
Road
will improve traffic congestion. Refer to
Veteran's
503201302C
Road East
3/19
DOT
Reconstruct streets
Fund reconstruction of Woodrow Road HWR-
Woodrow
890, from Rossville Avenue to Alexander
Road Rossville
Avenue. Woodrow Road is the only east-west
Avenue
arterial that has the potential for improvements
Alexander
that will mitigate traffic congestion. Woodrow
Avenue
Road had three public schools and
improvements would insure safety for students
and pedestrians. Refer to 503198901C
8/19
DOT
Repair or construct
Fund a DOT component for curbs & sidewalks
new curbs or
for all DDC construction projects. This includes
pedestrian ramps
land owned by NYC Department of Parks, NYC
Department of Environmental Protection,
Department of Citywide Administrative Services,
etc.
11/19
DOT
Reconstruct streets
Allocate funds for reconstruction and widening
Huguenot
of Huguenot Avenue between Rathbun and
Avenue
Drumgoole Road West. This is a primary north-
Rathbun
south thoroughfare connecting the Korean War
Avenue
Veterans Parkway and the West Shore
Drumgoole
Expressway and is used extensively by MTA
Road West
buses, school buses and commuters. Also, it is a
route to retail commercial districts, several
schools and churches. Refer to 503198309C
19/19
DOT
Other capital traffic
Homeowner needs a curb to stop storm water
49 Stevenson
improvements
from flooding her home. Street center crest is
Ave.
requests
higher than property, and water does not
naturally flow to the dead end. Complaints have
been previously reported to DOT and DEP.
CS
DOT
Reconstruct streets
Original Budget requests dates back to 1988. (503200501C) Arthur Kill Road is a major arterial with a combination of commercial corridors and residential homes. Traffic congestion worsens every year as our population grows. Arthur Kill Road is one lane each direction which causes major backups. Road requires widening and reconstruction including sidewalks for pedestrian safety.
Arthur Kill Road Clarke Avenue Richmond Avenue
CS
DOT
Reconstruct streets
Fund HWR-919 Reconstruction and Widening of Bloomingdale Road Refer to 503198711C
Bloomingdale Road Amboy Road Veteran's Road East
CS
DOT
Other transportation infrastructure requests
Fund the construction of the unbuilt portion of Tennyson Drive between Cleveland Avenue and Wiman Avenue. Opening this section of Tennyson Drive to connect to existing road would relieve some of the heavy trafic congestion on Hylan Blvd. Refer to 503200405C
Tennyson Drive Cleveland Avenue Wiman Avenue
CS
DOT
Other transportation infrastructure requests
Fund the construction of the unbuilt portion of Tennyson Drive at Armstrong Avenue. Opening this road would give an alternative corridor and relieve traffic congestion in the area. Refer to 503200802C
Tennyson Drive Armstrong Ave Robinson Avenue
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Staten Island Community Board 3
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Forestry services, including street tree maintenance
Most NYC Agencies Benefit from Apportioned Capital Budgets. A Committed Capital Budget Would Permit Planning for Long-Term Capital Projects, and Improvements in our Parks. Presently, the Reliance on Funds Allotted by our City Council Members and the Borough President is Inequitable. Because the present citywide system is subjective, we must rely on the generosity our City Council Members and the Borough President.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
We receive numerous complaints for various PARKS maintenance issues. Tree pruning, sidwalk lifts, PARKS property overgrowth on sidewalks and lack of sidewalks.
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
Community Boards are city agencies. And, as such should have the technological capability (intranet) to access NYC Agency department websites to enable them to research constituent requests and operate more smoothly.
Currently the only available access is the same as the general public.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation Location
2/19
DPR
Other requests for
Baseline a Capital Budget for the Department of
park, building, or
Parks & Recreation. Most NYC Agencies benefit
access
from apportioned Capital Budgets. A committed
improvements
Capital budget would permit planning for Long-
Term Capital Projects, and improvement to our
Parks. Presently the reliance of funding allotted
by our City Council Members and our Borough
President is inequitable. Because the present
citywide system is subjective, we my rely on the
generosity of our Council Members and the
Borough President Refer to 503201501C
9/19
DPR
Forestry services,
Baseline an increase in funding for the Trees &
including street tree
Sidewalks Program. Street tree maintenance
maintenance
and the Sidewalk Program is the Citys
responsibility and ensures that our trees are
healthy and pose no danger to residents. It is
also a cost-effective defense against liability
settlements due to lack of timely maintenance.
Refer to 503201503C
18/19
DPR
Reconstruct or
Allocate funding for the Design and
upgrade a building
Construction of a Restroom/Comfort Station in
in a park
Lemon Creek Park Restrooms are an essential
service and should be available in all
recreational park facilities, especially those that
accommodate children. Refer to 503200806C
CS
DPR
Other requests for
Allocate funding for the creation of an
park, building, or
engineered beach at Wolfe's Park. Multiple
access
storms and natural erosion have caused an
improvements
enormous loss of beach. This beachfront has not
been replenished, and without remediation we
are in danger of losing the beach completely.
CS
DPR
Reconstruct or
Allocate funding for the Design and
upgrade a building
Construction of a Restroom/Comfort Station in
in a park
Seaside Wildlife Nature Park. Restrooms are an
essential service and should be available in all
recreational park facilities, especially those that
accommodate children. Refer to 503201301C
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/5
OMB
Provide more
Increase the baseline budget for Community
community board
Boards so that each Community Board is
staff
properly funded to retain their own professional
services to assist in land use and development
planning. NYC agency assistance is not always
favorable or approving of planning ideologies
upheld by individual community boards.
4/5
DPR
Provide better park
Baseline funding for additional Parks personnel:
maintenance
Gardeners, Assistant Gardeners, CPWs and
PEPs. We continually add acreage and expand
our parks. We need additional personnel to
maintain grounds and continue the level of
cleanliness.
5/5
DPR
Other park
Baseline additional funding to supplement
programming
permanent playground associates. The ratio of
requests
playground associates to children is under par. It
is essential that our Parks provide a secure and
sate environment for children
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/19
DOT
Other
Fund HWR00510 for the Construction of the
Woodrow
transportation
unbuilt portion of Woodrow Road from
Road
infrastructure
Bloomingdale Road to Veteran's Road East. This
Bloomingdale
requests
is the only available east -west connection that
Road
will improve traffic congestion. Refer to
Veteran's
503201302C
Road East
2/19
DPR
Other requests for
Baseline a Capital Budget for the Department of
park, building, or
Parks & Recreation. Most NYC Agencies benefit
access
from apportioned Capital Budgets. A committed
improvements
Capital budget would permit planning for Long-
Term Capital Projects, and improvement to our
Parks. Presently the reliance of funding allotted
by our City Council Members and our Borough
President is inequitable. Because the present
citywide system is subjective, we my rely on the
generosity of our Council Members and the
Borough President Refer to 503201501C
3/19
DOT
Reconstruct streets
Fund reconstruction of Woodrow Road HWR-
Woodrow
890, from Rossville Avenue to Alexander
Road Rossville
Avenue. Woodrow Road is the only east-west
Avenue
arterial that has the potential for improvements
Alexander
that will mitigate traffic congestion. Woodrow
Avenue
Road had three public schools and
improvements would insure safety for students
and pedestrians. Refer to 503198901C
4/19
FDNY
Provide new
We request that NYC designate space for a
57 Cleveland
facilities such as a
FDNY satellite training facility to support
Place, Staten
firehouse or EMS
ongoing training for EMTs and paramedics. NYC
Island, New
station
recently acquired a 7 acre property (former St.
York, NY
John Villa Academy) in Staten Island earmarked
for the Department of Education. In addition to
being used as a training facility it would serve
the Staten Island community as classroom space
for community residents to take the Free FDNY
CPR training courses.
5/19
FDNY
Provide new
The purchase of an MARR vehicle will allow
emergency vehicles,
mutual aid rapid response in the event of a
such as fire trucks or
mutual aid activation. The FDNY holds mutual
ambulances
aid agreements in the event of any emergency,
catastrophic event or disaster. FDNY EMS
Operations serves as the primary coordinator
for all mutual aid activations provided under
agreements by Volunteer, Voluntary Hospitals,
NYS Mobilization Plan, Nassau County, New
Jersey, Suffolk County and the REMSCO Regional
Plan. The purchase of an MARR supports several
goals and objectives in the FDNY related to
enhancing regional capabilities, EMS service
tiered response, coordination, mutual aid,
public health readiness and enhancing incident
management and response capabilities.
6/19
NYPD
Add NYPD parking
The 123 Precinct on Main Street continues to
116 Main
facilities
have a serious lack of parking, both for POs,
Street, Staten
staff and visitors to Precinct. Block 8028 Lot 75
Island, New
on Main Street and Block 8028 Lot 10 are
York, NY
vacant. The owners are willing to make space
available for NYPD parking but are having
difficulty with the Department of Buildings. NYC
should intercede to fast-track an agreement.
7/19
FDNY
Provide new
Bariatic ambulances are in service in the
emergency vehicles,
boroughs of Brooklyn and Queens. Significant
such as fire trucks or
population of medical calls in addition to
ambulances
Brooklyn and Queens requiring bariatric
response and transport are in Manhattan and
the Bronx. In order to provide timely bariatric
ambulance response the FDNY needs additional
bariatric ambulances apparatus to the
boroughs of Manhattan and the Bronx.
Additional bariatric ambulances will support
FDNY goals and objectives related to challenges
bariatric patients pose for pre-hospital care and
transport directly affecting patient outcomes.
8/19
DOT
Repair or construct
Fund a DOT component for curbs & sidewalks
new curbs or
for all DDC construction projects. This includes
pedestrian ramps
land owned by NYC Department of Parks, NYC
Department of Environmental Protection,
Department of Citywide Administrative Services,
etc.
9/19
DPR
Forestry services,
Baseline an increase in funding for the Trees &
including street tree
Sidewalks Program. Street tree maintenance
maintenance
and the Sidewalk Program is the Citys
responsibility and ensures that our trees are
healthy and pose no danger to residents. It is
also a cost-effective defense against liability
settlements due to lack of timely maintenance.
Refer to 503201503C
10/19
DEP
Develop a capital
Allocate funding for a Pump Station in the
project for specific
Charleston/Richmond Valley area. With the
street segments
south shore experiencing rapid commercial
currently lacking
growth it is crucial to the future of our economic
sanitary sewers
development to have a sewer infrastructure.
Refer to 503199708C
11/19
DOT
Reconstruct streets
Allocate funds for reconstruction and widening
Huguenot
of Huguenot Avenue between Rathbun and
Avenue
Drumgoole Road West. This is a primary north-
Rathbun
south thoroughfare connecting the Korean War
Avenue
Veterans Parkway and the West Shore
Drumgoole
Expressway and is used extensively by MTA
Road West
buses, school buses and commuters. Also, it is a
route to retail commercial districts, several
schools and churches. Refer to 503198309C
12/19
SCA
Provide a new or
Allocate construction funds for a new school in
expand an existing
the Charleston Retail Center. The potential for
high school
an additional learning complex was created
when the Charleston Retail Center was
developed. The south shore needs additional
schools, especially a high school which would
benefit all of Staten Island. This would also be a
great site to develop a technical or specialized
high school to provide students with alternative
further education. Refer to 503199701C
13/19
DEP
Evaluate a public
Develop a project that will eliminate storm
Hylan Blvd
location or property
water flooding on all streets south of Hylan
Richard
for green
Blvd. between Richard Avenue and Swinnerton
Avenue
infrastructure, e.g.
Ave. The natural geographical properties
Swinnerton
rain gardens,
including small ponds and streams in this area
Avenue
stormwater
make it suitable to expand and develop the
greenstreets, green
Greenbelt to alleviate storm water flooding for
playgrounds
residents in the area. Residents have endured
storm water flooding for too long and flooding
repairs have put unfair financial burdens on
homeowners. Specifically Manhattan Street is
storm water flood prone even with an inch or
less of rain. Complaints date back for years.
14/19
DEP
Inspect sanitary
Allocate funding for the design and construction
sewer on specific
of sanitary and storm sewers in Kreischer Street,
street segment and
Androvette Street, Winant Place, etc. Existing
repair or replace as
cesspools and septic tanks continue to fail. This
needed (Capital)
community has a mixed use zoning of
residential and manufacturing. Current
conditions, as well as current interest and plans
for the future of this area justifies the need.
Refer to 503200210C
15/19
DEP
Inspect sanitary
Allocate funding for the design and construction
sewer on specific
of sanitary and storm sewers in Sharrotts Road,
street segment and
Storer Avenue, Carlin Avenue, etc. This mixed
repair or replace as
use zoning has many thriving business entities
needed (Capital)
as well as residences. The adjacent Clay Pit
Ponds State Park Preserve offers bride paths,
hiking trails and a visitor center. This is an
overlooked older community that is forced to
depend on failing septic systems. Also, the lack
of storm water management contributes to the
premature deterioration of Arthur Kill Road.
Refer to 503200211C
16/19
DEP
Inspect sanitary
Manila Ave at dead end (i/f/o 176 Manila Ave)
sewer on specific
has a flooding problem for years. The street
street segment and
termination abuts Parks Department property.
repair or replace as
Neither DOT or PARKS has a solution.
needed (Capital)
17/19
DEP
Inspect sanitary
Intersection of Albourne and Lenevar Avenue do
sewer on specific
not have storm sewers or catch basins. Storm
street segment and
water ponds and floods at this location
repair or replace as
needed (Capital)
18/19
DPR
Reconstruct or
Allocate funding for the Design and
upgrade a building
Construction of a Restroom/Comfort Station in
in a park
Lemon Creek Park Restrooms are an essential
service and should be available in all
recreational park facilities, especially those that
accommodate children. Refer to 503200806C
19/19
DOT
Other capital traffic
Homeowner needs a curb to stop storm water
49 Stevenson
improvements
from flooding her home. Street center crest is
Ave.
requests
higher than property, and water does not
naturally flow to the dead end. Complaints have
been previously reported to DOT and DEP.
CS
DEP
Inspect sanitary
Fund SER200258 Sanitary & Storm Sewers West
sewer on specific
Castor Place. Homeowners have been waiting
street segment and
30 years for sewers, their septic systems are
repair or replace as
failing. The lack of storm sewers prematurely
needed (Capital)
deteriorates our roads and causing ponding
conditions at intersections which are icy in the
winter months. 503201304C
CS
DPR
Other requests for
Allocate funding for the creation of an
park, building, or
engineered beach at Wolfe's Park. Multiple
access
storms and natural erosion have caused an
improvements
enormous loss of beach. This beachfront has not
been replenished, and without remediation we
are in danger of losing the beach completely.
CS
DOT
Reconstruct streets
Original Budget requests dates back to 1988.
Arthur Kill
(503200501C) Arthur Kill Road is a major
Road Clarke
arterial with a combination of commercial
Avenue
corridors and residential homes. Traffic
Richmond
congestion worsens every year as our
Avenue
population grows. Arthur Kill Road is one lane
each direction which causes major backups.
Road requires widening and reconstruction
including sidewalks for pedestrian safety.
CS
DPR
Reconstruct or
Allocate funding for the Design and
upgrade a building
Construction of a Restroom/Comfort Station in
in a park
Seaside Wildlife Nature Park. Restrooms are an
essential service and should be available in all
recreational park facilities, especially those that
accommodate children. Refer to 503201301C
CS
DOT
Reconstruct streets
Fund HWR-919 Reconstruction and Widening of
Bloomingdale
Bloomingdale Road Refer to 503198711C
Road Amboy
Road
Veteran's
Road East
CS
DOT
Other
Fund the construction of the unbuilt portion of
Tennyson
transportation
Tennyson Drive between Cleveland Avenue and
Drive
infrastructure
Wiman Avenue. Opening this section of
Cleveland
requests
Tennyson Drive to connect to existing road
Avenue
would relieve some of the heavy trafic
Wiman
congestion on Hylan Blvd. Refer to 503200405C
Avenue
CS
DOT
Other
Fund the construction of the unbuilt portion of
Tennyson
transportation
Tennyson Drive at Armstrong Avenue. Opening
Drive
infrastructure
this road would give an alternative corridor and
Armstrong
requests
relieve traffic congestion in the area. Refer to
Ave Robinson
503200802C
Avenue
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/5
DCP
Other zoning and
DCP must develop an expeditious process to
land use requests
map streets or surrender property for a mapped
street widening. When an applicant is
cooperative and agrees to part with property
there should be a quick means to relinquish
streets that will not delay an application. Staten
Island has a major problem caused by
applicant's interpretation of GCL35 and GCL36.
Unmapped roads and private roads are being
used to bolster density without acceptable
infrastructure.
2/5
OMB
Provide more
Increase the baseline budget for Community
community board
Boards so that each Community Board is
staff
properly funded to retain their own professional
services to assist in land use and development
planning. NYC agency assistance is not always
favorable or approving of planning ideologies
upheld by individual community boards.
3/5
DFTA
Allocate funds for
Services on the south shore are limited, expand
outreach services to
existing and support new programs to keep
homebound older
seniors in their homes.
adults and for
programs that allow
the elderly to age in
place
4/5
DPR
Provide better park
Baseline funding for additional Parks personnel:
maintenance
Gardeners, Assistant Gardeners, CPWs and
PEPs. We continually add acreage and expand
our parks. We need additional personnel to
maintain grounds and continue the level of
cleanliness.
5/5
DPR
Other park
Baseline additional funding to supplement
programming
permanent playground associates. The ratio of
requests
playground associates to children is under par. It
is essential that our Parks provide a secure and
sate environment for children

