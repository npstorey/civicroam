- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 4 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1-tD9hyZQa9A-smf9gC-lxy8jpdAwFlxi/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1-tD9hyZQa9A-smf9gC-lxy8jpdAwFlxi/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
4
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 4
image
Address: 1420 Bushwick Avenue, 370
Phone: (718) 628-8400
Email: BK04@cb.nyc.gov
Website: www.nyc.gov/brooklyncb4
Chair: Robert Camacho District Manager: Celestina León
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community District 4 includes all of the Brooklyn neighborhood of Bushwick from Broadway on the west, Flushing Avenue on the north, the Queens Borough line and Vermont Avenue on the east, as well as by Highland Avenue on the south. Bushwick is currently experiencing rapid change due to gentrification. This has led to a shift in population size, demographics, and land-use along with an ever-changing economic landscape. Most notable is the sharp increase in rents, which has made it challenging and, in some cases, impossible for many long-standing residents to remain in their apartments or within the neighborhood as a whole.
Unscrupulous and negligent property owners have taken advantage of the the current housing climate by illegally forcing residents out of apartments by any means necessary; some with the intention of selling the building and/or to raise the rents far beyond means of low and moderate income families that have considered the neighborhood their home for generations.
The senior citizen population has also experienced extreme challenges in terms of remaining in their homes or finding new places to live. Many seniors have been displaced from the neighborhood due to the limited housing options and long senior housing waiting lists. The availability of adequate living quarters for seniors has not kept pace with the development of market-rate and luxury homes in the neighborhood. Additionally, statistics have shown that major health risks remain prevalent within the neighborhood for illnesses, diseases, and chronic conditions, such as heart disease, hypertension, diabetes, asthma, and obesity. As stores begin to provide more diverse and healthier options these goods often remain out of reach for the most vulnerable populations due to the hight cost.
Certain district schools have also experienced sharp fluctuations in enrollment, as the neighborhood population changes. The neighborhood's transit and general infrastructure has become increasingly dated and ill-equipped to meet the demands of a growing population.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 4
image
The three most pressing issues facing this Community Board are:
Affordable housing
The construction boom and desirability of the neighborhood's location near transit rich options has ultimately led to a sharp decline in affordability. Area residents and families are faced with doubling up to cover the cost of rental apartments and there is a noticeable increase in transient, apartment-sharing residences. Another relevant issue is the demolition of potential landmark properties. These properties typically sit on larger than average-sized lots and are being purchased for redevelopment to make way for new and taller buildings with smaller units that are typically unaffordable, as well. Affordable housing remains one of the greatest needs of the community. Only a small number of buildings in the district are rent-stabilized and are subject to aggressive harassment tactics, as some landlords attempt to achieve vacancy decontrol. Additionally, the current Area Median Income (AMI) far exceeds the average income of Bushwick households, which encompass a range of extremely low to moderate income. The word affordable has become a trigger within the community, resulting often in the response for whom?
Unless developers take a community approach to their projects, their buildings often exclude low and extremely low-income families in Bushwick. All types of households continue to pay over fifty percent of their income in rent.
Land use trends (zoning, development, neighborhood preservation, etc.)
Since 2013, when the board's Housing and Land Use Committee drafted a letter to local elected officials, a comprehensive and collaborative effort has been underway to simultaneously address neighborhood preservation and the creation of affordable housing along with various community needs. This work and the resulting recommendations have become known as the Bushwick Community Plan. The process, a partnership between city agencies, local stakeholders, and residents, released their recommendations to the public in September 2018 after experiencing initial community push back during one of the community board's public hearings. The main source of contention is centered around land use and the uncertainty of the results of the primarily community-driven process. Furthermore, the majority of Bushwick remains blanketed by the R6 zoning designation, which allows developers to construct buildings and other edifices as-of-right that are typically non-conforming in height and non- contextual to other buildings in the area. The rents in these buildings are typically priced at the market rate, even when the developer seeks city subsidies due to broad regulations. Most of the new housing created in the neighborhood is out of reach for longtime residents due to extraordinarily rents and or units that don't meet their household's needs. These pressures have also spread to long-time and new commercial establishments that are more quickly priced out of their locations. Commercial rents have quickly become out of reach for newly established or small-scale business owners. Vacant storefronts are a common sight, as property owners typically opt to wait for higher paying tenants. The legal conversion of manufacturing to commercial continues to change the neighborhood’s landscape leading to new service challenges, as the properties were originally designed for manufacturing purposes. These challenges are compounded by an evolving culture that often adversely impacts the quality of life in the neighboring residential areas.
Street conditions (roadway maintenance)
As Bushwick evolves, there is an even greater need for investment in the preexisting infrastructure. Heavily-used transit corridors throughout the district, such as Broadway, Myrtle Avenue, and Wyckoff Avenue, should be examples of 21st modernization however, the roadbeds remain in poor condition, there are inadequate traffic safety features, and ultimately, in appearance, they remain a reminder of historic disenfranchisement of the neighborhood.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 4
image
M ost Important Issue Related to Health Care and Human Services
Chronic diseases (diabetes, heart disease, etc.)
Awareness of and access to quality medical services is another key issue within the neighborhood. Based on the recent Community Health Profile, Bushwick residents are more at-risk of developing chronic conditions, such as diabetes, asthma, and high blood pressure over the course of their lifetime than in other areas in the city. The majority of which are easily preventable by leading an active lifestyle and incorporating fresh, nutrient dense food into a regular diet. Many residents resort to visiting local hospitals for basic care and services due to various barriers and limited access to primary care. This often leads to longer wait times and costly medical bills. Non-English speakers also face barriers to communication, which can lead to further complications that are entirely avoidable with culturally sensitive translation services at the necessary capacity.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Community Board 4 is grateful for the work and support of our partners at Wyckoff Heights Medical Center and Woodhull Hospital, as well as, the local community based organizations and other service providers taking the lead to address systemic health disparities. It remains vital to continue and enhance the education/outreach efforts that help connect community members to the resources they need to lead healthy lives. Additionally, an increase in neighborhood construction in response to aging infrastructure and new housing developments have further exacerbated issues with rodents. The staging conditions at these locations and sites have become havens for the rodent population and require a multi-agency approach to curb and address breeding grounds before they impact neighboring properties and the general public.
Needs for Older NYs
Community Board 4 has historically prioritized requests for funding services for seniors. As the general population lives longer additional services are needed to meet the increasing population and ever-changing needs. Many are faced with declining mental and physical health, resulting from, but not limited to loneliness, abandonment, and other health-care issues. Seniors property owners are often the most vulnerable when it comes to issues such as deed fraud, home repairs, and maintenance services, as some do not have access to professional advocates and rely on a fixed income. Fortunately, programming and initiatives for the issues described above exist and should regularly promoted through strategic partnerships with facilities for seniors and other local community partners.
Needs for Homeless
Households across the city have been affected by the housing crisis. Longtime Bushwick residents, in particular, continue to face the consistent pressures of rent increases and poor building maintenance. A record number of families are now living in city shelters and often end up far from home. Single adults are faced with the harrowing choice of street homeless or an uncertain shelter environment that may worsen their overall circumstances. Regular street outreach and strategic community collaborations are necessary to reach homeless and at-risk populations.
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
6/24
DOHMH
Other animal and
Enhance outreach and conduct public education
pest control
workshops in partnership with the Department
requests
of Health for neighborhood residents,
businesses, and other stakeholders to combat
the rodent issue in Bushwick.
7/24
DOHMH
Other programs to
The Bushwick Neighborhood Health Action
335 Central
address public
Action formerly know as the Bushwick District
Avenue,
health issues
Public Health Office remains a valuable asset
Brooklyn,
requests
with considerable reach and influence on the
New York, NY
culture of health in Bushwick. To date, the
center and the various programs appear to lack
a clear and cohesive role in the community and
would benefit from a comprehensive outreach
plan, marketing, and opportunities for
community engagement around the future of
the site.
14/24
DHS
Expand street
Increase street outreach and support
outreach
community partnerships at intersections that
regularly draw a large homeless and/or at-risk
populations, such as, but not limited to the
Myrtle-Broadway intersection.
20/24
DFTA
Enhance
Implement and enhance diverse educational
educational and
and recreational programming for seniors
recreational
including the arts, technology, and inter-
programs
generational themes
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 4
image
M ost Important Issue Related to Youth, Education and Child Welfare
Youth workforce development and summer youth employment
As the modern day workforce continues to evolve youth need ample opportunity to prepare for their future. Access to prominent industries, such as technology, entertainment, and entrepreneurship should be standardized.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Community Board 4 continues to work with Community Education Council 32 and the leadership of all our local schools, learning centers, and community institutions that provide educational services to advocate for the needs of the community. We are appreciative of all efforts to invest in the renovation and upgrading of schools. Given the evolving educational atmosphere and society at large, all students and youth in Bushwick need equitable access to quality learning equipment and materials necessary for them to build the skills they need to thrive in the modern world.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
18/24 DYCD Provide, expand, or
enhance after school programs for elementary school students (grades K- 5)
Additional programming for this population is required, especially for youth enrolled in public schools. Parents have limited options within the district and are often drawn to schools that offer a full day of learning and after school programming.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 4
image
M ost Important Issue Related to Public Safety and Emergency Services
Police-community relations
As Bushwick continues to experience rapid and multivariate change due to gentrification, there is a need for adaptable police-community relations. Bushwick stakeholders have worked across generations to strengthen and improve the relationships with the 83rd Precinct. With an increasing volume of service complaints despite significant decrease in major crimes, greater transparency, efficiency, and visibility are need to meet the needs of the various communities that constitute the entirety of Bushwick.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Community Board 4 continues to work with the 83rd Precinct, Community and Clergy Councils, and residents to help address the safety needs of the neighborhood. Recent statistics show crime as a whole is down city-wide and within Bushwick however, it still remains a stark reality of city life. We look forward to advocating in partnership for the resources needed to address the most common public safety issues in the neighborhood, such as burglaries and grand larceny.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
15/15 NYPD Other NYPD
facilities and equipment requests (Capital)
Despite historic lows in crime in Bushwick, statistics show increases in grand larcenies and burglaries in addition to a high volume of quality of life concerns. A mobile command center would serve as both an additional vantage point and a deterrent for areas with chronic issues. Accompanied with outreach, a center will also simultaneously strengthen NYPD visibility and community relations.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/24
NYPD
Assign additional
Increase Manpower at the 83rd Precinct, Public
uniformed officers
Service Area 3, and Transit District 33.
Additional patrols and manpower from the
Academy are needed in Bushwick.
8/24
FDNY
Other FDNY facilities
Provide equipment needed by FDNY personnel
and equipment
including, but not limited to, generators,
requests (Expense)
printers for the firehouses, Level A Hazmat Suits,
and new defibrillator batteries.
17/24
FDNY
Provide more
A staff increase in Fire Marshals will improve
firefighters or EMS
their ability to investigate and respond to fires,
workers
as well as, meet the growing need for
inspections of new businesses; establishments
that plan to serve liquor in particular.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 4
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
Inconsistent garbage disposal practices and illegal dumping continue to plague the neighborhood. This impacts the not only quality of life, but also general public safety. Chronic illegal dumping conditions turn into go-to spots for dumping and provide breeding grounds for rodents/other small animals. The Department of Sanitation Brooklyn 4 Garage remains an excellent partner in responding to these and all sanitation issues, as they arise, with the intention of curbing their frequency and the goal of prevention. Additionally, educational outreach is needed within the district to prepare residents for various DSNY initiatives, such as the Curbside Organics Collection program.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
Historically, neglected vacant lots full of garbage and abandoned vehicles were a major issue in Bushwick and remain an issue in the present, although to a lesser degree. During the 70s and 80s, the board’s Sanitation Committee was one of the three largest committees. Presently, there are fewer lots however, garbage and debris from abandoned properties, new construction, and illegal dumping have become a regular and unsightly occurrence. All residents in proximity to the sites typically experience a higher amount of related quality of life and public safety issues. Community Board 4 is grateful for the support and efficiency of the local Brooklyn 4 Garage in addressing these issues.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
19/24
DSNY
Increase
The "Clean Up After Dog" Law needs additional
enforcement of
strategic enforcement via working with local
canine waste laws
stakeholders, residents, and other property
owners.
21/24
DEP
Clean catch basins
Hire additional personnel for the repair and
maintenance of catch basins and rain gardens.
The increase in neighborhood population and
construction has burdened the current sewer
system.
23/24
DSNY
Provide more
Reinstate 5 day per week garbage collection at
frequent garbage or
neighborhood institutions and community
recycling pick-up for
facilities, including, but not limited to schools,
schools and
early learn centers/pre-K programs, and senior
institutions
citizen centers. All of the above offer daily meals
for breakfast & lunch, generating a high volume
of garbage in designated locations that
contribute to the low scorecard rating.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 4
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
Affordable housing remains one of the greatest needs of the community. Only a small number of buildings in the district are rent-stabilized and are subject to aggressive harassment tactics, as some landlords attempt to achieve vacancy decontrol. Additionally, the current Area Median Income (AMI) far exceeds the average income of Bushwick households, which encompass a range of extremely low to moderate income. The word affordable has become a trigger within the community, resulting often in the response for whom? Unless developers take a community approach to their projects, their buildings often exclude low and extremely low-income families in Bushwick. All types of households continue to pay over fifty percent of their income in rent.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/15
HPD
Provide more
Strongly encourage private developers to
housing for
construct deeply affordable housing that meets
extremely low and
the needs of the community, as well as, create
low income
one hundred percent affordable housing when
households
feasible and especially for projects on city-
owned land. Currently, the majority of new
rental apartments are not affordable for
residents. This includes the majority of the
housing that has been labelled affordable based
on the Area Median Income (AMI). Many
neighborhood residents continue to struggle in
their search to find housing they can afford.
2/15
HPD
Provide more
Truly affordable housing for all remains a city-
housing for special
wide crisis however, seniors and other at-risk
needs households,
populations are among the most vulnerable.
such as the formerly
Given the long waiting lists and general
homeless
shortage in senior and supportive housing,
increased development and/or inclusion of
these projects should be encouraged along with
with feedback from the Community Board.
14/15
EDC
Make infrastructure
The primary commercial corridors in Bushwick
investments that
include Broadway, Myrtle, Knickerbocker
will support growth
Avenue, and Wyckoff Avenue. Given the high
in local business
volume of traffic on these avenues, investment
districts
in the infrastructure will improve overall transit
safety, the quality of life for all residents and
visitors, and provide a solid foundation to
support a vibrant and dynamic commercial
sector.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
3/24 DCP Other zoning and
land use requests
As emphasized by the majority in attendance during the public scoping meeting in June 2019, the Bushwick Community Plan should be analyzed as an alternative, as City Planning prepares the Environmental Impact Study for the Bushwick rezoning.
image
4/24
DOB
Expand code
Provide funding for additional building
enforcement
inspectors to respond to code violations. A high
volume of building construction and alterations
occurs throughout the district in many cases
illegally/without the proper permits. Additional
inspectors will assist in addressing this issue.
5/24
NYCHA
Expand programs
Hire code enforcement inspectors. Additional
for housing
Inspectors are needed to respond to a high
inspections to
volume of complaints within the district.
correct code
Inspectors should be trained to recognize
violations
chronic building negligence.
10/24
EDC
Expand programs
Establish an incubator within the district to spur
for certain
economic growth and support current/emerging
industries, e.g.
entrepreneurs.
fashion, film,
advanced and food
manufacturing, life
sciences and
healthcare
15/24
EDC
Expand programs to
Bushwick has a rich culture that includes small
support local
business owners and entrepreneurs. The
businesses and
demand for the services have grown, as the
entrepreneurs
population continues to increase. Workshops,
small grants, and other services/opportunities
are in higher demand.
16/24
SBS
Support merchant
Recently, joint efforts have been taken to
Broadway
organizing
organize the merchants along the Broadway
Flushing
corridor. In these early stages, support and
Avenue
resources are critical to establishing a
Eastern
foundation.
Parkway
24/24
EDC
Expand graffiti
Expand the graffiti removal program to improve
removal services on
the response time to requests for removal.
private sites
Currently, there are a limited amount of
programs and supplies within the community
that provide this service. Often this results in
longer than average wait times to resolve the
issue, which generally leads to worsening
conditions.
TRANSPORTATION
Brooklyn Community Board 4
image
M ost Important Issue Related to Transportation and Mobility
Traffic safety
Initiatives, such as Vision Zero, have served as a conduit to address some of Bushwick’s transit infrastructure and safety needs. This was accomplished through much needed safety upgrades and the implementation of other strategic traffic calming measures, such as the Myrtle-Wyckoff pedestrian plaza. Additional studies are needed to address aging infrastructure and safety issues on the busiest corridors in the neighborhood, including Broadway, Bushwick Avenue, Knickerbocker Avenue, Myrtle Avenue, and Wyckoff Avenue. Those corridors experience a high volume of evolving mixed-use traffic (pedestrian, cyclist, vehicular, etc.). They remain in great need of additional investment, ranging from resurfacing to the implementation of traffic calming measures.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/15
DOT
Reconstruct streets
Broadway was once the major commercial
Broadway
corridor drawing consumers from all over
Flushing
Brooklyn. In its current state, Broadway is far
Avenue
from the thriving strip of businesses it was in
Eastern
the past. Reconstructing Broadway from
Parkway
Flushing Avenue to Eastern Parkway is the first
step in investing in the economic future of the
neighborhood. The roadbed of this heavily
traveled commercial strip is in a deplorable
state. The last time it was repaved was the
Broadway Reconstruction Project of 1986.
Recent tragic incidents illustrate the need for an
enhanced roadway, lighting, and other transit
safety features.
6/15
DOT
Repair or provide
Lighting is needed throughout the district,
new street lights
especially under the NYCT MTA Elevated
Structures. High density lighting will provide for
better-lit and safer streets during the night
hours.
8/15
DOT
Reconstruct streets
Wyckoff Avenue is one of the major commercial
Wyckoff
and transit corridors in the neighborhood. The
Avenue
high volume of all types of traffic, including
Flushing
delivery trucks and EMS vehicles, leads to rapid
Avenue
erosion of the streets and easily congests traffic.
Cooper Street
The reconstruction of Wyckoff Avenue is an
important and capital project for safety of the
community. This avenue is also shared with our
neighbors in Queens, which would ideally make
capital investment more feasible, given the
potential for partnership on the project.
10/15
NYCTA
Repair or upgrade
Renovate the DeKalb Avenue Station on the
subway stations or
Canarsie L Line to include an elevator. The
other transit
station has experienced an increase in
infrastructure
commuter volume over the past several years
and is the closest train station to Wyckoff
Heights Medical Center. Renovations are also
needed to address flooding when it rains. The
installation of an elevator would improve the
overall function of this station and greatly
benefit the surrounding communities that rely
on the healthcare services in the area.
11/15
NYCTA
Repair or upgrade
Renovate the Wilson Avenue Station on the L
subway stations or
Line to include ADA compliance on the Canarsie
other transit
bound train, cameras, and additional lighting.
infrastructure
The partial renovation of this station has left
residents in need of Canarsie bound service at a
disadvantage.
13/15
DOT
Reconstruct streets
Myrtle Avenue from Broadway to Wyckoff
Myrtle
Avenue is another major commercial corridor
Avenue
that directly links Queens to Brooklyn. The
Broadway
general traffic infrastructure and equipment is
Wyckoff
outdated and unreliable. The avenue is also
Avenue
notoriously difficult to traverse, given the
overhead elevated M train line. The two-way
bus traffic also contributes to the potential
dangers of utilizing the corridor. Myrtle Avenue
holds great potential to serve as a
transportation conduit for the neighborhood
and surrounding areas. Prioritizing investment
will better prepare the neighborhood for the
future.
CS
DOT
Reconstruct streets
Complete the repair of the following roadbeds
Weirfield
on the HWK876 project: Weirfield Street
Street
between Wyckoff & Irving Avenues.
Wyckoff
Avenue Irving
Avenue
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
13/24
DOT
Other expense
Increase Contracts for Street Light Repairs. The
traffic
Community Board 4 area experiences significant
improvements
delays in response time to light malfunctions
requests
and requests for repair.The average wait has
increased to 15 days, which can lead to further
safety risks and issues.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 4
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
Our parks are centers of interaction with neighbors and nature. They are also conduits for a variety of activities and opportunities within the neighborhood for individuals and families. At the most basic level they help purify the air and surrounding environment. It is for those reasons and beyond, that it remains vital to prioritize their upkeep and necessary renovations. In the past several years, complaints have been made in reference to an increasing number of homeless individuals living in the parks, visible drug paraphernalia in bushes and play areas, and other general public safety issues. In consistent park maintenance and public safety issues remain common complaints. We are thankful for the partnership and support from the Brooklyn Borough Commissioner’s office and the local park manager in addressing situations as they arise.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
Bushwick is known for its rich cultural diversity and arts community. Over the years, the cultures and artistic expression have changed with time, but the spirit of creativity remains and has contributed to the large increase in new residents and visitors from all over the world. Aside from the recent increase in popularity of the neighborhood, much work is needed to connect youth, seniors, and local stakeholders to opportunities for enrichment and skills building. The arts remain a conduit to many pathways, including but not limited to, employment, outlets for expression, and strengthening community ties.
Needs for Library Services
No comments
Needs for Community Boards
Community Boards are tasked with monitoring and informing city agencies and elected officials about district needs. In order to build on this work, additional support is needed as it relates to technology. The development of a Constituent Relationship Management (CRM) software for community boards will potentially provide a comprehensive tool to streamline the work of the board. Additionally, boards have limited personnel services funding, which hinders their ability to pursue new hires that are needed to provide additional support to better serve an evolving population.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
4/15
DPR
Reconstruct or
The comfort station at Maria Hernandez Park is
upgrade a building
in serious need of an upgrade. There are
in a park
frequent complaints about the lack of regular
maintenance, pooling, and broken restroom
equipment from community members,
especially during the summertime. Given the
high volume of visitors and recreational
opportunities in general, a renovated comfort
station is needed to better accommodate the
public.
5/15
DPR
Forestry services,
Expand Contracts for Tree Pruning. The wait-
including street tree
time is extremely long for tree pruning as
maintenance
contracts do not accommodate the number of
requests.
7/15
BPL
Create a new, or
The Dekalb library is in need of a full major
790 Bushwick
renovate or upgrade
renovation, including the basement,
Avenue
an existing public
interior/exterior, window restoration, and
library
safety/security enhancements.
9/15
DPR
Provide a new, or
Add a comfort station to Irving Square Park.
new expansion to, a
building in a park
CS
BPL
Create a new, or
BPL - The Brooklyn Public Library Washington
360 Irving
renovate or upgrade
Irving is in need of an interior renovation to
Avenue,
an existing public
better accommodate patrons.
Brooklyn,
library
New York, NY
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/24
DPR
Enhance park safety
Hire Additional Park Enforcement Patrol (PEP)
through more
Staff. District parks are often vandalized; Gang
security staff (police
activity is present. PEP officers will provided a
or parks
sense of security.
enforcement)
11/24
OMB
Provide more
Increase the baseline budget to allow for
community board
additional part-time or a full-time hire to
staff
support the board and help manage the work
load.
12/24 DCLA Provide more public
art
As Bushwick continues to change at an accelerated pace it is important to honor and recognize the culture that helped create the neighborhood. Public art, especially as it relates to long-standing local artists and other aspects of the neighborhood's history, is one way to accomplish this. These kinds of projects should be implemented via partnership with community-based organizations, schools, and general community participation.
image
22/24 DPR Improve trash
removal and cleanliness
The larger parks in the neighborhood, such as Maria Hernandez Park and Irving Square Park have a high volume of visitors throughout the year, especially during the warmer weather months. Additional garbage collection is need to prevent the encouragement of illegal dumping and to keep the park entrances clear/clean.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
12/15
Other
Other capital budget
DOE - Establish additional Early Learn Centers
request
and Pre-K for All programs within the
neighborhood. Consider existing childcare
centers as potential host sites. Capital funding is
needed for renovation and/or new construction
of facilities capable of responding to this
request. As the population within the district
continues to grow, planning for childcare
facilities to meet those needs is essential.
CS
Other
Other capital budget
EDC - Major commercial corridors, such as
Broadway
request
Broadway, Myrtle, and Wyckoff are in need of
Flushing
investment to revitalize and restore them to
Avenue
their optimal capacity. This should be
Eastern
accomplished through joint efforts between
Parkway
local merchants associations, general
stakeholders, and the residents that are in most
cases the primary consumers for the businesses.
Improvements can include funding for signage,
street furniture, and other design elements.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
9/24
DOITT
Information technology goods and services
Collaboratively develop a CRM software tool to streamline community board work flow.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/15
HPD
Provide more
Strongly encourage private developers to
housing for
construct deeply affordable housing that meets
extremely low and
the needs of the community, as well as, create
low income
one hundred percent affordable housing when
households
feasible and especially for projects on city-
owned land. Currently, the majority of new
rental apartments are not affordable for
residents. This includes the majority of the
housing that has been labelled affordable based
on the Area Median Income (AMI). Many
neighborhood residents continue to struggle in
their search to find housing they can afford.
2/15
HPD
Provide more
Truly affordable housing for all remains a city-
housing for special
wide crisis however, seniors and other at-risk
needs households,
populations are among the most vulnerable.
such as the formerly
Given the long waiting lists and general
homeless
shortage in senior and supportive housing,
increased development and/or inclusion of
these projects should be encouraged along with
with feedback from the Community Board.
3/15
DOT
Reconstruct streets
Broadway was once the major commercial
Broadway
corridor drawing consumers from all over
Flushing
Brooklyn. In its current state, Broadway is far
Avenue
from the thriving strip of businesses it was in
Eastern
the past. Reconstructing Broadway from
Parkway
Flushing Avenue to Eastern Parkway is the first
step in investing in the economic future of the
neighborhood. The roadbed of this heavily
traveled commercial strip is in a deplorable
state. The last time it was repaved was the
Broadway Reconstruction Project of 1986.
Recent tragic incidents illustrate the need for an
enhanced roadway, lighting, and other transit
safety features.
4/15
DPR
Reconstruct or
The comfort station at Maria Hernandez Park is
upgrade a building
in serious need of an upgrade. There are
in a park
frequent complaints about the lack of regular
maintenance, pooling, and broken restroom
equipment from community members,
especially during the summertime. Given the
high volume of visitors and recreational
opportunities in general, a renovated comfort
station is needed to better accommodate the
public.
5/15
DPR
Forestry services,
Expand Contracts for Tree Pruning. The wait-
including street tree
time is extremely long for tree pruning as
maintenance
contracts do not accommodate the number of
requests.
6/15
DOT
Repair or provide
Lighting is needed throughout the district,
new street lights
especially under the NYCT MTA Elevated
Structures. High density lighting will provide for
better-lit and safer streets during the night
hours.
7/15
BPL
Create a new, or
The Dekalb library is in need of a full major
790 Bushwick
renovate or upgrade
renovation, including the basement,
Avenue
an existing public
interior/exterior, window restoration, and
library
safety/security enhancements.
8/15
DOT
Reconstruct streets
Wyckoff Avenue is one of the major commercial
Wyckoff
and transit corridors in the neighborhood. The
Avenue
high volume of all types of traffic, including
Flushing
delivery trucks and EMS vehicles, leads to rapid
Avenue
erosion of the streets and easily congests traffic.
Cooper Street
The reconstruction of Wyckoff Avenue is an
important and capital project for safety of the
community. This avenue is also shared with our
neighbors in Queens, which would ideally make
capital investment more feasible, given the
potential for partnership on the project.
9/15
DPR
Provide a new, or
Add a comfort station to Irving Square Park.
new expansion to, a
building in a park
10/15
NYCTA
Repair or upgrade
Renovate the DeKalb Avenue Station on the
subway stations or
Canarsie L Line to include an elevator. The
other transit
station has experienced an increase in
infrastructure
commuter volume over the past several years
and is the closest train station to Wyckoff
Heights Medical Center. Renovations are also
needed to address flooding when it rains. The
installation of an elevator would improve the
overall function of this station and greatly
benefit the surrounding communities that rely
on the healthcare services in the area.
11/15
NYCTA
Repair or upgrade
Renovate the Wilson Avenue Station on the L
subway stations or
Line to include ADA compliance on the Canarsie
other transit
bound train, cameras, and additional lighting.
infrastructure
The partial renovation of this station has left
residents in need of Canarsie bound service at a
disadvantage.
12/15
Other
Other capital budget
DOE - Establish additional Early Learn Centers
request
and Pre-K for All programs within the
neighborhood. Consider existing childcare
centers as potential host sites. Capital funding is
needed for renovation and/or new construction
of facilities capable of responding to this
request. As the population within the district
continues to grow, planning for childcare
facilities to meet those needs is essential.
13/15
DOT
Reconstruct streets
Myrtle Avenue from Broadway to Wyckoff
Myrtle
Avenue is another major commercial corridor
Avenue
that directly links Queens to Brooklyn. The
Broadway
general traffic infrastructure and equipment is
Wyckoff
outdated and unreliable. The avenue is also
Avenue
notoriously difficult to traverse, given the
overhead elevated M train line. The two-way
bus traffic also contributes to the potential
dangers of utilizing the corridor. Myrtle Avenue
holds great potential to serve as a
transportation conduit for the neighborhood
and surrounding areas. Prioritizing investment
will better prepare the neighborhood for the
future.
14/15
EDC
Make infrastructure
The primary commercial corridors in Bushwick
investments that
include Broadway, Myrtle, Knickerbocker
will support growth
Avenue, and Wyckoff Avenue. Given the high
in local business
volume of traffic on these avenues, investment
districts
in the infrastructure will improve overall transit
safety, the quality of life for all residents and
visitors, and provide a solid foundation to
support a vibrant and dynamic commercial
sector.
15/15
NYPD
Other NYPD
Despite historic lows in crime in Bushwick,
facilities and
statistics show increases in grand larcenies and
equipment requests
burglaries in addition to a high volume of
(Capital)
quality of life concerns. A mobile command
center would serve as both an additional
vantage point and a deterrent for areas with
chronic issues. Accompanied with outreach, a
center will also simultaneously strengthen NYPD
visibility and community relations.
CS
BPL
Create a new, or
BPL - The Brooklyn Public Library Washington
360 Irving
renovate or upgrade
Irving is in need of an interior renovation to
Avenue,
an existing public
better accommodate patrons.
Brooklyn,
library
New York, NY
CS
Other
Other capital budget
EDC - Major commercial corridors, such as
Broadway
request
Broadway, Myrtle, and Wyckoff are in need of
Flushing
investment to revitalize and restore them to
Avenue
their optimal capacity. This should be
Eastern
accomplished through joint efforts between
Parkway
local merchants associations, general
stakeholders, and the residents that are in most
cases the primary consumers for the businesses.
Improvements can include funding for signage,
street furniture, and other design elements.
CS
DOT
Reconstruct streets
Complete the repair of the following roadbeds
Weirfield
on the HWK876 project: Weirfield Street
Street
between Wyckoff & Irving Avenues.
Wyckoff
Avenue Irving
Avenue
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/24
NYPD
Assign additional
Increase Manpower at the 83rd Precinct, Public
uniformed officers
Service Area 3, and Transit District 33.
Additional patrols and manpower from the
Academy are needed in Bushwick.
2/24
DPR
Enhance park safety
Hire Additional Park Enforcement Patrol (PEP)
through more
Staff. District parks are often vandalized; Gang
security staff (police
activity is present. PEP officers will provided a
or parks
sense of security.
enforcement)
3/24
DCP
Other zoning and
As emphasized by the majority in attendance
land use requests
during the public scoping meeting in June 2019,
the Bushwick Community Plan should be
analyzed as an alternative, as City Planning
prepares the Environmental Impact Study for
the Bushwick rezoning.
4/24
DOB
Expand code
Provide funding for additional building
enforcement
inspectors to respond to code violations. A high
volume of building construction and alterations
occurs throughout the district in many cases
illegally/without the proper permits. Additional
inspectors will assist in addressing this issue.
5/24
NYCHA
Expand programs
Hire code enforcement inspectors. Additional
for housing
Inspectors are needed to respond to a high
inspections to
volume of complaints within the district.
correct code
Inspectors should be trained to recognize
violations
chronic building negligence.
6/24
DOHMH
Other animal and
Enhance outreach and conduct public education
pest control
workshops in partnership with the Department
requests
of Health for neighborhood residents,
businesses, and other stakeholders to combat
the rodent issue in Bushwick.
7/24
DOHMH
Other programs to
The Bushwick Neighborhood Health Action
335 Central
address public
Action formerly know as the Bushwick District
Avenue,
health issues
Public Health Office remains a valuable asset
Brooklyn,
requests
with considerable reach and influence on the
New York, NY
culture of health in Bushwick. To date, the
center and the various programs appear to lack
a clear and cohesive role in the community and
would benefit from a comprehensive outreach
plan, marketing, and opportunities for
community engagement around the future of
the site.
8/24
FDNY
Other FDNY facilities
Provide equipment needed by FDNY personnel
and equipment
including, but not limited to, generators,
requests (Expense)
printers for the firehouses, Level A Hazmat Suits,
and new defibrillator batteries.
9/24
DOITT
Information
Collaboratively develop a CRM software tool to
technology goods
streamline community board work flow.
and services
10/24
EDC
Expand programs
Establish an incubator within the district to spur
for certain
economic growth and support current/emerging
industries, e.g.
entrepreneurs.
fashion, film,
advanced and food
manufacturing, life
sciences and
healthcare
11/24
OMB
Provide more
Increase the baseline budget to allow for
community board
additional part-time or a full-time hire to
staff
support the board and help manage the work
load.
12/24
DCLA
Provide more public
As Bushwick continues to change at an
art
accelerated pace it is important to honor and
recognize the culture that helped create the
neighborhood. Public art, especially as it relates
to long-standing local artists and other aspects
of the neighborhood's history, is one way to
accomplish this. These kinds of projects should
be implemented via partnership with
community-based organizations, schools, and
general community participation.
13/24
DOT
Other expense
Increase Contracts for Street Light Repairs. The
traffic
Community Board 4 area experiences significant
improvements
delays in response time to light malfunctions
requests
and requests for repair.The average wait has
increased to 15 days, which can lead to further
safety risks and issues.
14/24
DHS
Expand street
Increase street outreach and support
outreach
community partnerships at intersections that
regularly draw a large homeless and/or at-risk
populations, such as, but not limited to the
Myrtle-Broadway intersection.
15/24
EDC
Expand programs to
Bushwick has a rich culture that includes small
support local
business owners and entrepreneurs. The
businesses and
demand for the services have grown, as the
entrepreneurs
population continues to increase. Workshops,
small grants, and other services/opportunities
are in higher demand.
16/24
SBS
Support merchant
Recently, joint efforts have been taken to
Broadway
organizing
organize the merchants along the Broadway
Flushing
corridor. In these early stages, support and
Avenue
resources are critical to establishing a
Eastern
foundation.
Parkway
17/24
FDNY
Provide more
A staff increase in Fire Marshals will improve
firefighters or EMS
their ability to investigate and respond to fires,
workers
as well as, meet the growing need for
inspections of new businesses; establishments
that plan to serve liquor in particular.
18/24
DYCD
Provide, expand, or
Additional programming for this population is
enhance after
required, especially for youth enrolled in public
school programs for
schools. Parents have limited options within the
elementary school
district and are often drawn to schools that
students (grades K-
offer a full day of learning and after school
5)
programming.
19/24
DSNY
Increase
The "Clean Up After Dog" Law needs additional
enforcement of
strategic enforcement via working with local
canine waste laws
stakeholders, residents, and other property
owners.
20/24
DFTA
Enhance
Implement and enhance diverse educational
educational and
and recreational programming for seniors
recreational
including the arts, technology, and inter-
programs
generational themes
21/24
DEP
Clean catch basins
Hire additional personnel for the repair and
maintenance of catch basins and rain gardens.
The increase in neighborhood population and
construction has burdened the current sewer
system.
22/24 DPR Improve trash
removal and cleanliness
The larger parks in the neighborhood, such as Maria Hernandez Park and Irving Square Park have a high volume of visitors throughout the year, especially during the warmer weather months. Additional garbage collection is need to prevent the encouragement of illegal dumping and to keep the park entrances clear/clean.
image
23/24 DSNY Provide more
frequent garbage or recycling pick-up for schools and institutions
Reinstate 5 day per week garbage collection at neighborhood institutions and community facilities, including, but not limited to schools, early learn centers/pre-K programs, and senior citizen centers. All of the above offer daily meals for breakfast & lunch, generating a high volume of garbage in designated locations that contribute to the low scorecard rating.
image
24/24 EDC Expand graffiti
removal services on private sites
Expand the graffiti removal program to improve the response time to requests for removal.
Currently, there are a limited amount of programs and supplies within the community that provide this service. Often this results in longer than average wait times to resolve the issue, which generally leads to worsening conditions.
image

