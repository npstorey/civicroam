- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 6 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1qyJSbnUSJQzZoTmMLVaQDuMYG2L2SXSh/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1qyJSbnUSJQzZoTmMLVaQDuMYG2L2SXSh/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
6
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 6
image
Address: 104-01 Metropolitan Avenue Phone: (718) 263-9250
Email: qn06@cb.nyc.gov
Website: www.nyc.gov/queenscb6
Chair: Alexa Weitzman District Manager: Frank P. Gulluscio
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
The 1969 Plan for New York Cities Community Boards describes Community Board 6 as “fine private homes on tree lined streets, attractive garden apartments, and towering modern apartment houses, including condos and co-op’s, as well as older rent-controlled apartment houses that make this district a most desirable place to live”. Community Board 6 is an active and welcoming community with a dynamic history, an abundance of greenery, and distinctive landscaping. There is a small town feeling throughout the area, which includes street fairs, jazz concerts, cultural events, and a Green Market on weekends. However, the quality of life issues of the district have changed. The swift increase in population has taxed the capacity of some public facilities. The schools are overcrowded, the subway is jammed during rush hours, and land use matters are becoming a major concern in Community Board 6. In spite of some problems the district provides a good living environment and prosperous commercial enterprises. However, both population and commercial growth have strained many components of the district’s physical and social infrastructure…we have most certainly changed. Community Board 6 requests the following: 1. Adequate staffing in the 112th Precinct. 2. Protect our established low density residential areas from over building. 3. Discourage intensive and or inappropriate commercial development. 4. Maintain and improve municipal services and infrastructure with regard to sewers and flooding issues in the district. 5. Encourage the integration of new citizens into the society and institutional fabric of our community. 6. Promote stable, long term residential tenure. 7. See continued enhancement of health care in the district, especially with respect to emergency room and hospital bed availability. 8. Maintain schools throughout district, with specific emphasis on Beacon Program. 9. Vision Zero incentives with regard to safety concerns along Queens Boulevard.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 6
image
The three most pressing issues facing this Community Board are:
Schools
Schools - Our youth population continues to increase and we do not need parents to relocate for better educational opportunities. Every child in CB 6 should have a seat in his or her neighborhood school.
Senior services
Senior Services - Senior services need to be continued as the "Baby Boomer" generation ages and the immigrant population increases.
Transit (buses & subways)
Transit - Safe, reliable subway and surface transportation within this community is a major priority as opposed to people using their automobiles.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 6
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
The immigrant elderly population is most certainly a population at risk. CB 6 ranks among the highest concentrations of seniors. They turn to their neighborhood based senior services for various assistance. Many are homebound, isolated and frail. The need for programs with regard to senior services is paramount!
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
CB 6 supports funding for enhanced education regarding availability and access , to services and resources Many of the non-senior population of CB 6 have long term illnesses that can also be life threatening such as cancer, multiple sclerosis, dementia etc. These individuals need many of the same services required by the senior population. They include but are not limited to: 1. Improved and timely transportation pertaining to the Access-A-Ride system. 2.
Delivery of meals 3. Counseling services - including for the homebound 4. Appropriate housing support 5. Hospice services 6. Increased home care services 7. Recreation activities - including library services for homebound 8.
Translation services 9. Appropriate Medication support and Management 10. Respite care for caregivers 11. Bereavement services for family 12. The services offered through ThriveNYC CB 6 encourages funding for research leading to an end to all life threatening diseases, particularly AIDS, Alzheimer’s ; Cancer, and Diabetes. CB 6 supports any program to educate with the aim of eliminating domestic violence. We also support any services which provide assistance to victims of domestic violence
Needs for Older NYs
CB 6 has one of the highest concentrations of senior population in NYC and probably in the State. There also has been a large influx of immigrants of all ages. The confluence of these two with the usual problems of the general population creates needs such as: 1. Affordable health care, including dental and eye care 2. Affordable housing 3. Public safety and security 4. Accessible transportation - both physically and affordable 5. Daycare services for homebound and elderly. 6. Affordable mental health services-also to be available to homebound 7. Affordable legal services 8. Recreation including library services for homebound Our community consists of a significant number of older adults, many of which are living their lives largely independent of family members who live far away. They turn to their neighborhood based senior services for assistance. The social adult day program aims to keep at risk elderly in the community and avoid premature institutionalization by providing them with an opportunity to socialize with peers and create a network of support to rely upon. The educational, recreational programs aim to stimulate their minds and bodies and enhance their self esteem. For the families of the dementia population, social adult day care provides a respite for the family members, and more are needed. These programs have long waiting lists and are underfunded. There is increased demand for services for persons with early dementia as there are waiting lists for the programs for persons who suffer from middle and late stage dementia. A population at risk is the large diverse immigrant elderly population, many of whom have not yet been able to acquire the language skills needed to obtain citizenship and have lost their benefits that are needed for everyday subsistence, including the ability to pay for shelter and food. As such, there is a tremendous increase in the need for ESL classes, conversation groups, tutorials, civics instruction and case assistance. Also, the cultural and language barriers have created increased tensions in the community that are being addressed by the Queens Community House through dialogue groups. These programs are funded minimally through government dollars. The demand for services is huge and the waitlist, long and discouraging.
Needs for Homeless
No comments
Needs for Low Income NYs
Community Board 6 supports an increase in "in home services" for individuals that are low income, yet do not qualify for Medicaid. These programs should be expanded to allow more seniors to have valuable cost saving services.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/13
DFTA
Other senior center
This request is to increase and maintain funding
program requests
for existing senior centers in CB 6 as well as the
expanded in home services for the elderly.
5/13
DHS
Other request for
This request is to increase funding for homeless
services for the
services.
homeless
13/13
DOHMH
Other animal and
This request is to fund personnel for pest control
pest control
and health department programs.
requests
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 6
image
M ost Important Issue Related to Youth, Education and Child Welfare
After school programs
Beacon programs are effective programs that offer positive youth development through educational, cultural and literacy programs. Currently we have two Beacon sites that serve the needs of approximately 47,000 youth.
Preventative programs are necessary to keep youngsters active and engaged in constructive programs , and should include educational and career choice counseling, as well as high school drop out prevention. Youth employment programs should be expanded to address youth employment, develop jobs, and job training programs. In order to make certain that we are doing the best for our youth, the Dept. of Youth and Community Development, must engage in cooperative planning, ensure the most effective use of current youth programs, as well as the development of additional programs.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Community Board 6 looks forward to working closely with District 28 as well as all the public, private, and parochial schools. More importantly, the lines of communication between the board and the schools should be more transparent. Attendance at CB 6 Cabinet Meetings must be taken seriously.
Needs for Youth and Child Welfare
Affordable Day Care for Children - There has been a substantial increase in the number of two parent families in which both parents are working and the also the number of single parent families who are in our community. As a result, there is a serious need for affordable daycare . One idea is to combine children with seniors. An intergenerational program will benefit everyone involved.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
11/16
SCA
Renovate interior building component
FUND INSTALLATION OF AIR CONDITIONING FOR JHS 190 TO ACCOMMODATE THE BEACON SUMMER PROGRAM
12/16
SCA
Renovate interior building component
This request is to fund the installation of water bottle fillers at all CB 6 schools.
14/16
SCA
Renovate exterior building component
This request is to fund the installation of solar panels at all public schools in the CB 6 District.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation Location
1/13
DYCD
Provide, expand, or
CONTINUE FUNDING BEACON PROGRAMS AT
enhance
JHS 190 AS WELL AS GENERAL AFTER SCHOOL
Cornerstone and
PROGRAMS IN COMMUNITY BOARD 6
Beacon programs
(all ages, including
young adults)
2/13
DOE
Improve school
INCREASE FUNDING FOR SECURITY CAMERAS AT
safety
SCHOOLS
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 6
image
M ost Important Issue Related to Public Safety and Emergency Services
Police-community relations
Returning to community policing is the first step toward community safety and repairing relationships. We must build back neighborhood partnerships while securing the safety and fair treatment of civilians and the police that risk their lives every day.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
More than 95 percent of CB 6, traditionally a safe, low crime area, is served by the 112th Precinct which has one of the smallest patrol forces in the City. For this reason, the 112th Precinct should not be pulled to assist with events in Flushing Meadow Park, Citifield, and the U.S. Open. The principal public safety need in this Community District is for real increases in the size of our patrol force, for these reasons: 1. A significant rise in population, the influx of new immigrants and a substantial increase in ethnic/racial diversity have made policing in CB 6 more complex and time- consuming; 2. Other demographic changes, particularly a great increase in youth population, add burdens to the precinct’s workload; 3. The district’s relative affluence continues to attract burglars, bank robbers and shoplifters; 4. The 112 Pct. must also provide police services for many tens of thousands of non-residents who enter our District daily - either to transfer (and often shop) at our three intermodal transit hubs along Queens Blvd. (at Union Turnpike, 71 Avenue, and 63 Road) or to visit the upscale retail/entertainment area along Forest Hills’ Austin Street - or to access the Rego Park regional shopping center; 5. Traffic safety remains an urgent focus of community concern, in view of the long history of pedestrian fatalities on Queens Blvd. An increasing number of motorists ignore the prohibition against use of hand-held cell phones while driving. Enforcement of this law, while difficult, is essential; In addition, greater emphasis should be placed on the guidelines of vision zero. 6. Quality of Life complaints (some not within NYPD’s purview) continue to be numerous in CB 6. 7. The urgent new counter- terrorism mission for NYPD, which requires extensive training time, assignment of officers to additional posts/duties within the precinct, and their detail for special situations elsewhere in the City, logically will affect performance in a small precinct more seriously than a larger one. 8. Increase police enforcement near schools, particularly the Metropolitan Avenue schools, and at all NYCHA Housing. 9. Support for CB 6’s Community Emergency Response Team. (CERT) and a continued focus on the 112th Precinct Explorer’s Program. 10. Staffing of school crossing guards should be a major priority in CB 6.
Needs for Emergency Services
As is well known, CB 6 is densely developed with high-rise and mid-rise multi-family structures, including several of the tallest residential buildings in Queens. CB6 has one engine and one ladder company in a single firehouse within its boundaries, and another on its border. FDNY deployments to structural fires within the district have customarily been satisfactorily prompt. Increased routine or complaint follow-up inspections by FDNY are viewed as essential fire protection actions by this community. All demolition and construction projects, particularly those undertaken by small contractors, in our densely developed district evoke neighborhood concerns and merit FDNY and DOB oversight. Housing market demand has led to numerous illegal conversions of one and two family homes to multi- family or SRO’s. We believe that participation by DOB, FDNY, and its Fire Prevention Bureau, to the fullest extent possible under existing laws, in the campaign to halt and reverse/remediate illegal conversions, would serve this community well.
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
9/16 FDNY Upgrade communication equipment to improve emergency response
Fund upgrading of all communication and computer equipment as well as generators for all firehouses in Community Board 6
image
13/16 NYPD Other NYPD
facilities and equipment requests (Capital)
This request is to fund the purchase of large boots for the 112th Precinct. These boots would accommodate large commercial vehicles, in an effort to prevent trucks from illegally parking within the CB 6 District
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
7/13
NYPD
Assign additional crossing guards
This request is to recruit and retain local precinct crossing guards to ensure the safety of students.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 6
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
The current economic climate has given rise to growing quality of life problems such as graffiti. Graffiti continues to be a problem that has come back on both public and private property throughout CB 6. We should encourage the private sector to provide funding to help keep our neighborhoods clean. Additional mechanical brooms are needed to keep our streets clean.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
Sanitation services continue to be a priority in both the residential and commercial areas of Community Board 6. In order to properly maintain the cleanliness level of CB6, we require: 1. Continue funding for litter basket pickups on commercial strips and a litter basket truck. 2. Fund regularly scheduled cleanup of medians. 3. Maintain weekly recycling. 4. Hire more Sanitation Enforcement agents. 5. Increase enforcement of dirty sidewalks and streets 6.
Mechanical broom for the fall leaf season, a 10 yard alley truck, additional salt spreading equipment for the winter, and a graffiti power washer
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
2/16 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
This request is to fund the upgrade of all CB 6 sewers to accommodate the increasing population.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
9/13
DEP
Investigate noise complaints at specific location
This request is to increase personnel for noise abatement issues within CB 6.
10/13
DSNY
Other enforcement requests
This request is to fund personnel for additional sanitation enforcement in CB 6.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 6
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Commercial district revitalization
There is a major need for programs to assist the commercial strips on Community Board 6 to improve business and cope with growing problems of vacancies; Long term businesses are being forced out because of substantial rent increases. Commercial rents need to be dealt with on a citywide basis. Support from Government would assist the commercial districts in making progress.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Community Board 6 recognizes the following needs:
Department of City Planning:
All large scale developments, whether commercial or residential, need to be studied to ensure that the local electrical grid, gas supply, water supply, sewerage, garbage disposal, transportation systems, schools, parks, recreational facilities, and other utilities and facilities have sufficient capacity for the additional demand that will be created by the developments. Much of CB6 development is as-of-right, which means the developers don't present to the CB and the process excludes environmental review or mandatory inclusionary housing. It is necessary to study the current and future as-of-right developments in CB6 in relation to these two categories.
Department of Buildings:
Hire additional inspectors for timely response to complaints.
Substantially increase penalties for violations so that they are meaningful.
Verify that payment for violations clear a bank before removing the violation.
Needs for Housing
No comments
Needs for Economic Development
There is a need for programs to assist the commercial strips in Forest Hills and Rego Park to improve business and cope with the growing problem of vacancies. There is a need to help small businesses in our community and elsewhere in the city. We support the small business first initiative to help small business owners.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
8/13 DOB Assign additional
building inspectors (including expanding training programs)
This request is to increase DOB inspectors and support staff.
TRANSPORTATION
Queens Community Board 6
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
In terms of traffic / traffic flow, adequacy, pedestrian and vehicular safety and resource allocation, transportation concerns impact Community Board 6 in a variety of significant ways that require priority attention.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Queens Boulevard - This major artery provides vital transportation access for the entire borough, but causes significant and chronic safety problems for both pedestrians and vehicles. To address these concerns, CB 6 recently approved a comprehensive plan by DOT to improve vehicular traffic, pedestrian and bike rider safety on Queens Boulevard in the western portion of our district. We urge DOT to implement this plan promptly and to continue this initiative to the eastern portion of CB 6 as quickly as reasonably possible.
Woodhaven Boulevard - It is especially important to balance the legitimate needs of streamlining traffic flow with the vital safety concerns of the pedestrians and bicycle riders who access Woodhaven Boulevard. Attention must be given to the enhancement of "green-light time" for those seeking to cross the boulevard; traffic markings that coincide with actual vehicular and pedestrian traffic flow; clearly delineated and properly "lined up" crosswalks that are sensitive to the needs of the disabled; and safe and appropriate bicycle lanes. In addition, the impact of Woodhaven's traffic flow upon adjacent local streets and the adoption of possible mitigating measures should also be included within the scope of this project. Lanes of traffic have been removed from Woodhaven Boulevard for general traffic and have become dedicated bus lanes. This has markedly increased traffic congestion on Woodhaven Blvd, especially in the vicinity of Woodhaven Blvd & Union Turnpike. However, bus speeds have improved on this corridor.
Union Turnpike - This heavily utilized thoroughfare generates significant traffic safety concerns that require DOT's ongoing priority attention. Specifically, aggressive enforcement plus the installation of traffic barriers are needed to deter the speeding and reckless driving problems. Pedestrian crosswalks need to be prominently highlighted and traffic signal "green-light time" increased at the local intersections to promote pedestrian safety. This particularly applies to the 71st Ave intersection, which provides primary pedestrian access to a heavily utilized playground as well as the Stop & Shop Supermarket. DOT and Parks Dept must ensure the proper lighting and maintenance of all pedestrian sidewalk and railroad bridge approaches leading to the Stop and Shop area. Yellowstone Boulevard - Yellowstone Boulevard generates significant traffic volumes that traverse a frequently winding road and several complex street crossings involving multiple major thoroughfares. The intersections at Queens Blvd, Austin St, Selfridge St & Woodhaven Blvd present significant traffic circulation and pedestrian access issues that need to be addressed systematically. Improved signage and highlighted crosswalks are needed in those areas where the street turns diminish pedestrian visibility.
Needs for Transit Services
Forest Hills and Kew Gardens form a major transportation hub for New York City. Thousands of commuters pass through these two destinations on their way to or from other destinations. Several bus lines originate here, four subway lines stop here, and two LIRR stations are here, creating significant impacts for Community Board 6. Given this intensity of ridership and intermodal usage, Queens Community Board 6 requires continual maintenance and investment in its transit infrastructure. The MTA is habitually short of critical capital funds needed to maintain and grow the system. Bus service, that runs parallel to subway service, when subway construction and repairs take place on weekends and in evening hours, should be increased. For example, when either the E, F, M or R are taken out of service on weekends and in the overnight hours for scheduled work, the Q60 should have increased service. Indeed
as development continues and the need to provide residents with alternatives to car use grows, bus service along our major thoroughfares, in particular 108th Street, Queens Boulevard and Woodhaven Boulevard needs to be increased generally. We therefore call on the City to provide a meaningful subsidy to the MTA, contingent upon the MTA living up to reasonable performance standards. These subsidies should assist in:
image
image
Funding E/F skip stop service, with some trains originating in Forest Hills. Enhancing frequency and speed of express bus service.
image
Improved subway station maintenance, cleanliness, improved lighting, updated platforms and mezzanines at 71st Ave. station
image
The creation of better bus shelters for the thousands of commuters who wait for buses in all weather.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/16
DOT
Repair or construct
Fund Curb repair throughout CB 6 District
new curbs or
pedestrian ramps
4/16
DOT
Reconstruct streets
This request is to fund street repairs throughout
CB 6.
6/16
DOT
Repair or construct
This request is to fund reconstruction of all CB 6
new curbs or
medians, along with a cracked sidewalk and
pedestrian ramps
crosswalk program. This should include
inspections to ensure adequate pedestrian
ramps
7/16
DOT
Improve traffic and
This request is to fund pedestrian timing devices
pedestrian safety,
and overall safety improvements
including traffic
calming (Capital)
8/16
DOT
Other
This request is to fund sound barriers along
transportation
Long Island Expressway Boundaries within CB 6
infrastructure
requests
10/16
NYCTA
Repair or upgrade
This request is for the installation of security
subway stations or
cameras at all subway stations in CB 6
other transit
infrastructure
15/16
DOT
Repair or provide
This request is to fund additional street lights
new street lights
throughout CB 6 including decorative lighting on
Austin Street, between Ascan Avenue and
Yellowstone Boulevard. The decorative lighting
was started but never completed.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/13
NYCTA
Other transit service requests
INCREASE FUNDING FOR UPDATED GPS SOFTWARE FOR ACCESS-A-RIDE VEHICLES
6/13 NYCTA Improve subway
station or train cleanliness, safety and maintenance
This request is for additional funding for subway station cleaning and maintenance in CB 6.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 6
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Library facilities and access
Full library services, year round with expanded programs for pre-school and after school needs of children. Our libraries are over crowded and have placed limitations on library services. We need larger facilities due to growing numbers of immigrants using them as an educational tool, such as the Rego Park Branch.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
O utreach through the Parks Dept. should be made to local business, Civic organizations and schools to “adopt” a Park or Vest Pocket to assist with planting, landscaping, clean up and also in monetary contributions.
F orestry: Pruning of all trees within CB 6, both in Parks and in residential areas as well as removal of all dead or infected trees and stumps/roots as part of regularly scheduled maintenance. Additionally, replanting or new planting of shade trees within all Park areas.
image
P arks, Playgrounds & Recreation: CB6 requests CONTINUED AND INCREASED MAINTENANCE of all playground equipment including safety matting and also additional “sprinkler” apparatus for children. All local parks, vest pocket park areas, dog runs and playgrounds should be cleaned and maintained on a regular schedule and enhanced to provide maximum usage.
L ost Battalion Hall is an essential part of the community and we support upgrading and improvement in all respects.
F lushing Meadow & Willow Lake Park areas should be made available to residents along the south side of the Park area and enhanced with benches and access routes.
W henever open land becomes available in high density areas, Parks Dept. should secure the property to provide a
green space for residents. However, if additional parks are added to the district, staff should be added to accomodate.
G reen Infrastructure: With an increasing number of rain gardens being installed throughout our community, we are requesting regular maintenance and cleaning of these structures.
Needs for Cultural Services
Cultural events within our community provide life enrichment, bring a diverse community together, and attract tourist dollars. CB6 requests adequate funding for the Department of Cultural Affairs Expense Budget to enable local arts programs; for cultural and arts programs within CB6 serving Queens as a whole (including Veterans groups - Memorial Day Parade, etc and the Chamber of Commerce - Jazz Thursday); and for performances, workshops, and other cultural opportunities.
Needs for Library Services
The libraries in Community Board 6 are heavily utilized by growing numbers of immigrants. It is essential that the libraries remain accessible to all people as an educational tool. Expansion of the Rego Park Library is a major priority of CB 6, along with weekend service to be permanently put in the budget.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/16
QL
Create a new, or
This request is to fund the expansion of the
91-41 63
renovate or upgrade
Rego Park Library which is over utilized for its
Drive
an existing public
current size. This request is also to ensure
library
adequate space for library services in the
community while construction is taking place.
5/16
DPR
Reconstruct or
Fund all current and future park improvements
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
16/16
BPL
Create a new, or
This request is to fund the necessary repairs to
renovate or upgrade
make all CB 6 Library entrances ADA Accessible.
an existing public
This includes Rego Park Library, Forest Hills
library
Library and North Forest Park Library.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
11/13
DPR
Provide better park maintenance
This request is to fund seasonal recreation associates for all playgrounds in CB 6
12/13
DPR
Forestry services, including street tree maintenance
This request is to fund and enhance overall forestry services, stump removal and street tree pruning programs.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/16
QL
Create a new, or
This request is to fund the expansion of the
91-41 63
renovate or upgrade
Rego Park Library which is over utilized for its
Drive
an existing public
current size. This request is also to ensure
library
adequate space for library services in the
community while construction is taking place.
2/16
DEP
Inspect sanitary
This request is to fund the upgrade of all CB 6
sewer on specific
sewers to accommodate the increasing
street segment and
population.
repair or replace as
needed (Capital)
3/16
DOT
Repair or construct
Fund Curb repair throughout CB 6 District
new curbs or
pedestrian ramps
4/16
DOT
Reconstruct streets
This request is to fund street repairs throughout
CB 6.
5/16
DPR
Reconstruct or
Fund all current and future park improvements
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
6/16
DOT
Repair or construct
This request is to fund reconstruction of all CB 6
new curbs or
medians, along with a cracked sidewalk and
pedestrian ramps
crosswalk program. This should include
inspections to ensure adequate pedestrian
ramps
7/16
DOT
Improve traffic and
This request is to fund pedestrian timing devices
pedestrian safety,
and overall safety improvements
including traffic
calming (Capital)
8/16
DOT
Other
This request is to fund sound barriers along
transportation
Long Island Expressway Boundaries within CB 6
infrastructure
requests
9/16
FDNY
Upgrade
Fund upgrading of all communication and
communication
computer equipment as well as generators for
equipment to
all firehouses in Community Board 6
improve emergency
response
10/16
NYCTA
Repair or upgrade
This request is for the installation of security
subway stations or
cameras at all subway stations in CB 6
other transit
infrastructure
11/16
SCA
Renovate interior
FUND INSTALLATION OF AIR CONDITIONING
building component
FOR JHS 190 TO ACCOMMODATE THE BEACON
SUMMER PROGRAM
12/16
SCA
Renovate interior
This request is to fund the installation of water
building component
bottle fillers at all CB 6 schools.
13/16
NYPD
Other NYPD
This request is to fund the purchase of large
facilities and
boots for the 112th Precinct. These boots would
equipment requests
accommodate large commercial vehicles, in an
(Capital)
effort to prevent trucks from illegally parking
within the CB 6 District
14/16
SCA
Renovate exterior
This request is to fund the installation of solar
building component
panels at all public schools in the CB 6 District.
15/16
DOT
Repair or provide
This request is to fund additional street lights
new street lights
throughout CB 6 including decorative lighting on
Austin Street, between Ascan Avenue and
Yellowstone Boulevard. The decorative lighting
was started but never completed.
16/16
BPL
Create a new, or
This request is to fund the necessary repairs to
renovate or upgrade
make all CB 6 Library entrances ADA Accessible.
an existing public
This includes Rego Park Library, Forest Hills
library
Library and North Forest Park Library.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/13
DYCD
Provide, expand, or
CONTINUE FUNDING BEACON PROGRAMS AT
enhance
JHS 190 AS WELL AS GENERAL AFTER SCHOOL
Cornerstone and
PROGRAMS IN COMMUNITY BOARD 6
Beacon programs
(all ages, including
young adults)
2/13
DOE
Improve school
INCREASE FUNDING FOR SECURITY CAMERAS AT
safety
SCHOOLS
3/13
DFTA
Other senior center
This request is to increase and maintain funding
program requests
for existing senior centers in CB 6 as well as the
expanded in home services for the elderly.
4/13
NYCTA
Other transit service
INCREASE FUNDING FOR UPDATED GPS
requests
SOFTWARE FOR ACCESS-A-RIDE VEHICLES
5/13
DHS
Other request for
This request is to increase funding for homeless
services for the
services.
homeless
6/13
NYCTA
Improve subway
This request is for additional funding for subway
station or train
station cleaning and maintenance in CB 6.
cleanliness, safety
and maintenance
7/13
NYPD
Assign additional
This request is to recruit and retain local
crossing guards
precinct crossing guards to ensure the safety of
students.
8/13
DOB
Assign additional
This request is to increase DOB inspectors and
building inspectors
support staff.
(including
expanding training
programs)
9/13
DEP
Investigate noise
This request is to increase personnel for noise
complaints at
abatement issues within CB 6.
specific location
10/13
DSNY
Other enforcement
This request is to fund personnel for additional
requests
sanitation enforcement in CB 6.
11/13
DPR
Provide better park
This request is to fund seasonal recreation
maintenance
associates for all playgrounds in CB 6
12/13 DPR Forestry services,
including street tree maintenance
This request is to fund and enhance overall forestry services, stump removal and street tree pruning programs.
image
13/13 DOHMH Other animal and
pest control requests
This request is to fund personnel for pest control and health department programs.
image

