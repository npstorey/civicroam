- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 10 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/15zucsmpJB1_asarFOqE9fvL1LGfbE-Vv/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/15zucsmpJB1_asarFOqE9fvL1LGfbE-Vv/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
10
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 10
image
Address: 215 West 125th Street, 4th Floor Phone: (212) 749-3105
Email: smitchell@cb.nyc.gov
Website: www.nyc.gov/mcb10
Chair: Cicely Harris District Manager: Shatic Mitchell
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Manhattan Community Board 10 encompasses the neighborhoods of Central Harlem, an area of approximately 1.5 square miles of relatively flat land. Three of the District's four major boundaries are natural features: Harlem River to the north, Central Park to the south and the Fordham Cliffs to the west. The District's eastern border, Fifth Avenue, is its only boundary that is not a natural feature. According to the 2010 Census Data, Central Harlem has a population of approximately 118,000, an increase of about 11,000 over the past ten years. Harlem has witnessed a phenomenal amount of social and physical change over the past few decades. The development of hundreds of vacant lots and buildings has brought a more diverse population to the community. Presently, African Americans make up approximately 58% of the District’s population, followed by Hispanic at 23%, White at 13% and Asian at 3%. Due to its long history as a center for arts, culture and social and political activism, Harlem is regarded as the cultural center for African Americans throughout the world, and one of New York City’s top tourist attractions.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 10
image
The three most pressing issues facing this Community Board are:
Affordable housing
Well before the promulgation of Mayor Bill de Blasio’s affordable housing plan - “Housing New York” and the approval of the Mandatory Inclusionary Housing (MIH) Text Amendment by the New York City Council in March of 2016 relating to the modification of income bands and affordable housing set asides, Manhattan Community Board 10 (through public hearings; committee and general board meetings on the subject) have identified the crisis of the lack of “deeply affordable” housing as its most pressing issue and need. While welcoming MIH as an affordable housing model with tremendous potential, CB 10 passed a joint resolution put forth by its Housing and Land Use Committees in June 2016 requiring more affordable units to be set aside and calling for deeper affordability to address the disparity of the proposed income bands (AMI) and the income realities of our District. In its MIH Resolution, the CB 10 Board has called for the Mayor, City Council, and all administrative agencies with MIH oversight to require an Impact Study before approval of any such application that reviews the impact of such project on schools, traffic and parking, and most importantly, for them to work with the United States Department of Housing and Urban Development to make the necessary adjustments to the AMI of Central Harlem to accurately reflect the real incomes of the residents of CB 10. Further on the issue of Affordable Housing, as part of its critical District Needs, the CB 10 MIH Resolution calls for enhanced affordable first time homebuyers options again reflecting the real incomes of CB 10 residents.
Commercial development (retail mix, small business, MWBE support, etc.)
As a natural connection to its holistic approach on affordable housing, CB 10 has heard through its public hearings, general board and committee meetings its connection to Commercial (Economic) development with special emphasis on its retail mix; support for small businesses and Minority/Women Business Enterprises (M/WBE). A consistent concern expressed by the public and members of the Board is the proliferation of businesses which require liquor licenses as an essential element of their sustainable business plan. Yet, while these businesses are a welcome component of economic development within the District, the lack of affordable commercial retail spaces prevent other businesses and enterprises owned by long-term and emerging minority residents from opening and operating businesses which preserve and maintain the balance and flavor of our neighborhoods. Our residents are concerned about the lack of emerging (and the closure of) retail shops; cafes; bakeries; art galleries; community spaces, etc within the District while witnessing the abundance of storefronts which remain vacant and the emergence of “big box” stores and chain restaurants. The CB 10 Economic Development Committee heard recently of the closure of an incubator space for small businesses within the District (utilized primarily by emerging minority and women enterprises and seek to develop strategies for the maintenance and preservation of such efforts to ensure the proper commercial mix. In this regard, CB 10 is working with our local elected officials, small business partners; community business resource partners (such as the Greater Harlem Chamber of Commerce, the 125th Street BID, Silicon Harlem, etc) to develop plans for more support for M/WBE’s and a greater community retail mix.
Trash removal & cleanliness
One of the most pressing needs of our district is trash removal and cleanliness. The District Office and many of our standing committees (Economic Development; Health and Human Services; Transportation and Housing) have all heard from the community that there is a critical need for additional basket service from the New York City Department of Sanitation. From the economic development side, the 125th Street Business Improvement District (BID) has petitioned CB 10 to assist in securing greater and more consistent collection of garbage along the 125th Street corridor. Reports done by Columbia and CB10 indicate the disparity and infrequency of collection by DSNY between our and other districts. CB 10 supports the efforts of the 125th Street BID and requests that more consistent and focused trash collection extend to the commercial corridors of 116th Street, 135th Street and 145th Street as well as on our commercial avenues and boulevards north and south. As the 125th Street BID suggests in their recent presentation, lack of garbage collection not only has a negative and adverse impact on the operation of the associated businesses but echoes the contention of our Health Committee that it creates health concerns for our residents due to the reality of increased rodent infestation. On Wednesday, August 2, 2017 Mayor Bill De Blasio
held a town hall for the residents in CB10. Both CB10 and the BID voiced these concerns, asking the Mayor to take the task. We hope and believe Mayor De Blasio will address this major concern and would like information on how much funding would be allocated and when.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 10
image
M ost Important Issue Related to Health Care and Human Services
State of health facilities
Harlem Hospital is one of Harlem's Safety Net hospitals. It services the entire Central Harlem District as well as residents from other parts of Manhattan and of the Bronx. Without proper funding Harlem Hospital would not be able to properly service the community members of Harlem. Furthermore past and future cutbacks have affected and will affect the working class in our district as a significant amount of Harlem Hospital employees are residents of Harlem. We request for more funding to be allocated to Harlem Hospital for capital improvements on the facility, to continue and expand its current services and to hire more employees from the community.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
While home to New York’s largest LGBT community, Harlem receives the smallest share of local, state, and federal LGBT budget dollars. Studies have found that LGBTQ youth comprise up to 40% of the homeless youth population in New York City. In December 2007 the Empire State Coalition of Youth and Family Services (ESC) reported on the findings of the first New York City Council census of homeless youth in NYC. This data showed that 28% of the street youth identified as lesbian, gay or bisexual, 11% were unsure of their sexual orientation or were not comfortable answering the question and 5% identified as transgender with another 18% unsure or choosing not to answer the question about gender identity. Furthermore, the Black and Latino LGBT community has the highest proportion of homeless youth, the highest incidence of HIV/AIDS, and the largest number of displaced seniors resulting from gentrification, among other disparities. Moreover, the Harlem LGBT community has no centralized safe space for the provision of dearly needed culturally competent health services. For these reasons, CB10 requests the allocation of city funds to support the creation of a Harlem Center for the LGBTQ+ communities, which will serve as an educational and cultural hub for the district, provide mental and physical health and wellness services, job skills training, and technological transfer, entrepreneurship training, referrals, social and other support services.
Needs for Older NYs
We are requesting that our Senior Facilities be redesigned and/or restructured to include senior fitness, nutrition and tech centers opposed to general Senior Citizen Centers. As our senior population is growing we need a facility that focuses on fitness, wellness and healthy eating. Fitness programs should include self-defense because seniors are targeted for robberies at an alarming rate.
Needs for Homeless
Homelessness in New York City has reached crisis levels, and Harlem is witness to this growing population. During FY16, CB 10, in partnership with CB 9 and CB 11, hosted a forum to address the homelessness crisis within our interconnected districts. Altogether, there are 42 shelters within our district, including 19 in CB 10; this effort eventually led to the creation of The Homelessness in Harlem: A.C.T. Now – Achieving Community Together initiative to address the homeless crisis. According to a September 2016 study by the Coalition for the Homeless , approximately 61,931 homeless people, including 15,691 homeless families with 24,148 homeless children, utilize the New York City municipal shelter system each night. Their research shows that the primary cause of homelessness, particularly among families, is lack of affordable housing. Most disconcerting is the fact that each night thousands of unsheltered homeless people sleep on New York City streets, in the subway system, and in other public spaces. There is no accurate measurement of New York City’s unsheltered homeless population, and recent city surveys significantly underestimate the number of unsheltered homeless New Yorkers. Approximately 58
percent of New York City homeless shelter residents are African-American, 31 percent are Latino, 7 percent are white, less than 1 percent are Asian-American, and 3 percent are of unknown race/ethnicity. The majority of homeless adults, families with children and adult families are Black/African American. A CB 10 moratorium on new or expanded special interest facilities revealed an already oversaturated Central Harlem; however, CB10 is keenly aware of the shortage and mismanagement of existing facilities, including those for working-families, seniors, and other marginalized communities. By stabilizing people through the use of shelters, moving them into permanent housing, and implementing assistance programs to stabilize their housing, the city cannot only reduce, but eliminate, homelessness in New York City.
Needs for Low Income NYs
While home to New York’s largest LGBT community, Harlem receives the smallest share of local, state, and federal LGBT budget dollars. Studies have found that LGBTQ youth comprise up to 40% of the homeless youth population in New York City. In December 2007 the Empire State Coalition of Youth and Family Services (ESC) reported on the findings of the first New York City Council census of homeless youth in NYC. This data showed that 28% of the street youth identified as lesbian, gay or bisexual, 11% were unsure of their sexual orientation or were not comfortable answering the question and 5% identified as transgender with another 18% unsure or choosing not to answer the question about gender identity. Furthermore, the Black and Latino LGBT community has the highest proportion of homeless youth, the highest incidence of HIV/AIDS, and the largest number of displaced seniors resulting from gentrification, among other disparities. Moreover, the Harlem LGBT community has no centralized safe space for the provision of dearly needed culturally competent health services.
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
2/42
HHC
Renovate or
Capital funding to be allocated for the
506 Lenox
upgrade an existing
improvements of the Harlem Hospital Facility
Avenue
health care facility
3/42
HHC
Other health care
Additional funding allocated to Renaissance
264 West
facilities requests
Health Care Network Diagnostic and Treatment
118th Street
Center
5/42
DFTA
Renovate or
Redesign Senior Facilities to include senior
upgrade a senior
fitness, nutrition and tech centers opposed to
center
general Senior Citizen Centers. At least 1 million
dollars should be allocated.
6/42
HRA
Other request for
allocation of city funds to support the creation
services for
of a Harlem Center for the LGBTQ+
vulnerable New
communities, which will serve as an educational
Yorkers
and cultural hub for the district, provide mental
and physical health and wellness services, job
skills training, and technological transfer,
entrepreneurship training, referrals, social and
other support services.
23/42
DHS
Other facilities for
a public facility that homeless will have access
the homeless
to
requests
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
2/41
HHC
Provide a new or
Harlem Hospital is one of Harlem's Safety Net
506 Lenox
expanded health
hospitals. It services the entire Harlem District
Avenue
care facility
as well as residents from other parts of
Manhattan and of the Bronx. We request for
more funding to be allocated to Harlem Hospital
to continue and expand its current health
services.
4/41
DOHMH
Reduce rat
All of Harlem! Especially 125th, 135th, 145th
populations
Street corridors and Malcolm X, Adam Clayton
Powell Jr. and Frederick Douglass Boulevards
6/41 DFTA Other services for
homebound older adults programs
Improved outreach efforts are needed to identify senior citizens who are living in relative isolation and without their basic needs being met, such as adequate shelter, nutritional and utility support, are necessary. According to reports from senior services providers, there remain a significant number of elderly persons in Central Harlem who are eligible for available services but do not take advantage of them.
Identification of this at risk population is of critical importance.
image
8/41 DFTA Enhance NORC
programs and health services
Add additional NORC programs for the increasing home-bound and non-home-bound seniors who are aging in place. We lost two critical NORC program in the CB10 area
image
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 10
image
M ost Important Issue Related to Youth, Education and Child Welfare
Schools and educational facilities (Maintenance)
Many of CB10's public schools have antiquated technological equipment for its students. With updated computers and other technological hardware/software our students can gain access to a more efficient and higher level of learning. We would like for the schools within our district to have its fair share of access to technology. Schools such as PS 36, PS 92, and PS 129 are in dire need of playgrounds that are well equipped to handle 3 and 4 year olds, due to an increase in pre-k programs.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
According to recent statistics, at least one - fifth of students were homeless in district 5. During the same period, at least 80% of students come from low- income families as our district is rent burdened and struggling with gentrification or displacement. Moreover, there are needs concerning matters of domestic violence within the schools and intervention and connection to services is warrented to help provide families with their immediate needs. These issues affect school performance and graduation rates.Supporting families in our district include afdressing the root causes of the needs within the community and to ensure funding and supports around providing programs within the schools that will connect families to services that they need. Programs like Safe Horizons and the Family Justice Center as well as connection to affordable housing opportunities are needed to accelerate and facilitate services to families in need. Providing access to them through the schools will help increase opportunities to education and help parents gain the assistance they need in a natural environment. The Mayor has proposed
$12 million dollars on new supports for homeless students including 100 "Bridging the Gap" social workers at schools with higher concentrations of students in temporary housing. District five would like to request these workers to assist with the current parent coordinators so that there is seamless access to services to address the needs of the community. We realize that in order for our children to be their best, thier basic needs must be addressed to develop to their full potential. We support these efforts.
Needs for Youth and Child Welfare
Community District Needs Related to Youth and Community Services and Programs in partnership with local non- profit organizations and community based entities such as Silicon Harlem, CB10 seeks funding from NYC DYCD to support STEM and STEAM programs that enhance, compliment and integrate youth development programs throughout the District. This includes opportunities for school and community groups to engage youth in ecological studies in CB10 Parks and other programs such as COMPASS NYC. Many of our school buildings are in disrepair and need capital upgrades. The auditoriums need to be remodeled and provided with safer accomodations. The doors of our school buildings need to be automated for people with disabilities and special needs. These provisions will provide greater assistance to the community at large and support to the families that we serve.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
4/42 SCA Provide technology
upgrade
New technological software (e.g. Microsoft Office Suite, Adobe Suite, etc.) and hardware (e.g. laptops, computers, etc.)
image
42/42 SCA Renovate exterior
building component
renovate/upgrade playground 222 St Hope Leadership Academy, Manhattan, New York, NY
Expense Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 10
image
M ost Important Issue Related to Public Safety and Emergency Services
Police-community relations
CB10’s Public Safety Committee seeks support and funding to convene youth, local faith-based organizations, and NYPD Community Affairs together to conduct a series of public forums and informational sessions to promote dialogue, improve transparency, cultivate greater trust between law enforcement and a greater cross section of youth within CB10.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Reducing gun violence - especially as it relates to youths. We need more youth programs that give children an opportunity to pursue their interests (i.e. dance, music, sports, academic enrichment, etc.). Our hope is that if kids have things to do, they will be less likely to spend their time on the street where it's more likely they may get into trouble.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 10
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
With the redevelopment of City-owned properties and an increase in the residential population and commercial establishments, the Community Board believes that Sanitation staffing has not kept pace with the need to process the additional waste tonnage. Cleaners streets are necessary because CB10 continues to hear from community about the amount garbage. As stated above, the more focused and thorough of the collection of garbage and trash and the cleaning of streets has impacts the health and well-being of the businesses and residents of our District.
Health and Safety: CB 10 has heard from community residents, block associations and business owners of the need to do a better job within the District of addressing the issue of rodent infestation. All agree that more frequent trash collection is critical to this process and further suggest a targeted program of replacing existing trash cans with tamper proof versions to prevent encroachment by rats and in some instances raccoons. Economic development: Work with 125th BID on more frequent garbage collection to better manage the vibrancy and cleanliness of the area so that business can flourish.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Maintenance and Cleaning of catch basins, sewers, storm drains; from debris buildup in street drainage systems affecting adjacent buildings and flooding of streets are needed.
Needs for Sanitation Services
One of the most pressing needs of our district is trash removal and cleanliness. The District Office and many of our standing committees (Economic Development; Health and Human Services; Transportation and Housing) have all heard from the community that there is a critical need for additional basket service from the New York City Department of Sanitation. From the economic development side, the 125th Street Business Improvement District (BID) has petitioned CB 10 to assist in securing greater and more consistent collection of garbage along the 125th Street corridor. Reports done by Columbia and CB10 indicate the disparity and infrequency of collection by DSNY between our and other districts. CB 10 supports the efforts of the 125th Street BID and requests that more consistent and focused trash collection extend to the commercial corridors of 116th Street, 135th Street and 145th Street as well as on our commercial avenues and boulevards north and south. As the 125th Street BID suggests in their recent presentation, lack of garbage collection not only has a negative and adverse impact on the operation of the associated businesses but echoes the contention of our Health Committee that it creates health concerns for our residents due to the reality of increased rodent infestation. On Wednesday, August 2, 2017 Mayor Bill De Blasio held a town hall for the residents in CB10. Both CB10 and the BID voiced these concerns, asking the Mayor to take the task. We hope and believe Mayor De Blasio will address this major concern and would like information on how much funding would be allocated and when.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
3/41 DSNY Provide more
frequent litter basket collection
Currently CB10's litter baskets and household garbage is being serviced only once a day. We are requesting an additional pick up each day.
image
14/41 DSNY Increase
enforcement of dirty sidewalk/dirty area/failure to clean area laws
Sidewalks remain filthy for long periods of time. Better enforcement will help keep them clean.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 10
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing preservation
The Manhattan Community Board 10 (CB10) Housing Committee continues to recognize that the most important land use, housing, and economic development issues facing CB10 can best be understood and summarized in the Mandatory Inclusionary Housing (MIH) Zoning Resolution, jointly proposed by the CB10 Land Use and Housing committees and adopted by the full CB10 board on June 1, 2016. The aforementioned MIH resolution addresses: 1) the impact on long-term residents who suffer under the looming threat of housing displacement in the very communities where they have resided for years; 2) the threat of homelessness for families at Area Median Income (AMI) levels below 165% AMI; 3) the need for the creation of AMI standards that accurately represent the incomes of long-term Harlem residents in CB10; 4) the scarcity of homeownership opportunities for residents of Harlem or their children, for individuals and families earning below 60% AMI (62,580 for a family of four) homeownership opportunities are negligible at best; 5) the threat and effects of predatory development and financing; and 6) the failure of the existing City-sponsored affordable housing strategies to provide preservation of historic neighborhoods and conservation of green spaces.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Adjustments to the AMI which more accurately reflect the incomes of the majority of residents of the District Greater financial support and subsidies for developers committed to develop projects with deeper affordability and greater emphasis on the homeless (or those threatened with homelessness The use of 501(c)(3) bonds to finance affordable housing developments to encourage commercial and community facility components of mixed-use projects to include not only restaurants, but other nonprofit health, wellness, arts, and cultural organizations which offer community-based programs and services; Support for Housing Development Fund Corporations (HDFC’s) by providing more informational and educational opportunities regarding the newly proposed Regulatory Agreement and to promote and establish better board governance and financial accountability Survey of vacant city-owned lots, and the status of site possession by developers An increase in mixed-use communities, in which housing, quality-paying employment opportunities and retail support the vitality of the Central Harlem community to create a more sustainable quality of life and path towards financial stability and economic vitality for both residents and local businesses Increased Affordable Home-ownership Programs to anchor community, at a wider range of affordability, including workforce options at higher AMI ranges.
Needs for Housing
Housing Development Fund Companies (HDFCs) During the 2017-2018 and 2016-1017 fiscal years, the CB10 Housing Committee focused its attention on retaining and stabilizing 4,936 units of cooperative housing in the district. These resident-owned special business corporations were created, beginning as early as 1966, by the Article XI of the New York State Private Housing Finance Law or the Housing Development Fund Company (HDFC) law. The HDFC law required all corporations organized under the legislation to include, “Housing Development Fund Company” or “HDFC” in its corporation’s name, thus causing this low-income housing stock to commonly be referred to as HDFCs. The city’s HDFCs represent one of the few, and for many, the only city-sponsored program that provides homeownership opportunities for first-time homebuyers, low-, and extremely low-income New Yorkers.
That changed during the Giuliani administration when the city’s Department of Housing Preservation and Development (HPD) rejected the federal government’s definition of low-income and created its own definition of low-income by doubling the federal maximum-income ceiling established by the Department of Housing and Urban Development (HUD) from 60%AMI to 120 AMI. Because of that policy HDFCs are no longer viable for families earning 60% AMI ($62,580 for a family of four), and those resources have been now diverted to families earning 120% AMI ($125,160 for a family of four). For approximately 90 HDFCs organized under this special program, the income maximum peaked at 165% AMI, ($172,095 for a family of four). By changing the definition of low-income,
based solely on language loosely constructed in Section 571 of Article XI, the city responded to the economic demand for housing opportunities from a segment of its constituents, and expanded HDFC homeownership opportunities for moderate and middle income New Yorkers. The shift in AMI in the 1990s, essentially eliminated HDFC homeownership opportunities for very-low and extremely-low income earners, severely reduced HDFC homeownership opportunities for those New Yorkers, who had traditionally identified as low-income--persons earning between 40% and 60% of AMI--and created loopholes that allowed people with substantial cash assets to purchase low-income housing and benefit from tax exemptions established to reward HDFCs as providers of low- income housing. While the Housing Committee recognizes the real economic demand for affordable housing opportunities from moderate and middle income New Yorkers, we urge HPD to reconsider the recommendation of zero property taxes as well as zero-interest financing for those HDFCs that maintain sustainability, while conserving 70 to 60 percent of these precious housing resources for persons earning under 60% AMI, ($62,580 for a family of four).’ Through a series of workshops, presentations, and housing clinics designed to empower HDFC shareholders and enhance the work of HDFC directors, the Housing Committee heard direct testimony and gathered information through its surveys. One of the important outcomes of this engagement was that there is an urgent and pressing need for advocacy, education, and technical training from diverse educational and technical training providers with legal and business expertise, with a curriculum focused on the rights of shareholders in HDFCs. Third Party Transfer (TPT) Program The Housing Committee has gone to considerable lengths to assist HDFCs that are in distress: we joined other Community Boards in calling for a moratorium on HDFC transfers that would strip shareholders in HDFCs of their homeownership rights and equity; we have demanded relief for qualified HDFCs though the Tax Amnesty Program provided by Article XI of the State of New York Private Housing Finance Law. We have urged City Council and HPD to engage in case-by-case determinations of each distressed HDFC in the district to decide whether the TPT program is the appropriate recourse or if other necessary resources and interventions can make the building sustainable. Those resources and interventions could include: removal of dysfunctional and corrupt directors, outside monitoring and management, full or partial exemption of property taxes; financially-feasible payment agreements that are modified and/or extended to reasonably satisfy the terms and conditions of the HDFC; a capital improvements program that provides low-interest financing at an interest rate of no more than 2% annually; and the elimination of balloon payments in financing packages that forced corporations to refinance their mortgages, which expose them to new regulatory agreements or to have to engage in predatory practices that undermine the spirit if not the letter of the HDFC law. Tenant Interim Lease (TIL) Program The Housing Committee partnered with and supported residents in the Tenant Interim Lease (TIL) program in their fight to avoid removal from the Tenant Interim Lease (TIL
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/42
HPD
Provide more
The City should encourage more subsidies for
housing for
housing programs for the lowest income
extremely low and
populations (i.e. 30 to 50 percent of AMI)
low income
and/or cross subsidize those populations
households
through mixed-income programs that target
households earning up to 165 percent of AMI.
This will allow us to serve a wider range of
households within the District.
17/42
NYCHA
Renovate or
New elevators and plumbing at Saint Nicholas
2406
upgrade public
Houses
Frederick
housing
Douglass Blvd
developments
28/42
HPD
Provide more
Housing Development Fund Companies
housing for
(HDFCs).During the 2017-2018 and 2016-1017
extremely low and
fiscal years, the CB10 Housing Committee
low income
focused its attention on retaining and stabilizing
households
4,936 units of cooperative housing in the
district. These resident-owned special business
corporations were created, beginning as early
as 1966, by the Article XI of the New York State
Private Housing Finance Law or the Housing
Development Fund Company (HDFC) law. The
HDFC law required all corporations organized
under the legislation to include, Housing
Development Fund Company or HDFC in its
corporations name, thus causing this low-
income housing stock to commonly be referred
to as HDFCs.
31/42
NYCHA
Renovate or
As evident the recent public hearings as well as
upgrade public
past and recent audits by New York City
housing
Comptroller Scott Stringer that exposed failed
developments
heating systems, unsatisfactory and dangerous
playgrounds, broken building entrance doors,
backlogged repairs, and extended vacancies,
the needs in New York City Housing Authority
(NYCHA) developments are dire and those needs
are escalating at an alarming rate. The extent of
the problem has caused the federal government
to propose appointing a federal monitor to
oversee NYCHA. It is not hyperbole for this
committee to describe conditions in some
NYCHA developments in the district as,
inhuman, where children are exposed to the
debilitating and toxic effects of mold.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
27/41
NYCHA
Expand tenant
Third Party Transfer (TPT) Program. The Housing
protection programs
Committee has gone to considerable lengths to
assist HDFCs that are in distress: we joined
other Community Boards in calling for a
moratorium on HDFC transfers that would strip
shareholders in HDFCs of their homeownership
rights and equity; we have demanded relief for
qualified HDFCs though the Tax Amnesty
Program provided by Article XI of the State of
New York Private Housing Finance Law. We have
urged City Council and HPD to engage in case-
by-case determinations of each distressed HDFC
in the district to decide whether the TPT
program is the appropriate recourse or if other
necessary resources and interventions can make
the building sustainable.
28/41
HPD
Other affordable
Affordable Neighborhood Cooperative Program
housing programs
(ANCP) The Housing Committee is calling for the
requests (expense)
creation of more affordable homeownership
opportunities by the creation of city-owned
residential properties to resident-owned
cooperatives through the newly introduced
Affordable Neighborhood Cooperative Program
(ANCP). All of the smaller NYCHA multi-dwelling
buildings in the district represent another
untapped source of affordable home-ownership
opportunities.
29/41
NYCHA
Expand tenant
HDFC Proposed Regulatory Agreement With
protection programs
HPD presently developing a revised draft of its
proposed regulatory agreement for HDFCs
created before 2008, the Housing Committee
will seize upon the opportunity these discussions
around the regulatory agreement afford us to
advocate for compromises that enhance the
rights of shareholders in HDFCs, delineate the
responsibilities of boards of directors, provide
interest-free financing for HDFCs that received
very little capital investment from the city at the
time of conversion, and offer deeper tax
exemptions, subsidies, and abatements for
those HDFCs that continue to operate as
providers of low-income housing.
36/41 NYCHA Other housing
support requests
Supportive Housing The Housing Committee recognizes the need to focus on supportive housing in the district, and it intends to evaluate supportive housing assets in the district as well as the needs of our most vulnerable constituents in the district, many who are beneficiaries of supportive housing. The Committees investigation will include: constituents currently or previously homeless; persons with a history of substance abuse; persons living with HIV-AIDS; and persons with mental health needs among others. Seeking to achieve a broad representative scope through the committees investigation, we will also examine the supportive housing needs of veterans, artists, musicians, persons with current or prior justice system involvement, persons under parole or probation supervision, person
image
41/41 NYCHA Expand tenant
protection programs
The Housing Committee partnered with and supported residents in the Tenant Interim Lease (TIL) program in their fight to avoid removal from the Tenant Interim Lease (TIL) Program, by assisting these residents with skills-building resources to improve compliance with financial reporting, rent collection, and annual elections. It is important to note that the overarching objective of the TIL program was to provide tenants with the education and technical training to convert these city-owned rental properties to HDFC cooperatives. In 2008, HPD stopped actively developing and converting its TIL buildings to HDFCs. This policy essentially reduced the thriving TIL program into a stagnant holding company consisting of roughly 125 buildings citywide.
image
TRANSPORTATION
Manhattan Community Board 10
image
M ost Important Issue Related to Transportation and Mobility
Traffic safety
309 people were injured in traffic crashes in CD 10 between Jan. 1 and Aug. 31 2015. This included 84 pedestrians, 37 bicyclists, and 188 motorists. There was also 1 tragic pedestrian fatality. Community District 10’s Transportation Committee works with City agencies and the community in an effort to implement Mayor de Blasio’s commitment to Vision Zero. Vision Zero is a traffic safety project which aims to achieve a street safety system with no fatalities or serious injuries in road traffic. Community Board 10 is at the forefront of this initiative and is working vigorously with City agencies and the community to map out the areas in Central Harlem which are unsafe to motorists, cyclists and in particular, pedestrians.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Manhattan Community Board 10 is serviced by several modes of public transportation, bicycle lanes, roads, bridges, and the Metro North railway. The Metropolitan Transportation Authority (MTA) currently operates six subway lines (2, 3, A, B, C, D lines) in CB10 and is planning on extending the Second Avenue line to East West 125th Street starting in 2017. In regards to public transportation needs, CB10 has recommendations regarding the Second Avenue subway extension and concerns relating to MTA service delays, safety and sanitation in the MTA stations in our district.
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
7/42 NYCTA Improve accessibility of transit infrastructure, by providing elevators, escalators, etc.
Add elevators or escalators to major transit stations to enhance accessibility. 3 line 148, 125, 116, ACD lines 145, 125 Streets Stations
image
16/42 DOT Repair or construct
new curbs or pedestrian ramps
Repair or construct new sidewalks, curbs, medians, islands and pedestrian ramps. Many sidewalks are in bad condition and are not ADA- accessible. We request that all pedestrian walkways are repaired and made ADA- accessible. In particular, the curb on West 129th Street between Adam Clayton Powell Jr. Blvd. and Frederick Douglass Blvd. should be lowered and a ramp installed in order to make it accessible for people with limited mobility.
image
22/42 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Fix bollards on Adam Clayton Powell Blvd. Adam Clayton
Powell Jr. Blvd 110th 155th
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
9/41
DOT
Improve traffic and
Increase pedestrian safety a. Ensure that the
pedestrian safety,
allotted time for pedestrians to cross at
including traffic
intersections is realistic. We want to make sure
calming (Expense)
that the elderly and individuals with disabilities
are able to cross at busy intersections along our
larger avenues - Malcolm X Avenue, Adam
Clayton Powell Jr., Blvd., and Frederick Douglass
Blvd. b. Build pedestrian islands.
12/41
NYCTA
Other transit service
The only station which will reach CB10 will be
requests
the 125th Street subway line, which will reach
Fifth Avenue and 125th Street. We recommend
to the MTA and Department of Transportation
(DOT) that they coordinate extensive
community outreach regarding the Phase 2
work extending to 125th Street.
13/41
NYCTA
Other transit service requests
With the start of the Harlem Bike Network, we need bicycle safety classes /workshops as well as bike helmet giveaway events
15/41
NYCTA
Other transit service
Increase access-a-ride program to decrease
requests
waiting time and no shows from drivers.
16/41
DOT
Conduct traffic or
Traffic study of Manhattan Ave from 110th-
Manhattan
parking studies
122nd street
Ave 110th St
122nd St
17/41
DOT
Conduct traffic or
Traffic study of 155th Street
155th St
parking studies
Harlem River
Dr Bradhurst
Ave
18/41
DOT
Conduct traffic or
Traffic study of 145th street
145th St
parking studies
Harlem River
Dr Bradhurst
Ave
23/41
DOT
Add street signage
Replace dull, illegible street signs throughout
or wayfinding
the district
elements
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 10
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Access to and quality of park programming
Parks, gardens and recreation centers provide a needed network of recreational and learning spaces for youth and adults of all ages. Our youth, who suffer from an alarming rate of obesity, diabetes and asthma, are particularly in need. Most CB10 residents come from moderate to low income families who must make the most use of their local parks. While CB 10 does have 23.6 acres of parkland, it ranks 34th in the City in terms of its open space ratio (open space acres per thousand residents). CB10 has 21 parks and 32 community gardens. For the mature adult population, active aging is a tremendously important key to continued physical and emotional health. CB10 parks need to offer a wide range of activities that help our growing population of seniors regain lost agility and increase their strength and flexibility. Multigenerational exercise equipment should allow for both safe and effective workouts regardless of the age or fitness level of the user. Multiple workout stations should be available that promote socialization and increase motivation for our seniors while facilitating a workout that's customized to individual needs. CB10 recognizes that Park users are diverse and have varying needs. CB10 Parks need programming to accommodate the diverse needs of users. Equitable use of CB10 Parks needs to be fostered to (1) help youth choose rewarding paths to adulthood by providing programs and opportunities to build physical, intellectual, emotional and social strength, (2) help new entrants to the workforce find productive jobs by offering decent, entry-level employment opportunities in the community, (3) help community residents improve their health by providing a place to enjoy fresh air and exercise and (4) help citizens join together to make their communities better by encouraging them to participate in park planning and management. According to the Citizens Committee for Children, CB10 ranks 12 (moderate to high risk) out of 59 districts across six domains of child well-being; Economic Security, Housing, Health, Education, Youth, and Family & Community. 15% of students who reside in CB10 are homeless. Families with children entering shelters in CB 0 has increased by 51% according to the Institute for Children, Poverty & Homelessness (ICPH). 56% of single mothers with children under five live in poverty in NYC Council District 9. CB10 has 21 family shelters which is 58% of Manhattan shelters and 6% of shelters citywide. The CB10 community requires programming and associated materials in local area parks to improve outcomes for these at-risk children. CB10 needs to develop strategies to holistically integrate the collaboration of city agencies and the Community to create long term and effective solutions, based on best practices, to address the housing, mental health and financial stability of our area’s neediest population in CB10.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Parks, gardens and recreation centers provide a needed network of recreational and learning spaces for youth and adults of all ages. Our youth, who suffer from an alarming rate of obesity, diabetes and asthma, are particularly in need. Most CB 10 residents come from moderate to low income families who must make the most use of their local parks. While CB 10 does have 23.6 acres of parkland, we cannot ignore the fact that it still ranks 34th in the City in terms of its open space ratio (open space acres per thousand residents). CB 10 recognizes that there are different types of Park users with different needs. CB 10 Parks need to have programming to accommodate the diverse needs of users. Equitable use of CB 10 Parks needs to be fostered to (1) help youth choose rewarding paths to adulthood by providing programs and opportunities to build physical, intellectual, emotional and social strength, (2) help new entrants to the workforce find productive jobs by offering decent, entry-level employment opportunities in the community, (3) help community residents improve their health by providing a place to enjoy fresh air and exercise and (4) help citizens join together to make their communities better by encouraging them to participate in park planning and management. According to the Citizens Committee for Children, CB 10 ranks 17 out of 59 districts where children are at risk for economic security, health, housing, education and issues specific to teens, youth and families. CB 10 requires programming and associated materials in local area parks to improve outcomes for these at- risk children. For the mature adult population, active aging is a tremendously important key to continued physical
and emotional health. CB 10 parks needs to offer a wide range of activities that help our growing population of seniors regain lost agility and increase their strength and flexibility. Multigenerational exercise equipment should allow for both safe and effective workouts regardless of the age or fitness level of the user. Multiple workout stations should be available that promote socialization and increase motivation for our seniors while facilitating a workout that's customized to individual needs. Community gardens are explicitly designated as green spaces for the common good and historically have helped to stabilize distressed neighborhoods, as in the case of CB 10 throughout the 70’s, 80’s and 90’s. Social ties are important to the wellbeing of people in a community as they bring positive health effects and community involvement. Community gardens allow for the creation of social ties and build a greater feeling of community. These connections help reduce crime, empower residents and allow them to feel safe in their neighborhoods. In addition, Community gardens help to reduce negative environmental impacts by promoting sustainable agriculture; reducing food transportation costs and reducing water runoff. Property values are also increased by proximity to community gardens. CB 10 seeks to maintain a balance between preserving open and green space for constituents and creating affordable housing. The following is an assessment of CB 10’s specific needs with respect to local area parks, playgrounds recreation facilities, green spaces and recommendations as to how the New York Department of Parks and Recreation (DPR) can best address them:
Needs for Cultural Services
Recommendations and resources for developers to engage local artists and public art into building construction plans, including the temporary programming of vacant spaces and storefront windows, is needed to celebrate Harlem’s rich cultural and artistic history.
Needs for Library Services
These past two years have been successful for libraries across the City. With the support of the City Council and the Administration libraries were able to make significant gains. In FY18 libraries were allocated an additional $110 million in capital funding to work toward maintaining and improving our infrastructure. In FY17, libraries received a baselined $43 million in additional expense funding. These increases have allowed the City’s three library systems to sustain six day service at all branches and provide our patrons with the functional, inspiring spaces they deserve.
Libraries are often the first place that communities turn to for help and information, and our branches are uniquely positioned to provide relevant and up to date information to New York’s most vulnerable populations. Libraries are a place for learning, safe and open access to information and will always welcome all New Yorkers. In an effort to continue to support our most vulnerable New Yorkers we are urging the City in FY19 to increase expense funding so that all neighborhoods and communities in our city have access to a library seven days a week
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
8/42
DPR
Reconstruct or
We are requesting that the list itemized below
Lenox and W
upgrade a park or
be upgraded or installed at Colonel Charles
143 St - 145
amenity (i.e.
Young Playground: Comfort station; New
St
playground, outdoor
Benches; Enhanced lighting; New signage and
athletic field)
enforcement to deter owners from letting dogs
off leash; Adult Exercise equipment; Resurface
perimeter for walking/jogging path; New
grill/picnic area. We need an off-leash dog park
which will address design criteria, including size,
fencing, gates and entrances, sanitation
facilities, water, surfacing, shade, seating,
agility equipment, paths, park maintenance,
supervision and monitoring, signage, specified
hours of operation and enforcement
9/42
DPR
Reconstruct or
We are requesting that the list itemized below
7th Ave and
upgrade a park or
be upgraded or installed at St. Nicholas
W 127 St
amenity (i.e.
Playground South: Comfort station; New
playground, outdoor
benches; Spray shower; Playground equipment
athletic field)
for disabled youth; Exercise equipment for
seniors, and new water fountains.
10/42
DPR
Reconstruct or
We are requesting that the list itemized below
280 West
upgrade a park or
be upgraded or installed at Rucker Holcomb
155th Street
amenity (i.e.
Park: Comfort station; Spray shower; New
playground, outdoor
playground surface; Exercise equipment for
athletic field)
seniors
11/42
DPR
Reconstruct or
We are requesting that the list itemized below
85 Bradhurst
upgrade a park or
be upgraded or installed at Jackie Robinson
Avenue
amenity (i.e.
Park: Comfort Station; Resurface two ball fields
playground, outdoor
to mitigate flooding; Playground equipment for
athletic field)
disabled youth; Exercise equipment for seniors.
We need an off-leash dog park which will
address design criteria, including size, fencing,
gates and entrances, sanitation facilities, water,
surfacing, shade, seating, agility equipment,
paths, park maintenance, supervision and
monitoring, signage, specified hours of
operation and enforcement
12/42
DPR
Reconstruct or
We are requesting that the list itemized below
W 138th St
upgrade a park or
be upgraded or installed at William McCray
and Lenox
amenity (i.e.
Playground: Playground renovation;
Ave
playground, outdoor
Resurfacing for flood prevention
athletic field)
13/42
DPR
Reconstruct or
We are requesting that the list itemized below
269 West
upgrade a park or
be upgraded or installed at Bill Bojangles
150th Street
amenity (i.e.
Playground: New benches; Resurface basketball
playground, outdoor
court and backboard
athletic field)
14/42
DPR
Reconstruct or
We are requesting that the list itemized below
2122 5th
upgrade a park or
be upgraded or installed at Courtney Callendar
Avenue
amenity (i.e.
Playground: Unisex bathroom; Landscaping;
playground, outdoor
New benches
athletic field)
15/42
DPR
Reconstruct or
We are requesting that the list itemized below
Lenox Ave
upgrade a park or
be upgraded or installed at Fred Samuel
and W 139 St
amenity (i.e.
Playground: Comfort station; Exercise
playground, outdoor
equipment for seniors
athletic field)
18/42
DPR
Reconstruct or
We need an upgrade of the staff building at
7 Ave and W
upgrade a park or
Frederick Johnson Playground to include interior
150 St
amenity (i.e.
repairs
playground, outdoor
athletic field)
19/42
DPR
Other requests for
New elevator at Hansborough Recreation
35 West
park, building, or
Center
134th Street
access
improvements
20/42
DCLA
Other cultural
Community Board 10 would like to see the
facilities and
creation of a PAC that would help to solidify its
resources requests
long cultural standing in the world as a center
(Capital)
for the arts and culture.
21/42
DPR
New equipment for
We need additional maintenance equipment
maintenance
vehicles
(Capital)
24/42
DPR
Reconstruct or
We need the upgrades of the Colonel Charles
upgrade a park or
Young Playground ball field to a multi-
amenity (i.e.
disciplinary field that will accommodate
playground, outdoor
softball, football, soccer, rugby and Lacrosse,
athletic field)
and mitigate flooding. We need to repave the
perimeter run around the ball park to enable
walking and jogging exercises and we need to
install a grill/picnic area
25/42
DPR
Provide a new or
We need to provide a dirt bike riding facility
expanded park or
where riders can practice the sport safely
amenity (i.e.
without endangerment to community residents,
playground, outdoor
while promoting safe and responsible ridership.
athletic field)
26/42
DPR
Provide a new or
We need the installation of playground
expanded park or
amenities and equipment to assist the disabled
amenity (i.e.
youth and adult populations in CB 10
playground, outdoor
athletic field)
27/42
DPR
Provide a new or
We need to provide Port-o-Sands in interim of
expanded park or
comfort station repairs in CB 10 parks and
amenity (i.e.
playgrounds
playground, outdoor
athletic field)
29/42
DPR
Other requests for
We need to install biographical plaques and
park, building, or
installation to commemorate park namesakes in
access
CB 10
improvements
30/42
DPR
Reconstruct or
We need to have repairs made to the Colonel
upgrade a park or
Charles Young Playground to mitigate flooding
amenity (i.e.
on the ball field
playground, outdoor
athletic field)
32/42
DPR
Other requests for
We need the installation of a new boiler in the
park, building, or
Hansborough Recreation Center
access
improvements
33/42
DPR
Other requests for
We need improved signage and enforcement to
park, building, or
deter owners from allowing dogs off leashes at
access
Colonel Charles Young Triangle
improvements
34/42
DPR
Provide a new or
We need to close the gap in the Harlem River
expanded park or
Park Bikeway and Esplanade between 145th
amenity (i.e.
and 163rd streets, We need to design and
playground, outdoor
construct the CB 10 portion of the esplanade
athletic field)
with community input
35/42
DPR
Reconstruct or
We need an upgrade of the staff building at
upgrade a building
Frederick Johnson Playground to include repairs
in a park
of the interior and the heating and cooling
systems
36/42
DPR
Provide a new or
We need dog stations installed along the
expanded park or
exterior of CB 10 parks and playgrounds
amenity (i.e.
playground, outdoor
athletic field)
37/42
DPR
Provide a new or
We need water fountains with water bottle
expanded park or
fillers in all of CB 10 parks and playgrounds
amenity (i.e.
playground, outdoor
athletic field)
38/42
DPR
Other requests for
We need ongoing landscaping and maintenance
park, building, or
for all CB10 parks and playgrounds.
access
improvements
39/42
DPR
Other requests for
We need to transfer HPD and DCAS properties
park, building, or
to the NYC Parks Department for creation of
access
green space and gardens in the vacant areas in
improvements
the district
40/42
DPR
Provide a new or
We need to reconstruct and stabilize retaining
expanded park or
walls and sea walls
amenity (i.e.
playground, outdoor
athletic field)
41/42
DPR
Provide a new or
We need to design a Harlem River Park
expanded park or
waterfront Esplanade
amenity (i.e.
playground, outdoor
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
1/41 OMB Provide more
community board staff
Increase the board's budget to accommodate additional staff to deal with all the intricacies of intergovernmental affairs and participation in the city's budget
image
5/41
DPR
Improve trash
Community residents are, in fact, complaining
removal and
that there are rat infestations in CB10 parks.
cleanliness
Rats can be seen venturing out from the park
onto peripheral sidewalks foraging for food. Rat
burrows are prevalent and clogged water drains
in CB 10 parks provide refuge for the
proliferation of rat populations. We need a
successful and integrated approach to rodent
management in CB 10 park facilities
7/41
NYPL
Extend library hours
In an effort to continue to support our most
or expand and
vulnerable New Yorkers we are urging the City
enhance library
in FY19 to increase expense funding so that all
programs
neighborhoods and communities in our city
have access to a library seven days a week.
10/41
DPR
Forestry services,
The Friends of the ACPB Malls are a volunteer
Adam Clayton
including street tree
Group that has worked in collaboration with the
Powell Jr. Blvd
maintenance
NYC Parks and Rec. Dept. since 1997. Their goal
110th St
= beautify and maintain the 42 landscaped
152nd St
Malls from 110th St. to 152nd St. They plant
bulbs in Oct. and flowering plants in May. Most
recently on 10/21/17 they oversaw the planting
several 1000s of bulbs. The Friends are
requesting $500,000. This money is being
requested for: Testing of soil, trees, and
drainage; evaluation of best plant life; a design
that would render the 42 Malls similar in
appearance; to design a barrier to discourage
walking on the Malls; to determine the cost
needed for each Mall
11/41
DPR
Other park
We need free, secure and reliable Wi-Fi service
programming
in CB 10 parks and playgrounds that provides a
requests
sufficient bandwidth to accommodate the park
traffic
19/41
DPR
Improve the
We need staff and materials to run arts, crafts
quality/staffing of
and recreational programs for children during
existing programs
the summer months
offered in parks or
recreational centers
20/41
DPR
Enhance park safety
We need additional PEP Officers to serve
through more
Manhattan CB10
security staff (police
or parks
enforcement)
21/41
DPR
Improve the
1) We need additional staffing of park
quality/staffing of
management 2) We need staff positions for
existing programs
Playground Associates for CB 10 playgrounds 3)
offered in parks or
We need additional staffing of park seasonal
recreational centers
maintenance staff
22/41
DPR
Provide better park
Park maintenance and safety: we need
maintenance
additional maintenance staff for park comfort
stations in CB10
24/41
DPR
Forestry services,
We need ongoing landscaping and maintenance
including street tree
for all CB10 parks and playgrounds
maintenance
25/41
DPR
Provide more
We need to continue to provide programs that
programs in parks or
promote community-based, park-partnership
recreational centers
activities and events
26/41
DPR
Other park
We need to identify and pursue strategies to
programming
increase the resilience to climate change and
requests
sea level rise within the CB 10 area with respect
to the specific shoreline topography
30/41
DPR
Improve the
We need additional staffing of park
quality/staffing of
management.
existing programs
offered in parks or
recreational centers
31/41
DPR
Other park
We need to support established and new
programming
community gardening stewardship and
requests
programming in CB 10 parks
32/41
DPR
Provide more
We need to develop and implement programs
programs in parks or
for educational components to facilitate school
recreational centers
and community groups to engage youth in
ecological studies in CB 10 parks
33/41
DPR
Other street trees
We need to provide a horticultural design that
and forestry
would render the 42 Malls synchronous in
services requests
design appearance and include a barrier to
discourage walking on the Malls
34/41
DPR
Other park
We need to promote City, State, federal, civic
programming
and private sectors partnering to advance
requests
shared goals and initiatives for the optimal
balance of waterfront and waterway uses
35/41
DPR
Forestry services, including street tree maintenance
We need horticultural upgrades to Courtney Callendar Playground, Hancock Park, Lafayette Square, Samuel Marx Triangle, CB 10 area of Harlem River Park and Dorrence Brook Square
37/41
DPR
Forestry services,
We need the installation of an embedded
including street tree
irrigation system in the Malls and we need to
maintenance
correct poor Mall drainage, trim overgrown
bushes and replace deficient soil.
38/41
DPR
Other park
We need a listing and mapping of all vacant lots
programming
in CB 10
requests
39/41
DPR
Enhance park safety
We need to enhance lighting for Colonel Charles
through design
Young Triangle
interventions, e.g.
better lighting
(Expense)
40/41
DPR
Other park
We need to require that DPR continue to
programming
implement outreach and advertising of existing
requests
programs in CB 10. We need to require that DPR
continue to strengthen education for volunteers
who participate in community-based programs
in CB 10 parks. We need to require that DPR
continue to strengthen and improve the
structure, procedures and processes of
community-based volunteer programs for CB 10
parks
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/42
HPD
Provide more
The City should encourage more subsidies for
housing for
housing programs for the lowest income
extremely low and
populations (i.e. 30 to 50 percent of AMI)
low income
and/or cross subsidize those populations
households
through mixed-income programs that target
households earning up to 165 percent of AMI.
This will allow us to serve a wider range of
households within the District.
2/42
HHC
Renovate or
Capital funding to be allocated for the
506 Lenox
upgrade an existing
improvements of the Harlem Hospital Facility
Avenue
health care facility
3/42
HHC
Other health care
Additional funding allocated to Renaissance
264 West
facilities requests
Health Care Network Diagnostic and Treatment
118th Street
Center
4/42
SCA
Provide technology
New technological software (e.g. Microsoft
upgrade
Office Suite, Adobe Suite, etc.) and hardware
(e.g. laptops, computers, etc.)
5/42
DFTA
Renovate or
Redesign Senior Facilities to include senior
upgrade a senior
fitness, nutrition and tech centers opposed to
center
general Senior Citizen Centers. At least 1 million
dollars should be allocated.
6/42
HRA
Other request for
allocation of city funds to support the creation
services for
of a Harlem Center for the LGBTQ+
vulnerable New
communities, which will serve as an educational
Yorkers
and cultural hub for the district, provide mental
and physical health and wellness services, job
skills training, and technological transfer,
entrepreneurship training, referrals, social and
other support services.
7/42
NYCTA
Improve
Add elevators or escalators to major transit
accessibility of
stations to enhance accessibility. 3 line 148,
transit
125, 116, ACD lines 145, 125 Streets Stations
infrastructure, by
providing elevators,
escalators, etc.
8/42
DPR
Reconstruct or
We are requesting that the list itemized below
Lenox and W
upgrade a park or
be upgraded or installed at Colonel Charles
143 St - 145
amenity (i.e.
Young Playground: Comfort station; New
St
playground, outdoor
Benches; Enhanced lighting; New signage and
athletic field)
enforcement to deter owners from letting dogs
off leash; Adult Exercise equipment; Resurface
perimeter for walking/jogging path; New
grill/picnic area. We need an off-leash dog park
which will address design criteria, including size,
fencing, gates and entrances, sanitation
facilities, water, surfacing, shade, seating,
agility equipment, paths, park maintenance,
supervision and monitoring, signage, specified
hours of operation and enforcement
9/42
DPR
Reconstruct or
We are requesting that the list itemized below
7th Ave and
upgrade a park or
be upgraded or installed at St. Nicholas
W 127 St
amenity (i.e.
Playground South: Comfort station; New
playground, outdoor
benches; Spray shower; Playground equipment
athletic field)
for disabled youth; Exercise equipment for
seniors, and new water fountains.
10/42
DPR
Reconstruct or
We are requesting that the list itemized below
280 West
upgrade a park or
be upgraded or installed at Rucker Holcomb
155th Street
amenity (i.e.
Park: Comfort station; Spray shower; New
playground, outdoor
playground surface; Exercise equipment for
athletic field)
seniors
11/42
DPR
Reconstruct or
We are requesting that the list itemized below
85 Bradhurst
upgrade a park or
be upgraded or installed at Jackie Robinson
Avenue
amenity (i.e.
Park: Comfort Station; Resurface two ball fields
playground, outdoor
to mitigate flooding; Playground equipment for
athletic field)
disabled youth; Exercise equipment for seniors.
We need an off-leash dog park which will
address design criteria, including size, fencing,
gates and entrances, sanitation facilities, water,
surfacing, shade, seating, agility equipment,
paths, park maintenance, supervision and
monitoring, signage, specified hours of
operation and enforcement
12/42
DPR
Reconstruct or
We are requesting that the list itemized below
W 138th St
upgrade a park or
be upgraded or installed at William McCray
and Lenox
amenity (i.e.
Playground: Playground renovation;
Ave
playground, outdoor
Resurfacing for flood prevention
athletic field)
13/42
DPR
Reconstruct or
We are requesting that the list itemized below
269 West
upgrade a park or
be upgraded or installed at Bill Bojangles
150th Street
amenity (i.e.
Playground: New benches; Resurface basketball
playground, outdoor
court and backboard
athletic field)
14/42
DPR
Reconstruct or
We are requesting that the list itemized below
2122 5th
upgrade a park or
be upgraded or installed at Courtney Callendar
Avenue
amenity (i.e.
Playground: Unisex bathroom; Landscaping;
playground, outdoor
New benches
athletic field)
15/42
DPR
Reconstruct or
We are requesting that the list itemized below
Lenox Ave
upgrade a park or
be upgraded or installed at Fred Samuel
and W 139 St
amenity (i.e.
Playground: Comfort station; Exercise
playground, outdoor
equipment for seniors
athletic field)
16/42
DOT
Repair or construct
Repair or construct new sidewalks, curbs,
new curbs or
medians, islands and pedestrian ramps. Many
pedestrian ramps
sidewalks are in bad condition and are not ADA-
accessible. We request that all pedestrian
walkways are repaired and made ADA-
accessible. In particular, the curb on West 129th
Street between Adam Clayton Powell Jr. Blvd.
and Frederick Douglass Blvd. should be lowered
and a ramp installed in order to make it
accessible for people with limited mobility.
17/42
NYCHA
Renovate or
New elevators and plumbing at Saint Nicholas
2406
upgrade public
Houses
Frederick
housing
Douglass Blvd
developments
18/42
DPR
Reconstruct or
We need an upgrade of the staff building at
7 Ave and W
upgrade a park or
Frederick Johnson Playground to include interior
150 St
amenity (i.e.
repairs
playground, outdoor
athletic field)
19/42
DPR
Other requests for
New elevator at Hansborough Recreation
35 West
park, building, or
Center
134th Street
access
improvements
20/42
DCLA
Other cultural
Community Board 10 would like to see the
facilities and
creation of a PAC that would help to solidify its
resources requests
long cultural standing in the world as a center
(Capital)
for the arts and culture.
21/42
DPR
New equipment for
We need additional maintenance equipment
maintenance
vehicles
(Capital)
22/42
DOT
Roadway
Fix bollards on Adam Clayton Powell Blvd.
Adam Clayton
maintenance (i.e.
Powell Jr. Blvd
pothole repair,
110th 155th
resurfacing, trench
restoration, etc.)
23/42
DHS
Other facilities for
a public facility that homeless will have access
the homeless
to
requests
24/42
DPR
Reconstruct or
We need the upgrades of the Colonel Charles
upgrade a park or
Young Playground ball field to a multi-
amenity (i.e.
disciplinary field that will accommodate
playground, outdoor
softball, football, soccer, rugby and Lacrosse,
athletic field)
and mitigate flooding. We need to repave the
perimeter run around the ball park to enable
walking and jogging exercises and we need to
install a grill/picnic area
25/42
DPR
Provide a new or
We need to provide a dirt bike riding facility
expanded park or
where riders can practice the sport safely
amenity (i.e.
without endangerment to community residents,
playground, outdoor
while promoting safe and responsible ridership.
athletic field)
26/42
DPR
Provide a new or
We need the installation of playground
expanded park or
amenities and equipment to assist the disabled
amenity (i.e.
youth and adult populations in CB 10
playground, outdoor
athletic field)
27/42
DPR
Provide a new or
We need to provide Port-o-Sands in interim of
expanded park or
comfort station repairs in CB 10 parks and
amenity (i.e.
playgrounds
playground, outdoor
athletic field)
28/42
HPD
Provide more
Housing Development Fund Companies
housing for
(HDFCs).During the 2017-2018 and 2016-1017
extremely low and
fiscal years, the CB10 Housing Committee
low income
focused its attention on retaining and stabilizing
households
4,936 units of cooperative housing in the
district. These resident-owned special business
corporations were created, beginning as early
as 1966, by the Article XI of the New York State
Private Housing Finance Law or the Housing
Development Fund Company (HDFC) law. The
HDFC law required all corporations organized
under the legislation to include, Housing
Development Fund Company or HDFC in its
corporations name, thus causing this low-
income housing stock to commonly be referred
to as HDFCs.
29/42
DPR
Other requests for
We need to install biographical plaques and
park, building, or
installation to commemorate park namesakes in
access
CB 10
improvements
30/42
DPR
Reconstruct or
We need to have repairs made to the Colonel
upgrade a park or
Charles Young Playground to mitigate flooding
amenity (i.e.
on the ball field
playground, outdoor
athletic field)
31/42
NYCHA
Renovate or
As evident the recent public hearings as well as
upgrade public
past and recent audits by New York City
housing
Comptroller Scott Stringer that exposed failed
developments
heating systems, unsatisfactory and dangerous
playgrounds, broken building entrance doors,
backlogged repairs, and extended vacancies,
the needs in New York City Housing Authority
(NYCHA) developments are dire and those needs
are escalating at an alarming rate. The extent of
the problem has caused the federal government
to propose appointing a federal monitor to
oversee NYCHA. It is not hyperbole for this
committee to describe conditions in some
NYCHA developments in the district as,
inhuman, where children are exposed to the
debilitating and toxic effects of mold.
32/42
DPR
Other requests for
We need the installation of a new boiler in the
park, building, or
Hansborough Recreation Center
access
improvements
33/42
DPR
Other requests for park, building, or access improvements
We need improved signage and enforcement to deter owners from allowing dogs off leashes at Colonel Charles Young Triangle
34/42
DPR
Provide a new or
We need to close the gap in the Harlem River
expanded park or
Park Bikeway and Esplanade between 145th
amenity (i.e.
and 163rd streets, We need to design and
playground, outdoor
construct the CB 10 portion of the esplanade
athletic field)
with community input
35/42
DPR
Reconstruct or
We need an upgrade of the staff building at
upgrade a building
Frederick Johnson Playground to include repairs
in a park
of the interior and the heating and cooling
systems
36/42
DPR
Provide a new or
We need dog stations installed along the
expanded park or
exterior of CB 10 parks and playgrounds
amenity (i.e.
playground, outdoor
athletic field)
37/42
DPR
Provide a new or
We need water fountains with water bottle
expanded park or
fillers in all of CB 10 parks and playgrounds
amenity (i.e.
playground, outdoor
athletic field)
38/42
DPR
Other requests for
We need ongoing landscaping and maintenance
park, building, or
for all CB10 parks and playgrounds.
access
improvements
39/42
DPR
Other requests for
We need to transfer HPD and DCAS properties
park, building, or
to the NYC Parks Department for creation of
access
green space and gardens in the vacant areas in
improvements
the district
40/42
DPR
Provide a new or
We need to reconstruct and stabilize retaining
expanded park or
walls and sea walls
amenity (i.e.
playground, outdoor
athletic field)
41/42
DPR
Provide a new or
We need to design a Harlem River Park
expanded park or
waterfront Esplanade
amenity (i.e.
playground, outdoor
athletic field)
42/42 SCA Renovate exterior
building component
renovate/upgrade playground 222 St Hope Leadership Academy, Manhattan, New York, NY
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/41
OMB
Provide more
Increase the board's budget to accommodate
community board
additional staff to deal with all the intricacies of
staff
intergovernmental affairs and participation in
the city's budget
2/41
HHC
Provide a new or
Harlem Hospital is one of Harlem's Safety Net
506 Lenox
expanded health
hospitals. It services the entire Harlem District
Avenue
care facility
as well as residents from other parts of
Manhattan and of the Bronx. We request for
more funding to be allocated to Harlem Hospital
to continue and expand its current health
services.
3/41
DSNY
Provide more
Currently CB10's litter baskets and household
frequent litter
garbage is being serviced only once a day. We
basket collection
are requesting an additional pick up each day.
4/41
DOHMH
Reduce rat
All of Harlem! Especially 125th, 135th, 145th
populations
Street corridors and Malcolm X, Adam Clayton
Powell Jr. and Frederick Douglass Boulevards
5/41
DPR
Improve trash
Community residents are, in fact, complaining
removal and
that there are rat infestations in CB10 parks.
cleanliness
Rats can be seen venturing out from the park
onto peripheral sidewalks foraging for food. Rat
burrows are prevalent and clogged water drains
in CB 10 parks provide refuge for the
proliferation of rat populations. We need a
successful and integrated approach to rodent
management in CB 10 park facilities
6/41
DFTA
Other services for
Improved outreach efforts are needed to
homebound older
identify senior citizens who are living in relative
adults programs
isolation and without their basic needs being
met, such as adequate shelter, nutritional and
utility support, are necessary. According to
reports from senior services providers, there
remain a significant number of elderly persons
in Central Harlem who are eligible for available
services but do not take advantage of them.
Identification of this at risk population is of
critical importance.
7/41
NYPL
Extend library hours
In an effort to continue to support our most
or expand and
vulnerable New Yorkers we are urging the City
enhance library
in FY19 to increase expense funding so that all
programs
neighborhoods and communities in our city
have access to a library seven days a week.
8/41
DFTA
Enhance NORC
Add additional NORC programs for the
programs and
increasing home-bound and non-home-bound
health services
seniors who are aging in place. We lost two
critical NORC program in the CB10 area
9/41
DOT
Improve traffic and
Increase pedestrian safety a. Ensure that the
pedestrian safety,
allotted time for pedestrians to cross at
including traffic
intersections is realistic. We want to make sure
calming (Expense)
that the elderly and individuals with disabilities
are able to cross at busy intersections along our
larger avenues - Malcolm X Avenue, Adam
Clayton Powell Jr., Blvd., and Frederick Douglass
Blvd. b. Build pedestrian islands.
10/41
DPR
Forestry services,
The Friends of the ACPB Malls are a volunteer
Adam Clayton
including street tree
Group that has worked in collaboration with the
Powell Jr. Blvd
maintenance
NYC Parks and Rec. Dept. since 1997. Their goal
110th St
= beautify and maintain the 42 landscaped
152nd St
Malls from 110th St. to 152nd St. They plant
bulbs in Oct. and flowering plants in May. Most
recently on 10/21/17 they oversaw the planting
several 1000s of bulbs. The Friends are
requesting $500,000. This money is being
requested for: Testing of soil, trees, and
drainage; evaluation of best plant life; a design
that would render the 42 Malls similar in
appearance; to design a barrier to discourage
walking on the Malls; to determine the cost
needed for each Mall
11/41
DPR
Other park
We need free, secure and reliable Wi-Fi service
programming
in CB 10 parks and playgrounds that provides a
requests
sufficient bandwidth to accommodate the park
traffic
12/41
NYCTA
Other transit service
The only station which will reach CB10 will be
requests
the 125th Street subway line, which will reach
Fifth Avenue and 125th Street. We recommend
to the MTA and Department of Transportation
(DOT) that they coordinate extensive
community outreach regarding the Phase 2
work extending to 125th Street.
13/41
NYCTA
Other transit service
With the start of the Harlem Bike Network, we
requests
need bicycle safety classes /workshops as well
as bike helmet giveaway events
14/41
DSNY
Increase
Sidewalks remain filthy for long periods of time.
enforcement of
Better enforcement will help keep them clean.
dirty sidewalk/dirty
area/failure to clean
area laws
15/41
NYCTA
Other transit service
Increase access-a-ride program to decrease
requests
waiting time and no shows from drivers.
16/41
DOT
Conduct traffic or
Traffic study of Manhattan Ave from 110th-
Manhattan
parking studies
122nd street
Ave 110th St
122nd St
17/41
DOT
Conduct traffic or
Traffic study of 155th Street
155th St
parking studies
Harlem River
Dr Bradhurst
Ave
18/41
DOT
Conduct traffic or
Traffic study of 145th street
145th St
parking studies
Harlem River
Dr Bradhurst
Ave
19/41
DPR
Improve the
We need staff and materials to run arts, crafts
quality/staffing of
and recreational programs for children during
existing programs
the summer months
offered in parks or
recreational centers
20/41
DPR
Enhance park safety
We need additional PEP Officers to serve
through more
Manhattan CB10
security staff (police
or parks
enforcement)
21/41
DPR
Improve the
1) We need additional staffing of park
quality/staffing of
management 2) We need staff positions for
existing programs
Playground Associates for CB 10 playgrounds 3)
offered in parks or
We need additional staffing of park seasonal
recreational centers
maintenance staff
22/41
DPR
Provide better park
Park maintenance and safety: we need
maintenance
additional maintenance staff for park comfort
stations in CB10
23/41
DOT
Add street signage
Replace dull, illegible street signs throughout
or wayfinding
the district
elements
24/41
DPR
Forestry services, including street tree maintenance
We need ongoing landscaping and maintenance for all CB10 parks and playgrounds
25/41
DPR
Provide more
We need to continue to provide programs that
programs in parks or
promote community-based, park-partnership
recreational centers
activities and events
26/41
DPR
Other park
We need to identify and pursue strategies to
programming
increase the resilience to climate change and
requests
sea level rise within the CB 10 area with respect
to the specific shoreline topography
27/41
NYCHA
Expand tenant
Third Party Transfer (TPT) Program. The Housing
protection programs
Committee has gone to considerable lengths to
assist HDFCs that are in distress: we joined
other Community Boards in calling for a
moratorium on HDFC transfers that would strip
shareholders in HDFCs of their homeownership
rights and equity; we have demanded relief for
qualified HDFCs though the Tax Amnesty
Program provided by Article XI of the State of
New York Private Housing Finance Law. We have
urged City Council and HPD to engage in case-
by-case determinations of each distressed HDFC
in the district to decide whether the TPT
program is the appropriate recourse or if other
necessary resources and interventions can make
the building sustainable.
28/41
HPD
Other affordable
Affordable Neighborhood Cooperative Program
housing programs
(ANCP) The Housing Committee is calling for the
requests (expense)
creation of more affordable homeownership
opportunities by the creation of city-owned
residential properties to resident-owned
cooperatives through the newly introduced
Affordable Neighborhood Cooperative Program
(ANCP). All of the smaller NYCHA multi-dwelling
buildings in the district represent another
untapped source of affordable home-ownership
opportunities.
29/41
NYCHA
Expand tenant protection programs
HDFC Proposed Regulatory Agreement With HPD presently developing a revised draft of its proposed regulatory agreement for HDFCs created before 2008, the Housing Committee will seize upon the opportunity these discussions around the regulatory agreement afford us to advocate for compromises that enhance the rights of shareholders in HDFCs, delineate the responsibilities of boards of directors, provide interest-free financing for HDFCs that received very little capital investment from the city at the time of conversion, and offer deeper tax exemptions, subsidies, and abatements for those HDFCs that continue to operate as providers of low-income housing.
30/41
DPR
Improve the quality/staffing of existing programs offered in parks or recreational centers
We need additional staffing of park management.
31/41
DPR
Other park programming requests
We need to support established and new community gardening stewardship and programming in CB 10 parks
32/41
DPR
Provide more programs in parks or recreational centers
We need to develop and implement programs for educational components to facilitate school and community groups to engage youth in ecological studies in CB 10 parks
33/41
DPR
Other street trees and forestry services requests
We need to provide a horticultural design that would render the 42 Malls synchronous in design appearance and include a barrier to discourage walking on the Malls
34/41
DPR
Other park programming requests
We need to promote City, State, federal, civic and private sectors partnering to advance shared goals and initiatives for the optimal balance of waterfront and waterway uses
35/41
DPR
Forestry services, including street tree maintenance
We need horticultural upgrades to Courtney Callendar Playground, Hancock Park, Lafayette Square, Samuel Marx Triangle, CB 10 area of Harlem River Park and Dorrence Brook Square
36/41
NYCHA
Other housing support requests
Supportive Housing The Housing Committee recognizes the need to focus on supportive housing in the district, and it intends to evaluate supportive housing assets in the district as well as the needs of our most vulnerable constituents in the district, many who are beneficiaries of supportive housing. The Committees investigation will include: constituents currently or previously homeless; persons with a history of substance abuse; persons living with HIV-AIDS; and persons with mental health needs among others. Seeking to achieve a broad representative scope through the committees investigation, we will also examine the supportive housing needs of veterans, artists, musicians, persons with current or prior justice system involvement, persons under parole or probation supervision, person
37/41
DPR
Forestry services, including street tree maintenance
We need the installation of an embedded irrigation system in the Malls and we need to correct poor Mall drainage, trim overgrown bushes and replace deficient soil.
38/41
DPR
Other park programming requests
We need a listing and mapping of all vacant lots in CB 10
39/41
DPR
Enhance park safety through design interventions, e.g. better lighting (Expense)
We need to enhance lighting for Colonel Charles Young Triangle
40/41
DPR
Other park programming requests
We need to require that DPR continue to implement outreach and advertising of existing programs in CB 10. We need to require that DPR continue to strengthen education for volunteers who participate in community-based programs in CB 10 parks. We need to require that DPR continue to strengthen and improve the structure, procedures and processes of community-based volunteer programs for CB 10 parks
41/41 NYCHA Expand tenant
protection programs
The Housing Committee partnered with and supported residents in the Tenant Interim Lease (TIL) program in their fight to avoid removal from the Tenant Interim Lease (TIL) Program, by assisting these residents with skills-building resources to improve compliance with financial reporting, rent collection, and annual elections. It is important to note that the overarching objective of the TIL program was to provide tenants with the education and technical training to convert these city-owned rental properties to HDFC cooperatives. In 2008, HPD stopped actively developing and converting its TIL buildings to HDFCs. This policy essentially reduced the thriving TIL program into a stagnant holding company consisting of roughly 125 buildings citywide.
image

