- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 9 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/16SnrkyxjbcN9d5iHaAuyQH0s1Bpcz5Gy/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/16SnrkyxjbcN9d5iHaAuyQH0s1Bpcz5Gy/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
9
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 9
image
Address: 16-18 Old Broadway Phone: (212) 864-6200
Email: info@cb9m.org
Website: www.cb9m.org
Chair: Hon. Barry Weinberg District Manager: Eutha Prince
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Manhattan Community Board No. 9 is made up of several distinct neighborhoods: Hamilton Heights, Manhattanville, Morningside Heights, and a small portion of Central Harlem. Our district runs from 110th Street to 155th Street. Our eastern border runs along Manhattan/Morningside Avenues, St. Nicholas/Edgecombe and Bradhurst Avenues, and the Hudson River is our western border. Each neighborhood is a distinct community.
Morningside Heights in the southern portion of the Board contains many of the area’s numerous institutions: Cathedral Church of St. John the Divine. Bank Street College of Education, Columbia University, Barnard College, Teacher's College, Manhattan School of Music, Union Theological Seminary, Jewish Theological Seminary, The National Council of Churches, Riverside Church, Grotto of Notre Dame, and the Mount Sinai St. Luke's Hospital Center. Morningside Heights itself is an extremely diverse area and is anchored at the northern end by the General Grant Houses NYCHA development and the former limited-equity cooperative Morningside Gardens. Real estate in Morningside Heights is overwhelmingly owned by the aforementioned institutions, with the remaining parcels generally belonging to private co-ops, with a small cluster of rent-stabilized, non-institutionally-owned rental buildings in the northwest area of the neighborhood around Tiemann Place, La Salle Street, and Claremont Avenue. Morningside Heights has recently been the site of battles fought with Institutions selling property to developers who then build luxury condominium or rental towers “as of right” that are out of context with no height limits under current zoning. A grassroots movement has erupted to finally form a study to rezone the area of Morningside Heights (30 years fought) and put limits on the height and context of buildings in this portion of the district.
Manhattanville begins at roughly 123rd Street and extends northward to 135th Street. This area includes the south campus of the City College, part of the City University of New York; the Manhattanville Houses NYCHA development; Riverview Towers/Riverside Community Housing at 3333 Broadway, (a former Mitchell-Lama rental building), and a number of small commercial establishments. Manhattanville is also the site of Columbia University’s new campus, which is currently under construction in an area formerly inhabited by light manufacturing businesses.
Manhattanville is also home to the District’s largest concentration of non-institutional commercial office space in the Manhattanville Factory District, comprising an area east of Amsterdam Avenue and west of Convent
Avenue between W 125th and W 130th Streets.
The northernmost section of Community Board No. 9 is comprised of Hamilton Heights (which includes the "Hamilton Heights/Sugar Hill Historic District". Hamilton Heights is home to a substantial number of owner- occupied brownstones and also includes the Audubon Houses NYCHA development and a large number of Housing Development Fund Cooperatives. There are very few vacant structures. The majority of the small businesses in this area are operated by a diverse group, including Hispanic/Latino, Middle Eastern, Caribbean, and Asian owner/operators. Hamilton Heights is also home to the North River Pollution Control Plant with the Riverbank State Park on its roof. Hamilton Heights and Manhattanville also abut St. Nicholas Park, the site of the Alexander Hamilton House.
The unique topography and history of these areas, partially separated from the rest of Upper Manhattan by a series of bluffs on its eastern end (St. Nicholas Park and Morningside Park) helps to create an eclectic and historic area with its own distinct character.
We are proud of our neighborhoods and are committed to maintaining them and ensuring that our neighbors will be afforded an excellent quality of life.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 9
image
The three most pressing issues facing this Community Board are:
Affordable housing
The need for affordable housing has become a major problem for low, medium and middle-income families. A significant portion of Manhattan Community Board No. 9 (MCB9) renter households is under a financial burden to pay rent. Technically, this includes households who have to use 30% or more of their income towards rent. In 2017, 25% of all CB9 households were “moderately rent-burdened”, paying 30% or more of their income towards rent.
Among those considered “Severely rent-burdened”, paying 50% of their income on rent, the situation turns much worse with 30% of all CB9 households in this category. Even worse, among our low-income population this number increases to 48% of households. As a result of the expiration of public subsidy contracts for affordable housing, and of rapid private development, long-term residents of public and rent-regulated and subsidized housing face the threat of displacement. River View Towers and Riverside Park Community is a recent example of a lost Mitchell Lama property with over 2,000 apartments we encourage the City to take all steps necessary to protect NYCHA, HPD and Mitchell-Lama properties from privatization. The privatization of the properties would render many residents homeless. MCB9 is also home to many buildings still in the Tenant Interim Lease program. Tenants in these City- owned buildings gave up their rent regulated leases in exchange for a commitment from the city to repair the buildings and sell the apartments to the tenants for $250. The City must fulfill its commitment to these tenants by repairing these buildings and allowing them to become shareholders without having the building shoulder an enormous debt burden, as is the case with the Affordable Neighborhood Cooperative Program.
Crime
Crime continues to be a problem for Community District 9, particularly in the areas of Manhattanville and Hamilton Heights covered by the 30th Precinct. There were approximately 9 shooting incidents recorded in a 52 week span available in the most recent data in Compstat 2.0, and several additional shootings have occurred in calendar year 2019. Narcotics trafficking and distribution, including cocaine and heroin, continue to drive incidents of violence in the neighborhood. Additional intervention in the form of social supports, anti-gang programming, and mental health resources in local schools is required to both cope with and help end these issues.
Unemployment
Unemployment in West Harlem has been hard hit like many other communities during these tough economic times. Unemployment is high and new jobs are scarce. Recent employment data from the Bureau of Labor Statistics and City Planning indicate an unemployment rate of 3.9 % for New York City in general and slightly higher than the national average; however, among peoples of color, the percentage is reportedly much higher. Most of our residents still commute outside of the area for jobs and we still have a high illiteracy rate in English and Spanish that limits employment opportunities for residents.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 9
image
M ost Important Issue Related to Health Care and Human Services
Other
Manhattan Community Board No. (MCB9) requests that additional inspectors be assigned to our district. We have been concerned for many years about the quality of our drinking water and request that DEP view this as a priority. The current number of inspectors in our area do not have the capacity to handle the level of complaints that have been recorded within our community by 311. MCB9 requests and expedited delivery of new equipment as well as coordinated training of the staff during emergencies at the Sewage Treatment Plant. As we have observed over the years, it is time to replace and upgrade existing equipment and evaluate and implement needed precautions to prevent a possible catastrophe. The air quality needs to be monitored consistently and evaluated for risks to the health of our community.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
New York City Department of Health launched TAKE CARE NEW YORK 2020 which provides a health profile for every community board in New York City. As a result, the community boards have a statistically driven idea of what our health issues are in comparison to the rest of the city. MANHATTAN COMMUNITY BOARD 9 (MCB9) ranked 10th in the City for people who are returning home from incarceration. MCB9 ranked in the top twenty-five percent for people who suffer from diabetes and obesity, ranked third in the city for people who needed Medical Care but went without. MCB9 currently has the highest childhood asthma rate in NYC as a whole and Manhattan. Solutions: Fund Reentry programs that have a holistic approach to assist people returning into the community; Fund programs geared toward obesity prevention by reaching out to community groups with programs; Fund outreach to people who have no insurance by going to unemployment offices, welfare offices, and food drives; Fund outreach to schools to provide asthma education training to caregivers in the school; MCB9 has a deficit of health care providers within the community. There needs to be more community-based providers and primary care physicians, MCB9 currently has very few; with Mt. Sinai West being the only Hospital in our district. There should be funding for health care offices on the street level that is accessible to everyone, those with insurance and without.
MCB9 is in need of having the Manhattanville Health Station reopened at full capacity. For almost a decade, Manhattanville Health Station remains closed and there has been no clear plan presented as to when we can expect to see the center rehabilitated. Programs originally on site have been relocated to other facilities and areas leaving a major gap in services for this area.
Needs for Older NYs
The elderly population in Manhattan Community Board No. 9 (MCB9) is increasing. During this time of budget constraints, we must not lose sight of the special needs of our seniors, it is imperative that long-range comprehensive planning includes housing, health and mental care, home care and senior centers. Only in this way can we ensure the continued quality of life and prevent the isolation, which places many of our elderly at risk of poor health, unacceptable living conditions, poor nutrition and inaccessible services. There is also a need for Programs that support Aging Artist Support and Establish Artists-in-Residence program at Senior Centers. 1.
Increase accessibility to subway and buses for Seniors and the handicapped 2. Increase in low-income Housing for Seniors and the handicapped
Needs for Homeless
No comments
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
5/30
DOHMH
Reduce mosquito
Continue funding to eliminate (reduce)
populations
mosquitos, and bedbugs.
8/30
DHS
Expand street
Dedicated outreach personnel for consistent
outreach
relationship building outreach to homeless in
CD9.
14/30
HRA
Other request for
+Mayor's Office of Immigrant Affairs; Increase
services for
funding for outreach programs dedicated to
vulnerable New
immigrants in an effort to raise awareness and
Yorkers
address safety issues, with dedicated outreach
to LGBTQ immigrants.
26/30
DOHMH
Other animal and
Increase funds for Pest Control and Rats within
pest control
CD9.
requests
29/30
HRA
Provide, expand, or
Maintain funding for job training and placement
enhance job search
for adults within CD9
and placement
support
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 9
image
M ost Important Issue Related to Youth, Education and Child Welfare
Educational attainment
Manhattan Community Board No. 9's (MCB9) Social Service programs and community services are vital to our district residents, and we have seen many successful implementations of these programs physically located in school buildings. Social Service "wraparound" programs help both the students in our community and their family members to cope with the challenges they face in their daily lives. Our committee desires to have funds allocated for support services to better the lives of all citizens, such as English literacy courses; mental, dental, and eye health providers and job training and placement programs. MCB9 has a significant population of homeless students. Our community requests to have funds allocated to addressing the specific needs of homeless children: providing students with clothing, counseling, support services, etc. to help them cope with the stresses of being without a permanent home.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
(MCB9) is in need of adequate physical space for existing schools in light of the co-location of many DOE and charter schools in DOE buildings. Colocation limits the physical space that is available for schools to use for physical education and play space (gyms), arts programming (required arts curricula: music, dance, visual arts, theatre), and adequate provision of special education services as required by law. Relatedly, many buildings are serving a different age range than they were originally designed for, so facilities like desks and bathrooms are inappropriate for the physical needs of current students. We request a major part of the budget for the development of physical space in existing public schools. MCB9 also needs adequate wireless internet and computer technology access in schools and in students’ homes, so that students can learn to use these important twenty-first-century tools and so that they can use them to support and enhance their other academic studies. Especially with curricular changes emphasizing STEM and computer science for all, it is essential that schools have the technology infrastructure, including high- speed internet bandwidth, to support laptop/tablet use in classrooms. MCB9 is concerned about the possibility of the presence of lead in school water fountains. We are not satisfied with the city’s level of testing or communication with families about the extent of the problem or possible risks. We request funding for more water testing and mitigation. In Addition Having a special needs program, year-round, within the borderlines of MCB9 is crucial to the development of our community. The special needs population is significant and growing. Yet there aren’t many local programs out there. Most therapists and behavioral counselors only accept Medicaid or out of pocket payments.
There is a growing number of working-class families that make too much to qualify for free programs or too little to afford specialty special needs care within MCB9.
Needs for Youth and Child Welfare
Manhattan Community Board No. 9's (MCB9) Social service programs and community services are vital to our district residents, and we have seen many successful implementations of these programs physically located in school buildings. Social service “wraparound” programs help both the students in our community and their family members, to cope with the challenges they face in their daily lives. Our committee desires to have funds allocated for support services to better the lives of all citizens, such as English literacy courses; mental, dental, and eye health providers; and job training and placement programs. MCB9 has a significant population of homeless students. Our community requests to have funds allocated to addressing the specific needs of homeless children: providing students with clothing, counseling, support services, etc. to help them cope with the stresses of being without a permanent home.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
3/44 SCA Provide a new or
expand an existing high school
Design and construct an Arts, Sciences, and Trades High School, of which 75-85 of students shall derive from low-income families within CD9
image
CS SCA Provide a new or expand an existing elementary school
Continue funding to design and construct a school K-8 within CD9 to eliminate the existing over crowding throughout CD9.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/30
DYCD
Provide, expand, or
Increase funding for existing and needed
enhance after
academic arts and mentoring after school
school programs for
programs through grades 8-12 within CD9.
middle school
students (grades 6-
8)
12/30
DOE
Other educational
Provide funding for development of culturally
programs requests
sensitive curriculum, for use within CD9 schools
in cooperation with the Community Education
Councils for Districts 5, and 6 recognizing the
historical contributions of figures, movements,
and more from diverse set of communities
within CD9, including African American,
Caribbean, Latino, and LGBTQ communities.
15/30
ACS
Increase support for
In light of the ongoing difficulties facing our
juvenile justice staff
community youth, funds are needed to be
allocated to helping our young citizens acquire
skills to understand their civil rights and how to
cope with any legal issues they may be face.
18/30
ACS
Provide, expand, or
Provide funding for supported housing for aged-
enhance housing
out youth within foster care facilities
assistance for youth
throughout the borough of Manhattan.
that are leaving
foster care
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 9
image
M ost Important Issue Related to Public Safety and Emergency Services
Police-community relations
The Police Department has the Neighborhood Coordination Officers, or NCO's, who are our local problem solvers. They spend all their working hours within the confines of the 26th and 30th Precincts, assigned sectors, and actively engaging with local community members and residents. They get to know the neighborhood, its people, and its problems extremely well. The Neighborhood Coordination Officers (NCO) program is broken down in the following
(3) units: Sectors A(Adam), B(Boyd), and C(Charlie).
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The Police Department has the Neighborhood Coordination Officers, or NCOs, who are our local problem solvers. They spend all their working hours within the confines of the 26th and 30th Precincts, assigned sectors, and actively engaging with local community members and residents. They get to know the neighborhood, its people, and its problems extremely well. The Neighborhood Coordination Officers (NCO) program is broken down in the following
(3) units: Sectors A, B, and C
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
29/44
NYPD
Provide a new NYPD
Allocate funds to renovate and repair the 30th
451 West 151
facility, such as a
Precinct and include ADA compliance.
St
new precinct house
or sub-precinct
36/44
NYPD
Add NYPD parking
Restore funding to improve NYPD parking
facilities
facilities including additional parking, and
structural maintenance
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
9/30
NYPD
Other NYPD
Increase and continue funding and staff for
programs requests
NYPD's LGBTQ Outreach Unit at the 26th & 30th
Pct. to have at least one dedicated LGBTQ
outreach officer to provide continuing education
to officers in the precinct on sensitive and
appropriate police interactions with the LGBTQ
community and to work together with other
community affairs staff to increase public safety
outreach, presentation, and collaborations with
members of the LGBTQ community in CD9.
21/30
NYPD
Assign additional
Allocate funds for additional Officers in the
520 West 126
uniformed officers
NYPD Lesbian, Gay, Bisexual, and Transgender
St
Liaison unit to be stationed at the 26th Pct.
22/30
NYPD
Assign additional
Allocate funds for additional Officers in the
451 West 151
uniformed officers
NYPD Lesbian, Gay, Bisexual, and Transgender
St
Liaison unit to be stationed at the 30th Pct.
23/30
NYPD
Assign additional
Provide funding for Housing Bureau police.
housing police
officers
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 9
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Environmental concerns affecting citizens
Manhattan Community Board No. 9 (MCB9) requests that additional inspectors be assigned to our district. We have been concerned for many years about the quality of our drinking water and request that DEP view this as a priority. The current number of inspectors in our area does not have the capacity to handle the level of complaints that have been recorded within our community by 311. MCB9 requests an expedited delivery of new equipment as well as coordinated training of the staff during emergencies at the Sewage Treatment Plant. As we have observed over the years, it is time to replace and upgrade existing equipment and evaluate and implement needed precautions to prevent a possible catastrophe. The air quality needs to be monitored consistently and evaluated for risks to the health of our community.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
While most of the drastic Sanitation cutbacks were restored, this is not enough to improve the quality of life in our community. This is especially true north of West 125th Street. The staffing does not reflect the actual tonnage of garbage handled by Community Board 9 Sanitation Crews. Pick-ups along the Commercial Strips of Broadway, Amsterdam Avenue (W 135th – W 155th Streets), and 125th Street cannot keep up with utilization. We urge the City to increase staffing to facilitate three pickups per day in these locations. There is a need for more garbage cans due to the rat infestation. For Vacant Lots and trouble locations, we need the Clean Team Restored. Recycling figures have greatly improved. We need, if not increased, consistent Sanitation Enforcement in our area, MCB9 has recommended an increase of Enforcement Officers in the afternoon when violations are at their peak. MCB9 believes the health and integrity of our community MUST be a top priority.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
6/30 DSNY Provide more on-
street trash cans and recycling containers
Provide funds for Solar powered compacting "Big Belly" waste receptacles in areas with a history of rodent infestation.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 9
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
The need for affordable housing has become a major problem for low, medium and middle-income families. A significant portion of Manhattan Community Board No. 9 (MCB9) renter households are under a financial burden to pay rent. Technically, this includes households who have to use 30% or more of their income towards rent. There are concentrations of such households where almost half the households are “rent-burdened.” MCB9 also has 23% of its residents paying more than 50% of their income in rent. With this being the case renters face even greater challenges of increases nearing 55% (or more) of their incomes. As a result of the expiration of public subsidy contracts for affordable housing, and of rapid private development, long-term residents of public & rent-regulated & subsidized housing face the threat of displacement.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Manhattan Community Board No. 9 is made up of several distinct neighborhoods, Hamilton Heights, Manhattanville, Morningside Heights and a portion of Central Harlem. Our district runs from 110th Street to 155th Street. Our Eastern border runs along Manhattan/Morningside Aves, St. Nicholas/Edgecombe and Bradhurst Aves and the Hudson River is our Western border. Each neighborhood is a distinct community; Morningside Heights in the southern portion of the Board contains many of the area’s numerous institutions: Cathedral Church of St. John the Divine. Bank Street College of Education, Columbia University, Barnard College, Teacher's College, Manhattan School of Music, Union Theological Seminary, Jewish Theological Seminary, The National Council of Churches, Riverside Church, Grotto of Notre Dame, and the Mount Sinai St. Luke's Hospital Center. Morningside Heights reflects great diversity at the southern end where two large housing complexes: The General Grant Public Housing Development and Manhattanville Housing Development; there is also the limited equity cooperative Morningside Gardens are nestled between major retail areas. Manhattanville begins at roughly 123rd Street and extends northward to 135th Street. This area includes the City College south campus of City University of New York, the Manhattanville Housing Development, Riverview Towers/Riverside Community Housing at 3333 Broadway, (a former Mitchell-Lama cooperative), and a number of small commercial establishments. Manhattanville is the site of Columbia University’s new Campus, which is currently under construction. The northernmost section of Community Board No. 9 is comprised of Hamilton Heights (part of this area is designated the "Hamilton Heights/Sugar Hill Historic District"). Hamilton Heights is home to a substantial number of owner-occupied brownstones and also includes the City-owned Audubon Houses and a large number of Housing Development Fund Cooperatives. There are very few vacant structures. The majority of the small businesses in this area are operated by a diverse group, including Hispanic/Latino, Middle Eastern, Caribbean, and Asian. Hamilton Heights is also home to the North River Pollution Control Plant with the Riverbank State Park on its Roof. These three neighborhoods which encompass St. Nicholas Park, the new home of the Alexander Hamilton House create an eclectic and historical area. We are proud of our neighborhoods and are committed to maintaining them and ensuring that our neighbors will be afforded true Quality of Life.
Needs for Housing
Manhattan Community Board No. 9 (MCB9) seeks to preserve and create affordable housing of various types-- NYCHA, rent stabilized, rent controlled, coops/condominiums, HDFCs, TILs and 1-4 family townhouses. We also seek to have community input in development projects big and small--particularly any plans for "soft" development sites. Having a designated planner available to the HLUZ committee and the board, in general, would help greatly in this regard.
Needs for Economic Development
West Harlem has been hard hit like many other communities during these tough economic times. Unemployment is high and new jobs are scarce. Recent employment data from the Bureau of Labor Statistics and City Planning
indicate an unemployment rate of 5.0 % for New York City in general and lower than the national average; however, among peoples of color, the percentage is reportedly much higher. The southern portion of our district has been more fortunate with only a few closings and a number of those vacant spots have new tenants building out those spaces. Our northern district has seen an increase of fast food establishments and communication stores like Metro PCS that can pay higher commercial rents limiting space for small “mom and pop” stores. We still believe that it is in everyone’s best interest to support more retail business and professional office spaces where appropriate in our community. Our community has certain advantages that could be attractive to new business owners. We have large sidewalks and boulevards. This distinct feature can lend itself for future street fairs, promotional events and art installations that could attract residents, tourists and fellow New Yorkers to our community.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/44
HPD
Other affordable
PROVIDE AND EXPAND AFFORDABLE HOUSING
housing programs
UNITS THROUGH ALL AVAILABLE PROGRAMS
requests (capital)
INCLUDING WORKSPACE FOR ARTISTS (I.E.
DAMP. TIL. LISC/ ENTERPRISE. SIP AND LOW-
INTEREST LOANS) AGENCY: HOUSING
PRESERVATION
2/44
HPD
Other affordable
Provide funding for repairs and renovations of
housing programs
Tenant Interim Lease Buildings
requests (capital)
5/44
NYCHA
Renovate or
Provide funding for exterior, interior, and
upgrade public
structural architectural renovations and repairs
housing
to Manhattanville Houses.
developments
6/44
HPD
Provide more
Restore funding of Section 202 Program for
housing for seniors
Senior Citizen housing
15/44
NYCHA
Renovate or
Provide funding for exterior Interior and
upgrade public
structural architectural renovations and repairs
housing
to Audubon Housing Development.
developments
20/44
HPD
Expand loan
Allocate funding for low-interest loans for
programs to
HDFC's to be used for repairs and facility
rehabilitate multiple
upgrades.
dwelling buildings
28/44
NYCHA
Renovate or
Allocate funds to maintain an Outdoor Reading
518 West 125
upgrade NYCHA
Garden on the Westside of the George Bruce
St
community facilities
Library. (Parcel of Open Space adjacent West of
or open space
518 W. 125th Street)
34/44
HPD
Provide more
Provide funding to construct more affordable
housing for seniors
Senior housing within CD9
35/44
HPD
Other affordable
Provide funding for tax incentives to developers
housing programs
to include art spaces (rehearsal/performance
requests (capital)
and visual arts work space) in their building
CS
NYCHA
Install recycling
Maintain funding for recycling facilities at
facilities at NYCHA
NYCHA developments within CD9.
developments
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
7/30
DCP
Study land use and
Provide funding for rezoning study for
zoning to better
Morningside Heights.
match current use
or future
neighborhood
needs
10/30
HPD
Other affordable
Provide funding to train skilled professional tech
housing programs
assistance to struggling HDFC's within CD9.
requests (expense)
11/30
HPD
Provide, expand, or
Increase funding for community-based tenant
enhance community
protection groups to educate tenants about new
outreach on HPD
rent laws and assist with legal representation.
programs and
services
16/30
EDC
Other public
Provide funding for HHAP Program that aims to
housing
improve the health & well-being of NYCHA
maintenance,
residents. Health workers are requested from
staffing and
the local community to offer health information
management
on asthma, diabetes, and high blood pressure.
requests
24/30
EDC
Other public
Allocate funds to hire or reinstate security
housing
personnel for NYCHA developments.
maintenance,
staffing and
management
requests
25/30
EDC
Other public
Continue funding for maintenance staff to
housing
control garbage and refuse.
maintenance,
staffing and
management
requests
30/30
SBS
Other expense
Maintain Funding for Job Training and
workforce
Placement for Adults within CB9
development
requests
TRANSPORTATION
Manhattan Community Board 9
image
M ost Important Issue Related to Transportation and Mobility
Other
Manhattan Community Board No. 9 residents need availability of convenient and reliable Mass Transportation, Manhattan Community Board No. 9 (MCB9) residents need availability of convenient and reliable mas transportation. They need subways and buses that deliver them to their place of employment on time. The Failure of the MTA to increase services that correspond with the 15% growth in mass transit utilization causes delays that make our residents travel more difficult. The M4, M5 & M104 should be extended service; however additional buses are needed on a regular basis especially on the M4 line. MCB9 is also in the need for bus pads along the route of Amsterdam Avenue. Broadway and 125th Street has become heavily congested. Given the many different objects of the drivers entering the intersection, it has become increasingly hazardous. Vehicular Congestion/Personal Injury: No further removal of vehicular traffic lanes.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 9
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
The Preservation of Landmarks and revival of Parks within the Manhattan Community Board No. 9 (MCB9) district is ever more pressing needs for the district today than in the past. Along with the current plans outlined by our city agencies to improve the 175 acres of city parkland and preserve the character of West Harlem with its 27 designated landmarks and 3 historic districts, the request outlined below details specific items in which NYC agencies can reference as areas of major concern for the MCB9 district of Manhattan Landmarks Preservation and Parks needs. Following the statistical trends of our area and desires of MCB9 of Manhattan stakeholders, our budget requests address the need for increased park enforcement, the rehabilitation of park infrastructure, increased support for the Landmark Preservation Commission and other preservation initiatives. Our goals are to have safe green-spaces available and equipped to serve Harlem's growing population of 111,645 people as of 2015, up 5% since the late 1990's and to properly identify & support all qualifying landmarked structures and areas within MCB9.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
PEP Officers: Our district’s need for safe and usable parks requires that park regulations are enforced. We have an acute need for additional Parks Enforcement Patrol (PEP) Officers to carry out this task. Dedicated PEP officers have been provided for the West Harlem Piers Park but our other parks including Upper Riverside, Morningside, St.
Nicholas and Montefiore Parks are woefully understaffed in this regard;
Needs for Cultural Services
Preserving and expanding support and cultural opportunities to all ethnic and cultural groups in our community ranked highest on our needs list, as we discussed the issues most important to the arts and cultural community of Manhattan Community Board Nine (MCB9). Local arts and cultural organizations need: • tools to collectively respond to economic challenges as they arise; • technical support to integrate and improve fundraising and marketing initiatives; • leadership and advocacy training are needed to educate the next generation of arts support and service delivery entrepreneurs; Manhattan Community Board No. 9 needs to identify ways to: • increase capacity; • improve outreach; • implement structural changes in such a way that we are prepared to meet fiscal challenges that force closings and curtailments. In this way, we are not simply reacting to each situation on a case by case basis without having a pre-established structure; In addition, MCB9 strongly supports the utilization of the arts and art appreciation as a means of community engagement, development, and empowerment. Finally, arts and cultural organizations frequently require designated spaces for performances, exhibitions, and installations, and as such are threatened by the growing lack of affordable space in our district. MCB9 needs newly dedicated arts and cultural spaces in our district to deal with the currently unmet demand for such spaces. Also, MCB9 needs support for existing spaces which sustainability is threatened by rising costs and other pressures. MCB9 also wants to acknowledge our community’s history as a center of artistic and cultural innovation and encourage identification preservation, and restoration of historic theaters, other cultural sites, and artistic venues.
Needs for Library Services
Public Libraries provide our community with substantial educational support, not only for current K-12 students but also for parents, families with young children, English language learners, job seekers, and more. Libraries provide access to reading material, technology equipment, and educational programs (homework help, literacy programs, etc.). Manhattan Community Board No. 9 (MCB9) requests that a portion of the allocated funds be distributed to the libraries located within the MCB9 district to allow them to maintain staffing, increase days/hours of service, and increase the variety of programming and audiences they serve. Two libraries within MCB9 (George Bruce and Hamilton Grange) also have specific capital facilities needs. These libraries have unused custodial apartments that
should be converted into usable library space. In both cases, some additional construction is required, chiefly to add elevator service to make the new space ADA compliant. Libraries could use this to provide warm and inviting spaces for teenagers, or additional classrooms in order to provide more regularly scheduled programming.
Needs for Community Boards
Manhattan Community Board No. 9 is requesting the Board's budget be increased. Given the size of our budgets, the cumulative effect of previous budget cuts, combined with those proposed and the increasing population in the district, any further cuts would minimize the effectiveness of the Community Board.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
4/44
DCLA
Other cultural
Provide funds to create a theater and Multi-
facilities and
Culture Center for Hamilton Theatre at 3560
resources requests
Broadway, NYC 10031
(Capital)
7/44
DPR
Reconstruct or
Provide funding to renovate Alexander Hamilton
West 140th &
upgrade a park or
Playground at Hamilton Place.
West 141st
playground
Streets
8/44
DPR
Reconstruct or
Provide funds to renovate St. Nicholas Park
W. 140th &
upgrade a park or
Playground.
St. Nicholas
playground
Ave.
10/44
DPR
Improve access to a
Allocate funding to renovate the Jacob Schiff
bet. West
park or playground
playground on Amsterdam Ave.
136th St. - W.,
138th Streets
13/44
DPR
Provide a new or
Provide funding for public comfort stations at
expanded park or
Morningside Park, St. Nicholas Park, Audubon
amenity (i.e.
Park @W. 155th St. and West Harlem Piers Park.
playground, outdoor
athletic field)
16/44
DPR
Reconstruct or
Provide funds to renovate the Croton Aqueduct
West 119 St
upgrade a building
Gatehouse at 119th Street and Amsterdam Ave.
and
in a park
to a Community and Cultural Facility.
Amsterdam
Ave
18/44
DPR
Other requests for
Allocate Funds to complete the rebuilding of
park, building, or
stairs at 133rd Street in St. Nicholas Park, repair
access
and rebuild stairs at 140th and 129th Street (St.
improvements
Nicholas Park); as well as improve lighting in
ALL locations.
19/44
BPL
Create a new, or
Provide funds to replace windows with energy
renovate or upgrade
efficient windows at Hamilton Grange Library.
an existing public
library
21/44
BPL
Create a new, or
Provide funds to replace windows with energy
renovate or upgrade
efficient windows at Hamilton Grange Library.
an existing public
library
22/44
DPR
Reconstruct or upgrade a park or playground
Provide funding for turf renovation playground renovation, security upgrades and stadium lighting at Annunciation Park.
30/44
DPR
Reconstruct or
Provide funds for sidewalk and pathway
upgrade a building
replacement in and around playgrounds and
in a park
athletic courts.
31/44
DPR
Provide a new or
Provide a new or expanded Park or Amenity (i.e.
expanded park or
Playground, Outdoor Athletic Field)
playground
32/44
NYPL
Create a new, or
Allocate funds to build-out unfinished space in
503 West 145
renovate or upgrade
the basement behind staff lounge and
St
an existing public
community room. Buildout is needed to create
library
600 sq.ft. classroom for OST. work will include
new HVAC system, new lighting and power, and
security system
33/44
DPR
Reconstruct or
Allocate funds to create a "New Entrance" to St.
upgrade a park or
Nicholas Park
amenity (i.e.
playground, outdoor
athletic field)
CS
DPR
Enhance park safety
Continue Funding to provide lighting along bike
through design
path as well as other safety measures along
interventions, e.g.
Riverside Park (Waterfront) bike path from
better lighting
110th Street to St. Clair's Place, and Cherry
(Capital)
Walk.
CS
DPR
Other requests for
Provide funds to maintain sidewalks along the
Riverside
park, building, or
North and Southbound corridor of Riverside
Drive West
access
Drive (bet. Grant's Tomb and the 125th St.
122 Street
improvements
Viaduct).
West 125
Street
CS
DPR
Improve access to a
Provide funds to complete the rebuilding of
park or amenity (i.e.
stairs at 133rd St. (St. Nicholas Park), repair and
playground, outdoor
rebuild stairs at 140th and 129th St. (St.
athletic field)
Nicholas Park), and 114th Street on the upper
level of Morningside Park.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/30
OMB
Other community
Maintain and Increase budget for ALL
board facilities and
Community Boards.
staff requests
3/30
NYPL
Extend library hours
Maintain funds to continue six-day service
or expand and
including increased hours, programming,
enhance library
collections, and sufficient staff to support theses
programs
functions.
17/30
DPR
Other street trees
Provide funds needed for pruning trees
and forestry
throughout parks, plazas and community
services requests
gardens to deter illegal activity within CD9.
20/30
DPR
Enhance park safety
Allocate funds to hire six full-time park workers
through more
for Morningside Park, St. Nicholas Park &
security staff (police
Montefiore Park and plaza, and Riverside Park.
or parks
Increase the number of Parks Enforcement
enforcement)
Patrol Officers, Foot/Bicycle/Cars assigned to
fixed patrols within CB9 specifically in high-
crime areas.
28/30
DPR
Other park
Fund six full-time park workers (CPW's for
maintenance and
Morningside, St. Nicholas/Montefiore, Riverside
safety requests
Parks).
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
9/44
Other
Other capital budget
HPD - Increase funding for Senior Citizen home
request
assistance program low interest/no interest
loans for senior home owners
11/44
Other
Other capital budget
EDC-Provide funds to purchase, lease or
request
otherwise obtain space for an Artisan Market
12/44
Other
Other capital budget
Provide funds to acquire Marime the old SRO at
request
611 West 112th Street as potential SGL/LGBTQ
Senior Housing
14/44
Other
Other capital budget
Provide funds to fully repair damaged Sewer
12th Ave.
request
lines and fix drainage issues repair sinkhole,
West 135th
replace eroded soil under 12th Ave., repave
Stret West
12th Ave., and construct sidewalks on the east
138th Street
and west sides of 12th Ave.
17/44
Other
Other capital budget
Provide funding to construct more supportive
request
housing within CD9.
23/44
Other
Other capital budget
Provide funding to complete the rebuilding of
request
stairs at 114th and 122nd Streets and improve
lighting in all locations.
24/44
Other
Other capital budget
Provide funds to renovate playground in front of
1299
request
Grant Houses Day Care Center
Amsterdam
Avenue,
Manhattan,
New York, NY
25/44
Other
Other capital budget
Provide funding incentive to developers for
request
affordable housing for artists.
26/44
Other
Other capital budget
Allocate funds to renovate baseball field at
112th St.
request
Morningside Park.
@Morningside
Drive,
Manhattan,
New York, NY
27/44
Other
Other capital budget
Provide funding to renovate Dog Run in
West 142nd
request
Riverside Park.
Street
37/44
Other
Other capital budget request
Continue funding for installation of security cameras and improved front door security for Manhattanville, Grant, and Audubon Houses.
38/44
Other
Other capital budget
Maintain funding for Recycling Facilities in
request
NYCHA Developments within CD9
39/44
Other
Other capital budget
Allocate funds for low-interest/no interest loans
request
for Mitchell-Lama repair loans to Mitchell Lama
buildings for Capital repairs.
40/44
Other
Other capital budget
Provide funds for the inclusion of Speed Bumps,
110th Street
request
Special Signage, Traffic signals, and/or
to St. Clair's
strategically placed bollards (needed to protect
Place
pedestrians from speeding bicyclists) at the
Cherry Walk - Riverside Park Waterfront bike
path.
41/44
Other
Other capital budget
Provide funding to support the development of
request
a location to support training for Trade
positions, Entrepreneurial growth and other
needs for the formerly incarcerated population.
42/44
Other
Other capital budget
Provide funds for the inclusion of Speed Bumps,
request
Special Signage, Traffic Signals, and/or
Strategically placed Bollards (needed to protect
pedestrians from speeding bicyclists) at the
Cherry Walk - Riverside Park Waterfront Bike
Path from 110th Street to St. Clair's Place.
43/44
Other
Other capital budget
Provide funding for libraries within CD9 to
request
upgrade and maintain building facilities
44/44
Other
Other capital budget
Provide funding for community-based
request
emergency housing facilities assigned to the
emergency housing needs of the LGBTQ
homeless youth and transgender community.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
4/30
Other
Other expense
DYCD - Provide funding to facilitate a youth
budget request
outreach effort which will allow opportunities to
connect children and their families with
necessary resources: youth programs,
internships, health clinics, job training and
placement, cultural activities, etc.
13/30 Other Other expense
budget request
Mayor's Office of Criminal Justice - Provide funding to support the establishment of a community bail fund. To allow for the posting of bail for individuals and connecting them to services to assure that they appear in court.
Other community bail initiatives have demonstrated approximately 95% success rates. Their business depends on them getting their money back, so they bail out people who are safe bets.
image
19/30 Other Other expense
budget request
DEP; Increase funding for water and sewer maintenance.
image
27/30 Other Other expense
budget request
Provide funding to libraries within the district to purchase laptops for the local libraries.
image
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/44
HPD
Other affordable
PROVIDE AND EXPAND AFFORDABLE HOUSING
housing programs
UNITS THROUGH ALL AVAILABLE PROGRAMS
requests (capital)
INCLUDING WORKSPACE FOR ARTISTS (I.E.
DAMP. TIL. LISC/ ENTERPRISE. SIP AND LOW-
INTEREST LOANS) AGENCY: HOUSING
PRESERVATION
2/44
HPD
Other affordable
Provide funding for repairs and renovations of
housing programs
Tenant Interim Lease Buildings
requests (capital)
3/44
SCA
Provide a new or
Design and construct an Arts, Sciences, and
expand an existing
Trades High School, of which 75-85 of students
high school
shall derive from low-income families within
CD9
4/44
DCLA
Other cultural
Provide funds to create a theater and Multi-
facilities and
Culture Center for Hamilton Theatre at 3560
resources requests
Broadway, NYC 10031
(Capital)
5/44
NYCHA
Renovate or
Provide funding for exterior, interior, and
upgrade public
structural architectural renovations and repairs
housing
to Manhattanville Houses.
developments
6/44
HPD
Provide more
Restore funding of Section 202 Program for
housing for seniors
Senior Citizen housing
7/44
DPR
Reconstruct or
Provide funding to renovate Alexander Hamilton
West 140th &
upgrade a park or
Playground at Hamilton Place.
West 141st
playground
Streets
8/44
DPR
Reconstruct or
Provide funds to renovate St. Nicholas Park
W. 140th &
upgrade a park or
Playground.
St. Nicholas
playground
Ave.
9/44
Other
Other capital budget
HPD - Increase funding for Senior Citizen home
request
assistance program low interest/no interest
loans for senior home owners
10/44
DPR
Improve access to a
Allocate funding to renovate the Jacob Schiff
bet. West
park or playground
playground on Amsterdam Ave.
136th St. - W.,
138th Streets
11/44
Other
Other capital budget request
EDC-Provide funds to purchase, lease or otherwise obtain space for an Artisan Market
12/44
Other
Other capital budget
Provide funds to acquire Marime the old SRO at
request
611 West 112th Street as potential SGL/LGBTQ
Senior Housing
13/44
DPR
Provide a new or
Provide funding for public comfort stations at
expanded park or
Morningside Park, St. Nicholas Park, Audubon
amenity (i.e.
Park @W. 155th St. and West Harlem Piers Park.
playground, outdoor
athletic field)
14/44
Other
Other capital budget
Provide funds to fully repair damaged Sewer
12th Ave.
request
lines and fix drainage issues repair sinkhole,
West 135th
replace eroded soil under 12th Ave., repave
Stret West
12th Ave., and construct sidewalks on the east
138th Street
and west sides of 12th Ave.
15/44
NYCHA
Renovate or
Provide funding for exterior Interior and
upgrade public
structural architectural renovations and repairs
housing
to Audubon Housing Development.
developments
16/44
DPR
Reconstruct or
Provide funds to renovate the Croton Aqueduct
West 119 St
upgrade a building
Gatehouse at 119th Street and Amsterdam Ave.
and
in a park
to a Community and Cultural Facility.
Amsterdam
Ave
17/44
Other
Other capital budget
Provide funding to construct more supportive
request
housing within CD9.
18/44
DPR
Other requests for
Allocate Funds to complete the rebuilding of
park, building, or
stairs at 133rd Street in St. Nicholas Park, repair
access
and rebuild stairs at 140th and 129th Street (St.
improvements
Nicholas Park); as well as improve lighting in
ALL locations.
19/44
BPL
Create a new, or
Provide funds to replace windows with energy
renovate or upgrade
efficient windows at Hamilton Grange Library.
an existing public
library
20/44
HPD
Expand loan
Allocate funding for low-interest loans for
programs to
HDFC's to be used for repairs and facility
rehabilitate multiple
upgrades.
dwelling buildings
21/44
BPL
Create a new, or renovate or upgrade an existing public library
Provide funds to replace windows with energy efficient windows at Hamilton Grange Library.
22/44
DPR
Reconstruct or
Provide funding for turf renovation playground
upgrade a park or
renovation, security upgrades and stadium
playground
lighting at Annunciation Park.
23/44
Other
Other capital budget
Provide funding to complete the rebuilding of
request
stairs at 114th and 122nd Streets and improve
lighting in all locations.
24/44
Other
Other capital budget
Provide funds to renovate playground in front of
1299
request
Grant Houses Day Care Center
Amsterdam
Avenue,
Manhattan,
New York, NY
25/44
Other
Other capital budget
Provide funding incentive to developers for
request
affordable housing for artists.
26/44
Other
Other capital budget
Allocate funds to renovate baseball field at
112th St.
request
Morningside Park.
@Morningside
Drive,
Manhattan,
New York, NY
27/44
Other
Other capital budget
Provide funding to renovate Dog Run in
West 142nd
request
Riverside Park.
Street
28/44
NYCHA
Renovate or
Allocate funds to maintain an Outdoor Reading
518 West 125
upgrade NYCHA
Garden on the Westside of the George Bruce
St
community facilities
Library. (Parcel of Open Space adjacent West of
or open space
518 W. 125th Street)
29/44
NYPD
Provide a new NYPD
Allocate funds to renovate and repair the 30th
451 West 151
facility, such as a
Precinct and include ADA compliance.
St
new precinct house
or sub-precinct
30/44
DPR
Reconstruct or
Provide funds for sidewalk and pathway
upgrade a building
replacement in and around playgrounds and
in a park
athletic courts.
31/44
DPR
Provide a new or
Provide a new or expanded Park or Amenity (i.e.
expanded park or
Playground, Outdoor Athletic Field)
playground
32/44
NYPL
Create a new, or
Allocate funds to build-out unfinished space in
503 West 145
renovate or upgrade
the basement behind staff lounge and
St
an existing public
community room. Buildout is needed to create
library
600 sq.ft. classroom for OST. work will include
new HVAC system, new lighting and power, and
security system
33/44
DPR
Reconstruct or
Allocate funds to create a "New Entrance" to St.
upgrade a park or
Nicholas Park
amenity (i.e.
playground, outdoor
athletic field)
34/44
HPD
Provide more
Provide funding to construct more affordable
housing for seniors
Senior housing within CD9
35/44
HPD
Other affordable
Provide funding for tax incentives to developers
housing programs
to include art spaces (rehearsal/performance
requests (capital)
and visual arts work space) in their building
36/44
NYPD
Add NYPD parking
Restore funding to improve NYPD parking
facilities
facilities including additional parking, and
structural maintenance
37/44
Other
Other capital budget
Continue funding for installation of security
request
cameras and improved front door security for
Manhattanville, Grant, and Audubon Houses.
38/44
Other
Other capital budget
Maintain funding for Recycling Facilities in
request
NYCHA Developments within CD9
39/44
Other
Other capital budget
Allocate funds for low-interest/no interest loans
request
for Mitchell-Lama repair loans to Mitchell Lama
buildings for Capital repairs.
40/44
Other
Other capital budget
Provide funds for the inclusion of Speed Bumps,
110th Street
request
Special Signage, Traffic signals, and/or
to St. Clair's
strategically placed bollards (needed to protect
Place
pedestrians from speeding bicyclists) at the
Cherry Walk - Riverside Park Waterfront bike
path.
41/44
Other
Other capital budget
Provide funding to support the development of
request
a location to support training for Trade
positions, Entrepreneurial growth and other
needs for the formerly incarcerated population.
42/44
Other
Other capital budget
Provide funds for the inclusion of Speed Bumps,
request
Special Signage, Traffic Signals, and/or
Strategically placed Bollards (needed to protect
pedestrians from speeding bicyclists) at the
Cherry Walk - Riverside Park Waterfront Bike
Path from 110th Street to St. Clair's Place.
43/44
Other
Other capital budget
Provide funding for libraries within CD9 to
request
upgrade and maintain building facilities
44/44
Other
Other capital budget
Provide funding for community-based
request
emergency housing facilities assigned to the
emergency housing needs of the LGBTQ
homeless youth and transgender community.
CS
SCA
Provide a new or
Continue funding to design and construct a
expand an existing
school K-8 within CD9 to eliminate the existing
elementary school
over crowding throughout CD9.
CS
DPR
Enhance park safety
Continue Funding to provide lighting along bike
through design
path as well as other safety measures along
interventions, e.g.
Riverside Park (Waterfront) bike path from
better lighting
110th Street to St. Clair's Place, and Cherry
(Capital)
Walk.
CS
DPR
Other requests for
Provide funds to maintain sidewalks along the
Riverside
park, building, or
North and Southbound corridor of Riverside
Drive West
access
Drive (bet. Grant's Tomb and the 125th St.
122 Street
improvements
Viaduct).
West 125
Street
CS
NYCHA
Install recycling
Maintain funding for recycling facilities at
facilities at NYCHA
NYCHA developments within CD9.
developments
CS
DPR
Improve access to a
Provide funds to complete the rebuilding of
park or amenity (i.e.
stairs at 133rd St. (St. Nicholas Park), repair and
playground, outdoor
rebuild stairs at 140th and 129th St. (St.
athletic field)
Nicholas Park), and 114th Street on the upper
level of Morningside Park.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/30
OMB
Other community
Maintain and Increase budget for ALL
board facilities and
Community Boards.
staff requests
2/30
DYCD
Provide, expand, or
Increase funding for existing and needed
enhance after
academic arts and mentoring after school
school programs for
programs through grades 8-12 within CD9.
middle school
students (grades 6-
8)
3/30
NYPL
Extend library hours
Maintain funds to continue six-day service
or expand and
including increased hours, programming,
enhance library
collections, and sufficient staff to support theses
programs
functions.
4/30
Other
Other expense
DYCD - Provide funding to facilitate a youth
budget request
outreach effort which will allow opportunities to
connect children and their families with
necessary resources: youth programs,
internships, health clinics, job training and
placement, cultural activities, etc.
5/30
DOHMH
Reduce mosquito
Continue funding to eliminate (reduce)
populations
mosquitos, and bedbugs.
6/30
DSNY
Provide more on-
Provide funds for Solar powered compacting
street trash cans
"Big Belly" waste receptacles in areas with a
and recycling
history of rodent infestation.
containers
7/30
DCP
Study land use and
Provide funding for rezoning study for
zoning to better
Morningside Heights.
match current use
or future
neighborhood
needs
8/30
DHS
Expand street
Dedicated outreach personnel for consistent
outreach
relationship building outreach to homeless in
CD9.
9/30
NYPD
Other NYPD
Increase and continue funding and staff for
programs requests
NYPD's LGBTQ Outreach Unit at the 26th & 30th
Pct. to have at least one dedicated LGBTQ
outreach officer to provide continuing education
to officers in the precinct on sensitive and
appropriate police interactions with the LGBTQ
community and to work together with other
community affairs staff to increase public safety
outreach, presentation, and collaborations with
members of the LGBTQ community in CD9.
10/30
HPD
Other affordable
Provide funding to train skilled professional tech
housing programs
assistance to struggling HDFC's within CD9.
requests (expense)
11/30
HPD
Provide, expand, or
Increase funding for community-based tenant
enhance community
protection groups to educate tenants about new
outreach on HPD
rent laws and assist with legal representation.
programs and
services
12/30
DOE
Other educational
Provide funding for development of culturally
programs requests
sensitive curriculum, for use within CD9 schools
in cooperation with the Community Education
Councils for Districts 5, and 6 recognizing the
historical contributions of figures, movements,
and more from diverse set of communities
within CD9, including African American,
Caribbean, Latino, and LGBTQ communities.
13/30
Other
Other expense
Mayor's Office of Criminal Justice - Provide
budget request
funding to support the establishment of a
community bail fund. To allow for the posting of
bail for individuals and connecting them to
services to assure that they appear in court.
Other community bail initiatives have
demonstrated approximately 95% success rates.
Their business depends on them getting their
money back, so they bail out people who are
safe bets.
14/30
HRA
Other request for
+Mayor's Office of Immigrant Affairs; Increase
services for
funding for outreach programs dedicated to
vulnerable New
immigrants in an effort to raise awareness and
Yorkers
address safety issues, with dedicated outreach
to LGBTQ immigrants.
15/30
ACS
Increase support for
In light of the ongoing difficulties facing our
juvenile justice staff
community youth, funds are needed to be
allocated to helping our young citizens acquire
skills to understand their civil rights and how to
cope with any legal issues they may be face.
16/30
EDC
Other public
Provide funding for HHAP Program that aims to
housing
improve the health & well-being of NYCHA
maintenance,
residents. Health workers are requested from
staffing and
the local community to offer health information
management
on asthma, diabetes, and high blood pressure.
requests
17/30
DPR
Other street trees
Provide funds needed for pruning trees
and forestry
throughout parks, plazas and community
services requests
gardens to deter illegal activity within CD9.
18/30
ACS
Provide, expand, or
Provide funding for supported housing for aged-
enhance housing
out youth within foster care facilities
assistance for youth
throughout the borough of Manhattan.
that are leaving
foster care
19/30
Other
Other expense
DEP; Increase funding for water and sewer
budget request
maintenance.
20/30
DPR
Enhance park safety
Allocate funds to hire six full-time park workers
through more
for Morningside Park, St. Nicholas Park &
security staff (police
Montefiore Park and plaza, and Riverside Park.
or parks
Increase the number of Parks Enforcement
enforcement)
Patrol Officers, Foot/Bicycle/Cars assigned to
fixed patrols within CB9 specifically in high-
crime areas.
21/30
NYPD
Assign additional
Allocate funds for additional Officers in the
520 West 126
uniformed officers
NYPD Lesbian, Gay, Bisexual, and Transgender
St
Liaison unit to be stationed at the 26th Pct.
22/30
NYPD
Assign additional
Allocate funds for additional Officers in the
451 West 151
uniformed officers
NYPD Lesbian, Gay, Bisexual, and Transgender
St
Liaison unit to be stationed at the 30th Pct.
23/30
NYPD
Assign additional
Provide funding for Housing Bureau police.
housing police
officers
24/30
EDC
Other public
Allocate funds to hire or reinstate security
housing
personnel for NYCHA developments.
maintenance,
staffing and
management
requests
25/30
EDC
Other public housing maintenance, staffing and management requests
Continue funding for maintenance staff to control garbage and refuse.
26/30
DOHMH
Other animal and pest control requests
Increase funds for Pest Control and Rats within CD9.
27/30
Other
Other expense budget request
Provide funding to libraries within the district to purchase laptops for the local libraries.
28/30
DPR
Other park maintenance and safety requests
Fund six full-time park workers (CPW's for Morningside, St. Nicholas/Montefiore, Riverside Parks).
29/30
HRA
Provide, expand, or enhance job search and placement support
Maintain funding for job training and placement for adults within CD9
30/30
SBS
Other expense workforce development requests
Maintain Funding for Job Training and Placement for Adults within CB9

