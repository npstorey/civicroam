- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 17 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/12N35QRGg57PAORQbNVorPWAGhycJyFSR/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/12N35QRGg57PAORQbNVorPWAGhycJyFSR/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
17
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 17
image
Address: 4112 Farragut Road Phone: (718) 434-3072
Email: bk17@cb.nyc.gov
Website: cb17brooklyn.org
Chair: Mr. Aaron Kojo Ampaw District Manager: Sherif Fraser
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community District 17 is comprised of the following neighborhoods: Remsen Village, Farragut, Rugby, East Flatbush. The geographic district encompasses East New York Avenue from East 98 Street to Utica Avenue, South on Utica Avenue to Clarkson Avenue, West on Clarkson Avneue to Bedford Avenue, South on Bedford Avenue to the Long Island Railroad/Glenwood Road East along the Long Island Railroad to East 98 Street, then North on East 98 Street to East New York Avenue.
Community District 17 is a culturally diverse community. Between 2000 and 2010 there was a -6% change in total population. According to the U.S. Census Bureau Population Estimate, 2013 the population in East Flatbush is approximately 156,151. with 89% Black, 7% Hispanic, 1%Asian, 1% White, 2% Other. The population by age varies: 22% - 0-17, 10%-18-24, 27%-25-44, 28%-45-64 and 14% - 65+. The census also noted, 53% of the population are foreign born and 9% have limited English proficiency. We believe, the East Flatbush community have many undocumented residents who, if counted, would probably increase the total population in the District.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 17
image
The three most pressing issues facing this Community Board are:
Schools
In CD17, enrollment in public schools has increased. We now have Universal Pre-K. The benefits of early education for children are clearly backed by research, and there is a great need for reliable and affordable child care for New York families. However, the universal aspect of Pre-K for All is perhaps its boldest and best feature, and it could be the key to creating a high-quality, sustainable program. We also need to increase graduation rate and College readiness and decrease the drop-out rate. Community Board 17 continues to advocate for smaller classrooms, resource availability for teachers and all the amenities to ensure all students are college and career ready in addition to vocational and technical training for students to be able to compete in the world of technology. We request the implementation of an "Out of School Time" (OST) Program at P.S. 198. The Board strongly supports the Borough Field Support Centers (BFSC's) to review this request and provide a favorable response. This program will provide a safe and nurturing environment for children whose parents have to work on non-school days and cannot afford the added expense of paying for child care services.
Senior services
Our population continues to age like the rest of the country; the frail and elderly are growing more numerous. The elderly age 65 and older stands at 14% according to the 2013 U.S. Census Bureau Population estimates. A sincere effort must be made to provide greater outreach to the shut-ins who depends on the Meals on Wheels program. Our senior population continues to grow. Many seniors are living longer, most elders live alone and are sometimes emotionally, financially and physically abused by their caretakers and sometimes strangers. We request enhanced funding to organizations and programs that participate in programs that caters to the needs of our seniors.
Street conditions (roadway maintenance)
We applaud the Department of Transportation for the Sidewalk Program. Many sidewalks in CD 17 were repaired, however, there remains a number of sidewalks and streets that remains in a state of disrepair. These conditions lead to pedestrians walking in roadways and drivers taking routes that are either out of their way or they must put their vehicle through unsafe roadways. The drivers and the pedestrians in our community deserve to travel under safe conditions. Additionally, we request the locations submitted by CB17 be added to the next phase of Trench Restoration.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 17
image
M ost Important Issue Related to Health Care and Human Services
Other
Sustaining a healthy living environment and accessible health care services for the youth, elderly and low income families in District 17 remains a priority. Comprehensive, quality health care services is one of the most important factors in promoting and maintaining health and leads to the prevention and management of many diseases that plague our community.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Access to Health Care, and Prevention Screening are two health related issues that affects the East Flatbush district. As noted in the NYC DOHMH Community Health Survey.
A lack of quality health care can lead to negative health outcomes and more intensive treatment such as avoidable hospitalizations. Adults in The same can be said for Prevention and Screening of various illnesses, such as Breast Cancer, HPV, Flu and HIV testing. When screening is applied it can be most effective in people living longer, healthier lives.
We support the creation and promotion of programs that increase awareness and encourage treatment of mental health. The many components of ThriveNYC, which aims to reduce mental illness stigma and close the gap in behavioral health services by integrating mental health care into primary care practices needs to be expanded to more low-income neighborhoods. It is difficult for physicians to ascertain the living conditions in which their patients come from and return to after clinic visits and especially after hospitalization. Increased services could help individuals cope with stressful situations.
Needs for Older NYs
We request that the Department For The Aging implement funded programs. There is a need for C2 housing to meet the needs of our aging population, namely: assisted living, independent living and dependent living. Our population continues to age like the rest of the country; the frail and elderly are growing more numerous
Needs for Homeless
Provide rental assistance/vouchers for permanent housing. The gap between affordability and unaffordable continues to rise. CB17 requests that programs are implemented to accommodate families and singles who due to their income range fall within the borders of unaffordability thus deeming them unable to apply for the affordable units. We believe the income range is a disadvantage to a large number of residents in our district.
Needs for Low Income NYs
Other Work Experience Program Requests: With the phasing out of the Work Experience Program, it is imperative that participants seeking independence and self-support are provided with the alternatives that continues to improve the skills they already possess and allow them opportunities to develop new abilities that increases their chances of employment.
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
22/25
DFTA
Renovate or
The Board supports the funding and installation
3304
upgrade a senior
of a kitchen at the Senior Center located at 3304
Clarendon
center
Clarendon Road. Having a kitchen on site will
Road
greatly enhance the quality of food service to
the seniors and eliminate the daily hassle of
transporting meals to the center.
23/25
HRA
Other request for
Provide more access and reliability in the HRA
District Wide
services to support
system for community residents who depends
low-income New
on the services.
Yorkers
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/33
HRA
Expand access to
Retirees receiving SSI or a pension do not have
District Wide
public health
disposable income to afford the medication and
insurance such as
services needed to properly manage their health
Medicaid
issues. Expanding Medicaid would allow for an
increase in social services such as more HHA
hours at home and increased prescription drug
coverage.
9/33
DHS
Expand
There needs to be an expansion of cash
District Wide
homelessness
assistance/rent negotiation programs as well as
prevention
mortgage refinancing advisors to assist renters
programs
and homeowners remain in their housing.
11/33
DFTA
Increase home
Significant number of elderly individuals and
District Wide
delivered meals
individuals living with multiple health problems,
capacity
shut-ins who depend on the Meals on Wheels
program.
12/33
DOHMH
Create or promote programs to de- stigmatize mental health problems and encourage treatment
Many socio - economic factors (cost of living/lack of affordable housing , employment, cost of childcare, medical health problems, etc) underlying contributors to a multitude of psychological disorder and maladaptive behavior. In order to treat mental illness, the root cause needs to be identified and resources provided to helping individuals cope with stressful situations. It is difficult for physicians to ascertain the living conditions in which their patients come from and return to after clinic visits and especially after hospitalizations.
District Wide
21/33
HRA
Enhance cash assistance programs
College students attending classes, interns and/or graduates seeking employment, MTA fare becomes a burden and creates a financial hardship.
27/33
DFTA
Enhance home care services
There should be outreach services to homebound older adults n elderly to allow them to age in place. Many cannot afford long term care of independent senior housig/communities
31/33
DOHMH
Other programs to address public health issues requests
Early mammogram testing means treatment starts earlier.
District Wide
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 17
image
M ost Important Issue Related to Youth, Education and Child Welfare
Youth workforce development and summer youth employment
Many of our young people lack the skills necessary for employment. We request continued funding of programs that offers a broader range of opportunities for youth to explore their career and educational interests.
Developmental programs such as "Learn and Earn" and "Train and Earn" that assist participants in overcoming barriers to employment, have proven successful over the years. Community Board 17 also support the Ladder for leaders program that allows partnering with relevant city agencies and/or community partners to create pathways and opportunities for youth and communities at large, to gain experience in the tech, entrepreneurship and entertainment/media field.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
We request expanded fundings for CAMBA and Sesame Flyers programs. CAMBA provides thousands of low income youth from pre-school through high school with academic assistance, counseling, tutoring, art, drama, music, sports, SAT and Regents help, opportunities to serve their community, internships and employment. CAMBA encourages older youth who are disconnected from either school or work to further their education and employment opportunities and serve their community Sesame Flyers offer tutoring, safe and nurturing spaces for children to play during the summer, youth-led community service activities, job readiness programs, case management and counseling for families in crisis, GED and computer technology programs, along with celebrations of the rich traditions of Caribbean culture.
Implementation of an "Out of School Time" (OST) Programs at P.S. 198. The Board strongly supports the request for this program which is designed to create a safe and nurturing environment for children whose parents have to work on non-school days and cannot afford the added expense of paying for child care services.
Our schools must also be equipped with the tools needed to provide adequate service to faculty and pupils.
Needs for Youth and Child Welfare
Adequate funding for child welfare: Community Board 17 supports Federal and State child welfare financing, increase in funding which allows agencies to better protect, care for and provide services to at risk children or those who were abused or neglected. We also advocate for competitive salaries, opportunities for career advancement, adequate compensation and manageable caseload sizes for caseworkers. There should be adequate child abuse and neglect prevention services for every family in need to ensure children have safe and stable permanent families.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
4/25
SCA
Renovate interior building component
P.S 198 - Request funding be allocated to install a Bell System which ties in with the Clock. Presently, the school do not have a bell system or a programmable clock.
4105 Farragut Rd
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
8/33
DYCD
Provide, expand, or
Residents particularly young people lack skills
District Wide
enhance skills
necessary for employment.
training and
employment
services for high
school students at
risk of dropping out
15/33
DYCD
Provide, expand, or
Funding for Computer literacy classes.
District Wide
enhance adult
literacy programs
services
22/33
DOE
Other educational
Implementation of an "Out of School Time"
programs requests
(OST) Programs at P.S. 198. The Board stronly
supports the request for this program which is
designed to create a safe and nurturing
environment for children whose parents have to
work on non-school days and cannot afford the
added expense of paying for child care services.
30/33
DYCD
Provide, expand, or
Residents particularly young people lack skills
District Wide
enhance skills
necessary for employment.
training and
employment
services for high
school students at
risk of dropping out
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 17
image
M ost Important Issue Related to Public Safety and Emergency Services
Crime prevention programs
The Board believes that crime prevention programs are most effective when they operate within the community and involve community residents actively working with their local government agencies to address issues contributing to crime, delinquency, and disorder in their communities. Increased funding for vandalism prevention, domestic violence prevention, youth crime prevention, and other crime prevention programs must continue. The implementation of the Neighborhood Coordinating Officers (NCO) an initiative that engages community members and officers has garnered applause by most community residents. This form of community policing, or community- oriented policing is a proven evident based model of police building ties and working closely with members of the communities. The Board supports the Advocates Intervene Mentor (AIM) program and request the program be expanded and hire more mentors and resource specialist to work with youth facing a violation of probation due to chronic absenteeism and/or chronic unresponsiveness to interventions and engagement strategies.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The safety and well-being of the men and women serving our community is paramount. CD17 is one of the largest districts in the Borough. With the increase of multi-family buildings throughout the community, the population is slated to increase by over 25%. An additional Precinct with added man-power would enhance the safety of our community.
There are many positive benefits to working in a clean office environment. Therefore, repairs to the Precinct house must be completed in a timely manner and technology needs met.
Illegally parked overnight commercial tractor trailers in residential areas, continues to be a nuisance in our community. The Board request a tow truck be added to the Precinct’s fleet.
Designated parking of service vehicles could decrease the time service vehicles take maneuvering in and out from between parked vehicles. The request for a feasibility study of the location (vacant lots) submitted to the NYPD must be revisited.
Needs for Emergency Services
Community Board 17 is overly concerned about the on-going vague response to issues of concerns to the community. As noted in our Expense Request, it is imperative that funding be allocated for emergency generators for the engine companies in District 17. Generators off-set that critical need that comes with the loss of electricity during a power outage. We also reiterate the importance of prioritizing for funding, the FDNY programs and staffing as noted: Fire Prevention Inspection Team, Juvenile Fire Setter Intervention program, carbon monoxide and smoke detectors for distribution to seniors and other residents unable to afford the purchase.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/25
NYPD
Add NYPD parking
Parking around the 67th Precinct remains a
2820 Snyder
facilities
priority. Several new apartment units were
Avenue,
erected around the precinct which presents a
Brooklyn,
challenge for parking service vehicles and could
New York, NY
hinder response time when cars are blocked in.
CB17 request a feasibility study be conducted to
lease the vacant lots across from the precinct
house, 2915 - 2917 Snyder Avenue.
3/25
NYPD
Other NYPD
Community District 17 is one of the largest
District Wide
facilities and
districts in the Borough. With the increase of
equipment requests
multi family buildings throughout the
(Capital)
community the population is slated to increase
by 25%. An added Precinct would enhance the
safety of our community.
6/25
NYPD
Renovate or
Renovation of the 67th Precinct Men and
2820 Snyder
upgrade existing
Women's bathroom on the second floor
Avenue
precinct houses
becomes hazardous due to traffic, especially
when special events are held at the precinct and
during the monthly community meetings. The
women's bathroom floor becomes wet and
slippery, paper towel holders are left open,
running faucets, dirty sink toilet seats etc. The
urinal in the mens bathroom floods and
presently, there's a leaky pipe in the wall. A
complete renovation is needed for both
bathrooms.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
2/33
FDNY
Expand funding for
Emergency Generators off-set that critical need
fire prevention and
that comes with the loss of eletricity during a
life safety initiatives
power outage. We support the allocation of
funding for emergency generators at Engine
248, BN41 and Engine 310, Ladder 174, BN 58.
3/33
NYPD
Assign additional
More Traffic Officers will assist the 67th Police
2820 Snyder
traffic enforcement
Precinct in addressing the ongoing illegally
Avenue,
officers
parked vehicles.
Brooklyn,
New York, NY
4/33
NYPD
Provide additional patrol cars and other vehicles
The 67 Precinct must rely on borrowing a tow truck on a very limited basis and cannot effectively address the issue of 18 wheelers illegally parked through out the community.
2820 Snyder Avenue, Brooklyn, New York, NY
7/33
NYPD
Other NYPD
Needed to combat the illegally parked
2820 Snyder
facilities and
commercial vehicles since ticketing has not been
Avenue,
equipment requests
a viable deterrent
Brooklyn,
(Expense)
New York, NY
14/33
FDNY
Expand funding for
CB17 support full funding for fire Prevention
fire prevention and
Inspection Program, Fire Prevention Inspection
life safety initiatives
Team and the Juvenile Fire Setter Intervention
program, in addition to carbon monoxide and
smoke detectors for distribution to seniors and
the other population unable to afford the
purchase.
16/33
NYPD
Other NYPD
The Precinct must update it's technology to keep
2820 Snyder
facilities and
up with the 21st century. We advocate for
Avenue
equipment requests
updated mobile technology and Wi-Fi service in
(Expense)
the Precinct.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 17
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
On weeks when there are holidays, a regular two-day a week pickup becomes a one day scheduled pick-up. This diminution of service is even worse for recyclable materials and the problems of vermin and rodent infestation multiplies. Sanitation should coalesce with the Department of Consumer Affairs to improve cleanliness compliance by homeowners and businesses and address sidewalk clutter.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Environmental concerns ranges from complaints about clogged catch basins, many of which are imploding due to lack of repairs and the need for DEP and DOT to collaborate and resolve Trench Restoration work in the community.
Funding for trench restoration projects in District 17 would decrease the number of sink holes in the
community. The community is also saturated with auto repair shops that discharge large amounts of volatile organic solvents and volatile organic compounds into the air which could contribute to respiratory diseases.
Needs for Sanitation Services
The New York City Department of Sanitation, via My Neighborhood Statistics recorded an average of 2.4 pounds of garbage and recycling collected per person each day in CD17. The Distict's average of 12.8% of recycling and 87.2% garbage is equivalent to approximately 174 Tons of garbage and recycling collected per day for disposal. The District needs all the necessary tools to ensure the cleanliness of our neighborhood on a daily basis.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/25
DSNY
Provide new or
There is a need for an additional Basket Truck at
Church, New
increase number of
BK17 garage to address the overflow of litter on
York Ave,
sanitation trucks
commercial strips.
Nostrand,
and other
equipment
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
10/33
DSNY
Other enforcement
The Community District has exceeded the
District Wide
requests
Cleanliness Threshold for more than Ten (10)
consecutive years and therefore is eligible for a
review.
26/33
DSNY
Provide more on-
Request for an increased cleanliness of these
Utica Avenue
street trash cans
areas. Unhealthy amount of garbage
Church
and recycling
throughout the areas.
Avenue
containers
Avenue D
32/33
DSNY
Increase
The district lacks sufficient amount of inspectors
enforcement of
to properly enforce street cleaning.
dirty sidewalk/dirty
area/failure to clean
area laws
33/33
DEP
Clean catch basins
Prevents flooding
District Wide
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 17
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Community Board 17 has been working with the Department of City Planning and it's elected officials to re-zone certain areas in the community. The Board also held outreach presentation meetings in various areas of the community in an effort to garner community input and support and to determine the areas that can be re-zoned. While the Board continues to analyze the zoning and ask residents what they would like to see in the neighborhood, there has been an increase of unwanted housing development, some of which do not conform to the surrounding areas.The Board would like a designated Cease and Desist zone in Brooklyn Community District 17.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
There is a need to identify as many corridors/clusters that are considered worth investigating for rezoning. Such corridors might be zoned to permit residential development and /or to maximize areas for housing where appropriate. Proximity to the Nostrand Avenue subway stations or the Livonia Avenue 3 line stations along 98th street should also be given consideration.
Needs for Housing
Community Board 17 recommends funding for non-for-profit organizations engaged in Foreclosure Prevention, Financial Literacy and Mortgage Modification. It is imperative that funding be provided for the current calendar year and beyond. Neighborhood Housing Services CDC Inc. must be funded for Foreclosure Prevention through HPD’s Neighborhood Preservation Consultant Contract. Also, such contracts should be awarded to organizations with the most experience and record of actual accomplishments that are engaged in the communities where their needs are. CB 17 supports Flatbush East Community Development Corporation, Neighborhood Housing Services CDC Inc. and Erasmus Neighborhood Federation in their request for funding to implement some much needed programs in our district. Annual funding is necessary to support all housing programs in District 17. With the present state of the economy, these programs are necessary to assist homeowners who are experiencing financial difficulties.
Needs for Economic Development
There is a need to implement more BIDs in CB 17 business areas such as, but not limited to, Utica and East New York Avenue, going south bound on Utica Avenue to Clarendon Road and Utica Avenue and Church Avenue east bound on Church Avenue to Remsen Avenue. The implementation of a BID would promote goodwill between the association members and the residents of the immediate adjacent areas. It will also promote businesses, improve shopping in the community through merchants and civic action projects and foster a stronger relationship between merchants, residents, service agencies and law enforcement for the betterment of the community.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
9/25
HPD
Provide more
CB17 supports the allocation of funding for the
housing for special
expansion of housing for special needs housing,
needs households,
such as seniors or the formerly homeless.
such as the formerly
homeless
17/25
SBS
Other capital
Increase availability of tech resources for use by
Church
commercial district
community along the business strip
Avenue
revitalization
Bedford
requests
Avenue East
95th Street
18/25
EDC
Make infrastructure
Cafes are seen as a place for innovation and a
Rutland Road
investments that
place where people gather to work on business
Utica Avenue
will support growth
ideas, socialize etc. A place where youths can
Church
in local business
come together and create the next big tech
Avenue
districts
business event or social change project
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
23/33
SBS
Other expense commercial district revitalization requests
Create a sense of community and promote the businesses in the area.
Church Avenue Nostrand Avenue
TRANSPORTATION
Brooklyn Community Board 17
image
M ost Important Issue Related to Transportation and Mobility
Bus service (frequency and access)
Shortage of local buses that provides service to our community, has long been an issue of complaint. The B8, B6, B46 and B44 bus routes are some of the busiest routes in District 17. Commuters wait longer on these routes for buses and sometimes have to utilize other means of transportation to get to and from their destination. Service cuts along these routes will not only extend the wait time especially during inclement weather but will negatively impact the finances of low-income families who depend on the service. Repair and upgrade of subway stations, Instillation of Bus sheds and Station sheds and improved accessibility of transit infrastructure, such as elevators and escalators are all Transit needs that exists in our District.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The Board continue to receive complaints regarding congestions on Utica Avenue, double parked cars, blocked businesses and cars parked on the sidewalk has become the norm in the district. The installation of the bus lanes has not remedy the situation.
There is also a need for more truck signage, lighting and traffic signals throughout the district .
Needs for Transit Services
The Newkirk Avenue station has experienced significant deterioration over the years. Rehabilitation will greatly enhance the aesthetic of the station and provide safety and quality service to the commuters. Although parts of this project was approved for funding, CB17 request that the total rehabilitation of this subway station be considered.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/25
DOT
Reconstruct streets
This is a long standing request We request this
Kings
location be added to the next Capital Project
Highway
slated for District 17.
Clarendon
Road Avenue
D
7/25
DOT
Reconstruct streets
Sidewalk reconstruction requested at this
Snyder
location
Avenue
Brooklyn
AVenue East
42nd Street
8/25
DOT
Repair or provide
Heavily Traffic intersection with a bus stop.
East 53 Street
new street lights
Block is poorly lit.
Kings
Highway
10/25
DOT
Roadway
Allocate funding for Trench Restoration in front
3402 Farragut
maintenance (i.e.
of 3402 Farragut Road between East 34th and
Rd
pothole repair,
East 35th Streets.
resurfacing, trench
restoration, etc.)
11/25
DOT
Roadway
Under the Overpass, the street not in
Glenwood
maintenance (i.e.
satisfactory condition to be driven on, needs to
Raod EAst 45
pothole repair,
be resurfaced
Schenectady
resurfacing, trench
Avenue
restoration, etc.)
12/25
DOT
Reconstruct streets
There is no sidewalk at this location. Needs to
Farragut Road
be prioritize for sidewalk installation.
Utica Avenue
Kings
Highway
13/25
DOT
Roadway
Trench restoration in front of 3801 Farragut
3801 Farragut
maintenance (i.e.
Road.
Rd
pothole repair,
resurfacing, trench
restoration, etc.)
14/25
DOT
Upgrade or create
Provide internet to lower income residents
Church
new plazas
lacking digital access
Avenue East
52nd Street
20/25
NYCTA
Other transit infrastructure requests
To accommodate our senior commuters during inclement weather, elements of rain, snow and flooding.
Church Avenue Nostrand Avenue South
Bound - B35
25/25
NYCTA
Other transit infrastructure requests
To accommodate senior commuters during inclement weather, elements of rain, snow and flooding.
Utica Avenue B46 Corridor
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
13/33
NYCTA
Expand bus service
For years, residents have complained about the
District Wide
frequency or hours
unreliable services delivered by the B8 bus line.
of operation
17/33
DOT
Add street signage
There is a noticeable lack of truck enforcement
District Wide
or wayfinding
signage in our district. Many resident complain
elements
of commercial trucks illegally driving and
parking on roads in the community.
18/33
DOT
Provide new traffic
It is very difficult for traffic emerging from the
East 40th
or pedestrian
side streets without hindrance vehicles
Street
signals
consistently obstructing full view.
Glenwood
Road
20/33
DOT
Provide new traffic
It is very difficult for traffic emerging from the
East 38th
or pedestrian
"Tercery streets without hindrance" Vehicles
Street
signals
consistently obstructed full view.
Glenwood
Road
28/33
DOT
Provide new traffic
Very difficult for traffic emerging from the side
East 39th
or pedestrian
streets without hindrance. Vehicles consistently
Street
signals
obstructed full view.
Farragut Road
29/33
DOT
Provide new traffic
Very difficult for traffic emerging from the side
East 35 Street
or pedestrian
street without hindrance. Vehicles consistently
Farragut Road
signals
obstructing full view
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 17
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Access to and quality of cultural programming
Access to quality and cultural programs are lacking in our district. The Board's request for a Caribbean Cultural Museum in the district directly relates to its demographic.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Park maintenance is essential to the cleanliness of our parks and requires the hiring of additional gardeners and other skilled non-managerial personnel.
The Board request the expansion of athletic programs and educational programs in Computer Resource Centers, to attract the youth in our district
We also request a feasibility study be conducted at our Parks to determine the installation of a swimming pool, a recreational need that would benefit the community as a whole.
Needs for Cultural Services
There is a urgent need for collaborative efforts to bring together various private and government funds to support, strengthen and expand arts and cultural nonprofits in Community District 17. The Board believes that cultural facilities and programs will promote and contribute to the culture and economic lives of the community, by creating jobs, cultural tourism, expand access and education in the arts, humanities and sciences, while improving the quality of life for community residents at large.
Needs for Library Services
Community Board 17 supports increased funding for the Brooklyn Public Library to provide the much needed services, supplies and equipment for our Branch libraries so that the needs of our students and adult population can be met. The three branches in CD 17, Rugby Branch, Clarendon Branch and East Flatbush Branch offer programs such as Homework help, Tutoring, Computer Classes and Games, Internet/Email Classes among other.
Needs for Community Boards
The role of the Community Boards has expanded throughout the years which requires more staffing to satisfy the needs of the office and assist with the required service delivery needs of the community. Adequate funding is requested to fulfill the Charter-mandated responsibilities of the Board.
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
19/25
DCLA
Other cultural
DCAS owned vacant site at the location: Our
Church
facilities and
district and surrounding districts lack arts and
Avenue
resources requests
cultural attractions. A center representative of
Bedford
(Capital)
the shared culture in our community would
Avenue
increase comradery and pride within residents.
21/25
DPR
Provide a new or
This request will be a positive addition for the
One District
expanded park or
many pet owners in the district.
Park
amenity (i.e.
playground, outdoor
athletic field)
24/25
DPR
Other park
There is no swimming pool in the district. This
District Wide
programming
request meets the recreational need vocalized
requests
by the youths and seniors in the community. A
pool will benefit the district as a whole.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
5/33
DPR
Provide better park
Hire additional personnel to trim the grass and
East 40th St
maintenance
maintain the garden at Paerdegat Park.
and Albany
Avenue
6/33
DPR
Forestry services,
Funding for Tree Pruning and Maintenance must
including street tree
be enhanced to reduce the seven year pruning
maintenance
cycle.
19/33
DPR
Provide more
Equipment that satisfies the workout
District Wide
programs in parks or
requirement of beginners as well as experienced
recreational centers
fitness buffs.
24/33
DPR
Forestry services,
Complaints of trees obstructing and/or clogging
East 43 Street
including street tree
drain pipes
Dead End
maintenance
Church
Avenue
25/33
DPR
Other street trees
Tree guards will enhance the beauty of the
Snyder
and forestry
district.
Avenue
services requests
Brooklyn
Avenue Troy
Avenue
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
15/25
Other
Other capital budget
Department For The Aging: Our population
Community
request
continues to age like the rest of the country.
Ditrict 17
There is a desperate need for additional centers
throughout the district as the District is
currently serviced by only one senior center in
the Community .
16/25
Other
Other capital budget
MTA - Transit Authority - The construction of a
Nostrand
request
shed at the train station will accommodate our
Avenue
seniors commuters during inclement weather,
Newkirk
elements of rain, snow and flooding.
Avenue
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
NYPD
Add NYPD parking
Parking around the 67th Precinct remains a
2820 Snyder
facilities
priority. Several new apartment units were
Avenue,
erected around the precinct which presents a
Brooklyn,
challenge for parking service vehicles and could
New York, NY
hinder response time when cars are blocked in.
CB17 request a feasibility study be conducted to
lease the vacant lots across from the precinct
house, 2915 - 2917 Snyder Avenue.
2/25
DSNY
Provide new or
There is a need for an additional Basket Truck at
Church, New
increase number of
BK17 garage to address the overflow of litter on
York Ave,
sanitation trucks
commercial strips.
Nostrand,
and other
equipment
3/25
NYPD
Other NYPD
Community District 17 is one of the largest
District Wide
facilities and
districts in the Borough. With the increase of
equipment requests
multi family buildings throughout the
(Capital)
community the population is slated to increase
by 25%. An added Precinct would enhance the
safety of our community.
4/25
SCA
Renovate interior
P.S 198 - Request funding be allocated to install
4105 Farragut
building component
a Bell System which ties in with the Clock.
Rd
Presently, the school do not have a bell system
or a programmable clock.
5/25
DOT
Reconstruct streets
This is a long standing request We request this
Kings
location be added to the next Capital Project
Highway
slated for District 17.
Clarendon
Road Avenue
D
6/25
NYPD
Renovate or
Renovation of the 67th Precinct Men and
2820 Snyder
upgrade existing
Women's bathroom on the second floor
Avenue
precinct houses
becomes hazardous due to traffic, especially
when special events are held at the precinct and
during the monthly community meetings. The
women's bathroom floor becomes wet and
slippery, paper towel holders are left open,
running faucets, dirty sink toilet seats etc. The
urinal in the mens bathroom floods and
presently, there's a leaky pipe in the wall. A
complete renovation is needed for both
bathrooms.
7/25
DOT
Reconstruct streets
Sidewalk reconstruction requested at this
Snyder
location
Avenue
Brooklyn
AVenue East
42nd Street
8/25
DOT
Repair or provide
Heavily Traffic intersection with a bus stop.
East 53 Street
new street lights
Block is poorly lit.
Kings
Highway
9/25
HPD
Provide more
CB17 supports the allocation of funding for the
housing for special
expansion of housing for special needs housing,
needs households,
such as seniors or the formerly homeless.
such as the formerly
homeless
10/25
DOT
Roadway
Allocate funding for Trench Restoration in front
3402 Farragut
maintenance (i.e.
of 3402 Farragut Road between East 34th and
Rd
pothole repair,
East 35th Streets.
resurfacing, trench
restoration, etc.)
11/25
DOT
Roadway
Under the Overpass, the street not in
Glenwood
maintenance (i.e.
satisfactory condition to be driven on, needs to
Raod EAst 45
pothole repair,
be resurfaced
Schenectady
resurfacing, trench
Avenue
restoration, etc.)
12/25
DOT
Reconstruct streets
There is no sidewalk at this location. Needs to
Farragut Road
be prioritize for sidewalk installation.
Utica Avenue
Kings
Highway
13/25
DOT
Roadway
Trench restoration in front of 3801 Farragut
3801 Farragut
maintenance (i.e.
Road.
Rd
pothole repair,
resurfacing, trench
restoration, etc.)
14/25
DOT
Upgrade or create
Provide internet to lower income residents
Church
new plazas
lacking digital access
Avenue East
52nd Street
15/25
Other
Other capital budget
Department For The Aging: Our population
Community
request
continues to age like the rest of the country.
Ditrict 17
There is a desperate need for additional centers
throughout the district as the District is
currently serviced by only one senior center in
the Community .
16/25
Other
Other capital budget request
MTA - Transit Authority - The construction of a shed at the train station will accommodate our seniors commuters during inclement weather, elements of rain, snow and flooding.
Nostrand Avenue Newkirk Avenue
17/25
SBS
Other capital
Increase availability of tech resources for use by
Church
commercial district
community along the business strip
Avenue
revitalization
Bedford
requests
Avenue East
95th Street
18/25
EDC
Make infrastructure
Cafes are seen as a place for innovation and a
Rutland Road
investments that
place where people gather to work on business
Utica Avenue
will support growth
ideas, socialize etc. A place where youths can
Church
in local business
come together and create the next big tech
Avenue
districts
business event or social change project
19/25
DCLA
Other cultural
DCAS owned vacant site at the location: Our
Church
facilities and
district and surrounding districts lack arts and
Avenue
resources requests
cultural attractions. A center representative of
Bedford
(Capital)
the shared culture in our community would
Avenue
increase comradery and pride within residents.
20/25
NYCTA
Other transit
To accommodate our senior commuters during
Church
infrastructure
inclement weather, elements of rain, snow and
Avenue
requests
flooding.
Nostrand
Avenue South
Bound - B35
21/25
DPR
Provide a new or
This request will be a positive addition for the
One District
expanded park or
many pet owners in the district.
Park
amenity (i.e.
playground, outdoor
athletic field)
22/25
DFTA
Renovate or
The Board supports the funding and installation
3304
upgrade a senior
of a kitchen at the Senior Center located at 3304
Clarendon
center
Clarendon Road. Having a kitchen on site will
Road
greatly enhance the quality of food service to
the seniors and eliminate the daily hassle of
transporting meals to the center.
23/25
HRA
Other request for
Provide more access and reliability in the HRA
District Wide
services to support
system for community residents who depends
low-income New
on the services.
Yorkers
24/25
DPR
Other park
There is no swimming pool in the district. This
District Wide
programming
request meets the recreational need vocalized
requests
by the youths and seniors in the community. A
pool will benefit the district as a whole.
25/25 NYCTA Other transit
infrastructure requests
To accommodate senior commuters during inclement weather, elements of rain, snow and flooding.
Utica Avenue B46 Corridor
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/33
HRA
Expand access to
Retirees receiving SSI or a pension do not have
District Wide
public health
disposable income to afford the medication and
insurance such as
services needed to properly manage their health
Medicaid
issues. Expanding Medicaid would allow for an
increase in social services such as more HHA
hours at home and increased prescription drug
coverage.
2/33
FDNY
Expand funding for
Emergency Generators off-set that critical need
fire prevention and
that comes with the loss of eletricity during a
life safety initiatives
power outage. We support the allocation of
funding for emergency generators at Engine
248, BN41 and Engine 310, Ladder 174, BN 58.
3/33
NYPD
Assign additional
More Traffic Officers will assist the 67th Police
2820 Snyder
traffic enforcement
Precinct in addressing the ongoing illegally
Avenue,
officers
parked vehicles.
Brooklyn,
New York, NY
4/33
NYPD
Provide additional
The 67 Precinct must rely on borrowing a tow
2820 Snyder
patrol cars and
truck on a very limited basis and cannot
Avenue,
other vehicles
effectively address the issue of 18 wheelers
Brooklyn,
illegally parked through out the community.
New York, NY
5/33
DPR
Provide better park
Hire additional personnel to trim the grass and
East 40th St
maintenance
maintain the garden at Paerdegat Park.
and Albany
Avenue
6/33
DPR
Forestry services,
Funding for Tree Pruning and Maintenance must
including street tree
be enhanced to reduce the seven year pruning
maintenance
cycle.
7/33
NYPD
Other NYPD
Needed to combat the illegally parked
2820 Snyder
facilities and
commercial vehicles since ticketing has not been
Avenue,
equipment requests
a viable deterrent
Brooklyn,
(Expense)
New York, NY
8/33
DYCD
Provide, expand, or
Residents particularly young people lack skills
District Wide
enhance skills
necessary for employment.
training and
employment
services for high
school students at
risk of dropping out
9/33
DHS
Expand homelessness prevention programs
There needs to be an expansion of cash assistance/rent negotiation programs as well as mortgage refinancing advisors to assist renters and homeowners remain in their housing.
District Wide
10/33
DSNY
Other enforcement
The Community District has exceeded the
District Wide
requests
Cleanliness Threshold for more than Ten (10)
consecutive years and therefore is eligible for a
review.
11/33
DFTA
Increase home
Significant number of elderly individuals and
District Wide
delivered meals
individuals living with multiple health problems,
capacity
shut-ins who depend on the Meals on Wheels
program.
12/33
DOHMH
Create or promote
Many socio - economic factors (cost of
District Wide
programs to de-
living/lack of affordable housing , employment,
stigmatize mental
cost of childcare, medical health problems, etc)
health problems
underlying contributors to a multitude of
and encourage
psychological disorder and maladaptive
treatment
behavior. In order to treat mental illness, the
root cause needs to be identified and resources
provided to helping individuals cope with
stressful situations. It is difficult for physicians to
ascertain the living conditions in which their
patients come from and return to after clinic
visits and especially after hospitalizations.
13/33
NYCTA
Expand bus service
For years, residents have complained about the
District Wide
frequency or hours
unreliable services delivered by the B8 bus line.
of operation
14/33
FDNY
Expand funding for
CB17 support full funding for fire Prevention
fire prevention and
Inspection Program, Fire Prevention Inspection
life safety initiatives
Team and the Juvenile Fire Setter Intervention
program, in addition to carbon monoxide and
smoke detectors for distribution to seniors and
the other population unable to afford the
purchase.
15/33
DYCD
Provide, expand, or
Funding for Computer literacy classes.
District Wide
enhance adult
literacy programs
services
16/33
NYPD
Other NYPD
The Precinct must update it's technology to keep
2820 Snyder
facilities and
up with the 21st century. We advocate for
Avenue
equipment requests
updated mobile technology and Wi-Fi service in
(Expense)
the Precinct.
17/33
DOT
Add street signage or wayfinding elements
There is a noticeable lack of truck enforcement signage in our district. Many resident complain of commercial trucks illegally driving and parking on roads in the community.
District Wide
18/33
DOT
Provide new traffic
It is very difficult for traffic emerging from the
East 40th
or pedestrian
side streets without hindrance vehicles
Street
signals
consistently obstructing full view.
Glenwood
Road
19/33
DPR
Provide more
Equipment that satisfies the workout
District Wide
programs in parks or
requirement of beginners as well as experienced
recreational centers
fitness buffs.
20/33
DOT
Provide new traffic
It is very difficult for traffic emerging from the
East 38th
or pedestrian
"Tercery streets without hindrance" Vehicles
Street
signals
consistently obstructed full view.
Glenwood
Road
21/33
HRA
Enhance cash
College students attending classes, interns
assistance programs
and/or graduates seeking employment, MTA
fare becomes a burden and creates a financial
hardship.
22/33
DOE
Other educational
Implementation of an "Out of School Time"
programs requests
(OST) Programs at P.S. 198. The Board stronly
supports the request for this program which is
designed to create a safe and nurturing
environment for children whose parents have to
work on non-school days and cannot afford the
added expense of paying for child care services.
23/33
SBS
Other expense
Create a sense of community and promote the
Church
commercial district
businesses in the area.
Avenue
revitalization
Nostrand
requests
Avenue
24/33
DPR
Forestry services,
Complaints of trees obstructing and/or clogging
East 43 Street
including street tree
drain pipes
Dead End
maintenance
Church
Avenue
25/33
DPR
Other street trees
Tree guards will enhance the beauty of the
Snyder
and forestry
district.
Avenue
services requests
Brooklyn
Avenue Troy
Avenue
26/33
DSNY
Provide more on- street trash cans and recycling containers
Request for an increased cleanliness of these areas. Unhealthy amount of garbage throughout the areas.
Utica Avenue Church Avenue Avenue D
27/33
DFTA
Enhance home care
There should be outreach services to
services
homebound older adults n elderly to allow them
to age in place. Many cannot afford long term
care of independent senior housig/communities
28/33
DOT
Provide new traffic
Very difficult for traffic emerging from the side
East 39th
or pedestrian
streets without hindrance. Vehicles consistently
Street
signals
obstructed full view.
Farragut Road
29/33
DOT
Provide new traffic
Very difficult for traffic emerging from the side
East 35 Street
or pedestrian
street without hindrance. Vehicles consistently
Farragut Road
signals
obstructing full view
30/33
DYCD
Provide, expand, or
Residents particularly young people lack skills
District Wide
enhance skills
necessary for employment.
training and
employment
services for high
school students at
risk of dropping out
31/33
DOHMH
Other programs to
Early mammogram testing means treatment
District Wide
address public
starts earlier.
health issues
requests
32/33
DSNY
Increase
The district lacks sufficient amount of inspectors
enforcement of
to properly enforce street cleaning.
dirty sidewalk/dirty
area/failure to clean
area laws
33/33
DEP
Clean catch basins
Prevents flooding
District Wide

