- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 3 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1OmcJo0p-O1D-i5RVBZOYwnXAWbI57Zhf/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1OmcJo0p-O1D-i5RVBZOYwnXAWbI57Zhf/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
3
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 3
image
Address: 1360 Fulton Street, 202
Phone: (718) 622-6601
Email: bk03@cb.nyc.gov
Website: www.nyc.gov/brooklyncb3
Chair: Richard Flateau District Manager: Henry Butler
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 3 is experiencing steady population growth at the rate of 6.3% between 2000 and 2010, outpacing New York City's overall growth rate of 2.1% in that same time period. While the majority (84.5%) of the population is of Black/African American and/or Hispanic origin, there has been a 10% decline among Black/African American residents. Of all age groups, the highest growth is taking place among residents between the ages of 20- 64 years old. Unemployment and income remain as two of CB3's top issues. According to the U.S. Census 2008-2012 5-year average, the unemployment rate for persons 16 years old and older is 8.8% in Community District 3, greater than the City's overall unemployment rate of 6.4%. In 2012, the median family income in New York City was
$57,113, compared to $44,300 in CB3. Out of all Brooklyn neighborhoods, CB3 also has the fourth largest number of residents with income less than 125% of the poverty level. In fact, more than one quarter of all families in CB3 live below the poverty level. These statistics reflect the need for greater investments in economic opportunities, social services, and community resources for the residents of Bedford-Stuyvesant. Although a number of social and economic issues persist, the overall outlook for Community District 3 is positive as local residents and stakeholders continue to come together to develop and implement community-centric solutions. Partnering with Community Board 3, civic and not-for-profit groups and local organizations such as Bedford Stuyvesant Restoration Corporation and the Bed-Stuy Gateway Business Improvement District are instrumental in multiplying the number of employment and business opportunities, enhancing the physical landscape of the district, and facilitating investments benefiting the community. These improvements will help create more pathways to economic prosperity and broaden the local tax base to support ongoing community growth.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 3
image
The three most pressing issues facing this Community Board are:
Affordable housing
Affordable housing is a critical issue in Community District 3 where the median income for all households is about
$40,600 and for families is $44,000. According to Renthop.com, the median rent in Bedford-Stuyvesant for one- bedroom apartments is $2,297 and $2,460 for two-bedrooms (up 3% in the past year). In order to afford an apartment most individuals and families would have to double their annual income -- putting affordability out of reach and contributing to extreme rent burdens and an acute homelessness crisis. We need more affordable housing options (including rents from extremely low income through middle income as well as home-ownership opportunities) that will enable individuals and families to live securely in our community.
Schools
Schools in Community District 3 traverse three different community school districts 13, 14, and 16, with the large majority in district 16. The community's schools lag in achievement and enrollment - a cycle that is self-fulfilling. Parents and children in our community deserve high-quality neighborhood schools. A true plan to make the schools work better must include a renewed effort from community education stake holders, the Department of Education, and the Mayor's office.
Trash removal & cleanliness
Population growth over the past decade has significantly impacted trash removal & cleanliness. Bedford-Stuyvesant is ranked 56 of 59 city's Community Districts (and 17, of 18, in Brooklyn) in street cleanliness according to the Department of Sanitation. There's been a large uptick in the rat population scurrying through the streets of the community at night. A combination of businesses failing to contract with private haulers and an inadequate number of street trash receptacles contributes to trash and lack of cleanliness along major corridors.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 3
image
M ost Important Issue Related to Health Care and Human Services
Mental health and substance abuse treatment and prevention programs
Bedford-Stuyvesant faces a wide array of negative health and wellness outcomes. In recent years, however, the community has experiences in the impacts from untreated mental health problems and substance use disorders. Community District 3 ranks in eighth citywide for adult psychiatric hospitalizations. K2/Spice and other synthetic cannabinoids has become a near epidemic in the District's northern corridor. The district needs mental health awareness that includes efforts to overcome stigma, wide distribution of Narcan, and prosecuting businesses that sell K2 and opioids.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
3/25
DOHMH
Create or promote
The district requests programming and
programs to de-
increased enforcement to combat the use of
stigmatize mental
K2/Spice and other synthetic cannabinoids, and
health problems
funding for preventative programming and
and encourage
services.
treatment
7/25
DOHMH
Reduce rat
Due to the overwhelming development projects,
populations
infrastructure repairs and increased renovation
on almost every street in the Bedford-
Stuyvesant community - the increasing rat
population besieges residents and businesses.
This presents safety and health issues for this
community.
11/25
DOHMH
Other programs to
The district requests creation and promotion of
address public
nutrition awareness and education on physical
health issues
activity, etc. specific to CB3’s most vulnerable
requests
populations (seniors and youth), programs to
address public health issues in CB3 (i.e. SHOP
Healthy Brooklyn), provide more HIV/AIDS
information and outreach, and promotion of
smoking cessation and anti-vaping programs.
17/25
DFTA
Other senior center
Community Board 3 requests that the
program requests
Department of Aging commit to a more
prominent physical presence in the Bedford-
Stuyvesant. A weekly pop-up resource center
that addresses the needs of our senior
population would greatly improve quality of
their lives here. The center would offer hands-on
assistance on housing support, health-related
issues - including insurance, access to medical
services, educational services and caretaker
support, among other things.
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 3
image
M ost Important Issue Related to Youth, Education and Child Welfare
Youth workforce development and summer youth employment
Summer is an important opportunity to engage teens and young adults. SYEP offers young people to chance to earn an income as they explore work and career opportunities. Meaningful engage youth with work increases their civic engagement, decreases the likelihood a young person will engage in petty crime, fosters self-confidence, builds skills, and provides necessary economic support for families.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
19/22
SCA
Renovate exterior
The children's play area at PS 3 is in disrepair
50 Franklin
building component
and no longer meets the needs of students and
Avenue,
community residents. It needs a complete
Brooklyn,
overhaul including adding better lighting and
New York, NY
security cameras.
20/22
SCA
Renovate exterior
The children's play area at MS 35 is in disrepair
272 Decatur
building component
and no longer meets the needs of students and
Street,
community residents. It needs a complete
Brooklyn,
overhaul including adding better lighting and
New York, NY
security cameras.
21/22
SCA
Provide technology
Provide 30 mobile computer labs, with 25
upgrade
laptops each, to be distributed to public schools
in CB3. In an effort to close the digital divide,
schools must be equipped with mobile computer
labs with laptops that provide meaningul access
to computer programs and the Internet for
students.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
5/25
DYCD
Provide, expand, or
Summer is an important opportunity to engage
enhance the
teens and young adults. SYEP offers young
Summer Youth
people to chance to earn an income as they
Employment
explore work and career opportunities.
Program
Meaningful engage youth with work increases
their civic engagement, decreases the likelihood
a young person will engage in petty crime,
fosters self-confidence, builds skills, and
provides necessary economic support for
families. We are requesting a minimum of 2,000
SYEP slots designated for Bedford-Stuyvesant
youth employment during the summer months.
6/25
DYCD
Provide, expand, or
Beacon and Cornerstone programs provide
enhance
essential services for community residents of all
Cornerstone and
ages. An expansion of Beacon and Cornerstone
Beacon programs
will go a long way to meeting the
(all ages, including
neighborhood's needs.
young adults)
9/25 DYCD Provide, expand, or
enhance after school programs for elementary school students (grades K- 5)
Learning should not stop at 3pm or during the summer. After school programs and summer camp should be a continuation of learning for elementary school kids. Also, with many parents working today, after school programs and summer camp are an important resource needed for our district.
image
22/25 DYCD Expand After School
Programs
Youth (pre-teens and teenagers) who are engaged in meaningful non-school activities have amongst the strongest outcomes as adults. We request more programming, staffed by skilled and caring adults, that engage youth after 6 pm during the week and all day on weekends (including late nights). Meaningful engagement reduces the chances a young person will get involved in the criminal justice system and helps to keep our community safe and vibrant.
image
23/25 DYCD Provide, expand, or
enhance the out-of- school youth program for job training and employment services
Bedford-Stuyvesant is experiencing an acute crisis of young adults (ages 18 to 26) who are "disconnected" (out-of-school and out-of-work). These young people are the most at-risk for experiencing homelessness and/or involvement in the criminal justice system. The community board requests deployment of a variety of programs and services designed to "reconnect" these young adults and help them build brighter futures.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 3
image
M ost Important Issue Related to Public Safety and Emergency Services
Police-community relations
Community District 3 works in close partnership with the 79th and 81st precincts, the local precinct councils, and PSA3 to promote more meaningful engagement between police and community. The NYPD's neighborhood policing approach and the introduction of neighborhood coordination officers are critical to building a more collaborative relationship with the community. We support those efforts and look forward to continuing to build bridges of dialogue and collaboration.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 3
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
Community District 3 is still without our own Sanitation Garage. We have been making this request since 1980. The designated site on Nostrand Avenue for our BK3 sanitation garage was acquired. There were multiple suits filed to prevent us from being able to utilize that site. We were successful in each of those litigations. Our demand is for OMB, DOS, the Mayor’s Office and the City Council to put the money back in the DSNY construction budget! In this district, there are other concerns that we deem crucial. Illegal dumping, which runs rampant is now endemic.
Sanitation does not have enough police to monitor and enforce infractions that are being committed. The DSNY police force must be increased so we can eliminate these problems.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
CS
DSNY
Provide new or
The City has control of the site identified for the
Nostrand &
upgrade existing
garage. The development of the scope of work
Park Avenue
sanitation garages
for the Community Board  3 Sanitation Garage
or other sanitation
was approved as an expense request two years
infrastructure
ago and should be completed. To improve the
environmental health in Community BD  3,
construction of the Sanitation Garage would be
a Capital request. Have a co-terminus sanitation
site in CB  3 will reduce gas emissions by
shortening the distance sanitation trucks must
travel to service this community board.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
4/25
DSNY
Increase
We need additional staff to deal with dumping
enforcement of
in lots, vacant buildings, parks, dog waste,
dirty sidewalk/dirty
closed businesses and even at our litter baskets.
area/failure to clean
This happens late at night or in the early hours
area laws
of the morning. All of this contributes to dirty
sidewalks and a dirty looking community. Our
low sanitation cleanliness scores confirm that
we need more enforcement. Without adequate
enforcement covering multiple shifts, this
condition cannot be obliterated. Community
Board 3 is requesting that funding be made
available for more enforcement officers and
request that Sanitation re-establish the signage
unit to combat the increased violations of dog
owners not picking up after their pets.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 3
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
The development of several parcels of land in the south eastern quadrant of Bedford-Stuyvesant, particularly on Fulton Street and Saratoga Avenue is crucial to the district, and we know that there are ongoing discussions regarding those parcels of land with HPD. The development of this land is an opportunity to create senior and affordable housing for the working people of Bedford Stuyvesant who are having a hard time finding affordable housing to raise their families in. A Community facility, startup incubator & general office space, a full service bank and a FRESH market can also be located within the new development. This development is an opportunity to incorporate sustainable features and practices in a mixed-use development project within Bedford Stuyvesant. We would like the Office of the Deputy Mayor for Economic Development and Rebuilding to direct a study to assess the need and impact of active manufacturing in northern sections of Bedford-Stuyvesant. Clear opportunities for either the attraction of industrial manufacturing and/or the protection of areas for manufacturing should be identified.
Additionally the study should include an assessment for the attraction of a green industry cluster appropriate and contextual to the Bedford-Stuyvesant neighborhood.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
No comments
Needs for Economic Development
Community Board 3 encompasses a vast area with diverse needs. In the past decade, Bedford-Stuyvesant has seen a significant uptick in start-up businesses and businesses moving to the area, yet many are forced to shutter due to high commercial rents. We know that a thriving community is one where small business can grow and be sustained. We need particular attention to small business development along our secondary commercial corridors, which serves portions resident without easy access to Fulton Street.
In addition, affordable homeownership remains a major obstacle in Bedford Stuyvesant. Studies show that the homeownership is the hallmark of a stable community. Rising home costs is making homeownership less achievable for many residents each day. Many long-time Bedford Stuyvesant residents find themselves unable to afford or maintain their homes, leaving them susceptible to foreclosure or unethical investors. These efforts disrupt the community’s cohesion.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
1/22 HPD Provide more
housing for medium income households
The Department of Housing Preservation & Development intends to release an RFP for land developemnt of various large plots in Bedford- Stuyvesants totaling nearly 70,000 square feet (block 1549, lots 19-34; block 1549, lot 407;
block 1548, lots 26-30; block 1557, lot 3; block
1557, lot 4; block 1557, lot 23; block 1557, lot
28, and; block 1557, lot 31-37). The Community Board strongly supports an RFP, to be awarded no later than FY2021 Q1, that develops affordable rental housing (from deeply affordable through middle income) and senior housing. We request that HPD prioritize proposals that commit to selecting MWBE contractors (beyond minimum levels) and incentives local hiring.
image
5/22 NYCHA Renovate or
upgrade public housing developments
Invest in maintaining and improving conditions of public housing building throughout community district 3. The conditions of many of the buildings is sub-par and an embarrassing representation of the city. Various developments need new boilers, secure doors, pest control and other structural improvements that will enhance residents' quality of life.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/25
HPD
Other affordable housing programs requests (expense)
Expansion of the agency's NIHOP program.
2/25
DOB
Assign additional
There is a tremendous amount of construction
building inspectors
going on in Bedford-Stuyvesant. In light of that,
(including
we are requesting additional inspectors for
expanding training
housing code compliance assigned to
programs)
Community Board 3. We often hear of collapses,
fires, toxic contamination and such in
connection with development projects. It is not
uncommon for developers to take short cuts but
this city, as a responsible overseer, should
provide adequate personnel to monitor
development throughout our community. The
citizens of this city deserve to be safe.
12/25
HPD
Provide or enhance
A majority of Bedford-Stuyvesant residents are
rental subsidies
rent burdened. The city should develop rent
programs
subsidy programs that will provide relief to
renters across a wide range of incomes.
13/25
SBS
Increase
We believe SBS should open a satellite office in
certification support
Brooklyn Community Board 3 if they are truly
for minority-,
trying to increase the number of MWBE
women-owned,
businesses from our community.
local and emerging
businesses
14/25
SBS
Provide or expand
Provide more job training programs in core skill
occupational skills
areas to young adults to create pipelines to
training programs
stable job and career opportunities.
16/25
EDC
Expand financial
Expand local job growth with public and private
incentives for job
companies.
creation and
retention
25/25
EDC
Expand tax incentive
Active commercial corridors are an important
programs to help
element of a thriving community. We request
neighborhood
expansion and continued support of tax
businesses construct
incentive programs that enable neighborhood
or improve space
business to improve their place of business
including facade restoration and attributes that
improve customer access.
TRANSPORTATION
Brooklyn Community Board 3
image
M ost Important Issue Related to Transportation and Mobility
Subway crowding and quality issues
The subway lines that run in and through Community District 3 are major arteries (A, C, G, J, M, Z) and connect to other popular neighbors in the city. Subject crowding, particularly during the morning commute borders, on dangerous. Deteriorating service has negatively contributing service quality and dramatically increased crowding. An investment in crowding easing, including improving spacing between trains, will go a long way to improving quality.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/22
NYCTA
Repair or upgrade
The Nostrand Avenue subway station on the "A"
subway stations or
and "C" line is a major subway hub that should
other transit
resemble a 21st century subway station. This
infrastructure
station should be completely renovated and
made ADA accessible. The rezoning of Fulton
street has brought higher density apartment
buildings with more retail. The usage of the
station has increased substantially, which is why
we are also requesting for the Bedford entrance
and station turnaround to be reopened.
7/22
DOT
Roadway
The Broadway corridor is in dire need of repair.
Broadway
maintenance (i.e.
Despite a recent surface repavement it remains
Flushing
pothole repair,
a roller coaster.
Avenue
resurfacing, trench
Saratoga
restoration, etc.)
Avenue
8/22
DOT
Roadway
Street has become a roller coaster with deep
Jefferson
maintenance (i.e.
depression in the middle of the street running
Avenue
pothole repair,
three quarters of the length of the block.
Stuyvesant
resurfacing, trench
Avenue
restoration, etc.)
Malcolm X
Boulevard
9/22
DOT
Roadway
In the middle of the block and near Stuyvesant
Macdonough
maintenance (i.e.
Avenue their is a deep depression. It's so bad
Street
pothole repair,
that the speed hump has actually sunk in.
Malcolm X
resurfacing, trench
Boulevard
restoration, etc.)
Stuyvesant
Avenue
CS
DOT
Roadway
There is a deep depression practically the full
Hancock
maintenance (i.e.
length of this block in the middle of the street.
Street
pothole repair,
You literally have to drive on the side and hope
Tompkins
resurfacing, trench
you don't hit a parked car on your left or right,
Avenue
restoration, etc.)
depending on which side you choose to drive on.
Marcy
Avenue
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
19/25 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
The following intersections need pedestrian safety improvements: Fulton Street & Tompkins/Brooklyn Aves. The intersection has a high rate of pedestrian and motorist injuries from collisions in the past five years and are located beside popular public transportation stops, within commercial shopping districts, and along important commuter routes. DOT has already recognized this intersections as a Vision Zero Priority Intersections and Priority Corridors. Crosswalk extensions, street markings, signal changes, and other safety improvements are requested to move vehicles safely, prevent injuries and improve quality of life in our commercial districts.
Fulton St. and Tompkins/Brooklyn Aves
image
20/25 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
The following intersection needs pedestrian safety improvements: Fulton Street & Albany Ave./Marcus Garvey Blvd. The intersection has a high rate of pedestrian and motorist injuries from collisions in the past five years and are located beside popular public transportation stops, within commercial shopping districts, and along important commuter routes. DOT has already recognized this intersections as a Vision Zero Priority Intersections and Priority Corridors. Crosswalk extensions, street markings, signal changes, and other safety improvements are requested to move vehicles safely, prevent injuries and improve quality of life in our commercial districts.
Fulton St. and Albany Ave/Marcus Garvey Blvd.
image
21/25 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
Intersection has a high rate of pedestrian and motorist injuries. High rate of pedestrian traffic due to Ralph Avenue A and C train stop, public school nearby and a NYCHA development at the corner.Crosswalk extensions, street markings, signal changes, and other safety improvements are requested to move vehicles safely, prevent injuries and improve quality of life in our commercial districts.
Fulton St. and Ralph Ave.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 3
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
As a community we continue to advocate for the better parks and playgrounds. Parks have always assisted our community in child development, community engagement through family events, physical activities, and a resource for our educators and their students. There are several assets in our district that require capital funding: • Improvements of Charlie’s Place ball field and hand ball court, • Improvements of comfort stations at Saratoga Park and Taffee playground, • Renovation of kitchen at Von King Culture Center, • Renovation of Kosciusko Pool into a year round facility, for which a feasibility study has been completed, and • A feasibility study on St. Andrew Park/Playground.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
The local branches of our libraries need to procure more recent selections of books. Current collection is dated. With an update, the libraries would be better used. Community Board 3 is requesting funding for newer selections of books at the Brooklyn Public Libraries.
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/22
DPR
Reconstruct or
St. Andrews Park, even in its current condition
upgrade a park or
remains a pivotal recreation destination in the
amenity (i.e.
Bedford Stuyvesant community where it resides
playground, outdoor
and for several organizations throughout the
athletic field)
borough that also use it. It has the potential to
be a jewel of a park although t has not been
renovated in decades and was the site of a
terrible incident concerning a Park's employee.
We are requesting funding for the following: to
completely reconstruct the playground and the
spray shower; to convert the asphalt field to a
more modern, and safe asphalt surface which
would include a Mondo perimeter track and
fencing; reconstruct the existing basketball
courts, adults fitness area to include fencing and
repair drainage; reconstruct the comfort station
and the perimeter sidewalks.
6/22
DPR
Provide a new, or
Convert the Kosciuszko Pool to a year-round
new expansion to, a
facility. The Koscuiszko Pool (K-Pool) is an vital
building in a park
community resource that is only used for 2 to 3
months a year. Similar to the project the convert
the McCarrren Pool in Greenpoint/Williamsburg
to year-round facility, our community would
benefit from a similar project at the Koscuiszko
Pool. During the final term of Former Council
Member Al Vann a feasibility study was
performed that found that the the K-Pool an
underused resource in an ever-expanding
community.
10/22
DPR
Reconstruct or
Jackie Robinson Park is need of new play
upgrade a park or
equipment. The equipment for the children is
amenity (i.e.
outdated and unsafe.
playground, outdoor
athletic field)
11/22
DPR
Reconstruct or
El-Shabazz Playground is another park in the
upgrade a park or
district with high usage by families. This park
amenity (i.e.
needs new and updated equipment. The current
playground, outdoor
equipment there is old and dangerous.
athletic field)
12/22
DPR
Reconstruct or
It has been many years since this playground
upgrade a park or
has been renovated. We have a growing
amenity (i.e.
population of families with small children who
playground, outdoor
need open space for their kids. We have several
athletic field)
apartment buildings being built within one to
two blocks from Potomac park.
13/22
DPR
Reconstruct or
The renovation of the kitchen was in the original
upgrade a building
plans for the overhaul of Von King Park's
in a park
Cultural Center; funding for the kitchen was
moved to the theater to make it ADA accessible
and correct violations. This request is for the
original project to be reinstated and would
include renovation of the kitchen and the
pottery kiln. The renovation of the kitchen and
addition of the pottery kiln would transform the
center into a state of the art training facility for
culinary studies and pottery.
14/22
DPR
Reconstruct or
It has been years since this comfort station has
upgrade a building
been upgraded. With the increase in population
in a park
of the community which has led to an increase
of usage of the park, we need for this facility to
be renovated
15/22
DPR
Reconstruct or
The request to convert Hancock Playground to a
upgrade a park or
green park space to include updated, resident
amenity (i.e.
friendly fences and hedges which would create
playground, outdoor
a more inviting environment; upgrade and
athletic field)
expand the existing children's play
equipment/sprinkler area; add perimeter race
track and sitting areas. Relocate the basketball
courts so that they dont consume the entire
park, and allow for diversifying the overall play
facilities. With t
16/22
BPL
Create a new, or
The Marcy Library has several large capital
617 De Kalb
renovate or upgrade
needs. They include ADA compliant bathrooms
Avenue,
an existing public
($500,000), safety and security enhancements
Brooklyn,
library
($200,000), exterior renovation ($1.2M), interior
New York, NY
renovation including initial outfitting, furniture,
fixtures and equipment ($1.5M), and roof
renovation ($1M). . The community board
requests that this renovation and restoration is
fully funded.
17/22
BPL
Create a new, or
The Bedford Library needs a significant exterior
496 Franklin
renovate or upgrade
renovation and window restoration ($3M). The
Avenue,
an existing public
community board requests that this renovation
Brooklyn,
library
and restoration is fully funded.
New York, NY
18/22
BPL
Create a new, or
The Macon Library has two major capital needs,
361 Lewis
renovate or upgrade
they are repair of the retaining wall ($600,000)
Avenue,
an existing public
and repair/replacement of HVAC system
Brooklyn,
library
($250,000). The community board requests that
New York, NY
this renovation and restoration is fully funded.
22/22
DPR
Reconstruct or
Community Board 3 is pleased that Charlie's
upgrade a park or
Place Playground was renovated, except for the
amenity (i.e.
basketball courts and the garden. Our request is
playground, outdoor
to have those two components completed as
athletic field)
well. Charlie's Place Playground is adjacent to
PS 373K, Brooklyn Transitional Center for
developmentally challenged students ages 9-12.
It is named after Charles Lubin, the founder of
Sara Lee. It is situated in a relatively new
community of families with young children. This
playground is situated in the middle of two
NYCHA developments and other playgrounds in
the area are an uncomfortable distance away,
where parents would not feel secure sending
their children.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
24/25
BPL
Extend library hours
Grow and expand the African American
361 Lewis
or expand and
Heritage Center at the Macon Library. We are
Avenue,
enhance library
requesting continued growth in the branch's
Brooklyn,
programs
collection and programming including public
New York, NY
events that highlight Black communities in
Brooklyn over time.
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
2/22
Other
Other capital budget
The Empire State Development Corporation is
357 Marcus
request
conducting a feasibility study on the 13th
Garvey
Regiment Avenue Armory on Marcus Garvey
Boulevard,
Blvd to maximize its use by the community. The
Brooklyn,
community board requests that the Economic
New York, NY
Development Corporation release an RFP that
will fund the Study's recommended overhaul of
the Armory.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
8/25
Other
Other expense
In recent years there's been an increase of deed
budget request
and property fraud incidents in Bedford
Stuyvesant. Many residents are being tricked
into signing over their long-held homes and
properties to unscrupulous dealers/agents. We
requesting that the King County District
Attorney Office work to continue to improve
enforcement and strengthen outreach and
awareness to owners and residents.
10/25
Other
Other expense
Community Board 3 would like to participate in
Hopkins
budget request
the Department of Transportation's A.P.T pilot
Street,
program. The self-sanitizing pay toilet
Brooklyn,
measuring 12' by 7.5', is about the size of an
New York, NY
empty tree pit, and is handicap accessible. We
are interested in siting a toilet at Charlie's Place.
This playground is near two NYCHA
developments and is heavily used, particularly
its newly renovated basketball and handball
courts. Adding this structure would make the
playground more of a destination instead of a
pit stop.
15/25
Other
Other expense
Community Board 3 requests that the Economic
budget request
Development Corporation provide space within
the district for start-ups and entrepreneurs can
expand and grow their small businesses.
18/25 LPC Expand staffing and
program related services
Bedford Stuyvesant has a large number of landmark buildings in three historic districts. Many residents struggle to maintain their buildings and too often they fall in disrepair. Expanded LPC staff to help with question and the review process and a program to support owners with loans or grants would help to maintain some of the city's most beautiful landmark areas.
image
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/22
HPD
Provide more
The Department of Housing Preservation &
housing for medium
Development intends to release an RFP for land
income households
developemnt of various large plots in Bedford-
Stuyvesants totaling nearly 70,000 square feet
(block 1549, lots 19-34; block 1549, lot 407;
block 1548, lots 26-30; block 1557, lot 3; block
1557, lot 4; block 1557, lot 23; block 1557, lot
28, and; block 1557, lot 31-37). The Community
Board strongly supports an RFP, to be awarded
no later than FY2021 Q1, that develops
affordable rental housing (from deeply
affordable through middle income) and senior
housing. We request that HPD prioritize
proposals that commit to selecting MWBE
contractors (beyond minimum levels) and
incentives local hiring.
2/22
Other
Other capital budget
The Empire State Development Corporation is
357 Marcus
request
conducting a feasibility study on the 13th
Garvey
Regiment Avenue Armory on Marcus Garvey
Boulevard,
Blvd to maximize its use by the community. The
Brooklyn,
community board requests that the Economic
New York, NY
Development Corporation release an RFP that
will fund the Study's recommended overhaul of
the Armory.
3/22
DPR
Reconstruct or
St. Andrews Park, even in its current condition
upgrade a park or
remains a pivotal recreation destination in the
amenity (i.e.
Bedford Stuyvesant community where it resides
playground, outdoor
and for several organizations throughout the
athletic field)
borough that also use it. It has the potential to
be a jewel of a park although t has not been
renovated in decades and was the site of a
terrible incident concerning a Park's employee.
We are requesting funding for the following: to
completely reconstruct the playground and the
spray shower; to convert the asphalt field to a
more modern, and safe asphalt surface which
would include a Mondo perimeter track and
fencing; reconstruct the existing basketball
courts, adults fitness area to include fencing and
repair drainage; reconstruct the comfort station
and the perimeter sidewalks.
4/22
NYCTA
Repair or upgrade
The Nostrand Avenue subway station on the "A"
subway stations or
and "C" line is a major subway hub that should
other transit
resemble a 21st century subway station. This
infrastructure
station should be completely renovated and
made ADA accessible. The rezoning of Fulton
street has brought higher density apartment
buildings with more retail. The usage of the
station has increased substantially, which is why
we are also requesting for the Bedford entrance
and station turnaround to be reopened.
5/22
NYCHA
Renovate or
Invest in maintaining and improving conditions
upgrade public
of public housing building throughout
housing
community district 3. The conditions of many of
developments
the buildings is sub-par and an embarrassing
representation of the city. Various developments
need new boilers, secure doors, pest control and
other structural improvements that will
enhance residents' quality of life.
6/22
DPR
Provide a new, or
Convert the Kosciuszko Pool to a year-round
new expansion to, a
facility. The Koscuiszko Pool (K-Pool) is an vital
building in a park
community resource that is only used for 2 to 3
months a year. Similar to the project the convert
the McCarrren Pool in Greenpoint/Williamsburg
to year-round facility, our community would
benefit from a similar project at the Koscuiszko
Pool. During the final term of Former Council
Member Al Vann a feasibility study was
performed that found that the the K-Pool an
underused resource in an ever-expanding
community.
7/22
DOT
Roadway
The Broadway corridor is in dire need of repair.
Broadway
maintenance (i.e.
Despite a recent surface repavement it remains
Flushing
pothole repair,
a roller coaster.
Avenue
resurfacing, trench
Saratoga
restoration, etc.)
Avenue
8/22
DOT
Roadway
Street has become a roller coaster with deep
Jefferson
maintenance (i.e.
depression in the middle of the street running
Avenue
pothole repair,
three quarters of the length of the block.
Stuyvesant
resurfacing, trench
Avenue
restoration, etc.)
Malcolm X
Boulevard
9/22
DOT
Roadway
In the middle of the block and near Stuyvesant
Macdonough
maintenance (i.e.
Avenue their is a deep depression. It's so bad
Street
pothole repair,
that the speed hump has actually sunk in.
Malcolm X
resurfacing, trench
Boulevard
restoration, etc.)
Stuyvesant
Avenue
10/22
DPR
Reconstruct or
Jackie Robinson Park is need of new play
upgrade a park or
equipment. The equipment for the children is
amenity (i.e.
outdated and unsafe.
playground, outdoor
athletic field)
11/22
DPR
Reconstruct or
El-Shabazz Playground is another park in the
upgrade a park or
district with high usage by families. This park
amenity (i.e.
needs new and updated equipment. The current
playground, outdoor
equipment there is old and dangerous.
athletic field)
12/22
DPR
Reconstruct or
It has been many years since this playground
upgrade a park or
has been renovated. We have a growing
amenity (i.e.
population of families with small children who
playground, outdoor
need open space for their kids. We have several
athletic field)
apartment buildings being built within one to
two blocks from Potomac park.
13/22
DPR
Reconstruct or
The renovation of the kitchen was in the original
upgrade a building
plans for the overhaul of Von King Park's
in a park
Cultural Center; funding for the kitchen was
moved to the theater to make it ADA accessible
and correct violations. This request is for the
original project to be reinstated and would
include renovation of the kitchen and the
pottery kiln. The renovation of the kitchen and
addition of the pottery kiln would transform the
center into a state of the art training facility for
culinary studies and pottery.
14/22
DPR
Reconstruct or
It has been years since this comfort station has
upgrade a building
been upgraded. With the increase in population
in a park
of the community which has led to an increase
of usage of the park, we need for this facility to
be renovated
15/22
DPR
Reconstruct or
The request to convert Hancock Playground to a
upgrade a park or
green park space to include updated, resident
amenity (i.e.
friendly fences and hedges which would create
playground, outdoor
a more inviting environment; upgrade and
athletic field)
expand the existing children's play
equipment/sprinkler area; add perimeter race
track and sitting areas. Relocate the basketball
courts so that they dont consume the entire
park, and allow for diversifying the overall play
facilities. With t
16/22
BPL
Create a new, or
The Marcy Library has several large capital
617 De Kalb
renovate or upgrade
needs. They include ADA compliant bathrooms
Avenue,
an existing public
($500,000), safety and security enhancements
Brooklyn,
library
($200,000), exterior renovation ($1.2M), interior
New York, NY
renovation including initial outfitting, furniture,
fixtures and equipment ($1.5M), and roof
renovation ($1M). . The community board
requests that this renovation and restoration is
fully funded.
17/22
BPL
Create a new, or
The Bedford Library needs a significant exterior
496 Franklin
renovate or upgrade
renovation and window restoration ($3M). The
Avenue,
an existing public
community board requests that this renovation
Brooklyn,
library
and restoration is fully funded.
New York, NY
18/22
BPL
Create a new, or
The Macon Library has two major capital needs,
361 Lewis
renovate or upgrade
they are repair of the retaining wall ($600,000)
Avenue,
an existing public
and repair/replacement of HVAC system
Brooklyn,
library
($250,000). The community board requests that
New York, NY
this renovation and restoration is fully funded.
19/22
SCA
Renovate exterior
The children's play area at PS 3 is in disrepair
50 Franklin
building component
and no longer meets the needs of students and
Avenue,
community residents. It needs a complete
Brooklyn,
overhaul including adding better lighting and
New York, NY
security cameras.
20/22
SCA
Renovate exterior
The children's play area at MS 35 is in disrepair
272 Decatur
building component
and no longer meets the needs of students and
Street,
community residents. It needs a complete
Brooklyn,
overhaul including adding better lighting and
New York, NY
security cameras.
21/22
SCA
Provide technology
Provide 30 mobile computer labs, with 25
upgrade
laptops each, to be distributed to public schools
in CB3. In an effort to close the digital divide,
schools must be equipped with mobile computer
labs with laptops that provide meaningul access
to computer programs and the Internet for
students.
22/22
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Community Board 3 is pleased that Charlie's Place Playground was renovated, except for the basketball courts and the garden. Our request is to have those two components completed as well. Charlie's Place Playground is adjacent to PS 373K, Brooklyn Transitional Center for developmentally challenged students ages 9-12. It is named after Charles Lubin, the founder of Sara Lee. It is situated in a relatively new community of families with young children. This playground is situated in the middle of two NYCHA developments and other playgrounds in the area are an uncomfortable distance away, where parents would not feel secure sending their children.
CS
DSNY
Provide new or upgrade existing sanitation garages or other sanitation infrastructure
The City has control of the site identified for the garage. The development of the scope of work for the Community Board  3 Sanitation Garage was approved as an expense request two years ago and should be completed. To improve the environmental health in Community BD  3, construction of the Sanitation Garage would be a Capital request. Have a co-terminus sanitation site in CB  3 will reduce gas emissions by shortening the distance sanitation trucks must travel to service this community board.
Nostrand & Park Avenue
CS
DOT
Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
There is a deep depression practically the full length of this block in the middle of the street. You literally have to drive on the side and hope you don't hit a parked car on your left or right, depending on which side you choose to drive on.
Hancock Street Tompkins Avenue Marcy Avenue
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
HPD
Other affordable
Expansion of the agency's NIHOP program.
housing programs
requests (expense)
2/25
DOB
Assign additional
There is a tremendous amount of construction
building inspectors
going on in Bedford-Stuyvesant. In light of that,
(including
we are requesting additional inspectors for
expanding training
housing code compliance assigned to
programs)
Community Board 3. We often hear of collapses,
fires, toxic contamination and such in
connection with development projects. It is not
uncommon for developers to take short cuts but
this city, as a responsible overseer, should
provide adequate personnel to monitor
development throughout our community. The
citizens of this city deserve to be safe.
3/25
DOHMH
Create or promote
The district requests programming and
programs to de-
increased enforcement to combat the use of
stigmatize mental
K2/Spice and other synthetic cannabinoids, and
health problems
funding for preventative programming and
and encourage
services.
treatment
4/25
DSNY
Increase
We need additional staff to deal with dumping
enforcement of
in lots, vacant buildings, parks, dog waste,
dirty sidewalk/dirty
closed businesses and even at our litter baskets.
area/failure to clean
This happens late at night or in the early hours
area laws
of the morning. All of this contributes to dirty
sidewalks and a dirty looking community. Our
low sanitation cleanliness scores confirm that
we need more enforcement. Without adequate
enforcement covering multiple shifts, this
condition cannot be obliterated. Community
Board 3 is requesting that funding be made
available for more enforcement officers and
request that Sanitation re-establish the signage
unit to combat the increased violations of dog
owners not picking up after their pets.
5/25
DYCD
Provide, expand, or
Summer is an important opportunity to engage
enhance the
teens and young adults. SYEP offers young
Summer Youth
people to chance to earn an income as they
Employment
explore work and career opportunities.
Program
Meaningful engage youth with work increases
their civic engagement, decreases the likelihood
a young person will engage in petty crime,
fosters self-confidence, builds skills, and
provides necessary economic support for
families. We are requesting a minimum of 2,000
SYEP slots designated for Bedford-Stuyvesant
youth employment during the summer months.
6/25
DYCD
Provide, expand, or
Beacon and Cornerstone programs provide
enhance
essential services for community residents of all
Cornerstone and
ages. An expansion of Beacon and Cornerstone
Beacon programs
will go a long way to meeting the
(all ages, including
neighborhood's needs.
young adults)
7/25
DOHMH
Reduce rat
Due to the overwhelming development projects,
populations
infrastructure repairs and increased renovation
on almost every street in the Bedford-
Stuyvesant community - the increasing rat
population besieges residents and businesses.
This presents safety and health issues for this
community.
8/25
Other
Other expense
In recent years there's been an increase of deed
budget request
and property fraud incidents in Bedford
Stuyvesant. Many residents are being tricked
into signing over their long-held homes and
properties to unscrupulous dealers/agents. We
requesting that the King County District
Attorney Office work to continue to improve
enforcement and strengthen outreach and
awareness to owners and residents.
9/25
DYCD
Provide, expand, or
Learning should not stop at 3pm or during the
enhance after
summer. After school programs and summer
school programs for
camp should be a continuation of learning for
elementary school
elementary school kids. Also, with many parents
students (grades K-
working today, after school programs and
5)
summer camp are an important resource
needed for our district.
10/25
Other
Other expense
Community Board 3 would like to participate in
Hopkins
budget request
the Department of Transportation's A.P.T pilot
Street,
program. The self-sanitizing pay toilet
Brooklyn,
measuring 12' by 7.5', is about the size of an
New York, NY
empty tree pit, and is handicap accessible. We
are interested in siting a toilet at Charlie's Place.
This playground is near two NYCHA
developments and is heavily used, particularly
its newly renovated basketball and handball
courts. Adding this structure would make the
playground more of a destination instead of a
pit stop.
11/25
DOHMH
Other programs to
The district requests creation and promotion of
address public
nutrition awareness and education on physical
health issues
activity, etc. specific to CB3’s most vulnerable
requests
populations (seniors and youth), programs to
address public health issues in CB3 (i.e. SHOP
Healthy Brooklyn), provide more HIV/AIDS
information and outreach, and promotion of
smoking cessation and anti-vaping programs.
12/25
HPD
Provide or enhance
A majority of Bedford-Stuyvesant residents are
rental subsidies
rent burdened. The city should develop rent
programs
subsidy programs that will provide relief to
renters across a wide range of incomes.
13/25
SBS
Increase
We believe SBS should open a satellite office in
certification support
Brooklyn Community Board 3 if they are truly
for minority-,
trying to increase the number of MWBE
women-owned,
businesses from our community.
local and emerging
businesses
14/25
SBS
Provide or expand
Provide more job training programs in core skill
occupational skills
areas to young adults to create pipelines to
training programs
stable job and career opportunities.
15/25
Other
Other expense
Community Board 3 requests that the Economic
budget request
Development Corporation provide space within
the district for start-ups and entrepreneurs can
expand and grow their small businesses.
16/25
EDC
Expand financial
Expand local job growth with public and private
incentives for job
companies.
creation and
retention
17/25 DFTA Other senior center
program requests
Community Board 3 requests that the Department of Aging commit to a more prominent physical presence in the Bedford- Stuyvesant. A weekly pop-up resource center that addresses the needs of our senior population would greatly improve quality of their lives here. The center would offer hands-on assistance on housing support, health-related issues - including insurance, access to medical services, educational services and caretaker support, among other things.
image
18/25 LPC Expand staffing and
program related services
Bedford Stuyvesant has a large number of landmark buildings in three historic districts. Many residents struggle to maintain their buildings and too often they fall in disrepair. Expanded LPC staff to help with question and the review process and a program to support owners with loans or grants would help to maintain some of the city's most beautiful landmark areas.
image
19/25 DOT Improve traffic and
pedestrian safety, including traffic calming (Expense)
The following intersections need pedestrian safety improvements: Fulton Street & Tompkins/Brooklyn Aves. The intersection has a high rate of pedestrian and motorist injuries from collisions in the past five years and are located beside popular public transportation stops, within commercial shopping districts, and along important commuter routes. DOT has already recognized this intersections as a Vision Zero Priority Intersections and Priority Corridors. Crosswalk extensions, street markings, signal changes, and other safety improvements are requested to move vehicles safely, prevent injuries and improve quality of life in our commercial districts.
Fulton St. and Tompkins/Brooklyn Aves
image
image
20/25
DOT
Improve traffic and
The following intersection needs pedestrian
Fulton St. and
pedestrian safety,
safety improvements: Fulton Street & Albany
Albany
including traffic
Ave./Marcus Garvey Blvd. The intersection has a
Ave/Marcus
calming (Expense)
high rate of pedestrian and motorist injuries
Garvey Blvd.
from collisions in the past five years and are
located beside popular public transportation
stops, within commercial shopping districts, and
along important commuter routes. DOT has
already recognized this intersections as a Vision
Zero Priority Intersections and Priority Corridors.
Crosswalk extensions, street markings, signal
changes, and other safety improvements are
requested to move vehicles safely, prevent
injuries and improve quality of life in our
commercial districts.
21/25
DOT
Improve traffic and
Intersection has a high rate of pedestrian and
Fulton St. and
pedestrian safety,
motorist injuries. High rate of pedestrian traffic
Ralph Ave.
including traffic
due to Ralph Avenue A and C train stop, public
calming (Expense)
school nearby and a NYCHA development at the
corner.Crosswalk extensions, street markings,
signal changes, and other safety improvements
are requested to move vehicles safely, prevent
injuries and improve quality of life in our
commercial districts.
22/25
DYCD
Expand After School
Youth (pre-teens and teenagers) who are
Programs
engaged in meaningful non-school activities
have amongst the strongest outcomes as
adults. We request more programming, staffed
by skilled and caring adults, that engage youth
after 6 pm during the week and all day on
weekends (including late nights). Meaningful
engagement reduces the chances a young
person will get involved in the criminal justice
system and helps to keep our community safe
and vibrant.
23/25
DYCD
Provide, expand, or
Bedford-Stuyvesant is experiencing an acute
enhance the out-of-
crisis of young adults (ages 18 to 26) who are
school youth
"disconnected" (out-of-school and out-of-work).
program for job
These young people are the most at-risk for
training and
experiencing homelessness and/or involvement
employment
in the criminal justice system. The community
services
board requests deployment of a variety of
programs and services designed to "reconnect"
these young adults and help them build brighter
futures.
24/25
BPL
Extend library hours or expand and enhance library programs
Grow and expand the African American Heritage Center at the Macon Library. We are requesting continued growth in the branch's collection and programming including public events that highlight Black communities in Brooklyn over time.
361 Lewis Avenue, Brooklyn, New York, NY
25/25
EDC
Expand tax incentive programs to help neighborhood businesses construct or improve space
Active commercial corridors are an important element of a thriving community. We request expansion and continued support of tax incentive programs that enable neighborhood business to improve their place of business including facade restoration and attributes that improve customer access.
