- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 6 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1kyZLLBgzkdJz-Jf5njHhKCSDlOBeH7vY/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1kyZLLBgzkdJz-Jf5njHhKCSDlOBeH7vY/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
6
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 6
image
Address: 1932 Arthur Avenue, 403-A Phone: (718) 579-6990
Email: bronxcb6@bronxcb6.org
Website: www.bronxcb6.org
Chair: Evonne Capers District Manager: John Sanchez
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Bronx Community District 6 covers 983.8 square miles in central Bronx, serving the communities of Belmont, Bathgate, Tremont and West Farms. According to the 2010 census, our population was 83,268. Bronx CB 6 is primarily populated by low income residents. It is tied for the highest unemployment rate in NYC at 18.2% and has the second highest percentage of its population under the age of 18 at 30%. 60% of residents receive some form of income assistance with 31.4% of residents living under the NYCgov poverty threshold. The median income is about
$22,600 per year. At present, major development is slated for Community Board 6 with nearly 3,000 new housing units and at least 72,000 square feet of commercial/retail space in the next 5-10 years. The growing population requires the construction of more schools to ease overcrowding as well as additional day care facilities. CB 6 has the East Tremont commercial corridor which has several small businesses, but also several vacant commercial spaces.
This corridor has great potential, but the small businesses need assistance in getting organized to fulfill it. Developing this corridor would help create more jobs that pay living wages. In 2011, parts of East Tremont Avenue were rezoned. Since 2011, only one building owner has taken advantage of the rezoning.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 6
image
The three most pressing issues facing this Community Board are:
Crime
3. CRIME: Certain areas of crime are increasing in the district. As of October 2018, the district has seen an increase in murders, rapes, misdemeanor sex crimes, and misdemeanor assaults compared to 2017. While the NCO program has helped reduce crime, it still is a concern to many. The impact of shootings is especially troublesome as it discourages city residents from moving into the neighborhoods, businesses from opening in the district, and other stakeholders from investing in the area due to a perception of danger. While increased NYPD presence is important so are the underlying causes of crime that must be addressed through efforts to reduce unemployment, supporting the previously incarcerated, and steering low-level offenders toward diversion and educational programs.
Schools
1. SCHOOLS: Bronx Community Board 6 schools are severely overcrowded and underperforming. The School Construction Authority's most recent capital plan states that there is a 1,144 student seat need between the Fordham/Belmont and Tremont/West Farms neighborhoods. This does not include the 912 seats funded in Tremont/West Farms that are not in the design and scope phase. It's imperative that with increased housing development that there is also infrastructure investment in schools to support the growing population. When it comes to school performance, more than 70% of students in CB 6 are not proficient in Math and Reading based on NY State Test scores for 3rd - 8th graders. Overcrowded and underperforming school districts are a major deterrent to new families thinking of moving into the neighborhood.
Unemployment
1. UNEMPLOYMENT: Community Board 6 has the highest unemployment rate of any community board in NYC (18.2%). Also, due to the fact that only 12.3% of residents older than 25 have a college degree, it's vital that there are increased job opportunities for those with a high school diploma and those without it. Unemployment rates are correlated to crime rates and it is an issue that if improved can have ripple effects in other areas.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 6
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
Many Health and Human service issues derive from homelessness. Opioid abuse and addiction plagues the homeless population in our district. Low-income residents who are homeless do not have access to healthy food options, are most likely to get an infectious disease, have mental issues and are prone to domestic violence.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Health issues are of great concern to Community Board 6. As of 2015, Bronx Community Board 6 ranks first in the percentage of adults that are obese (35%), ranks third in the percentage of adults with diabetes, fourth in child asthma hospitalizations, sixth in the number of hospitalizations due to stroke, and seventh in rate of adult psychiatric hospitalizations. Moreover, these statistics are exacerbated by Bronx Community Board 6 ranking last in supermarket square footage per 100 people.
Needs for Older NYs
Seniors are in need of more education on safety as well as recreation activities. There are few senior centers for older new yorkers in the district as well as places for them to access resources.
Needs for Homeless
Community Board 6 houses 22 shelter facilities and multiple organizations that provide services for the homeless population (i.e. people with substance abuse, rehabilitation services, formerly incarcerated, etc.). The board has had more than its fair share of shelters and does not wish to have additional facilities. We advocate for more permanent housing rather than shelters.
Needs for Low Income NYs
Many residents within Bronx Community District 6 are low-income and vulnerable New Yorkers. Bronx Community District 6 is among the poorest community districts in New York City. As of 2016, the median income for Bronx Community District 6 is $23,710 and 30.8% of Bronx Community District 6 residents live below the New York City poverty threshold (ACS 2012-2016). The low income population of District 6 is of great concern because it affects other aspects of their lives, i.e. health care, education, crime. Additionally, District 6 serves as home to many immigrants; 31.3% of residents are foreign-born. Due to documentation issues, lack of experience and education needed, many of these residents may not have access to high paying jobs.
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
6/16
DFTA
Renovate or
Currently, about 1000 square feet of upstair
2405
upgrade a senior
space at Mt. Carmel Center for Senior Citizens is
Southern Blvd
center
empty and unused in the facility. It will require
full renovation in order to be utilized, and will
enable more services and programming to be
available to seniors in the community.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/25
HRA
Provide, expand, or
There needs to be stronger job placement
enhance job search
support for those without college degrees in CB
and placement
6. Only 7.2% of residents over the age of 25
support
have a college degree and as a result job
placement needs to be targeted to the
population for jobs that do not require a
bachelor's degree ie (construction or tech
industry).
9/25
DHS
Provide programs
Funding is needed for expanded programming
for homeless
and regular case consultation meetings to
veterans
ensure chronically homeless veterans are moved
into shelters, and that each veteran within the
system receive the attention needed to create a
pathway to permanent housing for each
veteran.
19/25
DHS
Provide rental
With more than 26 homeless shelters, more
assistance/vouchers
vouchers are needed for residents to have
for permanent
permanent housing
housing
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 6
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
SCA states that School District 12, which is largely in CB 6, has an unfunded need of 572 seats. Furthermore, more than 3,000 units of housing are being built between 2017-2025 which will result in a larger student population. We will need new schools in our district to accommodate this increased need.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
CB 6 has a 1,144 school seat need between the Belmont/Fordham and Tremont/West Farms neighborhoods as well as 912 seats that are funded but not in the scope and design phase. This great student seat need does not account for the nearly 3,000 additional units of housing that will be developed in the district in the next 10 years. The district needs more elementary and middle schools to ease overcrowding.
Needs for Youth and Child Welfare
Provide more day care centers so that parents can work during the day. Enhance funding for child protective services.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
1/16
SCA
Provide a new or
SCA states that School District 12, which is
expand an existing
largely in CB 6, has an unfunded need of 572
elementary school
seats. We request that an elementary school is
built to accommodate the over 2,000 units of
housing being built between 2015-2025 which
will result in a larger student population. We
also request that SCA accelerates its timeline to
design and scope the 912 seats that are funded.
2/16
SCA
Provide a new or
SCA states that School District 12, which is
expand an existing
largely in CB 6, has an unfunded need of 572
middle/intermediate
seats. School District 12, which is in CB 6
school
,currently has a greater than 160% utilization
rate for its middle schools. We request that a
middle school is built to accommodate the over
2,000 units of housing being built between
2015-2025 which will result in a larger student
population. A new school is necessary to ease
overcrowding. We also request that SCA
accelerates its timeline to design and scope the
912 seats that are funded.
11/16
SCA
Renovate or
The auditorium in P.S. 67 Mohegan School
2024
upgrade an
needs to be renovated. The community board
Mohegan Ave
elementary school
requests that funding be allocated towards this
much needed upgrade.
13/16
SCA
Provide a new or
The community is requesting a P-Tech school to
expand an existing
allow students to receive an associate's degree
high school
in four years as well as pursue a career in
technology
16/16
SCA
Provide technology
MS 45 needs a technological upgrade with an
2502 Lorillard
upgrade
increase in laptops
Place Bronx,
NY 10458
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
4/25
DYCD
Provide, expand, or
125,000 to 150,000 SYEP slots should be
enhance the
allocated to fulfill the demand of students
Summer Youth
seeking employment
Employment
Program
5/25
DYCD
Provide, expand, or
More staffing needed for the Murphy
601 Crotona
enhance
Cornerstone center
Park North
Cornerstone and
Bronx, NY
Beacon programs
10457
(all ages, including
young adults)
8/25
ACS
Provide, expand, or
CB 6 has a large number of youth in foster care
enhance preventive
and these youth must receive more preventive
services and
services and alternatives to detention
community based
alternatives for
youth
11/25
DYCD
Provide, expand, or
We request more for Adult Basic Education, HSE,
enhance adult
and ESOL
literacy programs
services
12/25
DYCD
Provide, expand, or
There should be universal after school program
enhance after
offerings at each elementary school in Bronx CB
school programs for
6
elementary school
students (grades K-
5)
16/25
DYCD
Provide, expand, or
CB 6's HS graduation rate is below the NYC rate
enhance the out-of-
and thus there is a greater need for
school youth
employment services for these youth
program for job
training and
employment
services
18/25
DYCD
Provide, expand, or
There needs to be more year round offerings for
enhance skills
students to work, not just the summer so they
training and
can stay engaged and not drop out of school.
employment
services for high
school students at
risk of dropping out
23/25
DOE
Assign more
More teaching staff to accommodate Eagle
4143 Third
teaching staff
Academy
Ave Bronx, NY
10457
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 6
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
While crime has largely declined across the city, there are still categories of crime that have increased in Bronx Community District 6. As of October 2018, the district has seen an increase in murders, rapes, misdemeanor assaults, and misdemeanor sex crimes. While the NCO program has helped reduce crime, it still is a concern to many and still needs to be addressed.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Shootings and other crimes have declined in the community but certain crimes have increased such as murder (42.9% increase), rape (16.7%), misdemeanor assaults (2.5%), and misdemeanor sex crimes (32.4%). Expanding the NCO program as well as the NYPD Explorer and other youth programs would help further reduce crime by allowing officers to be more present as well as have more youth involved in their community.
Needs for Emergency Services
Agencies such as the Fire Department , EMS ,and NYPD should be equipped to service the public with adequate equipment and manpower.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
9/16
NYPD
Provide surveillance cameras
The community board is requesting surveillance cameras on Park Avenue between East 183rd Street and East 188th Street.
Park Avenue East 182nd Street East 183rd Street
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
15/25
NYPD
Assign additional community affairs officers
More community affairs officers to handle the several street activities in CB 6
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 6
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
Trash collection has always been an issue in Community District 6. It's not uncommon to see heaps of trash on streets, on corners, and in open spaces, such as parks and plazas. Our trash cans in the district often overflow, adding to the problem. We have received a total of 362 311 complaints regarding unsanitary conditions related to garbage and recycling storage in the last year, causing residents to throw trash on the ground. This is undoubtedly a hazard to all residents, as it contributes to the overall pollution and rodent infestation. In total, we have received 1393 311 complaints related to pests. Instead of garbage being put on the sidewalk, a few parking spaces should be removed to accommodate dumpsters the trash can be placed in.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Sewers need to be inspected and cleaned frequently so as to avoid clogging, dumping. Hydrants should also be inspected in order to ensure that water flows properly or that they are always in working order.
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
13/25
DSNY
Provide more
Litter baskets are frequently filled to the brim
Bathgate
frequent litter
and overflowing, contributing to more garbage
Avenue East
basket collection
on the streets and sidewalks.
Tremont
Avenue East
184th Street
14/25
DSNY
Provide more on-
There is a desperate need in our district for
Bathgate Ave
street trash cans
additional street corner garbage collection cans.
178th Street
and recycling
The Sanitation Department should purchase and
180th Street
containers
allocate additional collection cans to our
district. The need for additional collection cans
is particularly acute along our district
commercial strips (Arthur Avenue, East Tremont
Avenue).
24/25
DSNY
Provide more on-
Southern Blvd from E 183rd to Fordham Road
Southern Blvd
street trash cans
does not have enough trash cans though it is
183rd Street
and recycling
heavily trafficked due to proximity to the Bronx
Fordham
containers
Zoo
Road
25/25
DSNY
Increase
ASP is not followed on Vyse Ave between E
Vyse Ave E
enforcement of
179th and E 180th
179th E 180th
alternate street
parking cleaning
rules
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 6
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
The need for affordable housing is great in Bronx CB 6 which has a low median income. Upzonings of more segments of CB 6 should be explored to allow for more housing to be built.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
East Tremont Avenue has had little development since its 2011 rezoning. East Tremont Avenue from Webster Avenue to Belmont Avenue was rezoned to C4-5X, a mid-density contextual district that allows for increased Floor Area Ratio for mixed-use development. East Tremont Avenue between Belmont Avenue and Marmion Avenue was rezoned to C4-4A, a mid-density contextual district that allows for full commercial development where it previously was not permitted. The strip has the potential to revitalize the neighborhood with more employment opportunities, housing, and schools.
Needs for Housing
According to the American Community Survey 2012-2016 5-year Estimates, 51.6% of Bronx Community District 6 residents are rent burdened, spending more than 35% of their total income on rent. While we applaud the efforts put forth by the city to increase the development of affordable housing, "affordable housing" under 421-a often does not serve residents of our community, who predominantly fall within 20% to 30% of New York City's Average Median Income.
Needs for Economic Development
Although Community Board 6 has two Business Improvement Districts (Belmont and Fordham), merchants on the East Tremont commercial corridor are struggling. There is little diversity in the types of retail businesses offered on the strip, comprising fast food chains and discount stores. There are also more than half a dozen vacant commercial spaces in the district which discourages investment in the area.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
4/16
HPD
Provide more
52% of households in our district spend 35% or
housing for
more of their income on rent. Our district is in
extremely low and
need of more affordable housing (20-30% AMI)
low income
so that our residents are able to achieve a
households
higher quality of life without concern of losing
their homes.
5/16
HPD
Provide more
HPD has been doing an admirable job in
housing for medium
providing income for low and extremely low-
income households
oncome households. However, in order to spur
more development it is important that more
housing is provided for middle-income
households in the form of rentals and home
ownership opportunities in order to have people
more invested in the community.
7/16
NYCHA
Install security
Bronx Community Board 6 greatly appreciates
cameras or make
the 64 security cameras allocated for our
other safety
district, however we are in need of more
upgrades (Capital)
cameras. We request to have more cameras
near 1010 East 178th Street and Monterey
Houses, as well as lighting in hallways and
around the perimeter of buildings.
8/16
HPD
Provide more
We are requesting more funding be allocated
housing for special
for housing for special needs households in our
needs households,
district. With 52% of households in our district
such as the formerly
spending 35% or more of their income on rent,
homeless
many residents in our district are struggling to
make ends meet in order to keep their homes.
Our seniors and formerly homeless residents are
especially vulnerable and at risk of losing their
homes with fixed incomes.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
2/25
SBS
Help job seekers
Bronx Community Board 6 is tied for first in
connect to
unemployment rates in New York City at 18.2%.
employment
Additionally, 31.4% of residents live below the
poverty threshold. More needs to be done
directly in our district so that our residents are
provided with viable job options to help lift
themselves and their families out of poverty.
Employment should include the culinary and
tech industries.
3/25
DCP
Study land use and
The West Farms area, specifically E 180th
East 180th St
zoning to better
between Southern Blvd. to Morris Park Ave
Southern
match current use
should be studied to see if it can be up zoned for
Blvd. Morris
or future
higher commercial and residential projects.
Park Ave
neighborhood
needs
TRANSPORTATION
Bronx Community Board 6
image
M ost Important Issue Related to Transportation and Mobility
Bus service (frequency and access)
Community Board 6 only has two train stations, (West Farms-East Tremont and E 180th) and they are both on the eastern border of the district. Thus residents rely on bus service which is often delayed and crowded. Bus service needs to be improved especially since the neighborhood's population is increasing with new housing developments.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
Residents often complain of subways not working, running on time etc. MTA does not have in place cleaning crews for the upkeep of surrounding areas, cutting weeds, garbage etc.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
10/16
NYCTA
Improve
The E 174th Street station does not have
accessibility of
elevators or escalators to provide ADA access.
transit
infrastructure, by
providing elevators,
escalators, etc.
12/16
DOT
Repair or provide
Southern Blvd from E 183rd to Fordham Road is
Southern Blvd
new street lights
extremely dark at night and needs more lighting
E 183rd
Fordham
Road
14/16
DOT
Repair or construct
Southern Blvd between E 183rd and Fordham
Southern Blvd
new curbs or
Road needs new curbs and ramps.
E 183rd
pedestrian ramps
Fordham
Road
15/16
DOT
Roadway
E 180th between Webster Abe and Boston Road
E 180th
maintenance (i.e.
needs resurfacing
Webster Ave
pothole repair,
Boston Road
resurfacing, trench
restoration, etc.)
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
17/25
NYCTA
Expand bus service
The community board requests increased bus
frequency or hours
service frequency for all busses and, more
of operation
specifically, the Bx 15 and Bx17.
20/25
DOT
Address traffic
Southern Boulevard between East Fordham
Southern
congestion
Road and East 187th Street has consistent
Boulevard
congestion with school buses, MTA buses, and
East Fordham
cars
Road East
187th Street
21/25
DOT
Other expense
The community board is requesting improved
East Tremont
traffic
cross walks at Boston Road and East Tremont.
Avenue
improvements
Boston Road
requests
West Farms
Road
22/25 NYCTA Provide a new bus
service or Select Bus Service
We request a new bus stop be added to the BxM10 line on E 177th and Devoe or E 180th bet. E Tremont and Devoe Ave before the bus goes onto the highway.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 6
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
Although this District is endowed with numerous parks, many residents express concern about the low level of parks care and maintenance. Frequently, residents have reported excess litter in our parks, particularly on the weekends. Additionally, there have been complaints of loitering and drug use.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Additional Parks personnel is needed for the upkeep, i.e. cleaning, monitoring, pruning of all parks, malls.
Needs for Cultural Services
Although Community Board 6 hosts a state of the arts cultural center ( Bronx River Arts Center) more support is need for after school programs and beacon programs to fulfill the need of the growing youth population in our district.
Needs for Library Services
Community Board 6 has always been supportive of libraries. Continued support is needed to allow the NYPL to provide essential programs and services, such as ESOL classes, after school programs, technology training and world class research services, to the residents of this community.
Needs for Community Boards
Although the budgets for community planning boards have increased, the current budget only allows for the hiring of a third staff person. The responsibilities of the community board are monumental , there are at least 50 volunteer board members, numerous meetings, and many issues on a daily basis that require immediate attention.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/16
DPR
Reconstruct or
We request that Fairmount Playground be
upgrade a park or
renovated including the asphalt and benches so
amenity (i.e.
it can be used for the community. Currently the
playground, outdoor
disrepair of the park precludes community use.
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/25
DPR
Provide better park
In order to increase the level of service and
maintenance
parks and to keep up with new additions to the
parks system, 81 City Park Workers are
requested to service the parks throughout the
borough. These CPW's will be fix posted, and be
placed on mobile crews as well as cut grass.
7/25
DPR
Provide more
Provide more programming inside parks within
programs in parks or
Community Board 6. We have large parks such
recreational centers
as Tremont Park that would benefit from fitness
classes led by the Parks Department.
10/25
DCLA
Support nonprofit
The Bronx River Art Center requests $80,000 to
1087 E
cultural
convert three part-time positions to full-time
Tremont Ave
organizations
positions with benefits for an Education
Bronx, NY
Manager, Presenting and Administrative
10460
Assistant, and Bookkeeper
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/16
SCA
Provide a new or
SCA states that School District 12, which is
expand an existing
largely in CB 6, has an unfunded need of 572
elementary school
seats. We request that an elementary school is
built to accommodate the over 2,000 units of
housing being built between 2015-2025 which
will result in a larger student population. We
also request that SCA accelerates its timeline to
design and scope the 912 seats that are funded.
2/16
SCA
Provide a new or
SCA states that School District 12, which is
expand an existing
largely in CB 6, has an unfunded need of 572
middle/intermediate
seats. School District 12, which is in CB 6
school
,currently has a greater than 160% utilization
rate for its middle schools. We request that a
middle school is built to accommodate the over
2,000 units of housing being built between
2015-2025 which will result in a larger student
population. A new school is necessary to ease
overcrowding. We also request that SCA
accelerates its timeline to design and scope the
912 seats that are funded.
3/16
DPR
Reconstruct or
We request that Fairmount Playground be
upgrade a park or
renovated including the asphalt and benches so
amenity (i.e.
it can be used for the community. Currently the
playground, outdoor
disrepair of the park precludes community use.
athletic field)
4/16
HPD
Provide more
52% of households in our district spend 35% or
housing for
more of their income on rent. Our district is in
extremely low and
need of more affordable housing (20-30% AMI)
low income
so that our residents are able to achieve a
households
higher quality of life without concern of losing
their homes.
5/16
HPD
Provide more
HPD has been doing an admirable job in
housing for medium
providing income for low and extremely low-
income households
oncome households. However, in order to spur
more development it is important that more
housing is provided for middle-income
households in the form of rentals and home
ownership opportunities in order to have people
more invested in the community.
6/16
DFTA
Renovate or
Currently, about 1000 square feet of upstair
2405
upgrade a senior
space at Mt. Carmel Center for Senior Citizens is
Southern Blvd
center
empty and unused in the facility. It will require
full renovation in order to be utilized, and will
enable more services and programming to be
available to seniors in the community.
7/16
NYCHA
Install security
Bronx Community Board 6 greatly appreciates
cameras or make
the 64 security cameras allocated for our
other safety
district, however we are in need of more
upgrades (Capital)
cameras. We request to have more cameras
near 1010 East 178th Street and Monterey
Houses, as well as lighting in hallways and
around the perimeter of buildings.
8/16
HPD
Provide more
We are requesting more funding be allocated
housing for special
for housing for special needs households in our
needs households,
district. With 52% of households in our district
such as the formerly
spending 35% or more of their income on rent,
homeless
many residents in our district are struggling to
make ends meet in order to keep their homes.
Our seniors and formerly homeless residents are
especially vulnerable and at risk of losing their
homes with fixed incomes.
9/16
NYPD
Provide surveillance
The community board is requesting surveillance
Park Avenue
cameras
cameras on Park Avenue between East 183rd
East 182nd
Street and East 188th Street.
Street East
183rd Street
10/16
NYCTA
Improve
The E 174th Street station does not have
accessibility of
elevators or escalators to provide ADA access.
transit
infrastructure, by
providing elevators,
escalators, etc.
11/16
SCA
Renovate or
The auditorium in P.S. 67 Mohegan School
2024
upgrade an
needs to be renovated. The community board
Mohegan Ave
elementary school
requests that funding be allocated towards this
much needed upgrade.
12/16
DOT
Repair or provide
Southern Blvd from E 183rd to Fordham Road is
Southern Blvd
new street lights
extremely dark at night and needs more lighting
E 183rd
Fordham
Road
13/16
SCA
Provide a new or
The community is requesting a P-Tech school to
expand an existing
allow students to receive an associate's degree
high school
in four years as well as pursue a career in
technology
14/16
DOT
Repair or construct new curbs or pedestrian ramps
Southern Blvd between E 183rd and Fordham Road needs new curbs and ramps.
Southern Blvd E 183rd Fordham Road
15/16
DOT
Roadway
E 180th between Webster Abe and Boston Road
E 180th
maintenance (i.e.
needs resurfacing
Webster Ave
pothole repair,
Boston Road
resurfacing, trench
restoration, etc.)
16/16
SCA
Provide technology
MS 45 needs a technological upgrade with an
2502 Lorillard
upgrade
increase in laptops
Place Bronx,
NY 10458
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/25
HRA
Provide, expand, or
There needs to be stronger job placement
enhance job search
support for those without college degrees in CB
and placement
6. Only 7.2% of residents over the age of 25
support
have a college degree and as a result job
placement needs to be targeted to the
population for jobs that do not require a
bachelor's degree ie (construction or tech
industry).
2/25
SBS
Help job seekers
Bronx Community Board 6 is tied for first in
connect to
unemployment rates in New York City at 18.2%.
employment
Additionally, 31.4% of residents live below the
poverty threshold. More needs to be done
directly in our district so that our residents are
provided with viable job options to help lift
themselves and their families out of poverty.
Employment should include the culinary and
tech industries.
3/25
DCP
Study land use and
The West Farms area, specifically E 180th
East 180th St
zoning to better
between Southern Blvd. to Morris Park Ave
Southern
match current use
should be studied to see if it can be up zoned for
Blvd. Morris
or future
higher commercial and residential projects.
Park Ave
neighborhood
needs
4/25
DYCD
Provide, expand, or
125,000 to 150,000 SYEP slots should be
enhance the
allocated to fulfill the demand of students
Summer Youth
seeking employment
Employment
Program
5/25
DYCD
Provide, expand, or
More staffing needed for the Murphy
601 Crotona
enhance
Cornerstone center
Park North
Cornerstone and
Bronx, NY
Beacon programs
10457
(all ages, including
young adults)
6/25
DPR
Provide better park
In order to increase the level of service and
maintenance
parks and to keep up with new additions to the
parks system, 81 City Park Workers are
requested to service the parks throughout the
borough. These CPW's will be fix posted, and be
placed on mobile crews as well as cut grass.
7/25
DPR
Provide more programs in parks or recreational centers
Provide more programming inside parks within Community Board 6. We have large parks such as Tremont Park that would benefit from fitness classes led by the Parks Department.
8/25
ACS
Provide, expand, or
CB 6 has a large number of youth in foster care
enhance preventive
and these youth must receive more preventive
services and
services and alternatives to detention
community based
alternatives for
youth
9/25
DHS
Provide programs
Funding is needed for expanded programming
for homeless
and regular case consultation meetings to
veterans
ensure chronically homeless veterans are moved
into shelters, and that each veteran within the
system receive the attention needed to create a
pathway to permanent housing for each
veteran.
10/25
DCLA
Support nonprofit
The Bronx River Art Center requests $80,000 to
1087 E
cultural
convert three part-time positions to full-time
Tremont Ave
organizations
positions with benefits for an Education
Bronx, NY
Manager, Presenting and Administrative
10460
Assistant, and Bookkeeper
11/25
DYCD
Provide, expand, or
We request more for Adult Basic Education, HSE,
enhance adult
and ESOL
literacy programs
services
12/25
DYCD
Provide, expand, or
There should be universal after school program
enhance after
offerings at each elementary school in Bronx CB
school programs for
6
elementary school
students (grades K-
5)
13/25
DSNY
Provide more
Litter baskets are frequently filled to the brim
Bathgate
frequent litter
and overflowing, contributing to more garbage
Avenue East
basket collection
on the streets and sidewalks.
Tremont
Avenue East
184th Street
14/25
DSNY
Provide more on-
There is a desperate need in our district for
Bathgate Ave
street trash cans
additional street corner garbage collection cans.
178th Street
and recycling
The Sanitation Department should purchase and
180th Street
containers
allocate additional collection cans to our
district. The need for additional collection cans
is particularly acute along our district
commercial strips (Arthur Avenue, East Tremont
Avenue).
15/25
NYPD
Assign additional community affairs officers
More community affairs officers to handle the several street activities in CB 6
16/25
DYCD
Provide, expand, or
CB 6's HS graduation rate is below the NYC rate
enhance the out-of-
and thus there is a greater need for
school youth
employment services for these youth
program for job
training and
employment
services
17/25
NYCTA
Expand bus service
The community board requests increased bus
frequency or hours
service frequency for all busses and, more
of operation
specifically, the Bx 15 and Bx17.
18/25
DYCD
Provide, expand, or
There needs to be more year round offerings for
enhance skills
students to work, not just the summer so they
training and
can stay engaged and not drop out of school.
employment
services for high
school students at
risk of dropping out
19/25
DHS
Provide rental
With more than 26 homeless shelters, more
assistance/vouchers
vouchers are needed for residents to have
for permanent
permanent housing
housing
20/25
DOT
Address traffic
Southern Boulevard between East Fordham
Southern
congestion
Road and East 187th Street has consistent
Boulevard
congestion with school buses, MTA buses, and
East Fordham
cars
Road East
187th Street
21/25
DOT
Other expense
The community board is requesting improved
East Tremont
traffic
cross walks at Boston Road and East Tremont.
Avenue
improvements
Boston Road
requests
West Farms
Road
22/25
NYCTA
Provide a new bus
We request a new bus stop be added to the
service or Select Bus
BxM10 line on E 177th and Devoe or E 180th
Service
bet. E Tremont and Devoe Ave before the bus
goes onto the highway.
23/25
DOE
Assign more
More teaching staff to accommodate Eagle
4143 Third
teaching staff
Academy
Ave Bronx, NY
10457
24/25
DSNY
Provide more on- street trash cans and recycling containers
Southern Blvd from E 183rd to Fordham Road does not have enough trash cans though it is heavily trafficked due to proximity to the Bronx Zoo
Southern Blvd 183rd Street Fordham Road
25/25
DSNY
Increase
ASP is not followed on Vyse Ave between E
Vyse Ave E
enforcement of
179th and E 180th
179th E 180th
alternate street
parking cleaning
rules

