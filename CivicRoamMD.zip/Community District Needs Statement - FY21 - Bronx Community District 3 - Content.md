- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 3 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1Z_2CrfhsF-RQCDZnv6So-E11C5H5I37i/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1Z_2CrfhsF-RQCDZnv6So-E11C5H5I37i/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
3
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 3
image
Address: 1426 Boston Road, Ground Floor Phone: (718) 378-8054
Email: jdudley@cb.nyc.gov
Website: www.nyc.gov/bronxcb3
Chair: Gloria S. Alston District Manager: John Dudley
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Bronx Community District 3 encompasses parts of the Morrisania, Melrose, Claremont, Crotona Park East, Bathgate and Woodstock neighborhoods in Bronx County. The boundaries for Bronx Community District Three are north by the Cross Bronx Expressway and Crotona Park North; east by the Sheridan Expressway, E. 169 St., E. 167 St. and Prospect Avenue; south by E. 159 St. and E. 161 St. and west by Park and Webster Avenues. Due to varying socio- economic factors during the period 1970-1980, Community District 3 experienced the most significant population decline compared to all districts within the borough (64%). Between 2000 and 2010, the district led the borough in new population growth (16.3% change), exceeding the 4.8% cumulative increase in population for Bronx County as a whole, during this period. Overall, the district has experienced a 50% increase in its population from 1980, largely the result of an unprecedented increase of 8,457 units of new residential housing, and the preservation of an additional 9,036 units, since FY'1990. In accordance with Bronx Community District 3's Neighborhood Development Plan-Partnership For the Future, adopted by the NYC Council in November of 1992 as New York City's first community based planning initiative submitted in accordance with Sect. 197a of the NYC Charter, the NYC Department of City Planning has determined that the goals of Community District 3 to "increase the district population as well as provide for mixed-income housing", has been met substantially. Recent district and borough profile reports published by the NYC Department of City Planning for 2015, also indicate that while Bronx County experienced a decline in death rates per 1,000 persons of 0.7% for the period 2005-2012, the rate of decline within Community District 3 was more significant at 1.1%. Similarly, while Bronx County as a whole, experienced a decline in the rate of infant mortality for the period 2005-2012 of .6%, the rate of decline in Community District 3 was significantly higher at 3.9%. The percent of decline in birth rates for Community District Three vis-à-vis Bronx County as a whole for the period 2005-2012, was comparable at 1.2% per 1,000 persons. Based on 2010 U.S. census demographics, Community District 3 is comprised primarily of individuals of Hispanic origin (57.7%), followed by Black/African Americans (39.4%). The percent of change from 2000-2010 for individuals of Hispanic origin was 26.9% compared to 3.9% for Black/African Americans for the same period. For the period 2000-2010, the percent of individuals over 18 years of age totaled 25% compared to 0.3% for those under 18 years of age. General Areas of Concern: With the growth in population over the years attributable to increased new housing unit production and US immigrant migration patterns, the district continues to be faced with challenges in the areas of unemployment, insufficient job development/training programs, insufficient youth and after-school program services, inadequate educational attainment for youth/young adults, insufficient English Learning Language (ELL) programs for new immigrant groups, insufficient education services related to public health disparities and nutrition and the ever increasing demands placed on its communities by the city administration, related to disproportionate siting of temporary homeless and special needs housing. NYS Dept. of Labor unemployment rate for Bronx county - 7.0% (June 2015); NYS average- 5.3% NYC DOE (2013-2014) School Quality Report results for CD 3 (primarily School Districts 9 and 12) show below average ratings in attendance and achievement on NYS standardized tests.
NYCDOHMH Community Health profiles and vital statistics summaries show CD 3 as having the highest age adjusted death rate of 8.7 % per 1,000 persons (2013). Bronx Community District Three contains approximately 5% (2,717) of NYC's total homeless population based on the September 2014 estimate of 56,000 persons; approximately 18 facility sites. This figure represents three times (3X) what the average estimate, per district, would be (1.7%), should NYC Fair Share siting requirements have been strictly implemented. This land-use and facility planning decision by the NYC DHS, independent of and in consideration of the provision of ample supportive services for the populations in question, is singularly the largest factor which would undermine balanced planning and quality of life achievements made throughout the years, in the district.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 3
image
The three most pressing issues facing this Community Board are:
Health care services
Based on information provided in DOHMH Community Health Profiles and Characteristics, second edition-2006, the following represents Bronx CB 3 neighborhoods data for Morrisania, Bathgate and Crotona and general conclusions provided by DOHMH. This information may also be indicative of health indices in other communities within CD 3. - More than 1 in 3 adults consider themselves to be in fair or poor health. - More than 1 in 5 adults in the Central Bronx and Morrisania, smokes. - More than 1 in 4 adults in the Central Bronx and Morrisania are obese. - The self- reported asthma rates in the Central Bronx (10%) and Morrisania (7%), are above the rate in NYC overall (5%). - the rate of individuals with diabetes in the Central Bronx and Morrisania range between 11-16%, compared to 9% in NYC overall. - Avoidable hospitalization rates in the Central Bronx and Morrisania communities rank poorly; 40th and 39, respectively. - Deaths related to HIV (17%), Cancer (14-16%) and Heart disease (13-14%) are the primary causes of death in the Central Bronx and Morrisania communities. The annual death rate for people younger than 75 in the Central Bronx and Morrisania, rank 34th and 42nd among the city's 42 neighborhoods, respectively. - Despite a decrease in death rates in CD 3 communities, death rates remain consistently higher than in other parts of the Bronx and NYC as a whole (15-20%). - CD 3 neighborhoods rank below average on most indicators compared to NYC as a whole. Indicators with below average rankings include having a regular doctor, being heart healthy, getting help for depression, living alcohol and drug free, having a healthy baby and making your home safe and healthy.
Indicators in which the CD 3 communities ranked average or above average, include knowing your HIV status, being checked for cancer and being tobacco free. The unemployment rate for Bronx county is 7% or greater (June 2015) compared to NYS (5.3%). Bronx CB 3 continues to be challenged as a result of insufficient and locally accessible job development and training program services, in growth industries of tomorrow. Bronx CB 3 is also challenged to provide sufficient after school tutorial, recreational and family support programs for students in primary and secondary school. The lack thereof, has resulted in chronic school absenteeism and academic performance at all grade level
Unemployment
Based on information provided in DOHMH Community Health Profiles and Characteristics, second edition-2006, the following represents Bronx CB 3 neighborhoods data for Morrisania, Bathgate and Crotona and general conclusions provided by DOHMH. This information may also be indicative of health indices in other communities within CD 3. - More than 1 in 3 adults consider themselves to be in fair or poor health. - More than 1 in 5 adults in the Central Bronx and Morrisania, smokes. - More than 1 in 4 adults in the Central Bronx and Morrisania are obese. - The self- reported asthma rates in the Central Bronx (10%) and Morrisania (7%), are above the rate in NYC overall (5%). - the rate of individuals with diabetes in the Central Bronx and Morrisania range between 11-16%, compared to 9% in NYC overall. - Avoidable hospitalization rates in the Central Bronx and Morrisania communities rank poorly; 40th and 39, respectively. - Deaths related to HIV (17%), Cancer (14-16%) and Heart disease (13-14%) are the primary causes of death in the Central Bronx and Morrisania communities. The annual death rate for people younger than 75 in the Central Bronx and Morrisania, rank 34th and 42nd among the city's 42 neighborhoods, respectively. - Despite a decrease in death rates in CD 3 communities, death rates remain consistently higher than in other parts of the Bronx and NYC as a whole (15-20%). - CD 3 neighborhoods rank below average on most indicators compared to NYC as a whole. Indicators with below average rankings include having a regular doctor, being heart healthy, getting help for depression, living alcohol and drug free, having a healthy baby and making your home safe and healthy.
Indicators in which the CD 3 communities ranked average or above average, include knowing your HIV status, being checked for cancer and being tobacco free. The unemployment rate for Bronx county is 7% or greater (June 2015) compared to NYS (5.3%). Bronx CB 3 continues to be challenged as a result of insufficient and locally accessible job development and training program services, in growth industries of tomorrow. Bronx CB 3 is also challenged to provide sufficient after school tutorial, recreational and family support programs for students in primary and secondary school. The lack thereof, has resulted in chronic school absenteeism and academic performance at all grade level
Youth and children’s services
Based on information provided in DOHMH Community Health Profiles and Characteristics, second edition-2006, the following represents Bronx CB 3 neighborhoods data for Morrisania, Bathgate and Crotona and general conclusions provided by DOHMH. This information may also be indicative of health indices in other communities within CD 3. - More than 1 in 3 adults consider themselves to be in fair or poor health. - More than 1 in 5 adults in the Central Bronx and Morrisania, smokes. - More than 1 in 4 adults in the Central Bronx and Morrisania are obese. - The self- reported asthma rates in the Central Bronx (10%) and Morrisania (7%), are above the rate in NYC overall (5%). - the rate of individuals with diabetes in the Central Bronx and Morrisania range between 11-16%, compared to 9% in NYC overall. - Avoidable hospitalization rates in the Central Bronx and Morrisania communities rank poorly; 40th and 39, respectively. - Deaths related to HIV (17%), Cancer (14-16%) and Heart disease (13-14%) are the primary causes of death in the Central Bronx and Morrisania communities. The annual death rate for people younger than 75 in the Central Bronx and Morrisania, rank 34th and 42nd among the city's 42 neighborhoods, respectively. - Despite a decrease in death rates in CD 3 communities, death rates remain consistently higher than in other parts of the Bronx and NYC as a whole (15-20%). - CD 3 neighborhoods rank below average on most indicators compared to NYC as a whole. Indicators with below average rankings include having a regular doctor, being heart healthy, getting help for depression, living alcohol and drug free, having a healthy baby and making your home safe and healthy.
Indicators in which the CD 3 communities ranked average or above average, include knowing your HIV status, being checked for cancer and being tobacco free. The unemployment rate for Bronx county is 7% or greater (June 2015) compared to NYS (5.3%). Bronx CB 3 continues to be challenged as a result of insufficient and locally accessible job development and training program services, in growth industries of tomorrow. Bronx CB 3 is also challenged to provide sufficient after school tutorial, recreational and family support programs for students in primary and secondary school. The lack thereof, has resulted in chronic school absenteeism and academic performance at all grade level
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 3
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
Despite NYC DOHM health indices which speak to adverse health conditions affecting residents in the communities of Morrisania, Melrose, Claremont, Crotona Park East, Bathgate and Woodstock related to Asthma, Obesity, HIV/AIDs, Diabetes, Cancer and Heart disease, residents within the district are continually challenged in areas related to income support, rental housing subsidy needs, food and medical assistance, based on HRA caseload statistics as of June 2015.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
It is clear from the 2013 NYC DOHMH Summary of Vital Statistics Report, that Bronx CD 3 is faced with the need to become a more health conscious community, individually, through education and improved choices related to nutrition and healthy eating options; as well as environmentally by reducing human behavioral factors which contribute to area dumpout conditions, unsanitary street and sidewalk cleanliness conditions and the proliferation of vermin within our neighborhoods. The NYC DOHMH, Bureau of Pest Control Services, must increase its community education and awareness campaigns and outreach efforts, in collaboration with the local community board, the NYC Dept. of Consumer Affairs, the NYC Dept. of Education, the NYC Dept. of Sanitation, local community based organizations, tenant and homeowners associations and merchant groups and associations, in these areas.
Needs for Older NYs
According to information provided by DFTA (CENSUS 2010), the elderly population (60 yrs.+) represents 17.2% of NYC's population. The decade 2000-2010, had shown an uptick of 12.4% in the elderly population after a decline since 1980. Approximately 30% of persons 60 and over are between the ages 60 and 64; one in three are 75 and over and one in ten are 85 and over. In contrast to the 12.4% increase in the elderly population since 1980, the total population of NYC grew by 2.1% only. The population under 60, was almost unchanged due to a decline in the number of young persons age 14 and under, during the past decade. It is clear that CENSUS 2010 demographics in this area, support the need of the city administration to increase funding to address the needs of the city's growing elderly population. DFTA records show that Bronx CD 3 is home to 4 senior centers but serviced by 11 in areas related to arts, congregate lunch, health mgmt., telephone assurance, physical health/exercise, case assistance and case assistance medicaid, education/recreation, information, nutrition education, transportation, home delivered alternative meals, technology, visiting, etc.. Bronx CB 3 advocates for continued citywide budgetary increases in all programs, particularly the meals on wheels program, evidenced by the city administration's efforts to increase the agency's budget in FY' 17 by 5% ($1.8m) in this area. Bronx CB 3 also advocates for increased funding for transportation/escort services, case management, nutrition education, physical health/exercise, geriatric mental health and technology training, in an effort to support the nutritional, physical, emotional and technological needs of its growing senior population.
Needs for Homeless
Citywide, Bronx Community District Three is at the forefront as a district, in its representation of the social consciousness and sensitivity, born by local governance, in meeting the ever growing needs and demands of the city's homeless population. Needless to say, the city administration, through its NYC Dept. of Homeless Services, must re-evaluate the application of the NYC Fair Share Siting criteria, in determining the basis for future facility sitings in Bronx Community District Three.
Needs for Low Income NYs
Bronx Community Board Three supports increased funding for the following program services for low income and vulnerable residents within Bronx Community District Three: Increased job training/development and educational programs for adults with enhanced job search and placement support. These program services should assist young adults out of school, as well, in obtaining certifications in skilled trades or occupations with future local and regional employment growth opportunities. Provide additional or expanded programs for youth (under 18 ); i.e. recreation, tutorial and guidance counseling services. Provide increased funding to HRA for the Cash Assistance population as well as the Supplemental Nutrition Assistance/Food Stamps Program, and programs to assist in the payment of utility service bills for low income persons.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
9/28
DOHMH
Create or promote
In consideration of the fact that NYC DOHMH
1309 Fulton
programs for
health indices speak to adverse health
Avenue
education and
conditions in Bronx Community District Three
awareness on
related to Asthma, Obesity, HIV/AIDs, Diabetes,
nutrition, physical
Cancer and Heart Disease, Bronx Community
activity, etc.
Board Three is requesting an increase in the
assignment of health educators and related
personnel at the Morrisania Health Station-
1309 Fulton Avenue, for engagement with DOE
and private school students, residents, local
community based organizations and youth
service providers, for the purposes of providing
on going health education and education for
disease prevention, throughout Bronx
Community District Three.
11/28
DHS
Improve safety at
FY'16 priority request 311;FY'17 priority request
homeless shelters
9;Tracking code 103200101E. (Scope modified)
Provide for increased security at all DHS
contracted shelters and facilities in CD 3.
Security measures need to be enhanced to
preclude unauthorized and illicit activities which
occur around the perimeter of the shelter
grounds and to preserve sound quality of life
conditions in the areas in which these facilities
are located.
14/28
DFTA
Other senior center
Bronx Community Board Three requests
program requests
additional funds to be allocated to the NYC
Department for the Aging, to increase services
related to transport/escort, congregate and
home delivered meals and other coordination
and social action programs for senior centers in
Bronx Community District Three
17/28
DOHMH
Other animal and
FY'16 priority request 24; FY'17 priority request
1826 Arthur
pest control
22; Tracking Code 103199501E. Assign the
Avenue
requests
following additional personnel to the Bronx
DOHMH Bureau of Pest Control; two (2)
exterminators, three (3) clerical staff persons,
eight (8) field staff persons for building and yard
clean-up including additional supplies of talon.
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 3
image
M ost Important Issue Related to Youth, Education and Child Welfare
Educational attainment
Educational Attainment with After School Programs and Services for Youth are of paramount importance in the Area of Youth, Education and Child Welfare. In line with a baseline report provided under the CAS/Phipps South Bronx Rising Together initiative (CD 3 focus area for study - NYC DOE), it was determined that the percentage of students in CD 3 had a third grade reading proficiency of 19.3%, when the citywide proficiency rating was 30.1%. While the CD 3 8th grade proficiency in Math(15.4%) exceeded the Bronx as a whole(14.8%), the NYC average was 21.9%.
Other issues affecting educational attainment were chronic absenteeism(35.5%); 25.4% at-risk and 39.1% with good attendance, based on a 2012-2013 study. The CD 3 SBRT zone showed 17.7% of students in 4 year cohort who were college ready.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
Bronx Community Board Three has worked with the Childrens Aid Society and Phipps Neighborhoods through a grant they received from CHASE in 2013, to develop a cradle through college and career pathway for all children and youth in the Crotona Park East, Melrose and Morrisania neighborhoods of CD 3. Bronx CB 3 embraced this undertaking coined "South Bronx Rising Together "(SBRT), based on statistical data which show these and other communities within the district area, as academically challenged and part of the poorest congressional district in the nation (CD 15). The focus of this Collective Impact approach was to knit together institutions within the community focused on youth success . The purpose of the Collective Impact strategy would be to create a community that is college and career ready, by leveraging the expertise of a network of families, schools, business leaders, community advocates and service providers, to support the lifelong success of children and youth within Bronx Community District Three. The purpose of this initiative is to ensure that all children are healthy, all enter kindergarten ready to succeed, all succeed academically, all stakeholders in this endeavor contribute positively to the community, all graduate from high school-college ready, all attain a degree or post secondary credential and all begin a career.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
21/23 SCA Renovate other site
component
Renovate Swimming Pool at PS/MS4 located at Fulton Avenue and E. 173 St.; Bronx CB 3 capital budget request  16; Tracking Code: 103200704C; Bronx Community Board Three is requesting that DOE, in collaboration with the School Construction Authority, fund improvements to the swimming pool at PS/MS 4 to include ceiling painting and re-grouting of the existing tile($30k), in addition to the replacement of broken tiles, deck re-surfacing and upgrading of pool lockers and locker room.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
7/28
DYCD
Provide, expand, or
FY'16 priority request 15; FY'17 priority request
enhance after
13; Tracking code 103201401E. Increase
school programs for
funding for after school programs for Bronx
elementary school
Community District Three schools in DOE School
students (grades K-
Districts 8, 9 and 12. Due to educational
5)
challenges faced by both English and non-
English speaking students at the elementary,
junior high school and high school levels,
increased funding is needed for after school
support and tutorial assistance for students, as
well as resources for parents, to assist them in
promoting the educational achievement of their
children in school districts 8, 9 and 12, in Bronx
Community District Three.
10/28
DYCD
Provide, expand, or
FY' 16 priority request23; FY'17 priority
enhance the
request 21; Tacking code 103201001E.
Summer Youth
Increase funding for the Summer Youth
Employment
Employment Program to prevent the extent of
Program
idle youth behaviors and adverse youth
involvement with local neighborhood gangs.
12/28 DOE Other educational
programs requests
FY'16 priority request 14; FY'17 priority request 12; Tracking Code 103198512E. Install large containers for refuse and solid waste at public school sites. As a result of DOE protocols involving the service of school lunches using paper goods as opposed to the type of food service that was permanent and not disposable, solid waste remains on the street in front of schools. This condition is unsightly and attracts dogs and vermin.
image
26/28 DYCD Expand After School
Programs
Provide expanded after school tutorial services including SAT college preparatory services for youth and young adults ages 6-24 years, at Southeast Bronx Neighborhood Centers, Inc. (S.E.B.N.C.) at 955 Tinton Avenue.
image
28/28 DYCD Expand After School
Programs
Provide funding for after school tutorial, job/career development and wellness/recreation service programs, for high school students who have aged out of existing middle school programs.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 3
image
M ost Important Issue Related to Public Safety and Emergency Services
General crime
NYPD COMPSTAT figures over the past 22 years have shown a significant overall reduction in the seven major crime categories for CD 3- BRONX (-70%change). The recent increase in the NYPD patrol officer count (approx. 12) for the 42 Pct., should assist in curtailing increased trends in crime related to murder, rape, robbery, burglaries and GLAs (2015-2014). Attention is also needed at the local level in focusing on youth on youth crime which has surfaced related to robberies of electronic devices and in overall education of youth in the area of youth crime prevention at district schools.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Bronx CD 3 urges the appropriation of additional NYPD expense resources to address increased criminal activities, particularly related to Grand Larceny and GLA Auto, within the NYCHA PSA 7 Union Consolidated, Butler, Forest, McKinley, Eagle Avenue, East 163 St., Morris Houses, Webster and Morrisania NYCHA developments in the district. Bronx Community Board Three further requests the assignment of additional patrol officers based on US census demographics which show CD 3 has having the most significant gain in population compared to other Bronx communities between 2000-2010. Recent statistical information provided by NYPD Patrol Bronx command for criminal activity in parks/playgrounds, shows CD 3 as having the most arrests due to criminal activity occurring within the parks/playgrounds. This information supports the need for additional patrol officer assignments in all Bronx CD 3 sectors for FY'17 and baselined.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
18/23 NYPD Provide a new NYPD
facility, such as a new precinct house or sub-precinct
Renovate the NYPD 42nd Police Precinct; Bronx Community Board Three capital priority 21, Tracking code: 103200004C. Consider plans to renovate the NYPD 42nd Pct. at 830 Washington Avenue, to include a new or upgraded HVAC system throughout, new front desk replacement ($160k), new flooring, painting, platform re-construction, sub-floor structural improvements and overall spruce up in line with the Precinct Enhancement Program. Plans should also include additional on or off street parking options for sector vehicles assigned to the precinct.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/28
NYPD
Assign additional
Increase Housing Police Officers at PSA 7 and
housing police
assign to Forest Houses, Butler Houses,
officers
Webster/Morrisania Houses and Morris Houses
developments, within Bronx Community District
Three. FY'16 priority request 3; FY'17 priority
request 2; Tracking Code 103198509E
8/28
NYPD
Assign additional
FY'16 priority request  22; FY'17 priority
uniformed officers
request 20; Tracking Code 103198301E. Assign
additional police personnel to the NYPD 42nd.
Pct. to combat crime, ensure public safety and
provide concentrated enforcement efforts at
narcotics prone locations throughout the district
area.
23/28
NYPD
Other NYPD staff
FY'16 priority request 16; FY'17 priority request
resources requests
14; Tracking Code 103198502E. Increase traffic
personnel assignments in District Three in the
functional area of traffic control. The following
personnel are requested to be added: 1 senior
traffic control inspector, 2 traffic control agents.
24/28 NYPD Provide additional
patrol cars and other vehicles
FY'16 priority request 7; FY'17 priority request 5. Assign Additional equipment to the NYPD 42nd Pct. to include 1 van for the NYPD youth outreach program, 8 additional wheel scooters for police patrol surveillance and 10 bicycles for patrol purposes.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 3
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
Street and Sidewalk cleanliness is a reflection of the quality of the district in all respects including public perception of safety and security. Adverse street and sidewalk cleanliness including environmental issues and illegal dumping practices, contribute to other community environmental health concerns.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Due to increased population counts as a result of new multi-family residential housing and mixed-use development in the community from 1980 to present, the core infrastructure (water/trunk mains and sewers) have been challenged and are in need of repair/replacement.
Needs for Sanitation Services
Since 1990, Bronx Community District Three has received increasingly higher DOS scorecard ratings (50(+)% to 80(+)%), as provided through the Office of the Mayor. In the interest of ensuring that CD 3 obtains similarly high ratings for street and sidewalk cleanliness in FY'17 and into the out years, Bronx CD 3 seeks a new garage facility for improved management based on increased population demographics and new multi-family residential construction (FY 90'-FY 15'; 8,457 units), new and improved cleaning equipment and added police enforcement personnel, for district locations which are high profile sites for illegal dumping.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
16/23
DEP
Develop a capital
Install storm water line and related
Claremont
project for specific
infrastructure (catch basins) along Claremont
Parkway
street segments
Parkway between Crotona Park East and
Crotona Park
currently lacking
Crotona Avenue. Installation of infrastructure
East Crotona
sanitary sewers
for storm water run off is essential at this
Avenue
location due to a history of severe flooding and
ponding conditions along this stretch of
roadway after heavy rainfall. Flooding
conditions warranting this capital improvement
are particularly evident at the intersection of
Crotona Avenue and Claremont Parkway, at the
center of Crotona Park.
CS
DEP
Inspect water main
Bronx CB 3 DEP Capital priority request 1 in
Southern
on specific street
FY 16 (Tracking Code 103198502C) - Initial
Boulevard E.
segment and repair
Budget Line HW-698, Project ID HWX-698W -
174 St.
or replace as
Trunk Water Main replacements in connection
Jennings St.
needed (Capital)
with reconstruction of Southern Blvd. from E.
174 St. to Jennings St. in Bronx Community
District Three. The project was assigned to DEP
with expanded scope to include sanitary sewer
replacements and is now managed by DDC. The
current budget lines are SE-2X, WM-1, WM-6,
WM-944; Project IDs HED-553,SEX-002245. The
FY'16 Adopted Budget register indicates that
the final design contract has been let and that
this project is expected to go into construction in
FY'17. DDC has informed the board that the
project contract has been executed and that
construction is expected to commence before
the end of calendar yr
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
18/28
DSNY
Increase
FY'19 priority request 25; FY'17 priority request
enforcement of
23; Tracking code 103198902E. Increase
illegal dumping laws
Sanitation Police force by 20 officers citywide, to
address issues involving illegal dumping and
dumpout conditions on street and sidewalks.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 3
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Unemployment/Underemployment
Bronx Community District Three is located in the poorest congressional district in the nation (CD 15). The NYS Department of Labor unemployment rate for Bronx County is 7% as of June 2015; NYS average - 5.3%. The NYC administration via the Economic Development Corporation, must promote increased measures to foster economic development initiatives within the existing industrial and IBZ zones within the Community District Three, while offering business tax incentives to attract new and growing industries into the future. This, along with additional job development and training programs, will result in increased local employment opportunities for area residents in CD 3 .
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
Between 2000 and 2010, Bronx CD 3 led the borough in new population growth (16.3% change), exceeding the 4.8% cumulative increase in population for Bronx County as a whole, during this period. Based on information provided by the NYC Department of Housing Preservation and Development, the district has experienced a 50% increase in its population from 1980, largely the result of an unprecedented increase of 8,457 units of new residential housing, and the preservation of an additional 9,036 units, since FY'1990. Despite the gains in increased "affordable" housing and preservation efforts on the part of the city administration, Bronx Community Board Three recognizes that the city administration through HPD and HDC, must re-establish AMI eligibility indexes for affordable housing and moderate income housing models for applicants, to be more reflective of AMI indexes specific to Bronx county and local census tracts in the areas the residential developments are being constructed. This approach to eligibility will serve as a more realistic and effective approach by the city administration, in offering housing opportunities to the residents of Bronx Community District Three and other areas throughout the city. Apart from this re-evaluation of AMI eligibility indexes, Bronx CB 3 urges city, state and federal efforts to promote added long term housing subsidy programs, as a result of severe unemployment and under-employment and wage issues, which exist in the communities of Bronx CD 3. Bronx CB 3 also supports efforts on the part of the city administration to streamline the processing and compliance, on the part of NYCHA, to address longstanding apartment housing code violations, grounds conditions and common area violations within the city's public housing developments; particularly at the nation's largest public housing assemblage in Claremont Village - CD 3 (Butler, Webster/Morrisania, and Morris Houses).
Needs for Economic Development
Bronx Community Board Three recommends that the city administration provide increased funding to increase the number of Workforce I career centers to service the residents of Congressional District 15, while providing and/or expanding existing occupational skills training programs. Bronx Community Board Three also recommends increased efforts on the part of the city administration to promote a commercial district needs assessment for the Southern Boulevard, E. 174 St., Boston Road and Third Avenue retail corridors in Community District Three. The results of the assessment might address or support funding for retail façade improvements, business improvement plans and merchant organizing efforts.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
10/23 NYCHA Renovate or
upgrade NYCHA community facilities or open space
Install new HVAC system with total electrical system upgrades at Claremont Neighborhood Center, Inc. located at 489 E. 169 St. in Bronx Community District Three. FY' 16 priority request 31; FY' 17 priority request 30; tracking code 103201105C
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
2/28
NYCHA
Install security
Install security surveillance cameras at NYCHA
cameras or make
Butler and Webster/Morrisania Houses in
other safety
Claremont Village. FY'16 priority 4; FY'17
upgrades (Expense)
priority 3;Tracking Code 103200503E. Federal
CIAP and/or modernization funds were secured
for the purpose of installing high tech security
surveillance cameras at Morris Houses in 2000.
These funding appropriations allowed for
installation of cameras in and around building
perimeters and has significantly reduced crime
based on COMPSTAT crime indexes within PSA 7.
As a result, Bronx Community Board Three is
requesting similar fiscal appropriations for
camera installations at Butler and
Webster/Morrisania Houses.
3/28
EDC
Improve public
FY'16 priority request 13;FY'17 priority request
housing
11; Tracking Code 103198511E. Purchase
maintenance and
containers for storage of solid waste at NYCHA
cleanliness
developments in Community District Three-
Bronx. Allocations of compactor
containerization units are requested for
placement at NYCHA sites to contain large
amounts of refuse which remain on the street
attracting dogs and vermin. Placement of the
containerization units at NYCHA sites, will allay
adverse mayoral scorecard ratings for street
and sidewalk cleanliness issued by the Office of
the Mayor to DOS Bronx West Three district.
13/28
DOB
Assign additional building inspectors (including expanding training programs)
FY' 16 Priority request 5; FY' 17 priority request 4; Tracking Code 103199402E. Provide additional DOB inspectors Bronxwide to address issues of owner non-compliance with the NYC Administrative code and zoning requirements. Added funding for additional DOB inspectors will support the needs of each specific community district in addressing DOB violations relating to illegal property uses, work without permits, illegal SRO conversions and many other problematic building and zoning code conditions.
19/28
SBS
Provide or expand occupational skills training programs
Provide funding for development of year round home health aide training program at existing ground floor commercial space located at 584 E. 163 St. This location is a mixed use property owned by Morrisania Revitalization Corporation, a local development corporation within Bronx Community District Three.
584 E. 163 St.
27/28
SBS
Other expense workforce development requests
Provide funding for workforce development programs related to job training/development for the formerly incarcerated and youth aging out of foster care(14-25 years of age), aimed at preventing incarceration and increased rates of recidivism of the formerly incarcerated. Efforts should be undertaken to create incentives for prospective employers to hire formerly incarcerated adults and offenders.
TRANSPORTATION
Bronx Community Board 3
image
M ost Important Issue Related to Transportation and Mobility
Street lighting
This issue directly affects the safety of motorists and pedestrians and speaks to the broader issue involving the liability of NYC in personal injury cases and insurance claims. Additionally, this issue affects the ease of traffic mobility/flow and safety, in general.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Since 1980, the population of Bronx Community District Three has grown by 50%. An analysis by the NYC Department of Housing Preservation and Development has further shown that since 1990, there have been 8,457 new residential housing units constructed with over 9,036 units preserved. Despite DOT efforts to address street maintenance and repair, as well as intersection control studies and other engineering analyses, which have significantly enhanced overall traffic flow, safety and the viability of the district's infrastructure; Bronx Community Board Three encourages funding to allow DOT to initiate traffic and parking studies in meeting with the increased district population count since FY' 1990.
Needs for Transit Services
No comments
image
Priority
Agency
Request
Explanation
Location
3/23
DOT
Reconstruct streets
Provide for the Reconstruction of E. 161 St.
E. 161 Street
between Park Avenue and Third Avenue; Bronx
Park Avenue
CB 3 capital budget request 3; Tracking Code;
Third Avenue
103200207C; Bronx CB 3 is requesting the re-
construction of E. 161 St. between Park and
Third Avenues to complement an existing urban
design initiative for a new streetscape of E. 161
St. bounded by River Avenue and Park Avenues
within CD 4. This request will underscore the
previous re-construction of the bridge
underpass at E. 161 St., the new Criminal Court
complex undertaken by the NYS Dormitory
Authority and the recently implemented SBS BX
6 bus route. Additionally, this project will
complement future funding targeted for capital
improvements to the Morrisania Metro-North
train station and Railroad Park.
4/23
DOT
Repair or provide
Provide Enhanced Street Surface Lighting at
Southern
new street lights
Southern Boulevard from E. 174 St. to E. 167 St.
Boulevard E.
at the "Underside" of the Elevated 2 & 5 IRT
174 St. E. 167
train lines; Bronx CB 3 capital budget request 
St.
10; Tracking Code: 103199501C; In
consideration of the intent of the existing
Southern Blvd. Neighborhood Dev. Plan
implemented by DCP in 2016, and the current
DDC project involving installation of trunk mains
and sewers at Southern Blvd. between E. 174 St.
and E. 167 St. in CD 3 FY'17 (HED553), enhanced
illumination of this commercial corridor is
needed to further the economic vitality of
Southern Blvd. Enhanced street surface lighting
will also compliment the recently completed
painting of the train structure by the NYCTA in
2016.
Priority Agency Request Explanation Location
image
21/28 DOT Other expense
traffic improvements requests
Increase the number of Highway Repairmen at the NYC Dept. of Transportation; Bronx CB 3 expense budget request 18; Tracking Code: 103200103E; Bronx Community Board Three is requesting an increase in the number of Highway Repairmen assigned to the Bronx Office of NYC DOT, by ten(10), to assist in ithe repair of potholes/cave-in conditions within Bronx County.
image
22/28 DOT Provide new traffic
or pedestrian signals
Assign Additional Personnel to the New York City Department of Transportation, Bureau of Traffic; Bronx CB 3 expense budget requests 8; Tacking Code: 103199502E; In consideration of agency delays in the restoration and replacement of missing/defective traffic signage throughout the district, the following personnel are requested for assignment at the NYC DOT, Bureau of Traffic: Three (3) Device Maintainers.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 3
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Other
Bronx Community Board Three has focused its capital priorities on improvements to its parks and recreational facilities, in the interest of supporting an improved recreational infrastructure to encourage youth and young adults to enjoy open space/recreational activities, thus improving overall health indices and disparities of the district, compared to NYC at-large.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Bronx CB 3 in collaboration with the NYC Dept. of Parks and Recreation, working with the Friends of Crotona Park and numerous local community based organizations and residents groups, have developed a "Crotona Park Master Plan 2034". This plan includes recommendations for park improvements, park design/network changes and capital and expense budget requests(2034; proposed maturity year). This plan was developed recognizing Crotona Park as a major natural resource in District Three, for which long range community planning efforts were of paramount importance. Local funding efforts of the NYC Council and Bronx Borough President have framed parks and recreational support over the years.
Needs for Cultural Services
No comments
Needs for Library Services
Bronx Community Board Three supports the increase of $18m (+) in operating funds for the NYPL in FY'16; nevertheless, requests that this funding be baselined in FY'17 in order to preserve system wide enhancements, including additional librarians, hours, programs and books. Bronx Community Board Three is advocating for a new boiler and electrical upgrade at the Morrisania library ($1.5 million), as well as an ADA elevator ($725k).
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/23
NYPL
Create a new, or
Provide for Replacement of the HVAC system at
renovate or upgrade
the Morrisania branch library with an energy
an existing public
efficient model ($300k) and overall electrical
library
upgrades throughout the library ($1mil.). Bronx
Community Board Three is also requesting
replacement of the existing boiler with a new
energy efficient model ($500k). This
replacement will reduce energy consumption
and Greenhouse Gas emissions. ; Bronx CB 3
capital budget request  7; Tracking Code:
103201501C
2/23
DPR
Provide a new, or
Renovate the Crotona Pool and Recreation
new expansion to, a
spaces to allow for year round recreation uses
building in a park
for youth and adolescents as well as provide
available space for seniors (Crotona Park
Master Plan-2034). The indoor facility could also
serve as an indoor venue for special events
within Crotona Park; Bronx CB 3 capital budget
request 25; Tracking Code: 103201003C (scope
modified); This facility, once created, would
become the new sports/fitness center for
Crotona Park, as well as an indoor facility for
special events.
5/23
DPR
New equipment for
Provide the following equipment to enable
maintenance
M&O staff to effectively maintain parks and
(Capital)
playgrounds in Bronx CD 3: 1 toolcat with
attachments to cut grass, remove snow, spread
seeds, salt, pick up logs, dig large and deep
holes, evenly spread out the baseball field
surface, move and pick up heavy objects, soil
and wood chips ($75k), 5 bag pack leaf blowers
of commercial strength, Harvester for Indian
Lake (stored in Crotona Park) and 2 dual
hydrostatic gas zero turn riding mowers (John
Deere BM25104).
6/23
DPR
Reconstruct or
Renovate the existing comfort station at Drew
upgrade a park or
Playground (Fulton Avenue between E. 169 St.
amenity (i.e.
and E. 170 St.) ; Bronx CB 3 capital budget
playground, outdoor
request 17; Tracking Code 103200801C; Recent
athletic field)
capital improvements undergone at Drew
Playground related to asphalt work, renovation
of basketball courts with sports coating, bench
replacements, fence installation, playground
improvements, play unit installation and
sprinkler system installation. Drew playground is
in need of sports lighting throughout the park
and play areas to improve safety and promote
extended play conditions for youth during
summer hours.
7/23
DPR
Reconstruct or
Renovate Playground  9 (Clinton Playground)
upgrade a park or
in Crotona Park at Crotona Park South near
amenity (i.e.
Clinton and Crotona Avenues; Bronx CB 3 capital
playground, outdoor
budget request 35; Tracking Code:
athletic field)
103201403C; Due to the deteriorated condition
of this playground, Bronx CB 3 is requesting the
total renovation of the playground to include a
new multi-purpose space that includes a new
basketball court with upgraded play surface and
new bleachers, chess tables with comfortable
seating for seniors, a bicycle skills playground/
skate park, exercise/fitness equipment for
youth, teens and young adults, spray shower
and wading pool for infants/toddlers and
drinking fountain.
8/23
DPR
Reconstruct or
Provide for the reconstruction of the existing
upgrade a building
comfort station within Railroad
in a park
Park/Playground (Melrose Park; Site 58) within
the Melrose Commons Urban Renewal
Area(East 161 St. and Park Avenue); Bronx CB 3
capital budget request 12; Tracking Code
103200203C; Railroad park is utilized by
children at the Morrisania Air Rights project,
neighborhood day care centers, and the
immediate community. Plans should be
undertaken to renovate the existing building to
provide a comfort station and park concessions.
These improvements would serve to benefit the
area by fostering increased utilization of the
Metro-North Subway station. This location
serves as a major point of transfer for existing
bus line numbers BX 6, 13, 41 and 32.
9/23
DPR
Reconstruct or
Provide for installation of high intensity
upgrade a park or
security/sports lighting , additional electrical
amenity (i.e.
outlets for stage area and installation of fence
playground, outdoor
at the garden area at Eae J. Mitchell Park ( E.
athletic field)
174 St. and Longfellow Avenue); Bronx CB 3
Capital budget priority  11; Tracking Code
103200501C; Eae J. Mitchell Park requires high
intensity sports/security lighting throughout the
park, particularly along the north side adjacent
to the Cross Bronx Plaza Shopping Mall. This
lighting will serve as a deterrent for substance
abuse and narcotics sales and use within the
park during late evening hours. Added electrical
outlets suited for special events, stage and
musical performances, are also needed as well
as a fence to secure the garden area.
11/23
DPR
Reconstruct or
Install New High Intensity Security Lighting at
upgrade a building
Charlton-Thompson Garden located at E. 164 St.
in a park
between Boston Road an Cauldwell Avenue;
Bronx CB 3 capital budget request  34; Tracking
Code: 103201401C; Charlton-Thompson Garden
in Bronx CB 3 serves as a memorial to two
African American Congressional Medal of Honor
award recipients from the Korean War. This
park was recently re-constructed in 2010 due to
its former deteriorated condition. Of major
concern to area residents and to the Friends of
Charlton-Thompson Garden Preservation
committee and the National Association of
Black Veterans in Bronx County, is the fact that
the park has been the subject of vandalism and
graffiti, which have affected the integrity of this
memorial for two of our nation's war heroes.
12/23
DPR
Reconstruct or
Renovate Hill and Dale Playground
upgrade a park or
(Playground5) in Crotona Park at Crotona Park
amenity (i.e.
East and Suburban Place; Capital Budget
playground, outdoor
Priority  8; Tracking Code 103201102C) Bronx
athletic field)
CB 3 is recommending that the NYC DPR fund
the renovation of Hill and Dale playground due
to its existing poor condition. This playground
requires new drainage due to heavy ponding
after rainfall, new play equipment and safety
surface matting, as well as removal of the
existing concrete structures within the play
area. Provide for updated basketball courts and
handball courts.
13/23
DPR
Reconstruct or
Reconstruct Crotona Park - Playground 4
upgrade a park or
(Crotona Park East, Crotona Park North, E. 175
amenity (i.e.
St. and Southern Boulevard); Bronx CB 3 capital
playground, outdoor
budget request 14; Tracking Code
athletic field)
103200404C); provide for the reconstruction of
the soccer field goals, water fountain and mister
to provide recreational amenities for
neighborhood youth - estimated cost: $500K+
14/23
DPR
Reconstruct or
Renovate the existing comfort station at
upgrade a building
Gouverneur Morris Playground to be ADA
in a park
compliant(Third Avenue at E. 170 St.);Bronx CB
3 capital budget request 15;Tracking Code
103200502C;The capital reconstruction of Gov.
Morris Playground totaled nearly $1.7 million
and included new spray showers, swings,
playground and park house improvements,
basketball lighting, asphalt grading, sitting area
and handball court improvements, in addition to
$173k in requirements contract work for
fencing, color seal coating, new backboards,
rims, and related curb work associated with the
basketball courts. Presently, the Morris Houses
TA requests the renovation of the existing
comfort station, as it is the only capital item
unaddressed. It also services numerous children
in local day care/head start programs.
15/23
DPR
Reconstruct or
Install New High Intensity Sports Lighting at
upgrade a building
Newly Constructed Synthetic Soccer Field at
in a park
Crotona Park North and Crotona Park East in
Crotona Park. FY'16 priority request 29; FY'17
priority request 28; Tracking code 103201103C.
17/23
DPR
Reconstruct or
Install park benches within Crotona Park; Bronx
upgrade a park or
CB 3 capital budget request 18; Tracking Code
amenity (i.e.
103200802C; Due to the increased utilization of
playground, outdoor
Crotona Park as a result of capital
athletic field)
improvements to ballfields and play areas,
residents have sought to increase the
availability of park seating within the park for
passive relaxation and enjoyment purposes, in
accordance with the Crotona Park Master Plan-
2034.
19/23
DPR
Reconstruct or
Rehabilitate CS 132 Playground (Morgan
upgrade a park or
Playground) at E. 168 St., Park Avenue and
amenity (i.e.
Washington Avenue; Bronx CB 3 capital budget
playground, outdoor
request  33; Tracking Code; 103201203C;
athletic field)
Bronx CB 3 is requesting that CS 132 Playground
be rehabilitated to include improvements to the
play surface. backboards, and rims at the
basketball courts, including new line markings
and park logo. Additionally, the board is
requesting that the NYC DPR re-surface the
walls and floors of the existing handball courts.
20/23
DPR
Reconstruct or
Repair broken and Defective Concrete Facing at
upgrade a park or
Handball Courts and Related Grounds at Basil
amenity (i.e.
Behagen Playground - Union Avenue, Tinton
playground, outdoor
Avenue and E. 166 St. in Bronx CD 3; Bronx CB 3
athletic field)
capital budget request  26; Tracking Code
103201005C; Bronx CB 3 is requesting the
intervention of NYC DPR in repairing the
broken/defective concrete facing at numerous
locations on the handball courts and the related
ground areas. Additionally, the scope of work
should address other defective concrete
conditions throughout the park, particularly the
softball play area. These defects have impaired
the ability of players to enjoy games at the park
site. Bronx CB 3 recommends that this item be
addressed via a NYC Requirements contract.
22/23
DPR
Provide a new or
Develop Greenthumb and Flower Garden at
Hoe Ave
expanded park or
Block 2979, Lots 28, 30, 31,33,35,36 (Hoe
Home St
amenity (i.e.
Avenue between Home and Freeman Streets);
Freeman St
playground, outdoor
Bronx CB 3 capital budget priority request 6;
athletic field)
Tracking Code 103199506C Due to increased
residential development within the area of
Crotona Park East and in consideration of the
interest of the Hoe Avenue and Home St.
Garden committee, Bronx CB 3 is requesting
that NYC Parks and Recreation provide for the
development of a green and flower garden at
this location. The scope of work should include
landscaping, vegetable and flower plantings
and passive seating. It is further recommended
that NYC DPR collaborate with Bronx CB 3 and
the area homeowners association on Hoe
Avenue, to develop a final design for approval
by Bronx CB 3.
CS
DPR
Reconstruct or
Renovate Crotona Park Ballfields 4 and 5
upgrade a building
(contiguous and integrated play area) to
in a park
provide for removal of old and installation of
new bleachers, new drainage, new fencing, new
playing field surface with related field markings,
water fountains and a comfort station; Bronx CB
3 capital priority 5; Tracking Code
103201101C) Ballfields 4 and 5 at Crotona Park
North near Prospect Avenue, require renovation
due to the existing field condition which has
been compromised over the years due to
regular and seasonal league play.
CS
DPR
Reconstruct or
Reconstruct Comfort Station within Crotona
1596 Crotona
upgrade a building
Park at E. 171 St. and Fulton Avenue; Bronx CB 3
Ave
in a park
Capital Budget Request 9; Tracking Code
103199504C) Improvements to the existing
comfort station are needed to allow for
reactivation of its former use. This would
support the prior rehabilitation by NYC DPR of
Playground10 in FY 97/98. The improvements
should include allowances for ADA accessibility.
Councilman Joel Rivera had appropriated $840k
from FY 2012 for this purpose. This project is in
design.
CS
DPR
Provide a new or
Provide New Construction of Park at Site 32
expanded park or
with the Melrose Commons URA. Budget Line:
amenity (i.e.
P-D021, P-C021, WM0011; Project ID(s) P-
playground, outdoor
103MP32, P-101MELR, P-1CROT41 Bronx CB 3
athletic field)
capital budget priority request 2 (Tracking
Code-103200206C) Bronx CB 3 has requested
funding to construct a new park at this location
which divides Bronx Community Districts 3 and
1. This park, once completed, will address the
open space and recreational needs of the
residential community within the Melrose
neighborhoods shared by Bronx Community
Districts 3 and 1. The work scope and design is
expected to include a youth and tot play area,
water play area, arbor, granite stairs/plaza,
common lawn and buffer planting, garden and
adult fitness area.
CS DPR Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Provide for Renovation of Phase II of Estella Diggs Park at Third Avenue and E. 167 St. Bronx CB 3 capital budget request 4 (Tracking Code: 103200101C) Phase II funding request ($1.3 mil.) would address site stabilization due to topography, landscaping, perimeter fencing, pathways, new recreational playground and/or facility to include a waterfall at the site of E. 167 St. and Third Avenue; east side, Block 2608, lots 38,39,40,43,48,53,54). Such site will attract resident youth living at Claremont Consolidated NYCHA development on Washington Avenue, as well as numerous developments along Boston Road and E. 163 St. within CD 3. Phase I was completed on 5/10/11 at a cost of $2.9 mil.
image
CS DPR Reconstruct or upgrade a building in a park
Install New high Intensity Sports/Security Lighting at Ballfield 1 in Crotona Park at Claremont Parkway and Crotona Avenue; Tracking Code 103200804C; FY' 2017 CAPIS P-
103CRO1; Project in Procurement -$1.531 mil. (Council/Mayoral); March 2017 procurement completion. Ballfield 1 was the subject of capital improvements completed in 2008 which included new bleachers, new sod, and upgraded irrigation at a cost of $800k. At the request of Jaws Baseball Little League, Inc. Bronx CB 3 is requesting the installation of new high intensity sports/security lighting for extended evening and tournament play for youth.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
4/28
DPR
Provide better park
Increase Personnel in CD Three for Effective
maintenance
Operations; Bronx CB 3 expense budget request
6; Tracking Code: 103198904E; Provide the
following additional personnel for effective
parks maintenance and operation of our parks
and playgrounds: a. Two (2) Associate Park
Service Workers. The APSW requirements
include CDL licensing for truck operations
related to refuse removal throughout CD 3
parks and playgrounds b) Two (2) climbers and
pruners. The following personnel request is for
dedicated staffing to Crotona Park exclusively:
12 seasonal CPWs for maintenance of park
(Spring/Summer); 4 full time CPWs for year
round dedicated lake cleaning and
maintenance, 1 gardener, 2 PEP sergeants and 6
officers for year round park security and 1 driver
(APSW)
5/28
DPR
Provide better park
Assign Additional Maintenance and Operations
maintenance
Personnel in Crotona Park; Bronx CB 3 expense
budget request  10; Tracking Code:
103199504E; The rehabilitation/upgrading of
playgrounds and ball fields in Crotona Park, as
well as ongoing concerns regarding the cleaning
and maintenance of Indian Lake, warrant the
assignment of the following dedicated staff
personnel exclusively to Crotona Park: 12
seasonal CPWs for maintenance of park
(Spring/Summer); 4 full time CPWs for year
round dedicated lake cleaning and
maintenance, 1 gardener, 4 climbers and
pruners, 2 PEP sergeants and 6 officers for year
round park security and 1 driver (APSW)
6/28
NYPL
Extend library hours
Increase funding for the New York Public Library
or expand and
Services at the Morrisania Library; Bronx CB 3
enhance library
expense budget request 7; Tracking Code:
programs
103199503E; In order to provide the
opportunity for district children and youth to
fully participate in the NYPL's many services,
funding for the Morrisania branch needs to be
increased to allow for six day service including
increased hours, diverse programming, strong
collections and sufficient support staff to
support these functions. This request is justified
in that the circulation rate for Morrisania has
increased as well as the attendance at the
branch.
15/28
DPR
Improve the
Provide Funding for Personnel to Facilitate the
quality/staffing of
Continued Operation of the Crotona Park
existing programs
Nature Center; Bronx CB 3 expense budget
offered in parks or
request  17; Tracking Code 103200102E; In
recreational centers
order to promote environmental/park wildlife
education of neighborhood youth and those
attending local community and elementary and
intermediate schools in CD 3, park personnel are
needed to staff the operation of the Crotona
Park Nature Center year round.
16/28
DPR
Improve the
Hire Additional Recreational Staff for the
quality/staffing of
Crotona Pool and Recreation Center; Bronx CB 3
existing programs
expense budget request  19; Tracking Code;
offered in parks or
103198501E; With new public and private
recreational centers
renovated housing within the district, the
following additional staff are needed in the
recreation center and pool area of Crotona
Park: 2 recreational directors, 3 playground
assistants. 3 recreational aides, 2 community
aides, 1 clerk and 2 urban park rangers.
20/28
DPR
Enhance park safety
Provide Twenty (20) Additional Park
through more
Enforcement Patrol Officers (PEP) to Ensure
security staff (police
Quality of Life Observance in Bronx
or parks
Parks/Recreational Areas; Bronx CB 3 expense
enforcement)
priority  1; Tracking Code: 103199405E;
Community Board Three supports the need for
additional PEP staffing in support of increased
concerns regarding park security and
vandalism. CD 3 expresses the urgency of this
need in its efforts to ensure the viability of CD 3
parks and recreational facilities.
25/28
DPR
Forestry services,
Increase Forestry Services in District Three;
including street tree
Bronx CB 3 expense budget request 16;
maintenance
Tracking Code: 103198903E; Provide six(6)
additional climbers/pruners to the Bronx Office
of NYC DPR to assist in the backlog of tree
pruning and hazardous tree removal
complaints. Personnel are needed to address
tree limb overgrowth conditions which
compromise street lamp lumen emission
efficiency within parks, on street and at arterial
highway locations.
Other Capital Requests
Priority Agency Request Explanation Location
image
23/23 Other Other capital budget
request
Bronx Community Board Three is requesting the establishment of an emergency operations center to serve as a hub (operational base) for emergency preparedness purposes. This local emergency operations center would serve to coalesce residents, organizations, churches, businesses and civic groups and associations in Bronx Community District Three, under a cohesive emergency preparedness plan of action. (Jurisdiction of NYC Emergency Management)
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/23
NYPL
Create a new, or
Provide for Replacement of the HVAC system at
renovate or upgrade
the Morrisania branch library with an energy
an existing public
efficient model ($300k) and overall electrical
library
upgrades throughout the library ($1mil.). Bronx
Community Board Three is also requesting
replacement of the existing boiler with a new
energy efficient model ($500k). This
replacement will reduce energy consumption
and Greenhouse Gas emissions. ; Bronx CB 3
capital budget request  7; Tracking Code:
103201501C
2/23
DPR
Provide a new, or
Renovate the Crotona Pool and Recreation
new expansion to, a
spaces to allow for year round recreation uses
building in a park
for youth and adolescents as well as provide
available space for seniors (Crotona Park
Master Plan-2034). The indoor facility could also
serve as an indoor venue for special events
within Crotona Park; Bronx CB 3 capital budget
request 25; Tracking Code: 103201003C (scope
modified); This facility, once created, would
become the new sports/fitness center for
Crotona Park, as well as an indoor facility for
special events.
3/23
DOT
Reconstruct streets
Provide for the Reconstruction of E. 161 St.
E. 161 Street
between Park Avenue and Third Avenue; Bronx
Park Avenue
CB 3 capital budget request 3; Tracking Code;
Third Avenue
103200207C; Bronx CB 3 is requesting the re-
construction of E. 161 St. between Park and
Third Avenues to complement an existing urban
design initiative for a new streetscape of E. 161
St. bounded by River Avenue and Park Avenues
within CD 4. This request will underscore the
previous re-construction of the bridge
underpass at E. 161 St., the new Criminal Court
complex undertaken by the NYS Dormitory
Authority and the recently implemented SBS BX
6 bus route. Additionally, this project will
complement future funding targeted for capital
improvements to the Morrisania Metro-North
train station and Railroad Park.
4/23
DOT
Repair or provide
new street lights
Provide Enhanced Street Surface Lighting at
Southern Boulevard from E. 174 St. to E. 167 St.
Southern
Boulevard E.
at the "Underside" of the Elevated 2 & 5 IRT
174 St. E. 167
train lines; Bronx CB 3 capital budget request 
St.
10; Tracking Code: 103199501C; In
consideration of the intent of the existing
Southern Blvd. Neighborhood Dev. Plan
implemented by DCP in 2016, and the current
DDC project involving installation of trunk mains
and sewers at Southern Blvd. between E. 174 St.
and E. 167 St. in CD 3 FY'17 (HED553), enhanced
illumination of this commercial corridor is
needed to further the economic vitality of
Southern Blvd. Enhanced street surface lighting
will also compliment the recently completed
painting of the train structure by the NYCTA in
2016.
5/23
DPR
New equipment for
Provide the following equipment to enable
maintenance
M&O staff to effectively maintain parks and
(Capital)
playgrounds in Bronx CD 3: 1 toolcat with
attachments to cut grass, remove snow, spread
seeds, salt, pick up logs, dig large and deep
holes, evenly spread out the baseball field
surface, move and pick up heavy objects, soil
and wood chips ($75k), 5 bag pack leaf blowers
of commercial strength, Harvester for Indian
Lake (stored in Crotona Park) and 2 dual
hydrostatic gas zero turn riding mowers (John
Deere BM25104).
6/23
DPR
Reconstruct or
Renovate the existing comfort station at Drew
upgrade a park or
Playground (Fulton Avenue between E. 169 St.
amenity (i.e.
and E. 170 St.) ; Bronx CB 3 capital budget
playground, outdoor
request 17; Tracking Code 103200801C; Recent
athletic field)
capital improvements undergone at Drew
Playground related to asphalt work, renovation
of basketball courts with sports coating, bench
replacements, fence installation, playground
improvements, play unit installation and
sprinkler system installation. Drew playground is
in need of sports lighting throughout the park
and play areas to improve safety and promote
extended play conditions for youth during
summer hours.
7/23
DPR
Reconstruct or
Renovate Playground  9 (Clinton Playground)
upgrade a park or
in Crotona Park at Crotona Park South near
amenity (i.e.
Clinton and Crotona Avenues; Bronx CB 3 capital
playground, outdoor
budget request 35; Tracking Code:
athletic field)
103201403C; Due to the deteriorated condition
of this playground, Bronx CB 3 is requesting the
total renovation of the playground to include a
new multi-purpose space that includes a new
basketball court with upgraded play surface and
new bleachers, chess tables with comfortable
seating for seniors, a bicycle skills playground/
skate park, exercise/fitness equipment for
youth, teens and young adults, spray shower
and wading pool for infants/toddlers and
drinking fountain.
8/23
DPR
Reconstruct or
Provide for the reconstruction of the existing
upgrade a building
comfort station within Railroad
in a park
Park/Playground (Melrose Park; Site 58) within
the Melrose Commons Urban Renewal
Area(East 161 St. and Park Avenue); Bronx CB 3
capital budget request 12; Tracking Code
103200203C; Railroad park is utilized by
children at the Morrisania Air Rights project,
neighborhood day care centers, and the
immediate community. Plans should be
undertaken to renovate the existing building to
provide a comfort station and park concessions.
These improvements would serve to benefit the
area by fostering increased utilization of the
Metro-North Subway station. This location
serves as a major point of transfer for existing
bus line numbers BX 6, 13, 41 and 32.
9/23
DPR
Reconstruct or
Provide for installation of high intensity
upgrade a park or
security/sports lighting , additional electrical
amenity (i.e.
outlets for stage area and installation of fence
playground, outdoor
at the garden area at Eae J. Mitchell Park ( E.
athletic field)
174 St. and Longfellow Avenue); Bronx CB 3
Capital budget priority  11; Tracking Code
103200501C; Eae J. Mitchell Park requires high
intensity sports/security lighting throughout the
park, particularly along the north side adjacent
to the Cross Bronx Plaza Shopping Mall. This
lighting will serve as a deterrent for substance
abuse and narcotics sales and use within the
park during late evening hours. Added electrical
outlets suited for special events, stage and
musical performances, are also needed as well
as a fence to secure the garden area.
10/23
NYCHA
Renovate or
Install new HVAC system with total electrical
upgrade NYCHA
system upgrades at Claremont Neighborhood
community facilities
Center, Inc. located at 489 E. 169 St. in Bronx
or open space
Community District Three. FY' 16 priority
request 31; FY' 17 priority request 30; tracking
code 103201105C
11/23
DPR
Reconstruct or
Install New High Intensity Security Lighting at
upgrade a building
Charlton-Thompson Garden located at E. 164 St.
in a park
between Boston Road an Cauldwell Avenue;
Bronx CB 3 capital budget request  34; Tracking
Code: 103201401C; Charlton-Thompson Garden
in Bronx CB 3 serves as a memorial to two
African American Congressional Medal of Honor
award recipients from the Korean War. This
park was recently re-constructed in 2010 due to
its former deteriorated condition. Of major
concern to area residents and to the Friends of
Charlton-Thompson Garden Preservation
committee and the National Association of
Black Veterans in Bronx County, is the fact that
the park has been the subject of vandalism and
graffiti, which have affected the integrity of this
memorial for two of our nation's war heroes.
12/23
DPR
Reconstruct or
Renovate Hill and Dale Playground
upgrade a park or
(Playground5) in Crotona Park at Crotona Park
amenity (i.e.
East and Suburban Place; Capital Budget
playground, outdoor
Priority  8; Tracking Code 103201102C) Bronx
athletic field)
CB 3 is recommending that the NYC DPR fund
the renovation of Hill and Dale playground due
to its existing poor condition. This playground
requires new drainage due to heavy ponding
after rainfall, new play equipment and safety
surface matting, as well as removal of the
existing concrete structures within the play
area. Provide for updated basketball courts and
handball courts.
13/23
DPR
Reconstruct or
Reconstruct Crotona Park - Playground 4
upgrade a park or
(Crotona Park East, Crotona Park North, E. 175
amenity (i.e.
St. and Southern Boulevard); Bronx CB 3 capital
playground, outdoor
budget request 14; Tracking Code
athletic field)
103200404C); provide for the reconstruction of
the soccer field goals, water fountain and mister
to provide recreational amenities for
neighborhood youth - estimated cost: $500K+
14/23
DPR
Reconstruct or
Renovate the existing comfort station at
upgrade a building
Gouverneur Morris Playground to be ADA
in a park
compliant(Third Avenue at E. 170 St.);Bronx CB
3 capital budget request 15;Tracking Code
103200502C;The capital reconstruction of Gov.
Morris Playground totaled nearly $1.7 million
and included new spray showers, swings,
playground and park house improvements,
basketball lighting, asphalt grading, sitting area
and handball court improvements, in addition to
$173k in requirements contract work for
fencing, color seal coating, new backboards,
rims, and related curb work associated with the
basketball courts. Presently, the Morris Houses
TA requests the renovation of the existing
comfort station, as it is the only capital item
unaddressed. It also services numerous children
in local day care/head start programs.
15/23
DPR
Reconstruct or
Install New High Intensity Sports Lighting at
upgrade a building
Newly Constructed Synthetic Soccer Field at
in a park
Crotona Park North and Crotona Park East in
Crotona Park. FY'16 priority request 29; FY'17
priority request 28; Tracking code 103201103C.
16/23
DEP
Develop a capital
Install storm water line and related
Claremont
project for specific
infrastructure (catch basins) along Claremont
Parkway
street segments
Parkway between Crotona Park East and
Crotona Park
currently lacking
Crotona Avenue. Installation of infrastructure
East Crotona
sanitary sewers
for storm water run off is essential at this
Avenue
location due to a history of severe flooding and
ponding conditions along this stretch of
roadway after heavy rainfall. Flooding
conditions warranting this capital improvement
are particularly evident at the intersection of
Crotona Avenue and Claremont Parkway, at the
center of Crotona Park.
17/23
DPR
Reconstruct or
Install park benches within Crotona Park; Bronx
upgrade a park or
CB 3 capital budget request 18; Tracking Code
amenity (i.e.
103200802C; Due to the increased utilization of
playground, outdoor
Crotona Park as a result of capital
athletic field)
improvements to ballfields and play areas,
residents have sought to increase the
availability of park seating within the park for
passive relaxation and enjoyment purposes, in
accordance with the Crotona Park Master Plan-
2034.
18/23
NYPD
Provide a new NYPD
Renovate the NYPD 42nd Police Precinct; Bronx
facility, such as a
Community Board Three capital priority 21,
new precinct house
Tracking code: 103200004C. Consider plans to
or sub-precinct
renovate the NYPD 42nd Pct. at 830
Washington Avenue, to include a new or
upgraded HVAC system throughout, new front
desk replacement ($160k), new flooring,
painting, platform re-construction, sub-floor
structural improvements and overall spruce up
in line with the Precinct Enhancement Program.
Plans should also include additional on or off
street parking options for sector vehicles
assigned to the precinct.
19/23
DPR
Reconstruct or
Rehabilitate CS 132 Playground (Morgan
upgrade a park or
Playground) at E. 168 St., Park Avenue and
amenity (i.e.
Washington Avenue; Bronx CB 3 capital budget
playground, outdoor
request  33; Tracking Code; 103201203C;
athletic field)
Bronx CB 3 is requesting that CS 132 Playground
be rehabilitated to include improvements to the
play surface. backboards, and rims at the
basketball courts, including new line markings
and park logo. Additionally, the board is
requesting that the NYC DPR re-surface the
walls and floors of the existing handball courts.
20/23
DPR
Reconstruct or
Repair broken and Defective Concrete Facing at
upgrade a park or
Handball Courts and Related Grounds at Basil
amenity (i.e.
Behagen Playground - Union Avenue, Tinton
playground, outdoor
Avenue and E. 166 St. in Bronx CD 3; Bronx CB 3
athletic field)
capital budget request  26; Tracking Code
103201005C; Bronx CB 3 is requesting the
intervention of NYC DPR in repairing the
broken/defective concrete facing at numerous
locations on the handball courts and the related
ground areas. Additionally, the scope of work
should address other defective concrete
conditions throughout the park, particularly the
softball play area. These defects have impaired
the ability of players to enjoy games at the park
site. Bronx CB 3 recommends that this item be
addressed via a NYC Requirements contract.
21/23
SCA
Renovate other site
component
Renovate Swimming Pool at PS/MS4 located at
Fulton Avenue and E. 173 St.; Bronx CB 3 capital budget request  16; Tracking Code:
103200704C; Bronx Community Board Three is
requesting that DOE, in collaboration with the
School Construction Authority, fund
improvements to the swimming pool at PS/MS 4
to include ceiling painting and re-grouting of the
existing tile($30k), in addition to the
replacement of broken tiles, deck re-surfacing
and upgrading of pool lockers and locker room.
22/23
DPR
Provide a new or
Develop Greenthumb and Flower Garden at
Hoe Ave
expanded park or
Block 2979, Lots 28, 30, 31,33,35,36 (Hoe
Home St
amenity (i.e.
Avenue between Home and Freeman Streets);
Freeman St
playground, outdoor
Bronx CB 3 capital budget priority request 6;
athletic field)
Tracking Code 103199506C Due to increased
residential development within the area of
Crotona Park East and in consideration of the
interest of the Hoe Avenue and Home St.
Garden committee, Bronx CB 3 is requesting
that NYC Parks and Recreation provide for the
development of a green and flower garden at
this location. The scope of work should include
landscaping, vegetable and flower plantings
and passive seating. It is further recommended
that NYC DPR collaborate with Bronx CB 3 and
the area homeowners association on Hoe
Avenue, to develop a final design for approval
by Bronx CB 3.
23/23
Other
Other capital budget
Bronx Community Board Three is requesting the
request
establishment of an emergency operations
center to serve as a hub (operational base) for
emergency preparedness purposes. This local
emergency operations center would serve to
coalesce residents, organizations, churches,
businesses and civic groups and associations in
Bronx Community District Three, under a
cohesive emergency preparedness plan of
action. (Jurisdiction of NYC Emergency
Management)
CS
DEP
Inspect water main
on specific street
Bronx CB 3 DEP Capital priority request 1 in
FY 16 (Tracking Code 103198502C) - Initial
Southern
Boulevard E.
segment and repair
Budget Line HW-698, Project ID HWX-698W -
174 St.
or replace as
Trunk Water Main replacements in connection
Jennings St.
needed (Capital)
with reconstruction of Southern Blvd. from E.
174 St. to Jennings St. in Bronx Community
District Three. The project was assigned to DEP
with expanded scope to include sanitary sewer
replacements and is now managed by DDC. The
current budget lines are SE-2X, WM-1, WM-6,
WM-944; Project IDs HED-553,SEX-002245. The
FY'16 Adopted Budget register indicates that
the final design contract has been let and that
this project is expected to go into construction in
FY'17. DDC has informed the board that the
project contract has been executed and that
construction is expected to commence before
the end of calendar yr
CS
DPR
Reconstruct or
Renovate Crotona Park Ballfields 4 and 5
upgrade a building
(contiguous and integrated play area) to
in a park
provide for removal of old and installation of
new bleachers, new drainage, new fencing, new
playing field surface with related field markings,
water fountains and a comfort station; Bronx CB
3 capital priority 5; Tracking Code
103201101C) Ballfields 4 and 5 at Crotona Park
North near Prospect Avenue, require renovation
due to the existing field condition which has
been compromised over the years due to
regular and seasonal league play.
CS
DPR
Reconstruct or
Reconstruct Comfort Station within Crotona
1596 Crotona
upgrade a building
Park at E. 171 St. and Fulton Avenue; Bronx CB 3
Ave
in a park
Capital Budget Request 9; Tracking Code
103199504C) Improvements to the existing
comfort station are needed to allow for
reactivation of its former use. This would
support the prior rehabilitation by NYC DPR of
Playground10 in FY 97/98. The improvements
should include allowances for ADA accessibility.
Councilman Joel Rivera had appropriated $840k
from FY 2012 for this purpose. This project is in
design.
CS
DPR
Provide a new or
expanded park or
Provide New Construction of Park at Site 32
with the Melrose Commons URA. Budget Line:
amenity (i.e.
P-D021, P-C021, WM0011; Project ID(s) P-
playground, outdoor
103MP32, P-101MELR, P-1CROT41 Bronx CB 3
athletic field)
capital budget priority request 2 (Tracking
Code-103200206C) Bronx CB 3 has requested
funding to construct a new park at this location
which divides Bronx Community Districts 3 and
1. This park, once completed, will address the
open space and recreational needs of the
residential community within the Melrose
neighborhoods shared by Bronx Community
Districts 3 and 1. The work scope and design is
expected to include a youth and tot play area,
water play area, arbor, granite stairs/plaza,
common lawn and buffer planting, garden and
adult fitness area.
CS
DPR
Reconstruct or
Provide for Renovation of Phase II of Estella
upgrade a park or
Diggs Park at Third Avenue and E. 167 St. Bronx
amenity (i.e.
CB 3 capital budget request 4 (Tracking Code:
playground, outdoor
103200101C) Phase II funding request ($1.3
athletic field)
mil.) would address site stabilization due to
topography, landscaping, perimeter fencing,
pathways, new recreational playground and/or
facility to include a waterfall at the site of E. 167
St. and Third Avenue; east side, Block 2608, lots
38,39,40,43,48,53,54). Such site will attract
resident youth living at Claremont Consolidated
NYCHA development on Washington Avenue, as
well as numerous developments along Boston
Road and E. 163 St. within CD 3. Phase I was
completed on 5/10/11 at a cost of $2.9 mil.
CS
DPR
Reconstruct or
Install New high Intensity Sports/Security
upgrade a building
Lighting at Ballfield 1 in Crotona Park at
in a park
Claremont Parkway and Crotona Avenue;
Tracking Code 103200804C; FY' 2017 CAPIS P-
103CRO1; Project in Procurement -$1.531 mil.
(Council/Mayoral); March 2017 procurement
completion. Ballfield 1 was the subject of
capital improvements completed in 2008 which
included new bleachers, new sod, and upgraded
irrigation at a cost of $800k. At the request of
Jaws Baseball Little League, Inc. Bronx CB 3 is
requesting the installation of new high intensity
sports/security lighting for extended evening
and tournament play for youth.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/28
NYPD
Assign additional
Increase Housing Police Officers at PSA 7 and
housing police
assign to Forest Houses, Butler Houses,
officers
Webster/Morrisania Houses and Morris Houses
developments, within Bronx Community District
Three. FY'16 priority request 3; FY'17 priority
request 2; Tracking Code 103198509E
2/28
NYCHA
Install security
Install security surveillance cameras at NYCHA
cameras or make
Butler and Webster/Morrisania Houses in
other safety
Claremont Village. FY'16 priority 4; FY'17
upgrades (Expense)
priority 3;Tracking Code 103200503E. Federal
CIAP and/or modernization funds were secured
for the purpose of installing high tech security
surveillance cameras at Morris Houses in 2000.
These funding appropriations allowed for
installation of cameras in and around building
perimeters and has significantly reduced crime
based on COMPSTAT crime indexes within PSA 7.
As a result, Bronx Community Board Three is
requesting similar fiscal appropriations for
camera installations at Butler and
Webster/Morrisania Houses.
3/28
EDC
Improve public
FY'16 priority request 13;FY'17 priority request
housing
11; Tracking Code 103198511E. Purchase
maintenance and
containers for storage of solid waste at NYCHA
cleanliness
developments in Community District Three-
Bronx. Allocations of compactor
containerization units are requested for
placement at NYCHA sites to contain large
amounts of refuse which remain on the street
attracting dogs and vermin. Placement of the
containerization units at NYCHA sites, will allay
adverse mayoral scorecard ratings for street
and sidewalk cleanliness issued by the Office of
the Mayor to DOS Bronx West Three district.
4/28
DPR
Provide better park
maintenance
Increase Personnel in CD Three for Effective
Operations; Bronx CB 3 expense budget request
6; Tracking Code: 103198904E; Provide the
following additional personnel for effective
parks maintenance and operation of our parks
and playgrounds: a. Two (2) Associate Park
Service Workers. The APSW requirements
include CDL licensing for truck operations
related to refuse removal throughout CD 3
parks and playgrounds b) Two (2) climbers and
pruners. The following personnel request is for
dedicated staffing to Crotona Park exclusively:
12 seasonal CPWs for maintenance of park
(Spring/Summer); 4 full time CPWs for year
round dedicated lake cleaning and
maintenance, 1 gardener, 2 PEP sergeants and 6
officers for year round park security and 1 driver
(APSW)
5/28
DPR
Provide better park
Assign Additional Maintenance and Operations
maintenance
Personnel in Crotona Park; Bronx CB 3 expense
budget request  10; Tracking Code:
103199504E; The rehabilitation/upgrading of
playgrounds and ball fields in Crotona Park, as
well as ongoing concerns regarding the cleaning
and maintenance of Indian Lake, warrant the
assignment of the following dedicated staff
personnel exclusively to Crotona Park: 12
seasonal CPWs for maintenance of park
(Spring/Summer); 4 full time CPWs for year
round dedicated lake cleaning and
maintenance, 1 gardener, 4 climbers and
pruners, 2 PEP sergeants and 6 officers for year
round park security and 1 driver (APSW)
6/28
NYPL
Extend library hours
Increase funding for the New York Public Library
or expand and
Services at the Morrisania Library; Bronx CB 3
enhance library
expense budget request 7; Tracking Code:
programs
103199503E; In order to provide the
opportunity for district children and youth to
fully participate in the NYPL's many services,
funding for the Morrisania branch needs to be
increased to allow for six day service including
increased hours, diverse programming, strong
collections and sufficient support staff to
support these functions. This request is justified
in that the circulation rate for Morrisania has
increased as well as the attendance at the
branch.
7/28
DYCD
Provide, expand, or
FY'16 priority request 15; FY'17 priority request
enhance after
13; Tracking code 103201401E. Increase
school programs for
funding for after school programs for Bronx
elementary school
Community District Three schools in DOE School
students (grades K-
Districts 8, 9 and 12. Due to educational
5)
challenges faced by both English and non-
English speaking students at the elementary,
junior high school and high school levels,
increased funding is needed for after school
support and tutorial assistance for students, as
well as resources for parents, to assist them in
promoting the educational achievement of their
children in school districts 8, 9 and 12, in Bronx
Community District Three.
8/28
NYPD
Assign additional
FY'16 priority request  22; FY'17 priority
uniformed officers
request 20; Tracking Code 103198301E. Assign
additional police personnel to the NYPD 42nd.
Pct. to combat crime, ensure public safety and
provide concentrated enforcement efforts at
narcotics prone locations throughout the district
area.
9/28
DOHMH
Create or promote
In consideration of the fact that NYC DOHMH
1309 Fulton
programs for
health indices speak to adverse health
Avenue
education and
conditions in Bronx Community District Three
awareness on
related to Asthma, Obesity, HIV/AIDs, Diabetes,
nutrition, physical
Cancer and Heart Disease, Bronx Community
activity, etc.
Board Three is requesting an increase in the
assignment of health educators and related
personnel at the Morrisania Health Station-
1309 Fulton Avenue, for engagement with DOE
and private school students, residents, local
community based organizations and youth
service providers, for the purposes of providing
on going health education and education for
disease prevention, throughout Bronx
Community District Three.
10/28
DYCD
Provide, expand, or
FY' 16 priority request23; FY'17 priority
enhance the
request 21; Tacking code 103201001E.
Summer Youth
Increase funding for the Summer Youth
Employment
Employment Program to prevent the extent of
Program
idle youth behaviors and adverse youth
involvement with local neighborhood gangs.
11/28
DHS
Improve safety at
FY'16 priority request 311;FY'17 priority request
homeless shelters
9;Tracking code 103200101E. (Scope modified)
Provide for increased security at all DHS
contracted shelters and facilities in CD 3.
Security measures need to be enhanced to
preclude unauthorized and illicit activities which
occur around the perimeter of the shelter
grounds and to preserve sound quality of life
conditions in the areas in which these facilities
are located.
12/28
DOE
Other educational
FY'16 priority request 14; FY'17 priority request
programs requests
12; Tracking Code 103198512E. Install large
containers for refuse and solid waste at public
school sites. As a result of DOE protocols
involving the service of school lunches using
paper goods as opposed to the type of food
service that was permanent and not disposable,
solid waste remains on the street in front of
schools. This condition is unsightly and attracts
dogs and vermin.
13/28
DOB
Assign additional
FY' 16 Priority request 5; FY' 17 priority request
building inspectors
4; Tracking Code 103199402E. Provide
(including
additional DOB inspectors Bronxwide to address
expanding training
issues of owner non-compliance with the NYC
programs)
Administrative code and zoning requirements.
Added funding for additional DOB inspectors
will support the needs of each specific
community district in addressing DOB violations
relating to illegal property uses, work without
permits, illegal SRO conversions and many other
problematic building and zoning code
conditions.
14/28
DFTA
Other senior center
Bronx Community Board Three requests
program requests
additional funds to be allocated to the NYC
Department for the Aging, to increase services
related to transport/escort, congregate and
home delivered meals and other coordination
and social action programs for senior centers in
Bronx Community District Three
quality/staffing of
Continued Operation of the Crotona Park
existing programs
Nature Center; Bronx CB 3 expense budget
offered in parks or
request  17; Tracking Code 103200102E; In
recreational centers
order to promote environmental/park wildlife
education of neighborhood youth and those
attending local community and elementary and
intermediate schools in CD 3, park personnel are
needed to staff the operation of the Crotona
Park Nature Center year round.
16/28
DPR
Improve the
Hire Additional Recreational Staff for the
quality/staffing of
Crotona Pool and Recreation Center; Bronx CB 3
existing programs
expense budget request  19; Tracking Code;
offered in parks or
103198501E; With new public and private
recreational centers
renovated housing within the district, the
following additional staff are needed in the
recreation center and pool area of Crotona
Park: 2 recreational directors, 3 playground
assistants. 3 recreational aides, 2 community
aides, 1 clerk and 2 urban park rangers.
17/28
DOHMH
Other animal and
FY'16 priority request 24; FY'17 priority request
1826 Arthur
pest control
22; Tracking Code 103199501E. Assign the
Avenue
requests
following additional personnel to the Bronx
DOHMH Bureau of Pest Control; two (2)
exterminators, three (3) clerical staff persons,
eight (8) field staff persons for building and yard
clean-up including additional supplies of talon.
18/28
DSNY
Increase
FY'19 priority request 25; FY'17 priority request
enforcement of
23; Tracking code 103198902E. Increase
illegal dumping laws
Sanitation Police force by 20 officers citywide, to
address issues involving illegal dumping and
dumpout conditions on street and sidewalks.
19/28
SBS
Provide or expand
Provide funding for development of year round
584 E. 163 St.
occupational skills
home health aide training program at existing
training programs
ground floor commercial space located at 584 E.
163 St. This location is a mixed use property
owned by Morrisania Revitalization
Corporation, a local development corporation
within Bronx Community District Three.
through more
Enforcement Patrol Officers (PEP) to Ensure
security staff (police
Quality of Life Observance in Bronx
or parks
Parks/Recreational Areas; Bronx CB 3 expense
enforcement)
priority  1; Tracking Code: 103199405E;
Community Board Three supports the need for
additional PEP staffing in support of increased
concerns regarding park security and
vandalism. CD 3 expresses the urgency of this
need in its efforts to ensure the viability of CD 3
parks and recreational facilities.
21/28
DOT
Other expense
Increase the number of Highway Repairmen at
traffic
the NYC Dept. of Transportation; Bronx CB 3
improvements
expense budget request 18; Tracking Code:
requests
103200103E; Bronx Community Board Three is
requesting an increase in the number of
Highway Repairmen assigned to the Bronx
Office of NYC DOT, by ten(10), to assist in ithe
repair of potholes/cave-in conditions within
Bronx County.
22/28
DOT
Provide new traffic
Assign Additional Personnel to the New York
or pedestrian
City Department of Transportation, Bureau of
signals
Traffic; Bronx CB 3 expense budget requests 8;
Tacking Code: 103199502E; In consideration of
agency delays in the restoration and
replacement of missing/defective traffic signage
throughout the district, the following personnel
are requested for assignment at the NYC DOT,
Bureau of Traffic: Three (3) Device Maintainers.
23/28
NYPD
Other NYPD staff
FY'16 priority request 16; FY'17 priority request
resources requests
14; Tracking Code 103198502E. Increase traffic
personnel assignments in District Three in the
functional area of traffic control. The following
personnel are requested to be added: 1 senior
traffic control inspector, 2 traffic control agents.
24/28
NYPD
Provide additional
FY'16 priority request 7; FY'17 priority request
patrol cars and
5. Assign Additional equipment to the NYPD
other vehicles
42nd Pct. to include 1 van for the NYPD youth
outreach program, 8 additional wheel scooters
for police patrol surveillance and 10 bicycles for
patrol purposes.
including street tree
Bronx CB 3 expense budget request 16;
maintenance
Tracking Code: 103198903E; Provide six(6)
additional climbers/pruners to the Bronx Office
of NYC DPR to assist in the backlog of tree
pruning and hazardous tree removal
complaints. Personnel are needed to address
tree limb overgrowth conditions which
compromise street lamp lumen emission
efficiency within parks, on street and at arterial
highway locations.
26/28
DYCD
Expand After School
Provide expanded after school tutorial services
Programs
including SAT college preparatory services for
youth and young adults ages 6-24 years, at
Southeast Bronx Neighborhood Centers, Inc.
(S.E.B.N.C.) at 955 Tinton Avenue.
27/28
SBS
Other expense
Provide funding for workforce development
workforce
programs related to job training/development
development
for the formerly incarcerated and youth aging
requests
out of foster care(14-25 years of age), aimed at
preventing incarceration and increased rates of
recidivism of the formerly incarcerated. Efforts
should be undertaken to create incentives for
prospective employers to hire formerly
incarcerated adults and offenders.
28/28
DYCD
Expand After School
Provide funding for after school tutorial,
Programs
job/career development and
wellness/recreation service programs, for high
school students who have aged out of existing
middle school programs.

