- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 9 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1nOPyWHVRMI0oRD3r5IwSJg402Yfpp0Qx/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1nOPyWHVRMI0oRD3r5IwSJg402Yfpp0Qx/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
9
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 9
image
Address: 120-55 Queens Blvd., 310-A Phone: (718) 286-2686
Email: qn09@cb.nyc.gov
Website: www.nyc.gov/queenscb9
Chair: Kenichi Wilson District Manager: James McClelland
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board No. 9 consists of four communities, Woodhaven, Ozone Park, Richmond Hill and Kew Gardens (WORK). Each is very distinct yet all the residents have similar concerns and needs. Community Board No. 9 is truly a microcosm of the borough of Queens where our diversity is our strength.
Like many New Yorkers, the constituents of Community Board 9 want safe streets, great schools, senior services, economic opportunity, and access to quality parks and recreation. Our budget priority Capital and Expense List targets many of these areas and respectfully calls on our esteemed elected officials to consider each request.
Community Board 9 is facing the construction of a community jail in Kew Gardens and fully operational homeless shelter in Ozone Park. These two facilities will impact our infrastructure and ability to deliver city services.
Community Board 9 requests that the 102 precinct be considered for additional officers to help monitor these locations and keep the growing population of residents safe.
Great schools are a primary concern not only of existing residents but of individuals looking to move into the great borough of Queens. Our schools continue to endure severe overcrowding and therefore we must build more classrooms here in our communities.
We owe our seniors a debt of gratitude. We have an important responsibility to ensure they have access to effective programs. Therefore, our senior centers should be fully funded along with the programs they offer our senior residents.
Community Board 9 has strong retail corridors comprised of small business owners. It is important that we make these retail corridors attractive and safe for customers. We encourage a Green Streets program along Woodhaven Boulevard and improve the lighting along Jamaica Avenue.
Our parks and cultural centers provide a much needed outlet for residents. Forest Park is an incredible asset to the borough of Queens. Community Board 9 requests that funding be allocated for pruning, fencing and more Park Enforcement Patrol officers for Forest Park.
Libraries are a great gathering place for residents of all ages. It’s a place to access computers, it is all-inclusive, safe and friendly environment, and a unique forum for social networking and reading groups. We request that the Woodhaven and Richmond Hill Libraries remain fully funded and the projects move forward in a timely manner.
A multi-cultural Community Center would be a welcomed edition to the Community Board 9 community. We hope to work with the Queens Economic Development Corporation and interested non-for-profits to make this a reality.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 9
image
The three most pressing issues facing this Community Board are:
Quality of life issues (noise, graffiti, petty crime, etc.)
Qualify of life issues are are extremely important in the district. These issues range from traffic, noise, lack of parking, safe street and cleanliness. Residents are concerned that city agencies meet the growing demand to address these issues. The looming construction of a community jail, proliferation of homeless shelters and over development are putting a strain on existing infrastructure and services.
Schools
Community Board 9 has many successful and high performing schools. However, like many districts over-crowding is an issue and we need the construction of more classrooms. Many schools are having trouble obtaining funding for capital improvements and programmatic funding
Senior services
Our seniors are living longer and need access to life enrichment programs. Many are still able to be productive members of the workforce and lack the training in current computer technologies. We need to expand and make accessible programs for our seniors.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 9
image
M ost Important Issue Related to Health Care and Human Services
Programs, services or facilities for seniors
Maintaining physical fitness, eating right, etc. is a very important issue and is essential to living a healthy and happy long life. Adults in CB9Q are more likely to eat fruits and vegetables compared to adults citywide. Current Smokers rank 26th compared to East Flatbush who rank 59th. 1 or more 12oz sugary drink per day (cb9Q) 33% of residents ranks 19th. 93% of CB9Q residents has at least one serving of fruits or vegetables per day. Physical activity in the last 30 Days. Cb9Q residents ranks 76%. Obesity can lead to serious health problems such as diabetes and heart disease. At 24% the rate of obesity in CB9Q is three times the rate in Stuyvesant Town and Turtle Bay. Alcohol related hospitalization (per 100, 000 adults) cb9Q has 773 hospitalizations re;. Drug related hospitalizations in CB9Q is 315.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
In CB9Q one in five adults has no health insurance and one in Eight go without medial care. 21% have no Health Insurance. 12% went without needed medical care. 8.2% had late or no prenatal care. CB9 Teenage girls are less likely to receive the full human papillomavirus (HPV) vaccine series. 38% of girls ages 13-17 years have received all 3 doses of the HPV vaccine. 37% of Adults have gotten the Flue vaccination. High Blood Pressure is the leading risk factor for stroke and it very important to control. Hospitalizations due to stroke( per 100,00 adults) 310 residents in CB9Q were hospitalized due to stroke. 400 people in CB9Q have been hospitalized for Psychiatric reasons. The rate of Asthma hospitalizations among children ages 5 to 14 is lower then the citywide rate.
Needs for Older NYs
We currently have two thriving Senior Centers one in Kew Gardens and one in Ozone Park. They are in need of programs such as: computer programs and new computers. Need for progams for immigrants & seniors in general to learn new skills. We have a Senior Center in Ozone Park Address: 103-02 101st Avenue Ozone Park, NY 11416 the Center in Kew Gardens Address: 88-02 Kew Gardens Rd. Kew Gardens, Ny 11415
Needs for Homeless
No comments
Needs for Low Income NYs
The Human Resources Administration is dedicated to fighting poverty and income inequality with essential programs that help families and individuals with economic and social service needs. Constituents can apply or recertify for Supplemental Nutrition Assistance Program (SNAP) benefits online and check if you are eligible for Cash Assistance and many other programs at New York City’s front door for benefit access, ACCESS HRA.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
14/22 DFTA Create a new senior
center or other facility for seniors
Fund Senior Centers Throughout District 9 Additional funding to expand and create new senior centers within the CB9Q.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/14
DFTA
Enhance
Our seniors deserve programs that improve the
educational and
mental, physical, financial and emotional
recreational
health. It is importation we increase funding to
programs
programs that will greatly improve the quality
of life of our senior population.
4/14
DOHMH
Create or promote
In this technologically advance environment and
programs to de-
the use of various social media platforms can
stigmatize mental
cause stress and anxiety in our children and
health problems
young adults. There should access to mental
and encourage
health programs to help individuals cope with
treatment
stress and depression.
5/14
DOHMH
Create or promote
Many veterans return to civilian life that require
programs to de-
mental health support. Issues can be dealing
stigmatize mental
with PTSD, substance abuse or difficulties
health problems
returning to civilian life. It is important that we
and encourage
have programs to help our veteran population.
treatment
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 9
image
M ost Important Issue Related to Youth, Education and Child Welfare
Support services for special needs youth (disabled, immigrant, non-English proficient, etc.)
Students of all backgrounds, including learning and physical disabilities should have access to a quality education. Every effort should be made to ensure that each school has the ability and resources to our special needs children.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
PS 90 Requests an indoor Gym . We need Adequate finding for Universal Pre-K Programs in all Public Elementary Schools as well as home based Pre K. We need to ensure that all who apply for Pre- k have enough seats for all. CB9Q continues to advocate for increased funding to Our Beacon Program at JHS 210 and to fund all Beacon programs in NYC. Beacon program provide students with homework help, test preparation, recreation, Physical Fitness, nutritional programs, etc. CB9Q is also in desparate need for the construction of new schools in District 27,28 & 24 as many of our children who live in the district go to schools in Dist 24. Our board needs more School Crossing Guards. There are very dangerous conditions at our schools during morning arrival and afternoon dismissal. Many people have no regard for traffic rules and there is chaos when irrsponable drivers, etc. speed and don't abide my traffic laws For our growing Communiities there is: 1) complete absence of any complete community center to serve the needs of Indo-Caribbean and South Asian children and families. 2) Lack of legal affordable housing options 3) Not enough youth and academic programs for children from ages 6-18 especially when the drop out rate at high sch total disregard for our children & residents safety.
Needs for Youth and Child Welfare
1) Construct Community center to serve the needs of Indo-Caribbean, South Asian Children and families. 2) Expand youth and academic programs for children from ages 6-18 especially when the drop out rate at high school is about 50%
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
1/22
SCA
Renovate other site
Principal has requested new library for students.
8552 85th St,
component
This will allow for additional educational and
Woodhaven,
enrichment programs
NY 11421
3/22
SCA
Provide technology
PS 56Q needs security cameras to improve the
86-10 114th
upgrade
safety of teachers and students.
St, Richmond
Hill, NY 11418
6/22
SCA
Provide technology
Tiegerman High School serves the needs of
87-25 136th
upgrade
preschool and school age children with severe
St, Richmond
language and autism spectrum disorders.
Hill, NY 11418
Laptop computers will teachers to utilize
technology to enhance their successful program
12/22
SCA
Provide technology
PS 90 needs 20 more smartboards to ensure
upgrade
that each classroom is equipped with this
technology.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/14
DYCD
Provide, expand, or
Continue to fund Beacon Program at Middle
enhance
School 210 and expand to other district schools.
Cornerstone and
The Beacon Program provides educational,
Beacon programs
sports and mentoring opportunities outside
(all ages, including
normal classroom hours. Funding should be
young adults)
maintained or increased.
3/14
DOE
Other educational
Students of all backgrounds, including learning
programs requests
and physical disabilities should have access to a
quality education. Every effort should be made
to ensure that each school has the ability and
resources to our special needs children.
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 9
image
M ost Important Issue Related to Public Safety and Emergency Services
Crime prevention programs
Our Precinct- the 102nd does a great job in keeping our district safe and it is imperative to maintain our safety and the quality of life and this will thrieve with the addition of additional Police Officers. Increasing Funding for Domestic Violence Prevention Programs is essential in educating the public and to provide programs that help Families.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Increase Resources for domestic violence prevention programs as this is a serious issue and incidents are on the rise.
Needs for Emergency Services
Need to contact the agencies to see exactly know where this is needed.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
7/22
NYPD
Renovate or
The parking lot adjacent to the 102nd Precinct
87 118 Street,
upgrade existing
building needs to be resurfaced and repair. This
Queens, New
precinct houses
will provide adequate parking for police office
York, NY
and free up street parking in front of residential
property
13/22
NYPD
Provide surveillance
Request the installation of Argus surveillance
cameras
cameras at problematic or high crime locations.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
6/14
NYPD
Assign additional
We must receive our fair share of Police Officers.
uniformed officers
Our district will be home to high-rise community
jail and also includes Queens Borough Hall,
Forest Park, and a number of churches,
synagogues and temples that are in need of
constant attention.
7/14
NYPD
Increase resources
Domestic violence does not discriminate.
for domestic
Anyone of any race, age, sexual orientation,
violence prevention
religion or gender can be a victim – or
programs
perpetrator – of domestic violence. It can
happen to people who are married, living
together or who are dating. It affects people of
all socioeconomic backgrounds and education
levels. We need programs to help these victims
8/14
NYPD
Assign additional
Assign Additional School Crossing Guards.
crossing guards
Assign additional school crossing guards in all
schools in Community Board 9.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 9
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Sewer capacity
It is imperative that we have Sewers that are at full capacity and able to avoid over flowing water & flooding.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
We need Catch basins that will help to keep water flowing properly. Maintain and clean catch basins on a regular basis.
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
10/14 DSNY Expand
opportunities for electronic waste collection and disposal
With additions funding DSNY can increase their community service
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 9
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
Community Board 9 wants to strengthen its partnership with NYC City Planning. There must be a mutual respect for the ULURP process and the important role community boards play in the decision making process. Some large scale developments can have a beneficial impact and others can have negative effects on the district. Consequently, it is imperative that the process remain transparent, fair and scrupulous.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Queens Community District 9 is very concerned with NYC "Affordable Housing". It seems that many residents are unable to reach their dream of home ownership as prices of Homes, Condo's etc. are out of reach for many.
Needs for Housing
No comments
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
TRANSPORTATION
Queens Community Board 9
image
M ost Important Issue Related to Transportation and Mobility
Accessibility (crowded or obstructed sidewalks and other public thoroughfares)
Accessibility (crowded or obstructed sidewalks and other public thoroughfares)
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
The Department of Transportation's Select Bus Service (SBS) has been a controversial issue in CB9Q as residents are upset that DOT has not listened to their constituents and have reconfigured where people get on buses, i.e. middle median on Woodhaven Blvd. Routes would reconfigure lanes and eliminate left turns at major intersections as well as install bus stops in the median of Woodhaven Boulevard, which opponents fear will create unsafe conditions along the corridor and interrupt flow of traffic. Local Elected officials, i.e. State Sen. Joe Addabbo (D-Howard Beach), State Assemblyman Mike Miller (D-Woodhaven), and the Woodhaven Residents’ Block Association, the Business Improvement District, the Greater Woodhaven Development Corporation, and a Task Force for a Better Woodhaven gathered on Woodhaven Blvd to express their frustrations and concerns regarding the SBS Plan.
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/22
DOT
Upgrade or create
Incorporate Greenstreets Program on
Woodhaven
new greenways
Woodhaven Blvd. Additional tree plantings on
Blvd Myrtle
Woodhaven Blvd. from Myrtle Ave. to 103 Ave.
Ave 103 Ave
and gardens where appropriate.
11/22
DOT
Repair or construct
Funding for new contract to replace or repair
new curbs or
damaged curbs in residential and commercial
pedestrian ramps
areas in Woodhaven, Ozone Park, Richmond Hill
and Kew Gardens
15/22
DOT
Repair or provide
New lighting on Jamaica Ave from 86th St to
new street lights
Elderts Lane. Better lighting on all sidewalks is
needed in Forest Park. There are too many dark
areas where pedestrians become targets for
theft, assault, and etc.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
11/14
DOT
Add street signage or wayfinding elements
Welcome Signs for Community Board 9. Signs for Woodhaven, Ozone Park, Richmond Hill, and Kew Gardens.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 9
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Community board resources (offices, staff and equipment)
Community Boards are the front lines of dealing with a variety of community issues. It is important that each board has the resources to achieve its purpose to encourage and facilitate the participation of citizens within City government within their communities, and the efficient and effective organization of agencies that deliver municipal services in local communities and boroughs.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Please see previous page.
Needs for Cultural Services
No comments
Needs for Library Services
Increase funding for Libraries and expand weekend service at Richmond Hill, Woodhaven and all Libraries in Community Board 9 Queens.
Needs for Community Boards
Increase operating Budget of Community Boads. We are requesting an increase to $250,000 a portion of which will be used to upgrade and maintain our Computer System, Complaint system, fund website, a postage increase and to provide technical support for these functions. In addition to record and support live streaming of our meetings.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
2/22
QL
Create a new, or
Richmond Hill Library was scheduled to be
118-14
renovate or upgrade
renovated by Queens Library. Over $8 million
Hillside
an existing public
was allocated, Now DDC is charged with
Avenue,
library
managing the project. More money will be
Richmond
required to fully fund this important community
Hill, NY 11418
project
8/22
DPR
Reconstruct or
Maurice Park needs a full restoration.
106th Street
upgrade a park or
Constituents have requested resurfacing, new
and Atlantic
playground
playground equipment, and new basketball and
Avenue
handball courts.
9/22
DPR
Reconstruct or
Phil Rizzuto Park - Repair and replace existing
upgrade a park or
Ball Fields, installation of a new Track, replace
amenity (i.e.
water fountain, install bleacher seating, install
playground, outdoor
adult exercise equipment and construct a stage
athletic field)
area for events and performances. This Park is
utilized by many residents who use the ball
fields for numerous sports activities (i.e. Cricket,
baseball, football, soccer etc.) The current field
is in poor condition and is need of immediate
renovation. The installation of a Track will
enhance the parks usage.
10/22
DPR
Provide a new or
The Trust for Public Land is working with Friends
expanded park or
of the QueensWay, community members, and
playground
the City and State of New York to create the
QueensWay. This elevated pedestrian and
bicycle pathway would connect the
communities of Rego Park, Forest Hills,
Richmond Hill, Glendale, Woodhaven, and
Ozone Park. This would provide much needed
public green space, recreation areas,
opportunities for safe alternative commuting,
and community spaces to celebrate the cultural
diversity of Queens.
16/22
DPR
Provide a new, or
Install Handicapped Accessible Bathroom at the
W Main Dr
new expansion to, a
Visitors Center -Forest Park. This is located at
and
building in a park
the corner of W. Main Drive and Woodhaven
Woodhaven
Blvd.
Blvd
17/22
DPR
Reconstruct or
Fund Rehabilitation of the Greenhouse
upgrade a park or
Playground. Upgrade equipment, swings, slides,
amenity (i.e.
and safety surface, etc. Repair and construction
playground, outdoor
of all sewer basins, sidewalks, and roadway of
athletic field)
Forest Park Drive.
18/22
DCLA
Purchase equipment for cultural facility
Fund Additional Computers The Community Center in Kew Gardens operates an instructional program and helps seniors and immigrants learn new skills. The computers are outdated and were last upgraded in 2004. We recommend this project be brought to the attention of your elected officials.
20/22
DPR
Other park maintenance and safety requests
Secure New Equipment for Forest Park Maintenance Workers. Secure Crew Cub Dump Truck with Plow & Salt Spreader.
CS
DPR
Reconstruct or upgrade a park or playground
Adding toddler equipment, upgrade swings, install new spray shower
CS
DPR
Reconstruct or upgrade a parks facility
new benches, plantings and monument stone
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
9/14
DPR
Enhance park safety
Install plank fencing along Freedom Drive in
Freedom
through design
Forest Park . This fence will provide safety for
Drive
interventions, e.g.
pedestrian and also help control litter
better lighting
accumulation
(Expense)
12/14
DPR
Enhance park safety
Fund Park Enforcement Patrol Unit for Forest
through more
Park. Forest Park is host to many athletic
security staff (police
facilities, recreational programs, and special
or parks
events. It also has 543 acres of forest, which
enforcement)
feature numerous hiking trails and a 4-mile
equestrian path. Our park has a high volume of
events and activities. Problems such as user
conflicts permit violations, crowd control,
vandalism, deviant behavior and other
enforcement issues are in need of attention.
Often, PEP nits are not available to respond to
Forest Parks needs due to citywide distribution
of their staff, and summer staffing of pools and
beaches. This has created a rise in misuse of and
vandalism to park facilities, damage to the
landscape, criminal activity and mischief.
13/14 DPR Forestry services,
including street tree maintenance
Fund Pruning Contract for Forest Park This is now a safety issue. Branches have fallen during park concerts and events. It is only a matter of time before someone is seriously injured or killed. The 543-acre park has large mature trees that are 150 years plus. We desperately need a PIP (Parks Inspection Project) funded along with pruning dollars.
image
14/14 DPR Provide better park
maintenance
Fund Maintenance Workers & Equipment. Maintenance workers are funded for eight months only. During the winter they are laid off. When they return they have a backlog of winter work, i.e. painting, cement work, repairs etc., that can be done during the winter.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
4/22
Other
Other capital budget
DYCD assists local community to construct a
request
new community center with indoor pool in
Richmond Hill and Ozone Park where none exist.
This is a heavy populated community with very
limited activities and service for local residents
19/22
Other
Other capital budget
These ambulances used by FDNY are designed
request
with lifts and special wheel chairs to be used for
individuals over 500 pounds
21/22
Other
Other capital budget
To be used by FDNY for disasters to shelter and
request
treat individuals in one place
22/22
Other
Other capital budget
This FDNY equipment is used to respond ahead
request
with a liaison coordinator
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/22
SCA
Renovate other site
Principal has requested new library for students.
8552 85th St,
component
This will allow for additional educational and
Woodhaven,
enrichment programs
NY 11421
2/22
QL
Create a new, or
Richmond Hill Library was scheduled to be
118-14
renovate or upgrade
renovated by Queens Library. Over $8 million
Hillside
an existing public
was allocated, Now DDC is charged with
Avenue,
library
managing the project. More money will be
Richmond
required to fully fund this important community
Hill, NY 11418
project
3/22
SCA
Provide technology
PS 56Q needs security cameras to improve the
86-10 114th
upgrade
safety of teachers and students.
St, Richmond
Hill, NY 11418
4/22
Other
Other capital budget
DYCD assists local community to construct a
request
new community center with indoor pool in
Richmond Hill and Ozone Park where none exist.
This is a heavy populated community with very
limited activities and service for local residents
5/22
DOT
Upgrade or create
Incorporate Greenstreets Program on
Woodhaven
new greenways
Woodhaven Blvd. Additional tree plantings on
Blvd Myrtle
Woodhaven Blvd. from Myrtle Ave. to 103 Ave.
Ave 103 Ave
and gardens where appropriate.
6/22
SCA
Provide technology
Tiegerman High School serves the needs of
87-25 136th
upgrade
preschool and school age children with severe
St, Richmond
language and autism spectrum disorders.
Hill, NY 11418
Laptop computers will teachers to utilize
technology to enhance their successful program
7/22
NYPD
Renovate or
The parking lot adjacent to the 102nd Precinct
87 118 Street,
upgrade existing
building needs to be resurfaced and repair. This
Queens, New
precinct houses
will provide adequate parking for police office
York, NY
and free up street parking in front of residential
property
8/22
DPR
Reconstruct or
Maurice Park needs a full restoration.
106th Street
upgrade a park or
Constituents have requested resurfacing, new
and Atlantic
playground
playground equipment, and new basketball and
Avenue
handball courts.
9/22
DPR
Reconstruct or
Phil Rizzuto Park - Repair and replace existing
upgrade a park or
Ball Fields, installation of a new Track, replace
amenity (i.e.
water fountain, install bleacher seating, install
playground, outdoor
adult exercise equipment and construct a stage
athletic field)
area for events and performances. This Park is
utilized by many residents who use the ball
fields for numerous sports activities (i.e. Cricket,
baseball, football, soccer etc.) The current field
is in poor condition and is need of immediate
renovation. The installation of a Track will
enhance the parks usage.
10/22
DPR
Provide a new or
The Trust for Public Land is working with Friends
expanded park or
of the QueensWay, community members, and
playground
the City and State of New York to create the
QueensWay. This elevated pedestrian and
bicycle pathway would connect the
communities of Rego Park, Forest Hills,
Richmond Hill, Glendale, Woodhaven, and
Ozone Park. This would provide much needed
public green space, recreation areas,
opportunities for safe alternative commuting,
and community spaces to celebrate the cultural
diversity of Queens.
11/22
DOT
Repair or construct
Funding for new contract to replace or repair
new curbs or
damaged curbs in residential and commercial
pedestrian ramps
areas in Woodhaven, Ozone Park, Richmond Hill
and Kew Gardens
12/22
SCA
Provide technology
PS 90 needs 20 more smartboards to ensure
upgrade
that each classroom is equipped with this
technology.
13/22
NYPD
Provide surveillance
Request the installation of Argus surveillance
cameras
cameras at problematic or high crime locations.
14/22
DFTA
Create a new senior
Fund Senior Centers Throughout District 9
center or other
Additional funding to expand and create new
facility for seniors
senior centers within the CB9Q.
15/22
DOT
Repair or provide
New lighting on Jamaica Ave from 86th St to
new street lights
Elderts Lane. Better lighting on all sidewalks is
needed in Forest Park. There are too many dark
areas where pedestrians become targets for
theft, assault, and etc.
16/22
DPR
Provide a new, or
Install Handicapped Accessible Bathroom at the
W Main Dr
new expansion to, a
Visitors Center -Forest Park. This is located at
and
building in a park
the corner of W. Main Drive and Woodhaven
Woodhaven
Blvd.
Blvd
17/22
DPR
Reconstruct or
Fund Rehabilitation of the Greenhouse
upgrade a park or
Playground. Upgrade equipment, swings, slides,
amenity (i.e.
and safety surface, etc. Repair and construction
playground, outdoor
of all sewer basins, sidewalks, and roadway of
athletic field)
Forest Park Drive.
18/22
DCLA
Purchase equipment
Fund Additional Computers The Community
for cultural facility
Center in Kew Gardens operates an instructional
program and helps seniors and immigrants
learn new skills. The computers are outdated
and were last upgraded in 2004. We
recommend this project be brought to the
attention of your elected officials.
19/22
Other
Other capital budget
These ambulances used by FDNY are designed
request
with lifts and special wheel chairs to be used for
individuals over 500 pounds
20/22
DPR
Other park
Secure New Equipment for Forest Park
maintenance and
Maintenance Workers. Secure Crew Cub Dump
safety requests
Truck with Plow & Salt Spreader.
21/22
Other
Other capital budget
To be used by FDNY for disasters to shelter and
request
treat individuals in one place
22/22
Other
Other capital budget
This FDNY equipment is used to respond ahead
request
with a liaison coordinator
CS
DPR
Reconstruct or
Adding toddler equipment, upgrade swings,
upgrade a park or
install new spray shower
playground
CS
DPR
Reconstruct or
new benches, plantings and monument stone
upgrade a parks
facility
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/14
DFTA
Enhance
Our seniors deserve programs that improve the
educational and
mental, physical, financial and emotional
recreational
health. It is importation we increase funding to
programs
programs that will greatly improve the quality
of life of our senior population.
2/14
DYCD
Provide, expand, or
Continue to fund Beacon Program at Middle
enhance
School 210 and expand to other district schools.
Cornerstone and
The Beacon Program provides educational,
Beacon programs
sports and mentoring opportunities outside
(all ages, including
normal classroom hours. Funding should be
young adults)
maintained or increased.
3/14
DOE
Other educational
Students of all backgrounds, including learning
programs requests
and physical disabilities should have access to a
quality education. Every effort should be made
to ensure that each school has the ability and
resources to our special needs children.
4/14
DOHMH
Create or promote
In this technologically advance environment and
programs to de-
the use of various social media platforms can
stigmatize mental
cause stress and anxiety in our children and
health problems
young adults. There should access to mental
and encourage
health programs to help individuals cope with
treatment
stress and depression.
5/14
DOHMH
Create or promote
Many veterans return to civilian life that require
programs to de-
mental health support. Issues can be dealing
stigmatize mental
with PTSD, substance abuse or difficulties
health problems
returning to civilian life. It is important that we
and encourage
have programs to help our veteran population.
treatment
6/14
NYPD
Assign additional
We must receive our fair share of Police Officers.
uniformed officers
Our district will be home to high-rise community
jail and also includes Queens Borough Hall,
Forest Park, and a number of churches,
synagogues and temples that are in need of
constant attention.
7/14
NYPD
Increase resources
Domestic violence does not discriminate.
for domestic
Anyone of any race, age, sexual orientation,
violence prevention
religion or gender can be a victim – or
programs
perpetrator – of domestic violence. It can
happen to people who are married, living
together or who are dating. It affects people of
all socioeconomic backgrounds and education
levels. We need programs to help these victims
8/14
NYPD
Assign additional
Assign Additional School Crossing Guards.
crossing guards
Assign additional school crossing guards in all
schools in Community Board 9.
9/14
DPR
Enhance park safety
Install plank fencing along Freedom Drive in
Freedom
through design
Forest Park . This fence will provide safety for
Drive
interventions, e.g.
pedestrian and also help control litter
better lighting
accumulation
(Expense)
10/14
DSNY
Expand
With additions funding DSNY can increase their
opportunities for
community service
electronic waste
collection and
disposal
11/14
DOT
Add street signage
Welcome Signs for Community Board 9. Signs
or wayfinding
for Woodhaven, Ozone Park, Richmond Hill, and
elements
Kew Gardens.
12/14
DPR
Enhance park safety
Fund Park Enforcement Patrol Unit for Forest
through more
Park. Forest Park is host to many athletic
security staff (police
facilities, recreational programs, and special
or parks
events. It also has 543 acres of forest, which
enforcement)
feature numerous hiking trails and a 4-mile
equestrian path. Our park has a high volume of
events and activities. Problems such as user
conflicts permit violations, crowd control,
vandalism, deviant behavior and other
enforcement issues are in need of attention.
Often, PEP nits are not available to respond to
Forest Parks needs due to citywide distribution
of their staff, and summer staffing of pools and
beaches. This has created a rise in misuse of and
vandalism to park facilities, damage to the
landscape, criminal activity and mischief.
13/14 DPR Forestry services,
including street tree maintenance
Fund Pruning Contract for Forest Park This is now a safety issue. Branches have fallen during park concerts and events. It is only a matter of time before someone is seriously injured or killed. The 543-acre park has large mature trees that are 150 years plus. We desperately need a PIP (Parks Inspection Project) funded along with pruning dollars.
image
14/14 DPR Provide better park
maintenance
Fund Maintenance Workers & Equipment. Maintenance workers are funded for eight months only. During the winter they are laid off. When they return they have a backlog of winter work, i.e. painting, cement work, repairs etc., that can be done during the winter.
image

