- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Bronx Community District 11 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1g3zgyzREd_Lc-uMZRbnXuFRjmuFUdd-t/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1g3zgyzREd_Lc-uMZRbnXuFRjmuFUdd-t/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Bronx Community District
11
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Bronx Community Board 11
image
Address: 1741 Colden Avenue Phone: (718) 892-6262
Email: jwarneke@cb.nyc.gov
Website: www.nyc.gov/bronxcb11
Chair: Al D'Angelo District Manager: Jeremy Warneke
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Bronx Community Board 11 continues to grow in size and diversity. From the years 2000 to 2010, the Board’s district grew by 2.3 percent. Increasingly, its population is a transient one with a large influx of immigrants from Asia, the Middle East and Latin America. We are seeing positive developments with the opening of the first Marriott Hotel in the Bronx in the Hutch Metro Center area and our first potential Metro-North train stations on East Tremont Avenue and Morris Park Avenue. Most of the neighborhoods of Community Board 11 remain desired locations in which to live, but communities such as Van Nest continue to teeter. The reasons for this, and other areas of our district, are crime and general negligence. Too often, we have landlords in these problematic areas, who don’t live in the properties they own. Too many of these landlords are concerned with short-term profits. The recession and subprime mortgage crisis of 2007 to 2009 has exacerbated this problem.
4. TOP THREE PRESSING ISSUES OVERALL
Bronx Community Board 11
image
The three most pressing issues facing this Community Board are:
Police-community relations
CB 11 has a good relationship with the 49th Precinct and wants to maintain that relationship. Many of our residents appreciate beat cops and Neighborhood Coordination Officers (NCO) program support.
Public health facilities
Overcrowding of emergency rooms is an issue in CB 11.
Quality of life issues (noise, graffiti, petty crime, etc.)
CB 11 cares about quality of life issues such as graffiti, i.e. removing and preventing it, abandoned vehicles (removing them), etc. Murals are a great deterrent to graffiti. Last year, CB 11 supported a mural through City Council funding, however, the CB was prevented from doing so this year due to a conflict of interest.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Bronx Community Board 11
image
M ost Important Issue Related to Health Care and Human Services
State of health facilities
There is a need to address overcrowding in emergency rooms.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Aside from the previous explanation, it needs to be said that the roadways of Jacobi Medical Center are and have been atrocious. The potholes tend to become craters, which make trips to and from the Medical Center campus very problematic.
Needs for Older NYs
No comments
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
3/20 HHC Renovate or upgrade an existing health care facility
Fund the resurfacing of all roadway space within the Jacobi Medical Center complex, which is plagued with major pothole problems.
Expense Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
YOUTH, EDUCATION AND CHILD WELFARE
Bronx Community Board 11
image
M ost Important Issue Related to Youth, Education and Child Welfare
Other
There is a lack of quality schools in the District, specifically high schools and middle schools.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
6/20
SCA
Renovate or
Reconstruction of bathrooms for P.S. 89. Since
980 Mace
upgrade an
approximately 2010, the bathrooms at P.S. 89
Avenue
elementary school
are in poor condition and need to be renovated.
Tiles are coming off of the walls. Urinals and
toilets are leaking. Last year's response from the
City was "OMB supports the agency's position
as follows: Unable to prioritize funding for this
project request at this time." Please help us
understand why this is the case.
7/20
SCA
Renovate or
For the past four or five years, the bathrooms at
725 Brady
upgrade an
P.S. 105 have been in poor condition and need
Avenue
elementary school
to be replaced, the fourth floor boys and girls
bathrooms in particular. The wall tiles are falling
off in some locations, and the urinals are easily
broken. We appreciate the City's ability to
accommodate part of this request in the past.
More is needed however. Last year's response
from the City was "Unable to prioritize funding
for this project request at this time." Please help
us understand why this is the case.
20/20
SCA
Provide technology
P.S. 121 has a request for 30 iPads and 6 smart
upgrade
board upgrades. Please see the attachment,
which comes from the school principal.
Expense Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
PUBLIC SAFETY AND EMERGENCY SERVICES
Bronx Community Board 11
image
M ost Important Issue Related to Public Safety and Emergency Services
Crime prevention programs
As indicated in our Top Three Pressing Issues, crime prevention programs such as the addition of murals to address graffiti and beat cops assigned to specific streets, contribute to deterring crime and improving the public safety of the district.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
We always struggle to have an NYPD patrol force size which the community needs and desires. We can never have enough lighting and security cameras in our district, and the new bike patrol in our district should be expanded as well.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
2/9 NYPD Assign additional
uniformed officers
We always struggle have the patrol force size which our community needs and desires. The commander of the 49th Precinct has tremendously increased the police presence in our community by creating public events for children such as sports and video game tournaments as well as creating and expanding the bike patrol unit. We'd like ensure that his efforts continue and expand however.
image
6/9 NYPD Assign additional
school safety officers
All schools that have portable classrooms need additional school safety officers.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Bronx Community Board 11
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Snow clearing
While Sanitation and Parks do a great job they have many other priorities throughout the City. We want to ensure our streets are covered during snow cleaning, especially tertiary streets and areas of high pedestrian traffic. There are sections of the District where there is lack of accountability among agencies regarding snow removal.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
5/9 DSNY Increase enforcement of illegal dumping laws
Reference name is self-explanatory
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Bronx Community Board 11
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Building code and/or zoning enforcement
There is a need for increased enforcement capability of the Department of Buildings.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
Our New York City Housing developments are in great need of repair.
Needs for Economic Development
No comments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
9/20
NYCHA
Renovate or
Increase lighting on the grounds of Eastchester
1130 Burke
upgrade public
Gardens. This will help deter criminal activity at
Avenue
housing
this NYCHA development.
developments
10/20
NYCHA
Renovate or
Replace all 16 building entry lobby doors at
1130 Burke
upgrade public
Eastchester Gardens. The entry lobby doors at
Avenue
housing
this NYCHA development are in badly need of
developments
repair and are not compliant with the layered
access system.
11/20
NYCHA
Renovate or
Evaluate & repair the steps in all Eastchester
1130 Burke
upgrade public
Gardens buildings' basements & entrance
Avenue
housing
stairways. Some of these steps are not secure
developments
and pose a liability.
12/20
NYCHA
Renovate or
Evaluate & repair the roofs of the Eastchester
1130 Burke
upgrade public
Gardens complex. Water leaks into apartments
Avenue
housing
as a result of the damaged roofs.
developments
Expense Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
TRANSPORTATION
Bronx Community Board 11
image
M ost Important Issue Related to Transportation and Mobility
Roadway maintenance
We have some of the largest roadway space in the Bronx. With that come roadway maintenance issues such as potholes. The Pelham Parkway area is currently being reconstructed, but this project took 30 years to go into effect. There is a need for increased traffic agents and street light sensors to change the lights at certain times of day.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/20
DOT
Other capital traffic
Community Board 11 is requesting the
improvements
construction of Bassett Avenue from McDonald
requests
Street to Pelham Parkway. This portion of
Bassett Avenue is a mapped yet unpaved street.
The reason we are requesting this is because
there is a need to alleviate traffic congestion in
the vicinity; and there will be an even greater
need in the near future. Opening Bassett Avenue
will go a long way toward allowing easier
access to Pelham Parkway and alleviating traffic
congestion on Eastchester Road and Stillwell
Avenue.
19/20
DOT
Install streetscape
Areas such as Allerton Avenue, Van Nest, and
improvements
Morris Park could benefit from improved street
scapes to help attract more people to frequent
our local merchants and bring more outside
business to the area. Improved lighting is
essential in keeping the area safe and making
the residents feel comfortable walking in the
community during the evening time.
CS
DOT
Reconstruct streets
Reconstruct the north side of Pelham Parkway
Pelham
and repave the eastern-bound roadway from
Parkway
Boston Road to Stillwell Avenue. This section of
Stillwell Ave
Pelham Parkway is in dire need of
Boston Rd
reconstruction.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Bronx Community Board 11
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Library facilities and access
There is a need to support increased funding to ensure maintenance and accessibility of library facilities.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
Parents unfortunately use the libraries in our district as daycare centers, thereby putting an unnecessary burden upon the New York Public Library by distracting it from its primary mission: servicing the entire community.
Needs for Community Boards
Community Boards are the lowest level of city government with some of the highest needs.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/20
DPR
Reconstruct or
Rehabilitate Peace Memorial Plaza, which is in
upgrade a building
need of a total renovation, including the
in a park
installation of a Veterans Memorial Wall for the
Bronx's fallen and missing in action United
States military personnel. We understand last
year's response, but we need to know how
much the renovation would cost before we
attempt to solicit funds from elected officials.
2/20
DPR
Reconstruct or
Rehabilitate Pelham Parkway from the Bronx
Pelham
upgrade a park or
River Parkway to Stillwell Avenue: bridle path,
Parkway
amenity (i.e.
drainage, re-sod and replant foliage on
Stillwell Ave
playground, outdoor
greenways, rehabilitate cross paths and
Boston Rd
athletic field)
pedestrian walks, repair and replace benches,
install sidewalks and curbs. Construct a display
gateway at Bronx River Parkway and a
monument at Williamsbridge Road.
Construction has started at the western end of
Pelham Parkway, but funds have not been
committed for the rest of the parkway.
4/20
NYPL
Create a new, or
Funding to upgrade the HVAC system for the
2147 Barnes
renovate or upgrade
Pelham Parkway-Van Nest Library. We support
Avenue
an existing public
and recognize the need and mission of the New
library
York Public Library and therefore support their
request for increased public funding for these
this branch.
8/20
DPR
Reconstruct or
Complete renovation of Eastchester Playground
Burke and
upgrade a park or
is needed, particularly the underground
Adee
amenity (i.e.
infrastructure.
Avenues
playground, outdoor
athletic field)
13/20
DPR
Reconstruct or
The restrooms at Matthews-Muliner Playground
Matthews
upgrade a building
are unsanitary and, in addition to the drinking
and Muliner
in a park
fountains, need to be renovated.
Aves
14/20
DPR
Reconstruct or
The Mazzei Playground is used daily by the
upgrade a building
children of P.S. 89. An upgrade of the play areas
in a park
and public restrooms will improve the safety of
the children and school staff.
15/20
DPR
Reconstruct or
This Ben Abrams Playground has been
upgrade a building
neglected. It, including the restrooms, needs an
in a park
upgrade.
16/20 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
The Parkside Playground public restrooms, drinking fountains and play areas are in need of complete renovation. The playground is used daily by Brightside Academy day care and children from Parkside Houses. These improvements will ensure the safety and well being of the children in the community.
image
17/20 DPR Reconstruct or
upgrade a building in a park
The cobble stone along Bronx Park between Brady and Lydig Avenues need to be replaced. The community also requests additional benches inside Bronx Park at this location.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/9
OMB
Provide more
Increase Community Board budgets to $350,000
community board
annually. This will allow community boards to
staff
perform City Charter mandates where they are
lacking.
3/9
DPR
Enhance park safety
Increase the number of PEP officers in the
through more
Bronx. Though the numbers have increased in
security staff (police
the past year or so, the Bronx still an inadequate
or parks
number of PEP (Park Enforcement Patrol)
enforcement)
officers to handle all of the problems in our
parks.
4/9
DPR
Forestry services,
Improve Forestry Services. There is always
including street tree
backlog of pruning requests in our district.
maintenance
7/9
DPR
Other park
Improve & upgrade existing greenstreet bound
Unionport Rd
maintenance and
by Unionport Rd., Van Nest Ave & the inactive
Van Nest Ave
safety requests
Victor Street side of Van Nest Park. This will
Victor Street
compliment and beautify Van Nest Park and
provide for a more attractive and enticing
entrance way to the park.
8/9
DPR
Enhance park safety
The fencing in Bronx Park along the northbound
through design
lane of the Bronx River Parkway south of
interventions, e.g.
Fordham Road/Pelham Parkway needs to be
better lighting
replaced.
(Expense)
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority Agency Request Explanation Location
image
18/20 Other Other capital budget
request
CB11 lacks a non-profit community center similar to that of a YMCA or Kips Bay Boys & Girls Club. There is no hub of resources and recreation for CB11 children to choose from when having time after school and on weekends.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
9/9
Other
Other expense
The trees surrounding the Cornerstone
budget request
Playground at 785 Pelham Parkway North need
to be pruned. There are wooden benches in the
playground area that are unsafe and need to be
removed and/or replaced. And the fencing
surrounding the playground needs to be made
much higher.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/20
DPR
Reconstruct or
Rehabilitate Peace Memorial Plaza, which is in
upgrade a building
need of a total renovation, including the
in a park
installation of a Veterans Memorial Wall for the
Bronx's fallen and missing in action United
States military personnel. We understand last
year's response, but we need to know how
much the renovation would cost before we
attempt to solicit funds from elected officials.
2/20
DPR
Reconstruct or
Rehabilitate Pelham Parkway from the Bronx
Pelham
upgrade a park or
River Parkway to Stillwell Avenue: bridle path,
Parkway
amenity (i.e.
drainage, re-sod and replant foliage on
Stillwell Ave
playground, outdoor
greenways, rehabilitate cross paths and
Boston Rd
athletic field)
pedestrian walks, repair and replace benches,
install sidewalks and curbs. Construct a display
gateway at Bronx River Parkway and a
monument at Williamsbridge Road.
Construction has started at the western end of
Pelham Parkway, but funds have not been
committed for the rest of the parkway.
3/20
HHC
Renovate or
Fund the resurfacing of all roadway space
upgrade an existing
within the Jacobi Medical Center complex,
health care facility
which is plagued with major pothole problems.
4/20
NYPL
Create a new, or
Funding to upgrade the HVAC system for the
2147 Barnes
renovate or upgrade
Pelham Parkway-Van Nest Library. We support
Avenue
an existing public
and recognize the need and mission of the New
library
York Public Library and therefore support their
request for increased public funding for these
this branch.
5/20
DOT
Other capital traffic
Community Board 11 is requesting the
improvements
construction of Bassett Avenue from McDonald
requests
Street to Pelham Parkway. This portion of
Bassett Avenue is a mapped yet unpaved street.
The reason we are requesting this is because
there is a need to alleviate traffic congestion in
the vicinity; and there will be an even greater
need in the near future. Opening Bassett Avenue
will go a long way toward allowing easier
access to Pelham Parkway and alleviating traffic
congestion on Eastchester Road and Stillwell
Avenue.
6/20
SCA
Renovate or
Reconstruction of bathrooms for P.S. 89. Since
980 Mace
upgrade an
approximately 2010, the bathrooms at P.S. 89
Avenue
elementary school
are in poor condition and need to be renovated.
Tiles are coming off of the walls. Urinals and
toilets are leaking. Last year's response from the
City was "OMB supports the agency's position
as follows: Unable to prioritize funding for this
project request at this time." Please help us
understand why this is the case.
7/20
SCA
Renovate or
For the past four or five years, the bathrooms at
725 Brady
upgrade an
P.S. 105 have been in poor condition and need
Avenue
elementary school
to be replaced, the fourth floor boys and girls
bathrooms in particular. The wall tiles are falling
off in some locations, and the urinals are easily
broken. We appreciate the City's ability to
accommodate part of this request in the past.
More is needed however. Last year's response
from the City was "Unable to prioritize funding
for this project request at this time." Please help
us understand why this is the case.
8/20
DPR
Reconstruct or
Complete renovation of Eastchester Playground
Burke and
upgrade a park or
is needed, particularly the underground
Adee
amenity (i.e.
infrastructure.
Avenues
playground, outdoor
athletic field)
9/20
NYCHA
Renovate or
Increase lighting on the grounds of Eastchester
1130 Burke
upgrade public
Gardens. This will help deter criminal activity at
Avenue
housing
this NYCHA development.
developments
10/20
NYCHA
Renovate or
Replace all 16 building entry lobby doors at
1130 Burke
upgrade public
Eastchester Gardens. The entry lobby doors at
Avenue
housing
this NYCHA development are in badly need of
developments
repair and are not compliant with the layered
access system.
11/20
NYCHA
Renovate or
Evaluate & repair the steps in all Eastchester
1130 Burke
upgrade public
Gardens buildings' basements & entrance
Avenue
housing
stairways. Some of these steps are not secure
developments
and pose a liability.
12/20
NYCHA
Renovate or
Evaluate & repair the roofs of the Eastchester
1130 Burke
upgrade public
Gardens complex. Water leaks into apartments
Avenue
housing
as a result of the damaged roofs.
developments
13/20
DPR
Reconstruct or
The restrooms at Matthews-Muliner Playground
Matthews
upgrade a building
are unsanitary and, in addition to the drinking
and Muliner
in a park
fountains, need to be renovated.
Aves
14/20
DPR
Reconstruct or upgrade a building in a park
The Mazzei Playground is used daily by the children of P.S. 89. An upgrade of the play areas and public restrooms will improve the safety of the children and school staff.
15/20
DPR
Reconstruct or
This Ben Abrams Playground has been
upgrade a building
neglected. It, including the restrooms, needs an
in a park
upgrade.
16/20
DPR
Reconstruct or
The Parkside Playground public restrooms,
upgrade a park or
drinking fountains and play areas are in need of
amenity (i.e.
complete renovation. The playground is used
playground, outdoor
daily by Brightside Academy day care and
athletic field)
children from Parkside Houses. These
improvements will ensure the safety and well
being of the children in the community.
17/20
DPR
Reconstruct or
The cobble stone along Bronx Park between
upgrade a building
Brady and Lydig Avenues need to be replaced.
in a park
The community also requests additional
benches inside Bronx Park at this location.
18/20
Other
Other capital budget
CB11 lacks a non-profit community center
request
similar to that of a YMCA or Kips Bay Boys &
Girls Club. There is no hub of resources and
recreation for CB11 children to choose from
when having time after school and on
weekends.
19/20
DOT
Install streetscape
Areas such as Allerton Avenue, Van Nest, and
improvements
Morris Park could benefit from improved street
scapes to help attract more people to frequent
our local merchants and bring more outside
business to the area. Improved lighting is
essential in keeping the area safe and making
the residents feel comfortable walking in the
community during the evening time.
20/20
SCA
Provide technology
P.S. 121 has a request for 30 iPads and 6 smart
upgrade
board upgrades. Please see the attachment,
which comes from the school principal.
CS
DOT
Reconstruct streets
Reconstruct the north side of Pelham Parkway
Pelham
and repave the eastern-bound roadway from
Parkway
Boston Road to Stillwell Avenue. This section of
Stillwell Ave
Pelham Parkway is in dire need of
Boston Rd
reconstruction.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/9
OMB
Provide more
Increase Community Board budgets to $350,000
community board
annually. This will allow community boards to
staff
perform City Charter mandates where they are
lacking.
2/9
NYPD
Assign additional
We always struggle have the patrol force size
uniformed officers
which our community needs and desires. The
commander of the 49th Precinct has
tremendously increased the police presence in
our community by creating public events for
children such as sports and video game
tournaments as well as creating and expanding
the bike patrol unit. We'd like ensure that his
efforts continue and expand however.
3/9
DPR
Enhance park safety
Increase the number of PEP officers in the
through more
Bronx. Though the numbers have increased in
security staff (police
the past year or so, the Bronx still an inadequate
or parks
number of PEP (Park Enforcement Patrol)
enforcement)
officers to handle all of the problems in our
parks.
4/9
DPR
Forestry services,
Improve Forestry Services. There is always
including street tree
backlog of pruning requests in our district.
maintenance
5/9
DSNY
Increase
Reference name is self-explanatory
enforcement of
illegal dumping laws
6/9
NYPD
Assign additional
All schools that have portable classrooms need
school safety
additional school safety officers.
officers
7/9
DPR
Other park
Improve & upgrade existing greenstreet bound
Unionport Rd
maintenance and
by Unionport Rd., Van Nest Ave & the inactive
Van Nest Ave
safety requests
Victor Street side of Van Nest Park. This will
Victor Street
compliment and beautify Van Nest Park and
provide for a more attractive and enticing
entrance way to the park.
8/9
DPR
Enhance park safety
The fencing in Bronx Park along the northbound
through design
lane of the Bronx River Parkway south of
interventions, e.g.
Fordham Road/Pelham Parkway needs to be
better lighting
replaced.
(Expense)
9/9 Other Other expense budget request
The trees surrounding the Cornerstone Playground at 785 Pelham Parkway North need to be pruned. There are wooden benches in the playground area that are unsafe and need to be removed and/or replaced. And the fencing surrounding the playground needs to be made much higher.
image

