- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 16 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1DTRzn-orX79-frtu3ne9K6dp-LsKZ4qR/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1DTRzn-orX79-frtu3ne9K6dp-LsKZ4qR/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
16
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 16
image
Address: 444 Thomas S. Boyland Street, Room 103 Phone: (718) 385-0323
Email: bk16@cb.nyc.gov
Website: www1.nyc.gov/site/brooklyncb16/index.page
Chair: Genese Morgan District Manager: Viola Greene-Walker
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Bordered on the north by Broadway, on the east by Van Sinderen Avenue, on the south by L.I.R.R. and on the west by East 98th Street, East New York Avenue, Ralph Avenue, Atlantic Avenue and Saratoga Avenue, Community District 16 is located in East Brooklyn and encompasses the neighborhoods of Ocean Hill and Brownsville.
According to the American Community Survey, Ocean Hill-Brownsville has a population of 125,747 which is an increase from the 2010 census that recorded the population at 86,468. Approximately 76% of the population is Black/African American, 20% of Hispanic Origin, 1% White, 1% Asian, and 2% other. There are 29.1% of households with children under 18 years old, and 10% of the population is age 65 years and older. Many of our residents are disadvantaged from an early age, due to a lack of support and resources in our local schools and lack of access to early intervention services. Our students have some of the lowest attendance rates in the City and the overwhelming majority are not proficient in reading and math. This translates into low graduation rates, leaving many residents in our community unprepared for the job market. More than half of the population receives income support. Unemployment is an acute problem in our community where 18.3%% of the civilian labor force was unemployed on average (ACS 2016).. The issue is severely impacting our young people, with unemployment rates for 20 to 24 years old at 28 percent. Males are experiencing higher unemployment rates in the district than females, with rates of 19 and 11 percent respectively. Job training and placement programs are needed to combat this problem. High poverty creates a host of other issues related to affordable housing, health, childcare and crime. As we move forward to address the issue of homelessness, permanent housing is needed, not homeless shelters. The housing must be affordable to residents of the community where the median household income is $27,512.
According to the New York City Department of Health and Mental Hygiene, residents of Ocean Hill-Brownsville experience more barriers to health care access than those in New York City overall, with nearly 3 in 10 without a regular doctor. Many of our residents are not eating healthy meals because they lack the income and access to healthy foods. Heart disease, hypertension, diabetes, obesity, asthma, HIV and AIDS, mental health, and maternal and infant health are prevalent in our community. Gun violence involving young adults is an increasing problem in our community. Unreported crimes and injuries from street justice continue to negatively impact on our district. Many of the obstacles our community face are interrelated and cannot be solved in isolation. We need collaboration of both the public and private sectors to address the many issues our community residents have.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 16
image
The three most pressing issues facing this Community Board are:
Affordable housing
Permanent and affordable housing, not homeless shelters, are needed to meet the increasing needs of our senior citizens, families, and single adults with minimum wage jobs. We also need permanent and affordable housing for young adults whose income is below or above a certain income threshold - too much for subsidized housing but not enough for market rate housing. The price of a house is unaffordable to many of our residents. Even with government subsidies, many of our hardworking families find it difficult to attain the American dream of owning their own home because their income has not advanced with the cost of living. Rental housing costs are also skyrocketing, thus making it difficult for families and single adults to maintain permanent housing.
Health care services
Ocean Hill-Brownsville is part of the Central Brooklyn community where, according to the Department of Health and Mental Hygiene, its residents experience more barriers to health care access than those in New York City overall, with nearly 3 in 10 without a regular doctor. According to the New York City Department of Health and Mental Hygiene's Community Health Profiles 2015, 37% of Community District 16's residents live below the Federal Poverty level and it is the poorest neighborhood in Brooklyn and the seventh-poorest in neighborhood in New York City. In Community District 16, the rate of preterm births, a key driver of infant death, is the second highest in the city, the teen birth rate of 13.3% is higher than the Brooklyn rate of 8.8% and the citywide rate of 9%. We need the New York City Department of Health and Mental Hygiene to continue its partnership with the various community- based agencies to stem the tide of maladies that are consuming our community and expand obstetric, pediatric, geriatric, mental health, HIV and AIDS services, mental health, and maternal and infant health services.
Youth and children’s services
Residents under the age of 18 represent 29.1% of Community District 16's population (ACS 2016). During the 2018 testing period, results on the New York State ELA test for 4,625 students in grades 3 to 8 in School District 23 reveal that 37.8% are on Level 1, 36% on Level 2, 19.2% on Level 3 and 7.1% on Level 4. Results of the Math test for 4,509
students in grades 3 to 8 in School District 23 reveal that 49.9% are on Level 1, 29.6% on Level 2, 13.9% on Level 3
and 6.6% on Level 4.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 16
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
Poverty is a severe issue facing our community that impacts health and a host of other quality of life measures. Approximately 29% of residents have incomes below the New York City government poverty threshold (Source:PUMA). Poverty rates in Community District 16 are particularly severe among families with children where
43.5 percent are living in poverty. These rates rise even further for single mothers with children where poverty rates are 51.7 percent. It is important to note that this family type accounts for nearly 60 percent of the families within the district (Source: 2016 ACS). Living in poverty limits healthy lifestyle choices and makes it difficult to access health care and resources that can promote health and prevent illness. It is imperative that these families receive the much needed income support services such as cash assistance, medicaid and SNAP benefits; as well as job training and job placement.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Community District 16, which is located in Central Brooklyn and includes the neighborhoods of Ocean Hill and Brownsville, has for many decades been marginalized in receiving much needed health care and wellness services which has perpetuated the inability of local residents in improving their overall health. According to the 2015 Community District Health Profile released by the New York City Department of Health and Mental Hygiene, some of these challenges include low income attainment, compromised housing quality, air pollution, preterm births, absenteeism, violence, incarceration, substance abuse, chronic illnesses such as stroke, diabetes, hypertension, HIV and AIDS, and a lack of physical activity and access to health foods , and require intervention by New York City and health care institutions. The United States Office of Disease Prevention and Health Promotion - Healthy People 2020 report lists economic stability as a social determinant of health and the Center for Disease Control (CDC) reports that anti-poverty programs such as the Earned Income Tax Credit (EITC) help keep children and families above the poverty rate. The main purpose of the EITC is to incentivize people to work while also helping to reduce poverty, and also contributes to positive health outcomes for infants and mothers; and which impacts physical and mental health, infant mortality and low-birth weight rates. Community District 16 has the 2nd highest rate of pre-term births and infant mortality. Furthermore, preventative health care services and outreach increase education and reduce emergency room visits amongst our pediatric, adult and geriatric health care populations in Community District 16. In Central Brooklyn, 3 out of 10 residents are without a regular doctor and many of our residents are underinsured. According to the US Census Bureau's American Community Survey 5 year estimates for 2012-2016, zip codes 11212and 11233 respectively, approximately 11% of individuals have no health insurance. Other services such as mental health, physical activity and nutrition are important in keeping these residents in the community well. Income, housing, education, violence and access to health care have been adversarial issues in Community District 16 for decades and all are factors of the social determinants of health which continue to impact the lives of our residents. We need the New York City Department of Health and Mental Hygiene to continue its partnership with other levels of government, health care institutions, and the various community-based organizations to expand access to obstetrics and education to promote prenatal care, Lamaze, breastfeeding, and doulas which are positive interventions to maternal and infant health. We need health insurance companies to continue their outreach in the community to enroll individuals and families in health plans. We need assistance for adults who are experiencing financial hardship due to escalating costs of prescription medication. Our senior citizens, in particular, are finding it most difficult o pay out-of-pocket costs for prescriptions. We need nutrition education outreach in the community to identify and assist persons who are not eating properly and are at-risk of becoming obese and developing circulatory and respiratory conditions. We need services to combat these health challenges such as asthma and diabetes which are on the rise in our community. We also need programs to outreach to our adolescents and
teenage residents to educate them about reproductive health and services; consequences of engaging in premarital sex, teenage pregnancy prevention, and awareness, safety and services regarding increased cases of human trafficking. It is important that the New York City Department of Health and the Brownsville Neighborhood Health Action Center continue its work and support the residents of Community District 16 to achieve neighborhood health equity.
Needs for Older NYs
According to the American Community Survey, approximately 12% of our population is over the age of 62. A large number of our seniors are low-income, live alone, and reside in public housing for the elderly. For older persons at risk of losing self-sufficiency, senior centers are an entry point to an array of services that will assist them as they age in place. We need continued funding of our senior centers to enable them to offer a wide range of health, education, recreation, volunteer and other social interaction opportunities for their participants that enhance dignity, support independence, and encourage community involvement. Most importantly, the centers provide a social environment conducive to the development of a social support system reducing loneliness and depression. Expansion of the Meals-on-Wheels Program is needed for many of our seniors who live alone and whose income is insufficient to purchase ingredients for nutritional meals. Many of our elderly and infirm adults who live alone need escort services to accompany them to medical appointments and grocery shopping. They also need assistance with personal care, housekeeping, and financial management as they strive to live independently in their own homes.
Needs for Homeless
Community District 16 is over saturated with homeless housing. There are 12 homeless shelters funded by the Department of Homeless Services, several shelters for victims of domestic violence, and a number of three quarter houses. In addition, rooms are being rented in 4 hotels in the district to temporarily house homeless individuals and families. Families and individuals become homeless due to a variety of circumstances, including loss of job, instances of substance abuse, domestic violence, eviction, or unsafe building conditions. Because the shelter system should never be considered a home, programs such as CITYFHEPS and HRA HOME-Tenant-Based Rental Assistance (TBRA) are needed to assist this population to move into permanent housing. Homeless prevention programs such as Homebase are also needed to assist those at risk of losing affordable permanent housing by providing monetary assistance and linking them to needed resources such as job training, childcare, and substance abuse programs.
Community-based social service agencies and health care organizations must receive sufficient funding to give individuals and families the long term support that they need.
Needs for Low Income NYs
According to our district profile published by the Department of City Planning, 29% of our residents have incomes below the NYC government poverty threshold. Our low-income and vulnerable residents have less assets and often face major challenges meeting daily living expenses for housing, food, clothing, and health care. It is imperative that resources be provided to this group to enhance their quality of life. Low-income families experience severe hardships whether they rely on cash assistance, work or a combination of both. These families need institutional support in the form of education, financial literacy job training, fair wages, child care, parenting skills, and health care.
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
8/22
DOHMH
Other programs to
According to the New York City Department of
address public
Health and Mental Hygiene, the rate of preterm
health issues
births in Community District 16, a key driver of
requests
infant death, is the second highest in the city.
Maternal and infant health services are needed
to promote healthy pregnancies, positive birth
outcomes, and healthy infant growth and
development. The long-term goal of maternal
and infant health programs is to reduce
maternal and infant morbidity and mortality.
13/22
DOHMH
Create or promote
Gun violence is very prevalent in our
programs to de-
community. When gun violence ends a life, it
stigmatize mental
also impacts the lives of survivors (families and
health problems
friends) who struggle to cope with the lose of a
and encourage
loved one. Preventive and treatment programs
treatment
are needed for all ages.
14/22
DOHMH
Create or promote
Eating well is important for good health. A
programs for
healthy diet helps prevent many chronic
education and
diseases and conditions, such as obesity, type 2
awareness on
diabetes, hypertension, stroke, some cancers,
nutrition, physical
and heart disease. Expansion of outreach and
activity, etc.
educational programs such as Healthy Living is
needed to improve nutrition and physical
activity for all ages. In addition, programs such
as Shop Healthy NYC are needed to increase
access to healthy foods in the neighborhood
retailers. Outreach programs such as the
Newborn Visiting Program provides vital
resources to the community and needs
expansion.
15/22
DFTA
Increase
Many of our elderly and homebound residents
transportation
live alone. Without this service, they would not
services capacity
be able to get to their medical appointments
and shop for groceries.
16/22
DFTA
Enhance home care
Many of our seniors live alone and are in need
services
of assistance to perform activities of daily living
in their home such as bathing, feeding, and or
housekeeping.
17/22 DHS, HRA
Other homelessness prevention program request
According to the American Community Survey, about a third of families in Community District 16 are facing poverty. Many of these families are at risk of losing affordable housing for a variety of reasons, such as minimum wage jobs, temporary unemployed due to illness, and lost of job. Programs such as Homebase are needed to provide families with monetary assistance and resources to remain in permanent housing.
image
18/22 DFTA Increase home
delivered meals capacity
Many of our low-income elderly residents who live alone do not have sufficient income to shop for groceries and prepare daily nutritional meals. An expansion of the Meals-on-Wheels program will enable this population to eat more healthy and frequently.
image
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 16
image
M ost Important Issue Related to Youth, Education and Child Welfare
Youth workforce development and summer youth employment
Residents under the age of 18 represent 29.1% of Community District 16. Presently, the unemployment rate in the district is approximately 13.5% and has been higher at other times. Youth workforce development is extremely important to the Ocean Hill-Brownsville community where poverty is prevalent and the rate is 35.3%. During their formative years, youths can benefit a great deal from workforce development programs that help to reinforce classroom learning, offer exposure to new knowledge, technical and social skills, and help youths develop an attitude toward participation, teamwork and productivity. Summer Youth Employment Programs are early introductions to the world of work and help youth gain valuable work experience with transferrable skills that our youth need to develop good work habits and sustain employment. By developing good work habits and skills at an early age, our youth are more likely to continue this trend as they progress toward adulthood.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
School District 23 has one of the lowest attendance record in the city. We are requesting that the Department of Education provide additional resources to address the truancy problem. The Department of Education should work with community members to determine the root cause of truancy in the district and develop innovative solutions that serve our students before they become truant. During the 2018 testing period, results on the New York State ELA test for 4,625 students in grades 3 to 8 in School District 23 reveal that 37.8% are on Level 1, 36% on Level 2, 19.2% on Level 3 and 7.1% on Level 4. Results of the Math test for 4,509 students in grades 3 to 8 in School District 23 reveal that 49.9% are on Level 1, 29.6% on Level 2, 13.9% on Level 3 and 6.6% on Level 4. Nearly a third of the district's young people (18 to 24 years old) lack a high school diploma or equivalency, 50 percent more than Brooklyn as a whole. Another third have obtained a high school diploma or GED. Only five percent have completed a four year college degree. As New York City's economy becomes increasingly specialized, it is crucial for our residents to be prepared to compete for quality jobs. We are requesting that the New York City Department of Education further its investment in career and technical education and college readiness programs. Our schools will require highly skilled teachers, guidance counselors, and curricula incorporating STEM which will help place students on a college bound educational path. School children also need an environment that is conducive to learning, therefore, we need facility upgrades to our school buildings to support the use of technology, elevators for ADA compliance, and electrical wiring to support the use of air conditions. To ensure that youth in Community District 16 have the greatest opportunities for a comprehensive education, we also need funding to support civic engagement, financial literacy learning, and music and arts in our schools, and youth programs. It is important that the City of New York and the New York City Department of Education support the educational needs of our young residents in Community District 16 to achieve neighborhood equity in education..
Needs for Youth and Child Welfare
Approximately 16 percent of the district's population are children. Day care and headstart programs play a crucial role in supporting young children's development, learning and preparation for both school and life success. Early care and education programs foster children's healthy and positive cognitive, physical, social and emotional development. Early childhood education programs are also critical to parental employment stability. A number of grandparents and other relatives find themselves serving as parents for children whose own parents are unable to care for them because of substance abuse or incarceration. Many of these relatives need financial support to provide food, shelter and clothing to these children. Poverty, parental alcoholism, family instability, overcrowding and abusive conditions in the home, incarceration of a parent, or death of a parent render many of our children at- risk of juvenile delinquency. We need programs for at-risk youth and preventive services; i.e., juvenile justice, health education, sports, technology, cultural arts and design, workforce and entrepreneurship.
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
4/40
SCA
Renovate or
Upgrade student bathrooms, library and
985
upgrade a middle or
auditorium (curtains, sound system and air
Rockaway
intermediate school
condition) to provide a safe and healthy
Avenue
environment for students and staff at Kappa V.
11/40
SCA
Renovate or
Air circulation in the auditorium at Mott Hall
210 Chester
upgrade a middle or
Bridges Academy is poor and it is extremely
Street
intermediate school
uncomfortable during warm weather.
Installation of an air condition unit in the
auditorium is much needed to improve air
circulation.
17/40
SCA
Renovate or
Renovate all bathrooms at the Riverdale
upgrade an
Community School, located at 76 Riverdale
elementary school
Avenue to provide a safe and healthy
environment for students and staff.
18/40
SCA
Renovate or
A complete renovation of the cafeteria is
upgrade an
needed to provide better accommodations for
elementary school
the student body.
19/40
SCA
Renovate interior
Upgrading of electrical wiring will allow for
building component
safer and more efficient use of electrical power
with the ever increasing use of electrical
equipment such as air condition units,
computers and other equipment..
21/40
SCA
Renovate or
The cafeteria and auditorium at P.S. 137 are in
upgrade an
need of renovation to improve lighting and
elementary school
seating for the student body.
22/40
SCA
Renovate or
A complete renovation of the cafeteria in this
upgrade an
very old building is needed to provide better
elementary school
accommodation for the student body.
23/40
SCA
Renovate interior
Renovate all school buildings in District 23 to
building component
make them ADA compliant.
38/40
SCA
Renovate or
The auditorium at P.S. 41 is dimly lit. Upgrading
upgrade an
of the lighting will provide more illumination
elementary school
during performances and meetings.
39/40
SCA
Renovate or
Renovate all bathrooms at Brownsville
upgrade a middle or
Collaborative Middle School, located at 85
intermediate school
Watkins Street to provide a safe and healthy
environment for students and staff.
40/40 SCA Renovate or upgrade an elementary school
A complete renovation is needed for the cafeteria and auditorium to provide better lighting and seating for the student body.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
4/22
DYCD
Provide, expand, or
Summer youth employment programs are early
enhance the
introductions to the world of work and help to
Summer Youth
build skills that our youth need to develop good
Employment
work habits and sustain employment.
Program
9/22
DOE
Other educational
For various reasons, not every student is
programs requests
prepared to attend college. Therefore, they
should have the option to learn a skilled trade
while in high school that will equip them to
compete in the job market. Career and Technical
Education Programs will prepare our high
school students for entry level employment in a
specific occupation and is aligned with
business/industry standards.
10/22
DYCD
Provide, expand, or
Many of our impoverished families lack financial
enhance
resources to provide structured activities for
Cornerstone and
their children. We need continued funding of
Beacon programs
our Cornerstone and Beacon programs which
(all ages, including
provide a range of free educational, cultural and
young adults)
recreational resources to our children and
youth.
image
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 16
image
M ost Important Issue Related to Public Safety and Emergency Services
Youth crime
Youth violence is a growing concern in our community where poverty, family instability and unemployment provide fertile ground for its growth. Gangs are perpetuating youth on youth violence that result in injury and death. Far too many young lives are lost from street justice. Collateral damage inflicted by gun violence impacts the victim's family, friends and community.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Community District 16 has historically been known as an area of New York City with high rates of crime and incidents of violence. As a result, the New York Police Department and the 73rd Precinct have participated in anti- crime programs such as "Stop and Frisk" and "Operation IMPACT" to help mitigate incidents of crime and violence to improve overall safety within the community. In the years following the launch of these programs, they were criticized for being divisive and lacking proper supervision for assigned officers who were new police academy graduates. The New York Police Department has taken steps to phase out these programs and return to "Neighborhood-Based Policing" with a program known as "Build the Block" which is a comprehensive crimefighting strategy that assigns Neighborhood Coordination Officers (NCO) to specific areas of the community for better community engagement with local residents. Community District 16 was a pilot community and has been participating in this program since 2016. In the last several years, the New York Police Department and the 73rd Precinct have reported reduced incidents of crimes and more recently some historic lows. Although crimes are decreasing, we continue to need police presence on our streets, in subways, along commercial corridors, around our schools, and in our New York City Housing Authority buildings to combat incidents of crime, and support the Police Department continuing to connect with the community and building relationships. However, as a result of prior experiences with the Police Department, there are still some unreported incidents of crimes from street justice. In addition, some law-abiding citizens are reluctant to report crimes because they are distrustful of the police and their ability to reduce crimes. Therefore, we are asking that police officers continue to receive frequent training in community engagement, cultural sensitivity and mental health first aid response to incidents of opioid overdose. In addition, we request that police officers be equipped with body cameras for better transparency of incidents of policing. According to the most recent data from the New York City Police Department's CompStat report (10/14/19 - 10/20/19), crimes in the seven (7) major categories in Ocean Hill-Brownsville decreased by 13.85% compared to the same period in 2018. It is important that the New York City Police Department continue to make improvements in policing that respect the humanity of our residents and visitors, and deploy resources efficiently to achieve neighborhood equity.
Needs for Emergency Services
Community District 16 has a large concentration of New York City Housing Authority buildings as well as privately- owned elevated buildings which house many families in close proximity to each other. It is imperative that an adequate number of well trained firefighters are assigned to the firehouses in Community District 16 and they be provided with the necessary firefighting equipment to respond to fires, medical and other emergencies.
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
7/22 NYPD Provide resources to
train officers, e.g. in community policing
It is imperative that police officers assigned to the 73rd Precinct continue to receive frequent training in community engagement, cultural sensitivity, and mental health first aid to better equip them to patrol the community.
image
12/22 FDNY Other FDNY facilities
and equipment requests (Expense)
A Forcible Entry Door is requested for Battalion 44 which will enable ongoing training of firefighters in the method of opening locked doors in the event of a fire, especially in multiple dwelling buildings.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 16
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
Ongoing housing construction is bringing new families to the community. We need more Sanitation personnel to pick up garbage and clean our streets. Because of limited onsite storage, garbage from several of our schools and New York City Housing Authority buildings is placed on the sidewalks daily. We need daily pick up of this garbage which is unsightly and attracts rodents. Community District 16 continues to remain at the bottom for recycling. We need ongoing community outreach to educate our residents about the benefits of recycling.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
During heavy rainfall, flooding and ponding conditions are common at a number of heavily trafficked locations throughout the district. We need regular maintenance of our catch basins to remove obstructions and ensure that water continues to flow freely and not create ponding conditions. In 2015, the Department of Environmental Protection began installing over 200 bioswales, also known as rain gardens, throughout the district to reduce combined sewer overflow discharges into New York City's waterbodies. We encourage these green infrastructure improvements which are intended to reduce flooding, environmental and health impacts; however, because of the dimensions of the rain gardens, they also collect windblown litter and electronic and other illegally dumped debris. Furthermore, when the greenery is not properly maintained and pruned, they obstruct street view and pose a safety concern. We are in need of regular maintenance of our catch basins to remove obstructions and ensure that water continues to flow, and regular pruning and cleaning of rain gardens. We need ongoing community outreach to educate our residents about the benefits of rain gardens and the residents' assistance with maintenance. It is important that the NYC Department of Sanitation and Department of Environmental Protection make service level improvements as a result of these adverse concerns and deploy resources efficiently to achieve neighborhood equity and not overburden area residents..
Needs for Sanitation Services
As new housing construction bring new families to the community, we need more Sanitation personnel to pick up garbage and clean our streets. The most recent scorecard ratings state that our streets are 98% acceptably clean. However, areas in the vicinity of New York City Housing Authority buildings and schools continue to be problematic because garbage is placed on the sidewalks on a daily basis after the collection truck makes its regular pick up.
When this occurs, litter is strewn about the sidewalk and streets . Illegal dumping in vacant lots and on sidewalks in front of vacant buildings create unsightly, unhealthy and hazardous conditions. We need regular Sanitation patrol of chronic dumping locations to apprehend violators. According to the Department of Sanitation, 6.1 tons of metal, glass and plastic were recycled in Fiscal Year 2019 in Community District 16. This was the lowest in Brooklyn. We need ongoing community outreach to educate our residents about the benefits of recycling.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation Location
11/22
DEP
Clean catch basins
Windblown litter as well as household
electronics and furniture are deposited in our
many rain gardens on a daily basis. Additional
manpower is needed to clean the rain gardens
more frequently.
21/22
DEP
Clean catch basins
When litter and debris clog our catch basins,
flooding and ponding occur during heavy
rainfall at heavily trafficked locations which
makes it difficult and unsafe for pedestrian
crossing. Periodic cleaning of our catch basins is
required.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 16
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
Households that pay more than 30% of their income for housing, including utilities are considered cost burdened because they may have difficulty paying non-housing needs such as food, clothing, transportation, child care and medical care. According to the American Community Survey 2011-2016 five year estimates, 51% of households in Community District 16 spend 35% or more of their income on rent. Decent housing that is affordable to working and low income families and seniors is in short supply in our community. As the cost of housing continues to soar and income remains stagnant, residents are being pushed out of their homes and onto the streets. We need affordable housing and rent subsidy programs to provide stability for this vulnerable population.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
No comments
Needs for Housing
The availability of quality housing in Community District 16 is continuing to diminish due to the age and condition of our public housing buildings and upgrades needed to keep these units available to low income families. For residents not residing in public housing, the need for permanent affordable housing, not homeless shelters, continues to be a high priority for our community to meet the increasing needs of our senior citizens, families, and single adults with income that ranges from fixed and/or minimum wage and above, but is not sufficient to afford other housing opportunities. There is a growing need for affordable housing for young adults whose income is below or above certain thresholds - not enough for market rate housing but too much for subsidized housing. The lack of availability of these units forces these young adults out of the community and away from their families. The price of a house is unaffordable for many of our residents. Even with government subsidies, many of our hardworking families find it difficult to attain the American dream of owning their own home because their income has not increased with the cost of living. Rental housing costs are also skyrocketing, thus making it difficult for families and single adults to maintain permanent housing within New York City or Community District 16. We need the New York City Department of Housing Preservation and Development to provide funding to build truly affordable housing on City-owned land inclusive of a distribution of units that can house our seniors, young adults and families at affordable income levels; and also to the greatest extent possible offer equitable features through mixed use spaces and facilities to replace neighborhood conveniences that have been lost due to the high costs of real estate and taxes, but are needed in order to sustain a good quality of life for residents. In addition, we need the City to continue providing assistance to residents who are interested in homeownership and/or need to make repairs to their homes to make the homes livable into the foreseeable future.
Needs for Economic Development
Since the early 1970s, Ocean Hill-Brownsville has experienced extreme disinvestment along its commercial corridors of Pitkin Avenue, Mother Gaston Boulevard, Saratoga Avenue, Fulton Street, Rockaway Avenue, and Belmont Avenue. The most glaring impact is along Belmont Avenue where there are a number of vacant storefronts or marginal month-to-month tenants. We need both private and public investments in these commercial corridors where our local residents can purchase healthy foods, clothing, furniture, dine out, and engage in cultural enrichment activities. We need the New York City Department of Small Business Services to support our local residents with workforce placements, small business development, and Minority and Women-Owned Business (M/WBE) certifications to address the issues of commercial vacancies, availability of diverse goods and services, and contracting with city agencies. Additionally, we appeal to the New York City Department of Consumer Affairs to help with small business outreach and education. We need the New York City Department of Housing Preservation and Development and the New York City Economic Development Corporation to market City-owned parcels and work with private owners who are in need of financial assistance to develop their properties to better serve the
community. Given that small businesses are essential to local employment, support from these City agencies will help stimulate investment which will create economic opportunities for local residents and begin to address a persistent and acute problem of unemployment in Community District 16 across all demographics. This issue is severely impacting our young people with unemployment rates for 20-24 years old at 28 percent, compared with 20 percent for Brooklyn. Males in the district are experiencing higher unemployment rates in the district than females, with rates at 19 and 11 percent respectively. In order to achieve neighborhood equity, we call on the City to implement and expand job training and placement programs to combat high unemployment rates and concentrate resources available through the Summer Youth Employment Program, Workforce 1 and other programs that provide workforce development services. Furthermore, making improvements to the district's schools and incorporating Career and Technical Education will also help to address this problem by insuring that our young people are prepared for opportunities in the job market..
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
14/40
NYCHA
Install security
Residents of Howard Houses have reported that
cameras or make
crimes in the buildings and on the grounds have
other safety
been increasing in recent years. Installation of
upgrades (Capital)
CCTV cameras will help to deter crime and
enhance the quality of life for its residents.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/22
HPD
Provide more
The supply of decent affordable housing for
housing for
extremely low and low income households is
extremely low and
decreasing. As a result, many reside in
low income
substandard housing that impacts their health.
households
Others are forced into homeless shelters.
5/22
SBS
Other expense
A comprehensive one stop small business center
workforce
to include M/WBE programs and technical
development
assistance to support local businesses and
requests
entrepreneurs is needed. .
6/22
EDC
Expand programs to
M/WBE resources and technical assistance are
support local
needed within the district for small business
businesses and
owners who are struggling to compete with
entrepreneurs
more established businesses in the City of New
York.
19/22
SBS
Support
There are a number of vacant storefronts along
Belmont Ave
development of
our commercial corridors where property
Rockaway Ave
local Storefront /
owners need financial support to renovate.
Mother
Facade
Gaston Blvd
Improvement
Program
20/22
SBS
Support
There are a number of stores that need facade
Pitkin Ave
development of
improvement and property owners are in need
Howard Ave
local Storefront /
of financial assistance.
Mother
Facade
Gaston Blvd
Improvement
Program
TRANSPORTATION
Brooklyn Community Board 16
image
M ost Important Issue Related to Transportation and Mobility
Accessibility (ADA related compliance and infrastructure enhancements)
Community District 16 is a transit rich community with no accessible subway stations for persons with physical disabilities in the district. Public transportation is the only source of transportation for many of our residents who are economically disadvantaged and lack the resources to access alternative modes of transportation to travel outside of the community. Many of these individuals are single mothers with infants, handicapped and elderly residents who require an elevator to access the platform. This lack of compliance with the American Disability Act threatens the quality of life for these vulnerable residents who seek independence. This disparity adds to the amount of time it takes to travel and/or may increase travel costs for these already economically disadvantaged individuals to travel by an alternative mode; i.e., car service. There are 11 elevated and one subterranean (Rockaway Avenue on the "IND") train stations that are not accessible to the physically challenged, including Halsey Street, Chauncey Street and Broadway Junction station on the "IND" line, Atlantic Avenue, Sutter Avenue, Livonia Avenue and New Lots Avenue on the "L" line, and the Sutter-Rutland Road, Saratoga Avenue, Rockaway Avenue and Junius Street on the "IRT" line. We call upon the New York City Metropolitan Transit Authority to appropriate needed funds to install elevator access to stations throughout Community District 16 and construct a connecting passageway between the "L" and "IRT" lines at Junius Street and Livonia Avenue to enable commuters to freely transfer between stations. The Broadway Junction station has a very high volume of traffic because of its connections to 3 train lines and 5 bus lines. The station has a series of steps that prevent the physically challenged from using this facility. The East New York station on the Long Island Railroad is in need of updating. Cameras are in place on the platforms and should also be placed in the tunnel connecting the stairwells leading to the service roads of Atlantic Avenue, and additional lighting is also needed. Presently, there is no wheelchair access on the westbound platform. We are requesting that a permanent ramp be installed to provide access for wheelchair bound passengers who now must travel to the Atlantic Avenue terminal to disembark. Community District 16 is becoming increasingly denser and there are more people using the subway. Several of our transit stations have multiple entrances that could be used by commuters but are not currently accessible. We are requesting that NYC Transit make these entrances accessible to alleviate commuter congestion at train entrances, increase safety, offer neighborhood conveniences, and add to the quality of life for residents. It is important that these transit improvements are made to comply with federal law and achieve neighborhood safety.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Potholes and depressions continue to imperil traffic in Community District 16. The Departments of Transportation and Environmental Protection need to jointly inspect locations that frequently depress and eventually cave-in to identify the origin of the roadway condition and repair them in a timely fashion. A number of our streets are dimly lit and create an atmosphere conducive to criminal activities. The intensity of street lights need upgrading, especially underneath the elevated train lines along Broadway and Livonia Avenue, and along the bus routes. Truck traffic is increasing throughout the district. Residential blocks, instead of designated truck routes, are being used by 18-wheelers which are destroying our streets and creating congestion. More designated truck route signs are needed. With new housing construction, the volume of traffic is increasing. It is imperative that the Department of Transportation conduct a districtwide survey to determine locations for new traffic lights and stop signs.
Needs for Transit Services
There are no accessible subway stations for persons with physical disabilities in the district. The Halsey Street. Chauncey Street, Rockaway Avenue and Broadway Junction stations on the "IND" line, the Atlantic Avenue, Sutter Avenue, Livonia Avenue, and New Lots Avenue stations on the "L" line, and the Sutter Avenue-Rutland Road, Saratoga Avenue, Rockaway Avenue, and Junius Street stations on the "IRT" line are not accessible to the physically challenged due to them being subterranean and elevated.. We call upon the Metropolitan Transit Authority to
appropriate needed funds to rehabilitate the bridge at Junius Street that enables commuters to connect to
the Livonia Avenue station on the "L" line. In addition, we request that there be a free transfer between the Junius Street station on the IRT-3 and Livonia Avenue station on the "L" line. We also request that the New Lots Avenue station on the "L" line be rehabilitated to include new lighting.The Broadway Junction station has a very high volume of traffic because of its connections to 3 train lines and 5 bus lines. The station has a series of steps that prevent the physically challenged from using this facility. We urge the Transit Authority to make the station handicap accessible. The East New York Avenue station on the Long Island Railroad is in need of updating. Cameras are in place on the platforms and should also be placed in the tunnel connecting the stairwells leading to the service roads of Atlantic Avenue. Presently, there is no wheelchair access on the westbound platform. We are requesting that a permanent ramp be installed to provide access for wheelchair bound passengers who now must travel to the Atlantic Avenue terminal to disembark.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
13/40
NYCTA
Repair or upgrade
Rehabilitate pedestrian bridge connecting the
subway stations or
IRT-3 at Junius Street and the L-line at Livonia
other transit
Avenue to provide safe passage and connection
infrastructure
to subway stations. Upgrade lights on the
bridge to better illuminate the walkway.
24/40
NYCTA
Improve
The Rockaway Avenue station on the IND line is
accessibility of
subterranean and is not ADA compliant. An
transit
elevator or escalator is needed to enable
infrastructure, by
persons who cannot walk down the series of
providing elevators,
steps to access the subway system.
escalators, etc.
25/40
NYCTA
Improve
The Rockaway Avenue station on the IRT line is
accessibility of
an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
26/40
NYCTA
Repair or upgrade
New Lots Avenue station on the L-line is dimly
subway stations or
lit. Upgrade lights at the station to provide more
other transit
illumination for commuters.
infrastructure
27/40
NYCTA
Improve
The Livonia Avenue station on the "L" line is an
accessibility of
elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stariway to use the station.
escalators, etc.
28/40
NYCTA
Improve
The Broadway Junction station has a very high
accessibility of
volume of pedestrian traffic because of its
transit
connection to 3 train lines and 5 bus lines. The
infrastructure, by
station has a series of stairs that prevent the
providing elevators,
physically challenged from using this facility. We
escalators, etc.
are requesting that the station be made
handicap accessible.
29/40
NYCTA
Improve
The Sutter Avenue station on the "L" line is an
accessibility of
elevated structure and is not handicap
transit
accessble. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
31/40
NYCTA
Improve
The Sutter-Rutland Road station on the IRT line
accessibility of
is an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
32/40
NYCTA
Improve
The Saratoga Avenue station on the IRT line is
accessibility of
an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
33/40
NYCTA
Improve
The New Lots Avenue station on the "L" line is
accessibility of
an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station
escalators, etc.
34/40
DOT
Repair or construct
Broken sidewalks, curbs and pedestrian ramps
Belmont
new curbs or
are in need of repair along this commercial
Avenue
pedestrian ramps
strip.
Rockaway
Avenue
Christopher
Avenue
35/40
NYCTA
Improve
The Atlantic Avenue station on the "L" line is an
accessibility of
elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walkup the stairway
providing elevators,
to use the station.
escalators, etc.
36/40
DOT
Repair or construct
Broken sidewalks, curbs and pedestrian ramps
Pitkin Ave
new curbs or
are in need of repair along our commerical strip.
Howard Ave
pedestrian ramps
Mother
Gaston Blvd
37/40
NYCTA
Improve
The Chauncey Street station on the "J" line is an
accessibility of
elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station
escalators, etc.
CS
DOT
Repair or provide
The IRT subway line runs along Livonia Avenue
Livonia Ave
new street lights
between Junius Street and East 98th Street.
Junius St East
Additional lights are needed along Livonia
98th St
Avenue to brighten the street and make it less
conducive to criminal activities.
CS NYCTA Improve accessibility of transit infrastructure, by providing elevators, escalators, etc.
The Junius Street station on the IRT line is an elevated structure and is not handicap accessible. An elevator or escalator is needed to enable persons who cannot walk up the stairway to use the station. We're also requesting the construction of a passageway between the "Junius Street" station on the IRT-3 and the "Livonia Avenue" station on the IND-L to enable commuters to transfer between stations without descending to the street to re-enter the transit system.
image
CS DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Due to heavy traffic, salting of our roadways, and ongoing excavations to repair our infrastructure and install utility lines, numerous potholes and cave-ins result which creates hazardous conditions for motorists and pedestrians. Ongoing repairs are needed on streets throughout the district.
Expense Requests Related to Transportation and Mobility
The Community Board did not submit any Budget Requests in this category.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 16
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Quality of parks and park facilities
Our playgrounds and parks provide the only recreation for many of our residents who are economically disadvantaged and are unable to travel outside of the community. Several of these parks are located adjacent to public schools where hundreds of children use them on a daily basis during school hours. We need regular maintenance to keep them clean and prevent their deterioration from normal wear and tear. The Brownsville Recreation Center is an indoor facility that is used on a daily basis by hundreds of patrons. Additional maintenance staff is needed to keep the facility clean.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Community District 16 has 23 parks and playgrounds and 65 community facilities, including the Brownsville Recreation Center, 3 branches of the Brooklyn Public Library, Betsy Head Park and Pool (which is a New York City landmark built during the WPA era), and several other community facilities located throughout our 20 New York City Housing Authority developments. All of these parks, playgrounds, and community facilities serve residents of all ages on a daily basis and must comply with the American Disability Act and be properly maintained and upgraded regularly to ensure that the infrastructure and facilities continue to meet the needs of our residents into the foreseeable future. Our playground, parks, and community facilities provide the only source of recreation for many or our residents who are economically disadvantaged and lack the resources to travel outside of the community to recreation facilities. It is important that these open spaces and community facilities be maintained, upgraded and programmed to achieve neighborhood equity, and respect the cultural sensitivity of the community with regard to sports and other recreation activities that are in high demand in comparison to other communities across New York City with greater income and access. Our playground, parks and community facilities are used by hundreds of residents on a daily basis. They offer much needed recreation facilities for at-risk youths, low-income children and families; and in general improves the overall quality of life for residents which makes the Ocean Hill-Brownsville neighborhood more livable. Several of these parks and playgrounds are located adjacent to public schools and are used by students during school hours. According to research, green spaces, public parks, and recreation facilities have been strongly linked to reductions in crime and in particular reduction in juvenile delinquency. During the summer months, playground assistants are needed to provide structured activities in our playgrounds and parks.
Community District 16 has 29 community gardens which are critically important to the historical narrative of the community and provide additional community and open space for residents, and most importantly fresh vegetables and fruits for our residents. Resources and support to maintain community gardens are equally important and much needed. To ensure that all facilities are properly maintained and the greatest amount of community benefit can be derived, additional maintenance and recreation staff are needed in our playground, parks, and community facilities, especially in the Brownsville Recreation Center.
Needs for Cultural Services
The Brownsville Multi Services Center, located at 444 Thomas S. Boyland Street, is in need of renovation. There has been no major renovation to this facility since it was built in the 1970s. The bathrooms, elevator, heating and ventilation system, and electrical wiring need upgrading to better service the needs of its occupant agencies that provide an array of services to the general public.
Needs for Library Services
The Saratoga Library Branch and the Stone Avenue Library Branch are in need of interior and exterior repairs to improve the environment for their patrons and staff. The heating and cooling system at the Saratoga Library branch needs upgrading, safety and security enhancements are needed, in addition to new furniture and equipment to better serve the needs of the patrons. New windows, doors, repointing and rehab of the limestone, roof and side entry steps are needed at the Stone Avenue branch library.
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/40
DPR
Reconstruct or
Reconstruction of Floyd Paterson Field with
upgrade a park or
synthetic turf for multi purpose use such as
amenity (i.e.
baseball, football, soccer, and cricket will
playground, outdoor
improve the condition of the field and make it
athletic field)
more conducive for recreational activities for all
ages.
2/40
DPR
Provide a new, or
A comfort station is needed at Powell Street
new expansion to, a
Playground. Construction of a comfort station
building in a park
will also service users of Houston Playground
which is located across the street.
3/40
DPR
Reconstruct or
Rehabilitation of the play equipment and
upgrade a park or
comfort station at South Pacific Playground,
playground
which is adjacent to Kingsboro Houses, will
continue to provide much needed recreation for
community residents.
5/40
DPR
Reconstruct or
The play equipment is in need of replacement
upgrade a park or
due to heavy use. A section of the running track
playground
has caved in. Security lights are needed to
enable use of the running track in the evening
hours
6/40
DPR
Reconstruct or
Dr. Richard Greene Playground is adjacent to a
upgrade a park or
public school and several NYCHA buildings
amenity (i.e.
which is the only source of recreation for
playground, outdoor
hundreds of children. The play equipment needs
athletic field)
upgrading as well as the comfort station.
8/40
DPR
Reconstruct or
Due to many years of use, the swimming pool is
upgrade a park or
in need of renovation as well as the bath house.
amenity (i.e.
playground, outdoor
athletic field)
9/40
BPL
Create a new, or
Renovation of the interior of the Saratoga
renovate or upgrade
Library Branch is needed to include the heating
an existing public
and cooling system and safety and security
library
enhancements.
10/40
DPR
Provide a new, or
Nehemiah Park and Floyd Paterson Field are
new expansion to, a
located diagonally from each other.
building in a park
Construction of a comfort station at Nehemiah
Park will service both Nehemiah Park and Floyd
Paterson Field which are heavily used by
residents of neighboring housing developments.
12/40
BPL
Create a new, or
Repointing and rehabilitation of the limestone
renovate or upgrade
are needed to prevent further deterioration of
an existing public
exterior of the Stone Avenue Library Branch
library
which is also in need of a new roof and side
entry steps. In addition, new windows and doors
are also needed.
15/40
DPR
Reconstruct or
Livonia Park is adjacent to a senior citizen
upgrade a park or
complex. New benches, checkers and chess
amenity (i.e.
tables are needed.
playground, outdoor
athletic field)
16/40
DPR
Reconstruct or
Van Dyke Playground is used by hundreds of
upgrade a park or
residents who live in Van Dyke Houses, a NYCHA
playground
development. The play equipment and
basketball court are in need of rehabilitation.
20/40
DPR
Reconstruct or
New and updated play equipment is needed at
upgrade a park or
Fish Playground to provide recreation for
amenity (i.e.
children in the adjacent school as well as the
playground, outdoor
community.
athletic field)
30/40
DPR
Reconstruct or
Installation of a dome over the Betsy Head Park
Betsy Head
upgrade a park or
will enable use of the facility year round during
Play Center,
amenity (i.e.
inclement weather.
Brooklyn,
playground, outdoor
New York, NY
athletic field)
CS
DPR
Reconstruct or
Chester Playground is located adjacent to PS/IS
upgrade a park or
327. Rehabilitation of the playground
amenity (i.e.
equipment and basketball courts are needed.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Rehabilitate Osborn Playground to include new
upgrade a park or
play equipment and safety surface. The comfort
amenity (i.e.
station is also in need of renovation.
playground, outdoor
athletic field)
CS
DPR
Other requests for
Renovate public locker rooms at the Brownsville
park, building, or
Recreation Center to provide better security for
access
belongings of patrons.
improvements
Expense Requests Related to Parks, Cultural and Other Community Facili es
Priority Agency Request Explanation Location
image
22/22 DPR Forestry services,
including street tree maintenance
Street trees throughout the district are in need of pruning. Tree limbs are covering streetlights and creating a condition conducive to criminal activities.
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
7/40
Other
Other capital budget
Since its construction in the early 1970s, there
444 Thomas
request
has been no major renovation of this facility.
Boyland
The bathrooms, elevator, heating and
Street,
ventilation system, electrical wiring and lighting
Brooklyn,
need upgrading to better service the needs of its
New York, NY
occupant agencies that provide an array of
services to residents of CD 16.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
2/22
Other
Other expense
HPD - Maintaining permanent housing is
budget request
becoming more difficult for low wage working
individuals and families. Medium income
housing will enable them to become less rent
burden and remain in the community
3/22
Other
Other expense
HPD - Many of our multi family housing stock
budget request
are in need of roof replacement, heating and
electrical upgrades. Financing programs such as
the Participation Loan Program and Multifamily
Housing Rehabilitation Program are needed to
facilitate the physical and financial
sustainability and affordability of privately-
owned multifamily buildings.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/40
DPR
Reconstruct or
Reconstruction of Floyd Paterson Field with
upgrade a park or
synthetic turf for multi purpose use such as
amenity (i.e.
baseball, football, soccer, and cricket will
playground, outdoor
improve the condition of the field and make it
athletic field)
more conducive for recreational activities for all
ages.
2/40
DPR
Provide a new, or
A comfort station is needed at Powell Street
new expansion to, a
Playground. Construction of a comfort station
building in a park
will also service users of Houston Playground
which is located across the street.
3/40
DPR
Reconstruct or
Rehabilitation of the play equipment and
upgrade a park or
comfort station at South Pacific Playground,
playground
which is adjacent to Kingsboro Houses, will
continue to provide much needed recreation for
community residents.
4/40
SCA
Renovate or
Upgrade student bathrooms, library and
985
upgrade a middle or
auditorium (curtains, sound system and air
Rockaway
intermediate school
condition) to provide a safe and healthy
Avenue
environment for students and staff at Kappa V.
5/40
DPR
Reconstruct or
The play equipment is in need of replacement
upgrade a park or
due to heavy use. A section of the running track
playground
has caved in. Security lights are needed to
enable use of the running track in the evening
hours
6/40
DPR
Reconstruct or
Dr. Richard Greene Playground is adjacent to a
upgrade a park or
public school and several NYCHA buildings
amenity (i.e.
which is the only source of recreation for
playground, outdoor
hundreds of children. The play equipment needs
athletic field)
upgrading as well as the comfort station.
7/40
Other
Other capital budget
Since its construction in the early 1970s, there
444 Thomas
request
has been no major renovation of this facility.
Boyland
The bathrooms, elevator, heating and
Street,
ventilation system, electrical wiring and lighting
Brooklyn,
need upgrading to better service the needs of its
New York, NY
occupant agencies that provide an array of
services to residents of CD 16.
8/40
DPR
Reconstruct or
Due to many years of use, the swimming pool is
upgrade a park or
in need of renovation as well as the bath house.
amenity (i.e.
playground, outdoor
athletic field)
9/40
BPL
Create a new, or
Renovation of the interior of the Saratoga
renovate or upgrade
Library Branch is needed to include the heating
an existing public
and cooling system and safety and security
library
enhancements.
10/40
DPR
Provide a new, or
Nehemiah Park and Floyd Paterson Field are
new expansion to, a
located diagonally from each other.
building in a park
Construction of a comfort station at Nehemiah
Park will service both Nehemiah Park and Floyd
Paterson Field which are heavily used by
residents of neighboring housing developments.
11/40
SCA
Renovate or
Air circulation in the auditorium at Mott Hall
210 Chester
upgrade a middle or
Bridges Academy is poor and it is extremely
Street
intermediate school
uncomfortable during warm weather.
Installation of an air condition unit in the
auditorium is much needed to improve air
circulation.
12/40
BPL
Create a new, or
Repointing and rehabilitation of the limestone
renovate or upgrade
are needed to prevent further deterioration of
an existing public
exterior of the Stone Avenue Library Branch
library
which is also in need of a new roof and side
entry steps. In addition, new windows and doors
are also needed.
13/40
NYCTA
Repair or upgrade
Rehabilitate pedestrian bridge connecting the
subway stations or
IRT-3 at Junius Street and the L-line at Livonia
other transit
Avenue to provide safe passage and connection
infrastructure
to subway stations. Upgrade lights on the
bridge to better illuminate the walkway.
14/40
NYCHA
Install security
Residents of Howard Houses have reported that
cameras or make
crimes in the buildings and on the grounds have
other safety
been increasing in recent years. Installation of
upgrades (Capital)
CCTV cameras will help to deter crime and
enhance the quality of life for its residents.
15/40
DPR
Reconstruct or
Livonia Park is adjacent to a senior citizen
upgrade a park or
complex. New benches, checkers and chess
amenity (i.e.
tables are needed.
playground, outdoor
athletic field)
16/40
DPR
Reconstruct or upgrade a park or playground
Van Dyke Playground is used by hundreds of residents who live in Van Dyke Houses, a NYCHA development. The play equipment and basketball court are in need of rehabilitation.
17/40
SCA
Renovate or
Renovate all bathrooms at the Riverdale
upgrade an
Community School, located at 76 Riverdale
elementary school
Avenue to provide a safe and healthy
environment for students and staff.
18/40
SCA
Renovate or
A complete renovation of the cafeteria is
upgrade an
needed to provide better accommodations for
elementary school
the student body.
19/40
SCA
Renovate interior
Upgrading of electrical wiring will allow for
building component
safer and more efficient use of electrical power
with the ever increasing use of electrical
equipment such as air condition units,
computers and other equipment..
20/40
DPR
Reconstruct or
New and updated play equipment is needed at
upgrade a park or
Fish Playground to provide recreation for
amenity (i.e.
children in the adjacent school as well as the
playground, outdoor
community.
athletic field)
21/40
SCA
Renovate or
The cafeteria and auditorium at P.S. 137 are in
upgrade an
need of renovation to improve lighting and
elementary school
seating for the student body.
22/40
SCA
Renovate or
A complete renovation of the cafeteria in this
upgrade an
very old building is needed to provide better
elementary school
accommodation for the student body.
23/40
SCA
Renovate interior
Renovate all school buildings in District 23 to
building component
make them ADA compliant.
24/40
NYCTA
Improve
The Rockaway Avenue station on the IND line is
accessibility of
subterranean and is not ADA compliant. An
transit
elevator or escalator is needed to enable
infrastructure, by
persons who cannot walk down the series of
providing elevators,
steps to access the subway system.
escalators, etc.
25/40
NYCTA
Improve
The Rockaway Avenue station on the IRT line is
accessibility of
an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
26/40
NYCTA
Repair or upgrade subway stations or other transit infrastructure
New Lots Avenue station on the L-line is dimly lit. Upgrade lights at the station to provide more illumination for commuters.
27/40
NYCTA
Improve
The Livonia Avenue station on the "L" line is an
accessibility of
elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stariway to use the station.
escalators, etc.
28/40
NYCTA
Improve
The Broadway Junction station has a very high
accessibility of
volume of pedestrian traffic because of its
transit
connection to 3 train lines and 5 bus lines. The
infrastructure, by
station has a series of stairs that prevent the
providing elevators,
physically challenged from using this facility. We
escalators, etc.
are requesting that the station be made
handicap accessible.
29/40
NYCTA
Improve
The Sutter Avenue station on the "L" line is an
accessibility of
elevated structure and is not handicap
transit
accessble. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
30/40
DPR
Reconstruct or
Installation of a dome over the Betsy Head Park
Betsy Head
upgrade a park or
will enable use of the facility year round during
Play Center,
amenity (i.e.
inclement weather.
Brooklyn,
playground, outdoor
New York, NY
athletic field)
31/40
NYCTA
Improve
The Sutter-Rutland Road station on the IRT line
accessibility of
is an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
32/40
NYCTA
Improve
The Saratoga Avenue station on the IRT line is
accessibility of
an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station.
escalators, etc.
33/40
NYCTA
Improve
The New Lots Avenue station on the "L" line is
accessibility of
an elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station
escalators, etc.
34/40
DOT
Repair or construct
Broken sidewalks, curbs and pedestrian ramps
Belmont
new curbs or
are in need of repair along this commercial
Avenue
pedestrian ramps
strip.
Rockaway
Avenue
Christopher
Avenue
35/40
NYCTA
Improve
The Atlantic Avenue station on the "L" line is an
accessibility of
elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walkup the stairway
providing elevators,
to use the station.
escalators, etc.
36/40
DOT
Repair or construct
Broken sidewalks, curbs and pedestrian ramps
Pitkin Ave
new curbs or
are in need of repair along our commerical strip.
Howard Ave
pedestrian ramps
Mother
Gaston Blvd
37/40
NYCTA
Improve
The Chauncey Street station on the "J" line is an
accessibility of
elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station
escalators, etc.
38/40
SCA
Renovate or
The auditorium at P.S. 41 is dimly lit. Upgrading
upgrade an
of the lighting will provide more illumination
elementary school
during performances and meetings.
39/40
SCA
Renovate or
Renovate all bathrooms at Brownsville
upgrade a middle or
Collaborative Middle School, located at 85
intermediate school
Watkins Street to provide a safe and healthy
environment for students and staff.
40/40
SCA
Renovate or
A complete renovation is needed for the
upgrade an
cafeteria and auditorium to provide better
elementary school
lighting and seating for the student body.
CS
DPR
Reconstruct or
Chester Playground is located adjacent to PS/IS
upgrade a park or
327. Rehabilitation of the playground
amenity (i.e.
equipment and basketball courts are needed.
playground, outdoor
athletic field)
CS
DPR
Reconstruct or
Rehabilitate Osborn Playground to include new
upgrade a park or
play equipment and safety surface. The comfort
amenity (i.e.
station is also in need of renovation.
playground, outdoor
athletic field)
CS
DPR
Other requests for
Renovate public locker rooms at the Brownsville
park, building, or
Recreation Center to provide better security for
access
belongings of patrons.
improvements
CS
DOT
Repair or provide
The IRT subway line runs along Livonia Avenue
Livonia Ave
new street lights
between Junius Street and East 98th Street.
Junius St East
Additional lights are needed along Livonia
98th St
Avenue to brighten the street and make it less
conducive to criminal activities.
CS
NYCTA
Improve
The Junius Street station on the IRT line is an
accessibility of
elevated structure and is not handicap
transit
accessible. An elevator or escalator is needed to
infrastructure, by
enable persons who cannot walk up the
providing elevators,
stairway to use the station. We're also
escalators, etc.
requesting the construction of a passageway
between the "Junius Street" station on the IRT-3
and the "Livonia Avenue" station on the IND-L to
enable commuters to transfer between stations
without descending to the street to re-enter the
transit system.
CS
DOT
Roadway
Due to heavy traffic, salting of our roadways,
maintenance (i.e.
and ongoing excavations to repair our
pothole repair,
infrastructure and install utility lines, numerous
resurfacing, trench
potholes and cave-ins result which creates
restoration, etc.)
hazardous conditions for motorists and
pedestrians. Ongoing repairs are needed on
streets throughout the district.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/22
HPD
Provide more
The supply of decent affordable housing for
housing for
extremely low and low income households is
extremely low and
decreasing. As a result, many reside in
low income
substandard housing that impacts their health.
households
Others are forced into homeless shelters.
2/22
Other
Other expense
HPD - Maintaining permanent housing is
budget request
becoming more difficult for low wage working
individuals and families. Medium income
housing will enable them to become less rent
burden and remain in the community
3/22
Other
Other expense
HPD - Many of our multi family housing stock
budget request
are in need of roof replacement, heating and
electrical upgrades. Financing programs such as
the Participation Loan Program and Multifamily
Housing Rehabilitation Program are needed to
facilitate the physical and financial
sustainability and affordability of privately-
owned multifamily buildings.
4/22
DYCD
Provide, expand, or
Summer youth employment programs are early
enhance the
introductions to the world of work and help to
Summer Youth
build skills that our youth need to develop good
Employment
work habits and sustain employment.
Program
5/22
SBS
Other expense
A comprehensive one stop small business center
workforce
to include M/WBE programs and technical
development
assistance to support local businesses and
requests
entrepreneurs is needed. .
6/22
EDC
Expand programs to
M/WBE resources and technical assistance are
support local
needed within the district for small business
businesses and
owners who are struggling to compete with
entrepreneurs
more established businesses in the City of New
York.
7/22
NYPD
Provide resources to
It is imperative that police officers assigned to
train officers, e.g. in
the 73rd Precinct continue to receive frequent
community policing
training in community engagement, cultural
sensitivity, and mental health first aid to better
equip them to patrol the community.
8/22
DOHMH
Other programs to
According to the New York City Department of
address public
Health and Mental Hygiene, the rate of preterm
health issues
births in Community District 16, a key driver of
requests
infant death, is the second highest in the city.
Maternal and infant health services are needed
to promote healthy pregnancies, positive birth
outcomes, and healthy infant growth and
development. The long-term goal of maternal
and infant health programs is to reduce
maternal and infant morbidity and mortality.
9/22
DOE
Other educational
For various reasons, not every student is
programs requests
prepared to attend college. Therefore, they
should have the option to learn a skilled trade
while in high school that will equip them to
compete in the job market. Career and Technical
Education Programs will prepare our high
school students for entry level employment in a
specific occupation and is aligned with
business/industry standards.
10/22
DYCD
Provide, expand, or
Many of our impoverished families lack financial
enhance
resources to provide structured activities for
Cornerstone and
their children. We need continued funding of
Beacon programs
our Cornerstone and Beacon programs which
(all ages, including
provide a range of free educational, cultural and
young adults)
recreational resources to our children and
youth.
11/22
DEP
Clean catch basins
Windblown litter as well as household
electronics and furniture are deposited in our
many rain gardens on a daily basis. Additional
manpower is needed to clean the rain gardens
more frequently.
12/22
FDNY
Other FDNY facilities
A Forcible Entry Door is requested for Battalion
and equipment
44 which will enable ongoing training of
requests (Expense)
firefighters in the method of opening locked
doors in the event of a fire, especially in multiple
dwelling buildings.
13/22
DOHMH
Create or promote
Gun violence is very prevalent in our
programs to de-
community. When gun violence ends a life, it
stigmatize mental
also impacts the lives of survivors (families and
health problems
friends) who struggle to cope with the lose of a
and encourage
loved one. Preventive and treatment programs
treatment
are needed for all ages.
14/22
DOHMH
Create or promote
Eating well is important for good health. A
programs for
healthy diet helps prevent many chronic
education and
diseases and conditions, such as obesity, type 2
awareness on
diabetes, hypertension, stroke, some cancers,
nutrition, physical
and heart disease. Expansion of outreach and
activity, etc.
educational programs such as Healthy Living is
needed to improve nutrition and physical
activity for all ages. In addition, programs such
as Shop Healthy NYC are needed to increase
access to healthy foods in the neighborhood
retailers. Outreach programs such as the
Newborn Visiting Program provides vital
resources to the community and needs
expansion.
15/22
DFTA
Increase
Many of our elderly and homebound residents
transportation
live alone. Without this service, they would not
services capacity
be able to get to their medical appointments
and shop for groceries.
16/22
DFTA
Enhance home care
Many of our seniors live alone and are in need
services
of assistance to perform activities of daily living
in their home such as bathing, feeding, and or
housekeeping.
17/22
DHS,
Other homelessness
According to the American Community Survey,
HRA
prevention program
about a third of families in Community District
request
16 are facing poverty. Many of these families
are at risk of losing affordable housing for a
variety of reasons, such as minimum wage jobs,
temporary unemployed due to illness, and lost
of job. Programs such as Homebase are needed
to provide families with monetary assistance
and resources to remain in permanent housing.
18/22
DFTA
Increase home
Many of our low-income elderly residents who
delivered meals
live alone do not have sufficient income to shop
capacity
for groceries and prepare daily nutritional
meals. An expansion of the Meals-on-Wheels
program will enable this population to eat more
healthy and frequently.
19/22
SBS
Support
There are a number of vacant storefronts along
Belmont Ave
development of
our commercial corridors where property
Rockaway Ave
local Storefront /
owners need financial support to renovate.
Mother
Facade
Gaston Blvd
Improvement
Program
20/22 SBS Support development of local Storefront / Facade Improvement Program
There are a number of stores that need facade improvement and property owners are in need of financial assistance.
Pitkin Ave Howard Ave Mother Gaston Blvd
image
21/22 DEP Clean catch basins When litter and debris clog our catch basins,
flooding and ponding occur during heavy rainfall at heavily trafficked locations which makes it difficult and unsafe for pedestrian crossing. Periodic cleaning of our catch basins is required.
image
22/22 DPR Forestry services,
including street tree maintenance
Street trees throughout the district are in need of pruning. Tree limbs are covering streetlights and creating a condition conducive to criminal activities.
image

