- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 4 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1bfn3GMwlfIrFs3oD172Hi9mrqTdz6rvy/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1bfn3GMwlfIrFs3oD172Hi9mrqTdz6rvy/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board Budget Requests •-
Fiscal Year
2021
,•'','
image
11¥1:
Published by:
PLANNING
February 2020
Manhattan Community District
4
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 4
image
Address: 330 West 42nd Street, 26th Floor Phone: (212) 736-4536
Email: jbodine@cb.nyc.gov
Website: www.nyc.gov/manhattancb4
Chair: Lowell Kern
District Manager: Jesse Bodine
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Manhattan Community District 4 (“MCD4”) is comprised of three neighborhoods on the west side of Manhattan: Chelsea, Clinton/Hell's Kitchen, and Hudson Yards. Bounded by 14th Street in the south; West 59th Street in the north; Sixth Avenue south of West 26th Street and Eighth Avenue north of 26th Street as its eastern border; and Hudson River to the west. MCD4 borders Greenwich Village, the Flatiron District, the Upper West Side and the Midtown central business district. Portions of several well-known areas exist within MCD4's boundaries, including the Garment District, the Flower District, the Gansevoort Market Historic District, the Ladies’ Mile Shopping District, the West Chelsea Historic District and the Theater District. Other notable sites in MCD4 include: Restaurant Row, The High Line, the Bella Abzug Park, the Vessel and the Cuture Shed, the Intrepid Sea, Air & Space Museum, the Circle Line, the Javits Center, the Rubin Museum, Chelsea art galleries, Columbus Circle, Maritime Piers 56-99, the Farley Building/Moynihan Station, the Lincoln Tunnel, the Port Authority Bus Terminal, and the northern half of Hudson River Park.
The total population of MCD4 has grown from approximately 87,000 in 2000 to over 104,000 according to the 2010 Census. This represents 19% growth overall, much of it concentrated in recently rezoned areas. This rate of growth is faster than most parts of New York City. As a result of rezoning, significant new commercial and residential development is now transforming formerly industrial areas. The fast growing stock of hotels and conversions to AirBnB, as well as new tourists attractions are adding to traffic congestion and sidewalk crowding. Large segments of our neighborhoods are under construction. The rapid increase in land value is accelerating the displacement of many long-time tenants and small business owners, while the new benefits of development have yet to materialize and may not be available to all. Members of MCD4 have strived for balance between the redevelopment of these areas with the preservation and expansion of the district's residential neighborhoods. A major priority is ensuring that new development helps produce more permanently affordable housing. The increased development has also put enormous pressure on transportation systems in the area. Overall, the rezoning and subsequent construction has contributed to the deterioration of the quality of life of residents of MCD4. This mass of new construction is exacerbated by the development of large-scale proposals within MCD4, including Hudson Yards, Manhattan West, the Port Authority Bus Terminal, Amtrak’s Gateway Tunnel proposal, and the conversion of the Farley Post Office into the new Moynihan Train Station.
Massive increases in truck deliveries and for hire services are disproporationalty affecting our district. Further,
traffic congestion caused by the Port Authority Bus Terminal and the Lincoln Tunnel are increasingly incompatible with the new residential zoning of the surrounding neighborhoods.
MCD4 is intent on preserving the character of our neighborhoods while taking regional needs into account.
MCD4's priorities include:
Maintaining neighborhood character and preventing displacement and eviction of residents and small businesses, to enhance diversity and positive neighborhood relations among disparate groups;
Preserving affordable housing and creating additional affordable housing for people making between 60 and 80% of AMI;
Maintaining the stability of a long-standing local retail presence in our communities and preserving affordable commercial space for businesses, community, arts and cultural groups;
Increased investment to renovate and vastly improve the living conditions at Harborview, Elliot Chelsea, and Fulton Houses NYCHA developments;
Improving quality of air, water, and land;
Developing coherent transportation infrastructure for our district, including increasing public safety in transportation, strengthening and improving public bus and rapid transit systems, expanding the NYC Ferry network to the west side, and fostering a better balance in street usage between pedestrians, bicycles and vehicles, particularly buses;
Building new elementary and middle schools, to combat overcrowding and accommodate the rapidly increasing school-age population;
Creating additional green spaces to combat the lack of parkland;
Increasing services to the homeless, seniors, people with disabilities, and youth;
Addressing the quality of life issues associated with construction, a multitude of bars and restaurants and poor sanitation services; and
Working with the City to ensure its commitments generated by previous rezoning actions (affordable housing, bus garage, parks, arts Spaces) are completed within a timeframe that addresses the looming threats of gentrification.
Overall Most Pressing Issues:
The massive rezoning actions on the West Side have created thousands of market rate units. It made the neighborhoods of Chelsea and Hell's Kitchen very attractive and expensive. This increasingly expensive supply has accelerated the loss of affordable housing units and it is threatening the preservation of the neighborhood character with loss of diversity in residents as well as in businesses. This increase in population puts additional stress on an underfunded transportation system and also results in increased vehicular traffic through the Lincoln Tunnel, which continues to be a major safety and quality of life concern. The three most pressing issues facing Manhattan Community Board 4 are:
Affordable housing
Neighborhood preservation (development trends)
Traffic & Air Quality
Funded Requests: MCD4 would like to thank various agencies for their response to certain requests included in last year’s budget and their assistance in addressing these pressing needs. Thank you to:
DOE for completing the handicap lift at PS11
DPR for funding and completing the design for a new park on 48th Street and Tenth Ave
DOE for renovating the chemistry lab at the Food and Science High School
DCA for the develooment of a study and database for affordable spaces for arts organiations
DOT for convering Eleventh Ave to one-way from 57th to 37th 42nd Street; installing a bike lane and adding pedistrian safety improvements including concrete islands
NYPD for funding a study to relocate the Tow Pound of Pier 76
DSNY for the funding of additional crews to increase residential waste and recycling pickup
DHS for expanding staffing and resources for the Street Homeless Outreach Program
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 4
image
The three most pressing issues facing this Community Board are:
Affordable housing
For decades, Community District 4 has lost thousands of affordable housing units because of weak regulation of affordable housing by the state and city. This included demolition restrictions, illegal hotel conversion, and harassment of tenants by landlords. Only recently have state laws been strengthened to preserve and protect the existing affordable housing stock. The existing affordable housing has also been confronted by a tremendous increase in the development of new market rate and luxury housing. Through large re-zonings, the MCD4 community has achieved more new affordable housing through recent re-zonings and continued push for more affordable units, but the new numbers do not offset the units lost. Of continued top importance is the preservation and creation of affordable housing at all income bands.
Land use trends (zoning, development, neighborhood preservation, etc.)
The massive rezoning actions on the West Side have created thousands of market rate units. It made the neighborhoods of Chelsea & Hell's kitchen very attractive and expensive. This increasingly expensive supply has accelerated the loss of affordable housing units and it is threatening the preservation of the neighborhood character with loss of diversity in residents as well as in businesses. This increase in population puts additional stress on an underfunded transportation system and also results in increased vehicle traffic through the Lincoln Tunnel, which continues to be a major safety and quality of life concern.
Traffic
Manhattan Community District 4 is home to the Port Authority Bus Terminal and the Lincoln Tunnel, both of which greatly contribute to vehicular traffic and therefore pollution in our community. These facilities diminish air quality, slow public transit, and negatively impact pedestrian safety and space. Additionally, massive rezoning actions have further strained traffic and roadway infrastructure which has not been improved to meet the growing demands of the community from large scale commercial and residential development. The overall growth in deliveries, and for hire vehicles is compounding the problems specificities to our neighborhoods. Our district is home to major citywide distribution centers: USPS with the Farley Annex and major FedEx and UPS facilities on the west side.
Pedestrian and bicycle traffic continue to grow, too. While bike lanes are being installed, pedestrians and cyclists regularly confront danger and quality of life issues as they fight for space with vehicles which also impede on public transit. Significant investment in sidewalks and pedestrian safety improvements are needed to mitigate the continued increase in vehicular traffic.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 4
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
Homelessness has become a major issue in MCD4 over the last several years. Large public facilities located within MCD4, such as the Port Authority Bus Terminal (where recent issues of human trafficking have arisen) and adjacent Penn Station are a natural gathering place for people without homes. Many homeless people need social services, in particular substance use treatment, mental health services, and vocational training. The presence of very large homeless shelters, such as BRC, and drug rehabilitation centers has also brought major stress to the community. We do not oppose homeless shelters in our district, however, location and size will be important to consider in future new centers.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
Clinton and Chelsea neighborhoods have consistently been ranked as ones with the highest rates of new HIV diagnoses among all five boroughs, almost four times the citywide rate. The recent re-opening of the Chelsea Sexual Health Clinic along with long-standing community partners in our district, i.e. Ryan-Chelsea Clinton Community Health Center, Callen-Lorde, and Gay Men's Health Crisis, are crucial partners in this fight; but more resources are needed for the efforts to make PrEP, PEP, and rapid HIV testing more accessible to all members of our community district. Public awareness campaigns around safe sex and sexual health should also be expanded.
Needs for Older NYs
According to the US Bureau of the Census, there are 16,972 individuals (12.1%) over 65 years of age living in the Chelsea/Clinton Neighborhoods. The number of people over age 65 began to increase substantially beginning in 2011 as the oldest members of the baby-boom generation reach the 65-year mark. The number of people age 65 or older will nearly double between 2000 and 2030. To better understand the growing needs of our seniors, in 2013, the Board partnered with The Actors Fund (a human service organization for the performing arts with many constituents living in MCD4), the Visiting Nurse Service of New York and the Rodney Kirk Center of Manhattan Plaza (a 1700 unit Section 8 building with over 1100 seniors) to conduct a survey of seniors residing in Community District
An Advisory Committee of over 40 senior service, health care, affordable housing providers, local political representatives and entertainment unions came together to focus on the needs, concerns and supports required for this community. The Committee identified several main priorities:
Education/Outreach to seniors about the increase of SCRIE
A campaign to identify and promote Age Friendly local business
Expansion of affordable mental health services for seniors and medical home visit programs
Support services for caregivers of the frail elderly
A housing agenda for older New Yorkers.
Additional needs for people with disabilities
According to the 2010 Census there has been a 8.3 percent growth in our district of people with disabilities. The Committee identified several main priorities:
image
Affordable Housing: Increase the proportion of affordable housing units in the community for people with disabilities.
image
Tenant Edcuation: Making sure residents living with disabilities know federal, state, and local housing laws and property owners responsabilities to provide ada access and accomadations.
image
Additional city agenceis must make all sidewalks and city owned facilities accessable.
Needs for Homeless
Homelessness has become a major issue in MCD4 over the last several years. Large public facilities located within MCD4, such as the Port Authority Bus Terminal and Penn Station are a natural gathering places for people without homes. Many of the homeless population need social services specifically around substance use and mental health treatment. The presence of very large homeless shelters, such as BRC, and drug rehabilitation centers has also brought major stress to the community. We are open to homeless shelters in our district, however, significant is location and size of any shelter opening in our community.
Needs for Low Income NYs
According to the NYU Furman Center, MCB4 represents the interests of the neighborhoods with one of the highest levels of income inequality in New York City. Our district is also home to three large public housing developments: the Chelsea-Elliot Houses, the Robert Fulton Houses, and Harborview Terrace. As stated in an October 2017 letter, the Board is deeply concerned there are only four vendors in our district who participate in the Supplemental Nutrition Program for Women, Infants, and Children (WIC), all who happen to be small businesses. Two stores serve the 507 WIC participants within Chelsea zip codes, Ideal Marketplace and Western Beef, while the other two vendors serving our district are Sugar Deli and Liberty Bagel Deli and Grocery located in Clinton. More resources are needed to help MCB4 residents access WIC providers and help more grocery stores become authorized WIC vendors.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
2/41 DHS Provide new homeless shelters or SROs
Downsize the BRC shelter at 131 West 25th Street in exchange establish a new family with children shelter.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
2/41
DHS,
Other homelessness
Include additional funding for after placement
HRA
prevention program
support staff for homeless families that are
request
selected through the DHS family preference for
buildings receiving 421a benefits. These
buildings are typically luxury/market buildings
with no onsite supportive services. Both the
families coming from the DHS shelter system
and the building management will benefit from
additional onsite and or light touch supportive
services to assist the family to acclimate with
the transition.
3/41
DHS
Expand
Expand funding for support for families and
homelessness
adults exiting shelter to decrease homeless
prevention
recidivism. In particular, expand, GED
programs 1
completion programs, job training, and
continuity of social services with additional
caseworkers for at least 3 months after exiting
shelter.
4/41
DFTA
Increase home
Expand existing programs for Seniors (DFTA)
delivered meals
Meal programs at the following locations: Penn
capacity
South NORC - 290 9th Ave Encore Community
Services - 239 West 49th Street The SAGE Center
Midtown - 305 Seventh Avenue
7/41
DOHMH
Provide more
As referenced in the 2018 NYC DOHMH
HIV/AIDS
Community Health Profile for Clinton and
information and
Chelsea neighborhoods, CD4 ranks highest in
services
the rate of new HIV diagnoses, almost four
times the citywide rate. Given the demographics
of the resident population in Chelsea and
Clinton, the district requires increased funding
for education, prevention and treatment for the
following organizations: GMHC - 307 W 38th
Street, Ryan Chelsea/Clinton Health Center - 645
10th Ave , and Callen-Lord - 356 West 18th St.
16/41
DFTA
Increase case
As the SARA program expands affordable senior
management
housing, an increase in funding for support
capacity
services are needed to help seniors age-in-place.
The number of people over age 65 began to
increase substantially beginning in 2011 as the
oldest members of the baby-boom generation
reached the 65-year mark. Increase funding for
existing programs for seniors for mental health
services; In-home supportive services;
preventive health; and social services for low
income seniors. Possibly by partnering with
service providers such as Service Program for
Older People (SPOP) and the following
organizations: Ryan Chelsea Clinton Clinic,
GMHC, Hudson Guild Senior Services,
Coffeehouse Senior Center – Project FIND, and
Clinton Senior Center – Project FIND.
36/41
DHS,
Provide, expand, or
Continued Support: Expand HRA Anti-
HRA
enhance anti-
Harassment Legal Services to Manhattan
eviction legal
Community District 4. These important
services
homeless prevention programs are only
provided in East Harlem and Inwood
neighborhoods in Manhattan. While the
administration is committed to supporting legal
services to prevent harassment in districts that
are to be rezoned in the near future, community
districts such as CD4 which was subject to three
large rezonings in the past decade, need
enhanced funding to mitigate the increasing
amount of tenant harassment due to the
increasing development pressures as a result of
the rezoning. Enhanced legal services are
needed to represent individual tenants and
tenant associations in Manhattan CD4.
41/41
DHS
Expand street
Continued Support: Continue to expand funding
outreach
for staffing and resources for street homeless
outreach program
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 4
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
The current number of existing and planned schools in MCD4 is not meeting the demand for seats of school-age children who are currently living in our community and the expected increase in students from all the new residential developments. As development continues, more children will enter our district schools, impacting schools already operating at full and at over capacity. Funds need to be allocated to both acquire space for new schools and upgrade existing facilities.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
The Challenges Facing Our Public Schools.
S chool Capacity:
The current number of existing and planned schools in MCD4 is not meeting the demand for seats of school-age children who are currently living in our community and the expected increase in students from all the new residential developments. Due to the increasing number of larger apartment units being built, traditional methods for estimating the number of school-age children is inadequate in determining the future needs for school seats. As development continues, more children are entering our district schools and impacting schools already operating at full or near capacity. Funds need to be allocated to both acquire space for new schools and to upgrade existing facilities.
N eeds Related to Student Welfare and Programs:
Several schools in MCD4 are experiencing an increasing enrollment of students who, with their families, are living in temporary hotel shelters. These students bring new challenges and needs to the system. They include: lack of laundry services, lack of social service needs and lack of a housing specialist. Until New York City has eliminated the use of temporary hotel shelters, these schools need to have permanent on-site social workers to address the challenges that these students and their families are experiencing. In addition, as the population in the district continues to become more diverse, more effort should be made to mirror our diverse community in our schools thereby enhancing the social development of all our students. New York City DOE needs to identify and provide additional support for schools with a high number of special needs students.Test preparation should be available to all students and funds made available to make all schools ADA compliant as required by law.
Our priority should be to provide our students with the resources to enable them to perform at their best level and develop the skills needed to continue their education.
Needs for Youth and Child Welfare
Our schools are experiencing an increasing number of students living in temporary housing located in MCD4. Many children residing in temporary housing have, at some point, child welfare involvement. Until New York City has eliminated the use of temporary housing in hotels, schools in MCD4 must have on-site full time social workers to address the challenges these students and their families are experiencing.
New York City DOE needs to provide additional support for schools with a high number of special needs students. Test preparation should also be available to all students as well as funds to make all schools ADA compliant as required by law.
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
7/41
SCA
Renovate interior
Expand funding to the School Construction
building component
Authority for security cameras in the following
schools: P.S. 33 Chelsea Prep – 281 9th Avenue
P.S. 51 Elias Howe – 525 West 44th Street P.S.
111 Adolph S. Ochs – 440 West 53rd Street P.S.
212 Midtown West – 328 West 48th Street
10/41
SCA
Renovate or
Expand funding to SCA to refurbish two science
525 West
upgrade a high
labs for Manhattan Bridges High School at 525
50th Street.
school
West 50th Street.
17/41
SCA
Renovate or
Provide Funds to make P.S. 111 School entrance,
440 West
upgrade an
gymnasium, and auditorium ADA accessible.
53rd Street
elementary school
Upgrade pre-k bathrooms and sink areas.
18/41
SCA
Renovate or
Continue funding for renovation of the following
281 9
upgrade an
areas and items at P.S. 33: bathrooms; kitchen
Avenue,
elementary school
cafeteria; PA system; security cameras.
Manhattan,
New York, NY
19/41
SCA
Renovate or
P.S.35M: Increase funding of $100,000.00 to
317 West 52
upgrade a high
upgrade library to include also computer and
Street
school
media lab.
31/41
SCA
Renovate or
Expand funding to SCA for Wifi\Internet
250 West
upgrade an
upgrade for Liberty High School.
18th Street
elementary school
32/41
SCA
Renovate or
Arts & Craftsmanship High School: Fund 10
439 West
upgrade a high
Smartboards for classrooms.
49th Street
school
34/41
SCA
Renovate or
Increase additional funding of $300,000 for NYC
333 West
upgrade a high
Lab School to complete renovation of third floor
17th Street
school
student and staff bathrooms.
35/41
SCA
Renovate or
Increase additional funding of $100,000 for
525 West 44
upgrade an
P.S.51 to complete and Earth Science Lab.
Street,
elementary school
Manhattan,
New York, NY
37/41
SCA
Renovate or
Increase additional fuding for building wide
225 West 24
upgrade a high
electrical upgrade to High School for Fashion
Street
school
Industries.
38/41
SCA
Renovate interior
building component
Increase additional funding for elevator
replacement at the Bayard Rustin Educational Complex.
351 West 18
Street, Manhattan,
New York, NY
39/41
SCA
Renovate or
Increase additional funding for new security
320 West 21
upgrade an
door alarms at P.S. 11.
Street,
elementary school
Manhattan,
New York, NY
40/41
SCA
Renovate interior
Increase funding for auditorium air conditioning
439 West 49
building component
for Business of Sports and Graphic Arts Campus.
Street,
Manhattan,
New York, NY
CS
SCA
Provide a new or
With schools operating a full or over capacity,
expand an existing
we need to identify sites to build new district
middle/intermediate
middle schools. Development on the west side,
school
including Hudson Yards, will bring in an
extraordinary number of students, in a short
time frame.
CS
SCA
Renovate or
PS11 Captial Needs: Complete Scope and fund
320 West 21
upgrade an
Handicap Lift for universal access to the
Street
elementary school
building. This school of approximately 950
students is not yet handicap accessible.
CS
SCA
Renovate or
Food and Finance High School: Complete
525 West
upgrade a high
needed funding of $2 million for a chemistry
50th Street
school
lab.
CS
SCA
Renovate or
High School for Environmental Studies:
444 West 56
upgrade a high
Complete funding for $100,000 shortfall for new
Street
school
roof project.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
17/41
DYCD
Provide, expand, or enhance after school programs for all grade levels
Provide full funding for all after school programs in the district.
33/41 DOE Assign more non-
teaching staff, e.g., to provide social, health and other services
Expand and Baseline funding for Licensed School Social Workers in all schools within Manhattan School District 2
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 4
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
83.5% of the district's population does not own a car. A full third of the population walks to work. In the last fiscal year, our community has seen an increase of 250% in fatalities in spite of robust street improvements. It is critical that the NYPD significantly increase its enforcement of speeding, running of red lights, failure to yield and gridlock which prevent pedestrians and cyclists from crossing the intersections safely.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
With the development of the Hudson Yards underway, the addition of tens of thousands of residents, the installation of new tourist destinations (the Vessel, Bella Abzug Park, Whitney museum, High line, ) and commuter flows (7 subway, Lincon tunnel and Bus terminal) increased deliveries ( Whole Foods/Amazon, USPS , Fedex and UPS distribution centers in our districts) and new schools (Avenues, Success Accadmy , PS 33) our current precincts are stretched to the limit. More traffic agents are needed forthe 83.5% of the district's population does not own a car. A full third of the population walks to work. in the last fiscal year, our community has seen an increase of 250% in fatalities in spite of robust street improvements. It is critical that the NYPD significantly increase its enforcement of speeding , running of red lights, failure to yield and gridlock which prevent pedestrians and cyclists from crossing the intersections safely. Enforcement of bus routes, layover, spill-back and idling are needed. the fact that we have four different precincts Make it very difficult to work cooperativley with all of their oficers.
Needs for Emergency Services
As the West of Manhattan becomes more residential and the impact of global warming becomes a significant concern FDNY\EMS stations must become more environmentally and neighborhood friendly.
image
Priority
Agency
Request
Explanation Location
8/41
NYPD
Other NYPD
Relocate the Tow Pound from Pier 76: The
facilities and
Hudson River Park Act calls for the City to use its
equipment requests
best efforts to find a new location for the
(Capital)
existing tow pound so that Pier 76 can be
developed as 50% parkland and 50% compatible
commercial use. We urge the City to consider
alternatives as soon as possible so that Pier 76
can take its rightful place as part of Hudson
River Park.
33/41
NYPD
Provide a new NYPD
Per the city charter which requires matching of
facility, such as a
service delivery with other administrative
new precinct house
boundaries, adjust the boundaries of two
or sub-precinct
existing precincts (midtown north and 10th
Precinct) to serve all of CD4. This would reduce
the number of precincts from presently 4 to 2 .
Resources would be reallocated between
precincts. As the population has grown by 17%
and residential areas now extend to Hudson
Yards and to 11th Avenue, the remaining
precincts boundaries and resources should be
readjusted to serve the new population to the
West in a cohesive manner for the residents.
CS
NYPD
Other NYPD
Continued Support: Continue to fund study to
facilities and
review moving the tow pound on Pier 76 at
equipment requests
West 34th Street. Study should explore how
(Capital)
these sites will support the construction and
maintenance of sections of Hudson River Park
and bring some predictability to the
development community for sites one block east
of the Park.
CS
FDNY
Provide new
Continue to fund the permanent relocation of
facilities such as a
the West 23rd Street 7 EMS station (FDNY) to
firehouse or EMS
West 29th Street (11/12 Ave) MCB4 specifically
station
requests immediate funding for a relocation of
the EMS station that is temporarily located on
W. 23rd Street and Tenth Avenue. The current
temporary location was never designed for the
heavy use the EMS is placing on this site. The
current small, cramped location adjacent to
residential buildings has resulted in noise and
exhaust pollution. The site is unsafe for both
FDNY personnel and nearby residents and
pedestrians.
Priority
Agency
Request
Explanation
Location
18/41
NYPD
Assign additional
Fund and deploy 9 traffic officers to increase
uniformed officers
enforcement of the following traffic violations:
vehicular spill-back, parking in no standing, bus
drivers using unauthorized routes, vehicular
idling, bicycles riding on sidewalks, wrong way
on bike paths and streets, running red lights,
Illegal electric bikes, vehicles blocking bike
lanes, and unnecessary honking.
21/41
NYPD
Assign additional
Increase funding to increase salaries and
522 West 44
crossing guards
benefits for Crossing Guard positions.
Street
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 4
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Air quality and pollution
Street sanitation has become much worse in the high traffic corridors of Eighth and Ninth Avenues, and along Tenth Avenue by the High Line. Poor garbage storage (and infrequent collection) has led to a serious pest control problem and increased litter making its way into waterways and parks. MCD4 does not have a sufficient number of DSNY trash pickup trucks, despite its rapidly increasing population. In addition, the increase in restaurants has brought sidewalk obstructions (multiple sandwich boards, menus stands, plants etc.) make it nearly impossible for pedestrians to navigate the sidewalk on Ninth Avenue north of 34th street and on Eighth Avenue. Increased enforcement is required to ensure a safe pedestrian experience.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
The entire coastline of MCD4 and portions of the West Chelsea Historic District is categorized as High Risk Flood Zones. MCD4 is especially concerned about the southern and western areas of MCD4 and the entrances to the Lincoln and Amtrak tunnels. According to the New York City Department of Health and Mental Hygiene, this community suffers the second highest incidents of chronic lung disease of any community in Manhattan south of Harlem. Given the proximity of the Chelsea and Clinton/Hell’s Kitchen neighborhoods to the Lincoln Tunnel and to the Port Authority Bus Terminal, MCD4 is at particular risk from unhealthy air affected by emissions from motor vehicles, especially from the diesel engines in trucks and buses. Another major cause of air pollution in MCD4 is carbon emissions from buildings still using “dirty boilers” that burn heating oil 4 and 6. Many of the buildings using these dirty boilers are rent-regulated and cannot (or will not) pay for the cost of converting to cleaner alternatives. Noise complaints from MCD4 consistently rank among the highest registered by DEP and are rising, especially at night. The main sources of noise are from clubs and lounges (sound equipment and revelers in the wee hours leaving), construction, mechanical/air handling equipment (typically on roof tops), truck traffic (especially private sanitation trucks making pick-ups in the middle of night), emergency vehicles and honking.
Needs for Sanitation Services
The board is very concerned with the frequency of pick-up of garbage in the public wastebaskets that are often overflowing and attracting rodents. This situation has worsened and seen no improvement from previous years and needs immediate attention. With the increase in restaurants in the district, accompanying sidewalk obstructions (multiple sandwich boards, menus stands, plants, etc.) have appeared on the sidewalk making it nearly impossible for pedestrians to navigate on the sidewalk on Ninth Avenue, north of 34th Street and on 8th Avenue. Increased enforcement is required to ensure a safe pedestrian experience.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
22/41 DSNY Provide new or
increase number of sanitation trucks and other equipment
Increase funding to purchase the DSNY District 4 garage an additional holster to clear snow and salt from the additional bike lanes in the district.
image
CS DEP Evaluate a public location or property for green infrastructure, e.g. rain gardens, stormwater greenstreets, green playgrounds
Continued Support: MCB4 lauds the administrations NYC Green Infrastructure Program and we ask that EDC and other agency partners, including the Federal government design, construct and maintain a variety of sustainable green infrastructure practices within MCD4. A portion of the FY 2021 budget should be earmarked to conduct a feasibility study of measures that can limit the damage of storm surges including flood gates. It has been estimated that the cost to design and construct flood gates at Verrazano Narrows, Arthur Kill and Throgs Neck is approximately $10 billion
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
5/41
DSNY
Provide more
Baseline the $8 million for DSNY staff overtime
frequent litter
for additional basket pick up and expand
basket collection
funding to reach four basket pick up crews in
total.
6/41
DEP
Investigate air
Increase funding to increase pollution monitors
quality complaints
in CD4. According to the New York City
at specific location
Department of Health and Mental Hygiene, this
community suffers the third highest levels of air
pollution in the five boroughs. Air pollution
increases incidents of chronic lung disease.
Given the proximity of the Chelsea and
Clinton/Hells Kitchen neighborhoods to the
Lincoln Tunnel and to the Port Authority Bus
Terminal, MCD4 most likely is at particular risk
from unhealthy air.
25/41
DSNY
Provide or expand
Increase funding for NYC organics collection
NYC organics
program
collection program
32/41 DSNY Other cleaning
requests
Baseline funding for DSNY staff for an additional two crews to bring residential and recycling
pick-up service on Thursday and Saturday equivalent to the rest of the week.
image
35/41 DEP Investigate noise
complaints at specific location
Continued Support: Enhance or expand noise pollution abatement and enforcement programs: Additional resources are needed for night inspections when the noise pollution is most acute and invasive.
image
40/41 DSNY Provide more
frequent garbage or recycling pick-up
Continued Support: Continue to fund the additional DSNY staff for two additional crews to bring residential and recycling pick-up service on Thursday and Saturday equivalent to the rest of the week within the district.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 4
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
Increased pressures from re-zonings and development have diminished existing affordable housing stock and have made the need for new affordable housing even greater. Through illegal demolition, illegal hotel conversion, and harrassment affordable housing stock has shrunk, and the committments to create new affordable housing continue to be unmet. The MCD4 Affordable Housing Plan offers a roadmap for how to fulfill and develop more units of affordable housing at all income bands.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Years after both Hudson Yards and West Chelsea in 2005 and the Western Rail Yards in 2009, construction is in full swing but many City commitments remain unfilled. A number of items that were agreed to by the developers, the Administration and the City Council await completion. They need the commitment of financial resources from both the expense and capital budgets to support staff and implementation from the Department of City Planning), Economic Development Corporation, Housing Preservation and Development and other relevant agencies.
Needs for Housing
As stated in MCD4’s Affordable Housing Plan, affordable housing within the district is critical to the diverse population of artists, students, minimum wage, earners, and seniors. This mixed population includes the many of the most frail and isolated members of our community as well as the backbone of the service and cultural economy that is essential to NYC. It is vital that the City free up subsidies to replenish the inventory of affordable housing units in Chelsea & Hell’s Kitchen. MCD4 has developed a detailed plan to generate and preserve almost 10,000 units in our district. MCD4 stands to lose a significant amount of affordable housing due to expiring use in the immediate future. Sadly, our district has been plagued by the illegal demolition of buildings which were “protected” by zoning enacted in large part due to the efforts of this Community Board. We have been fighting against these illegal demolitions but the City needs to step up and do its part. It is unacceptable that 150 units of affordable housing have already been lost because of dishonest landlords and inactive agencies. MCD4 faces additional problems from being home to the second greatest amount of illegal bed and breakfast conversions in the City. Such usage is prevalent in rent-regulated housing and in buildings that benefit from tax abatement programs such as 421- and J-
51. The largest concentration of SRO housing in our community lies between 8th and 9th Avenues from W. 42nd to
W. 57th Streets. In that area, 62 buildings contain nearly 2,200 SRO units. West 51st Street alone contains 12 buildings with a total of 574 units. West 46th Street has 21 buildings with 289 units. Supporting Materials: The Community Board has provided the following supporting materials which can be accessed by clicking on the link(s) below or by copying and pasting the link(s) found in the Appendix into a browser.
Needs for Economic Development
More than a decade after the rezoning of the Hudson Yards (2005) and West Chelsea (2007), and nearly a decade after the rezoning of the Western Rail Yards (2009), buildings have been built, residents have moved in and businesses have opened but the much-promised resources for housing and infrastructure have not been delivered: many of the City’s commitments remain unfulfilled.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/41
HPD
Other affordable
Provide adequate capital subsidy for the HPD
525 W 55th
housing programs
development at the NYCHA Harborview Terrace
St
requests (capital)
site located at West 55 Street and 10th Avenue
and designate a developer from the most recent
RFP process.
3/41
NYCHA
Renovate or
Harborview Terrace (525 West 55th Street, New
525 West
upgrade public
York, NY 10019) - Prioritize Funding for the
55th Street
housing
following items: Roof repair, Boiler upgrade, and
developments
new building entrance doors,
4/41
NYCHA
Install security
Fulton Houses (421 West 17th Street New York,
cameras or make
NY 10011): Install security cameras on the roof
other safety
of all buildings.
upgrades (Capital)
5/41
NYCHA
Renovate or
Fulton Development (421 West 17th Street New
421 West
upgrade public
York, NY 10011): Increase funding to
17th Street
housing
renovate\upgrade the Elevators at 418-419
developments
West 17 Street and 420 West 19 Street.
12/41
NYCHA
Renovate or
Harborview Terrace (525 West 55th Street, New
Harborview
upgrade public
York, NY 10019): Increase funding for the
Terrace
housing
following items: upgraded lighting for public
Building 1,
developments
hallways, retiling public hallways, new hoper
Manhattan,
doors (garbage shoot doors), renovate garbage
New York, NY
storage area for senior building, and new
apartment front doors.
13/41
NYCHA
Renovate or
Fulton Development (421 West 17th Street New
9 Avenue,
upgrade public
York, NY 10011): Increase funding to
Manhattan,
housing
renovate\upgrade the following items: new
New York, NY
developments
sump pit\pumps for the following buildings: 401
West 16 Street; 420 West 19 street; 434 West 17
Street.
14/41
HPD
Other affordable
Provide adequate capital subsidy for the
500 & 560
housing programs
Multifamily Preservation Loan Program (MPLP)
West 52nd St
requests (capital)
and the Senior Affordable Rental Apartments
(SARA) for the following affordable housing
projects: 560 West 52nd Street - (MPLP) 500
West 52nd Street - (SARA)
23/41
EDC
Invest in capital
Fund a Brooklyn\Chelsea Ferry service to serve
projects to improve
the large workers population in the lower part
access to the
of our district. Location Site Street: 11th
waterfront
Avenue/Pier 57 at West 14th Street.
CS
HPD
Other affordable
housing programs requests (capital)
Provide affordable housing subsidy for
Slaughterhouse Site RFP located at 495 11th Ave. This 100% permanently affordable development will satisfy two commitments made by the City in the rezoning for affordable apartments to be built on Site M, and on the 20th Street sanitation parking space. It will be affordable at 80 to 165% of AMI. The project will have a height of 45 stories, will include an affordable supermarket and 0ver 75 units of Supportive Housing.
495 11
Avenue, Manhattan, New York, NY
CS
EDC
Make infrastructure investments that will support growth in local business districts
Continue to fund the creation of Block 5 and 6 of Bella Abzug Park by issuing tax-exempt bonds by HYDC.
CS
HPD
Provide more housing for medium income households
Provide adequate capital subsidy for 100% permanent middle and moderate affordable housing at the HPD developments committed to in the Western Rail Yards Points of Agreements. DEP Site: 705 10th Avenue MTA Site: 806 9th Avenue
CS
NYCHA
Renovate or upgrade public housing developments
Elliot-Chelsea (425 West 25th Street) Fund and complete following projects: Fund and complete renovations of all building lobbies. Cameras in front of the Hudson Guild pathway and playground 441 West 26th Street
425 West 25th Street
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/41
DOB
Expand code
Expand funding for Dept. of Buildings Code
enforcement
Enforcement to provide 1-2 dedicated inspector
for Special District enforcement to ensure
compliance of Land Use regulations in the
Special Districts. In addition, raise the priority of
updating the DOB website so applications for
improper demolitions and certificates of non-
harassment in special districts can be flagged
earlier.
14/41
DOB
Expand code
Provide additional funding for Dept. of Buildings
enforcement
enforcement inspectors for non-compliant ADA
entrances.
22/41
EDC
Expand programs
Fund study to review moving the heliport at
for certain
West 30th Street in the Hudson River Park.
industries, e.g.
fashion, film,
advanced and food
manufacturing, life
sciences and
healthcare
23/41
DCP
Study land use and
Implement the extension of the Special West
zoning to better
Chelsea District (SWCD) to adjacent areas. It is
match current use
now time, nine years after the creation of the
or future
SWCD, for the City to follow through with the
neighborhood
promises it made including those listed then as
needs
Points of Agreement. In particular, expand the
SWCD to the West from 11th Avenue to 12th
Avenue at West 26th Street to West 28th Street.
The Department of City Planning must re-
examine the unforeseen problems, which have
emerged as development rises in the SWCD
creating pressures on adjacent areas like West
14th Street that might necessitate new zonings
or the expansion of the SWCD itself.
24/41
DCP
Other zoning and
Modify the special permit process for off-street
land use requests
parking in new residential buildings. The current
methodology for calculating parking for special
permit findings does not reflect the realities of
CD4, particularly in West Chelsea. The
methodology encourages the building of
parking spaces which attract more cars in an
area that is already overwhelmed by traffic and
has excellent mass transit.
26/41
DOB
Expand code
Increase funding for staffing to pursue with due
enforcement
diligence the collection of outstanding fines
owed by repeat violators, and enforce unsafe
and after hours construction compliance is
essential. In particular, Increase the number of
inspectors, community coordinators, and
administrative associates.
27/41
DCP
Other zoning and
Fund study on impact of exempting cultural not-
land use requests
for-profit organizations from real estate taxes.
28/41
DCP
Other zoning and
Study the effects of the transfer of Transferable
land use requests
Development Rights (TDRs) from churches and
other non-profit entities on their surrounding
communities. Develop methods to control the
development of out-of-scale buildings based on
these TDRs.
29/41
DCP
Study land use and
Study the rezoning of the midblock areas
zoning to better
between Sixth and Eighth Avenues, between
match current use
West 14th and West 26th Streets to control the
or future
development of out-of-scale buildings and to
neighborhood
preserve a continuous street wall.
needs
30/41
DOB
Assign additional
Expand after-hour inspections by additional
building inspectors
funding for inspectors.
(including
expanding training
programs)
31/41
DCP
Other zoning and
Fund study on the impact of not requiring
land use requests
commercial gyms to obtain a Special Permit for
Physical Culture Establishments.
34/41
DOB
Expand code
Continued Support: Expand funding for the
enforcement
enforcement of the regulations on illegal hotel
use. Illegal hotel use continues to exist and
expand in the CD4 district. The NYS Attorney
General report Airbnb in the City, found that
CB4 is one most trafficked neighborhoods for
illegal hotel use, and of the three community
districts that collectively account for 41% of
Airbnbs revenue in NYC. Illegal hotel use
depletes our affordable housing stock,
incentives tenant harassment and creates
quality of life issues for existing tenants.
Increase OSE resources including lawyers,
investigators and inspectors dedicated to
bringing litigation against illegal hotel use,
particularly in the most problematic districts.
TRANSPORTATION
Manhattan Community Board 4
image
M ost Important Issue Related to Transportation and Mobility
Pedestrian safety
Trucks and buses are a looming presence on residential streets. The current on-street facilities for buses and commuter vans are inadequate, and environmental pollution is a constant quality of life complaint and threat to public health. Due to sidewalk obstructions, pedestrians are forced to compete with each other for every inch of walkable sidewalk and are often forced to walk in traffic. Compounding he issue, pedestrian ramps are poorly maintained. Crosstown bike lanes are more popular and more dangerous than ever; protected bike lanes are needed in order to adequately protect riders. the scores of workers coming to and from Brooklyn to our tech companies need additional modes of transportation, such as ferry service between Brooklyn and the west side. Bus service continues to deteriorate: more dedicated bus lines are needed on 9th and 10th Avenue . There is less and less space for charter bus parking and it is urgent to build the garage that was promised during the Hudson Yards rezoning.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Trucks and buses are a looming presence on residential streets. The current on-street facilities for buses and commuter vans are inadequate, and environmental pollution is a constant quality of life complaint and threat to public health. Due to sidewalk obstructions, pedestrians are forced to compete with each other for every inch of walkable sidewalk and are often forced to walk in traffic. Compounding the issue, pedestrian ramps are poorly maintained. Crosstown bike lanes are more popular and more dangerous than ever; protected bike lanes are needed in order to adequately protect riders. . There is less and less space for charter bus parking and it is urgent to build the garage that was promised during the Hudson Yards rezoning.
Needs for Transit Services
Bus service continues to deteriorate: more dedicated bus lanes are needed on 9th Avenue and 42nd Street. with numerous hi rise construction already completed on the far west side, buidling the West 41st Street subway sttaion is becoming inmperative to reduce jitneys proliferation and congestion. Scores of workers coming to and from Brooklyn need additional modes of transportation, such as ferry service between Brooklyn and the west side. More taxis and for hire vehicles are needed to improve transt for ADA and seniors.
image
Priority
Agency
Request
Explanation
Location
6/41
DOT
Improve traffic and
Convert painted pedestrian islands, extensions
pedestrian safety,
and neck downs to permanent concrete
including traffic
structures (10th Avenue and 11th Avenue)
calming (Capital)
including tree pits and trees. As committed by
NYC DOT in the 11th Avenue project: 10th
Avenue: 3 islands - From West 52 Street to West
60 Street. 11th Avenue: West 58 Street and
West 59 Street – 2 concrete median islands and
West 57 Street to West 42 Street - convert 25
painted islands to concrete.
15/41
DOT
Repair or construct
Fulfill the city commitment to install ADA
new curbs or
compliant ramps at intersections - Dyer Ave and
pedestrian ramps
West 34th Street - North side of West 42 Street
and Dyer Avenue - Ramps are missing at this
location. In addition, install up to 30 audible
pedestrian signals, especially at West 15th
Street and 9th Avenue.
20/41
DOT
Roadway
Resurface 8th Avenue bike lane. The bike lane is
maintenance (i.e.
very damaged with many potholes and the
pothole repair,
green paint and stripping is warn off.
resurfacing, trench
restoration, etc.)
25/41
DOT
Reconstruct streets
Reconstruct Ninth Avenue from West 55th to
9th Ave West
34th Streets to implement changes resulting
55th St West
from the DOT study now underway. Implement
34th St
neck downs on each street block directly to the
East and West of Ninth Avenue.
29/41
NYCTA
Other transit
Work with MTA to design the West 41st and
West 41 St
infrastructure
10th Ave station for the  7. And extend 7 to
10th Ave 11th
requests
service additional communities.
Ave
36/41
DOT
Repair or construct
Fulfill the city commitment to reduce radius of
Dyer Avenue
new curbs or
West 35th Street turn at Dyer Avenue (Hudson
West 35th St
pedestrian ramps
Yards rezoning follow up actions, Western Rail
yards negotiations.
CS
NYCTA
Other transit
MCB4 continues support for funding for
infrastructure
improvements to the Para-transit system and
requests
Access-a-Ride service. Including purchase of
additional vehicles, vehicle upgrades, and better
customer service training.
Priority
Agency
Request
Explanation
Location
8/41
DOT
Improve traffic and
Fund Study on pedestrian safety at 11th Avenue
11th Avenue
pedestrian safety,
from West 20th Street to West 24th Street.
West 20th
including traffic
Street West
calming (Expense)
23rd Street
9/41
DOT
Conduct traffic or
Study sidewalk capacity and pedestrian demand
8th and 9th
parking studies
along the balance of 8th Avenue from 34th
Ave West
Street to 38th street and 43rd Street to 50th
34th St West
streets; and 9th Avenue North of 34th Street. In
59th St
particular, study space effectively allocated to
pedestrians, sidewalk obstructions and
pedestrian volumes resulting in a true
pedestrian level of service. Make
recommendation to address congestion and
lack of pedestrian flow.
12/41
DOT
Conduct traffic or
Study the location and construction of a tour
parking studies
and charter Bus Garage. In the Hudson Yards
rezoning in 2005, the city identified the need for
a garage to accommodate additional off-street
parking sites for tourist and commuter buses
and vans, services, and waiting "black cars".
Currently these buses and cars layover on the
street and idle. According to the New York City
Department of Health and Mental Hygiene, this
community suffers the third highest levels of air
pollution in the five boroughs.
15/41
DOT
Conduct traffic or
Conduct Study of Protected Bike Lane on 10th
10th Avenue
parking studies
Avenue from West 13th to West 59th Streets.
West 13th
Street West
59th Street
19/41
DOT
Provide new bike
Study new protected crosstown bike lanes in
lanes
midtown - between West 33rd Street and West
36th Street.
20/41
DOT
Address traffic
Study the creation of bus lane on 9th Avenue
9th Ave 44th
congestion
from 44th street to 57th street to increase the
St 57th St
M11 reliability and consistency of its service.
37/41
NYCTA
Other transit service
Continued Support: NYC DOT Para-Transit
requests
Servcie Access-A-Ride vehicles have GPS
capabilities but are not always utilized due to
lack of training. Continue funding for Training
for all staff to utilize the GPS technology and
enhanced customer service.
39/41 DOT Address traffic
congestion
Continued Support: Continue to fund the Conversion and needed enforcement of the change of 11th Avenue to one-way southbound from 57th Street to 42nds Street Reduce congestion by re-balancing traffic between 9th and 11th Avenue as recommended in the Hells Kitchen study. Continue to fund pedestrian safety features and a protected bus lane. Make Eleventh Avenue one-way southbound from West 57th Street to West 44th Street to ensure the reliability of the new bus route.
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 4
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Library facilities and access
Although significant progress has been made in recent years relating to the number of parks and open spaces in MCD4, the huge influx in the number of residents to the District means that even these new spaces are overburdened. Further, the facilities of the Department of Parks and Recreation in our District provide other services, as emergency shelters, and providing support for other city agencies. Thus, support for our parks cannot be seen as an afterthought, but must be prioritized.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
While many of the parks in our District have had some upgrades in recent years, much work still needs to be done. Restroom facilities in three major parks have not been upgraded in years, while other recreational facilities have been. This has resulted in bringing more people into our parks but not providing adequate restroom facilities. These restrooms must be upgraded. Such upgrades will also allow DPR to provide a full-time, on-site park keeper to address constituents' concerns, provide security and perform routine maintenance. Funding should also be dedicated to support Green Thumb Community Gardens and pruning for street trees. Funding should also be directed towards full-time gardeners, maintenance workers, PEP officers, as well as seasonal aides and playground associates for the summer.
Needs for Cultural Services
According to a study conducted by Innovative Theater Foundation and Columbia University in the Fall of 2008, close to 30% of performance spaces have closed within MCD4 in the last nine years due to development pressures. The presence of performing arts groups develop and give voice to new talent in areas of writing, performing, dancing, choreography, and directing. This vitalizes our New York City and our community, both culturally and commercially, on a block-to-block level. In addition, support services for theater and other artistic services within MCD4 in the areas of rental storage space for art, costumes, scenery, lighting, and rehearsal studios have long been located throughout Chelsea and Clinton/Hell's Kitchen. These services are also losing viable space due to development and real estate costs. The money generated from these industries provides employment and maintains the artistic life of the city. The Board is concerned with the loss of artists' studios in the District and the displacement of working artists.
Needs for Library Services
Supporting and expanding the role of libraries as continuous learning center, job centers, and community connective tissue.
Needs for Community Boards
Since the 1990s, budgets (outside of personnel services) have not been re-evaluated for inflation.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
9/41
NYPL
Create a new, or
Fund $400,000 for needed roof repair of
742 10th
renovate or upgrade
Columbus Avenue Branch Library.
Avenue
an existing public
library
11/41
DPR
Reconstruct or
Fund the renovation and construction of the
upgrade a park or
bathrooms at the following parks: Dewitt
amenity (i.e.
Clinton Park - West 52/54 from 11/12 Ave
playground, outdoor
Matthews-Palmer Park - 445 W 45th St Chelsea
athletic field)
Park - 450 West 27th Street. Without new and
updated bathrooms these parks can not live up
to their potential nor can they support needed
fixed post park staff.
16/41
DPR
Reconstruct or
Fund complete renovation of Gertrude Kelly
320 West
upgrade a park or
Playground and park area.
17th Street
amenity (i.e.
playground, outdoor
athletic field)
21/41
DPR
Reconstruct or
Increase funding additional $1 Million to
West 26
upgrade a park or
renovate Penn South Basket Ball Court
Street 8/9
amenity (i.e.
Avenues
playground, outdoor
athletic field)
24/41
NYPL
Provide more or
Muhlenberg Branch: Fund $500,000.00 to
better equipment to
replace HVAC system with energy efficient
a library
model.
26/41
DPR
Other park
The popularity of the NYC Parks has increased
maintenance and
the amount of refuse left in Manhattan parks.
safety requests
Manhattan parks require it's own Packer Truck
to transport the refuse.
27/41
DPR
Other street trees
Increase funding for street tree pit guards to
and forestry
include existing trees. A number of existing tree
services requests
pits have been identified as dangerous for
pedestrians and for low vision individuals in
particular. More tree guards should be used to
resolve this problem, which presents a real
danger to low-vision pedestrians.
28/41
DPR
Reconstruct or
Renovate Hell's Kitchen Park.
10 Avenue,
upgrade a park or
Manhattan,
playground
New York, NY
30/41
DPR
Reconstruct or
upgrade a park or playground
Renovate Chelsea Park field running track.
West 27
Street, Manhattan,
New York, NY
41/41
DPR
Provide new type
Increase funding for Fitness Recreation
and/or specific type
Specialists
of program
CS
DPR
Provide a new or
Continue to complete the design for a new park
10th Ave
expanded park or
at West 48th Street and 10th Avenue as
West 48th St
amenity (i.e.
committed to during Western Rail Yard rezoning
West 49th Str
playground, outdoor
and negotiations.
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
10/41
DCLA
Support nonprofit
Dedicate funding to Department of Cultural
789 10
cultural
Affairs for 52nd Street Project, 789 10th Avenue
Avenue,
organizations
for the following programs: - Playwriting and
Manhattan,
performing programs from children ages 10-18 -
New York, NY
New Platforms: Additional arts programs to
introduce young people to art forms other than
theater - Smart Partners: Mentorship program,
averaging 50-52 pairs per year.
11/41
DPR
Other park
Increase funding for fixed post staff at Dewitt
maintenance and
Clinton Park Mathew Palmer Park, and Chelsea
safety requests
Park. The parks in the CD4 district that have
comfort stations should have fixed post staff to
address constituents' concerns, provide security
and perform routine maintenance of that park.
13/41
DCLA
Support nonprofit
Dedicate funding to Department of Cultural
23-23 48
cultural
Affairs to fund the following IndieSpace
Street,
organizations
Programs within the Community District 4
Queens, New
borders: - One on one theatre organization
York, NY
consultations - Additional workshops - Panel
discussions and events
38/41 DCLA Support nonprofit
cultural organizations
Continued Support: Fund the development of study and database for accessibility of Theatre groups for accessible rehearsal space sharing for the purposes of preserving and creating affordable space for small to mid-sized art and theatrical groups, and other non-profit performance and visual art organizations. MCB4 has long avocated for the creation of a subsidy program, as part of the overall budget of the Department of Cultural Affairs as well as through the theater Sub-district. A database and the subsidy program would help ensure permanent locations for existing and displaced nonprofit arts entities.
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/41
HPD
Other affordable
Provide adequate capital subsidy for the HPD
525 W 55th
housing programs
development at the NYCHA Harborview Terrace
St
requests (capital)
site located at West 55 Street and 10th Avenue
and designate a developer from the most recent
RFP process.
2/41
DHS
Provide new
Downsize the BRC shelter at 131 West 25th
homeless shelters or
Street in exchange establish a new family with
SROs
children shelter.
3/41
NYCHA
Renovate or
Harborview Terrace (525 West 55th Street, New
525 West
upgrade public
York, NY 10019) - Prioritize Funding for the
55th Street
housing
following items: Roof repair, Boiler upgrade, and
developments
new building entrance doors,
4/41
NYCHA
Install security
Fulton Houses (421 West 17th Street New York,
cameras or make
NY 10011): Install security cameras on the roof
other safety
of all buildings.
upgrades (Capital)
5/41
NYCHA
Renovate or
Fulton Development (421 West 17th Street New
421 West
upgrade public
York, NY 10011): Increase funding to
17th Street
housing
renovate\upgrade the Elevators at 418-419
developments
West 17 Street and 420 West 19 Street.
6/41
DOT
Improve traffic and
Convert painted pedestrian islands, extensions
pedestrian safety,
and neck downs to permanent concrete
including traffic
structures (10th Avenue and 11th Avenue)
calming (Capital)
including tree pits and trees. As committed by
NYC DOT in the 11th Avenue project: 10th
Avenue: 3 islands - From West 52 Street to West
60 Street. 11th Avenue: West 58 Street and
West 59 Street – 2 concrete median islands and
West 57 Street to West 42 Street - convert 25
painted islands to concrete.
7/41
SCA
Renovate interior
Expand funding to the School Construction
building component
Authority for security cameras in the following
schools: P.S. 33 Chelsea Prep – 281 9th Avenue
P.S. 51 Elias Howe – 525 West 44th Street P.S.
111 Adolph S. Ochs – 440 West 53rd Street P.S.
212 Midtown West – 328 West 48th Street
8/41
NYPD
Other NYPD
Relocate the Tow Pound from Pier 76: The
facilities and
Hudson River Park Act calls for the City to use its
equipment requests
best efforts to find a new location for the
(Capital)
existing tow pound so that Pier 76 can be
developed as 50% parkland and 50% compatible
commercial use. We urge the City to consider
alternatives as soon as possible so that Pier 76
can take its rightful place as part of Hudson
River Park.
9/41
NYPL
Create a new, or
Fund $400,000 for needed roof repair of
742 10th
renovate or upgrade
Columbus Avenue Branch Library.
Avenue
an existing public
library
10/41
SCA
Renovate or
Expand funding to SCA to refurbish two science
525 West
upgrade a high
labs for Manhattan Bridges High School at 525
50th Street.
school
West 50th Street.
11/41
DPR
Reconstruct or
Fund the renovation and construction of the
upgrade a park or
bathrooms at the following parks: Dewitt
amenity (i.e.
Clinton Park - West 52/54 from 11/12 Ave
playground, outdoor
Matthews-Palmer Park - 445 W 45th St Chelsea
athletic field)
Park - 450 West 27th Street. Without new and
updated bathrooms these parks can not live up
to their potential nor can they support needed
fixed post park staff.
12/41
NYCHA
Renovate or
Harborview Terrace (525 West 55th Street, New
Harborview
upgrade public
York, NY 10019): Increase funding for the
Terrace
housing
following items: upgraded lighting for public
Building 1,
developments
hallways, retiling public hallways, new hoper
Manhattan,
doors (garbage shoot doors), renovate garbage
New York, NY
storage area for senior building, and new
apartment front doors.
13/41
NYCHA
Renovate or
Fulton Development (421 West 17th Street New
9 Avenue,
upgrade public
York, NY 10011): Increase funding to
Manhattan,
housing
renovate\upgrade the following items: new
New York, NY
developments
sump pit\pumps for the following buildings: 401
West 16 Street; 420 West 19 street; 434 West 17
Street.
14/41
HPD
Other affordable
Provide adequate capital subsidy for the
500 & 560
housing programs
Multifamily Preservation Loan Program (MPLP)
West 52nd St
requests (capital)
and the Senior Affordable Rental Apartments
(SARA) for the following affordable housing
projects: 560 West 52nd Street - (MPLP) 500
West 52nd Street - (SARA)
15/41
DOT
Repair or construct
Fulfill the city commitment to install ADA
new curbs or
compliant ramps at intersections - Dyer Ave and
pedestrian ramps
West 34th Street - North side of West 42 Street
and Dyer Avenue - Ramps are missing at this
location. In addition, install up to 30 audible
pedestrian signals, especially at West 15th
Street and 9th Avenue.
16/41
DPR
Reconstruct or
Fund complete renovation of Gertrude Kelly
320 West
upgrade a park or
Playground and park area.
17th Street
amenity (i.e.
playground, outdoor
athletic field)
17/41
SCA
Renovate or
Provide Funds to make P.S. 111 School entrance,
440 West
upgrade an
gymnasium, and auditorium ADA accessible.
53rd Street
elementary school
Upgrade pre-k bathrooms and sink areas.
18/41
SCA
Renovate or
Continue funding for renovation of the following
281 9
upgrade an
areas and items at P.S. 33: bathrooms; kitchen
Avenue,
elementary school
cafeteria; PA system; security cameras.
Manhattan,
New York, NY
19/41
SCA
Renovate or
P.S.35M: Increase funding of $100,000.00 to
317 West 52
upgrade a high
upgrade library to include also computer and
Street
school
media lab.
20/41
DOT
Roadway
Resurface 8th Avenue bike lane. The bike lane is
maintenance (i.e.
very damaged with many potholes and the
pothole repair,
green paint and stripping is warn off.
resurfacing, trench
restoration, etc.)
21/41
DPR
Reconstruct or
Increase funding additional $1 Million to
West 26
upgrade a park or
renovate Penn South Basket Ball Court
Street 8/9
amenity (i.e.
Avenues
playground, outdoor
athletic field)
22/41
DSNY
Provide new or
Increase funding to purchase the DSNY District 4
increase number of
garage an additional holster to clear snow and
sanitation trucks
salt from the additional bike lanes in the district.
and other
equipment
23/41
EDC
Invest in capital
Fund a Brooklyn\Chelsea Ferry service to serve
projects to improve
the large workers population in the lower part
access to the
of our district. Location Site Street: 11th
waterfront
Avenue/Pier 57 at West 14th Street.
24/41
NYPL
Provide more or
better equipment to a library
Muhlenberg Branch: Fund $500,000.00 to
replace HVAC system with energy efficient model.
25/41
DOT
Reconstruct streets
Reconstruct Ninth Avenue from West 55th to
9th Ave West
34th Streets to implement changes resulting
55th St West
from the DOT study now underway. Implement
34th St
neck downs on each street block directly to the
East and West of Ninth Avenue.
26/41
DPR
Other park
The popularity of the NYC Parks has increased
maintenance and
the amount of refuse left in Manhattan parks.
safety requests
Manhattan parks require it's own Packer Truck
to transport the refuse.
27/41
DPR
Other street trees
Increase funding for street tree pit guards to
and forestry
include existing trees. A number of existing tree
services requests
pits have been identified as dangerous for
pedestrians and for low vision individuals in
particular. More tree guards should be used to
resolve this problem, which presents a real
danger to low-vision pedestrians.
28/41
DPR
Reconstruct or
Renovate Hell's Kitchen Park.
10 Avenue,
upgrade a park or
Manhattan,
playground
New York, NY
29/41
NYCTA
Other transit
Work with MTA to design the West 41st and
West 41 St
infrastructure
10th Ave station for the  7. And extend 7 to
10th Ave 11th
requests
service additional communities.
Ave
30/41
DPR
Reconstruct or
Renovate Chelsea Park field running track.
West 27
upgrade a park or
Street,
playground
Manhattan,
New York, NY
31/41
SCA
Renovate or
Expand funding to SCA for Wifi\Internet
250 West
upgrade an
upgrade for Liberty High School.
18th Street
elementary school
32/41
SCA
Renovate or
Arts & Craftsmanship High School: Fund 10
439 West
upgrade a high
Smartboards for classrooms.
49th Street
school
33/41
NYPD
Provide a new NYPD
facility, such as a new precinct house or sub-precinct
Per the city charter which requires matching of
service delivery with other administrative boundaries, adjust the boundaries of two existing precincts (midtown north and 10th Precinct) to serve all of CD4. This would reduce the number of precincts from presently 4 to 2 . Resources would be reallocated between precincts. As the population has grown by 17% and residential areas now extend to Hudson Yards and to 11th Avenue, the remaining precincts boundaries and resources should be readjusted to serve the new population to the West in a cohesive manner for the residents.
34/41
SCA
Renovate or upgrade a high school
Increase additional funding of $300,000 for NYC Lab School to complete renovation of third floor student and staff bathrooms.
333 West 17th Street
35/41
SCA
Renovate or upgrade an elementary school
Increase additional funding of $100,000 for
P.S.51 to complete and Earth Science Lab.
525 West 44 Street, Manhattan, New York, NY
36/41
DOT
Repair or construct new curbs or pedestrian ramps
Fulfill the city commitment to reduce radius of West 35th Street turn at Dyer Avenue (Hudson Yards rezoning follow up actions, Western Rail yards negotiations.
Dyer Avenue West 35th St
37/41
SCA
Renovate or upgrade a high school
Increase additional fuding for building wide electrical upgrade to High School for Fashion Industries.
225 West 24 Street
38/41
SCA
Renovate interior building component
Increase additional funding for elevator replacement at the Bayard Rustin Educational Complex.
351 West 18 Street, Manhattan, New York, NY
39/41
SCA
Renovate or upgrade an elementary school
Increase additional funding for new security door alarms at P.S. 11.
320 West 21 Street, Manhattan, New York, NY
40/41
SCA
Renovate interior building component
Increase funding for auditorium air conditioning for Business of Sports and Graphic Arts Campus.
439 West 49 Street, Manhattan, New York, NY
41/41
DPR
Provide new type and/or specific type of program
Increase funding for Fitness Recreation Specialists
CS
DEP
Evaluate a public
Continued Support: MCB4 lauds the
location or property
administrations NYC Green Infrastructure
for green
Program and we ask that EDC and other agency
infrastructure, e.g.
partners, including the Federal government
rain gardens,
design, construct and maintain a variety of
stormwater
sustainable green infrastructure practices within
greenstreets, green
MCD4. A portion of the FY 2021 budget should
playgrounds
be earmarked to conduct a feasibility study of
measures that can limit the damage of storm
surges including flood gates. It has been
estimated that the cost to design and construct
flood gates at Verrazano Narrows, Arthur Kill
and Throgs Neck is approximately $10 billion
CS
HPD
Other affordable
Provide affordable housing subsidy for
495 11
housing programs
Slaughterhouse Site RFP located at 495 11th
Avenue,
requests (capital)
Ave. This 100% permanently affordable
Manhattan,
development will satisfy two commitments
New York, NY
made by the City in the rezoning for affordable
apartments to be built on Site M, and on the
20th Street sanitation parking space. It will be
affordable at 80 to 165% of AMI. The project
will have a height of 45 stories, will include an
affordable supermarket and 0ver 75 units of
Supportive Housing.
CS
EDC
Make infrastructure
Continue to fund the creation of Block 5 and 6 of
investments that
Bella Abzug Park by issuing tax-exempt bonds by
will support growth
HYDC.
in local business
districts
CS
HPD
Provide more
Provide adequate capital subsidy for 100%
housing for medium
permanent middle and moderate affordable
income households
housing at the HPD developments committed to
in the Western Rail Yards Points of Agreements.
DEP Site: 705 10th Avenue MTA Site: 806 9th
Avenue
CS
NYCHA
Renovate or
Elliot-Chelsea (425 West 25th Street) Fund and
425 West
upgrade public
complete following projects: Fund and complete
25th Street
housing
renovations of all building lobbies. Cameras in
developments
front of the Hudson Guild pathway and
playground 441 West 26th Street
CS
NYPD
Other NYPD
Continued Support: Continue to fund study to
facilities and
review moving the tow pound on Pier 76 at
equipment requests
West 34th Street. Study should explore how
(Capital)
these sites will support the construction and
maintenance of sections of Hudson River Park
and bring some predictability to the
development community for sites one block east
of the Park.
CS
FDNY
Provide new
Continue to fund the permanent relocation of
facilities such as a
the West 23rd Street 7 EMS station (FDNY) to
firehouse or EMS
West 29th Street (11/12 Ave) MCB4 specifically
station
requests immediate funding for a relocation of
the EMS station that is temporarily located on
W. 23rd Street and Tenth Avenue. The current
temporary location was never designed for the
heavy use the EMS is placing on this site. The
current small, cramped location adjacent to
residential buildings has resulted in noise and
exhaust pollution. The site is unsafe for both
FDNY personnel and nearby residents and
pedestrians.
CS
NYCTA
Other transit
MCB4 continues support for funding for
infrastructure
improvements to the Para-transit system and
requests
Access-a-Ride service. Including purchase of
additional vehicles, vehicle upgrades, and better
customer service training.
CS
SCA
Provide a new or
With schools operating a full or over capacity,
expand an existing
we need to identify sites to build new district
middle/intermediate
middle schools. Development on the west side,
school
including Hudson Yards, will bring in an
extraordinary number of students, in a short
time frame.
CS
SCA
Renovate or
PS11 Captial Needs: Complete Scope and fund
320 West 21
upgrade an
Handicap Lift for universal access to the
Street
elementary school
building. This school of approximately 950
students is not yet handicap accessible.
CS
DPR
Provide a new or
Continue to complete the design for a new park
10th Ave
expanded park or
at West 48th Street and 10th Avenue as
West 48th St
amenity (i.e.
committed to during Western Rail Yard rezoning
West 49th Str
playground, outdoor
and negotiations.
athletic field)
CS
SCA
Renovate or
Food and Finance High School: Complete
525 West
upgrade a high
needed funding of $2 million for a chemistry
50th Street
school
lab.
CS SCA Renovate or upgrade a high school
High School for Environmental Studies: Complete funding for $100,000 shortfall for new roof project.
444 West 56 Street
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/41
DOB
Expand code
Expand funding for Dept. of Buildings Code
enforcement
Enforcement to provide 1-2 dedicated inspector
for Special District enforcement to ensure
compliance of Land Use regulations in the
Special Districts. In addition, raise the priority of
updating the DOB website so applications for
improper demolitions and certificates of non-
harassment in special districts can be flagged
earlier.
2/41
DHS,
Other homelessness
Include additional funding for after placement
HRA
prevention program
support staff for homeless families that are
request
selected through the DHS family preference for
buildings receiving 421a benefits. These
buildings are typically luxury/market buildings
with no onsite supportive services. Both the
families coming from the DHS shelter system
and the building management will benefit from
additional onsite and or light touch supportive
services to assist the family to acclimate with
the transition.
3/41
DHS
Expand
Expand funding for support for families and
homelessness
adults exiting shelter to decrease homeless
prevention
recidivism. In particular, expand, GED
programs 1
completion programs, job training, and
continuity of social services with additional
caseworkers for at least 3 months after exiting
shelter.
4/41
DFTA
Increase home
Expand existing programs for Seniors (DFTA)
delivered meals
Meal programs at the following locations: Penn
capacity
South NORC - 290 9th Ave Encore Community
Services - 239 West 49th Street The SAGE Center
Midtown - 305 Seventh Avenue
5/41
DSNY
Provide more
Baseline the $8 million for DSNY staff overtime
frequent litter
for additional basket pick up and expand
basket collection
funding to reach four basket pick up crews in
total.
6/41
DEP
Investigate air
Increase funding to increase pollution monitors
quality complaints
in CD4. According to the New York City
at specific location
Department of Health and Mental Hygiene, this
community suffers the third highest levels of air
pollution in the five boroughs. Air pollution
increases incidents of chronic lung disease.
Given the proximity of the Chelsea and
Clinton/Hells Kitchen neighborhoods to the
Lincoln Tunnel and to the Port Authority Bus
Terminal, MCD4 most likely is at particular risk
from unhealthy air.
7/41
DOHMH
Provide more
As referenced in the 2018 NYC DOHMH
HIV/AIDS
Community Health Profile for Clinton and
information and
Chelsea neighborhoods, CD4 ranks highest in
services
the rate of new HIV diagnoses, almost four
times the citywide rate. Given the demographics
of the resident population in Chelsea and
Clinton, the district requires increased funding
for education, prevention and treatment for the
following organizations: GMHC - 307 W 38th
Street, Ryan Chelsea/Clinton Health Center - 645
10th Ave , and Callen-Lord - 356 West 18th St.
8/41
DOT
Improve traffic and
Fund Study on pedestrian safety at 11th Avenue
11th Avenue
pedestrian safety,
from West 20th Street to West 24th Street.
West 20th
including traffic
Street West
calming (Expense)
23rd Street
9/41
DOT
Conduct traffic or
Study sidewalk capacity and pedestrian demand
8th and 9th
parking studies
along the balance of 8th Avenue from 34th
Ave West
Street to 38th street and 43rd Street to 50th
34th St West
streets; and 9th Avenue North of 34th Street. In
59th St
particular, study space effectively allocated to
pedestrians, sidewalk obstructions and
pedestrian volumes resulting in a true
pedestrian level of service. Make
recommendation to address congestion and
lack of pedestrian flow.
10/41
DCLA
Support nonprofit
Dedicate funding to Department of Cultural
789 10
cultural
Affairs for 52nd Street Project, 789 10th Avenue
Avenue,
organizations
for the following programs: - Playwriting and
Manhattan,
performing programs from children ages 10-18 -
New York, NY
New Platforms: Additional arts programs to
introduce young people to art forms other than
theater - Smart Partners: Mentorship program,
averaging 50-52 pairs per year.
11/41
DPR
Other park
Increase funding for fixed post staff at Dewitt
maintenance and
Clinton Park Mathew Palmer Park, and Chelsea
safety requests
Park. The parks in the CD4 district that have
comfort stations should have fixed post staff to
address constituents' concerns, provide security
and perform routine maintenance of that park.
12/41
DOT
Conduct traffic or
Study the location and construction of a tour
parking studies
and charter Bus Garage. In the Hudson Yards
rezoning in 2005, the city identified the need for
a garage to accommodate additional off-street
parking sites for tourist and commuter buses
and vans, services, and waiting "black cars".
Currently these buses and cars layover on the
street and idle. According to the New York City
Department of Health and Mental Hygiene, this
community suffers the third highest levels of air
pollution in the five boroughs.
13/41
DCLA
Support nonprofit
Dedicate funding to Department of Cultural
23-23 48
cultural
Affairs to fund the following IndieSpace
Street,
organizations
Programs within the Community District 4
Queens, New
borders: - One on one theatre organization
York, NY
consultations - Additional workshops - Panel
discussions and events
14/41
DOB
Expand code
Provide additional funding for Dept. of Buildings
enforcement
enforcement inspectors for non-compliant ADA
entrances.
15/41
DOT
Conduct traffic or
Conduct Study of Protected Bike Lane on 10th
10th Avenue
parking studies
Avenue from West 13th to West 59th Streets.
West 13th
Street West
59th Street
16/41
DFTA
Increase case
As the SARA program expands affordable senior
management
housing, an increase in funding for support
capacity
services are needed to help seniors age-in-place.
The number of people over age 65 began to
increase substantially beginning in 2011 as the
oldest members of the baby-boom generation
reached the 65-year mark. Increase funding for
existing programs for seniors for mental health
services; In-home supportive services;
preventive health; and social services for low
income seniors. Possibly by partnering with
service providers such as Service Program for
Older People (SPOP) and the following
organizations: Ryan Chelsea Clinton Clinic,
GMHC, Hudson Guild Senior Services,
Coffeehouse Senior Center – Project FIND, and
Clinton Senior Center – Project FIND.
17/41
DYCD
Provide, expand, or
enhance after school programs for all grade levels
Provide full funding for all after school programs
in the district.
18/41
NYPD
Assign additional
Fund and deploy 9 traffic officers to increase
uniformed officers
enforcement of the following traffic violations:
vehicular spill-back, parking in no standing, bus
drivers using unauthorized routes, vehicular
idling, bicycles riding on sidewalks, wrong way
on bike paths and streets, running red lights,
Illegal electric bikes, vehicles blocking bike
lanes, and unnecessary honking.
19/41
DOT
Provide new bike
Study new protected crosstown bike lanes in
lanes
midtown - between West 33rd Street and West
36th Street.
20/41
DOT
Address traffic
Study the creation of bus lane on 9th Avenue
9th Ave 44th
congestion
from 44th street to 57th street to increase the
St 57th St
M11 reliability and consistency of its service.
21/41
NYPD
Assign additional
Increase funding to increase salaries and
522 West 44
crossing guards
benefits for Crossing Guard positions.
Street
22/41
EDC
Expand programs
Fund study to review moving the heliport at
for certain
West 30th Street in the Hudson River Park.
industries, e.g.
fashion, film,
advanced and food
manufacturing, life
sciences and
healthcare
23/41
DCP
Study land use and
Implement the extension of the Special West
zoning to better
Chelsea District (SWCD) to adjacent areas. It is
match current use
now time, nine years after the creation of the
or future
SWCD, for the City to follow through with the
neighborhood
promises it made including those listed then as
needs
Points of Agreement. In particular, expand the
SWCD to the West from 11th Avenue to 12th
Avenue at West 26th Street to West 28th Street.
The Department of City Planning must re-
examine the unforeseen problems, which have
emerged as development rises in the SWCD
creating pressures on adjacent areas like West
14th Street that might necessitate new zonings
or the expansion of the SWCD itself.
24/41
DCP
Other zoning and
Modify the special permit process for off-street
land use requests
parking in new residential buildings. The current
methodology for calculating parking for special
permit findings does not reflect the realities of
CD4, particularly in West Chelsea. The
methodology encourages the building of
parking spaces which attract more cars in an
area that is already overwhelmed by traffic and
has excellent mass transit.
25/41
DSNY
Provide or expand
Increase funding for NYC organics collection
NYC organics
program
collection program
26/41
DOB
Expand code
Increase funding for staffing to pursue with due
enforcement
diligence the collection of outstanding fines
owed by repeat violators, and enforce unsafe
and after hours construction compliance is
essential. In particular, Increase the number of
inspectors, community coordinators, and
administrative associates.
27/41
DCP
Other zoning and
Fund study on impact of exempting cultural not-
land use requests
for-profit organizations from real estate taxes.
28/41
DCP
Other zoning and
Study the effects of the transfer of Transferable
land use requests
Development Rights (TDRs) from churches and
other non-profit entities on their surrounding
communities. Develop methods to control the
development of out-of-scale buildings based on
these TDRs.
29/41
DCP
Study land use and
Study the rezoning of the midblock areas
zoning to better
between Sixth and Eighth Avenues, between
match current use
West 14th and West 26th Streets to control the
or future
development of out-of-scale buildings and to
neighborhood
preserve a continuous street wall.
needs
30/41
DOB
Assign additional
Expand after-hour inspections by additional
building inspectors
funding for inspectors.
(including
expanding training
programs)
31/41
DCP
Other zoning and
Fund study on the impact of not requiring
land use requests
commercial gyms to obtain a Special Permit for
Physical Culture Establishments.
32/41
DSNY
Other cleaning
requests
Baseline funding for DSNY staff for an additional
two crews to bring residential and recycling pick-up service on Thursday and Saturday equivalent to the rest of the week.
33/41
DOE
Assign more non-
Expand and Baseline funding for Licensed
teaching staff, e.g.,
School Social Workers in all schools within
to provide social,
Manhattan School District 2
health and other
services
34/41
DOB
Expand code
Continued Support: Expand funding for the
enforcement
enforcement of the regulations on illegal hotel
use. Illegal hotel use continues to exist and
expand in the CD4 district. The NYS Attorney
General report Airbnb in the City, found that
CB4 is one most trafficked neighborhoods for
illegal hotel use, and of the three community
districts that collectively account for 41% of
Airbnbs revenue in NYC. Illegal hotel use
depletes our affordable housing stock,
incentives tenant harassment and creates
quality of life issues for existing tenants.
Increase OSE resources including lawyers,
investigators and inspectors dedicated to
bringing litigation against illegal hotel use,
particularly in the most problematic districts.
35/41
DEP
Investigate noise
Continued Support: Enhance or expand noise
complaints at
pollution abatement and enforcement
specific location
programs: Additional resources are needed for
night inspections when the noise pollution is
most acute and invasive.
36/41
DHS,
Provide, expand, or
Continued Support: Expand HRA Anti-
HRA
enhance anti-
Harassment Legal Services to Manhattan
eviction legal
Community District 4. These important
services
homeless prevention programs are only
provided in East Harlem and Inwood
neighborhoods in Manhattan. While the
administration is committed to supporting legal
services to prevent harassment in districts that
are to be rezoned in the near future, community
districts such as CD4 which was subject to three
large rezonings in the past decade, need
enhanced funding to mitigate the increasing
amount of tenant harassment due to the
increasing development pressures as a result of
the rezoning. Enhanced legal services are
needed to represent individual tenants and
tenant associations in Manhattan CD4.
37/41
NYCTA
Other transit service
Continued Support: NYC DOT Para-Transit
requests
Servcie Access-A-Ride vehicles have GPS
capabilities but are not always utilized due to
lack of training. Continue funding for Training
for all staff to utilize the GPS technology and
enhanced customer service.
38/41
DCLA
Support nonprofit
Continued Support: Fund the development of
cultural
study and database for accessibility of Theatre
organizations
groups for accessible rehearsal space sharing
for the purposes of preserving and creating
affordable space for small to mid-sized art and
theatrical groups, and other non-profit
performance and visual art organizations. MCB4
has long avocated for the creation of a subsidy
program, as part of the overall budget of the
Department of Cultural Affairs as well as
through the theater Sub-district. A database
and the subsidy program would help ensure
permanent locations for existing and displaced
nonprofit arts entities.
39/41
DOT
Address traffic
Continued Support: Continue to fund the
congestion
Conversion and needed enforcement of the
change of 11th Avenue to one-way southbound
from 57th Street to 42nds Street Reduce
congestion by re-balancing traffic between 9th
and 11th Avenue as recommended in the Hells
Kitchen study. Continue to fund pedestrian
safety features and a protected bus lane. Make
Eleventh Avenue one-way southbound from
West 57th Street to West 44th Street to ensure
the reliability of the new bus route.
40/41
DSNY
Provide more
Continued Support: Continue to fund the
frequent garbage or
additional DSNY staff for two additional crews
recycling pick-up
to bring residential and recycling pick-up service
on Thursday and Saturday equivalent to the rest
of the week within the district.
41/41
DHS
Expand street
Continued Support: Continue to expand funding
outreach
for staffing and resources for street homeless
outreach program

