- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Manhattan Community District 5 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1e3lbAzfa0upI6UlXp28JD6RJ6bHxIim3/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1e3lbAzfa0upI6UlXp28JD6RJ6bHxIim3/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Manhattan Community District
5
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Manhattan Community Board 5
image
Address: 450 7th Avenue South, 2109
Phone: (212) 465-0907
Email: office@cb5.org
Website: www.cb5.org
Chair: Vikki Barbero District Manager: Wally Rubin
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Manhattan Community Board Five (CB5) in the heart of Manhattan beats with the pulse of the City. With boundaries extending largely from Lexington to 8th Avenues and 14th to 59th Streets, CB5 is the City’s midtown central business district and the first and last impression of New York City for millions of commuters and tourists who pass through Penn Station, Grand Central Terminal, Times Square, Herald Square, and Union Square every day. All but three subway lines traverse CB5, and with the Port Authority just outside our western border, the district is at the core of the City’s substantial pedestrian and vehicular traffic. New York City experienced a record number of visitors in 2018, over 65.2 million people, and it would be fair to say many of them came to see and experience New York City’s greatest business, tourist, entertainment and industrial landmarks all located within the confines of CB5. In order to service these visitors, hotel construction has boomed within CB5, particularly in the flower district and the Broadway corridor. The Broadway Theater District, the Museum of Modern Art, Radio City Music Hall, Carnegie Hall, Rockefeller Center, and the Flatiron Building are all found within CB5. The District generates substantial sales tax and other revenues for the City as it is home to world-class shopping destinations such as Macy’s, Saks, Tiffany’s, Cartier and Nordstrom (to name but a few). Over half of the district is in a business improvement district and three of the City’s most intensely utilized parks -- Bryant, Madison Square, and Union Square -- are here. Although we have one of the smallest residential populations of any of the City’s 59 Community Boards, we are among the fastest-growing. CB5 experienced explosive growth in both residential and commercial buildings. along with newly expanded footpaths, new traffic patterns and additional bicycle lanes. The extraordinary growth and popularity of CB5 create unique and substantial budgetary needs and corresponding opportunities.
4. TOP THREE PRESSING ISSUES OVERALL
Manhattan Community Board 5
image
The three most pressing issues facing this Community Board are:
Traffic
The top three issues of concern within CB5 are homelessness (along with perceived public safety issues), congestion and sanitation. Congestion, from cars, bicycles and pedestrians, is also of huge concern to those who live and work in CB5. Congestion has arisen from myriad circumstances, including increased construction, newly installed pedestrian walkways, new bicycle paths, increased residential populations and increased visitor counts. Uber, Lyft have added to the yellow cabs and other for hire drivers transversing the district. Increased residential accommodation has created increased delivery needs and idling trucks can be seen at all hours of the day and night throughout the district. Many of the complaints received concerning congestion involve the non-enforcement of already existing regulation. CB5 hopes to see enforcement for cars and trucks that double park or “block the box”, cyclists who travel on the sidewalk or in the opposite direction of traffic, and pedestrians who walk in the bike lane. The closing of 14th street to private traffic is creating new traffic patterns and CB5 would like the City to collect data may be to understand the full impact on the neighborhood and City as a whole. Food carts, news stand, old phone booths and Links NYC all contribute to pedestrian congestion. CB5 discourages the creation of newstands within the District, seeks the removal of old phone booths, encourages enforcement against food carts and hopes that the siting of Links kiosk will be in line with the needs of the District.
Trash removal & cleanliness
Throughout the District, overflowing garbage cans and debris on the streets can be seen, particularly in the west 20s ad the west 50s. Large institutions, BIDS and citizens have all called for additional sanitation services to ensure the removal of street litter and the collection of full litter bins. The increasing tourism and pedestrian traffic in our district has triggered the need for corresponding additional sanitation services including significant improvements in the frequency of corner trash pick-up. Additional litter baskets, recycling and composting bins would aid this problem. CB5 welcomes the goals of the new commercial carting regulation, and hopes that the City will diligently collect data to measure whether this new measure achieves those goals. CB5 is an outlier in terms of its commercial carting needs, so it is particularly concerned at how the regulations, crafted for the City as a whole, will impact the large number of commercial businesses, large and small, throughout the district.
Homelessness
CB5 has seen an increased number of individuals panhandling, loitering and living on the streets of the district; a great number are located on the many plazas within CB5 or near tourist attractions and destinations. BIDS, business owners and residents have become seriously concerned with this situation. While stakeholders recognize that affordable housing is needed within the district to address homelessness, wrap around services, including mental health and substance abuse treatment are also necessary to ensure that those placed in housing can safely stay there. CB5 encourages shelter providers to craft solutions that meet the homeless where they are and to address their concerns regarding possessions, pets and significant others as a means of encouraging the homeless to seek shelter.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Manhattan Community Board 5
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
The most pressing healthcare and human service issue within the district is the provision of services to reduce or prevent homelessness. CB 5 has seen a great increase in the number of homeless people throughout the district. Access to health care and mental health, substance abuse treatment and prevention programs are important to assist in alleviating the plight of those on the streets. CB5 has directed many of its budget requests to these issues. Given the magnitude of the issues and its importance to CB5 stakeholders, the Board is assembling a task force to determine what it may do in its own way to address the problems.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
The most pressing healthcare and Human service issue within the district is the provision of services to reduce or prevent homelessness. While the access to health care and mental health, substance abuse treatment and prevention programs are important to stakeholders within CB5, the great increase in the number of homeless people seen within CB5 mandates that there is a critical need for programs that address this dire situation.
Needs for Older NYs
The district has thousands of households that appear to be aging in place. There was a 26.4% increase in the 65+ age population between 2000 and 2010—bringing the district's population to nearly 6,000.
Needs for Homeless
The district has a growing street homeless levels. For both the street homeless and sheltered homeless, the City must identify pathways to permanent affordable housing for individuals and families. The existing shelter system, along with the emergency shelter program, must be improved to make them a palatable alternative to populations who select to remain on the streets (generally for safety and security reasons), and support services for mental health, substance abuse and placement out of the homeless system are also imperative.
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/40
DHS
Other facilities for
Medical respite programs provide hospitals with
the homeless
an alternative to discharging homeless patients
requests
to the streets or to unequipped shelters.
Medical respite programs seek to improve
transitional care for this population and end the
cycle of homelessness by supporting patients in
access benefits and housing.
3/40
DHS
Provide new
One of the biggest issues we’re seeing right now
homeless shelters or
is that the safe haven system is not meeting the
SROs
demand, especially for women. Currently, there
is no safe haven in NYC exclusively for women,
which is barring many women from coming off
the streets.
15/40
DHS
Upgrade existing
Advocates have indicated that this centralized
facilities for the
system alienates those who would avail of
homeless
shelter and by humanizing the process with
smaller in take centers throughout the city more
people could potentially be removed from our
streets.
16/40
DHS
Provide new
Current safe havens do not allow for people do
homeless shelters or
be housed with animals, except for service or
SROs
emotional support animals. This causes a
significant population to refuse shelter so as not
to be separated from their pets. Advocates
claim that should such a a pet friendly safe
haven would encourage more homeless to avail
of this shelter.
17/40
HHC
Other health care
Only half of the community air survey monitors
facilities requests
are undertaking a 24/7 data collection. In
addition there is a monitoring gap between
Prince Street and 37th Street, particularly in the
southern portions of CB5 near 23rd St./Madison
Square Park and 14th Street, Union Square.
38/40
DHS
Upgrade existing
City has meaningfully increased the funding for
facilities for the
both service initiatives and continues to do so in
homeless
the coming years. However outreach and
informational campaign have not reached many
corners of the city. If the services are not known,
they will not be fully utilized.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
6/24
DHS
Expand street
One of the most pressing issues facing the
outreach
district is homelessness and many of these
individuals congregate in the Pennn Station, FIT
and Port Authority area. These individuals have
myriad problems including mental illness and
drug addiction and additional outreach and
services to work with this population can only
help with these issues.
10/24
DHS,
Other homelessness
IT system handling shelter population requires
HRA
prevention program
modernization to better handle the increased
request
population, specifically storing data
electronically, mapping vacancies across
shelters, storing data around optimal
communities for a resident to be housed in and
creating an algorithm to place ppl in optimal
shelters for their rehabilitation
14/24
DHS
Other request for
These individuals face a myriad of problems,
services for the
programs and outreach from an array of
homeless
sources, both public and private. Establishing
trust and confidence is difficult and the presence
of a licensed professional who can work on a
continuing basis to connect them with existing
resources could be life-changing for these
individuals. This presence also will help leverage
the success of existing programs and
interventions.
15/24
DHS,
Other homelessness
Fund grants that can be awarded to community
HRA
prevention program
boards, business improvement districts, private
request
businesses and not for profit organizations who
organize to create and operate programs in the
district to address issues of street homelessness,
connect individuals and families to resources,
enhance resources available in the district,
study the existence and success of shelters and
other resources, and otherwise address the fact
and perception of increasing numbers of
individuals experiencing homelessness
individuals on the streets in the district.
Homeless is one of the greatest challenges
facing the district. While many agencies and
organizations are attempting to tackle this
problem the encouraging other entities to help
find solutions may create the next best way to
address the issue.
YOUTH, EDUCATION AND CHILD WELFARE
Manhattan Community Board 5
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
Schools and educational facilities are the most important Youth, Education and Child Welfare within the district. We have seen a proliferation of new construction within CB5 but no correlation in the number of school seats being provided. Indeed, CB5 believes that the SEQR system in use is currently outdated and requires reform to reflect adequately the number of school seats needed not only in this district but also throughout the City. Additionally, CB5 believes that funding of the schools within and just outside the district are underfunded in respect to after school programming, internet connectivity, ADA accessibility and mental health care for students, all things that stakeholders within the district have found to be of vital importance.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
CB5 requires an increase in school seats, without disrupting current funding levels for existing schools (both traditional public schools and charters). Charter schools may be able to play a role in this so long as they do not displace what would otherwise be zoned schools seats. We also require more adequate for universal pre-k. Lastly, we hope to see improvement in the quality of food available to NYC students. We urge the NYC DOE to go beyond federal standards for acceptable meals, and also remove junk food in vending machines on campuses.
Needs for Youth and Child Welfare
In collaboration with the Department of Education, we request an increase in after-school programs and childcare.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
21/40 SCA Renovate other site
component
The material currently on the rooftop playground creates a situation where the children cannot play on the surface for a day or two after rain.
image
37/40 SCA Provide technology
upgrade
Currently not enough functional computers for all students to work at once. The provision of laptops will not only allow students to become proficient in the latest technology and allow their teachers to use current tools such as GoogleClassroom and DeltaMath but also allows students to prepare and submit college applications
Expense Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
PUBLIC SAFETY AND EMERGENCY SERVICES
Manhattan Community Board 5
image
M ost Important Issue Related to Public Safety and Emergency Services
Traffic violations and enforcement
Enforcement of violations is the number one public safety issue within CB5. Stakeholders have repeatedly noted that enforcement of violations are critically important and that what is needed within the district is not new legislation and regulation but enforcement of current rules.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
Maintaining levels of highly-skilled NYPD units and increased vigilance on grand larceny. As the highly-congested, prominent tourism hub, Homeland Security, NYPD and Port Authority have already determined that Midtown is an area the requires hyper-vigilance and thus we already have elite trained squads for counterterrorism and the like. Obviously, we believe that this shall remain, but we also understand that the strategic need for those kinds of crime prevention are determined by a coalition of city, state, and federal government and law enforcement agencies.
Therefore, we feel for this exercise of budget needs it is more important to drill down on the local compstats. Grand larceny (e.g. pickpockets, street scams, robbery etc) is the largest issue facing CB5 and thus increased funding to combat this issue would be prudent.
Needs for Emergency Services
Growing community requires adequate emergency services With the many new residential and commercial developments coming online in and on the borders of CB5, the emergency services may become overly burdened as the ratio of person to EMS vehicle changes and the City must be cognizant of this and monitor for any increased budget needs. FDNY has asked for $280,000 to install additional fire alarms across the city and CB5 supports that request, in addition to their desire for additional funds for more trainings and CPR trainings.
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
5/24
NYPD
Increase resources
There are currently three construction projects
for other crime
on the north side West 28th Street between
prevention
Seventh and Eighth avenues, one of which (GDS-
programs
NY) also fronts on Seventh Avenue. A fourth
project is close to beginning at the long-empty
Edison block-through site at the western end of
the street. Individuals have taken up day-time
residence on Seventh Avenue under the GDS-NY
construction shed. In the evening, the sheds on
28th Street serve as gathering places for drug
uses and loiterers. Additional patrols will help
maintain some semblance of safety and
decorum on the street. BIDS and other members
of the District have identified an increase in pan
handlers, the mentally ill and homeless
populating the area around Penn Station and
Times Square. This are some of the most
densely congested areas
18/24
NYPD
Other NYPD
Continuing Support for noise abasement and
facilities and
enforcement: Resident surveys, 311 complaints
equipment requests
and anecdotal information show a strong need
(Expense)
for enhanced/expanded noise pollution
abatement and enforcement programs.
Additional resources include night inspections
and enhanced enforcement, as well as outreach
to the regulated community and residents alike
about the requirements of the law, how it is
enforced and penalties for lack of compliance.
Noise complaints from traffic, from construction
and from bars and nightclubs continue to be
one of the biggest issues facing our district and
it would be helpful to ensure that these
22/24
NYPD
Assign additional
Funding to provide additional Traffic Agents to
traffic enforcement
address Parking Violations
officers
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Manhattan Community Board 5
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water runoff and flooding
Water runoff and flooding in many areas throughout CB5 has been identified, while trash collection, particularly in the West 50’s and West 20’s is also of concern. In its budget requests year on year, CB5 has identified with some granularity those areas where rainwater consistently pools and flooding occurs.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
Sanitation needs of our district are immense. The district needs significantly improved corner trash pick-up. There is also a need for more recycling and composting bins—especially in the residential sections of the District. Tourism in the city is at record levels, and we need to ensure Times Square and other key tourist destinations are kept at impeccably clean levels.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
39/40 DSNY Other garbage
collection and recycling infrastructure requests (Capital)
For FIT in particular, we are especially concerned about trash the Megabus drop-off site on Seventh Avenue at 27th Street - the sole drop off for the entire city. (Passengers disembark after 3-6 hour bus rides with significant food garbage, and the trash can at the Megabus site often overflows onto the street.) Also, there appears to be a significant increase in trash in the gutters and on the sidewalks in the district which might be addressed with more frequent street cleaning. Complaints of overflowing baskets are particularly rife on 7th avenue from FIT all the way to 5t8h Street West 29th street has also been problematic with one resident claiming not to have seen one street cleaning in almost a year. It would be helpful if we had a schedule of pick up and cleanings
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
3/24
DSNY
Other garbage
The new waste management proposal is not
collection and
well understood by small businesses in our
recycling requests
district and we would like to see outreach to
these organizations so that they understand the
new carting policy and can be part of the
conversation as the waste management plan
evolves; fund outreach to stakeholders on the
design of the program, to research the efficacy
of the system once its in place, to create a small
hauler advocacy program would all enhance the
new carting system.
7/24 DSNY Provide more
frequent garbage or recycling pick-up
For FIT in particular, we are especially concerned about trash the Megabus drop-off site on Seventh Avenue at 27th Street - the sole drop off for the entire city. (Passengers disembark after 3-6 hour bus rides with significant food garbage, and the trash can at the Megabus site often overflows onto the street.) Also, there appears to be a significant increase in trash in the gutters and on the sidewalks in the district which might be addressed with more frequent street cleaning. Complaints of overflowing baskets are particularly rife on 7th avenue from FIT all the way to 5t8h Street West 29th street has also been problematic with one resident claiming not to have seen one street cleaning in almost a year. It would be helpful if we had a schedule of pick up and cleanings and if this could b
image
11/24 DEP Clean catch basins These catch basins are clogged, which results in
odors from standing water and poor drainage when it rains. We get some very bad ponding conditions on the plazas in particular. We have reported them to 311 in the past but to my knowledge they have Specific locations include the northeast corner of Broadway and West 38th Street, Northeast corner of West 38th Street and Broadway, Northeast corner of Broadway and West 37th Street never been cleaned.
image
19/24 DSNY Other garbage
collection and recycling requests
DSNY should be given adequate funding to effectively manage the city’s transition to a zoned commercial waste zone system, if such a system is required by the City Council.
Manhattan CB 5 joins BP Brewer and other stakeholders who have expressed concern that the proposed Department of Sanitation Division of Commercial Waste be created and funded sufficiently to execute a clear organizational structure and delineation of responsibilities to promote communication among city agencies, the regulated community, large and small businesses, and other affected stakeholders.
DSNY should be given adequate funding to ensure that the advantages and resulting efficiencies, customer service benchmarks, recycling, and other benefits promised from the commercial waste zone system in fact are created and c
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Manhattan Community Board 5
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
Affordable housing is one of the single most important issues identified by stakeholders within the district. Not only for low and moderate-income families, but increasingly also for middle class affordable housing programs. The enormous amount of construction within the district and the loss of small buildings owned by individual landlords, the cost of housing vis-a-vis income and income inequality have all stoked interest in preserving and creating affordable housing programs. It is hoped that the newly adopted legislation governing certain rental property, which was supported by CB5, will help to retain affordable property within the district. The opportunity to gather data at the start of the implementation of these regulations is one not to be missed as the impact of these regulations can be used to guide future policy. CB5 opposes the use of mechanical voids as a means of gaining additional building height and is concerned with the proliferation of super-tall buildings. Super-talls not only create shadows throughout the City but also block the sightline views of iconic landmarks such as the Empire State building.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
New Housing Affordable to a Wide Range of Household Incomes—From Central Park South to Union Square, the district is becoming an increasingly desirable place to life. This demand for housing stock in our district can has resulted in a significant increase in residential development, some of which is creating affordable housing units through the Inclusionary Housing Program. Unfortunately, the existing R10 Inclusionary Program is flawed in that it requires far too little affordable housing for the enormous benefit granted in the form of a zoning bonus. The City must alter the ratios to ensure that much more permanently affordable housing is created when new construction occurs.
Needs for Housing
Affordable housing is one of the single most important issues identified by stakeholders within the district. Not only for low and moderate income families but also increasingly, we have heard calls for middle-class affordable housing programs. The enormous amount of construction within the district and the loss of buildings owned by individual landlords to large corporate entities has helped fuel the concern regarding this issue. The cost of housing vis-a-vis income and income inequality has also stoked interest in preserving and creating such programs.
Needs for Economic Development
Our economy is increasingly bifurcated—with high wage financial services, corporate, law, consulting and tech jobs on the one hand, and low-wage retail and service jobs on the other hand. There needs to be careful consideration of how all city policies impact the economic wellbeing of the diverse members of the community. It is important to CB5 that our city's economic policy support a diversified economy within our district. One means of achieving this goal is ensuring that land use policies allow for the growth and flourishing of industries with living-wage jobs in fashion, light manufacturing and other sectors currently using the Class B and Class C office stock of the district.
Workforce Development—The City should identify and pursue policies that enable low-wage workers (thousands of which are in our district) and the unemployed to meet the workforce needs in the city. The City should identify and pursue policies that enable our District workforce to develop skills that employers seek, to improve their career progression and income mobility - and for the lower wage workforce whose numbers are considerable - to enhance their economic stability. This includes the City adopting the principles and recommendations of the Mayor's Jobs for New Yorkers Task Force including the following: 1. Establish Career Pathways as the framework for the City’s workforce system; 2. Launch or expand Industry Partnerships in six sectors: healthcare, technology, industrial/ manufacturing, construction, retail and food service; 3. Invest in bridge programs that prepare low-skill jobseekers for entry-level work and middle-skill job training; 4. Triple the City’s training investment in career-track, middle-skill occupations, including greater support for incumbent workers who are not getting ahead; 5. Improve and expand CTE and college preparedness programs, adjust CUNY’s alternative credit policy, and invest in career counseling; 6.
Increase work-based learning opportunities for youth and high-need jobseeker; 7. Create a standard that recognizes high-road employers who have good business practices; 8. Improve the conditions of low-wage work by expanding access to financial empowerment resources and pursuing legislative changes such as increasing the minimum wage;
9. Maximize local job opportunities through the City’s contracts and economic development investments
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
2/40 HPD Provide more
housing for extremely low and low income households
The extra subsidy will help finance more new construction rental units at shelter rent allowance and create more units for the homeless which is needed given the number of homeless within the district.
image
31/40 HPD Other affordable
housing programs requests (capital)
Supportive housing is imperative to help get people who are chronically homeless off the streets. Without the wrap around services to address their needs it is unlikely they will stay independent or become contributing members of the City.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
8/24
EDC
Improve public
As DCA & DOHMH debate increasing the
markets
number of cart permits, we would like to
understand how these carts impact current
businesses
9/24
DCP
Study land use and
Residents have indicated that they feel their
zoning to better
buildings sway and are concerned street
match current use
foundation weaknesses that will be magnified
or future
by the new transit rules for 14th street that will
neighborhood
see more traffic being routed to their streets.
needs
12/24
NYCHA
Other housing
Emergency grant applicants may obtain rental
support requests
assistance in cases of impending evictions,
assistance with home energy and utility bills,
disaster assistance including moving expenses,
and the purchase of personal items for health
and safety. The City should build upon recent
efforts to streamline this process to ensure more
people are quickly connected to One Shot Deal.
13/24
HPD
Provide or enhance
Housing developments face two major
rental subsidies
expenses: expenses in building and expenses in
programs
ongoing maintenance. HPD can and has been
funding subsidies attached to specific units
within housing developments for the homeless.
By increasing the level of this subsidy, more
units for the homeless can be brought on line
and be maintained adequately.
20/24
HPD
Other affordable
Limited dollar amount, % in rent increase, and
housing programs
length of time for depreciation on capital
requests (expense)
improvements projects (in existing rent stablized
building) are some key restrictions that the new
rent laws cover. Multi-year tracking of builing &
unit conditions should start now, in year 0, to
identify the positive/negative effects of the new
laws. Will these restrictions reduce landlord's
incentives to conduct building-wide capital
improvements and unit-specific repairs?
23/24
SBS
Other expense
This would be similar to the Community Toilet
commercial district
Scheme that has been in operation in the UK for
revitalization
the past decade and recently adopted by
requests
Washington DC. There is a lack of public
bathrooms in our district and an incredibly high
percentage of public urination per documented
311 calls.
24/24
SBS
Other expense
Expand offerings under Chamber-on-the-Go
commercial district
revitalization
requests
TRANSPORTATION
Manhattan Community Board 5
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
Our district has immense transportation needs given the dense concentration of businesses and the presence of Grand Central Terminal, Penn Station, the Port Authority Bus Terminal, and many subway stations within or just outside our borders. Commercial and office spaces make up roughly 65% of the district, bringing hundreds of thousands of commuters into the district and leading to severe congestion. Many stakeholders in CB5, along with advocates, have stated their wish for a comprehensive congestion plan to address congestion concerns. Accessible and safe public transportation is also extremely important given the large numbers of commuters, residents, and visitors in the district. MTA funding disputes between state and city officials continuously affect CB5, which is home to nine of the ten busiest subway stations (MTA Annual Ridership by Station Report). Furthermore, several highly frequented subway stations in CB5, such as the 4/5/6 at Union Square and S at Times Square, are not ADA compliant, limiting accessibility for residents and visitors alike. In addition, our district has a high traffic flow with several complex intersections, which are in need of improved traffic safety as evidenced by high annual collision rates, poor pedestrian safety, and several conflicting traffic patterns. The district welcomes the newly created bike routes, but the safety of bikers, pedestrians, and drivers depends on active enforcement of regulations.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Our district has immense transportation needs given the dense concentration of businesses and the presence in (or bordering) our district of Grand Central Terminal, Penn Station, the Port Authority Bus Terminal, and many subway stations. Commercial and office spaces make up roughly 65% of the district, bringing hundreds of thousands of commuters into the district and leading to severe congestion. In addition, the impending L-Train shut down is expected to further increase congestion by shuttling commuters in buses across 14th street. Several transportation authorities in CB5 jurisdiction would like to see a comprehensive congestion plan implemented to address these needs while many wish the City to recognize the importance of private transportation to those with young children, the elderly and the disabled.. Accessible and safe public transportation is also extremely important given the large numbers of commuters, residents, and visitors in the district. MTA funding disputes between state and city officials continuously affect CB5, which is home to 9 of the 10 busiest subway stations (MTA Annual Ridership by Station Report). Furthermore, several highly frequented subway stations in CB5, such as the 4/5/6 at Union Square and S at Times Square, are not ADA compliant, limiting accessibility for residents and visitors alike. In addition, our district has a high traffic flow with several complex intersections which are in need of improved traffic safety as evidenced by high annual collision rates, poor pedestrian safety, and several conflicting traffic patterns. The district welcomes the newly created bike routes, but the safety of bikers, pedestrians, and drivers depends on active enforcement of regulations. Furthermore, several transportation authorities in CB5 would like to see increased road safety through projects such as replacing street lights and repairing sidewalks on 8th avenue.
Needs for Transit Services
Conditions on the 4/5/6 lines are extremely overburdened and the City and MTA must find ways to alleviate overcrowding to support a more efficient flow of riders.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/40
DOT
Other
Our district has the highest density of New
transportation
Yorkers and concentration of tourists, and there
infrastructure
are not enough public bathrooms to serve them.
requests
Our districts also has a extremely high number
of 311 complaints from public urination. We
also have a high amount of homeless
population living on the streets that do not have
access to public bathrooms.
6/40
DOT
Repair or construct
These curb repairs are needed near the
8th Avenue
new curbs or
M20/M104 bus stop
45th 46th
pedestrian ramps
7/40
DOT
Repair or construct
This request has not been addressed from last
new curbs or
year. Very specifically, we would like to see this
pedestrian ramps
at the following locations: 28th and PAS, Penn
Station on 7th Ave at 31st, 32nd, & 33rd, SE
corner 40th & 8th, SE corner 39th & 8th, NE
corner 42nd & 8th
8/40
DOT
Repair or construct
These locations are: 8th Ave at 550 8th Ave
new curbs or
(37th/38th), at 554 8th Ave (37th/38th), at 572
pedestrian ramps
8th Ave, at 590, 592, 594 8th Ave, at 614 to 616
8th Ave, Northern half of 8th Ave from 45th to
46th. We are requesting that the new grates
should be similar to the grates in front of the
Microsoft entrance at 11 Times Sq 8th
(41st/42n) because they are flat with the
sidewalk, stable (don’t bounce or wiggle), and
blend in with the sidewalk (these grates don’t
look like an obstacle to be avoided). 8th Ave
sidewalks between Penn Station & PABT are
very crowded. We need every inch of the
sidewalk and do not need pedestrians queuing
up to walk around subway grates.
9/40
DOT
Other
Repainting of crosswalks at: Union Square West
transportation
at 14&15 Streets Park Ave South/15 &
infrastructure
16thEast/West 5th Ave & 15 St.: North-South
requests
Crosswalk on west side of 5th
10/40
DOT
Repair or provide
Traffic congestion is an issue that is repeatedly
5th Avenue
new street lights
mentioned by people within the district and
lights for buses would significantly improve
traffic.
11/40
DOT
Repair or construct
Congestion is a problem within the districting it
new curbs or
is growing because the number of visitors is
pedestrian ramps
increasing, there residential population is
increasing and the homeless are also occupying
a lot of space, particularly along the 8th avenue
corridor. This work has already begun at 39th
street west but should span from 34th st to 49th
on 8th avenue
12/40
DOT
Reconstruct streets
The bike lane design here is confusing and
should be improved in this area to lessen cyclist-
pedestrian conflicts. It would be also helpful to
remove unessential concrete islands from 34th
St which remain from when Broadway was not
pedestrian only. Funding should be provided to
find a design which would allow pedestrians to
walk on a wide sidewalk on Sixth Ave along the
both parks’ Sixth Ave fence. Currently, the
passage is very it is very narrow (2ft) along
Greeley Sq and pits pedestrians against the
uptown bike path along Herald Sq.
13/40
DOT
Roadway
Water has pooled within the same location for
maintenance (i.e.
over a year at times forcing bicyclists into the
pothole repair,
street. This is one of the only through way bike
resurfacing, trench
lanes in the area.
restoration, etc.)
14/40
DOT
Upgrade or create
Pershing Square West has been repaired and
new plazas
looks great; it would be great if the rest of the
Plazas could follow suit.
18/40
DOT
Upgrade or provide
This initiative would help congestion.
42nd Street
new Select Bus
Service (SBS) routes
19/40
DOT
Improve traffic and
Congestion is a big problem in the district and
pedestrian safety,
this is one tool to help solve the issue. Traffic
including traffic
often comes to a standstill in the 6th, 7th and
calming (Capital)
8th avenue area where traffic blocks the box
and impedes other traffic flow as well as
pedestrian flow.
20/40
DOT
Install streetscape
Bikes are being chained through the district on
improvements
lampposts and pocket parks. The provision of
bike corrals would make this situation less
unsightly.
22/40
DOT
Repair or provide
Replacing existing street lights with City Lights
Broadway
new street lights
design and increase number of street lights on
34th 42nd
Broadway between 34th and 42nd
23/40
DOT
Upgrade or create new plazas
NYPL and Bryant Park pedestrian improvements
Avenue Of The Americas, Manhattan,
New York, NY
24/40
DOT
Repair or provide
The repair would help ease street congestion
new street lights
and curb access
25/40
DOT
Install streetscape
Create/enhance an ongoing program in the
improvements
department to promote/require green
infrastructure initiatives throughout the district,
but particularly in areas of greatest pedestrian
traffic such as around Penn Station, Herald and
Greeley Squares, and Times Square. These green
infrastructure initiatives should include rain
gardens, stormwater management,
greenstreets, etc. to create a variety of
sustainable green infrastructure practices in
public and private streetscapes in the district.
32/40
NYCTA
Repair or upgrade
Repair leaks in the 1 train 50th Street Station
subway stations or
other transit
infrastructure
33/40
NYCTA
Improve
Subway Elevator access to both 4/5/6 platforms
accessibility of
at Union Square/14th St Station, MadisonSq
transit
23rd St R/W Station, Bryant Park 42ndSt
infrastructure, by
B/D/F/M/7 Station
providing elevators,
escalators, etc.
34/40
NYCTA
Other transit
Provide additional electric Buses to be used on
infrastructure
the routes in CB5
requests
35/40
DOT
Other capital traffic
Congestion and traffic are a big issue through
improvements
out the district and installing these clocks would
requests
give the public some indication of
36/40
DOT
Other capital traffic
FIT strongly supports the addition of a plan to
improvements
take off the street the many long-distance buses
requests
currently using curbside pick-up and drop-off
sites throughout the district and in CB4. These
buses can be accommodated within the new
PABT or in a separate structure, but the issue
must be included in the EIS scope and advance
simultaneously with the PABT project.
40/40 NYCTA Improve
accessibility of transit infrastructure, by providing elevators, escalators, etc.
The new elevators and escalators from the mezzanine level down to the 7 platforms bypass the 4-5-6- platforms so most transferring commuters will congest the 4-5-6- platforms to access the two current stairwells down to the 7 platform.
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
16/24 DOT Other expense
traffic improvements requests
Comprehensive Street Use plan - 5th and 6th Aves from 14th to 59th Sts
image
17/24 DOT Other expense
traffic improvements requests
Create/enhance an ongoing program in the department to promote/require green infrastructure initiatives throughout the district, but particularly in areas of greatest pedestrian traffic such as around Penn Station, Herald and Greeley Squares, and Times Square. These green infrastructure initiatives should include rain gardens, stormwater management, greenstreets, etc. to create a variety of sustainable green infrastructure practices in public and private streetscapes in the district.
image
21/24 NYCTA Other transit service
requests
Eliminate Enhanced service
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Manhattan Community Board 5
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Community board resources (offices, staff and equipment)
The issue of funding for the Community Board office has been of particular concern to CB5 and has been its number one budget request for the last three years. The participation of ordinary individuals in the processes that determine how we live in the city is vital, particularly in a time where increasingly such participation is being chipped away. Accordingly, CB5 believes that funding a Board office that can hire competitively and that can robustly handle stakeholder requests is of primary importance.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Parks—Privately managed parks are an important feature of the district. There is a need to maximize use of public spaces for recreational use by residents and workers within the context of allowing these management organizations to have self-supporting financing mechanisms to cover maintenance and park programming. Privately- Owned Public Spaces—The Department of City Planning and DOB need to coordinate to ensure that properties receiving density bonuses through provision of a plaza are fulfilling all of their obligations to afford a true public amenity. The City should make unexpected inspections of all privately owned public spaces each year, issue warnings to owners violating the terms of their bonus and remove the DOB occupancy permits for bonuses floor area for owners who do not bring their plazas into compliance within a reasonable time frame.
Needs for Cultural Services
No comments
Needs for Library Services
CB5 is home to six branches of the New York Public Library, including two of the four research libraries in New York. The New York Public Library facilities serving the district continue to need additional funding to meet the demand for its services. In the fiscal year 2016, CB5 libraries had 4,769,129 visits, some of the highest levels of use in the City. Libraries in our district provide Internet access to low income residents, out of school programs, early literacy, and events for senior citizens.
Needs for Community Boards
The issue of funding for the Community Board office has been of particular concern to CB5 and has been its number one budget request for the last two years. The participation of ordinary individuals in the processes that determine how we live in the city is vital, particularly in a time where increasingly such participation is being chipped away.
Accordingly, CB5 believes that funding a Board office that can hire competitively and that can robustly handle stakeholder requests is of primary importance.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
5/40
DPR
Provide a new, or
DPR should fund the renovation, construction
new expansion to, a
and operation of public restrooms at parks
building in a park
throughout the district. The lack of these
facilities is a major contributor to street
pollution.The recent public advocate publication
on this issue highlighted the lack of public
facilities within our parks. Herald and Greeley
Square, Fr. Duffy Park and Union Square are
areas in which public bathrooms could be
considered.
26/40
DPR
Provide a new or
Locations include 57th Street on the west side
expanded park or
and 29th street on the east side, west 30th
playground
street, renew the neglected green space at
Broadway and 54th street as well as on West
53rd and West 55th streets
27/40
DPR
Reconstruct or
The public bathroom at Greeley Square has
upgrade a parks
been closed for some time and currently the
facility
public bathroom at herald square is under
renovation. Because these open spaces and
commercial corridor are heavily visited, access
to public bathrooms are paramount and we ask
that Parks work with 34th Street Partnership to
provide safe accessible bathrooms in this area
preferably with an attendant.
28/40
DPR
Reconstruct or
Identification, purchase and planting of
upgrade a park or
shadow-resistant trees and plants in areas of
playground
Central Park covered by skyscraper shade
29/40
DPR
Reconstruct or
Upgrade of restroom next to Delacorte Theater
Childrens Zoo
upgrade a parks
in Central Park
Ticket Booth,
facility
Manhattan,
New York, NY
30/40
DPR
Provide a new or
Increased Development & Maintenance of
expanded park or
Publicly Accessible Parks & Playgrounds
playground
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority Agency Request Explanation Location
image
1/24 OMB Other community
board facilities and staff requests
CB5 has used its funding to increase its outreach to the community and undertake important studies that will inform members and the public about issues such as shadows created by the supertalls and other new buildins in the district.
image
4/24 QL Extend library hours or expand and enhance library programs
Ensure funding to provide minimum six days per week openings and high-quality and diverse programming. We would like to ensure appropriate funding for the expansion of libraries, and to ensure that services and collections are maintained. This is particularly important now that more people rely on library services for myriad things such as early literacy programming, ESOL classes for immigrants and story times for homeless families.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority Agency Request Explanation Location
image
2/24 Other Other expense
budget request
Request should be conveyed to DOITT. The full list of non-auctioning telephone booths within the district is attached. A clear timetable of removal should be made available.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/40
DHS
Other facilities for
Medical respite programs provide hospitals with
the homeless
an alternative to discharging homeless patients
requests
to the streets or to unequipped shelters.
Medical respite programs seek to improve
transitional care for this population and end the
cycle of homelessness by supporting patients in
access benefits and housing.
2/40
HPD
Provide more
The extra subsidy will help finance more new
housing for
construction rental units at shelter rent
extremely low and
allowance and create more units for the
low income
homeless which is needed given the number of
households
homeless within the district.
3/40
DHS
Provide new
One of the biggest issues we’re seeing right now
homeless shelters or
is that the safe haven system is not meeting the
SROs
demand, especially for women. Currently, there
is no safe haven in NYC exclusively for women,
which is barring many women from coming off
the streets.
4/40
DOT
Other
Our district has the highest density of New
transportation
Yorkers and concentration of tourists, and there
infrastructure
are not enough public bathrooms to serve them.
requests
Our districts also has a extremely high number
of 311 complaints from public urination. We
also have a high amount of homeless
population living on the streets that do not have
access to public bathrooms.
5/40
DPR
Provide a new, or
DPR should fund the renovation, construction
new expansion to, a
and operation of public restrooms at parks
building in a park
throughout the district. The lack of these
facilities is a major contributor to street
pollution.The recent public advocate publication
on this issue highlighted the lack of public
facilities within our parks. Herald and Greeley
Square, Fr. Duffy Park and Union Square are
areas in which public bathrooms could be
considered.
6/40
DOT
Repair or construct
These curb repairs are needed near the
8th Avenue
new curbs or
M20/M104 bus stop
45th 46th
pedestrian ramps
7/40
DOT
Repair or construct new curbs or pedestrian ramps
This request has not been addressed from last year. Very specifically, we would like to see this at the following locations: 28th and PAS, Penn
Station on 7th Ave at 31st, 32nd, & 33rd, SE
corner 40th & 8th, SE corner 39th & 8th, NE
corner 42nd & 8th
8/40
DOT
Repair or construct
These locations are: 8th Ave at 550 8th Ave
new curbs or
(37th/38th), at 554 8th Ave (37th/38th), at 572
pedestrian ramps
8th Ave, at 590, 592, 594 8th Ave, at 614 to 616
8th Ave, Northern half of 8th Ave from 45th to
46th. We are requesting that the new grates
should be similar to the grates in front of the
Microsoft entrance at 11 Times Sq 8th
(41st/42n) because they are flat with the
sidewalk, stable (don’t bounce or wiggle), and
blend in with the sidewalk (these grates don’t
look like an obstacle to be avoided). 8th Ave
sidewalks between Penn Station & PABT are
very crowded. We need every inch of the
sidewalk and do not need pedestrians queuing
up to walk around subway grates.
9/40
DOT
Other
Repainting of crosswalks at: Union Square West
transportation
at 14&15 Streets Park Ave South/15 &
infrastructure
16thEast/West 5th Ave & 15 St.: North-South
requests
Crosswalk on west side of 5th
10/40
DOT
Repair or provide
Traffic congestion is an issue that is repeatedly
5th Avenue
new street lights
mentioned by people within the district and
lights for buses would significantly improve
traffic.
11/40
DOT
Repair or construct
Congestion is a problem within the districting it
new curbs or
is growing because the number of visitors is
pedestrian ramps
increasing, there residential population is
increasing and the homeless are also occupying
a lot of space, particularly along the 8th avenue
corridor. This work has already begun at 39th
street west but should span from 34th st to 49th
on 8th avenue
12/40
DOT
Reconstruct streets
The bike lane design here is confusing and
should be improved in this area to lessen cyclist-
pedestrian conflicts. It would be also helpful to
remove unessential concrete islands from 34th
St which remain from when Broadway was not
pedestrian only. Funding should be provided to
find a design which would allow pedestrians to
walk on a wide sidewalk on Sixth Ave along the
both parks’ Sixth Ave fence. Currently, the
passage is very it is very narrow (2ft) along
Greeley Sq and pits pedestrians against the
uptown bike path along Herald Sq.
13/40
DOT
Roadway
Water has pooled within the same location for
maintenance (i.e.
over a year at times forcing bicyclists into the
pothole repair,
street. This is one of the only through way bike
resurfacing, trench
lanes in the area.
restoration, etc.)
14/40
DOT
Upgrade or create
Pershing Square West has been repaired and
new plazas
looks great; it would be great if the rest of the
Plazas could follow suit.
15/40
DHS
Upgrade existing
Advocates have indicated that this centralized
facilities for the
system alienates those who would avail of
homeless
shelter and by humanizing the process with
smaller in take centers throughout the city more
people could potentially be removed from our
streets.
16/40
DHS
Provide new
Current safe havens do not allow for people do
homeless shelters or
be housed with animals, except for service or
SROs
emotional support animals. This causes a
significant population to refuse shelter so as not
to be separated from their pets. Advocates
claim that should such a a pet friendly safe
haven would encourage more homeless to avail
of this shelter.
17/40
HHC
Other health care
Only half of the community air survey monitors
facilities requests
are undertaking a 24/7 data collection. In
addition there is a monitoring gap between
Prince Street and 37th Street, particularly in the
southern portions of CB5 near 23rd St./Madison
Square Park and 14th Street, Union Square.
18/40
DOT
Upgrade or provide
This initiative would help congestion.
42nd Street
new Select Bus
Service (SBS) routes
19/40
DOT
Improve traffic and
Congestion is a big problem in the district and
pedestrian safety,
this is one tool to help solve the issue. Traffic
including traffic
often comes to a standstill in the 6th, 7th and
calming (Capital)
8th avenue area where traffic blocks the box
and impedes other traffic flow as well as
pedestrian flow.
20/40
DOT
Install streetscape
Bikes are being chained through the district on
improvements
lampposts and pocket parks. The provision of
bike corrals would make this situation less
unsightly.
21/40
SCA
Renovate other site
The material currently on the rooftop
component
playground creates a situation where the
children cannot play on the surface for a day or
two after rain.
22/40
DOT
Repair or provide
Replacing existing street lights with City Lights
Broadway
new street lights
design and increase number of street lights on
34th 42nd
Broadway between 34th and 42nd
23/40
DOT
Upgrade or create
NYPL and Bryant Park pedestrian improvements
Avenue Of
new plazas
The Americas,
Manhattan,
New York, NY
24/40
DOT
Repair or provide
The repair would help ease street congestion
new street lights
and curb access
25/40
DOT
Install streetscape
Create/enhance an ongoing program in the
improvements
department to promote/require green
infrastructure initiatives throughout the district,
but particularly in areas of greatest pedestrian
traffic such as around Penn Station, Herald and
Greeley Squares, and Times Square. These green
infrastructure initiatives should include rain
gardens, stormwater management,
greenstreets, etc. to create a variety of
sustainable green infrastructure practices in
public and private streetscapes in the district.
26/40
DPR
Provide a new or
Locations include 57th Street on the west side
expanded park or
and 29th street on the east side, west 30th
playground
street, renew the neglected green space at
Broadway and 54th street as well as on West
53rd and West 55th streets
27/40
DPR
Reconstruct or
The public bathroom at Greeley Square has
upgrade a parks
been closed for some time and currently the
facility
public bathroom at herald square is under
renovation. Because these open spaces and
commercial corridor are heavily visited, access
to public bathrooms are paramount and we ask
that Parks work with 34th Street Partnership to
provide safe accessible bathrooms in this area
preferably with an attendant.
28/40
DPR
Reconstruct or
Identification, purchase and planting of
upgrade a park or
shadow-resistant trees and plants in areas of
playground
Central Park covered by skyscraper shade
29/40
DPR
Reconstruct or
Upgrade of restroom next to Delacorte Theater
Childrens Zoo
upgrade a parks
in Central Park
Ticket Booth,
facility
Manhattan,
New York, NY
30/40
DPR
Provide a new or
Increased Development & Maintenance of
expanded park or
Publicly Accessible Parks & Playgrounds
playground
31/40
HPD
Other affordable
Supportive housing is imperative to help get
housing programs
people who are chronically homeless off the
requests (capital)
streets. Without the wrap around services to
address their needs it is unlikely they will stay
independent or become contributing members
of the City.
32/40
NYCTA
Repair or upgrade
Repair leaks in the 1 train 50th Street Station
subway stations or
other transit
infrastructure
33/40
NYCTA
Improve
Subway Elevator access to both 4/5/6 platforms
accessibility of
at Union Square/14th St Station, MadisonSq
transit
23rd St R/W Station, Bryant Park 42ndSt
infrastructure, by
B/D/F/M/7 Station
providing elevators,
escalators, etc.
34/40
NYCTA
Other transit
Provide additional electric Buses to be used on
infrastructure
the routes in CB5
requests
35/40
DOT
Other capital traffic
Congestion and traffic are a big issue through
improvements
out the district and installing these clocks would
requests
give the public some indication of
36/40
DOT
Other capital traffic
FIT strongly supports the addition of a plan to
improvements
take off the street the many long-distance buses
requests
currently using curbside pick-up and drop-off
sites throughout the district and in CB4. These
buses can be accommodated within the new
PABT or in a separate structure, but the issue
must be included in the EIS scope and advance
simultaneously with the PABT project.
37/40
SCA
Provide technology
Currently not enough functional computers for
upgrade
all students to work at once. The provision of
laptops will not only allow students to become
proficient in the latest technology and allow
their teachers to use current tools such as
GoogleClassroom and DeltaMath but also
allows students to prepare and submit college
applications
38/40
DHS
Upgrade existing
City has meaningfully increased the funding for
facilities for the
both service initiatives and continues to do so in
homeless
the coming years. However outreach and
informational campaign have not reached many
corners of the city. If the services are not known,
they will not be fully utilized.
39/40
DSNY
Other garbage
For FIT in particular, we are especially
collection and
concerned about trash the Megabus drop-off
recycling
site on Seventh Avenue at 27th Street - the sole
infrastructure
drop off for the entire city. (Passengers
requests (Capital)
disembark after 3-6 hour bus rides with
significant food garbage, and the trash can at
the Megabus site often overflows onto the
street.) Also, there appears to be a significant
increase in trash in the gutters and on the
sidewalks in the district which might be
addressed with more frequent street cleaning.
Complaints of overflowing baskets are
particularly rife on 7th avenue from FIT all the
way to 5t8h Street West 29th street has also
been problematic with one resident claiming
not to have seen one street cleaning in almost a
year. It would be helpful if we had a schedule of
pick up and cleanings
40/40
NYCTA
Improve
The new elevators and escalators from the
accessibility of
mezzanine level down to the 7 platforms bypass
transit
the 4-5-6- platforms so most transferring
infrastructure, by
commuters will congest the 4-5-6- platforms to
providing elevators,
access the two current stairwells down to the 7
escalators, etc.
platform.
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/24
OMB
Other community
CB5 has used its funding to increase its outreach
board facilities and
to the community and undertake important
staff requests
studies that will inform members and the public
about issues such as shadows created by the
supertalls and other new buildins in the district.
2/24
Other
Other expense
Request should be conveyed to DOITT. The full
budget request
list of non-auctioning telephone booths within
the district is attached. A clear timetable of
removal should be made available.
3/24
DSNY
Other garbage
The new waste management proposal is not
collection and
well understood by small businesses in our
recycling requests
district and we would like to see outreach to
these organizations so that they understand the
new carting policy and can be part of the
conversation as the waste management plan
evolves; fund outreach to stakeholders on the
design of the program, to research the efficacy
of the system once its in place, to create a small
hauler advocacy program would all enhance the
new carting system.
4/24
QL
Extend library hours
Ensure funding to provide minimum six days per
or expand and
week openings and high-quality and diverse
enhance library
programming. We would like to ensure
programs
appropriate funding for the expansion of
libraries, and to ensure that services and
collections are maintained. This is particularly
important now that more people rely on library
services for myriad things such as early literacy
programming, ESOL classes for immigrants and
story times for homeless families.
5/24
NYPD
Increase resources
There are currently three construction projects
for other crime
on the north side West 28th Street between
prevention
Seventh and Eighth avenues, one of which (GDS-
programs
NY) also fronts on Seventh Avenue. A fourth
project is close to beginning at the long-empty
Edison block-through site at the western end of
the street. Individuals have taken up day-time
residence on Seventh Avenue under the GDS-NY
construction shed. In the evening, the sheds on
28th Street serve as gathering places for drug
uses and loiterers. Additional patrols will help
maintain some semblance of safety and
decorum on the street. BIDS and other members
of the District have identified an increase in pan
handlers, the mentally ill and homeless
populating the area around Penn Station and
Times Square. This are some of the most
densely congested areas
6/24
DHS
Expand street
One of the most pressing issues facing the
outreach
district is homelessness and many of these
individuals congregate in the Pennn Station, FIT
and Port Authority area. These individuals have
myriad problems including mental illness and
drug addiction and additional outreach and
services to work with this population can only
help with these issues.
7/24
DSNY
Provide more
For FIT in particular, we are especially
frequent garbage or
concerned about trash the Megabus drop-off
recycling pick-up
site on Seventh Avenue at 27th Street - the sole
drop off for the entire city. (Passengers
disembark after 3-6 hour bus rides with
significant food garbage, and the trash can at
the Megabus site often overflows onto the
street.) Also, there appears to be a significant
increase in trash in the gutters and on the
sidewalks in the district which might be
addressed with more frequent street cleaning.
Complaints of overflowing baskets are
particularly rife on 7th avenue from FIT all the
way to 5t8h Street West 29th street has also
been problematic with one resident claiming
not to have seen one street cleaning in almost a
year. It would be helpful if we had a schedule of
pick up and cleanings and if this could b
8/24
EDC
Improve public
As DCA & DOHMH debate increasing the
markets
number of cart permits, we would like to
understand how these carts impact current
businesses
9/24
DCP
Study land use and
Residents have indicated that they feel their
zoning to better
buildings sway and are concerned street
match current use
foundation weaknesses that will be magnified
or future
by the new transit rules for 14th street that will
neighborhood
see more traffic being routed to their streets.
needs
10/24
DHS,
Other homelessness
IT system handling shelter population requires
HRA
prevention program
modernization to better handle the increased
request
population, specifically storing data
electronically, mapping vacancies across
shelters, storing data around optimal
communities for a resident to be housed in and
creating an algorithm to place ppl in optimal
shelters for their rehabilitation
11/24
DEP
Clean catch basins
These catch basins are clogged, which results in
odors from standing water and poor drainage
when it rains. We get some very bad ponding
conditions on the plazas in particular. We have
reported them to 311 in the past but to my
knowledge they have Specific locations include
the northeast corner of Broadway and West
38th Street, Northeast corner of West 38th
Street and Broadway, Northeast corner of
Broadway and West 37th Street never been
cleaned.
12/24
NYCHA
Other housing
Emergency grant applicants may obtain rental
support requests
assistance in cases of impending evictions,
assistance with home energy and utility bills,
disaster assistance including moving expenses,
and the purchase of personal items for health
and safety. The City should build upon recent
efforts to streamline this process to ensure more
people are quickly connected to One Shot Deal.
13/24
HPD
Provide or enhance
Housing developments face two major
rental subsidies
expenses: expenses in building and expenses in
programs
ongoing maintenance. HPD can and has been
funding subsidies attached to specific units
within housing developments for the homeless.
By increasing the level of this subsidy, more
units for the homeless can be brought on line
and be maintained adequately.
14/24
DHS
Other request for
These individuals face a myriad of problems,
services for the
programs and outreach from an array of
homeless
sources, both public and private. Establishing
trust and confidence is difficult and the presence
of a licensed professional who can work on a
continuing basis to connect them with existing
resources could be life-changing for these
individuals. This presence also will help leverage
the success of existing programs and
interventions.
15/24
DHS,
Other homelessness
Fund grants that can be awarded to community
HRA
prevention program
boards, business improvement districts, private
request
businesses and not for profit organizations who
organize to create and operate programs in the
district to address issues of street homelessness,
connect individuals and families to resources,
enhance resources available in the district,
study the existence and success of shelters and
other resources, and otherwise address the fact
and perception of increasing numbers of
individuals experiencing homelessness
individuals on the streets in the district.
Homeless is one of the greatest challenges
facing the district. While many agencies and
organizations are attempting to tackle this
problem the encouraging other entities to help
find solutions may create the next best way to
address the issue.
16/24
DOT
Other expense
Comprehensive Street Use plan - 5th and 6th
traffic
Aves from 14th to 59th Sts
improvements
requests
17/24
DOT
Other expense
Create/enhance an ongoing program in the
traffic
department to promote/require green
improvements
infrastructure initiatives throughout the district,
requests
but particularly in areas of greatest pedestrian
traffic such as around Penn Station, Herald and
Greeley Squares, and Times Square. These green
infrastructure initiatives should include rain
gardens, stormwater management,
greenstreets, etc. to create a variety of
sustainable green infrastructure practices in
public and private streetscapes in the district.
18/24
NYPD
Other NYPD
Continuing Support for noise abasement and
facilities and
enforcement: Resident surveys, 311 complaints
equipment requests
and anecdotal information show a strong need
(Expense)
for enhanced/expanded noise pollution
abatement and enforcement programs.
Additional resources include night inspections
and enhanced enforcement, as well as outreach
to the regulated community and residents alike
about the requirements of the law, how it is
enforced and penalties for lack of compliance.
Noise complaints from traffic, from construction
and from bars and nightclubs continue to be
one of the biggest issues facing our district and
it would be helpful to ensure that these
19/24
DSNY
Other garbage
DSNY should be given adequate funding to
collection and
effectively manage the city’s transition to a
recycling requests
zoned commercial waste zone system, if such a
system is required by the City Council.
Manhattan CB 5 joins BP Brewer and other
stakeholders who have expressed concern that
the proposed Department of Sanitation Division
of Commercial Waste be created and funded
sufficiently to execute a clear organizational
structure and delineation of responsibilities to
promote communication among city agencies,
the regulated community, large and small
businesses, and other affected stakeholders.
DSNY should be given adequate funding to
ensure that the advantages and resulting
efficiencies, customer service benchmarks,
recycling, and other benefits promised from the
commercial waste zone system in fact are
created and c
20/24
HPD
Other affordable
Limited dollar amount, % in rent increase, and
housing programs
length of time for depreciation on capital
requests (expense)
improvements projects (in existing rent stablized
building) are some key restrictions that the new
rent laws cover. Multi-year tracking of builing &
unit conditions should start now, in year 0, to
identify the positive/negative effects of the new
laws. Will these restrictions reduce landlord's
incentives to conduct building-wide capital
improvements and unit-specific repairs?
21/24
NYCTA
Other transit service
Eliminate Enhanced service
requests
22/24
NYPD
Assign additional
Funding to provide additional Traffic Agents to
traffic enforcement
address Parking Violations
officers
23/24 SBS Other expense commercial district revitalization requests
This would be similar to the Community Toilet Scheme that has been in operation in the UK for the past decade and recently adopted by Washington DC. There is a lack of public bathrooms in our district and an incredibly high percentage of public urination per documented 311 calls.
image
24/24 SBS Other expense commercial district revitalization requests
Expand offerings under Chamber-on-the-Go
image

