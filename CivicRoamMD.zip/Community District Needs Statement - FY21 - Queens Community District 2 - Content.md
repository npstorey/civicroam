- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Queens Community District 2 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1g5TzxzX7bdTgf9cKy9qCbcB38G7AsVFY/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1g5TzxzX7bdTgf9cKy9qCbcB38G7AsVFY/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Queens Community District
2
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Queens Community Board 2
image
Address: 43-22 50th Street, Suite 2B Phone: (718) 533-8773
Email: qn02@cb.nyc.gov
Website: www.nyc.gov/queenscb2
Chair: Denise Keehan-Smith District Manager: Debra Markell Kleinert
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 2 represents the areas of Sunnyside, Woodside, Long Island City and a portion of West Maspeth. The district is bounded on the north by Queens Plaza North, the northern property line of the Sunnyside Rail Yard and Northern Boulevard; on the east by the Con Rail property; on the south by Calamus, Maurice and Maspeth Avenues and Newtown Creek; the East River to the west. Community Board 2 is a diverse zoning district consisting of one, two family homes as well as a large number of multiple dwellings including Queens West, a very rapidly expanding residential district; commercial, manufacturing and industrial areas; mass transit systems and is accessible by a number of arterial highways, bridges, ferries and the Queens Midtown Tunnel. Board 2 is home to Citicorp Tower One and Two, Gotham Center, the UN Credit Bank, Silvercup Studios, LaGuardia Community College, LaGuardia Performing Arts Center, P.S. 1 Contemporary Art Museum, Thalia Spanish Theatre; and the Borden Avenue Veterans Residence. The Long Island City Partnership and the Sunnyside Business Improvement District are working to improve and enhance the commercial districts in CB 2.
4. TOP THREE PRESSING ISSUES OVERALL
Queens Community Board 2
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
City resources are needed to address and mitigate the impact of development trends. CB 2 has experienced record growth over the past two decades. Prior rezonings originally aimed toward commercial growth poorly anticipated the residential boom and the pressure this has placed on every aspect of the community's needs. Development has outpaced essential services, upkeep of the infrastructure, schools, roads, transit, and open space. Rising housing costs have become a destabilizing factor. Long time renters are being displaced by increased housing costs. Small home owners - many on fixed incomes - have large property tax increases. The cost of local retail including basics such as food and other groceries have significantly risen. Very few working class, public employees, or small business owners can afford to buy property. Many of the properties that come on the market are available as knock downs for development or for speculation. Those that are retained are modernized with an eye toward an upscale market (often having previously neglected the property's condition). The district has a wealth of small and large manufacturers, tech companies, design firms, retail, and service industries that innovate and provide jobs. Many have been part of the community for decades. Some are new. All experience exceptional pressure resulting in higher failure rates, turnover, layoffs and unemployment. In many instances zoning allows former manufacturing lots to be replaced by housing which further exacerbates the ongoing problems. CB 2 has been home to a vast community of creative individuals and groups who have given the area much of its unique identity as well as being an important sector for economic growth. PS1 / MoMa is a prime example of how a fledgling space for artist studios was able to evolve into a world class museum that provides a wide range of jobs, artist opportunities, as well as tourism revenue. Additionally, an important synergy exists between local businesses, manufacturers, and artisans - each able to share unique capabilities and ideas where the economic whole becomes greater than the sum. Our district is home to professional dancers, actors, composers, writers, and musicians who work in a professional capacity while at the same time innovating and experimenting on their own. This creative sector is among the most immediately threatened population in the district. The not fully addressed challenges of climate change and sea water rise affects the district's vast waterfront. As current information is compiled we learn that the inland affects are potentially greater than previously understood even in recent planning. Other environmental issues that stem from over development include air quality from traffic congestion, rats from excavation, and continual dust and debris in the air from construction sites. Resources need to be directed toward maintenance, sustainability, and neighborhood preservation. Land use actions and related project proposals need to move away from those that negatively impact resiliency or further destabilize the existing residential, cultural, and business communities. Land use actions and related project proposals should preserve and support concepts that comprehensively address all the above needs rather than segmented decisions and allocations that might be beneficial in one policy area or location but have unforeseen or negative consequences in others. Our budgetary needs include those that address a wide range of issues that impact the sustainability and quality of life within our neighborhoods. Our needs are equally directed toward a balance between economic growth and preserving and protecting the residents, businesses, artists, and makers who have given the community its special character.
Transit (buses & subways)
Community Board 2 is in a unique position. Directly across the East River from Midtown Manhattan and north of Brooklyn, it is crossed by two major highways—the Long Island Expressway and the Brooklyn-Queens Expressway. Queens Boulevard is heavily utilized to access the Queensboro Bridge with over 170,000 vehicles a day. The Kosciuszko Bridge carries over 160,000 vehicles a day. Inevitable traffic jams create noise, air pollution and accidents. While CB 2 is generally well-served by mass transit, the trains are over-crowded during rush hours. Efforts should be made to provide more frequent service. A promised stop in Sunnyside should be provided as part of the LIRR East Side Access project to Grand Central Station, as well as cross-honoring MTA fairs on the LIRR from the 61st Street station to Penn Station. Handicapped entrances must be installed to give greater access to mass transit for the elderly and handicapped, as well as for those with strollers. Access-A-Ride should be improved. It is failing to meet the needs of our residents.
Homelessness
Community Board 2 has experienced an increase of homelessness within our district over the past few years. Consistent with overall trends in NYC, the reasons for the increase include lack of affordable housing, evictions and overcrowded living conditions. Most view shelters as an unsafe option and often refuse to be taken to facilities unless the weather falls below 32 degrees. Individuals facing these circumstances can be found in clusters within the district. Some of the more noticeable include: encampments behind Big Bush Park, stations in and around the 7 train in Sunnyside and Woodside, including the 61st Street MTA/LIRR Ticket Booth areas as well as under overpasses along the BQE near Laurel Hill Boulevard. The general impact to the neighborhood has been unfavorable as there has been an increase in drunkenness/disorderly conduct, crime, assaults and at least one murder. There is a general lack of services and support for this most vulnerable population. The district is home to three permanent shelters, the Metro Family Shelter in Woodside, a Veteran’s Shelter LIC and most recently the North Star in Blissville.
Beginning in 2016 three hotels were converted to temporary shelters; one in Woodside and two in Blissville. The number of beds in the temporary shelters far exceeds the number of homeless from the district. The Blissville area is a poor choice because it lacks the most basic of services. It is zoned as an Industrial/Manufacturing district and is primarily a small enclave situated between Sunnyside, LIC, Maspeth and Brooklyn. It is a transportation desert with very limited bus service along the main corridor of Greenpoint Avenue. There is no supermarket, laundry facilities, dry cleaning services or places of worship. Services are inadequate and insufficient.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Queens Community Board 2
image
M ost Important Issue Related to Health Care and Human Services
Environmental health issues (noise, lead, respiratory illness, etc.)
The district is severely impacted by local living conditions which have a negative effect on the general health of its residents. We are directly impacted by the fumes of heavy traffic conditions within the district, but especially those who live near the BQE, Midtown Tunnel, Queensboro Bridge, and within the LGA flight path. We’ve seen an increase in asthma of the residents as a result. The noise of the 7 train, LIRR and low flying planes landing at LGA also play a part in creating unpleasant conditions within the district.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
CB2 is the home to one of the largest populations of senior citizens. CB 2 is in need of expanding the Meals-on- Wheels program. As a growing population in Western Queens we are in need of additional full service senior centers in Hunters Point.
Needs for Homeless
No comments
Needs for Low Income NYs
Community Board 2 would like 200,000 additional units of affordable housing. We are requesting Department of City Planning to review additional sites for rezoning in our community in ourder to expand the availability of afforable housing. CB2 seeks to expand opportunities for low and moderate income residents in our community for Long Island City, Woodside, and Sunnyside.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
6/46 HHC Provide a new or
expanded health care facility
Increase number of health care facilities due to hospital closings in Western Queens within CB 2. expand primary care services to CB 2 area as part of the caring neighborhood initiative.
image
8/46 DFTA Create a new senior
center or other facility for seniors
Obtain funding for a acquistion for site for a new senior / community center in Hunters Point.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
9/33
HRA
Provide, expand, or
Provide funding to social adult day services
enhance
programs.
educational
programs for adults
10/33
DFTA
Other senior center
Increase funds for DFTA to meet growing
program requests
demands for day care programs for seniors
including Alzheimer's programs to establish a
baseline for funding.
19/33
DFTA
Enhance home care
Increase to DFTA to meet growing demands for
services
homecare services within the boundaries of CB
2 Queens.
21/33
DOHMH
Reduce mosquito
Continue funding NYCDOH bureau of pest
populations
control for rodent abatement and spraying for
west nile virus within CB 2.
30/33
HRA
Provide, expand, or
Provide funding for immigrant services such as
enhance
legal citizenship assistance and translation.
educational
programs for adults
YOUTH, EDUCATION AND CHILD WELFARE
Queens Community Board 2
image
M ost Important Issue Related to Youth, Education and Child Welfare
Support services for special needs youth (disabled, immigrant, non-English proficient, etc.)
This is the most important issue for the district because the current services for the disabled and immigrant children are mostly inadequate. The Sunnyside and Woodside areas have a high immigrant population in which parents aren’t always proficient in speaking English. There is a significant need for improvement in the district. There have been a number of new schools opened in the district, providing ample space for current students and for future attendees.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
CB2 is requesting funding for a high level early children center within the CB 2 district. CB 2 is requesting SCA conduct an analysis for a middle school within the boundaries of CB 2. In addition, CB 2 is requesting funding for a Beacon School.
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
30/46
SCA
Renovate other site
To establish and locate an early childhood
component
center within the Community Board 2 district
with the location of PS11 and renovate other
sites within CB 2.
31/46
SCA
Provide a new or
Request SCA to conduct analysis for an
expand an existing
additional Middle School with the boundaries of
middle/intermediate
Community Board 2.
school
32/46
SCA
Provide a new or
Request the SCA conduct an analysis for an
expand an existing
additional elementary school within the
elementary school
boundaries of Community Board 2.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
24/33
DOE
Provide more funds
Increase funding for purchase of new schools
for teaching
supplies needed for local schools.
resources such as
classroom material
31/33
DYCD
Provide, expand, or
Workforce development for disconnected youth
enhance adolescent
Queens connect
literacy programs
and services
33/33
DYCD
Provide, expand, or
Increase funding to expand the Dept of Youth
enhance
and community development for community
Cornerstone and
residents in the cornerstone and beacon
Beacon programs
program within the boundaries of CB 2.
(all ages, including
young adults)
PUBLIC SAFETY AND EMERGENCY SERVICES
Queens Community Board 2
image
M ost Important Issue Related to Public Safety and Emergency Services
Emergency service delivery (including rapid response)
The district includes Woodside, Sunnyside and LIC and is geographically spread from east to west. The current NYPD precinct is located at the western most point in LIC, very close to the East River. When residents in western Woodside and Sunnyside report a problem, it can take an excessive amount of time for the police officers to respond. Reports of broken car windows or slashed tires have resulted in wait times of 2-3 hours. This is also the reason we would like to build a new precinct building in a more centralized location of the district.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
No comments
Needs for Emergency Services
CB2 is requesting an increase in the number of police officiers at the 108th precinct to help decrease response time. CB 2 is requesting funding to FDNY to maintain manpower levels at a miminum of 5 at each engine company and 5 at each ladder company.
image
Capital Requests Related to Public Safety and Emergency Services
Priority Agency Request Explanation Location
image
1/46 NYPD Provide a new NYPD
facility, such as a new precinct house or sub-precinct
Provide funds to design and construct new police station house more centrally located within the boundaries of the 108th Precinct. We need better response time to respond to the expanding communities.Provide parking spaces.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
11/33
NYPD
Assign additional
Increase police officers at the 108th precinct to
uniformed officers
help decrease response time.
12/33
FDNY
Provide more
Request funding to FDNY to maintain manpower
firefighters or EMS
levels at a minimum of 5 at each engine
workers
company and 5 at each ladder company services
the CB 2 community and the borough of
Queens.
17/33
FDNY
Other FDNY facilities
Provide funding for Trash Water Pumps for the
and equipment
FDNY within the boundaries of CB 2.
requests (Expense)
18/33
NYPD
Assign additional
Provide funds for regular/weekly truck traffic
staff to address
enforcement at 48th Street from Northern Blvd
specific crimes (e.g.
to Queens Blvd and 48th Street and Queens Blvd
drug, gang-related,
South to 54th Avenue. Close proximenty to
vice, etc.)
highways, commercial and industrial areas
whichh create high volume of truck traffic on
48th Street. Target zone on Skillman ave from
Roosevelt Avenue to 39th Street.
20/33
NYPD
Increase resources
Increase funding for graffiti removal programs
for vandalism
within the boundaries of CB 2 queens.
prevention
programs, such as
anti-graffiti
initiatives
29/33
FDNY
Other FDNY facilities
Provide funding for the purchase of smoke
and equipment
detectors and carbon monoxide detectors to be
requests (Expense)
distributed to the elderly and families with
young children within the boundaries of CB 2.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Queens Community Board 2
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Air quality and pollution
While NYC has made great strides in reducing air pollution by eliminating coal and implementing regulations requiring conversion to natural gas or at least low-sulfur fuel No. 4 by 2030, Western Queens still earns it’s nickname, Asthma Alley. This is due to vehicular traffic, air traffic, power plants and LIRR diesel engines. Big Allis power plant on the East River, the world’s largest generating facility in the world when it was built in 1963, continues to send emissions to Western Queens. In 2000, New York Power Authority sited two 47-megawatt natural gas generators at 42-30 Vernon Boulevard. The siting of Big Allis required water access for delivery of coal (then oil) by barge, but a natural gas generator does not have the same requirement as gas is transported by pipe. The generators were opposed by all the civic groups in the area and by elected officials. They were supposed to be temporary. However, they are now approaching their 20th year of operation. It is well past time to move them. The Long Island Rail Road has major facilities in CB 2, including the massive Sunnyside Yards and the Borden Avenue rail yard for its double-Decker trains. The double-Decker trains are diesel-fueled and their engines are operated 24- hours a day, including when they are parked in the Borden Avenue yard. This creates constant air and noise pollution in LIC and air pollution during inversions all along the line. The foul weather landing pattern for LaGuardia Airport crosses CB 2. Because this use is often during inversions, jet fuel emissions are prevalent here. LIC has a long history of heavy industry. As sites are re-mediated, noxious chemicals can be released. CB 2 needs air monitoring to measure existing conditions and to evaluate improvements (or worsening conditions) as they occur.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
No comments
Needs for Sanitation Services
No comments
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
11/46
DEP
Inspect sanitary
Reconstruct 61st Street from 39th Avenue to
61st Street
sewer on specific
37th Avenue including sewers and catch basins
39th Avenue
street segment and
37th Avenue
repair or replace as
needed (Capital)
14/46
DEP
Inspect sanitary
Reconstrct Hunters Point Sewers to provide
sewer on specific
adequate service for Hunters Point Waterfront
street segment and
Development and existing homes and
repair or replace as
manufacturing companies in Hunters Point
needed (Capital)
residential area. DEP should study the entire
Hunters Point sewer system to determine areas
that require new sewers and catch basins. From
Newtown Creek to 44th Drive; from East River
west to Jackson Avenue.
15/46
DEP
Inspect sanitary
Redesign and construct sewers and catch basins
sewer on specific
to eliminate and prevent flooding. Locations
street segment and
include 58th Street to 69th Street. Tyler Avenue
repair or replace as
to Maurice Avenue to Laurel Hill Boulevard and
needed (Capital)
Queens Boulevard
19/46
DEP
Inspect sanitary
Reconstruct Borden Avenue between Van Dam
sewer on specific
Street and 30th Street, and 30th place, 31st
street segment and
Street, 31st Place between Borden Avenue.
repair or replace as
Include new catch basins and improved
needed (Capital)
drainage to relieve chronic flooding conditions.
DEP to develop drainage plan to build new or
expand storm sewers.
21/46
DEP
Evaluate a public
Provide funding for green infrastructure for a
location or property
bioswale at Bradley Avenue and Van Dam
for green
Triangle.
infrastructure, e.g.
rain gardens,
stormwater
greenstreets, green
playgrounds
22/46
DEP
Evaluate a public
Request funds to create a bioswale on the east
location or property
side of dutch kills turning basin at 29th Street.
for green
infrastructure, e.g.
rain gardens,
stormwater
greenstreets, green
playgrounds
34/46 DEP Inspect water main
on specific street segment and repair or replace as needed (Capital)
Support funds to reconstruct streets, replace sewers / catch basins as recommended by the west maspeth task force and the maspeth Industrial commerial owners local development corp.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/33
DEP
Investigate air
Air Monitors, request annual air quality testing
quality complaints
by expert firm or vendor to conduct testing and
at specific location
locations to be determined within the
boundaries of Community Board 2 and the
following areas: Borden Avenue, 5th Street ,
Aviation HS, Queens Blvd, Midtown Tunnel, rail
yards, General Woodside area, proximity of the
Airport..
3/33
DEP
Inspect storm sewer
For the entire CB 2 district, Inspect storm
on specific street
sewers, with a huge growth in Western Queens
segment and
public services needs for a livable, equitable and
service, repair or
sustainable community.. Provide funding for
replace as needed
storm sewers.
6/33
DEP
Investigate and
Investigate the persistent problem with lead in
address water
drinking water in schools, and senior centers
quality complaints
within CB 2 to be tested.
at an address or on
specific street
segments
32/33
DSNY
Other garbage
CB 2 supports DOS need for new equipment
collection and
called a Holster.
recycling requests
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Queens Community Board 2
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Neighborhood preservation
There are multiple overlapping aspects that we see a part and parcel to neighborhood preservation. We have therefore selected the area that we believe would encompass most of the listed items. In particular, older established neighborhoods are experiencing destabilizing levels of density and displacement as well as diminished services. Newer neighborhoods are having difficulty becoming and sustaining as neighborhoods because costs encourage higher turnover and basic services and entities that would be part of an organically evolved community do not exist. We recognize that among the most important integral significant issues are: deeply affordable housing, and deeply affordable small business, maker, and artist space. Equally important and integral is commercial district revitalization particularly as it applies to existing small storefronts, small business services and support, and workforce development that dovetails with existing businesses. The district has experienced many changes from outside coming in. Support is needed toward preserving what we already have had from within. All of the most important housing, economic development and land use issues should be informed by the basic necessity to preserve and protect the quality, character, and economy of all the existing neighborhoods that comprise CB 2.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
CB2 is seeking EDC funds to develop open accessible space on EDC property in area north of 44th Drive, west of Department of Education building and east of the east river. CB2 is requesting that 44-02 Vernon Blvd back fill the entire site. This is a site that has been abandoned. City should foreclose and seize property for development.
Needs for Housing
To expand the 421 A exclusion zone to encompass the entire Queens Plaza Sub District and study the impact of increasing the FAR in the subdistrict to accommodate inclusionary zoning.
Needs for Economic Development
CB2 is seeking the Economic Development Corp to develop open accessible space on EDC property in area north of 44thDrive, west of Department of Education building and east of the east river in Long Island City.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
2/46
EDC
Invest in capital
Encourage EDC to acquire the DOE building and
projects to improve
preserve accessible space on EDC property in
access to the
area north of 44th Drive, west of Board of
waterfront
Education dept building and east of the east
River. Transfer control from DOE to EDC for the
creation of mixed use, job training, Arts,
recreational facility and maker space to be
managed by a non profit organization.
Community has advocated for these uses for a
number of years.
3/46
EDC
Invest in capital
Invest in Capital Projects to improve access to
projects to improve
the waterfront with public land from the DOT
access to the
building SW of DOE building along 44th Drive to
waterfront
waterfront.. Create Public Land to advance
economic development on all remaining city
property and public access to the waterfront.
Invest in piers and other capital projects along
the waterfront.
4/46
EDC
Improve
Improve streetcape in business districts to
61st Street
streetscapes in
attract and encourage commercial activity
and Roosevelt
business districts to
within the Commercial corridor at 61st Street /
Avenue
attract/encourage
Roosevelt Avenue. To preserve, support
commercial activity
enhance, repair, replace Street lighting,
(i.e., lighting,
sidewalks, loose bricks. In addition, encourage
sidewalks)
new businesses and preserve existing
businesses.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
1/33
DCP
Study land use and
Comprehensive development plan for the entire
zoning to better
CB 2 district.
match current use
or future
neighborhood
needs
4/33
SBS
Support local, long-
Study improvements needed for small and local
standing businesses
businesses to ensure success rates.
5/33
SBS
Other expense commercial district revitalization requests
Improve the Commercial District of Woodside from 56th Street to 69th Street
14/33
DOB
Assign additional
Increase DOB personnel services budget to
building inspectors
allow for hiring of additional inspectors for
(including
Queens.
expanding training
programs)
22/33
NYCHA
Expand programs
Provide additional funds to increase code
for housing
enforcement inspectors and emergency repair
inspections to
inspectors at HPD.
correct code
violations
28/33
NYCHA
Expand programs
Increase funding to hire more ligitation attorney
for housing
for HPD.
inspections to
correct code
violations
TRANSPORTATION
Queens Community Board 2
image
M ost Important Issue Related to Transportation and Mobility
Subway crowding and quality issues
Most residents of the district use mass transportation when traveling to and from work. We are serviced primarily by the 7 and E trains. As the population and number of commuters has increased along the train lines, the infrastructure has not been keeping pace causing services to be severely inadequate. The 7 train is over capacity and there are often delays during rush hours. Westbound express trains originate in Flushing and are available at the 61st Street Woodside location, but are usually too crowded to enter. The same conditions are true for Sunnyside commuters on the local line. Additional trains and better service are long overdue. Falling debris from the elevated 7 train in Woodside has become a serious issue. There have been several instances in which large and small pieces of metal have come close to causing severe harm to pedestrians below. A temporary solution of netting has been implemented, but a long term solution will be needed in the near future. The 52nd, 61st and 69th Street subway stations are decrepit and in desperate need of repair. Peeling paint, poor lighting and unstable steps should be immediately addressed. The lack of accessibility is also of major concern. The volume of commuters at the 61st Street has increased exponentially, causing constant maintenance issues of the escalator (MTA) and elevator (LIRR). More needs to be done to ensure both are working properly on a regular basis.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
No comments
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
5/46
NYCTA
Improve
Improve.and upgrade transit in the district
accessibility of
including upgrade and install elevators. CB 2
transit
prioritizes 5 locations for accessibility for all
infrastructure, by
public district wide capital improvements:
providing elevators,
Vernon/Jackson Court Square, Queensboro
escalators, etc.
plaza 40th Street, 61st Street, 52nd Street
7/46
DOT
Roadway
Reconstruct Winfield Industrial Streets from
maintenance (i.e.
69th Street to 72nd Drive, Queens Boulevard to
pothole repair,
Maurice Avenue. Repair or construct new
resurfacing, trench
streets, sidewalks, curbs, medians, pedestrian
restoration, etc.)
ramps or bus pads.
10/46
DOT
Reconstruct streets
Reconstruct Vernon Blvd near 53rd Avenue and
Vernon Blvd
Newtown Creek, as the roadway is collapsing.
53rd Ave
Newtown
Creek
16/46
DOT
Reconstruct streets
Request full reconstruction of the service roads
Queens Blvd
from Queens Blvd from 69th Street to 48th
69th St 48th
Street.
St
18/46
DOT
Repair or provide
Request funds to improve street lighting under
new street lights
LIRR overpasses as well as under the LIE and
BQE overpasses within CB 2. Additional lighting
survey needed for specific locations near 61st
Street.
20/46
DOT
Reconstruct streets
Reconstruct Barnett Avenue between 48th
Barnett Ave
Street and 52nd Streets to include catch basins,
48th St 52nd
sidewalks, on both sides of the street and
St
retaining walls.
24/46
DOT
Reconstruct streets
Reconstruct street on Greenpoint Avenue
Greenpoint
between Starr Avenue and Review Avenue
Ave Starr Ave
Review Ave
26/46
DOT
Reconstruct streets
Request funds for the design and reconstruction
48th Ave 65th
of 48th Avenue between 65th Place and 72nd
place 72nd st
Street in the Winfield area of Woodside
27/46
DOT
Rehabilitate bridges
Support funding for the reconstruction of the
51st Avenue pedestrian bridge over LIRR
mainline. Need to increase lighting levels.
29/46
NYCTA
Other transit
NYCTA - Provide funding to create and install
infrastructure
barriers, signage, and birth control to curtail
requests
pigeon population and droppings and provide
funding to prevent roosting and nesting along
the 7 train with the CB 2 boundaries. Provide
funding for powerwashing to entrances and
subway stairs at stations.
33/46
DOT
Reconstruct streets
Reconstruct Hunters Point Streets. All side
streets including 11th Street, 21st Street and
23rd Street and Vernon Boulevard from 51st
Avenue to 44th Drive.
35/46
DOT
Other
Provide funding to reconstruct the Woodside
transportation
Avenue Bridge over the LIRR to include
infrastructure
sidewalks and replacement fencing
requests
36/46
DOT
Repair or construct
Install and replace sidewalks at 69th place
69th Place
new curbs or
between garfield avenue and 51st avenue.
Garfield Ave
pedestrian ramps
51st Ave
38/46
DOT
Repair or construct
Request sidewalk installation on hicks drive
Hicks Dr 63rd
new curbs or
between 63rd Street and 64th Street.
St 64th St
pedestrian ramps
39/46
NYCTA
Other transit
Provide LIRR funds to create, install barriers,
infrastructure
signage and birth control to curtail pigeon
requests
droppings and nesting under overpasses within
the boundaries of community board 2.
41/46
DOT
Other
Allocate funds to create / install barriers to
transportation
curtail pigeon droppings and nesting under
infrastructure
arterial roadway overpasses in CB 2.
requests
43/46
DOT
Other
Replace sidewalk pavers from 58th Street to
transportation
63rd Street along Roosevelt Avenue corridor. ,
infrastructure
61st Street between Roosevelt Avenue and
requests
Woodside Avenue.
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
8/33 NYCTA Other transit service
requests
Improve the efficiency of access a ride services for seniors and the disabled. This is in response to the comptrollers report, community needs and demand.
image
27/33 DOT Other expense
traffic improvements requests
FUND NYCDOT to maintain current levels of manpower assigned to the sign shop, pothole crews, and personnel to conduct traffic studies.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Queens Community Board 2
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Insufficient park or open space
LIC is the fastest growing neighborhood in the country and it also has the lowest ratio of people to open space. The overdevelopment of the area in an relatively short period of time has left the neighborhood at a deficit. Blissville and Court Square fall under similar circumstances. While Blissville is primarily an industrial and manufacturing area, there are a core group of residents that live there; some for generations. The three new homeless shelters leave them at a further disadvantage. There are several hundred additional residents with no park or open spaces to enjoy. There is an open lot on Van Dam that was being considered for a park, but it was determined by Parks and DOT to be an unsuitable location. Court Square was initially zoned for commercial development but quickly became a growing residential neighborhood. It has become a family-oriented community, but a lack of open space and schools need to be addressed.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
No comments
Needs for Cultural Services
No comments
Needs for Library Services
CB2 is welcoming the new Hunters Point South Library that has been in the pipeline for a while. CB 2 is always looking for libraries to be continually funded.
Needs for Community Boards
Community Boards are always in need of additional funding to keep up with the growing and changing needs of our community with changes in technology and provide our community with our charter mandidated responsibilities.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
9/46
DPR
Provide a new or
Request funding to identify and acquire site for
Bradley Ave
expanded park or
a site for a park in the Blissville Community.
Van Dam St
amenity (i.e.
Bradley Ave
playground, outdoor
athletic field)
23/46
DPR
Other requests for
Request Park dept funding to refurbish veterans
park, building, or
memorial square (Civil war Momument) parks
access
property in Old Calvary Cemetery.
improvements
25/46
DPR
Other requests for
Request removed flag pole and flag to be
park, building, or
replaced in Van Dam Park at the base of
access
Greenpoint Avenue bridge at triangle park.
improvements
28/46
DPR
Plant new street
Continue to support funding for continued tree
trees
planting new and replace missing street trees
within CB 2.
37/46
DPR
Reconstruct or
Reconstruct Little Bush Park and new play
upgrade a park or
equipment.
amenity (i.e.
playground, outdoor
athletic field)
40/46
DPR
Improve access to a
Request Hart Playground water fountain and
park or amenity (i.e.
park improvements.
playground, outdoor
athletic field)
42/46
DPR
Provide a new or
Provide funding for the city to aquire lot on
50th St 39th
expanded park or
corner of 50th Street and 39th Avenue for a
Ave
amenity (i.e.
communitiy playground.
playground, outdoor
athletic field)
44/46
DPR
Reconstruct or
Allocate funds to renovate Baby Park near
upgrade a park or
Queenscbridge Houses.
amenity (i.e.
playground, outdoor
athletic field)
45/46 DPR Reconstruct or
upgrade a park or amenity (i.e. playground, outdoor athletic field)
Court Square Park revitalization to move the fountain and restore the park in front of the court house.
image
46/46 DPR Provide a new or
expanded park or amenity (i.e. playground, outdoor athletic field)
Allocate funds to create a park at Rafferty Triangle and the Citicorp Building.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
7/33
DPR
Provide better park
Provide funding for parks for increased
maintenance
maintenance within all parks though out
Community Board 2.
13/33
DPR
Other street trees
Provide funds to NYC parks dept for Tree
and forestry
pruning and stump removal contracts for the
services requests
boundaries of CB 2, in Sunnyside Gardens.
Increase funds to NYC parks dept / forestry
division to enable the agency to secure dead
tree and stump removal contracts.
15/33
DPR
Other park
Provide funding for all parks for increased
maintenance and
security within all parks throughout CB 2.
safety requests
16/33
DPR
Provide better park
Continue to support funds for six month
maintenance
seasonal associates and six month playground
associates for CB 2 parks and playgrounds.
25/33
DPR
Provide better park
Horticulture maintenance program - funding for
maintenance
this program will provide staffing to maintain
park landscapes, gardens, lawns and other
horticultural amenities.
26/33
DPR
Provide better park
Continue to support funding for parks
maintenance
department to hire maintenance personnel on a
full time line to up keep parks within CB 2.
image
6. OTHER BUDGET REQUESTS
Other Capital Requests
Priority
Agency
Request
Explanation
Location
12/46
Other
Other capital budget
EDC - Request city to work with CB 2 to
request
construct affordable housing locations. Allocate
funding to acquire department of Education
building on 44th Drive.
13/46
Other
Other capital budget
EDC - Acquire and seize the location known as
44-02 Vernon
request
Lake Vernon at 44-02 Vernon Blvd. CB 2 is
Boulevard,
requesting to back fill the entire site. This is a
Queens, New
stalled construction site that CB 2 is looking for
York, NY
the City to condemn and seize property to be
appropriately developed to benefit the
community.
17/46
Other
Other capital budget
Request funding for broken water distribution
Woodside
request
regulator for the woodside community. To also
Avenue 56
include reconstruction of sewers and catch
Street 58
basins on woodside ave between 56th Street
Street
and 58th Street.
Other Expense Requests
Priority
Agency
Request
Explanation
Location
23/33
Other
Other expense budget request
Queens Library - Increase funding for purchase of new books and other materials needed to meet the growing demand of library usage within the CB 2 Queens district.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/46
NYPD
Provide a new NYPD
Provide funds to design and construct new
facility, such as a
police station house more centrally located
new precinct house
within the boundaries of the 108th Precinct. We
or sub-precinct
need better response time to respond to the
expanding communities.Provide parking spaces.
2/46
EDC
Invest in capital
Encourage EDC to acquire the DOE building and
projects to improve
preserve accessible space on EDC property in
access to the
area north of 44th Drive, west of Board of
waterfront
Education dept building and east of the east
River. Transfer control from DOE to EDC for the
creation of mixed use, job training, Arts,
recreational facility and maker space to be
managed by a non profit organization.
Community has advocated for these uses for a
number of years.
3/46
EDC
Invest in capital
Invest in Capital Projects to improve access to
projects to improve
the waterfront with public land from the DOT
access to the
building SW of DOE building along 44th Drive to
waterfront
waterfront.. Create Public Land to advance
economic development on all remaining city
property and public access to the waterfront.
Invest in piers and other capital projects along
the waterfront.
4/46
EDC
Improve
Improve streetcape in business districts to
61st Street
streetscapes in
attract and encourage commercial activity
and Roosevelt
business districts to
within the Commercial corridor at 61st Street /
Avenue
attract/encourage
Roosevelt Avenue. To preserve, support
commercial activity
enhance, repair, replace Street lighting,
(i.e., lighting,
sidewalks, loose bricks. In addition, encourage
sidewalks)
new businesses and preserve existing
businesses.
5/46
NYCTA
Improve
Improve.and upgrade transit in the district
accessibility of
including upgrade and install elevators. CB 2
transit
prioritizes 5 locations for accessibility for all
infrastructure, by
public district wide capital improvements:
providing elevators,
Vernon/Jackson Court Square, Queensboro
escalators, etc.
plaza 40th Street, 61st Street, 52nd Street
6/46
HHC
Provide a new or expanded health care facility
Increase number of health care facilities due to hospital closings in Western Queens within CB 2. expand primary care services to CB 2 area as part of the caring neighborhood initiative.
7/46
DOT
Roadway
Reconstruct Winfield Industrial Streets from
maintenance (i.e.
69th Street to 72nd Drive, Queens Boulevard to
pothole repair,
Maurice Avenue. Repair or construct new
resurfacing, trench
streets, sidewalks, curbs, medians, pedestrian
restoration, etc.)
ramps or bus pads.
8/46
DFTA
Create a new senior
Obtain funding for a acquistion for site for a
center or other
new senior / community center in Hunters Point.
facility for seniors
9/46
DPR
Provide a new or
Request funding to identify and acquire site for
Bradley Ave
expanded park or
a site for a park in the Blissville Community.
Van Dam St
amenity (i.e.
Bradley Ave
playground, outdoor
athletic field)
10/46
DOT
Reconstruct streets
Reconstruct Vernon Blvd near 53rd Avenue and
Vernon Blvd
Newtown Creek, as the roadway is collapsing.
53rd Ave
Newtown
Creek
11/46
DEP
Inspect sanitary
Reconstruct 61st Street from 39th Avenue to
61st Street
sewer on specific
37th Avenue including sewers and catch basins
39th Avenue
street segment and
37th Avenue
repair or replace as
needed (Capital)
12/46
Other
Other capital budget
EDC - Request city to work with CB 2 to
request
construct affordable housing locations. Allocate
funding to acquire department of Education
building on 44th Drive.
13/46
Other
Other capital budget
EDC - Acquire and seize the location known as
44-02 Vernon
request
Lake Vernon at 44-02 Vernon Blvd. CB 2 is
Boulevard,
requesting to back fill the entire site. This is a
Queens, New
stalled construction site that CB 2 is looking for
York, NY
the City to condemn and seize property to be
appropriately developed to benefit the
community.
14/46
DEP
Inspect sanitary
Reconstrct Hunters Point Sewers to provide
sewer on specific
adequate service for Hunters Point Waterfront
street segment and
Development and existing homes and
repair or replace as
manufacturing companies in Hunters Point
needed (Capital)
residential area. DEP should study the entire
Hunters Point sewer system to determine areas
that require new sewers and catch basins. From
Newtown Creek to 44th Drive; from East River
west to Jackson Avenue.
15/46
DEP
Inspect sanitary
Redesign and construct sewers and catch basins
sewer on specific
to eliminate and prevent flooding. Locations
street segment and
include 58th Street to 69th Street. Tyler Avenue
repair or replace as
to Maurice Avenue to Laurel Hill Boulevard and
needed (Capital)
Queens Boulevard
16/46
DOT
Reconstruct streets
Request full reconstruction of the service roads
Queens Blvd
from Queens Blvd from 69th Street to 48th
69th St 48th
Street.
St
17/46
Other
Other capital budget
Request funding for broken water distribution
Woodside
request
regulator for the woodside community. To also
Avenue 56
include reconstruction of sewers and catch
Street 58
basins on woodside ave between 56th Street
Street
and 58th Street.
18/46
DOT
Repair or provide
Request funds to improve street lighting under
new street lights
LIRR overpasses as well as under the LIE and
BQE overpasses within CB 2. Additional lighting
survey needed for specific locations near 61st
Street.
19/46
DEP
Inspect sanitary
Reconstruct Borden Avenue between Van Dam
sewer on specific
Street and 30th Street, and 30th place, 31st
street segment and
Street, 31st Place between Borden Avenue.
repair or replace as
Include new catch basins and improved
needed (Capital)
drainage to relieve chronic flooding conditions.
DEP to develop drainage plan to build new or
expand storm sewers.
20/46
DOT
Reconstruct streets
Reconstruct Barnett Avenue between 48th
Barnett Ave
Street and 52nd Streets to include catch basins,
48th St 52nd
sidewalks, on both sides of the street and
St
retaining walls.
21/46
DEP
Evaluate a public
Provide funding for green infrastructure for a
location or property
bioswale at Bradley Avenue and Van Dam
for green
Triangle.
infrastructure, e.g.
rain gardens,
stormwater
greenstreets, green
playgrounds
22/46
DEP
Evaluate a public
Request funds to create a bioswale on the east
location or property
side of dutch kills turning basin at 29th Street.
for green
infrastructure, e.g.
rain gardens,
stormwater
greenstreets, green
playgrounds
23/46
DPR
Other requests for
Request Park dept funding to refurbish veterans
park, building, or
memorial square (Civil war Momument) parks
access
property in Old Calvary Cemetery.
improvements
24/46
DOT
Reconstruct streets
Reconstruct street on Greenpoint Avenue
Greenpoint
between Starr Avenue and Review Avenue
Ave Starr Ave
Review Ave
25/46
DPR
Other requests for
Request removed flag pole and flag to be
park, building, or
replaced in Van Dam Park at the base of
access
Greenpoint Avenue bridge at triangle park.
improvements
26/46
DOT
Reconstruct streets
Request funds for the design and reconstruction
48th Ave 65th
of 48th Avenue between 65th Place and 72nd
place 72nd st
Street in the Winfield area of Woodside
27/46
DOT
Rehabilitate bridges
Support funding for the reconstruction of the
51st Avenue pedestrian bridge over LIRR
mainline. Need to increase lighting levels.
28/46
DPR
Plant new street
Continue to support funding for continued tree
trees
planting new and replace missing street trees
within CB 2.
29/46
NYCTA
Other transit
NYCTA - Provide funding to create and install
infrastructure
barriers, signage, and birth control to curtail
requests
pigeon population and droppings and provide
funding to prevent roosting and nesting along
the 7 train with the CB 2 boundaries. Provide
funding for powerwashing to entrances and
subway stairs at stations.
30/46
SCA
Renovate other site component
To establish and locate an early childhood center within the Community Board 2 district with the location of PS11 and renovate other sites within CB 2.
31/46
SCA
Provide a new or
Request SCA to conduct analysis for an
expand an existing
additional Middle School with the boundaries of
middle/intermediate
Community Board 2.
school
32/46
SCA
Provide a new or
Request the SCA conduct an analysis for an
expand an existing
additional elementary school within the
elementary school
boundaries of Community Board 2.
33/46
DOT
Reconstruct streets
Reconstruct Hunters Point Streets. All side
streets including 11th Street, 21st Street and
23rd Street and Vernon Boulevard from 51st
Avenue to 44th Drive.
34/46
DEP
Inspect water main
Support funds to reconstruct streets, replace
on specific street
sewers / catch basins as recommended by the
segment and repair
west maspeth task force and the maspeth
or replace as
Industrial commerial owners local development
needed (Capital)
corp.
35/46
DOT
Other
Provide funding to reconstruct the Woodside
transportation
Avenue Bridge over the LIRR to include
infrastructure
sidewalks and replacement fencing
requests
36/46
DOT
Repair or construct
Install and replace sidewalks at 69th place
69th Place
new curbs or
between garfield avenue and 51st avenue.
Garfield Ave
pedestrian ramps
51st Ave
37/46
DPR
Reconstruct or
Reconstruct Little Bush Park and new play
upgrade a park or
equipment.
amenity (i.e.
playground, outdoor
athletic field)
38/46
DOT
Repair or construct
Request sidewalk installation on hicks drive
Hicks Dr 63rd
new curbs or
between 63rd Street and 64th Street.
St 64th St
pedestrian ramps
39/46
NYCTA
Other transit
Provide LIRR funds to create, install barriers,
infrastructure
signage and birth control to curtail pigeon
requests
droppings and nesting under overpasses within
the boundaries of community board 2.
40/46
DPR
Improve access to a park or amenity (i.e. playground, outdoor athletic field)
Request Hart Playground water fountain and park improvements.
41/46
DOT
Other
Allocate funds to create / install barriers to
transportation
curtail pigeon droppings and nesting under
infrastructure
arterial roadway overpasses in CB 2.
requests
42/46
DPR
Provide a new or
Provide funding for the city to aquire lot on
50th St 39th
expanded park or
corner of 50th Street and 39th Avenue for a
Ave
amenity (i.e.
communitiy playground.
playground, outdoor
athletic field)
43/46
DOT
Other
Replace sidewalk pavers from 58th Street to
transportation
63rd Street along Roosevelt Avenue corridor. ,
infrastructure
61st Street between Roosevelt Avenue and
requests
Woodside Avenue.
44/46
DPR
Reconstruct or
Allocate funds to renovate Baby Park near
upgrade a park or
Queenscbridge Houses.
amenity (i.e.
playground, outdoor
athletic field)
45/46
DPR
Reconstruct or
Court Square Park revitalization to move the
upgrade a park or
fountain and restore the park in front of the
amenity (i.e.
court house.
playground, outdoor
athletic field)
46/46
DPR
Provide a new or
Allocate funds to create a park at Rafferty
expanded park or
Triangle and the Citicorp Building.
amenity (i.e.
playground, outdoor
athletic field)
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/33
DCP
Study land use and
Comprehensive development plan for the entire
zoning to better
CB 2 district.
match current use
or future
neighborhood
needs
2/33
DEP
Investigate air
Air Monitors, request annual air quality testing
quality complaints
by expert firm or vendor to conduct testing and
at specific location
locations to be determined within the
boundaries of Community Board 2 and the
following areas: Borden Avenue, 5th Street ,
Aviation HS, Queens Blvd, Midtown Tunnel, rail
yards, General Woodside area, proximity of the
Airport..
3/33
DEP
Inspect storm sewer
For the entire CB 2 district, Inspect storm
on specific street
sewers, with a huge growth in Western Queens
segment and
public services needs for a livable, equitable and
service, repair or
sustainable community.. Provide funding for
replace as needed
storm sewers.
4/33
SBS
Support local, long-
Study improvements needed for small and local
standing businesses
businesses to ensure success rates.
5/33
SBS
Other expense
Improve the Commercial District of Woodside
commercial district
from 56th Street to 69th Street
revitalization
requests
6/33
DEP
Investigate and
Investigate the persistent problem with lead in
address water
drinking water in schools, and senior centers
quality complaints
within CB 2 to be tested.
at an address or on
specific street
segments
7/33
DPR
Provide better park
Provide funding for parks for increased
maintenance
maintenance within all parks though out
Community Board 2.
8/33
NYCTA
Other transit service
Improve the efficiency of access a ride services
requests
for seniors and the disabled. This is in response
to the comptrollers report, community needs
and demand.
9/33
HRA
Provide, expand, or enhance educational programs for adults
Provide funding to social adult day services programs.
10/33
DFTA
Other senior center
Increase funds for DFTA to meet growing
program requests
demands for day care programs for seniors
including Alzheimer's programs to establish a
baseline for funding.
11/33
NYPD
Assign additional
Increase police officers at the 108th precinct to
uniformed officers
help decrease response time.
12/33
FDNY
Provide more
Request funding to FDNY to maintain manpower
firefighters or EMS
levels at a minimum of 5 at each engine
workers
company and 5 at each ladder company services
the CB 2 community and the borough of
Queens.
13/33
DPR
Other street trees
Provide funds to NYC parks dept for Tree
and forestry
pruning and stump removal contracts for the
services requests
boundaries of CB 2, in Sunnyside Gardens.
Increase funds to NYC parks dept / forestry
division to enable the agency to secure dead
tree and stump removal contracts.
14/33
DOB
Assign additional
Increase DOB personnel services budget to
building inspectors
allow for hiring of additional inspectors for
(including
Queens.
expanding training
programs)
15/33
DPR
Other park
Provide funding for all parks for increased
maintenance and
security within all parks throughout CB 2.
safety requests
16/33
DPR
Provide better park
Continue to support funds for six month
maintenance
seasonal associates and six month playground
associates for CB 2 parks and playgrounds.
17/33
FDNY
Other FDNY facilities
Provide funding for Trash Water Pumps for the
and equipment
FDNY within the boundaries of CB 2.
requests (Expense)
18/33
NYPD
Assign additional
Provide funds for regular/weekly truck traffic
staff to address
enforcement at 48th Street from Northern Blvd
specific crimes (e.g.
to Queens Blvd and 48th Street and Queens Blvd
drug, gang-related,
South to 54th Avenue. Close proximenty to
vice, etc.)
highways, commercial and industrial areas
whichh create high volume of truck traffic on
48th Street. Target zone on Skillman ave from
Roosevelt Avenue to 39th Street.
19/33
DFTA
Enhance home care
Increase to DFTA to meet growing demands for
services
homecare services within the boundaries of CB
2 Queens.
20/33
NYPD
Increase resources
Increase funding for graffiti removal programs
for vandalism
within the boundaries of CB 2 queens.
prevention
programs, such as
anti-graffiti
initiatives
21/33
DOHMH
Reduce mosquito
Continue funding NYCDOH bureau of pest
populations
control for rodent abatement and spraying for
west nile virus within CB 2.
22/33
NYCHA
Expand programs
Provide additional funds to increase code
for housing
enforcement inspectors and emergency repair
inspections to
inspectors at HPD.
correct code
violations
23/33
Other
Other expense
Queens Library - Increase funding for purchase
budget request
of new books and other materials needed to
meet the growing demand of library usage
within the CB 2 Queens district.
24/33
DOE
Provide more funds
Increase funding for purchase of new schools
for teaching
supplies needed for local schools.
resources such as
classroom material
25/33
DPR
Provide better park
Horticulture maintenance program - funding for
maintenance
this program will provide staffing to maintain
park landscapes, gardens, lawns and other
horticultural amenities.
26/33
DPR
Provide better park
Continue to support funding for parks
maintenance
department to hire maintenance personnel on a
full time line to up keep parks within CB 2.
27/33
DOT
Other expense traffic improvements requests
FUND NYCDOT to maintain current levels of manpower assigned to the sign shop, pothole crews, and personnel to conduct traffic studies.
28/33
NYCHA
Expand programs
Increase funding to hire more ligitation attorney
for housing
for HPD.
inspections to
correct code
violations
29/33
FDNY
Other FDNY facilities
Provide funding for the purchase of smoke
and equipment
detectors and carbon monoxide detectors to be
requests (Expense)
distributed to the elderly and families with
young children within the boundaries of CB 2.
30/33
HRA
Provide, expand, or
Provide funding for immigrant services such as
enhance
legal citizenship assistance and translation.
educational
programs for adults
31/33
DYCD
Provide, expand, or
Workforce development for disconnected youth
enhance adolescent
Queens connect
literacy programs
and services
32/33
DSNY
Other garbage
CB 2 supports DOS need for new equipment
collection and
called a Holster.
recycling requests
33/33
DYCD
Provide, expand, or
Increase funding to expand the Dept of Youth
enhance
and community development for community
Cornerstone and
residents in the cornerstone and beacon
Beacon programs
program within the boundaries of CB 2.
(all ages, including
young adults)

