- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 7 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1DDwTfVua1bxXJX4QeJl7DvfH4Uc3zx5P/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1DDwTfVua1bxXJX4QeJl7DvfH4Uc3zx5P/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
7
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 7
image
Address: 4201 4th Avenue Phone: (718) 854-0003
Email: bk07@cb.nyc.gov
Website: www.nyc.gov/brooklyncb7
Chair: Cesar Zuñiga District Manager: Jeremy Laufer
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community District 7 is a mixed residential, industrial and commercial community. Home to a diverse and integrated population, the District is comprised of two main communities: Sunset Park and Windsor Terrace. Other community identities have gained popularity and become more established recently, including Greenwood Heights and South Park Slope. Sunset Park consists of a strong residential community, two viable commercial strips, 5th and 8th Avenues and a large industrial area, mainly along the waterfront. It is bifurcated by the Gowanus Expressway and is bordered to the south by the Long Island Rail Road cut. The 23-acre facility, Sunset Park, has an Olympic-sized swimming pool, a recreation center and a large open space with spectacular views of the harbor. Windsor Terrace and the northern part of the district consist of a smaller residential community with three commercial strips on 5th and 7th Avenues and Prospect Park West. Windsor Terrace is surrounded by the natural boundaries of Prospect Park and Green-Wood Cemetery. The Gothic Brownstone “gatehouse” at the cemetery’s entrance is a New York City landmark and the most widely known symbol of the community. The District has been home to generations of immigrants, Irish and Italian and Scandinavian in the early 20th century and before. Mid-century saw an influx from Puerto Rico, then immigrants from the Dominican Republic and from central and South America. The 1980s saw a large increase in residents from China and the 90s began an influx from Mexico, more rural areas of China and, to a lesser extent, the Middle East. Our community is extremely diverse and yet our populations live mostly in peace, making for a family-friendly neighborhood. The residents have learned to organize to fight for resources and demand change and our collective action has produced positive results. We defeated a floating power plant in 2004 that would have been taller than any building in the area and longer than the Titanic. We rezoned most of our residential community in 2005 and 2009. After a 40-year effort, we finally built a local high school in 2009 and followed that up with four additional schools and five more in progress. We finished our 197-a Plan, which calls for the enhancement of our industrial waterfront, improved environmental performance and additional recreation opportunities on our waterfront and it was passed by the City. New businesses are bringing investment and jobs to our waterfront. The Community Board, along with six community organizations, negotiated a reduction in emissions from two of our local power plants. We are home to a bio-technology center, enormous economic development investments at Industry City, Liberty View Plaza, the Brooklyn Army Terminal, Bush Terminal and the South Brooklyn Marine Terminal and we have the capacity to continue to grow our industrial sector with good-paying jobs for local residents. We have led the local effort to improve pedestrian safety and redesign our streets for safety and mobility improvements. Clearly, positive changes and investments are being made in our community, but more needs to be done for a community that had been left behind in the past. Our Board has been forward-looking and aggressive in our pursuit of investments and infrastructure improvements that will enhance the lives and livelihoods of our residents, workers and business owners. However, there continue to be sections of our community that have not received sufficient investments and improvements and this continues to leave some of our residents behind. Our community has overcrowded schools, an insufficient amount of parkland, second oldest housing stock in NYC according to NYU, and not nearly enough affordable and senior housing units. Our waterfront access is extremely limited. There are concerns that the investments being made may not have a positive impact on the local residents and may exacerbate economic pressures and displacement. Many of our streets remain dangerous to cross and have crumbling infrastructure. Public transportation does not extend far enough and is in need of upgrades. We do not have fiber-optic cable and more than 20% of households in Sunset Park do not have internet service, according to a recent survey. The Gowanus Expressway is under constant construction and continues to bring 50 million emission-spewing vehicles through our community every year.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 7
image
The three most pressing issues facing this Community Board are:
Affordable housing
Affordable Housing With increasing income inequality and a tightening market for affordable housing, long-time residents of Community Board 7 Brooklyn are being displaced and or forced to live in severely overcrowded conditions. Few units of affordable housing are being built and existing affordable housing is being lost through landlords opting-out, speculative development and tenant harassment. There are a range of new insights into the relationship between affordable housing and life outcomes for children and families. Development and Job Creation With recent development and proposed development projects along the district’s waterfront many opportunities and challenges present themselves. Some of the opportunities include community-led SMART growth strategies; in the other words the planning of community development that is sustainable, compact, transit-oriented, walkable, bicycle-friendly land use, including neighborhood schools, complete streets, and mixed-use development with a range of housing choices. Billions of dollars in public and private development is being invested in the Sunset Park waterfront, potential creating thousands of new jobs with good wages. CB 7 has long sought to protect its industrial community because of the economic benefits that can come. However, there are negatives associated with proximity to industry, including heavy truck traffic and emissions. We believe the residents who must endure these hardships should be prioritized when it comes to reaping the benefits of these investments.
Schools
Education and Early Childhood Development Despite the construction of new schools since 2009 and new construction on six new sites, CB 7 still lacks an adequate number of seats and facilities, particularly for pre-k students, students with developmental disabilities and students whose native language is not English. The district lacks space of appropriate size for additional school development and we must think creatively to find new spaces. Sunset Park has a birthrate that is nearly double that of New York City’s. The high birthrate of our community creates the need for vital support services; initiatives to support parents, promote child health and safety, and improve access to high-quality childcare can help the district in five key ways: Positive experiences between birth and school entry boost a child’s healthy development and future prospects. Research clearly demonstrates that the “hard wiring” of a child’s brain occurs during these early years. Children who get off to a good start are less likely to be held back or to get into trouble in school. Studies have even shown that early childhood success can lead to higher college graduation rates, lower crime rates, and reduced need for emergency services many years later.
Families are more stable when the needs of their young children are met. When children are healthy and in reliable care, their parents are more likely to maintain steady employment and are typically more productive workers. When children enter school ready to learn, schools are better able to meet high standards and student needs. Successful schools benefit all students, improve a city’s livability, and help develop a strong future workforce. Strong early childhood programs are a valuable asset for local economic development. In the short term, these programs can help attract better workers and support working parents. In the longer term, a city that has made the necessary investments to maintain a quality workforce over time is likely to be more appealing to businesses looking for a stable location. Early childhood initiatives that expand access to quality services help “level the playing field.” Economic, racial, and ethnic disparities are too often perpetuated from one generation to the next unless children from disadvantaged households have the kinds of early childhood opportunities that are commonplace among their more advantaged peers. Far too many cases have been reported in Sunset Park about children bused to school facilities far away from the district, in one extreme case a set of autistic twin kindergarteners commute over an hour to get to a school with the facilitates to that can attend to their needs. Nowhere is the challenge for fulfilling the promise of academic achievement greater than in the work with diverse learners (aka students with learning disabilities). All students deserve an education that prepares them for postsecondary success and a lifetime of unlimited opportunity. Related services include Occupational Therapy (fine motor skill focus), Physical Therapy (gross motor skill focus, Speech Therapy, Language Therapy. In addition to the services, school buildings should be equipped with relevant facilities like sensory gyms and other technologies such as assistive technologies. Full Funding of the IDEA is necessary to provide early identification and early intervention services. Increased and
enhanced early childhood programs. Reduced class size and caseloads. Incentives to attract and retain qualified personnel, including teachers, related services personnel, special education administrators, and paraprofessionals. Parent training. Alternative placements for children with behavior disorders and school-wide positive behavioral support programs. After-school, extended-day, and extended-year programs. School- and community-based life skills and vocational training. Technology, both computer-aided instruction and assistive technology devices. School repair, renovation, and construction.
Other
Economic Development and Job Creation With recent development and proposed development along the district's waterfront many opportunities and challenges present themselves. Some of the opportunities include community- led SMART growth strategies; in other words, the planning of community development that is sustainable, compact, transit-oriented, walkable, bicycle-friendly land use, including neighborhood schools, complete streets and mixed- used development with a range of housing choices. Billions of dollars in public and private development is being invested in the Sunset Park waterfront, potentially creating thousands of new jobs with good wages. CB7 has long sought to protect its industrial community because of the economic benefits that can come. However, there are negatives associated with proximity to industry, including heavy truck traffic and emissions. We believe the residents who must endure these hardships should be prioritized when it comes to reaping the benefits of these investments.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 7
image
M ost Important Issue Related to Health Care and Human Services
Services to reduce or prevent homelessness
DHS's past failure to communicate with the local residents or even elected officials and government agencies about new and existing shelters makes the local community believe the City is hiding something, such as placing pedophiles in the community. Even after DHS has corrected these missteps, giving us six months notice in the most recent placement, the lack of trust is a terrible disservice to the clients the agency serves. Ours is a welcoming community and embraces people of all backgrounds and economic status, but the City's past failure to disclose builds distrust for the City and the vulnerable population they are trying to serve. Efforts must be made to improve DHS's negative image. That starts with communication.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
Under the FY20 Capital Priorities for the Board, our members call for an increase in programmatic funding for existing senior centers in the district. Our members are concerned about the proliferation of for-profit adult day services around the city and believe the city's senior centers provide a much higher level or service and more opportunities for seniors. Unfortunately, the city centers are not eligible for the Medicaid funding and therefore are not playing on an even field. CB 7 believes the city should provide additional funds to allow for the centers to increase the number of seniors the serve.
Needs for Homeless
No comments
Needs for Low Income NYs
CD 7 has a high rate of poverty (28%), a very large foreign-born population (47.2%) and well=below average for English proficiency and educational attainment so it could be argued than all services provided are for low-income and vulnerable New Yorkers
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
11/24
HRA
Provide, expand, or
Increase funding for adult ESOL, adult literacy
enhance
and adult education programs in CD 7.
educational
programs for adults
19/24
HRA
Provide, expand, or
CB 7 believes community-based employment
enhance job training
training programs for special needs populations
should be restored.
22/24
DFTA
Enhance
CB 7 believes city senior centers are now in
educational and
competition with for-profit facilities that have
recreational
access to federal reimbursement. Programs at
programs
city facilities should be enhanced to compete.
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 7
image
M ost Important Issue Related to Youth, Education and Child Welfare
Support services for special needs youth (disabled, immigrant, non-English proficient, etc.)
Five new schools have opened in our community since 2009, with more under construction, and still our schools are extremely overcrowded. The lack of space is exacerbated by few development parcels of appropriate size in the community and an influx of additional students through universal Pre-K. CB 7 approved one site for a new school at an acknowledged dangerous intersection, but we have few choices for new sites, even when we have a budget for new schools. We also took no position, having weighed need against safety, on a school proposed within the Industrial Business Zone.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
CB 7 has worked recently collecting sites for future school construction. Recent school construction belies the fact that our schools are overcrowded for lack of appropriate planning in the past as our community’s population has grown 50% in 20 years. Our lack of seats in public schools and the closure over the past decade of private schools at OLPH, St. Michael’s and Bishop Ford, put additional pressures on our existing facilities but also creates opportunities for our not-for-profits. The overcrowding makes the search for additional school sites even more urgent and we believe some of the smaller sites we have identified may be appropriate for Pre-K programs and perhaps even charter schools, which can alleviate the overburden on existing facilities. We recognize the importance of early childhood education and this deficit of seats leaves our children, who are mostly poor and/or from immigrant families, at a terrible disadvantage. New seats also sometimes have negative consequences, as well. The new PS 516 opened in the building that previously held the Sunset Park Head Start program, which had to move and whose 400 student population was cut in half. With the ever-growing and diverse immigrant populations within our community, there is an immediate need for augmented bilingual/ESL education for our Latino, Asian, Middles Eastern and Eastern European populations. Additionally, English proficiency programs, perhaps through our schools using the very students who are mastering language skills, for older residents would serve a great need for our community. Work skills and experience programs, such as SYEP and internships, must be expanded to prepare our students for the job market. We are very pleased that our high school’s curriculum embraces such learning outside the classroom and that two AmeriCorps programs serve our community through the Red Hook Community Justice Center and NYU Family Health Care.
Needs for Youth and Child Welfare
The population of the District has a large percentage of young people (30% under age 19) and programs for youth are greatly needed. Since our District has a minimum of public recreation space our children must rely on afterschool and other community-based programs for arts, entertainment, sports and academic help. Many of our residents fall beneath the poverty line and parents often have to work more than one job to support their families. These programs are vitally important to the life, learning and social skills of our youngest residents. The City must do more to support our children and our community-based organizations by providing additional funds. We must consider the need for afterschool and vacation care for children whose parents work. Additional funds must be available to support organizations that provide these services to create more day care slots for the local community and facilities. This could have an added benefit of creating jobs. Our local SYEP program is run through a program located at our high school and the school has an aggressive internship program for upperclassmen, but these options are not enough for a community with such a large youth population. The approximately 1600 SYEP slots are the same amount we had a decade ago, when our population was smaller. When the economy turned bad, there was increased competition from older workers for precious few jobs, increasing youth unemployment. These programs provide some of the few opportunities our young people have to gain work experience. CB7 held two
gang awareness forums for youth and parents to make people aware of the local gangs in the community and alternatives. NYPD and former gang members provided dozens of people with stark information. Awareness, avoidance and alternatives are keys to combating this problem in our community.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/35
SCA
Renovate interior
Make all schools and facilities within schools
building component
100% accessible to all student populations, in
new and rehabilitated schools
8/35
SCA
Renovate other site
Replace playground equipment at PS 971 with
6214 4
component
age-appropriate equipment. The school was
Avenue
built as an early childhood center but has a
population up to grade 5, As such, the
playground equipment is inadequate for the
older children.
20/35
SCA
Provide a new or
Allocate funds for site acquisition, design and
expand an existing
construction of a new Early Childhood Learning
elementary school
Center to serve the students of the Sunset
Park/Windsor Terrace communities.
31/35
SCA
Provide a new or
Allocate funds for site acquisition, design and
expand an existing
construction of a new high school in CD 7.
high school
Sunset Park High School opened in 2009, the
only HS in the district, and is beyond capacity, as
are the school in neighboring communities. It
took 40 years of effort to get Sunset Park HS.
The CB feels it is necessary to start the process
again, given the time scale.
32/35
SCA
Provide a new or
Allocate funds for site acquisition, design and
expand an existing
construction for a new elementary school in the
elementary school
Sunset Park/Windsor Terrace community.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
2/24
ACS
Provide, expand, or
Increase ACS day care slots in CD 7. The
enhance primary
community's need has increased significantly,
prevention services
but we have lost seats due to competition for
to strengthen
space. Head Start had to move for a new public
families
school and lost half its slots in the process. The
popular BAT Kids contract was not renewed and
the space was used for Pre-K.
3/24
DOE
Other educational programs requests
Ensure all children who are eligible for specialized and related programs (NEST,
bilingual, ESL, ASD, G&T, OTPT, etc.) in the
district receive such programs and services at
schools within the district in a continuum of
services from pre-K to grade 12
4/24
ACS
Provide, expand, or
Increase funding for preventive protective
enhance child
services for children.
welfare preventive
services slots
12/24
ACS
Provide, expand, or
Increase programmatic funding for youth-
enhance preventive
oriented diversion programs concerning drugs,
services and
crime, alcohol and gangs in CD 7.
community based
alternatives for
youth
15/24
DYCD
Provide, expand, or
Allocate funds for after school music and arts
enhance after
programs and comprehensive ASP, ELA, STEAM,
school programs for
sports and math programs districtwide
middle school
students (grades 6-
8)
16/24
DYCD
Provide, expand, or
Allocated funding for after school music and
enhance after
arts programs and comprehensive ASP, ELA,
school programs for
STEAM, sports and math programs districtwide
elementary school
students (grades K-
5)
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 7
image
M ost Important Issue Related to Public Safety and Emergency Services
Police-community relations
CB 7 is a relatively low crime community, with a serious crime rate of 8.7/1000 residents. However, high profile events in the past, including some that have taken place outside of our community and even city, have reopened a rift between some parts of the community and the 72nd Precinct. We acknowledge that the precinct and Brooklyn South has worked diligently to overcome this divergence. We believe community relations have been enhanced with the implementation of the Neighborhood Coordination Officers. We are strong believers that positive relations between our precinct and our residents will lead to even better results in reducing crimes and particularly quality- of-life complaints. Much of the credit for improved relations belongs to Deputy Inspector Gonzalez who has demonstrated that communication and respect for the community leads to communication and respect from the community.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The implementation of the Neighborhood Coordination Officer program (NCO) has helped to foster improved community relations and dialogue. Residents now have direct access to their local officers, who are essentially community specialists. The diverse NCO officers reflect the diversity of our community, improving understanding, trust and communication, However quality-of-life concerns are the most frequent constituent complaints addressed through the Community Board. The top QOL complaints we recent include: * Double-parking. Changes to and construction on 4th Avenue have highlighted the need for vigorous double-parking enforcement; * Noise. Noise complaints, which are most prevalent in the summer, include residential, but usually concern noise and illegal behavior at businesses (particularly one’s with liquor licenses); * Prostitution. We have seen recent spike in our prostitution complaints, particularly on 39th Street, at or near newly built hotels in the manufacturing district; * Vagrancy/public intoxication: We have also seen an uptick in complaints about vagrancy/public intoxication, particularly in or near parks. The recent introduction of a homeless population to the district through hotels in the manufacturing zones may have led to this increase; * Nightlife. Our community has become popular for weekend raves and party boats have come to the 58th Street Pier (without community approval). This has stretch NYPD resources thin during weekends. Pedestrian safety is also a top concern and we are trying to address this issue through DOT, however, it is vital that appropriate NYPD resources be made available, including an increase in the number of school crossing guards allocated to our community. We have new schools, annexes, pre-K facilities and charters in the past 20 years, as well as a burgeoning population, but have not seen an increase to crossing guards in decades. Several children have been injured or even killed in our district in the past years making this an essential need.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/24
NYPD
Assign additional
Increase school crossing guard personnel in CD
crossing guards
7 and increase hours to reflect afterschool
programs. Our population has grown by 50% in
two decades and we have many more schools,
charters and pre-K programs, but our crossing
guard personnel has remained at 40
throughout. Several children have been hit at
unguarded crossing in the past few years in this
community, with at least four deaths. The
allocation formula has never been explained.
5/24
NYPD
Other NYPD staff
Allocate funds for additional training of school
resources requests
safety officers for all schools, especially those
serving in schools with District 75 students
8/24
NYPD
Other NYPD
Increase and sustained truck enforcement. CD 7
programs requests
has an inordinate number or trucks due to a
large industrial area and poor highway access.
Truck traveling off-route in in a dangerous
manner (such as speeding) have been an
increasing concern for residents.
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 7
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Cleanliness/trash collection
All of the above choices are of great concern, however street cleanliness has always been a big issue for our community. Recent efforts made by the DSNY, including enhanced cleaning and additional basket pick up along with resources provided by the Councilman and Borough President have helped improve our ratings to where we are above average for Brooklyn, but still below City average. Cleanliness concerns remain on the cleanliness of our commercial strips, near transit hubs, our industrial area, beneath the Gowanus Expressway and alongside the MTA properties.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
The sewers, watermains and catch basins in this community are among the oldest in Brooklyn. There are a number of sewer collapses and undermined roadways reported to the Board each year. Several street reconstruction projects have been on our roster of Capital Budget requests for more than twenty years. The heavy volume of traffic, particularly on 3rd, 4th, 5th, 8th and Caton Avenues, major thoroughfares and truck routes, causes severe wear and erosion on these streets and off-route trucks put an additional heavy burden on our side streets, which were not meant to accommodate such heavy vehicles. Our old streets and infrastructure are crumbling and additional contracts and resources must be made available for trenching activities. While the City occasionally paves streets, we are fearful that the underlying causes of the street degradation are not being addressed and repaving merely covers over the problems. We believe that DOT and DEP must address these concerns much sooner and more comprehensively, otherwise it may simply be a waste of funds as streets keep sinking despite new asphalt.
Three years ago, a pipe thirty feet below 43rd Street broke leaving residents and businesses on the block without water, sewer and other city services, months of construction and a lack of access, as well as other hardships, on the block. Two years ago, a street collapse on 64th Street prevented travel on the heavily-used Fifth Avenue, including the rerouting of the bus for several days, causing hardships and loss of revenue for residents and businesses alike. It took over a year to repair. We believe that if the sewer and water pipes were replaced in 1988, as they were scheduled to be, this expensive, year-long plus infrastructure problem would not have occurred. We still are waiting on this work, nearly thirty years later.
Needs for Sanitation Services
Community District 7 continues to host more than its fair share of sanitation facilities. In addition to numerous private carters and recyclers, we are also home to the SIMS Municipal Recycling Facility, which will take most of NYC’s metal and plastic recyclables; the garage for BK-7 and BK-10 (which serves CB10); the Hamilton Avenue Marine Transfer Station. IESI, a private company that takes 1000 tons of city residential trash. We will soon be home to an industrial grease recycling facility, as well. All these facilities require additional trucks in our community and, unfortunately, sometimes we are taken advantage of. Many of the private municipal waste truck drivers take liberties by parking beneath the Gowanus Expressway, along 3rd Avenue or next to Green-Wood Cemetery.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
3/35
DEP
Inspect water main
Establish a design an reconstruction contract for
5 Avenue 34
on specific street
5th Avenue between 34th and 65th Streets,
Street 64
segment and repair
including sewers, mains, pedestrian plazas,
Street
or replace as
historic lighting and other public amenities and
needed (Capital)
include an incentive clause for early completion.
This project was supposed to start in 1988. It
has been repeatedly delayed to (now) 2022.
DOT blames DEP's lack of a budget.
7/35
DEP
Inspect sanitary
Replace sewer pipes in 1st Avenue from 39th to
1st Avenue
sewer on specific
58th Streets which was cut out of the 2005
39th Street
street segment and
street rehabilitation. Green infrastructure
58 Street
repair or replace as
should be included wherever feasible.
needed (Capital)
23/35
DEP
Inspect sanitary
Rehabilitate the sewer pipe and add green
34th and 35th
sewer on specific
infrastructure on 33rd and 34th Street between
Streets 4th
street segment and
4th and 5th Avenues.
Avenue 5th
repair or replace as
Avenue
needed (Capital)
30/35
DSNY
Provide new or
Acquire site to relocate and construct a new BK-
upgrade existing
7 garage. CB 7 strongly believes the sanitation
sanitation garages
garage should not be located on a waterfront
or other sanitation
property. Additionally, BK-10's garage, currently
infrastructure
housed in the same building as BK - 7, should be
located in its home district.
33/35
DSNY
Other garbage
Purchase and place "big belly" garbage pails at
collection and
intersections with heavy pedestrian use
recycling
infrastructure
requests (Capital)
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
6/24
DSNY
Provide more
Increase funding for corner basket pick up.
frequent litter
Corner baskets in CD 7 are overflowing and BK -
basket collection
7 has responded, in part, by reducing the
number of baskets. CB 7 believe more frequent
pick ups can alleviate the problem.
13/24
DEP
Clean catch basins
Increase funding for sewer and catch basin maintenance in CD 7.
14/24
DEP
Inspect storm sewer
Study water and sewer problems in area
Kermit Place
on specific street
bounded by Kermit Place, East 7th Street, East
East 7th
segment and
17th Street and Caton Avenue
Street East
service, repair or
8th Street
replace as needed
20/24
DSNY
Provide more
Restore 5-day-a-week pick up at all schools
frequent garbage or
districtwide. Many schools do not have capacity
recycling pick-up for
for storing garbage multiple days. Most of our
schools and
schools are overcrowded and have more
institutions
garbage that capacity.
21/24
DSNY
Other cleaning
Allocate additional personnel for manual street
requests
sweeping in CD 7 on commercial streets.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 7
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Affordable housing creation
There is a rising concern that new housing development is not affordable for local residents, as the median income in CB 7 is approximately $43,000/year, while the standard for affordability includes the median income from more affluent communities. Additionally, affordable units that are mandatory within a project that includes developer incentives need to include family-sized units and not just studio and one-bedroom units. Finally, unlike DCP’s characterization at a presentation on the Mayor’s affordability plan, our experience is poor people do own cars and the plan should reflect that reality.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
CB7 is greatly concerned that hotels are allowed as-of-right in manufacturing districts, as we believe this is a back door way to promote housing expansion. We have spent almost two decades promoting and trying to safeguard our industrial waterfront, through our 197-a study and plan, and wish DCP would close this loophole, which could have devastating consequences for businesses and local employment if additional hotels are allowed to open in our manufacturing area. Many of the most recent hotels built in our community are either being used for homeless shelters. We are concerned these uses may one day make our manufacturing zones unaffordable, opening the door for housing, and throwing thousands of local residents out of their jobs. This as-of-right loophole for hotels in manufacturing zones must be closed. When he was Councilman for this community, Mr. deBlasio promised legislation to close the loophole to allow hotels in manufacturing zones as of right. A decade later we are still waiting for that legislation. In the meantime, those hotels have now become the City's homeless plan.
Needs for Housing
No comments
Needs for Economic Development
Our Board welcomes economic development along our waterfront, but insists that any development immediately adjacent to the water be limited to water-dependant and community uses. Our waterfront is our greatest physical asset with spectacular views and large areas ripe for development. We strongly believe that any development in our community must be sensitive to our current residents and businesses. Should businesses be required to move as part of a major development, priority should be given to relocating the businesses within the community. Our priority is to bring additional jobs to the community, not to force some businesses to leave. Our community has seen much of its potential wasted in the past from the placement of negative-impact facilities, such as the Metropolitan Detention Center, power plants and waste transfer stations. The community has received a disproportionate number of these facilities while many of the other neighborhoods in the City receive money to lessen the impact of such facilities or relocated them altogether. Our community has received millions, and promised additional billions, in public and private investments in recent years and there is a concern that such developments and changes will not reach the local residents and may even have negative consequences, such as making housing unaffordable. This issue is especially important now as we will soon have to make a determination on Industry City's proposed rezoning.
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
1/35 EDC Invest in capital
projects to improve access to the waterfront
Full funding for construction of Bush Terminal Park through Phase 2, including playground, environmental center and pier 5. Although the park is open, EDC has not provided all the amenities promised to this community.
image
5/35 EDC Invest in capital
projects to improve access to the waterfront
Allocate funds for a bathroom on the BAT campus adjacent to the 58th Street Pier and available to the pier's patrons as well as a properly designed bus turn around and speed humps for the pier
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
18/24
SBS
Provide or expand
Provide vocational training, day habilitation and
occupational skills
placement services for adults with disabilities.
training programs
23/24
EDC
Expand public
Allocate funds for security in off-peak hours in
programming and
order to maintain public access at BAT Pier 4
activation of City-
owned sites
TRANSPORTATION
Brooklyn Community Board 7
image
M ost Important Issue Related to Transportation and Mobility
Freight movement (loading zones, freight related traffic, etc.)
This issue includes many of the other issues listed, including the bicycle network, pedestrian ramps, truck routes, enforcement, access, traffic, street lighting and public transportation. Pedestrian safety is multifaceted and not just physical changes and capital outlays. It also includes NYSDOT (and other agencies) as the Gowanus and Prospect Expressways have a significant impact on safety issues.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
Transportation issues are amongst our most pressing. This is because we are home to two major highways, a large industrial area that requires trucks and because transportation issues have a strong impact on public safety and the quality-of-life in our community. State DOT also plays a crucial role in how trucks access our community as most come via the Gowanus and Prospect Expressways. Unfortunately, constant repair of the Gowanus and terrible traffic on both highways encourages drivers to get off the highways and travel local streets. In addition, a lack of appropriate highway entrances and exits, coupled with our large industrial area, mean that we constantly have problems with off-route trucks looking for ways to get around traffic. These additional trucks on our streets, with more coming due to welcomed economic development along our waterfront, mean additional conflicts with and dangers for pedestrians. City DOT, however, has recognized these conflicts and has worked with the Community Board and others to develop a traffic and pedestrian safety plan for 4th Avenue that has reduced the number of traffic lanes from three to two (north and south), widened the pedestrian medians and vehicle turning lanes, added high visibility paint and plastic bollards. Additional improvements are expected, including sheltered bike lanes and planted medians. However, because the City failed to keep up with these infrastructure needs for decades, many of the projects are happening at the same time, as the City rushes to support our economic growth in the industrial area, including simultaneous lane closures on 2nd, 3rd and 4th Avenues, daily work on the Gowanus Expressway structure, and side street closures in the 40s and 50s. This leads us to worry that agencies are not properly communicating and coordinating on projects, producing extra burdens on our residents and businesses.
Needs for Transit Services
While we are happy that MTA is finally adding an elevator to the 59th Street station, it is not nearly enough. All station rehabilitations should include elevator and/or ramps. We are very happy the 53rd Street and Prospect Avenue stations have recently been rehabilitated, we feel accessibility is much more important than cell phone charging. More frequent bus service is necessary on Eighth and particularly on 5th Avenue, especially when school is in session. MTA failed to provide traffic agents along 4th Avenue, as promised creating a safety hazard for all traverse the boulevard.
image
Capital Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
4/35 DOT Reconstruct streets Establish a design and reconstruction contract
for the 20th Street - McDonald Avenue truck route between 4th Avenue and Caton Avenue to make the entire corridor safer for pedestrians, bicyclists and cars/trucks
20th Street/McDonald Avenue 4th Avenue Caton Avenue
image
10/35 DOT Reconstruct streets Allocate funds for the design and reconstruction
of 3rd Avenue from 65th to 17th Street, to include all service roads, with safer pedestrian crossings and improved lighting at every intersection
3rd Avenue 17th Street 65th Street
image
11/35 DOT Repair or provide
new street lights
Rehabilitate lights beneath the Gowanus Expressway and add shorter street lights to 3rd Avenue
3 Avenue 15
Street 65 Street
image
12/35 NYCTA Repair or upgrade
subway stations or other transit infrastructure
Create secondary entrances/exits at all subway stations in CD 7. This is necessary for mobility and public safety reasons
image
13/35 DOT Reconstruct streets Rehabilitate 2nd Avenue between 29th and
42nd Streets and remove unused rail. EDC was supposed to have done this in a 2005 project but removed it without community notice.
2 Avenue 29
Street 42 Street
image
16/35 NYCTA Improve
accessibility of transit infrastructure, by providing elevators, escalators, etc.
Add 3 elevators and rehabilitate the 15th Street/Prospect Park station on the F line to improve station and ensure it is handicap accessible
image
22/35 NYCTA Improve
accessibility of transit infrastructure, by providing elevators, escalators, etc.
Add 3 elevators and make 36th Street station on the N/R line handicap accessible
image
25/35 DOT Roadway maintenance (i.e. pothole repair, resurfacing, trench restoration, etc.)
Increase funds for pothole repair in CD 7
image
26/35
DOT
Reconstruct streets
Fund the reconstruction of 39th Street from 2nd Avenue to the Western Terminus
39th Street 2nd Avenue bulkhead line
28/35
DOT
Repair or construct
Replace sidewalks on Ft. Hamilton Parkway
Ft Hamilton
new curbs or
between East 5th Street and the bridge over the
Parkway East
pedestrian ramps
Prospect Expressway. The adjacent property
5th Street
owner is NYC.
Prospect
Expressway
34/35
NYCTA
Other transit
Add shelters and benches to all bus stops on 3rd
infrastructure
Avenue in CD 7
requests
CS
NYCTA
Improve
Add 3 elevators to the 59th Street subway
59 Street and
accessibility of
station for handicap accessibility
4 Avenue
transit
infrastructure, by
providing elevators,
escalators, etc.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
9/24
NYCTA
Expand bus service
Restore full funding for the B-37 bus to 3rd
frequency or hours
Avenue in CD 7, with 24 hour service
of operation
10/24
NYCTA
Expand bus service
Increase service on the B63 bus and ensure
frequency or hours
much more frequent service, particularly during
of operation
school rush hours. The B63 serves several school
inside and outside the district and service levels
have not been frequent enough to handle the
volume of children. We have received numerous
complaints about children being late due to
overcrowded buses bypassing stops.
24/24
DOT
Improve parking
Allocate funds to study the lack of parking
operations
throughout CD 7 and examine options for
increasing parking availability district-wide
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 7
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
While some of our parks have undergone rehabilitation recently, many remain in need of upgrades, including: • Rainbow playground • Martin Luther Playground • John Allen Payne Park (half rehabilitated) • D’Emic Park • Pena- Herrera Park Bush Terminal Park opened in 2014, but we still only have half the park the community was promised. Its been 5 years and the park still doesn't even have lighting or other promised amenties, such as a picnic area, playground, environmental center or even a plan for Pier 5 as part of the park. In a community that has less than half of the city’s standard for parkland per capita and where nearly 25% of our population is more than ¼ mile from a park, it should stand to reason that the few facilities we have should be kept in top condition.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Our parks are oases within the concrete City where people of all generations, socio-economic statuses and ethnic and national backgrounds can gather, relax, play or simply enjoy a more pastoral setting within the City. They are for mental rejuvenation, physical fitness and stress relief. However, during difficult economic times our parks see an increase in use because of limited personal recreation funds, but often experience a decrease in programming and upkeep. Together these facts spell trouble for our parks as overused equipment falls into disrepair or natural settings are overtaxed. Unfortunately for local parks, the City’s main parks seem to get all the attention while our facilities become eyesores. Facility upgrades are left to our Councilmembers’ discretion and ability to negotiate and while our elected officials have done a great job bring these funds to the community, we believe it is unfair to them to have to concentrate funds in parks that should be funded directly by the agency. As such, we call upon the City to establish a capital program for local parks that does not rely on limited discretionary funds from elected officials.
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
6/35
DCAS
Renovate, upgrade
Rehabilitate Community Board 7 rest rooms (to
4201 4
or provide new
ensure ADA compliance), lobby, plumbing,
Avenue
community board
electrical and hvac systems and security. CB 7,
facilities and
despite being in a city-owned building, is not
equipment
ADA-compliant.
9/35
DPR
Reconstruct or
Reconstruct Rainbow Playground.
5523 6
upgrade a park or
Avenue
amenity (i.e.
playground, outdoor
athletic field)
14/35
DPR
Reconstruct or
Replace all windows in the Sunset Park
4200 7
upgrade a building
Recreation Center.
Avenue
in a park
15/35
DPR
Reconstruct or
Rehabilitate D'Emic Playground.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
17/35
DPR
Reconstruct or
Rehabilitate Martin Luther Playground.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
18/35
DPR
Reconstruct or
Rehabilitate Pena-Herrera Park.
4601 3
upgrade a park or
Avenue
amenity (i.e.
playground, outdoor
athletic field)
19/35
DPR
Reconstruct or
Rehabilitate basketball and handball courts at
upgrade a park or
Greenwood Park.
amenity (i.e.
playground, outdoor
athletic field)
21/35
DPR
Reconstruct or
Rehabilitate Sherman Street Park at Ocean
318 Sherman
upgrade a park or
Parkway.
Street
amenity (i.e.
playground, outdoor
athletic field)
24/35
DPR
Reconstruct or upgrade a building in a park
Improve access and add trees and amenities including a spotlight on the monument around the center of Bartel Pritchard Square
27/35
BPL
Create a new, or
Allocate for acquisition, design and construction
renovate or upgrade
of an additional library in Sunset Park adjacent
an existing public
to 7th or 8th Avenues
library
29/35
DPR
Improve access to a
Replace sidewalks and curbs on East 4th Street
East 4th
parks facility
between Ft. Hamilton Parkway and Caton
Street Ft.
Avenue at the community garden. The adjacent
Hamilton
property owner is NYC.
Parkway
Caton Avenue
35/35
DPR
Reconstruct or
Rehabilitate the portion of John Allen Payne
upgrade a park or
Park that has not already been rehabilitated
amenity (i.e.
playground, outdoor
athletic field)
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
7/24
DPR
Other park maintenance and safety requests
Increase Parks personnel budget for additional maintenance workers and Recreation Center workers
4200 7th Ave
17/24
DPR
Forestry services, including street tree maintenance
Increase funding for tree planting and pruning district-wide in order to expedite schedule
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority Agency Request Explanation Location
image
1/35 EDC Invest in capital
projects to improve access to the waterfront
Full funding for construction of Bush Terminal Park through Phase 2, including playground, environmental center and pier 5. Although the park is open, EDC has not provided all the amenities promised to this community.
image
2/35 SCA Renovate interior
building component
Make all schools and facilities within schools 100% accessible to all student populations, in new and rehabilitated schools
image
3/35 DEP Inspect water main
on specific street segment and repair or replace as needed (Capital)
Establish a design an reconstruction contract for 5th Avenue between 34th and 65th Streets, including sewers, mains, pedestrian plazas, historic lighting and other public amenities and include an incentive clause for early completion. This project was supposed to start in 1988. It has been repeatedly delayed to (now) 2022.
DOT blames DEP's lack of a budget.
5 Avenue 34
Street 64 Street
image
4/35 DOT Reconstruct streets Establish a design and reconstruction contract
for the 20th Street - McDonald Avenue truck route between 4th Avenue and Caton Avenue to make the entire corridor safer for pedestrians, bicyclists and cars/trucks
20th Street/McDonald Avenue 4th Avenue Caton Avenue
image
5/35 EDC Invest in capital
projects to improve access to the waterfront
Allocate funds for a bathroom on the BAT campus adjacent to the 58th Street Pier and available to the pier's patrons as well as a properly designed bus turn around and speed humps for the pier
image
6/35 DCAS Renovate, upgrade
or provide new community board facilities and equipment
Rehabilitate Community Board 7 rest rooms (to ensure ADA compliance), lobby, plumbing, electrical and hvac systems and security. CB 7, despite being in a city-owned building, is not ADA-compliant.
4201 4
Avenue
image
7/35 DEP Inspect sanitary
sewer on specific street segment and repair or replace as needed (Capital)
Replace sewer pipes in 1st Avenue from 39th to 58th Streets which was cut out of the 2005 street rehabilitation. Green infrastructure should be included wherever feasible.
1st Avenue 39th Street 58 Street
image
8/35
SCA
Renovate other site
Replace playground equipment at PS 971 with
6214 4
component
age-appropriate equipment. The school was
Avenue
built as an early childhood center but has a
population up to grade 5, As such, the
playground equipment is inadequate for the
older children.
9/35
DPR
Reconstruct or
Reconstruct Rainbow Playground.
5523 6
upgrade a park or
Avenue
amenity (i.e.
playground, outdoor
athletic field)
10/35
DOT
Reconstruct streets
Allocate funds for the design and reconstruction
3rd Avenue
of 3rd Avenue from 65th to 17th Street, to
17th Street
include all service roads, with safer pedestrian
65th Street
crossings and improved lighting at every
intersection
11/35
DOT
Repair or provide
Rehabilitate lights beneath the Gowanus
3 Avenue 15
new street lights
Expressway and add shorter street lights to 3rd
Street 65
Avenue
Street
12/35
NYCTA
Repair or upgrade
Create secondary entrances/exits at all subway
subway stations or
stations in CD 7. This is necessary for mobility
other transit
and public safety reasons
infrastructure
13/35
DOT
Reconstruct streets
Rehabilitate 2nd Avenue between 29th and
2 Avenue 29
42nd Streets and remove unused rail. EDC was
Street 42
supposed to have done this in a 2005 project
Street
but removed it without community notice.
14/35
DPR
Reconstruct or
Replace all windows in the Sunset Park
4200 7
upgrade a building
Recreation Center.
Avenue
in a park
15/35
DPR
Reconstruct or
Rehabilitate D'Emic Playground.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
16/35
NYCTA
Improve
Add 3 elevators and rehabilitate the 15th
accessibility of
Street/Prospect Park station on the F line to
transit
improve station and ensure it is handicap
infrastructure, by
accessible
providing elevators,
escalators, etc.
17/35
DPR
Reconstruct or
Rehabilitate Martin Luther Playground.
upgrade a park or
amenity (i.e.
playground, outdoor
athletic field)
18/35
DPR
Reconstruct or
Rehabilitate Pena-Herrera Park.
4601 3
upgrade a park or
Avenue
amenity (i.e.
playground, outdoor
athletic field)
19/35
DPR
Reconstruct or
Rehabilitate basketball and handball courts at
upgrade a park or
Greenwood Park.
amenity (i.e.
playground, outdoor
athletic field)
20/35
SCA
Provide a new or
Allocate funds for site acquisition, design and
expand an existing
construction of a new Early Childhood Learning
elementary school
Center to serve the students of the Sunset
Park/Windsor Terrace communities.
21/35
DPR
Reconstruct or
Rehabilitate Sherman Street Park at Ocean
318 Sherman
upgrade a park or
Parkway.
Street
amenity (i.e.
playground, outdoor
athletic field)
22/35
NYCTA
Improve
Add 3 elevators and make 36th Street station on
accessibility of
the N/R line handicap accessible
transit
infrastructure, by
providing elevators,
escalators, etc.
23/35
DEP
Inspect sanitary
Rehabilitate the sewer pipe and add green
34th and 35th
sewer on specific
infrastructure on 33rd and 34th Street between
Streets 4th
street segment and
4th and 5th Avenues.
Avenue 5th
repair or replace as
Avenue
needed (Capital)
24/35
DPR
Reconstruct or
Improve access and add trees and amenities
upgrade a building
including a spotlight on the monument around
in a park
the center of Bartel Pritchard Square
25/35
DOT
Roadway
Increase funds for pothole repair in CD 7
maintenance (i.e.
pothole repair,
resurfacing, trench
restoration, etc.)
26/35
DOT
Reconstruct streets
Fund the reconstruction of 39th Street from 2nd Avenue to the Western Terminus
39th Street 2nd Avenue bulkhead line
27/35
BPL
Create a new, or
Allocate for acquisition, design and construction
renovate or upgrade
of an additional library in Sunset Park adjacent
an existing public
to 7th or 8th Avenues
library
28/35
DOT
Repair or construct
Replace sidewalks on Ft. Hamilton Parkway
Ft Hamilton
new curbs or
between East 5th Street and the bridge over the
Parkway East
pedestrian ramps
Prospect Expressway. The adjacent property
5th Street
owner is NYC.
Prospect
Expressway
29/35
DPR
Improve access to a
Replace sidewalks and curbs on East 4th Street
East 4th
parks facility
between Ft. Hamilton Parkway and Caton
Street Ft.
Avenue at the community garden. The adjacent
Hamilton
property owner is NYC.
Parkway
Caton Avenue
30/35
DSNY
Provide new or
Acquire site to relocate and construct a new BK-
upgrade existing
7 garage. CB 7 strongly believes the sanitation
sanitation garages
garage should not be located on a waterfront
or other sanitation
property. Additionally, BK-10's garage, currently
infrastructure
housed in the same building as BK - 7, should be
located in its home district.
31/35
SCA
Provide a new or
Allocate funds for site acquisition, design and
expand an existing
construction of a new high school in CD 7.
high school
Sunset Park High School opened in 2009, the
only HS in the district, and is beyond capacity, as
are the school in neighboring communities. It
took 40 years of effort to get Sunset Park HS.
The CB feels it is necessary to start the process
again, given the time scale.
32/35
SCA
Provide a new or
Allocate funds for site acquisition, design and
expand an existing
construction for a new elementary school in the
elementary school
Sunset Park/Windsor Terrace community.
33/35
DSNY
Other garbage
Purchase and place "big belly" garbage pails at
collection and
intersections with heavy pedestrian use
recycling
infrastructure
requests (Capital)
34/35
NYCTA
Other transit
Add shelters and benches to all bus stops on 3rd
infrastructure
Avenue in CD 7
requests
35/35
DPR
Reconstruct or upgrade a park or amenity (i.e. playground, outdoor athletic field)
Rehabilitate the portion of John Allen Payne Park that has not already been rehabilitated
CS
NYCTA
Improve accessibility of transit infrastructure, by providing elevators, escalators, etc.
Add 3 elevators to the 59th Street subway station for handicap accessibility
59 Street and
4 Avenue
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/24
NYPD
Assign additional
Increase school crossing guard personnel in CD
crossing guards
7 and increase hours to reflect afterschool
programs. Our population has grown by 50% in
two decades and we have many more schools,
charters and pre-K programs, but our crossing
guard personnel has remained at 40
throughout. Several children have been hit at
unguarded crossing in the past few years in this
community, with at least four deaths. The
allocation formula has never been explained.
2/24
ACS
Provide, expand, or
Increase ACS day care slots in CD 7. The
enhance primary
community's need has increased significantly,
prevention services
but we have lost seats due to competition for
to strengthen
space. Head Start had to move for a new public
families
school and lost half its slots in the process. The
popular BAT Kids contract was not renewed and
the space was used for Pre-K.
3/24
DOE
Other educational
Ensure all children who are eligible for
programs requests
specialized and related programs (NEST,
bilingual, ESL, ASD, G&T, OTPT, etc.) in the
district receive such programs and services at
schools within the district in a continuum of
services from pre-K to grade 12
4/24
ACS
Provide, expand, or
Increase funding for preventive protective
enhance child
services for children.
welfare preventive
services slots
5/24
NYPD
Other NYPD staff
Allocate funds for additional training of school
resources requests
safety officers for all schools, especially those
serving in schools with District 75 students
6/24
DSNY
Provide more
Increase funding for corner basket pick up.
frequent litter
Corner baskets in CD 7 are overflowing and BK -
basket collection
7 has responded, in part, by reducing the
number of baskets. CB 7 believe more frequent
pick ups can alleviate the problem.
7/24
DPR
Other park
Increase Parks personnel budget for additional
4200 7th Ave
maintenance and
maintenance workers and Recreation Center
safety requests
workers
8/24
NYPD
Other NYPD
Increase and sustained truck enforcement. CD 7
programs requests
has an inordinate number or trucks due to a
large industrial area and poor highway access.
Truck traveling off-route in in a dangerous
manner (such as speeding) have been an
increasing concern for residents.
9/24
NYCTA
Expand bus service
Restore full funding for the B-37 bus to 3rd
frequency or hours
Avenue in CD 7, with 24 hour service
of operation
10/24
NYCTA
Expand bus service
Increase service on the B63 bus and ensure
frequency or hours
much more frequent service, particularly during
of operation
school rush hours. The B63 serves several school
inside and outside the district and service levels
have not been frequent enough to handle the
volume of children. We have received numerous
complaints about children being late due to
overcrowded buses bypassing stops.
11/24
HRA
Provide, expand, or
Increase funding for adult ESOL, adult literacy
enhance
and adult education programs in CD 7.
educational
programs for adults
12/24
ACS
Provide, expand, or
Increase programmatic funding for youth-
enhance preventive
oriented diversion programs concerning drugs,
services and
crime, alcohol and gangs in CD 7.
community based
alternatives for
youth
13/24
DEP
Clean catch basins
Increase funding for sewer and catch basin
maintenance in CD 7.
14/24
DEP
Inspect storm sewer
Study water and sewer problems in area
Kermit Place
on specific street
bounded by Kermit Place, East 7th Street, East
East 7th
segment and
17th Street and Caton Avenue
Street East
service, repair or
8th Street
replace as needed
15/24
DYCD
Provide, expand, or
Allocate funds for after school music and arts
enhance after
programs and comprehensive ASP, ELA, STEAM,
school programs for
sports and math programs districtwide
middle school
students (grades 6-
8)
16/24
DYCD
Provide, expand, or
Allocated funding for after school music and
enhance after
arts programs and comprehensive ASP, ELA,
school programs for
STEAM, sports and math programs districtwide
elementary school
students (grades K-
5)
17/24
DPR
Forestry services,
Increase funding for tree planting and pruning
including street tree
district-wide in order to expedite schedule
maintenance
18/24
SBS
Provide or expand
Provide vocational training, day habilitation and
occupational skills
placement services for adults with disabilities.
training programs
19/24
HRA
Provide, expand, or
CB 7 believes community-based employment
enhance job training
training programs for special needs populations
should be restored.
20/24
DSNY
Provide more
Restore 5-day-a-week pick up at all schools
frequent garbage or
districtwide. Many schools do not have capacity
recycling pick-up for
for storing garbage multiple days. Most of our
schools and
schools are overcrowded and have more
institutions
garbage that capacity.
21/24
DSNY
Other cleaning
Allocate additional personnel for manual street
requests
sweeping in CD 7 on commercial streets.
22/24
DFTA
Enhance
CB 7 believes city senior centers are now in
educational and
competition with for-profit facilities that have
recreational
access to federal reimbursement. Programs at
programs
city facilities should be enhanced to compete.
23/24
EDC
Expand public
Allocate funds for security in off-peak hours in
programming and
order to maintain public access at BAT Pier 4
activation of City-
owned sites
24/24
DOT
Improve parking
Allocate funds to study the lack of parking
operations
throughout CD 7 and examine options for
increasing parking availability district-wide

