- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 14 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1OYpWVPKaSCDGPz_tmQLgXAC-sJSoQLJb/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1OYpWVPKaSCDGPz_tmQLgXAC-sJSoQLJb/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
14
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 14
image
Address: 810 East 16 Street
Phone: (718) 859-6357
Email: info@cb14brooklyn.com
Website: cb14brooklyn.com
Chair: Ed Powell District Manager: Shawn Campbell
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Located in the heart of Brooklyn, Community Board 14 comprises the diverse and dynamic communities of Flatbush, Midwood and eastern Kensington. The District embraces 2.9 square miles within which approximately 165,000 people reside. The district remains among the most diverse in New York City; ranking fourth of 59 Community Districts citywide. Approximately 40% of the District is White; 32% of the total population is Black/African American; 11% is Asian; and 15% is of Hispanic origin. About 43% of our District’s population is foreign born; down slightly from a high of 49%. Changes in our population and demographics have an impact on all city services including social services and institutions in the District such as schools. Many of these impacts inform the needs of our District as outlined in this statement of needs.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 14
image
The three most pressing issues facing this Community Board are:
Infrastructure resiliency
Infrastructure resiliency includes street conditions/roadway, street bridge, mass transit maintenance and infrastructure; street flooding; maintenance of institutions and public space. A request for a new precinct house has been a priority for three decades. NYPD recognized the need but has not delivered. CD 14 is considered a transit zone but there have been no studies of station capacity. To the extent that capacity and thus resiliency improvements are being made by agencies and utilities alike, there is insufficient coordination so that roadway disruptions are extended and poorly planned.
Traffic
We receive more service delivery requests for issues related to DOT than any other agency. Community members generate requests for traffic studies; street conditions; for traffic calming such as speed humps, stop signs, traffic signals; changes in alternate side of the street parking; sidewalk conditions; bike lanes that make sense and more. In addition, DOT has initiated installations of pedestrian islands; curb extensions; bike lane expansions; and safety measures near schools. The requests and initiatives too often do not intersect. With so many projects and requests and with the increased development in the area, CB14 continues to encourage DOT to implement changes based on data and studies of the specifics of the areas that will be affected by projects and to include the community in the early phases of proposal development.
Other
Census 2020. We are one of the most undercounted communities in the most undercounted county in the country. The hundreds of millions of dollars forfeited due to being so woefully undercounted must be corrected. Therefore, we CB14 has formed a Complete Count Committee and will work with our CBOs and the NYC Census to garner the support needed to correct this long lasting impact.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 14
image
M ost Important Issue Related to Health Care and Human Services
Mental health and substance abuse treatment and prevention programs
It is important to understand the interrelation of our health care and human services needs and to ensure that issues are addressed with a multi-disciplinary approach. It remains a defect of this City Planning run DNS process that directs Boards to prioritize services for domestic violence victims over access to healthy food or services to reduce homelessness. Animal and pest control complaints come to our office's attention on an increasing basis. The number of street homeless and homeless encampments continue to be reported at concerning rates. Those individuals often present with mental health and substance abuse issues. Resources for vulnerable and low income residents are needed. Air quality, housing violations, obesity, unmet medical care needs all continue to rank among the top DOHMH documented needs assessed in the District. It is incumbent upon the City to assess the budgetary needs for these various and frequently interrelated issues and to fund and address accordingly.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
The most recent Department of Health and Mental Hygiene Community Health Profile for CD 14 correctly notes that living a long and healthy life is not equally available to all New Yorkers. Secure jobs with benefits, well-maintained and affordable housing, and access to parks, healthy and affordable food, and quality health care are at the root of good health. The poverty rate in the District is 22%. Sixteen percent of adults have no health insurance, and the rate of avoidable hospitalizations is higher than the citywide and borough wide averages. More than 57% of residents pay more than a third of their income on rent; while only 40% of housing units are adequately maintained by landlords. CD 14 ranks at the bottom citywide in terms of the percentage of residents who live more than a quarter of a mile away from a park.
Needs for Older NYs
According to the Department for the Aging's analysis of 2010 Census data, the population of older New Yorkers is increasing as a share of the total population. Furthermore, those over the age of 85 is increasing the most. In addition, the gender gap between older New Yorkers is decreasing and the number of "younger" older New Yorkers seeking services is increasing. These shifts require new focus on providing support services for aging New Yorkers. In CD 14, from 2000 to 2010, the only age categories of population increase was the 45-65 group, which increased by 14.4%, and the 65 years and older group, which increased by 2.8%. Services for our aging population are increasingly imperative.
Needs for Homeless
The homeless populations has risen over the past five years to over 60,000 people on any given day. Reports of homeless encampments have increased citywide and our community is no different. Not every person on the street is homeless and not every homeless person is on the street. Breaking Ground is Brooklyn's DHS contractor and provides excellent service. Since HOME-STAT was launched in 2016, 311 calls for street homeless assistance in CD14 have dropped from 298 to 187 in 2018. We understand that there are nearly 500 workers in the HOME-STAT program but since it takes on average 250 encounters with street outreach teams before individuals will accept services, and we are on track to receive 200 calls in 2019 for homeless assistance, a continued expansion of the teams is warranted. The Midwood Safehaven has undergone expansion and is now operating at capacity. Such programs should be expanded and sited with the best interest of the community in mind. One in every 7 elementary students in CD 14 will have experienced homelessness by the 5th grade. The affects are profound.
Needs for Low Income NYs
Community Board 14 continues to host non-profit roundtable events each year in order to stay aware of needs being met by Community Based Organizations (CBO), who they are serving, and what type of support they need to manage and expand caseloads. In the past we brought the CBOs together with city agencies and nonprofit support organizations to expand their capacity and strengthen the CBO network in our community. This past year the nonprofit roundtable centered on the 2020 Census and resulted in the formation of a Complete Count Committee. Kings county is the most undercounted county in the country and many tracts in our Distriact are woefully undercounted. Those who serve on our Human Services Committee have high hopes that in collaboration with our local CBO's we can help make Brooklyn Count 100%. The increased federal funding that will result from an accurate count will help ensure that residents in poverty, in overcrowded, rent overburdened dwellings can have education, job, health and other human and support services to which we are actually entitled.
image
Capital Requests Related to Health Care and Human Services
Priority Agency Request Explanation Location
image
19/19 HRA Other request for
services to support low-income New Yorkers
The poverty rate in CD 14 is 22%. Housing, education, job assistance, health care, and other human services are investments in our human resources that have been underfunded because we are so woefully undercounted.
Census 2020 - make Brooklyn Count 100%
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
1/26
DHS
Expand street
Reports on homeless encampments and
outreach
regarding individuals who appear to be
homeless have increased over the past year.
Common Ground is the current contractor and
provides excellent service. Given the increase in
calls to the Community Board, the Police and
311, an increase in outreach services is
warranted.
3/26
DHS,
Other homelessness
Community District 14 ranks 11th of 59 in the
HRA
prevention program
percentage of severely rent burdened household
request
35% up from 30% the year before. The District
ranks 8th in the percent of renter households
that are severely overcrowded. Nearly 35% of
renters in the District pay over 50% of their
household income on monthly rent. Affordability
of rentals (at 80% of AMI) decreased from 2010-
2017, from 71.3% to only 49%. These are
pressures that lend themselves to homelessness
and continued expansion of prevention
programs is warranted.
12/26
DOHMH
Create or promote
There were approximately 657 (per 100,000
programs to de-
adults) psychiatric hospitalizations last year,
stigmatize mental
compared to 743 Brooklyn wide and 684
health problems
citywide. In addition alcohol and drug related
and encourage
hospitalizations were 836 and 649 per 100,000
treatment
respectively. Many times HOMESTATE teams
find that people who are reported as homeless
actually have homes but are on the streets to
use. Teams specifically geared to engage with
mental illness and substance abuse would be a
valuable complement to the HOME STAT
approach.
13/26
DOHMH
Reduce rat
CD 14 continues to be among the highest
populations
number of rodent complaints in the City and
those complaints are on the way to doubling
from 300 in 2018 to 600 in 2019. While DOHMH
continues to increase the number of inspections
performed annually, these efforts are outpaced
by conditions contributing to rodent
infestations. Increased coordination with DOB's
abatement rules for construction sites, with
DSNY to address illegal dumping and school
collections, and with the public at large to
educate people on the down side of feeding
feral cats and birds are warranted.
15/26
DFTA
Other services for
Case management, home care, legal services,
homebound older
and transportation services are generally
adults programs
intertwined. There is no way to prioritize the
needs of one senior citizen over those of
another and it would be folly to provide
transportation over home care for a senior who
is need of both. The funding of these services
must be designed with the approach that
support services are inextricable.
20/26
DFTA
Create a new senior
Open an RFP to enable a Senior Center to
center or other
service additional residents of CD 14.
facility for seniors
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 14
image
M ost Important Issue Related to Youth, Education and Child Welfare
School and educational facilities (Capacity)
Community Board 14 has identified the need for expanded school seats as a budget priority for well over a decade and the Department of Education has recognized the need but has not fulfilled it. There are several new developments slated for the district, which will exacerbate overcrowding. We urge DOE and SCA to hasten efforts to provide several hundred elementary school seats. For the past 10 years CB 14 has organized a Youth Conference and in 2018 more than 500 young people attended. CB14's experience with the need for youth workforce development and summer youth employment is most direct. We continue to advocate for an even greater expansion of SYEP. We also encourage DYCD to continue to partner with our Board's efforts on the annual conference.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
There are 35 public elementary and secondary schools in the District serving more than 20,000 students. In addition, there are 26 private/parochial elementary and secondary schools serving 6709 students. The public elementary schools in our district are over capacity - ranging from 111% to 146% over enrolled. The City has recognized our need for additional seats in the District for well over a decade. CB 14 ranks 32nd of 59 in the percentage of students performing at grade level on the NYS 4th grade ELA and Math exams. Our schools have a higher than citywide average of ELL students. Over 30 different first languages are represented on one of our elementary schools.
Needs for Youth and Child Welfare
Given that the population of children under the age of five numbered 11,680 in 2010 and that 22.3% of families in the District with a child under the age of five fell below the poverty line at least once from 2010 to 2012, the number of early childhood programs is woefully inadequate. This is especially needed in our District where 28% of our residents have limited English language proficiency. We will be planning our 13th Annual Youth Conference.
This event serves more than 16 students every year; over 60 organization, agencies and job providers participate. We value DYCD's role in this event and hope it can be expanded.
image
Capital Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
9/19 SCA Provide a new or
expand an existing elementary school
PS 139 is at 121% of utilization; PS 127 is at 125%; PS 249 is at 128%, PS 193 is at 111%; PS
315 is at 118% and the PS 152 Annex is at 146%. Since annexes are built to address overcrowding, an overcrowded annex boldly underscores the need for additional elementary school seats in the northern end of the District. The elementary schools listed above are all north of Avenue L.
image
14/19 SCA Renovate other site
component
Areas to store garbage before and then areas to place bags or containers for pick up need better planning and design. Too many schools place a large number of bags out too early in the day.
They are often ripped and are adding to our rodent population and public health and safety concerns.
Expense Requests Related to Youth, Education and Child Welfare
Priority
Agency
Request
Explanation
Location
10/26
DYCD
Provide, expand, or
According to our Youth Conference attendees
enhance the
survey the biggest draw for the 600 youth who
Summer Youth
attended out annual conference was "jobs".
Employment
However, it has become increasingly difficult to
Program
schedule the conference in tandem with the
Summer Youth Employment application
deadline because funding is always so
uncertain. Given the very small percentage of
applicants who are placed in summer jobs, it is
imperative that the program be expanded and
dependably funded.
19/26
ACS
Other foster care
The agency has made positive strides in
and child welfare
reducing caseloads. This effort must be
requests
continued.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 14
image
M ost Important Issue Related to Public Safety and Emergency Services
Public safety facilities (precinct, fire houses, etc.)
The need for a new police precinct in an appropriate setting has been recognized by the community and by the NYPD for decades. This is a need worthy of top priority in the arena of public safety.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
The men and women of the 70th Police Precinct serve our community exceptionally well, keeping crime and quality of life problems at historic lows. They manage to do so from a Precinct House that is poorly suited to their needs and to the needs of the community. The 70th Precinct House is undersized, antiquated and deteriorated. Adapt Community Network, which serves people with cerebral palsy, shares this very narrow, one-way street. Thus one of the most active Precinct Houses is in the midst of one of the largest concentrations of multiply handicapped people in the city. Overall crime numbers continue to decrease, making the 70th Precinct one of the few in the city where crime has dropped every year since since the introduction of Compstat. The introduction of the Mayor's and Commissioner's "One City: Safe and Fair Everywhere", neighborhood policing plan has made great strides in addressing the needs of both the police and community members in terms of communication, information sharing and all around good relations. The Neighborhood Coordinating Officers have become familiar with and to community members and have addressed both quality of life and matters of public safety with new efficiency, instilling greater confidence throughout the community. The number of crossing guards has increased over the past two years, however it has not kept pace with need. Ensuring that the position offers incentives to attract and retain personnel is a priority.
Needs for Emergency Services
None of the firehouses in CD 14 are slated for renovations or generators. Given that mandatory inspections are based on Department of Buildings new construction, alteration and demolition permits and given that those permit applications are increasing, the need to ensure adequate resources for inspections is clear. Education programs to prevent fires and swift response are also key It remains distressing that response times continue to increase for FDNY and for EMS. The process by which FDNY approves DOT installations such as speed humps, pedestrian islands, and curb extensions must be reviewed has improved to ensure that local input is emphasized.
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/19
NYPD
Renovate or
The history of efforts to relocate this aging
upgrade existing
facility goes back three decades. In 2006, DCAS
precinct houses
began property acquisition at 1326 Ocean
Avenue and NYPD set aside $30 million for the
property, and OMB stated its commitment to
identify additional funding. construction was set
to begin in 2013. It did not and the site was lost
to a market rate housing development. A
scoping study to asses the feasibility of building
a new precinct house on site reportedly
acknowledges the locational challenges that the
current site presents. Relocating the precinct
house remains a priority. A new site search must
be funded. In the meantime, the current
precinct house floods and leaks and does not
have adequate lockers, storage, or parking, nor
it is handicap accessible.
8/19
NYPD
Renovate or
While NYPD continues the search for an
upgrade existing
appropriate location for a new precinct house,
precinct houses
the current precinct house floods and leaks and
does not have adequate lockers, storage,
parking, nor it is handicap accessible.
11/19
NYPD
Add NYPD parking
Expand capacity of the NYPD tow pound.
facilities
According to NYPD consultations, there is
sometimes not space a the two pound to keep
pace with ro-tows. We understand that NYPD is
exploring the use of auto parking lifts to expand
capacity and we support this plan.
13/19
NYPD
Provide surveillance
This continues to be a common request from the
cameras
community and the Precinct. CD 14 would defer
to the CO as to most warranted location. While
cameras are typically funded by allocations
made by elected officials, we believe funding
should be provided in the NYPD budget directly
so that placement is not contingent on the
interest level of whichever city councilmembers
overlap with a Precinct.
15/19
FDNY
Rehabilitate or
Fund station house renovations and upgrades at
renovate existing
Engine 255/Ladder 157; Engine 281/Ladder 147
fire houses or EMS
and Engine 250 firehouses. Including the
stations
addition of a station house generator at one of
these fire stations. There are no firehouses in CD
14 with a generator.
17/19 FDNY Provide new
facilities such as a firehouse or EMS station
Expand facilities for training programs. The expansion of classroom space and a parking facility to meet the needs of the growing footprint for training programs for FDNY and EMS is an important investment in our city's safety resources as development and population growth continues citywide.
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
6/26
NYPD
Assign additional
This is an increasing request. New schools have
crossing guards
opened, new developments are in the pipeline.
The Community Board defers to the Police
Precinct to assign additional crossing guards to
new locations.
14/26
NYPD
Provide additional
According to NYPD consultations, many vehicles
patrol cars and
are reaching the end of their useful life which
other vehicles
means that more cars are in repair more often
and for longer periods of time awaiting parts.
Parks and new vehicles must be funded.
16/26
FDNY
Provide more
Fund adequate new firefighter, Marshall, EMS
firefighters or EMS
and inspector hires. Given the pace of
workers
development and the density that is adding to
our community, it is imperative that we ensure
that staffing remain optimal and that the
addition of a 5th firefight on the truck is
expanded to firehouses serving our community.
Two years ago more than a dozen Fire
Marshalls were hired and dedicated to
Brooklyn. The increase is useful and should be
augmented by additional hires for Marshalls
and inspectors in FY 20.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 14
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Water runoff and flooding
Many issues are interrelated and thus hard to prioritize from City Planning's predetermined list. Usually environmental concerns lead to air quality, and water pollution issues. Sewer capacity and flooding are related. Additionally, snow clearing is only a priority in the winter, flooding is only a concern when it rains. These important but not everyday issues make it hard to prioritize. They can be more urgent, however garbage must be collected every day. CB 14 is extremely gratified that after ten years of prioritizing our request for a six day a week dedicated basket truck, DSNY has restored this service. It has made an immediate improvement in the cleanliness of our commercial streets. It is important to ensure that this is a permanent, baseline service. Rodent complaints have doubled in the past year, in part due to food that is put out for cats and birds. These behaviors are nearly impossible to enforce. One of the most stubborn and damaging complaints that CB 14 continues to receive are those related to flooding, water run off and ponding. There was hope that flooding on Church Avenue would be abated by the installation of catch basins as part of the capital sidewalk project, but it was not. Now we are told to pin our hopes on a capital project at the Parade Ground. This should not be such a puzzle. The cause and solution of these ongoing flooding concerns must be determined.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Trench restoration continues to be an issue in the District. DOT was allocated $60 million to address trench issues citywide, thus DEP was able to pass the ball on these projects. However, not one of the trenches in CD 14 made the DOT list. There has been no forward progress on this issue. Flooding remains an issue in several locations. A sidewalk improvement project on Church Avenue added 30 new catch basins to the corridor but there has been no improvment for the businesses and homes that get flooded in heavy rains. DEP has offered to assist Parks in maintanance north of the occurances but ultimately, the overwhelmed system in the city streets is under the purview of DEP and they must address this issue.
Needs for Sanitation Services
Given that each and every resident produces more than two pounds of garbage every day, the efforts of the Department of Sanitation workers at BK 14 to keep pace with the needs of our District are greatly appreciated. Within our 2.9 miles there are 89 road miles and 54 dead ends and several narrow streets. In additon, bike lanes, pedestrian island, and neckdowns installed by DOT offer new challenges to collection, recycling, street sweeing and snow removal. Illegal dumping continues to be a difficult issue in the District with its many dead ends, one block streets and many road bridges. Cleanliness has improved and complaints have abated along commercial streets since the six day a week basket truck was restored. The reintroduction of electronics collection by DSNY has also been a positive change in the District. We are extremely grateful for BK14's responsiveness to the needs of our community in general and thier interagency work pertinent to homeless encampment conditions and derelict vehicles that are persistent issues in several locations in the District.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority Agency Request Explanation Location
image
2/19 DSNY Provide new or
upgrade existing sanitation garages or other sanitation infrastructure
Replace all condemned heating and cooling systems installed on the BK14 roof to upgraded, operational systems to ensure that the garage has heat in the winter and adequate cooling in the summer. Continued repair is not adequate - the system must be replaced. Repair the roof so that it no longer leads and so that tarp is not needed on the ceiling in the locker room.
image
7/19 DSNY Provide new or
increase number of sanitation trucks and other equipment
DSNY and DOT both reported that they are continuing to collaborate on addressing collection, street sweeping, and snow removal issues that have arising following the installation of bike lanes, neck downs, and pedestrian islands. DSNY requires additional smaller vehicles, such as bobcats and haulsters to address the growing numbers of such conditions in CD14.
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
5/26
DEP
Inspect water main
There are several locations in the District that
on specific street
flood chronically in rainstorms. These locations
segment and repair
have all been brought to DEP's attention and we
or replace as
are awaiting determination as to cause. DCP
needed (Expense)
has provided a limited drop down list from
which to choose a budget priority. We ask the
DEP respond to the requests pending and advise
as to what the respective issues are so that we
can identify what budget line these requests fall
into. The bottom line is that DEP must provide
solutions to these locations because property,
businesses and public areas should not have to
withstand chronic flooding. Several claims have
been filed with the City of New York.
18/26
DSNY
Provide more
Provide garages with weed wackers, bolt
frequent litter
cutters, pruning sheers and other tools to assist
basket collection
with lots, dead ends, and DOT pedestrian
islands.
22/26 DSNY Provide more
frequent litter basket collection
The return of this baseline service to your community after a six-year hiatus was an immediate and noticeable improvement . The service now convers the entirety of our District, not just areas were councilmembers were willing and able to fund this collection on overtime. It has allowed for additional corner baskets on commercial streets now that the District can meet demand with daily service. We urge the Department to continue this funding.
image
23/26 DSNY Other cleaning
requests
There are 1200 road segments in CD 14. Given the number of dead ends, overpasses, and road bridges, cleaning is a persistent need. The sheer variety of Supervisors' functions in this increasingly densely populated and high traffic district has increasingly demonstrated that additional supervisors would alleviate myriad issues.
image
26/26 DSNY Increase
enforcement of canine waste laws
Illegal drop offs and dumping at commercial baskets, dead-ends, tree pits, etc is an ongoing complaint. Resident bring garbage to corner baskets, construction and other commercial debris are often found under elevated train tracks. Often the sanitation workers, supervisors and police know who the offenders are but the rules for enforcement require a stake out.
Funding to increase enforcement's capacity to steak out chronic locations, day and night, could make an enormous difference in the public health, safety and appearance of out District.
image
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 14
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Housing support (including tenant protection)
Housing code enforcement and building code enforcement are equally important in the District. CB14 now ranks 12th (up from 18th) of 59 community districts in the number of reported serious housing code violations. Only 40% of renter occupied homes are adequately maintained by landlords. Housing code violations are correlated with health issues and is a problem underscored by the fact that the district is also one of the most severely rent burdened and overcrowded. Given the fact that over 48% of the area of the district is comprised of 1-2 family homes, combined with the fact that we rank 12th in the city in terms of population density, the renters of multi- family dwellings are highly concentrated. This contrasts with how the District’s single family homes are economically situated. In CD 14, the median price of a single family home is among the highest in New York City. Prospect Park South, Ditmas Park, Midwood Park-Fiske Terrace, Albermarle-Kenmore Terraces, are all historically landmarked neighborhoods. They comprise 6% of lots in the District, which ranks us 18th in the City for lots regulated by the Landmarks Preservation Commission. There is also a special permit district in the southern end of the district, which allows an increase the floor area of existing homes. Zoning violations occur throughout the District. Primarily, these violations are commercial use in a residential zone. There are also many complaints of illegal curb cuts and parking pads. There has been very little enforcement of any of CB14's zoning violation complaints. So many of these issues have been pending for many years. In addition to zoning violations, there continues to be a growing number of construction complaints including work without a permit, work beyond permitted times and days, as well as illegal conversions. It is important to protect the uniquely beautiful, valuable, and significant history of our single family residential areas while balancing the quality of denser, multi-unit dwellings.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
Community Board 14 residents live in a mix of housing that is dominated by single and two family homes. There are four historic district in CD 14. The capacity to develop in the district is one of the lowest in the city, yet the pressures for affordable housing are great. We rank 8th in the city in the severe overcrowding rate. This district is disproportionately rent burdened, with 50% of low-income renter households severely burdened, meaning that rent is at least 50% of household income. CB14 ranks 12th in the city in the number of serious housing code violations and only 40% of renter occupied homes are adequately maintained by landlords.
Needs for Housing
The District ranks 8th in the rate of severe overcrowding in renter households. Despite the fact that last year the District was 53rd of 59 Districts in terms of unused capacity for development, yet the ranking for units authorized for new building permits has soared from 59th in 2000 to 17th in 2016-17. Units issued new certificates of occupancy went form 53rd citywide to 12th in the same period. While those number slowed in the following year, those residents are now members of our population and add to the demand for quality public infrastruction and city services. It is important to understand where the units are being developed vis a vis our
public infrastructure in terms of schools, parks, transportation and water and sewer systems; and to ascertain the extent to which affordability of newly developed housing corresponds to the needs of our current residents.
Needs for Economic Development
There are several commercial strips in the district serving the needs of residents and beyond. Many small independent stores line Church Avenue, Cortelyou Road, Avenues J and M and Coney Island Avenue, Flatbush Avenue and Newkirk Plaza. Several new businesses have opened in the District over the past year, including new
restaurants, bars, and boutiques. There are three Business Improvement Districts – Flatbush Nostrand Junction BID, the Flatbush BID and the Church Avenue BID - and several merchant associations in our community.
We face notable challenges in maximizing commercial activity throughout the District. Triangle Junction shopping mall still has Target as it's anchor store but many other national chains have come and gone, suggesting that there are questions about the fate of this development. The installation of the dedicated bus lane on Church Avenue has met with deep consternation from the business owners on this route that is heavily traveled by mass transit, personal vehicles, bikes and cars alike. The City continue to refuse to assign Newkirk Plaza to DOT or an appropriate agency to allow enforcement, services, and programming.
The Kings Theatre, a 3300 seat live performance venue, draws people from near and far. This project combined with the completion of the Brooklyn College Tow Performing Arts Center to the south and the existence of performing arts venues to the north, provide a vital link in Brooklyn’s cultural corridor and many spillover opportunities for surrounding merchants. CB14 was awarded a Planning Fellow from the Fund for the City of New York who will research our past and current economic development opportunities. We look forward to the information and the guidance to ensure resources are brought to bear in the most efficient manner.
image
Capital Requests Related to Housing, Economic Development and Land Use
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
4/26
NYCHA
Expand programs
Four out of five top 311 requests are for HPD
for housing
inspections and violation enforcement. CB 14
inspections to
ranks 12th in the city in the number of housing
correct code
code violations per 1000 residents.
violations
7/26
EDC
Expand public
Develop and RFP for Newkirk Plaza. The Plaza is
programming and
a platform over MTA NYCT's Brighton Line
activation of City-
station. However, NYCT does not recognize the
owned sites
street level pedestrian mall as being under it's
purview. Likewise, while the Plaza offers public
access, and serves as walkway flanked by
approximately 20 stores, DOT does not include
the Plaza in it's inventory of sidewalks in the
public right of way. Furthermore, DOT will not
accept Newkirk Plaza into the DOT Pedestrian
Plaza program, despite the fact that Newkirk
Plaza is prototypical. Since this is publically
owned land, EDC should develop and RFP so
that the space can be assumed and programed
by an interested party for better maintenance,
programming and public benefit.
9/26
DOB
Assign additional
Too many complaints are closed out due to lack
building inspectors
of access while unpermitted work continues to
(including
the point of completion. Better timing of
expanding training
inspections, additional attempts and more
programs)
detailed follow ups would assist in the ability to
enforcement myriad violations.
17/26
EDC
Expand public
Issue an RFP for the lot on Bedford and Church
Church
programming and
Avenues. This lot was the site of a historically
Avenue
activation of City-
landmarked school hat had to be demolished.
owned sites
The now empty lot is poorly maintained by the
City. In a community where green space and
public gathering space is at a premium, EDC
should hasten the RFP process with a
community amenity in mind.
24/26 SBS Other expense commercial district revitalization requests
The development and restoration of the Kings theater was an EDC project that is owned and managed by a private entity and is a for profit enterprise, the Tow Performing Arts Center is housed at a public institution of higher education but will run ticketed events, the Mayor's Office of Media and Entertainment permitted over 150 film and television productions in our 2.9 square miles of space last year. These enterprises generate a good deal of profit with the support of public space and financing. There should be some sort of mechanism that directs some funding back to the local community that often bears significant inconvenience from these activities.
image
TRANSPORTATION
Brooklyn Community Board 14
image
M ost Important Issue Related to Transportation and Mobility
Traffic congestion
The Department of Transportation is the agency with the most service delivery requests directed to the Community Board. This is in part due to the sheer number of requests and the length of time it takes DOT to address many service delivery items. Requests for speed reducers, signs, traffic lights, street lights, etc. can take DOT years to respond to. In our commercial areas there are frequent complaints regarding traffic congestion, parking, and street conditions. Flatbush Avenue and Coney Island Avenue are two main north/south corridors. Flatbush Avenue is a congested and it seems that improvements have not kept pace with development and increased activity. Thus it continues to be a high crash corridor. Coney Island Avenue also presents traffic and safety issues. The installation of a pedestrian island at Cortelyou Road has met with unintended consequences and DOT continues to try to modify this publically un-vetted installation. High weeds on the pedestrian islands at Avenue O and N are undermines safe sight lines yet, DOT claims no responsibility for maintenance. CB14 has requested a safety study of the entire Coney Island Avenue corridor. There were three vehicular fatalities along Coney Island Avenue since the summer.
East/west streets including Avenue J, Foster Avenue, Cortelyou Road, Church and Caton Avenues are nearly constantly backed up. Oftentimes cars wait for multiple light cycles to pass an intersection. Church and Caton Avenues are also truck routes. A new 255 unit residential development is planned at Flatbush and Caton Avenues and it is hard to imagine the impact that this additional density will have on these two very congested roads. The streets surrounding the 70th Precinct are also problematic. There was also fatal crash in this area. These narrow streets are nearly always congested. Last year DOT implemented changes that had a positive impact at Foster and Ocean Parkway. More of this thoughtful, local consideration should be a matter of course and additional improvements should be implemented. The Beverly Road Bridge is so compromised that parking has been removed and trucks are rerouted. There is no timeframe for when the bridge will be repaired. The Parkside Road Bridge has been prioritized for capital repair, yet we have no timeframe for this work either. In addition to community driven requests, DOT initiates proposals for bike paths, pedestrian islands, and pedestrian plazas. While safety is paramount and community amenities are positive proposals, they must be carefully considered and community input must be highly valued. DOT has shifted its policy with regard to community input on many installations. While gathering local input is time-consuming and often messy, the end result in inevitably better and there is always a better outcome with stakeholder buy in.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
All types of ground transportation are important in District 14 where approximatley 11% of commuters walk or ride bikes to work (up 28%!), nearly 65% take mass transit (up 3%) and nearly a quarter drive (down 2%). Within the 2.9 miles that comprise the District, there are 89.2 road miles, 54 dead end streets, two through truck routes, several road bridges over the Brighton Line and LIRR tracks and approximately 1200 street segments. Given its Central Brooklyn location and number of thoroughfares in the District including Flatbush Avenue, Coney Island Avenue, Ocean Parkway, Nostrand Avenue running north/south; and Church Avenue, Cortelyou Road, Foster Avenue and Avenues J and M going east/west, traffic and road conditions are constant concerns. Community Board 14 service delivery data show that DOT requests outnumber those of any other agency with which the Community Board interacts. Part of the reason for this accumulation is the time-lag for many DOT issue responses. In the meantime, DOT has proactively introduced initiatives not requested (and sometimes not supported) by the community.
Responsiveness and community input are important. Of great concern is that there is no way to ascertain an overview of DOT traffic calming measures. Since 2018 we have handled nearly 190 DOT service delivery
requests, but there is no way to understand how implementation of all or any combination of these requests would impact traffic flow in the District. Rather, such requests are considered only insofar as they impact the block for
which they are requested. There are nine subway stations, seven of which are Brighton Line outdoor tracks, therefore track work affects road traffic. There are also 15 bus lines that operate in the district including express buses and select bus service routes.
Needs for Transit Services
There are nine subway stations in the District: one Culver Line IND stop; one IRT terminal stop and the reminder Brighton Line BMT stops. Most of the Brighton Line stations have been updated - some in full, others partial renovations. However the Church Avenue station is in serious need up rehabilitation. We look forward to accessbility improvments and hope they will expand to the Culver line.
We have asked MTA NYCT to provide us with station capacity data to take into consideration when new developments are proposed so that we can better predict the impact on local transit. CB 14 will work to maximize community input on MTA's Fast Forward Brooklyn Bus Network Redesign. We trust this will lead to the restoraton of the B23 on Cortelyou Road! We were disappointed with MTA NYCT's culpability in the Church Avenue dedicated bus lane process that involved so little community input and so poorly engaged merchants directly affected by the lanes.
The community garden on the exterior side of the Church Avenue Brighton Line station house continues to be
a positive addition to the community and should serve as a model for use of the commons. It is unfortunate that Transit will not take the same creative initiative with Newkirk Plaza.
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
4/19
DOT
Upgrade or create
We urge DOT to include Newkirk Plaza into the
new plazas
Plaza Program. The infrastructure exists. An
organization is willing to partner and the Plaza
should be under the auspices of a City agency
given that it is public property.
5/19
DOT
Rehabilitate bridges
The Beverley Road Bridge is in such disrepair
Beverley
that DOT barricaded the north side so that there
Road
is no parking. has reconfigured the dividing line
Marlborough
to shift traffic south and has rerouted trucks so
Rd E 16th St
they do not drive over the bridge at all. Yet, DOT
has not provided information as to funding and
timing for repair. DOT responded last year that
the agency had requested funding for the
Beverley Road bridge but CB 14 was recently
informed that the Parkside Road bridge will be
repaired. We were unaware that this bridge was
in disrepair.
6/19
DOT
Roadway
DOT had a $60 million allocation for trench
maintenance (i.e.
restoration and CB 14 received none of it. Six
pothole repair,
locations have been submitted to DOT. 564 East
resurfacing, trench
29th Street; 1781 Ocean Avenue/SE corner of
restoration, etc.)
Avenue M; 715 Ocean Parkway Service Road;
Waldorf Court between East 17 and Dead End;
Hillel Place and Kenilworth Place intersection;
464-476 East 16th Street. The suggestion that
Community Boards should turn to local elected
officials to tend to trench conditions is
irresponsible.
10/19
NYCTA
Repair or upgrade
Church Avenue is the most heavily utilized
Church Ave
subway stations or
station in the District and is in disrepair. This line
and E 18 St
other transit
has had the most requests for security cameras.
infrastructure
16/19
NYCTA
Improve
The 18th Avenue Stop on the Culver Line is on
accessibility of
the same block as the United Cerebral Palsey
transit
complex. This stop was recently upgraded. It's
infrastructure, by
unfortunate that accessibility was not one of
providing elevators,
the improvements.
escalators, etc.
Expense Requests Related to Transportation and Mobility
Priority Agency Request Explanation Location
image
2/26 DOT Conduct traffic or
parking studies
There have been five vehicle related deaths in the District this year. Coney Island Avenue is a congested corridor that warrants study. The Church Avenue and Caton Avenue truck route study warrants a more urgent focus.
Improvements in the vicinity on the 70th Precinct should continue based on previous studies. Flatbush Avenue improvements should be updated. East and West corridor congestion should be addressed. If DOT will not conduct studies, the City should consider requiring traffic studies for all development proposals.
image
21/26 NYCTA Other transit service
requests
Assume responsibility for the maintenance of Newkirk Plaza. As the gateway to one of MTA's most unique stations, atop America's first outdoor shopping Plaza, there is an opportunity to improve and program the Plaza. An local CBO has expressed interest in a partnership that could mimic the community garden at the Church Avenue station, which inarguably has improved the exterior conditions and the community perspective on that station.
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 14
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Community board resources (offices, staff and equipment)
Community Board 14 is 59th out of 59 community districts citywide in terms of the number of residents who live more than a quarter of a mile away from a park. Arts and culture continues to be a draw to and an asset in our community. The Kings Theatre is a busy venue that also serves the community as a special event and graduation venue. The Tow Center and Brooklyn College has now opened for programming and our libraries are as vibrant as ever, with programming and space for valuable community gathering. It has been noted that there are a number of entities who profit from cultural institutions, as well as daily film shoots in the community. There should be a way to ensure that those profiting off of our community are helping to fund our local parks, playgrounds, cultural offerings, etc. The Community Board is instrumental in ensuring that cultural and park programming, and facilities; community facility access and programming; forestry services; library facilities and services; parks access, care and maintenance; park safety; quality library programming and other parks, cultural and other community facilities are accessible to the public and maintained by the appropriate agencies. While the number of service delivery requests have increased, the number of proposals to consider have increased, the number of meetings and events continue to increase, our funding has not. A $42,500 expense grant has been provided to the Board for the past two years and has enabled the Board to upgrade signage, outreach and expand events. However, these endeavors require additional staff time as well and without a baseline increase, the current staff is approaching capacity.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Residents of CD 14 live further away from a park than any other District in the entire City of New York, with over 70% living a quarter mile away or more. The largest park in our district is the Parade Grounds at our northern border, which includes 40 acres of athletic fields, and tennis courts available by permit only. The only recreational space available at the Parade Ground to the local community without a permit is the heavily-utilized Detective Dillon Stewart Memorial Playground. Kolbert Park is in the southern end of the District and the Deputy Inspector Joseph DiGilio Playground is in the west. Umma Park is a small playground over the BMT tracks in the northeastern end of the District, which as antiquated play equipment and no greenery. There are also two tot lots in the District – on Cortelyou Road and on Campus Road. The Department itself must be adequately resourced to maintain its own inventory, instead of relying on funding provided by elected officials. The identification of additional space for parkland and additional greening of green streets areas is essential in our park-poor community. In 2017 a Planning Fellow provided by the Fund for the City of New York researched and provided recommendations for greening CD14.
Needs for Cultural Services
Situated at the approximate center of Flatbush Avenue, the Kings Theatre serves as a cultural fulcrum of Brooklyn's Cultural Corridor. Brooklyn College is set to open the Tow Center and the diversity and cultural richness of the District lends itself to the support for and involvement in cultural facilities and programming. Libraries in the district are highly utilized by the community for both traditional and increasingly creative cultural offerings.
Needs for Library Services
District 14’s four existing branch libraries are heavily used and highly valued by the community. The Board continues to strongly support essential improvements needed at these locations and advocated for keeping libraries open seven days a week. Our local branch libraries provide programs and services that relate in important ways to our communities such as the Caribbean Literacy and Cultural Center at the Flatbush Branch, and the Cortelyou Road library’s teamwork with other community groups.
Needs for Community Boards
The Community Board meets monthly from September through June. During that season there are several monthly public hearings and committee meetings are held almost weekly. We also host an annual Youth Conference, which has grown each year since its inception in 2007, hosting over 600 students this past year. The Board has instituted Community Based Organization Roundtable which continues to grow every year and this past year was the imputus for the formation of CB14's Census Complete Count Committee Task Force. Every day the District Office assists residents, business owners, organizations and other community members with service delivery requests. Over the past eight years, CB 14 staff have addressed nearly 3000 service delivery requests that require ongoing monitoring and follow up case work. In addition, the office fields many complaints and inquiries daily, that are addressed immediately (such as missed sanitation collections, or requests for information). The 311 system may have value in the City but the community relationships, the ability to proactively follow up on citizen concerns and the ability to distill myriad complaints into budget requests and policy proposals must happen at a very local level and must be managed by people charged with advocating for the community. We are approaching staff productivity
capacity. The ability to continue to assist the District at the highest potential rests on solid support from the City of New York. Access to data and assistance with data analysis; service delivery support; and additional agency liaisons from agencies that are not District Service Cabinet members would go far to increase our reach and efficiency.
Additional funding would assist with our collaboration with city agencies, public institutions, and all community members, as we strive to make even better the vitality, quality of life, access to programs, services and beauty and enjoyment our community has to offer.
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/19
DPR
Reconstruct or
Umma Park is in need of updating - the
upgrade a park or
equipment is antiquated and the surface is in
amenity (i.e.
disrepair. There has been a good deal of
playground, outdoor
residential development in the area thus the
athletic field)
population in surrounding neighborhood is
increasing. This park is in the most dense, and
the most socio-economically neighborhood in
the District, yet is the only playground in the
District to not have been recently rehabilitated.
The time has come to address and improve this
increasingly important community asset. When
CB14 first requested this upgrade, the projected
cost was $1 million. The most recent cost
projection is closer to $2 million. The cost of not
taking action is high. Let's get this done before
the 255 unit residential building nearby fills with
families in need of an outdoor amenity.
12/19
BPL
Create a new, or
The following capital improvements are needed
renovate or upgrade
at our local libraries: Cortelyou Branch - safety
an existing public
and security enhancements; Flatbush Branch -
library
safety and security enhancements, and
abatement; Midwood Branch - safety and
security enhancements, boiler, HVAC, roof. In CD
14 investments include an $8.2 million project
at the Flatbush Branch, which has been
allocated.
18/19
DPR
Provide a new or
CD 14 ranks last in the city in terms of the
expanded park or
number of residents who live more than a
amenity (i.e.
quarter of a mile away from a park.
playground, outdoor
athletic field)
image
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
8/26
OMB
Provide more
One District Manager, one full time and one
community board
part time Community Associate have addressed
staff
over 3000 service delivery requests, which
require on going casework in addition to
thousands of one time, immediate requests,
annual events and increasing administrative
responsibilities. Additional resources would
enable community boards to hire staff and/or
temporary specialists, such as planners, policy
analysts, and IT assistance, etc. This would
enable CBs to introduce more initiatives such as
our CBO roundtable and develop longer range
projects that build from those gatherings.
Ultimately, this enables Community Boards to
complement it's reactive, complaint driven role
with a more proactive, grass roots effort.
11/26
DPR
Forestry services,
Flatbush and Midwood boast 11,319 street
including street tree
trees, including 121 different species according
maintenance
to the most recent DPR tree census. Argyle Road
between Ditmas and Dorchester Roads is
considered the "leafiest" in Brooklyn. We are
gratified by improvement in the DPR pruning
cycle, but at budget consultations the
Commissioner agreed that an even more robust
pruning cycle is desirable. Requests for
emergency pruning and fallen branches have
not subsided in the District.
25/26
BPL
Extend library hours
The Community Board supports the
or expand and
continuation and expansion of programs that
enhance library
are so valuable in connecting our community
programs
members to literacy and culture. From small
children, to teens, adults and older adults, the
breadth of library programming is impressive
and invaluable. The role that branch libraries
will play in the Census 2020 will help ensure
that many millions of federal dollars will be
rightfully restored to our communities. This
should qualify the library to reap some of those
funding benefits.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
The Community Board did not submit any Budget Requests in this category.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/19
NYPD
Renovate or
The history of efforts to relocate this aging
upgrade existing
facility goes back three decades. In 2006, DCAS
precinct houses
began property acquisition at 1326 Ocean
Avenue and NYPD set aside $30 million for the
property, and OMB stated its commitment to
identify additional funding. construction was set
to begin in 2013. It did not and the site was lost
to a market rate housing development. A
scoping study to asses the feasibility of building
a new precinct house on site reportedly
acknowledges the locational challenges that the
current site presents. Relocating the precinct
house remains a priority. A new site search must
be funded. In the meantime, the current
precinct house floods and leaks and does not
have adequate lockers, storage, or parking, nor
it is handicap accessible.
2/19
DSNY
Provide new or
Replace all condemned heating and cooling
upgrade existing
systems installed on the BK14 roof to upgraded,
sanitation garages
operational systems to ensure that the garage
or other sanitation
has heat in the winter and adequate cooling in
infrastructure
the summer. Continued repair is not adequate -
the system must be replaced. Repair the roof so
that it no longer leads and so that tarp is not
needed on the ceiling in the locker room.
3/19
DPR
Reconstruct or
Umma Park is in need of updating - the
upgrade a park or
equipment is antiquated and the surface is in
amenity (i.e.
disrepair. There has been a good deal of
playground, outdoor
residential development in the area thus the
athletic field)
population in surrounding neighborhood is
increasing. This park is in the most dense, and
the most socio-economically neighborhood in
the District, yet is the only playground in the
District to not have been recently rehabilitated.
The time has come to address and improve this
increasingly important community asset. When
CB14 first requested this upgrade, the projected
cost was $1 million. The most recent cost
projection is closer to $2 million. The cost of not
taking action is high. Let's get this done before
the 255 unit residential building nearby fills with
families in need of an outdoor amenity.
4/19
DOT
Upgrade or create
We urge DOT to include Newkirk Plaza into the
new plazas
Plaza Program. The infrastructure exists. An
organization is willing to partner and the Plaza
should be under the auspices of a City agency
given that it is public property.
5/19
DOT
Rehabilitate bridges
The Beverley Road Bridge is in such disrepair
Beverley
that DOT barricaded the north side so that there
Road
is no parking. has reconfigured the dividing line
Marlborough
to shift traffic south and has rerouted trucks so
Rd E 16th St
they do not drive over the bridge at all. Yet, DOT
has not provided information as to funding and
timing for repair. DOT responded last year that
the agency had requested funding for the
Beverley Road bridge but CB 14 was recently
informed that the Parkside Road bridge will be
repaired. We were unaware that this bridge was
in disrepair.
6/19
DOT
Roadway
DOT had a $60 million allocation for trench
maintenance (i.e.
restoration and CB 14 received none of it. Six
pothole repair,
locations have been submitted to DOT. 564 East
resurfacing, trench
29th Street; 1781 Ocean Avenue/SE corner of
restoration, etc.)
Avenue M; 715 Ocean Parkway Service Road;
Waldorf Court between East 17 and Dead End;
Hillel Place and Kenilworth Place intersection;
464-476 East 16th Street. The suggestion that
Community Boards should turn to local elected
officials to tend to trench conditions is
irresponsible.
7/19
DSNY
Provide new or
DSNY and DOT both reported that they are
increase number of
continuing to collaborate on addressing
sanitation trucks
collection, street sweeping, and snow removal
and other
issues that have arising following the
equipment
installation of bike lanes, neck downs, and
pedestrian islands. DSNY requires additional
smaller vehicles, such as bobcats and haulsters
to address the growing numbers of such
conditions in CD14.
8/19
NYPD
Renovate or
While NYPD continues the search for an
upgrade existing
appropriate location for a new precinct house,
precinct houses
the current precinct house floods and leaks and
does not have adequate lockers, storage,
parking, nor it is handicap accessible.
9/19
SCA
Provide a new or
PS 139 is at 121% of utilization; PS 127 is at
expand an existing
125%; PS 249 is at 128%, PS 193 is at 111%; PS
elementary school
315 is at 118% and the PS 152 Annex is at 146%.
Since annexes are built to address
overcrowding, an overcrowded annex boldly
underscores the need for additional elementary
school seats in the northern end of the District.
The elementary schools listed above are all
north of Avenue L.
10/19
NYCTA
Repair or upgrade
Church Avenue is the most heavily utilized
Church Ave
subway stations or
station in the District and is in disrepair. This line
and E 18 St
other transit
has had the most requests for security cameras.
infrastructure
11/19
NYPD
Add NYPD parking
Expand capacity of the NYPD tow pound.
facilities
According to NYPD consultations, there is
sometimes not space a the two pound to keep
pace with ro-tows. We understand that NYPD is
exploring the use of auto parking lifts to expand
capacity and we support this plan.
12/19
BPL
Create a new, or
The following capital improvements are needed
renovate or upgrade
at our local libraries: Cortelyou Branch - safety
an existing public
and security enhancements; Flatbush Branch -
library
safety and security enhancements, and
abatement; Midwood Branch - safety and
security enhancements, boiler, HVAC, roof. In CD
14 investments include an $8.2 million project
at the Flatbush Branch, which has been
allocated.
13/19
NYPD
Provide surveillance
This continues to be a common request from the
cameras
community and the Precinct. CD 14 would defer
to the CO as to most warranted location. While
cameras are typically funded by allocations
made by elected officials, we believe funding
should be provided in the NYPD budget directly
so that placement is not contingent on the
interest level of whichever city councilmembers
overlap with a Precinct.
14/19
SCA
Renovate other site
Areas to store garbage before and then areas to
component
place bags or containers for pick up need better
planning and design. Too many schools place a
large number of bags out too early in the day.
They are often ripped and are adding to our
rodent population and public health and safety
concerns.
15/19
FDNY
Rehabilitate or
Fund station house renovations and upgrades at
renovate existing
Engine 255/Ladder 157; Engine 281/Ladder 147
fire houses or EMS
and Engine 250 firehouses. Including the
stations
addition of a station house generator at one of
these fire stations. There are no firehouses in CD
14 with a generator.
16/19
NYCTA
Improve
The 18th Avenue Stop on the Culver Line is on
accessibility of
the same block as the United Cerebral Palsey
transit
complex. This stop was recently upgraded. It's
infrastructure, by
unfortunate that accessibility was not one of
providing elevators,
the improvements.
escalators, etc.
17/19
FDNY
Provide new
Expand facilities for training programs. The
facilities such as a
expansion of classroom space and a parking
firehouse or EMS
facility to meet the needs of the growing
station
footprint for training programs for FDNY and
EMS is an important investment in our city's
safety resources as development and population
growth continues citywide.
18/19
DPR
Provide a new or
CD 14 ranks last in the city in terms of the
expanded park or
number of residents who live more than a
amenity (i.e.
quarter of a mile away from a park.
playground, outdoor
athletic field)
19/19
HRA
Other request for
The poverty rate in CD 14 is 22%. Housing,
services to support
education, job assistance, health care, and
low-income New
other human services are investments in our
Yorkers
human resources that have been underfunded
because we are so woefully undercounted.
Census 2020 - make Brooklyn Count 100%
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/26
DHS
Expand street
Reports on homeless encampments and
outreach
regarding individuals who appear to be
homeless have increased over the past year.
Common Ground is the current contractor and
provides excellent service. Given the increase in
calls to the Community Board, the Police and
311, an increase in outreach services is
warranted.
2/26
DOT
Conduct traffic or
There have been five vehicle related deaths in
parking studies
the District this year. Coney Island Avenue is a
congested corridor that warrants study. The
Church Avenue and Caton Avenue truck route
study warrants a more urgent focus.
Improvements in the vicinity on the 70th
Precinct should continue based on previous
studies. Flatbush Avenue improvements should
be updated. East and West corridor congestion
should be addressed. If DOT will not conduct
studies, the City should consider requiring traffic
studies for all development proposals.
3/26
DHS,
Other homelessness
Community District 14 ranks 11th of 59 in the
HRA
prevention program
percentage of severely rent burdened household
request
35% up from 30% the year before. The District
ranks 8th in the percent of renter households
that are severely overcrowded. Nearly 35% of
renters in the District pay over 50% of their
household income on monthly rent. Affordability
of rentals (at 80% of AMI) decreased from 2010-
2017, from 71.3% to only 49%. These are
pressures that lend themselves to homelessness
and continued expansion of prevention
programs is warranted.
4/26
NYCHA
Expand programs
Four out of five top 311 requests are for HPD
for housing
inspections and violation enforcement. CB 14
inspections to
ranks 12th in the city in the number of housing
correct code
code violations per 1000 residents.
violations
5/26 DEP Inspect water main
on specific street segment and repair or replace as needed (Expense)
There are several locations in the District that flood chronically in rainstorms. These locations have all been brought to DEP's attention and we are awaiting determination as to cause. DCP has provided a limited drop down list from which to choose a budget priority. We ask the DEP respond to the requests pending and advise as to what the respective issues are so that we can identify what budget line these requests fall into. The bottom line is that DEP must provide solutions to these locations because property, businesses and public areas should not have to withstand chronic flooding. Several claims have been filed with the City of New York.
image
6/26 NYPD Assign additional
crossing guards
This is an increasing request. New schools have opened, new developments are in the pipeline. The Community Board defers to the Police Precinct to assign additional crossing guards to new locations.
image
7/26 EDC Expand public programming and activation of City- owned sites
Develop and RFP for Newkirk Plaza. The Plaza is a platform over MTA NYCT's Brighton Line station. However, NYCT does not recognize the street level pedestrian mall as being under it's purview. Likewise, while the Plaza offers public access, and serves as walkway flanked by approximately 20 stores, DOT does not include the Plaza in it's inventory of sidewalks in the public right of way. Furthermore, DOT will not accept Newkirk Plaza into the DOT Pedestrian Plaza program, despite the fact that Newkirk Plaza is prototypical. Since this is publically owned land, EDC should develop and RFP so that the space can be assumed and programed by an interested party for better maintenance, programming and public benefit.
image
image
8/26
OMB
Provide more
One District Manager, one full time and one
community board
part time Community Associate have addressed
staff
over 3000 service delivery requests, which
require on going casework in addition to
thousands of one time, immediate requests,
annual events and increasing administrative
responsibilities. Additional resources would
enable community boards to hire staff and/or
temporary specialists, such as planners, policy
analysts, and IT assistance, etc. This would
enable CBs to introduce more initiatives such as
our CBO roundtable and develop longer range
projects that build from those gatherings.
Ultimately, this enables Community Boards to
complement it's reactive, complaint driven role
with a more proactive, grass roots effort.
9/26
DOB
Assign additional
Too many complaints are closed out due to lack
building inspectors
of access while unpermitted work continues to
(including
the point of completion. Better timing of
expanding training
inspections, additional attempts and more
programs)
detailed follow ups would assist in the ability to
enforcement myriad violations.
10/26
DYCD
Provide, expand, or
According to our Youth Conference attendees
enhance the
survey the biggest draw for the 600 youth who
Summer Youth
attended out annual conference was "jobs".
Employment
However, it has become increasingly difficult to
Program
schedule the conference in tandem with the
Summer Youth Employment application
deadline because funding is always so
uncertain. Given the very small percentage of
applicants who are placed in summer jobs, it is
imperative that the program be expanded and
dependably funded.
11/26
DPR
Forestry services,
Flatbush and Midwood boast 11,319 street
including street tree
trees, including 121 different species according
maintenance
to the most recent DPR tree census. Argyle Road
between Ditmas and Dorchester Roads is
considered the "leafiest" in Brooklyn. We are
gratified by improvement in the DPR pruning
cycle, but at budget consultations the
Commissioner agreed that an even more robust
pruning cycle is desirable. Requests for
emergency pruning and fallen branches have
not subsided in the District.
12/26
DOHMH
Create or promote
There were approximately 657 (per 100,000
programs to de-
adults) psychiatric hospitalizations last year,
stigmatize mental
compared to 743 Brooklyn wide and 684
health problems
citywide. In addition alcohol and drug related
and encourage
hospitalizations were 836 and 649 per 100,000
treatment
respectively. Many times HOMESTATE teams
find that people who are reported as homeless
actually have homes but are on the streets to
use. Teams specifically geared to engage with
mental illness and substance abuse would be a
valuable complement to the HOME STAT
approach.
13/26
DOHMH
Reduce rat
CD 14 continues to be among the highest
populations
number of rodent complaints in the City and
those complaints are on the way to doubling
from 300 in 2018 to 600 in 2019. While DOHMH
continues to increase the number of inspections
performed annually, these efforts are outpaced
by conditions contributing to rodent
infestations. Increased coordination with DOB's
abatement rules for construction sites, with
DSNY to address illegal dumping and school
collections, and with the public at large to
educate people on the down side of feeding
feral cats and birds are warranted.
14/26
NYPD
Provide additional
According to NYPD consultations, many vehicles
patrol cars and
are reaching the end of their useful life which
other vehicles
means that more cars are in repair more often
and for longer periods of time awaiting parts.
Parks and new vehicles must be funded.
15/26
DFTA
Other services for
Case management, home care, legal services,
homebound older
and transportation services are generally
adults programs
intertwined. There is no way to prioritize the
needs of one senior citizen over those of
another and it would be folly to provide
transportation over home care for a senior who
is need of both. The funding of these services
must be designed with the approach that
support services are inextricable.
16/26
FDNY
Provide more
Fund adequate new firefighter, Marshall, EMS
firefighters or EMS
and inspector hires. Given the pace of
workers
development and the density that is adding to
our community, it is imperative that we ensure
that staffing remain optimal and that the
addition of a 5th firefight on the truck is
expanded to firehouses serving our community.
Two years ago more than a dozen Fire
Marshalls were hired and dedicated to
Brooklyn. The increase is useful and should be
augmented by additional hires for Marshalls
and inspectors in FY 20.
17/26
EDC
Expand public
Issue an RFP for the lot on Bedford and Church
Church
programming and
Avenues. This lot was the site of a historically
Avenue
activation of City-
landmarked school hat had to be demolished.
owned sites
The now empty lot is poorly maintained by the
City. In a community where green space and
public gathering space is at a premium, EDC
should hasten the RFP process with a
community amenity in mind.
18/26
DSNY
Provide more
Provide garages with weed wackers, bolt
frequent litter
cutters, pruning sheers and other tools to assist
basket collection
with lots, dead ends, and DOT pedestrian
islands.
19/26
ACS
Other foster care
The agency has made positive strides in
and child welfare
reducing caseloads. This effort must be
requests
continued.
20/26
DFTA
Create a new senior
Open an RFP to enable a Senior Center to
center or other
service additional residents of CD 14.
facility for seniors
21/26
NYCTA
Other transit service
Assume responsibility for the maintenance of
requests
Newkirk Plaza. As the gateway to one of MTA's
most unique stations, atop America's first
outdoor shopping Plaza, there is an opportunity
to improve and program the Plaza. An local CBO
has expressed interest in a partnership that
could mimic the community garden at the
Church Avenue station, which inarguably has
improved the exterior conditions and the
community perspective on that station.
22/26
DSNY
Provide more
The return of this baseline service to your
frequent litter
community after a six-year hiatus was an
basket collection
immediate and noticeable improvement . The
service now convers the entirety of our District,
not just areas were councilmembers were
willing and able to fund this collection on
overtime. It has allowed for additional corner
baskets on commercial streets now that the
District can meet demand with daily service. We
urge the Department to continue this funding.
23/26
DSNY
Other cleaning
There are 1200 road segments in CD 14. Given
requests
the number of dead ends, overpasses, and road
bridges, cleaning is a persistent need. The sheer
variety of Supervisors' functions in this
increasingly densely populated and high traffic
district has increasingly demonstrated that
additional supervisors would alleviate myriad
issues.
24/26
SBS
Other expense
The development and restoration of the Kings
commercial district
theater was an EDC project that is owned and
revitalization
managed by a private entity and is a for profit
requests
enterprise, the Tow Performing Arts Center is
housed at a public institution of higher
education but will run ticketed events, the
Mayor's Office of Media and Entertainment
permitted over 150 film and television
productions in our 2.9 square miles of space last
year. These enterprises generate a good deal of
profit with the support of public space and
financing. There should be some sort of
mechanism that directs some funding back to
the local community that often bears significant
inconvenience from these activities.
25/26
BPL
Extend library hours
The Community Board supports the
or expand and
continuation and expansion of programs that
enhance library
are so valuable in connecting our community
programs
members to literacy and culture. From small
children, to teens, adults and older adults, the
breadth of library programming is impressive
and invaluable. The role that branch libraries
will play in the Census 2020 will help ensure
that many millions of federal dollars will be
rightfully restored to our communities. This
should qualify the library to reap some of those
funding benefits.
26/26 DSNY Increase
enforcement of canine waste laws
Illegal drop offs and dumping at commercial baskets, dead-ends, tree pits, etc is an ongoing complaint. Resident bring garbage to corner baskets, construction and other commercial debris are often found under elevated train tracks. Often the sanitation workers, supervisors and police know who the offenders are but the rules for enforcement require a stake out.
Funding to increase enforcement's capacity to steak out chronic locations, day and night, could make an enormous difference in the public health, safety and appearance of out District.
image

