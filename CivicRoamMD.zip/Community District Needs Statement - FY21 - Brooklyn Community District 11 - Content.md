- Page Type:: [[Content]]
- Metadata:: [[Community District Needs Statement - FY21 - Brooklyn Community District 11 - Metadata]] 
- Roam Embed::
    - {{pdf: https://drive.google.com/file/d/1RG7fOlgYj44-3TTSzEgn3h-mOos4OA_B/preview}}
- Obsidian Embed::
    - <iframe src="https://drive.google.com/file/d/1RG7fOlgYj44-3TTSzEgn3h-mOos4OA_B/preview" width="100%" height="600"></iframe>
- Text::
    - image
Statements of Community District Needs
and
Community Board BudgetRequ
Fiscal Year
2021
image
11¥1:
Published by:
PLANNING
February 2020
,•'','
Brooklyn Community District
11
INTRODUCTION
The annual Statements of Community District Needs (CD Needs Statements) and Community Board Budget Requests (Budget Requests) are Charter mandates that form an integral part of the City's budget process. Together, they are intended to support communities in their ongoing consultations with city agencies, elected officials and other key stakeholders and influence more informed decision making on a broad range of local planning and budget priorities. This report also provides a valuable public resource for neighborhood planning and research purposes, and may be used by a variety of audiences seeking information about New York City's diverse communities.
HOW TO USE THIS REPORT
This report represents the Statement of Community District Needs and Community Board Budget Requests for Fiscal Year (FY) 2021. This report contains the formatted but otherwise unedited content provided by the community board, collected through an online form available to community boards from August to November, 2019.
Community boards may provide substantive supplemental information together with their Statements and Budget Requests. This supporting material can be accessed by clicking on the links provided in the document or by copying and pasting them into a web browser, such as Chrome, Safari or Firefox.
If you have questions about this report or suggestions for changes please contact: C DNEEDS_DL@planning.nyc.gov
This report is broadly structured as follows:
Overarching Community District Needs
Sections 1 – 4 provide an overview of the community district and the top three pressing issues affecting this district overall as identified by the community board. Any narrative provided by the board supporting their selection of their top three pressing issues is included.
Policy Area-Specific District Needs
Section 5 is organized by seven distinct policy areas aligned with the service and program areas of city agencies. For each policy area, community boards selected the most important issue for their districts and could provide a supporting narrative. The policy area section also includes any agency-specific needs and a list of relevant budget requests submitted by the community board. If the community board submitted additional information outside of a specific policy area, it may be found in Section 6.
Community Board Budget Requests
The final section includes the two types of budget requests submitted to the City for the FY21 budget cycle; one list for capital and another for expense budget requests. For each budget request, community boards were able to provide a priority number, explanation, location, and supporters. OMB remains the definitive source on budget requests submitted to city agencies.
D isclaimer
This report represents the Statements of Community District Needs and Community Board Budget Requests of this Community District for Fiscal Year 2021. This report contains the formatted but otherwise unedited content provided by the community board.
Budget Requests: Listed for informational purposes only. OMB remains the definitive source on budget requests and budget request responses.
Budget Priorities: Priority numbers apply to expense and capital Budget requests from all policy areas. A complete list of expense and capital budget requests by this Board sorted by priority can be found in Section 7 of this document.
Supporting Materials: Some community boards provided substantive supplemental information. This supportive material can be accessed by clicking on the links provided in the document or by copying and pasting the links provided in the Appendix into a browser.
TABLE OF CONTENTS
Community Board Information
image
Community District Profile and Land Use Map
image
Overview of Community District
image
Top Three Pressing Issues Overall
image
image
image
Summary of Community District Needs and Budget Requests Health Care and Human Services
image
image
Youth, Education and Child Welfare Public Safety and Emergency Services
image
image
image
Core Infrastructure, City Services and Resiliency Housing, Economic Development and Land Use Transportation
Parks, Cultural and Other Community Facilities
image
Other Budget Requests
image
Summary of Prioritized Budget Requests
image
1. COMMUNITY BOARD INFORMATION
Brooklyn Community Board 11
image
Address: 2214 Bath Avenue Phone: (718) 266-8800
Email: BK11@cb.nyc.gov
Website: www.brooklyncb11.org
Chair: William R. Guarinello District Manager: Marnee Elias-Pavia
image
2. COMMUNITY DISTRICT PROFILE AND LAND USE MAP
image
image
3. OVERVIEW OF COMMUNITY DISTRICT
Community Board 11 encompasses four major neighborhoods: Bensonhurst, Bath Beach, Mapleton and Gravesend. The north, south, east, west limits of 61st Street, Gravesend Bay, 26th Avenue and Avenue U.
The most recent data derived from the 2013-2017 American Community Survey and census data, the population of the community has grown from approximately 182,000 in 2010 to 205,850 in 2017. Accordingly, the population density increased to about 50,000 people per square mile, with some census tracts increasing by as much as 16.8%.
The district’s demographics are comprised of 40% white, 39% Asian, 15% Hispanic and 2% black. The population is by no means static as evidenced by the ongoing settlement of Asian, Russian, Hispanic and Middle Eastern/North African immigrants, with 55% of the community foreign born.
According to the New York State Controller, between 2009 and 2017, there was a 62% job growth increase in Bath Beach and Bensonhurst. The economic level of the population is best defined as middle class with a considerable blue-collar emphasis.
The housing stock consists of one- and two-family homes with pockets of six-story buildings of 50-60 units, and four and five story walk-ups of 16 to 40 units. The District includes many smaller properties that are under-developed in relation to the development rights provided by the existing zoning and there has been a trend for such properties to be fully developed.
Commercially, Community Board 11 is well served, as is all southern Brooklyn by 86th Street. This comparative commercial shopping street running from 14th Avenue to 26th Avenue, are extremely viable. There are few vacancies and rents are high. Additional strong commercial strips serving the district are 18th Avenue, Bay Parkway, Kings Highway, Avenue U and Bath Avenue.
With expanded areas of the community included in the Preliminary Flood Insurance Rate Maps, mitigation and resiliency projects are necessary. Storm water and sewer infrastructure upgrades, increased permeability, legislative action to enforce illegal parking pads and curb cuts are a priority for this community.
There is a need for coastal protections along the Shore Parkway promenade from Bay Parkway to Bay 8th Street, to protect the Belt Parkway and upland from wave action, tidal protection and flooding.
The Capital and Expense priorities submitted for Fiscal Year 2020, were carefully targeted to meet the needs of the entire community. Planning for Fiscal Year 2021 will continue the board’s efforts to get adequate governmental assistance for all of Community Board 11.
4. TOP THREE PRESSING ISSUES OVERALL
Brooklyn Community Board 11
image
The three most pressing issues facing this Community Board are:
Land use trends (zoning, development, neighborhood preservation, etc.)
There is a need for the Department of City Planning to conduct a comprehensive review of the district to assess the need for additional core services needed by this community. Over the past few years, Community Board 11 has seen an increase in the amount of as of right development. In addition to small development projects, 3 properties on Cropsey Avenue have filed plans, which combined will contain 437 new residential units. Had these projects undergone discretionary zoning approval, a full environmental impact statement would have been conducted. Our district includes many smaller properties that are under-developed in relation to the development rights provided by the existing zoning and there has been a trend for such properties to be fully developed. Such development analysis and projections would assist Community Board 11 in advocating for appropriate levels of service and staffing for Police, Sanitation, Transportation and Parks services. Additionally, reviews of schools for the adequacy of school seat capacity and utilization, needs for childcare slots, and for senior cent services should be reviewed to determine the ability to support added growth. This community will not be sustainable without addressing the need for additional services.
Quality of life issues (noise, graffiti, petty crime, etc.)
With the increase in population, we are also seeing an increase in quality of life complaints, which include street cleanliness and garbage removal on our commercial corridors. Department of Sanitation Litter, dirty areas and improper disposal are a common complaint that the district office receives. There is a need for additional Motorized Litter Patrols, additional motorized sweeper service, and enforcement agents to address these conditions.
Department of Buildings Illegal building conversions, illegal curb cut complaints, the removal of green space in front yards for parking, and the lack of parking continue to be the top complaints the board receives. The Department of Buildings needs additional allocations and legislative tools to address these complaints and ensure the safety of our first responders and residents. NYPD Police Department According to BoardStat, the most requested 311 complaint filed within Community Board 11 relates to illegal parking. The 62nd Precinct, in fiscal year 2019 received 5,031 service requests for blocked driveways and 4,804 service requests for blocked fire hydrants. In fiscal year 2018, there were 4,706 service requests for blocked driveways and 4,168 service requests for blocked hydrants. Illegal Parking is the top non-emergency complaint filed via 311 received by the 62nd Precinct. We expect this trend to continue in fiscal year 2021.
Street conditions (roadway maintenance)
Department of Transportation has prioritized many streets in our district, that are in need of capital improvements. High priority should be given to the inclusion of streets surveyed by this Department. As our priorities reflect, numerous locations have been referred by the Department of Transportation to the Department of Environmental Protection for action. These locations should be classified as capital projects. Over the past fiscal years, sewer reconstruction projects have only been conducted under emergency reconstruction projects. Additionally, the Department of Transportation has identified streets where sewer reconstruction was made using the trench method. Currently, only two streets are scheduled for capital reconstruction. However, there are additional streets with defects that appear to be related to failing trenches. Streets that were constructed with the trench method should be identified and included in the capital plan. The board has identified roadways that are sinking, hummocked and have had numerous reoccurring cave-ins. There needs to be better coordination between agencies and utility companies to prevent planned work on newly repaved streets.
image
5. SUMMARY OF COMMUNITY DISTRICT NEEDS AND BUDGET REQUESTS
HEALTH CARE AND HUMAN SERVICES
Brooklyn Community Board 11
image
M ost Important Issue Related to Health Care and Human Services
Services for low-income and vulnerable New Yorkers
Community Board 11 is in need of an ambulatory health care facility. Long distances hamper the older population from easy access to Coney Island, NYU Lutheran and Maimonides Hospitals; existing emergency rooms are over capacity. It is vital that healthcare be made more accessible by having an outreach clinic within Community Board
11. A Naturally Recurring Retirement Community is designated within the district. It is vital that adequate assistance is given to the board through programs administered by the Department of Housing Preservation and Development, particularly Article 8A loans and increased community development funding for housing programs. Additionally, the Department should work closely with housing groups in our area. According to the available data released by the Department of Health, there are 463 per 100,000 adults had alcohol related hospitalizations. While alcohol related issues cannot be attributed to any group or demographic, complaints continue from area residents regarding day laborers who congregate on commercial corridors awaiting work. It has been reported from residents that workers that do not get work tend to consume alcohol to a point where emergency intervention is required. This vulnerable population is in need of support services to address these issues.
image
image
C ommunity District Needs Related to Health Care and Human Services
Needs for Health Care and Facilities
No comments
Needs for Older NYs
Increased funding for Senior Services There is a need to provide increased services to our older residents, which have been diminished by budgetary constraints. According to the Department of City Planning our older population in New York City will increase by 40 percent to more than 1.4 million people between now and 2040. Support services should be increased to reflect this growing, vulnerable population.
Needs for Homeless
No comments
Needs for Low Income NYs
No comments
image
Capital Requests Related to Health Care and Human Services
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Health Care and Human Services
Priority
Agency
Request
Explanation
Location
15/36
DOHMH
Reduce rat
There has been an increase in the amount of rat
populations
sightings being reported within the district. The
board has done extensive outreach, education
and made recommendations to reduce garbage
and food availability; there is still a need for
increased funding for inspection services and
abatement.
25/36
DOHMH
Promote Quit
In recent years the smoking rates have declined
Smoking Programs
citywide due to outreach, education and
support; however there is still a need in our
community to further these reductions.
30/36
DFTA
Other senior center
Community Board 11 supports increased
program requests
funding for all categories of senior services.
32/36
DOHMH
Create or promote
According to the Department of Health and
programs to de-
Mental Hygiene Emergency Departments at
stigmatize mental
NYU Langone and Maimonides Medical Center
health problems
are offering buprenorphine initiation. Funding
and encourage
should be allocated to expand this program to
treatment
HHC facilities.
33/36
DOHMH
Create or promote
According to the Department of Homeless
programs to de-
Services, New Yorkers who sleep on the streets
stigmatize mental
are their most uniquely challenged population
health problems
to engage, with higher rates of mental health
and encourage
and substance use disorders. Provide Funding
treatment
for training and certification to homeless
outreach service providers to
administer/prescribe buprenorphine and
Subaxone.
YOUTH, EDUCATION AND CHILD WELFARE
Brooklyn Community Board 11
image
M ost Important Issue Related to Youth, Education and Child Welfare
Other
Community Board 11 supports a variety of programs for youth including community based counselling, recreational, tutoring and cultural programs. However, the existing needs in our community far exceed the services available.
Additional needs which must be addressed are free/low cost daycare programs, job opportunities for youth, affordable summer programs/day camps and special programs for immigrant youth. Community Board 11 supports overall increased funding for youth services. With 37% of households with children under 18 years old, funding programs targeted to this population is crucial. Community Board 11 will continue to partner with our community based organizations and the Neighborhood Advisory Board to advocate for these services.
image
image
C ommunity District Needs Related to Youth, Education and Child Welfare
Needs for Youth Education
No comments
Needs for Youth and Child Welfare
No comments
image
Capital Requests Related to Youth, Education and Child Welfare
The Community Board did not submit any Budget Requests in this category.
Expense Requests Related to Youth, Education and Child Welfare
Priority Agency Request Explanation Location
image
28/36 DYCD Provide, expand, or
enhance after school programs for all grade levels
Community Board 11 supports an increase in funding for across the board youth programs.
PUBLIC SAFETY AND EMERGENCY SERVICES
Brooklyn Community Board 11
image
M ost Important Issue Related to Public Safety and Emergency Services
Other
According to the NYU Furman Center's, State of NYC's Housing and Neighborhoods in 2018, the serious crime rate in Bath Beach, Bensonhurst and the surrounding neighborhood's within Community Board 11 was 5.3 per 1,000 residents, one of the safest communities citywide. While we applaud the men and women of the 62nd Precinct for their work in keeping our community safe; quality of life complaints remain high. During fiscal year 2019, the 62nd Precinct responded to 19,100 non-emergency service requests through the 311 system.
image
image
C ommunity District Needs Related to Public Safety and Emergency Services
Needs for Public Safety
As previously stated, according to NYU Furman Center’s, State of New York City's Housing and Neighborhoods in 2018, the serious crime rate was 5.3 per 1,000 residents, making Bensonhurst one of the safest communities citywide. While we applaud, the men and women of the 62nd Precinct for the work that they do to keep our community safe, quality of life complaints remain high. The 62nd Precinct, from June 1, 2018 to July 31, 2019, received 19,100 non-emergency service requests via the 311 system.
During fiscal year 2019, there were about 10, 200 complaints filed for illegal parking and 5,000 complaints filed for blocked driveways.
There is a need for increased manpower so that patrol services can adequately handle emergency calls and non- emergency calls for service. Over the past several years, area residents have ongoing concern regarding the proliferation of trucks and large tractor-trailers traversing through the community. While legislation has been enacted to increase the penalties to truckers that travel off the designated truck route, additional enforcement personnel are needed to ensure compliance.
Needs for Emergency Services
No comments
image
Capital Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
18/27
NYPD
Renovate or
The sidewalks surrounding the 62nd Precinct,
1925 Bath
upgrade existing
located at 1925 Bath Avenue, are in need of
Avenue
precinct houses
replacement to prevent trip hazards and injury.
27/27
NYPD
Other NYPD
Funding for generators at Police Precincts
facilities and
citywide.
equipment requests
(Capital)
Expense Requests Related to Public Safety and Emergency Services
Priority
Agency
Request
Explanation
Location
1/36
NYPD
Assign additional
The staffing of Patrol Officers/Detectives for the
uniformed officers
62nd Precinct is appropriated 125. There is a
need for increased manpower so that patrol
services can adequately handle emergency calls
and non-emergency calls for service.
6/36
NYPD
Provide resources to
The Police Department is the enforcement arm
train officers, e.g. in
of some regulatory agencies. Many of the
community policing
quality of life complaints, as it relates to general
vending, mobile food vending, restricted streets,
and oversized stoopline stands are codified by
the Rules of the City of New York and the
Administrative Code. Additional training is
needed to address and recognize these
conditions.
12/36
NYPD
Other NYPD
Additional funding is requested to enhance
programs requests
truck enforcement. Presently the truck
enforcement unit is understaffed and cannot
address the increased amount of truck traffic on
our streets.
24/36
FDNY
Expand funding for
Increase funding for the Office of Community
fire prevention and
Affairs to expand citywide open houses and
life safety initiatives
summer block parties to promote fire safety.
34/36
NYPD
Provide additional
Funding is requested for for life cycle
patrol cars and
replacement vehicles for Fleet Services.
other vehicles
35/36 FDNY Other FDNY facilities
and equipment requests (Expense)
Funding is requested for a Major Emergency Response Vehicle and bariatric ambulances.
image
36/36 NYPD Other NYPD
programs requests
Funding is requested to off-set the annual dues fee for children participating in the Explorers Program.
image
CORE INFRASTRUCTURE, CITY SERVICES AND RESILIENCY
Brooklyn Community Board 11
image
M ost Important Issue Related to Core Infrastructure, City Services and Resiliency
Other
While all categories relating to core infrastructure and city services are high priorities to this community, issues relating to street cleanliness are the most common recurring complaints that the district office receives. There is a need for additional personnel and equipment to address improper disposal, littering, and failure to clean. The southern boundary of the district is Gravesend Bay and all efforts need to be taken to keep litter out of the waterway. As our capital priorities reflect, there is a need to plan for long term coastal protection due to tidal surge and wave action along the Shore Parkway promenade. Salt water wash-over is a frequent occurrence between the promenade and the Belt Parkway, between Bay 8th Street and Bay Parkway. This area should be made more resilient to absorb both saltwater and storm run-off. Native plantings and progressive planning are needed to increase absorption and protect inland residential properties from future storms.
image
image
C ommunity District Needs Related to Core Infrastructure, City Services and Resiliency
Needs for Water, Sewers, and Environmental Protection
Over the past fiscal years, we have seen extreme weather, from Hurricane Sandy to record setting blizzards, all of which have taken a toll on our streets and infrastructure. The board has identified roadways that are sinking, hummocked and have had numerous reoccurring cave-ins.
Our community has seen a proliferation of illegal curb cuts, as well as the removal of front yard gardens to create concrete parking pads. Many of these locations received violations from the Department of Buildings, could never be legalized and are contrary to the Streetscape Preservation zoning text. While this could be viewed as a Department of Buildings issue, we believe this is an issue of resiliency and sustainability.
Properties that have been violated for illegal curb cuts and/or parking pads should not be omitted from the Green Infrastructure Program or the Street Tree Planting Program. Efforts should be made to coordinate with the Department of Buildings to determine legal status.
With areas of the community now located in the special flood hazard areas efforts need to be made to increase permeability, divert storm water from our sewer system and help reduce discharges from the combined sewer outfalls.
Needs for Sanitation Services
With increased population and development, there is a need for additional sanitation personnel and equipment, specifically in the area of cleaning activities.
The District Office continues to receive complaints relating to illegal drops offs, improper disposal, illegal posting, and litter. There is a need for motorized litter patrol to address street cleanliness, an expanded anti-litter campaign for outreach, education and enforcement. There is also a need for an increase in Sanitation Enforcement Agents. Currently, there are two agents enforcement agents per day assigned to Community Board 11.
image
Capital Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
5/27
DEP
Investigate odor
Fund study to determine the feasibility of
17th Ave
complaints about a
installing a tidal gate at the 17th Avenue
Shore
wastewater facility
combined sewer outfall to prevent discharge
parkway
and address/repair
and washout of sewage into Gravesend Bay.
Promenade
or make equipment
The 17th Avenue combined sewer outfall has
improvements as
dry weather discharges of sewage into
needed (Capital)
Gravesend Bay. It has been suggested that this
is due to washout of the pipe due to tidal action.
A tidal gate would prevent these occurrences
and the associated smell of sewage in the
community.
6/27
DEP
Inspect sanitary
Study and planning to reconstruct Shore
Shore
sewer on specific
Parkway from Bay 20th Street to Bay 8th Street.
Parkway 21st
street segment and
This segment of the roadway has cave-ins along
Avenue Bay
repair or replace as
the sewer-line in the center roadway. While
8th Street
needed (Capital)
televising has been completed, planning needs
to be initiated to address flooding, drainage and
roadway integrity. Capital Project STORM, HLSS
& SANITARY SEWER & WM IN CROPSEY
AVE(SE883),addresses the area of Shore
Parkway from 21 Avenue to Bay 20th Street.
7/27
DEP
Inspect sanitary
Bay Parkway between Bath Avenue and 86th
Bay Parkway
sewer on specific
Street has multiple cave-ins, raised manholes
Bath Avenue
street segment and
and the center of the roadway is depressed. This
86th Street
repair or replace as
location may be in need of a trench restoration
needed (Capital)
project; however, this location needs to be
prioritized to address roadway conditions.
8/27
DEP
Inspect sanitary
Bay Ridge Avenue between 15th and 17th
Bay Ridge
sewer on specific
Avenues has multiple cave-ins, raised manholes,
Avenue 15th
street segment and
and the center of the roadway is depressed. This
Avenue 17th
repair or replace as
location may be in need of a trench restoration
Avenue
needed (Capital)
project; however, this location needs to be
identified and prioritized to address roadway
conditions.
9/27
DEP
Inspect sanitary
The area bounded by Shore Parkway to Benson
sewer on specific
Avenue and Bay Parkway to 26th Avenue,
street segment and
following Hurricane Sandy has experienced
repair or replace as
street flooding during heavy rains. A study
needed (Capital)
should be initiated to determine the cause of
this new issue.
15/27
DSNY
Maintain replacement cycle for trucks and equipment
New mechanical brooms are needed to replace the aging equipment within the fleet.
19/27
DEP
Investigate odor
Provide funding to study the removal of
complaints about a
permeable surfaces for illegal front yard parking
wastewater facility
and the amount of storm water that could be
and address/repair
diverted from the system thereby preventing
or make equipment
combined sewer overflows.
improvements as
needed (Capital)
23/27
DEP
Inspect sanitary
Initiate study and planning to address the new
Bay Parkway
sewer on specific
flooding issue on Bay Parkway and Shore
Shore
street segment and
Parkway.
Parkway
repair or replace as
Gravesend
needed (Capital)
Bay
Expense Requests Related to Core Infrastructure, City Services and Resiliency
Priority
Agency
Request
Explanation
Location
2/36
DSNY
Other garbage
Assign additional personnel for motorized litter
collection and
patrols to address litter and drop-offs within the
recycling requests
district.
7/36
DSNY
Improve snow
Allocate an additional salt spreader for the Belt
Belt Parkway
removal
Parkway. Currently the allocation of spreaders
Cropsey
provides one for each section. The Belt Parkway
Avenue 69th
should have a dedicated salt spreader that is
Street
not from BK 11's allotment.
13/36
DSNY
Provide more
Allocate funding for dedicated basket truck on
frequent litter
day-line for DSNY. This would insure that the
basket collection
commercial corridors would be serviced daily in
the early morning hours and prevent overflow.
14/36
DSNY
Increase
Our community has been bombarded with
enforcement of
illegally posted "moving" signs and "cash for
illegal posting laws
cars" advertisements throughout this district.
Many poles are plastered with old tape and torn
off fliers are often littered in the streets.
18/36
DSNY
Other cleaning
Allocate funding for dedicated 12AM - 8AM
requests
broom Our community has commercial and
manufacturing areas that have overnight street
cleaning regulations. The dedicated broom
would provide cleaning services on a daily basis
and could provide additional cleaning service to
the commercial corridors.
19/36
DSNY
Other enforcement
Allocate Funding for Additional Sanitation
requests
Enforcement. Additional enforcement agents
are needed to address illegal dumping and/or
drop offs, improve ability to conduct
surveillance and apprehend those illegally
dumping, and would ensure that there is
adequate coverage to enforce residential and
commercial routing times.
20/36
DSNY
Provide more
Provide baseline funding for additional basket
frequent litter
truck collection on commercial strips within
basket collection
Community Board 11. One collection is not
enough to address the overflowing baskets on
our commercial strips.
22/36
DSNY
Other garbage
Allocate additional manpower to address "work
collection and
left out" in the district. Garbage that is not
recycling requests
collected attract litter, dumping and rodents.
31/36
DSNY
Increase
Litter is an ongoing complaint received by
enforcement of
Community Board 11. To keep litter from
dirty sidewalk/dirty
entering our waterways and surrounding
area/failure to clean
beaches, enforcement of existing litter laws
area laws
need to be enforced.
HOUSING, ECONOMIC DEVELOPMENT AND LAND USE
Brooklyn Community Board 11
image
M ost Important Issue Related to Housing, Economic Development and Land Use
Land use and zoning
There is a need for City Planning to conduct a comprehensive review of the district to assess the need for additional core services needed by this community. Community Board 11 has seen an increase in the amount of as of right development. In a small 2 block segment of our community there are approved plans for 437 new residential units within a 2 block segment. Had these projects undergone discretionary zoning approval a full environmental impact statement would have been required. The housing stock within the district includes many smaller properties that are underdeveloped in relation to the development rights provided under existing zoning and there has been a trend for such properties to be fully developed. Such development analysis and projections would assist Community Board 11 in advocating for appropriate level of service for Police, Sanitation, Transportation and Parks services.
Additionally, reviews of schools of the adequacy for school seat capacity and utilization, needs for child care slots, and for senior services should be reviewed to determine the ability to support added growth. This community will not be sustainable without addressing the need for additional services.
image
image
C ommunity District Needs Related to Housing, Economic Development and Land Use
Needs for Land Use
There has been an increase in the number of illegal activities, such as non-approved construction, building alterations, illegal curb cuts, and the creation of front yard parking pads and zoning violations. Our community over the past few years has numerous complaints for illegal conversions and adult entertainment establishments. This type of building activity and use is a safety issue for the residents who reside in illegally occupied housing and for emergency responders. It is imperative to our residential community and quality of life that policy be implemented to expeditiously close adult entertainment establishments that violate the zoning resolution. With increased population, density, and plans for new development a study should be initiated to determine how much additional development can be supported by existing infrastructure. The Department of Buildings needs increased enforcement authority. Inspectors responding to building complaints are denied access and complaints are closed after two attempts. In addition, there needs to be additional authority as it relates to illegal curb cuts and parking pads. While many locations have received violations, there is no mechanism to enforce compliance. This is not just a quality of life issue it is one of sustainability. The removal of front yards and green space limits our storm water absorption. Community Board 11 supports the city making restoration of illegal curb cuts and billing the property owner, similar to the Department of Transportation's Sidewalk Program.
Needs for Housing
Community Board 11 is home to a large population of older adults. A portion of our district has been designated a Naturally Occurring Retirement Community (NORC). It is vital that adequate assistance be given to the Board through programs administered by the Department of Housing Preservation and Development, particularly Article 8A loans in addition to an increase in community development funding for housing programs.
Needs for Economic Development
Initiate study for ferry service from the Bay Parkway Landing. "Gravesend - Bensonhurst New York Rising Community Reconstruction Plan (December 2014), multi-purpose ferry service, with the primary goal of emergency transportation during disaster events as well as year-round benefits such as commuter ferry service, economic development opportunities or recreational access to the waterfront. During Superstorm Sandy, the Community’s transportation network was cut off by inundated roadways, flooding on the N subway line, and tree damage on the D subway line, leaving only the F subway line functioning. Nearby communities such as Red Hook in Brooklyn,the Rockaways in Queens, and Staten Island had emergency ferry service after Superstorm Sandy. Similar emergency ferry service would have increased transportation opportunities for Gravesend and Bensonhurst after the disaster to speed the Community’s recovery. This project would analyze potential sites for multi-purpose ferry service, with the
primary goal of emergency transportation during disaster events as well as year-round benefits such as commuter ferry service, economic development opportunities, or recreational access to the waterfront. This project could complement the Citywide Ferry Study Preliminary Report, published in 2013 by NYC EDC, which evaluated potential sites for fast ferry service. One potential location for a resilient dock is the end of Bay Parkway, where storm surge entered the Community and the adjacent seawall was damaged during Superstorm Sandy. A dock at this location could be constructed in conjunction with a potential seawall-raising project to provide better protection to the upland areas. If feasible, this location near the Bensonhurst Park Tennis Center would also facilitate transportation of local workers after a disaster to other areas in the city."
image
Capital Requests Related to Housing, Economic Development and Land Use
Priority Agency Request Explanation Location
image
13/27 HPD Expand loan programs to rehabilitate multiple dwelling buildings
Increase Community Development Funding for Housing Programs. Housing stock in area has deteriorated. To keep landlords from abandoning buildings, funding is needed for loans to rehabilitate their properties.
image
17/27 EDC Invest in capital
projects to improve access to the waterfront
Initiate study for ferry service from the Bay Parkway Landing. With increased development along the waterfront of CB 11 and neighboring waterfront communities, a study should be initiated to provide alternative transportation modes. Residents currently have a 47 minute commute. Ferry service could provide alternative transportation service especially during during emergencies, to provide economic development opportunities, reduce congestion on our roadways and provide recreational access to our waterfront.
Expense Requests Related to Housing, Economic Development and Land Use
Priority
Agency
Request
Explanation
Location
4/36
DCP
Other zoning and
Initiate comprehensive review of the district to
land use requests
assess the need for additional core services.
With increased as-of-right development and
population, data is needed to determine if our
infrastructure and core services can support
additional population growth.
10/36
NYCHA
Expand tenant
Allocate funding for HPD Housing Litigation.
protection programs
Housing Litigators bring non conforming
landlords to court to advocate on behalf of
tenants.
11/36
DOB
Assign additional
The illegal use of building and zoning infractions
building inspectors
are increasing. Inspections and follow-ups are
(including
needed to ensure compliance. Additional
expanding training
inspectors should be hired.
programs)
16/36
EDC
Expand graffiti
Graffiti removal services should be expanded to
removal services on
preserve our commercial corridors and maintain
private sites
property values in our community.
21/36 NYCHA Expand programs
for housing inspections to correct code violations
Allocate additional funding for H.P.D. Code Enforcers. Funding is needed for additional personnel to inspect citizen complaints.
image
23/36 SBS Support merchant
organizing
Community Board 11 has several strong commercial corridors with no formal merchant's association or BID. There are many programmatic opportunities available for organized merchants.
image
TRANSPORTATION
Brooklyn Community Board 11
image
M ost Important Issue Related to Transportation and Mobility
Other
All transportation and mobility issues are a high priority for this community, from accessibility to traffic safety. Over the past few years, the weather has taken a toll on our streets. The Department of Transportation has recently resurfaced many streets throughout the district, however there is still a need for additional streets to be resurfaced. High priority should be given to the inclusion of streets surveyed by this Department. Careful planning must be taken by all agencies to coordinate projects to prevent conflicts. In addition to weather related issues, many streets have had multiple street openings for utility work. Many of these locations do not wear as well as the roadway and the openings deteriorate. The segment of roadway on New Utrecht Avenue from 86th Street to 61 Street, is constructed of cement. Over the years the roadway has deteriorated due to wear and tear and utility openings.
There are intersections especially in the low 70's, where asphalt has been placed to make necessary repairs. These temporary repairs, especially those located in the crosswalk, have left uneven crossings and potential trip hazards. With the installation of new 3 and 4-way stop signs and bicycle infrastructure, periodic inspections of high usage corridors should be made to ensure that thermoplastic markings are in good condition and visible. Along many of our commercial corridors the streets have hummocked within the bus stops. Additional repairs are needed to make the street safer for all users of the roadway. According to the State of New York City's Housing and Neighborhoods in 2018, the mean travel time to work is 47.4 minutes. A study to determine the feasibility of initiating multi-purpose ferry service from the Bay Parkway Landing. This service would provide year round benefits as a commuter ferry service and emergency transportation during a disaster.
image
image
C ommunity District Needs Related to Transportation and Mobility
Needs for Traffic and Transportation Infrastructure
As our capital priorities recommendations reflect there are multiple roadways that may be in need of trench restoration projects. While funding was allocated for the first phase of restorations, additional funding is needed for additional trench restoration projects that have been identified by the Department of Transportation.
Needs for Transit Services
No comments
image
Capital Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
3/27
DOT
Install streetscape
New Utrecht Avenue within the confines of
New Utrecht
improvements
Community Board 11 is a wholly commercially
Avenue 86th
zoned corridor located under the elevated train.
Street 61
This segment is in need of reconstruction, which
Street
includes additional security lighting, benches,
bike racks and resurfacing of the existing
cement roadway.
4/27
DOT
Upgrade or create
Guardrails to do not protect the Shore Parkway
Shore
new greenways
Green-way from Bensonhurst Park to Bay 8th
Parkway
Street on the Belt Parkway side. Users of the
Greenway
green-way and the planted areas should be
Bensonhurst
protected from motor vehicles. There are no
Park Bay 8th
shoulders, most of the curbing is deteriorated or
Street
are below grade, and motorists are using this
open space for parking.
14/27
DOT
Other
Funding is requested for the next phase of
transportation
trench restorations.
infrastructure
requests
16/27
DOT
Other
Relocate eastbound Belt Parkway entrance from
Shore
transportation
Bay Parkway easterly. With increased
Parkway Bay
infrastructure
population and vehicular traffic, planning needs
Parkway 26
requests
to be initiated to allow access to east bound Belt
Avenue
Parkway. Presently, vehicles cannot enter the
eastbound Belt Parkway upon exiting the
shopping centers on Shore Parkway. This may
also address congestion at the Bay Parkway two
left turn lanes onto Shore Parkway.
20/27
DOT
Repair or construct
Fund citywide concrete curbing program for
new curbs or
commercial and multiple dwelling properties.
pedestrian ramps
21/27
DOT
Other
Street name signs and alternate side parking
transportation
signs throughout the district are faded and
infrastructure
illegible. Requests have been made for
requests
replacement signs as submitted by DSNY.
Funding should be provided so that a contract
can be let to replace all illegible signs within the
Community District.
24/27 DOT Other transportation infrastructure requests
Allocate funding for the expanded installation of bus countdown clocks at various locations within Community Board 11.
image
25/27 DOT Other transportation infrastructure requests
Allocate funding for the installation of pedestrian countdown clocks at various locations.
Expense Requests Related to Transportation and Mobility
Priority
Agency
Request
Explanation
Location
17/36
DOT
Improve traffic and
Allocate funding for Vision Zero messaging
pedestrian safety,
through the banner program on priory corridors
including traffic
and high crash locations.
calming (Expense)
26/36
DOT
Other expense
Allocate additional funding for the milling and
traffic
resurfacing program.
improvements
requests
27/36
DOT
Other expense
Allocate additional funding for the night
traffic
resurfacing program.
improvements
requests
image
PARKS, CULTURAL AND OTHER COMMUNITY FACILITIES
Brooklyn Community Board 11
image
M ost Important Issue Related to Parks, Cultural and Other Community Facilities
Park care and maintenance
Almost every park with Community Board 11 has received funding for renovations. Recently, Seth Low Park, Benson Park, and Lt. Joseph Petrosino Park were completed. Bensonhurst Park and Bath Beach Park are in various stages of design and construction phases. These rehabilitation projects have significantly enhanced our community.
Bensonhurst Park including the promenade are in need of capital improvements. Both are in need of new equipment and surfaces. Additional resources are needed to address garbage collection, litter, and general maintenance issues.With only 45% of residential units within 1/4 mile of a park, and the increase in population, our existing parks are heavily used. There is also a need for increased park care, maintenance, and parks enforcement police.
image
image
C ommunity District Needs Related to Parks, Cultural and Other Community Facilities
Needs for Parks
Bensonhurst Park including the promenade are in need of capital improvements. Both are in need of new equipment and surfaces. Community Board 11 supports the reconstruction and rehabilitation of the Shore Parkway Promenade from Bay 8th Street through Bay Parkway. This section of the promenade is in need of mitigation and resiliency efforts to protect the Belt Parkway, residential properties, businesses, and infrastructure from future storms. The parkway itself needs to be protected from storm surge and wave action so that first responders and military can move people and goods during an emergency.
Needs for Cultural Services
No comments
Needs for Library Services
No comments
Needs for Community Boards
No comments
image
Capital Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
1/27
DPR
Reconstruct or
Initiate study and planning for long term coastal
Shore
upgrade a park or
protections due to tidal surge and wave action
Parkway
amenity (i.e.
on the Shore Parkway Promenade from Bay 8th
Promenade
playground, outdoor
Street across Bay Parkway This area from Bay
Bay Parkway
athletic field)
Parkway to Bay 8th Street floods during high
Bay 8th Street
tides and storms. Infrastructure needs to be
protected as well as evacuation routes.
2/27
DPR
Reconstruct or
Initiate study and planning of the open space
Shore
upgrade a park or
along the Belt Parkway from Bay Parkway to
Parkway
amenity (i.e.
Bay 8th Street to mitigate storm surge and be
Promenade
playground, outdoor
more resilient in order to protect infrastructure
Bay Parkway
athletic field)
and property. The open space along the Belt
Bay 8th Street
Parkway should be utilized to absorb seawater
to protect infrastructure and property. Currently
the open space consists of dead grass and dirt.
Native plantings and progressive planning
would increase absorption and improve
resiliency.
10/27
DPR
Reconstruct or
Bensonhurst Park recently received funding for
upgrade a park or
phase 1 and phase 2 of renovations. are
amenity (i.e.
Additional funding is requested for the final
playground, outdoor
renovation phases.
athletic field)
11/27
DPR
Reconstruct or
Additional funding is requested for
upgrade a park or
refurbishment of the basketball and handball
amenity (i.e.
courts.
playground, outdoor
athletic field)
12/27
DPR
Other requests for
The sidewalk area along the perimeter of Bath
park, building, or
Beach Park is in need of sidewalk replacement.
access
There are areas that are broken and crumbling
improvements
that are in need of repair.
22/27
DPR
Reconstruct or
Bath Playground is a jointly operated
upgrade a park or
playground that serves the community and
amenity (i.e.
Joseph B. Cavallaro Junior High School. The park
playground, outdoor
is in need of modernization to the children's play
athletic field)
area.
26/27
DPR
Reconstruct or
Explore the feasibility for the placement of a
upgrade a parks
comfort station and water fountain/bottle filler
facility
near the vicinity of the Bensonhurst Park Ball
Fields and the Shore Parkway Bike Path.
Expense Requests Related to Parks, Cultural and Other Community Facilities
Priority
Agency
Request
Explanation
Location
3/36
DPR
Forestry services,
Improve Forestry Operations. Assign additional
including street tree
pruners and climbers borough-wide. While the
maintenance
trees are dying, manpower needed to care for
our trees has diminished. The Board
recommends that either additional manpower
be hired or contractors should make the
necessary repairs.
8/36
DPR
Enhance park safety
Allocate Funding for Park Enforcement Police.
through more
Additional Park Enforcement Patrol officers are
security staff (police
needed for parks within Community Board 11.
or parks
enforcement)
9/36
DPR
Improve trash
Assign Additional Maintenance and Recreation
removal and
Workers. The parks in Community Board 11 are
cleanliness
fully utilized and additional maintenance and
recreation workers are needed to address
increased trash and litter.
6. OTHER BUDGET REQUESTS
Other Capital Requests
The Community Board did not submit any Budget Requests in this category.
Other Expense Requests
Priority Agency Request Explanation Location
image
5/36 Other Other expense
budget request
Provide funding to the Department of Transportation for additional inspectors for Brooklyn Highway Inspections and Quality Assurance.
image
29/36 Other Other expense
budget request
Allocate funding for additional cleaning personnel for arterial highways.
7. SUMMARY OF PRIORITIZED BUDGET REQUESTS
Capital Budget Requests
Priority
Agency
Request
Explanation
Location
1/27
DPR
Reconstruct or
Initiate study and planning for long term coastal
Shore
upgrade a park or
protections due to tidal surge and wave action
Parkway
amenity (i.e.
on the Shore Parkway Promenade from Bay 8th
Promenade
playground, outdoor
Street across Bay Parkway This area from Bay
Bay Parkway
athletic field)
Parkway to Bay 8th Street floods during high
Bay 8th Street
tides and storms. Infrastructure needs to be
protected as well as evacuation routes.
2/27
DPR
Reconstruct or
Initiate study and planning of the open space
Shore
upgrade a park or
along the Belt Parkway from Bay Parkway to
Parkway
amenity (i.e.
Bay 8th Street to mitigate storm surge and be
Promenade
playground, outdoor
more resilient in order to protect infrastructure
Bay Parkway
athletic field)
and property. The open space along the Belt
Bay 8th Street
Parkway should be utilized to absorb seawater
to protect infrastructure and property. Currently
the open space consists of dead grass and dirt.
Native plantings and progressive planning
would increase absorption and improve
resiliency.
3/27
DOT
Install streetscape
New Utrecht Avenue within the confines of
New Utrecht
improvements
Community Board 11 is a wholly commercially
Avenue 86th
zoned corridor located under the elevated train.
Street 61
This segment is in need of reconstruction, which
Street
includes additional security lighting, benches,
bike racks and resurfacing of the existing
cement roadway.
4/27
DOT
Upgrade or create
Guardrails to do not protect the Shore Parkway
Shore
new greenways
Green-way from Bensonhurst Park to Bay 8th
Parkway
Street on the Belt Parkway side. Users of the
Greenway
green-way and the planted areas should be
Bensonhurst
protected from motor vehicles. There are no
Park Bay 8th
shoulders, most of the curbing is deteriorated or
Street
are below grade, and motorists are using this
open space for parking.
5/27
DEP
Investigate odor
Fund study to determine the feasibility of
17th Ave
complaints about a
installing a tidal gate at the 17th Avenue
Shore
wastewater facility
combined sewer outfall to prevent discharge
parkway
and address/repair
and washout of sewage into Gravesend Bay.
Promenade
or make equipment
The 17th Avenue combined sewer outfall has
improvements as
dry weather discharges of sewage into
needed (Capital)
Gravesend Bay. It has been suggested that this
is due to washout of the pipe due to tidal action.
A tidal gate would prevent these occurrences
and the associated smell of sewage in the
community.
6/27
DEP
Inspect sanitary
Study and planning to reconstruct Shore
Shore
sewer on specific
Parkway from Bay 20th Street to Bay 8th Street.
Parkway 21st
street segment and
This segment of the roadway has cave-ins along
Avenue Bay
repair or replace as
the sewer-line in the center roadway. While
8th Street
needed (Capital)
televising has been completed, planning needs
to be initiated to address flooding, drainage and
roadway integrity. Capital Project STORM, HLSS
& SANITARY SEWER & WM IN CROPSEY
AVE(SE883),addresses the area of Shore
Parkway from 21 Avenue to Bay 20th Street.
7/27
DEP
Inspect sanitary
Bay Parkway between Bath Avenue and 86th
Bay Parkway
sewer on specific
Street has multiple cave-ins, raised manholes
Bath Avenue
street segment and
and the center of the roadway is depressed. This
86th Street
repair or replace as
location may be in need of a trench restoration
needed (Capital)
project; however, this location needs to be
prioritized to address roadway conditions.
8/27
DEP
Inspect sanitary
Bay Ridge Avenue between 15th and 17th
Bay Ridge
sewer on specific
Avenues has multiple cave-ins, raised manholes,
Avenue 15th
street segment and
and the center of the roadway is depressed. This
Avenue 17th
repair or replace as
location may be in need of a trench restoration
Avenue
needed (Capital)
project; however, this location needs to be
identified and prioritized to address roadway
conditions.
9/27
DEP
Inspect sanitary
The area bounded by Shore Parkway to Benson
sewer on specific
Avenue and Bay Parkway to 26th Avenue,
street segment and
following Hurricane Sandy has experienced
repair or replace as
street flooding during heavy rains. A study
needed (Capital)
should be initiated to determine the cause of
this new issue.
10/27
DPR
Reconstruct or
Bensonhurst Park recently received funding for
upgrade a park or
phase 1 and phase 2 of renovations. are
amenity (i.e.
Additional funding is requested for the final
playground, outdoor
renovation phases.
athletic field)
11/27
DPR
Reconstruct or
Additional funding is requested for
upgrade a park or
refurbishment of the basketball and handball
amenity (i.e.
courts.
playground, outdoor
athletic field)
12/27
DPR
Other requests for
The sidewalk area along the perimeter of Bath
park, building, or
Beach Park is in need of sidewalk replacement.
access
There are areas that are broken and crumbling
improvements
that are in need of repair.
13/27
HPD
Expand loan
Increase Community Development Funding for
programs to
Housing Programs. Housing stock in area has
rehabilitate multiple
deteriorated. To keep landlords from
dwelling buildings
abandoning buildings, funding is needed for
loans to rehabilitate their properties.
14/27
DOT
Other
Funding is requested for the next phase of
transportation
trench restorations.
infrastructure
requests
15/27
DSNY
Maintain
New mechanical brooms are needed to replace
replacement cycle
the aging equipment within the fleet.
for trucks and
equipment
16/27
DOT
Other
Relocate eastbound Belt Parkway entrance from
Shore
transportation
Bay Parkway easterly. With increased
Parkway Bay
infrastructure
population and vehicular traffic, planning needs
Parkway 26
requests
to be initiated to allow access to east bound Belt
Avenue
Parkway. Presently, vehicles cannot enter the
eastbound Belt Parkway upon exiting the
shopping centers on Shore Parkway. This may
also address congestion at the Bay Parkway two
left turn lanes onto Shore Parkway.
17/27
EDC
Invest in capital
Initiate study for ferry service from the Bay
projects to improve
Parkway Landing. With increased development
access to the
along the waterfront of CB 11 and neighboring
waterfront
waterfront communities, a study should be
initiated to provide alternative transportation
modes. Residents currently have a 47 minute
commute. Ferry service could provide
alternative transportation service especially
during during emergencies, to provide economic
development opportunities, reduce congestion
on our roadways and provide recreational
access to our waterfront.
18/27
NYPD
Renovate or upgrade existing precinct houses
The sidewalks surrounding the 62nd Precinct, located at 1925 Bath Avenue, are in need of replacement to prevent trip hazards and injury.
1925 Bath Avenue
19/27
DEP
Investigate odor
Provide funding to study the removal of
complaints about a
permeable surfaces for illegal front yard parking
wastewater facility
and the amount of storm water that could be
and address/repair
diverted from the system thereby preventing
or make equipment
combined sewer overflows.
improvements as
needed (Capital)
20/27
DOT
Repair or construct
Fund citywide concrete curbing program for
new curbs or
commercial and multiple dwelling properties.
pedestrian ramps
21/27
DOT
Other
Street name signs and alternate side parking
transportation
signs throughout the district are faded and
infrastructure
illegible. Requests have been made for
requests
replacement signs as submitted by DSNY.
Funding should be provided so that a contract
can be let to replace all illegible signs within the
Community District.
22/27
DPR
Reconstruct or
Bath Playground is a jointly operated
upgrade a park or
playground that serves the community and
amenity (i.e.
Joseph B. Cavallaro Junior High School. The park
playground, outdoor
is in need of modernization to the children's play
athletic field)
area.
23/27
DEP
Inspect sanitary
Initiate study and planning to address the new
Bay Parkway
sewer on specific
flooding issue on Bay Parkway and Shore
Shore
street segment and
Parkway.
Parkway
repair or replace as
Gravesend
needed (Capital)
Bay
24/27
DOT
Other
Allocate funding for the expanded installation of
transportation
bus countdown clocks at various locations
infrastructure
within Community Board 11.
requests
25/27
DOT
Other
Allocate funding for the installation of
transportation
pedestrian countdown clocks at various
infrastructure
locations.
requests
26/27
DPR
Reconstruct or
Explore the feasibility for the placement of a
upgrade a parks
comfort station and water fountain/bottle filler
facility
near the vicinity of the Bensonhurst Park Ball
Fields and the Shore Parkway Bike Path.
27/27 NYPD Other NYPD
facilities and equipment requests (Capital)
Funding for generators at Police Precincts citywide.
image
Expense Budget Requests
Priority
Agency
Request
Explanation
Location
1/36
NYPD
Assign additional
The staffing of Patrol Officers/Detectives for the
uniformed officers
62nd Precinct is appropriated 125. There is a
need for increased manpower so that patrol
services can adequately handle emergency calls
and non-emergency calls for service.
2/36
DSNY
Other garbage
Assign additional personnel for motorized litter
collection and
patrols to address litter and drop-offs within the
recycling requests
district.
3/36
DPR
Forestry services,
Improve Forestry Operations. Assign additional
including street tree
pruners and climbers borough-wide. While the
maintenance
trees are dying, manpower needed to care for
our trees has diminished. The Board
recommends that either additional manpower
be hired or contractors should make the
necessary repairs.
4/36
DCP
Other zoning and
Initiate comprehensive review of the district to
land use requests
assess the need for additional core services.
With increased as-of-right development and
population, data is needed to determine if our
infrastructure and core services can support
additional population growth.
5/36
Other
Other expense
Provide funding to the Department of
budget request
Transportation for additional inspectors for
Brooklyn Highway Inspections and Quality
Assurance.
6/36
NYPD
Provide resources to
The Police Department is the enforcement arm
train officers, e.g. in
of some regulatory agencies. Many of the
community policing
quality of life complaints, as it relates to general
vending, mobile food vending, restricted streets,
and oversized stoopline stands are codified by
the Rules of the City of New York and the
Administrative Code. Additional training is
needed to address and recognize these
conditions.
7/36
DSNY
Improve snow
Allocate an additional salt spreader for the Belt
Belt Parkway
removal
Parkway. Currently the allocation of spreaders
Cropsey
provides one for each section. The Belt Parkway
Avenue 69th
should have a dedicated salt spreader that is
Street
not from BK 11's allotment.
8/36
DPR
Enhance park safety
Allocate Funding for Park Enforcement Police.
through more
Additional Park Enforcement Patrol officers are
security staff (police
needed for parks within Community Board 11.
or parks
enforcement)
9/36
DPR
Improve trash
Assign Additional Maintenance and Recreation
removal and
Workers. The parks in Community Board 11 are
cleanliness
fully utilized and additional maintenance and
recreation workers are needed to address
increased trash and litter.
10/36
NYCHA
Expand tenant
Allocate funding for HPD Housing Litigation.
protection programs
Housing Litigators bring non conforming
landlords to court to advocate on behalf of
tenants.
11/36
DOB
Assign additional
The illegal use of building and zoning infractions
building inspectors
are increasing. Inspections and follow-ups are
(including
needed to ensure compliance. Additional
expanding training
inspectors should be hired.
programs)
12/36
NYPD
Other NYPD
Additional funding is requested to enhance
programs requests
truck enforcement. Presently the truck
enforcement unit is understaffed and cannot
address the increased amount of truck traffic on
our streets.
13/36
DSNY
Provide more
Allocate funding for dedicated basket truck on
frequent litter
day-line for DSNY. This would insure that the
basket collection
commercial corridors would be serviced daily in
the early morning hours and prevent overflow.
14/36
DSNY
Increase
Our community has been bombarded with
enforcement of
illegally posted "moving" signs and "cash for
illegal posting laws
cars" advertisements throughout this district.
Many poles are plastered with old tape and torn
off fliers are often littered in the streets.
15/36
DOHMH
Reduce rat
There has been an increase in the amount of rat
populations
sightings being reported within the district. The
board has done extensive outreach, education
and made recommendations to reduce garbage
and food availability; there is still a need for
increased funding for inspection services and
abatement.
16/36
EDC
Expand graffiti
Graffiti removal services should be expanded to
removal services on
preserve our commercial corridors and maintain
private sites
property values in our community.
17/36
DOT
Improve traffic and pedestrian safety, including traffic calming (Expense)
Allocate funding for Vision Zero messaging through the banner program on priory corridors and high crash locations.
18/36
DSNY
Other cleaning
Allocate funding for dedicated 12AM - 8AM
requests
broom Our community has commercial and
manufacturing areas that have overnight street
cleaning regulations. The dedicated broom
would provide cleaning services on a daily basis
and could provide additional cleaning service to
the commercial corridors.
19/36
DSNY
Other enforcement
Allocate Funding for Additional Sanitation
requests
Enforcement. Additional enforcement agents
are needed to address illegal dumping and/or
drop offs, improve ability to conduct
surveillance and apprehend those illegally
dumping, and would ensure that there is
adequate coverage to enforce residential and
commercial routing times.
20/36
DSNY
Provide more
Provide baseline funding for additional basket
frequent litter
truck collection on commercial strips within
basket collection
Community Board 11. One collection is not
enough to address the overflowing baskets on
our commercial strips.
21/36
NYCHA
Expand programs
Allocate additional funding for H.P.D. Code
for housing
Enforcers. Funding is needed for additional
inspections to
personnel to inspect citizen complaints.
correct code
violations
22/36
DSNY
Other garbage
Allocate additional manpower to address "work
collection and
left out" in the district. Garbage that is not
recycling requests
collected attract litter, dumping and rodents.
23/36
SBS
Support merchant
Community Board 11 has several strong
organizing
commercial corridors with no formal merchant's
association or BID. There are many
programmatic opportunities available for
organized merchants.
24/36
FDNY
Expand funding for
Increase funding for the Office of Community
fire prevention and
Affairs to expand citywide open houses and
life safety initiatives
summer block parties to promote fire safety.
25/36
DOHMH
Promote Quit Smoking Programs
In recent years the smoking rates have declined citywide due to outreach, education and support; however there is still a need in our community to further these reductions.
26/36
DOT
Other expense
Allocate additional funding for the milling and
traffic
resurfacing program.
improvements
requests
27/36
DOT
Other expense
Allocate additional funding for the night
traffic
resurfacing program.
improvements
requests
28/36
DYCD
Provide, expand, or
Community Board 11 supports an increase in
enhance after
funding for across the board youth programs.
school programs for
all grade levels
29/36
Other
Other expense
Allocate funding for additional cleaning
budget request
personnel for arterial highways.
30/36
DFTA
Other senior center
Community Board 11 supports increased
program requests
funding for all categories of senior services.
31/36
DSNY
Increase
Litter is an ongoing complaint received by
enforcement of
Community Board 11. To keep litter from
dirty sidewalk/dirty
entering our waterways and surrounding
area/failure to clean
beaches, enforcement of existing litter laws
area laws
need to be enforced.
32/36
DOHMH
Create or promote
According to the Department of Health and
programs to de-
Mental Hygiene Emergency Departments at
stigmatize mental
NYU Langone and Maimonides Medical Center
health problems
are offering buprenorphine initiation. Funding
and encourage
should be allocated to expand this program to
treatment
HHC facilities.
33/36
DOHMH
Create or promote
According to the Department of Homeless
programs to de-
Services, New Yorkers who sleep on the streets
stigmatize mental
are their most uniquely challenged population
health problems
to engage, with higher rates of mental health
and encourage
and substance use disorders. Provide Funding
treatment
for training and certification to homeless
outreach service providers to
administer/prescribe buprenorphine and
Subaxone.
34/36 NYPD Provide additional
patrol cars and other vehicles
Funding is requested for for life cycle replacement vehicles for Fleet Services.
image
35/36 FDNY Other FDNY facilities
and equipment requests (Expense)
Funding is requested for a Major Emergency Response Vehicle and bariatric ambulances.
image
36/36 NYPD Other NYPD
programs requests
Funding is requested to off-set the annual dues fee for children participating in the Explorers Program.
image

